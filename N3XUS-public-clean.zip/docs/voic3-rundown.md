# VOIC3 — what it is, how it is meant to work, and what works today

Written for you to look through and find solutions. Every "works" below was tested
against the running server today; every "does not" says why.

---

## What VOIC3 is

VOIC3 is the communications half of NEXUS — the part that lets the people in the
business talk to each other and to patients, without paying for Zoom, WhatsApp
Business, or a phone system.

It is one product made of five things that share a single message store:

1. **Messaging** — direct messages, department groups, and announcement-only channels.
2. **Calls** — one-to-one voice and video between two employees.
3. **Meetings** — many people at once, with a waiting room, host controls, and a
   recording you can keep.
4. **Presence** — who is online, busy, do-not-disturb or offline.
5. **Shared work** — templates, workflow cards, and the meeting side panel with chat
   and a shared whiteboard.

The design goal: **it runs on your own computer, on your own network, with no
account with anybody and no monthly fee.** Nothing leaves the machine unless you
send it somewhere.

---

## How it is meant to work

```
  Phone A ──┐
            ├──► NEXUS server (this PC, HTTPS) ──► encrypted database
  Phone B ──┘            │
                         └──► direct audio/video between the phones (WebRTC)
```

- **The server is the switchboard, not the pipe.** It stores messages, tells each
  phone who is online, and introduces two phones to each other. The actual voice and
  video go **directly between the phones** — that is what keeps it free.
- **Two phones find each other with STUN.** Each phone asks a STUN server "what is my
  public address?", tells the other phone, and they connect.
- **When they cannot connect directly, a TURN relay is needed.** The relay carries
  the audio when two networks will not let the phones reach each other. This is the
  single most important thing missing (see below).
- **The phone asks the server what it can do** (`/api/voic3/rtc/capabilities`) and
  then picks the simplest route: direct call, SFU for big meetings, or relay.
- **Recording** is captured in the browser and uploaded to the server in one piece,
  saved under `Data/voic3_uploads/`, and posted into the meeting's conversation so it
  is not lost.
- **Offline** messages queue on the phone and are sent when the connection returns,
  in the order they were typed.

---

## What works — tested today

| Feature | Evidence |
|---|---|
| **Conversations list** | 200 in 0.02 s |
| **Sending a message** | 201, message stored |
| **Message search** | 200 |
| **Presence (online / busy / DND)** | 200 |
| **Message templates** | 200 |
| **Push notifications** | VAPID public key served, 200 |
| **Call history** | 200 |
| **Meeting list** | 200 |
| **Meetings: every host control** | **20/20 actions 200** — create, join by code, snapshot, poll, raise hand, reaction, mute all, lock, unlock, spotlight, end for all |
| **Two people in one meeting** | both joined and polled concurrently, 0.01–0.03 s |
| **1:1 call start, signalling, ICE, answer, end** | 201 / 201 / 200 / 403-correct / 200 |
| **Hang-up** | fixed this week — now actually ends the call |
| **Finding a colleague by number** | new `/api/mobile/directory`, 5 people |
| **End-to-end encryption flag** | reported **enabled** |
| **Meeting recording** | 400 KB round-trip byte-identical; 25 MB cap; 20 MB upload in 0.3 s |
| **Offline outbox** | built (Section 12) |
| **Workflow cards** | route live, rejects unknown card types correctly (400) |
| **Whiteboard + meeting chat** | built (Section 10) |

---

## What does not work — and exactly why

### 1. Calls between two different mobile networks
**Why:** no TURN relay is configured. STUN (which we have) only works when the two
phones can reach each other. Two carriers will not allow it.
**What I verified:** no free Windows coturn build exists; the free public relay is
dead (ports 3478/443/80 all time out); but your **outbound UDP works** — Google and
Cloudflare STUN both replied.
**Solutions:** free Cloudflare Tunnel (recommended, no account), or coturn built from
source.

### 2. Large meetings (more than ~6 people)
**Why:** the SFU is off — `/api/voic3/rtc/capabilities` reports `"sfu": {"enabled":
false}`. It needs LiveKit, which needs `VOIC3_LIVEKIT_URL`, `VOIC3_LIVEKIT_API_KEY`
and `VOIC3_LIVEKIT_API_SECRET`. Self-hosting LiveKit is free, but it is a second
service to run.
**Today:** meetings work peer-to-peer, which is fine up to about six people and then
the upload bandwidth of the host's PC becomes the limit.

### 3. Transcription / live captions
**Why:** `"transcription": {"enabled": false}` — no local Whisper engine installed.
**Fix, free:** `pip install faster-whisper`. It runs locally, no API key, no fee.

### 4. Voice notes and attachments over a slow link
**Why:** not broken, but the whole file goes in one upload with a 30-second stall
limit. On a bad 3G link a long voice note will time out with "Upload timed out."
**Fix:** the same chunked upload that recording already uses.

### 5. Calls on 4G need the laptop to stay awake
**Why:** the switchboard is this PC. If it sleeps or closes, nobody can call anybody.
**Fix:** a free Cloudflare Tunnel plus keeping the machine awake, or accept office-only.

### 6. The certificate warning on every phone
**Why:** self-signed certificate.
**Fix:** Cloudflare Tunnel (real certificate) or `mkcert` for the office Wi-Fi.

### 7. Two real people have never used it
**Why:** I tested with one session plus direct requests. The two-person path is
proven at the protocol level, not with two humans holding two phones.
**Fix:** one real call, one on Wi-Fi and one on mobile data. Ten minutes, and it tells
us exactly which of the above actually bites.

---

## Where the code lives

| File | What it does |
|---|---|
| `web_backend.py` | all VOIC3 routes (~40 of them) |
| `ui/meetings.js` | the meeting screen — lobby, grid, spotlight, host toolbar, recording |
| `ui/shared/voic3_rtc.js` | the call engine — offers, answers, ICE |
| `ui/shared/voic3_sfu.js` | LiveKit path for big meetings (off until configured) |
| `ui/shared/voic3_offline.js` | the outbox that survives a dropped connection |
| `ui/shared/voic3_cards.js` | workflow cards |
| `voic3_sfu.py` | decides what the client should use |
| `voic3_push.py` | Web Push subscriptions |
| `voic3_workflow.py` | approval cards |
