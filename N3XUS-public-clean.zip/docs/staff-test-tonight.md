# Staff test tonight — three steps

**Link to share with staff:**
`https://YOUR_TUNNEL.trycloudflare.com/mobile`

*(This link changes whenever the tunnel restarts. If it does not load, the laptop is
asleep or the tunnel stopped — open the N3XUS icon on the desktop.)*

---

## 1. Put N3XUS on the home screen

**Android (Chrome)**
1. Open the link above.
2. Tap the **⋮** menu → **Add to Home screen** (sometimes "Install app").
3. Confirm. The **N3XUS** icon appears on the home screen.

**iPhone (Safari — must be Safari, not Chrome)**
1. Open the link in **Safari**.
2. Tap the **Share** button → **Add to Home Screen**.
3. Confirm. The **N3XUS** icon appears.

Once added it opens **full screen, no address bar**, like a real app.

**What was fixed to make this work:** the server was sending the service-worker
script with the wrong content type, so the browser silently refused to install the
app. That is fixed and verified — registration now succeeds.

---

## 2. On your laptop

There is now **one N3XUS icon**:
- on the **Desktop**
- in the **Start menu**

Double-click it. It starts the relay and the server together, minimised, and it is
the only thing you need to launch. (The console window must stay open — that *is* the
server.)

---

## 3. The call test — one phone on Wi-Fi, one on 4G

1. Phone A: join your office Wi-Fi, open the link, sign in.
2. Phone B: **turn Wi-Fi off**, use mobile data only, open the link, sign in.
3. On Phone A, find Phone B in the directory and start a video call.
4. Answer on Phone B.

**What to look for**
- Audio and video both ways
- Hang up, and confirm Phone B stops ringing/connected
- If it fails: tell me which phone showed the spinner, and whether the call
  connected but had no sound, or never connected at all

---

## Honest status of the six gaps you listed

| Gap | State tonight |
|---|---|
| **TURN relay not running** | **Fixed** — built as a native Windows `.exe`, running, allocation verified. *No WSL2, no admin rights needed after all.* |
| **Laptop must stay awake** | **Needs one click from you** — I cannot change Power Options without admin. Settings → System → Power → Screen and sleep → *When plugged in, never sleep*. |
| **Tunnel name changes on restart** | Not fixed. Free tunnels always get a new name. The fix is a named tunnel (needs a free Cloudflare account) or DuckDNS + Caddy (needs your router). Both free, neither tonight. |
| **`OWNER-TEST` exists** | Still there, for tonight's test. Say the word and I delete it. |
| **Backups on the same disk** | Not fixed — the backup runs nightly and is encrypted, but sits on `C:`. Plug in a USB drive and I will point the second copy at it. |
| **No git remote** | Not fixed — 60 commits on this disk only. Needs a repo you control; free. |

**Still true: R0 spent. No API keys. No subscriptions. No account with anybody.**

---

## One thing only you can do

**Router: forward UDP 3478 → `YOUR_SERVER_IP`.**

Without it, Wi-Fi ↔ Wi-Fi works and 4G ↔ anything that can already see the server
works, but **two phones on two different carriers will not connect**. If your router
blocks inbound UDP, tell me and I will switch the relay to TCP mode — one flag, one
minute.
