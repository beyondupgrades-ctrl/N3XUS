# Production readiness — what is live, what is not, and what must happen before launch

Checked against the running server (port 64281, HTTPS, LAN) and the live encrypted
database. Every claim below was tested, not assumed.

---

## The short answer

**The core is live and working.** Calls, meetings, messaging, the EVOLV3 academy,
leave, payslips, the document vault and the patient-care screens all answer
correctly and are wired to real routes — **347 API routes** in total.

**It is not yet safe to hand to real staff and real patients**, for four reasons,
none of them code quality:

1. **The HTTPS certificate is self-signed.** Every phone shows a scary warning.
   Fixable in a day, free.
2. **Calls between two different mobile networks still fail** — there is no TURN
   relay, and no free Windows build of coturn exists. Free fix: a Cloudflare
   Tunnel keeps everything on one network path.
3. **Nothing is backed up off this computer.** One disk failure loses everything.
4. **The test account `TST-9001` is still active** and the owner password is known
   only to you.

---

## Feature status

### Working now (verified by request, not by reading code)

| Area | Endpoints | State |
|---|---|---|
| **VOIC3 calls** | start, signal, ICE, answer, end, history | Working. Hang-up, self-answer, ICE and directory bugs fixed this week |
| **VOIC3 meetings** | create, join by code, snapshot, poll, raise hand, reaction, mute all, lock, unlock, spotlight, end for all | **20/20 actions returned 200**, two people polling at once |
| **Messaging** | conversations, messages, search, attachments, voice notes | Working |
| **EVOLV3 academy** | cards, quiz, rate, certificates, verify, enrol, my-courses | Working; certificate verify correctly rejects a fake code |
| **Leave / payslips / contracts / vault** | list, apply, PDF, upload, sign | Working |
| **Patient care** | list, detail, safety, walks, location, SOS, vitals, alerts, ack | Working, and **correctly refuses a patient that is not assigned to you** |
| **Roles** | 7 role types, invites, role-filtered tabs | Built and live — the phone shows only the tabs the role allows |
| **Meetings chat + whiteboard** | side panel, peer-to-peer strokes | Built (Section 10) |
| **Offline outbox / push / artwork / workflow cards / SFU** | Sections 11–15 | Built and committed |

### Deliberately locked (correct behaviour, not faults)

- **`/api/mobile/admin/*` answers 404 to a staff phone.** This is the gate working.
  An admin account gets 200.
- **Check-in is 403 unless the device is a paired company phone.**
- **Compliance export is 403 for staff.** Admin only.
- **A patient you are not assigned to is 403.**
- **One patient's alerts** now answer properly (was a real 404 — fixed).

### Not working — and why

| Item | State | What it needs |
|---|---|---|
| **Calls across mobile networks** | No TURN relay | Free Cloudflare Tunnel, or coturn built from source |
| **Phone trust warning** | Self-signed cert | Free CA cert (e.g. a free Let's Encrypt certificate via a tunnel, or your own CA installed on the company phones) |
| **Off-site backup** | None | A scheduled copy to a second disk or a free cloud bucket |
| **Owner console end-to-end** | Untested | One sign-in on the owner's phone |

---

## Before launch — in order, all free

1. **Deactivate `TST-9001`** (one command; I can do it the moment you say so).
2. **Put a real certificate on it** so no phone shows a warning.
3. **Set up a nightly backup** of `Beyond Registration/Data` to a second location.
4. **One real two-person call** on two different phones — one on Wi-Fi, one on
   mobile data — to confirm exactly what does and does not get through.
5. **One owner sign-in** so the seven admin screens get a real test.

## What I would not claim yet

- "Works on 4G" — it does not, without the tunnel.
- "Tested by two real users" — I tested with one session and direct requests;
  the two-person path is verified at the protocol level, not with two people.
- "Backed up" — it is not.
