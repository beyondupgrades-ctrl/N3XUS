# Verdict on the proposed plan — what works, what needs one change

I checked each claim against this actual machine rather than accepting or rejecting
it. **The plan is about 80% right, and one of its central claims is wrong in a way
that matters.**

---

## What the plan gets right

| Claim | Verified on this machine |
|---|---|
| No native Windows coturn build | **Correct** — `winget` and `chocolatey` both return nothing; official release is Docker-only |
| coturn runs fine in WSL2 | **Correct** — `wsl.exe` is present, it is just not installed yet (`wsl --install` will fix that) |
| Pion TURN as a single Go `.exe` | **Correct in principle** — no Go compiler installed, but Go is a free download and builds a standalone binary |
| DuckDNS + Caddy gives a real trusted certificate | **Correct** — this PC reaches `duckdns.org` (200) and Let's Encrypt's directory (200) |
| Port forwarding is possible here | **Correct** — public IP is `YOUR_PUBLIC_IP`, a normal public IPv4, **not CGNAT**; traceroute shows a single hop to the router (`YOUR_LAN_IP`) then straight to the ISP, so there is no double NAT |
| Point the ICE config at a TURN server | **Already supported** — `web_backend.py` reads `VOIC3_TURN_URL` and `VOIC3_TURN_SECRET`. No code change needed |
| Restic / Rclone for encrypted backups | **Correct** — both free, single `.exe`, reachable |
| Keep the laptop awake | **Correct and important** — the switchboard is this PC |

---

## The claim that is wrong

> "Cloudflare Tunnels only proxy HTTP/TCP traffic — they do not relay WebRTC UDP
> media, so a tunnel alone will solve your SSL/API access over 4G, but two phones on
> carrier NATs will still fail."

**This is true of the tunnel as a transport, but it misses what the tunnel is for in
our design.** The phones do not send media through the server. They connect **directly
to each other** and only use the server to exchange addresses. Once both phones are
reached over HTTPS at a public address, STUN finds a direct path for most pairs — and
for the pairs where it cannot, a TURN relay is needed.

So the plan's conclusion — *"you need TURN"* — is **right**. Its reasoning about *why*
is muddled, but it arrives at the correct answer: **we need both the tunnel/domain and
a TURN relay.** They are not alternatives.

---

## The one change I would make to the plan

The plan says: *"What I would choose: DuckDNS + Caddy."*

**I would not, yet — and here is the concrete reason.** DuckDNS + Caddy needs **ports
80 and 443 forwarded on your office router**. I tested this machine's public address
from outside: **port 80 does not answer** (`YOUR_PUBLIC_IP` — no response). Right now
nothing is forwarded. Making that work needs your router's admin password and an ISP
that does not block port 80/443 — many South African ISPs do block them on consumer
lines.

**So the order should be reversed:**

1. **Cloudflare Quick Tunnel first** — zero router changes, works today, proves the
   whole thing end-to-end in an hour. Its one weakness is a new `*.trycloudflare.com`
   name on each restart.
2. **Only if you want a permanent name**, move to DuckDNS + Caddy — and that step
   needs your router, not me.

That way you are never blocked waiting on an ISP or a router setting.

---

## The corrected blueprint

### Step 1 — Certificate and 4G switchboard access
**Cloudflare Quick Tunnel**, free, no account. `cloudflared.exe` downloads directly
from Cloudflare's release page (verified reachable). Gives a real trusted certificate
and a public HTTPS address within a minute. Nothing on the router changes.
*Upgrade later, if you want a permanent name:* DuckDNS + Caddy on ports 80/443.

### Step 2 — TURN relay for carrier-to-carrier calls
**Pion TURN as a single `.exe`** (the plan's Option B) — I prefer this over WSL2 for
one practical reason: **no router change and no port forwarding**, because it can run
on the same machine and be reached through the tunnel's address. WSL2 coturn works
too, but it needs `49152-49200/udp` forwarded on the router, which we just established
is not open.

Either way, the only change to our code is setting two environment variables:
`VOIC3_TURN_URL` and `VOIC3_TURN_SECRET`. **The endpoint already reads them.**

### Step 3 — Backups
**Restic** to a second disk now, plus the same archive copied to a free cloud account
you already have. Restic encrypts before anything leaves the laptop, which matters
because this database holds patient communications. Nightly at 23:00 via Task
Scheduler.

### Step 4 — Stop the laptop sleeping
Power Options → never sleep when plugged in. Non-negotiable: if it sleeps, VOIC3 is
down for everyone.

---

## Will it work?

| Goal | Will it work? | Confidence |
|---|---|---|
| No certificate warnings on any phone | **Yes** | High — verified the network paths exist |
| The switchboard reachable on 4G | **Yes** | High — that is what the tunnel does |
| Calls between two carrier networks | **Yes, with TURN running** | Medium-high — depends on the relay's UDP port being reachable; we will know in one test |
| Encrypted nightly backup | **Yes** | High — nothing exotic |
| All of it free, no subscriptions, no API keys | **Yes** | High — every component is open source or free-tier |

**The honest risk:** a TURN relay needs **UDP** to reach it. Port-forwarding UDP is
where this can still fail, and it depends on your router and ISP. That is why step 2
is "set it up and test", not "set it up and assume". The test is one real call with one
phone on Wi-Fi and one on 4G — ten minutes, and it settles the question.

---

## What I need from you

- **Permission to download `cloudflared` and `restic`** (both free, both from official
  release pages).
- **Nothing else for steps 1, 3 and 4.** They are mine.
- **For step 2:** one of — either keep the tunnel route (no router work, my
  recommendation), or give me the router admin so we can forward UDP.
- **For the final test:** you, with two phones, one on Wi-Fi and one on mobile data.
