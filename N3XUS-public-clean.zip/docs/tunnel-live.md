# Tunnel is live — the first blocker is gone

Everything below was run on this machine just now.

---

## 1. Downloads — done, both free, no account

| Tool | Version | Where |
|---|---|---|
| **cloudflared** | 2026.11.0 | `desktop/tools/cloudflared.exe` (55 MB) |
| **restic** | 0.19.1 | `desktop/tools/restic.exe` (11 MB) |

Restic's versioned download URL had moved (`0.18.1` now 404s); I read GitHub's release
API and fetched `0.19.1`, which is current.

---

## 2. The tunnel is running and serving the real app

```
https://YOUR_TUNNEL.trycloudflare.com
```

| Test | Result |
|---|---|
| Pre-flight checks | **All PASS** — DNS, UDP/QUIC, TCP/HTTP2, Cloudflare API |
| `GET /mobile/` over the public URL | **200 in 0.72 s** |
| TLS verification | **`verify_result = 0`** — a real, trusted certificate |
| `GET /mobile/mobile.js` | **200, 132 558 bytes** |

**No certificate warning. No account. No router change. Nothing forwarded.**

That is the first two blockers — the padlock and reaching the switchboard from 4G —
solved in about ten minutes.

---

## 3. Two things the tunnel exposed, both now fixed

### A. The QR code pointed at an address phones on mobile data cannot reach
`/api/connect/qr` always returned the LAN address (`https://YOUR_SERVER_IP:64281/mobile`).
A phone on 4G cannot resolve `YOUR_SERVER_IP`, so the code would have been useless the
moment you left the office.

**Fixed:** the route now reads `X-Forwarded-Host` / `X-Forwarded-Proto`. A LAN,
loopback or `.local` host still gets the LAN address; anything public gets the public
address. Verified against seven hostnames:

```
YOUR_SERVER_IP          -> LAN
YOUR_SERVER_IP            -> LAN
127.0.0.1            -> LAN
localhost            -> LAN
nexus.local          -> LAN
reliance-court-...   -> PUBLIC
YOUR_PUBLIC_IP        -> PUBLIC
```

### B. Our QR encoder could not draw a tunnel address at all
It only implemented QR versions 1–3, which top out at **53 bytes**. A trycloudflare
address is **63 bytes**, so the endpoint returned
`503 QR unavailable: payload too long for this encoder`.

**Fixed:** versions 4, 5 and 6 added (80, 108 and 272 data codewords, with their
alignment patterns). Capacity is now 270 bytes.

**Proof it works, not just that it returns 200:** I rendered the served SVG in
Chromium and decoded it with jsQR:

```
decoded: https://YOUR_TUNNEL.trycloudflare.com/mobile
```

Byte-for-byte the address the tunnel is serving.

---

## 4. Tests

```
Ran 187 tests in 19.7s
OK (skipped=1)
```

Nothing broken. Committed as `9483dde`.

---

## 5. What is still open

| Item | State |
|---|---|
| Padlock on every phone | **Done** |
| Switchboard reachable on 4G | **Done** — but see the caveat below |
| QR works from anywhere | **Done and decode-verified** |
| Calls between two carriers | **Not yet** — needs the TURN relay (coturn in WSL2) |
| Encrypted nightly backup | **Not yet** — restic is downloaded and ready |
| Laptop never sleeps | Not done — one Power Options setting |

**The caveat:** a Cloudflare *quick* tunnel gives a **new random name each time it
restarts**. Fine for testing today; for staff rollout you either keep the process
running, or move to a named tunnel / DuckDNS + Caddy later. Nothing else changes.

---

## 6. Next, in order

1. **Nightly encrypted backup with restic** — I can do this now, unattended, no
   router, no account.
2. **TURN relay** — `wsl --install -d Ubuntu`, then coturn with the corrected config
   from `docs/turn-setup.md`. This is the only thing standing between you and
   carrier-to-carrier calls.
3. **The two-phone test** — you, one phone on Wi-Fi, one on 4G.
