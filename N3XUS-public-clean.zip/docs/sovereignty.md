# Sovereignty Statement — this build

**Build:** NEXUS / Beyond Registration 5.1.3
**Statement date:** 16 November 2026
**Commit:** `852e477` + the temp-owner, backup and tunnel work described below
**Machine:** this PC, `YOUR_SERVER_IP`

Sovereignty here means one thing: **this system answers to you and nobody else.**
It runs on your hardware, holds your data, and stops working only if you stop it.
Nothing in it can be switched off, repriced, or read by a third party.

---

## 1. What it costs

| Item | Cost | Recurring |
|---|---|---|
| The application | R0 — written here | none |
| Database | R0 — SQLite, on your disk | none |
| Messaging, calls, meetings | R0 — peer-to-peer | none |
| Encryption | R0 — `cryptography`, Apache-2.0 | none |
| QR codes | R0 — our own encoder | none |
| Public HTTPS address | R0 — Cloudflare quick tunnel, no account | none |
| TURN relay | R0 — coturn, self-hosted | none |
| Backups | R0 — restic, BSD-2 | none |
| **Total** | **R0** | **R0 / month** |

**No API keys. No subscriptions. No paid tier. No trial that expires.**

---

## 2. What it depends on outside this machine

This is the honest list. Everything here is free and none of it can hold your data
to ransom — but you should know it exists.

| Dependency | What it is for | If it disappeared |
|---|---|---|
| **Cloudflare quick tunnel** | a public HTTPS address with a real certificate | falls back to the LAN address; office use unaffected |
| **Google + Cloudflare STUN** | tells a phone its own public address so two phones can connect | calls stop working off-network; messaging unaffected |
| **Your ISP** | the connection itself | nothing works remotely; LAN unaffected |
| **Windows** | the operating system | — |
| **A web browser** | the phone app runs in it | — |

**Not on this list, deliberately:** no cloud database, no hosted backend, no
authentication provider, no push service you must pay, no vendor account of any kind.
There is no company that can revoke a licence, because there is no licence.

---

## 3. Where the data lives

| What | Where | Who can read it |
|---|---|---|
| The database | `%LOCALAPPDATA%\Beyond Registration\Data\your-userd_registration.db` | you — AES-GCM, key held in this Windows profile |
| Uploads and recordings | `Data\voic3_uploads\` | you |
| Backups | `C:\N3XUS_BACKUP\restic-repo` | you — encrypted before it is written, passphrase in `tools\restic.pass` |
| Backups (off-machine, optional) | a drive you choose | you |

**Nothing is sent to a third party for storage.** The tunnel carries traffic; it does
not keep it. The database is encrypted at rest with a key that never leaves this
profile.

---

## 4. What was proved tonight

| Claim | How it was proved |
|---|---|
| The app is reachable from outside with a trusted certificate | `GET /mobile/` → 200 in 0.72 s over the public URL, TLS verify result 0 |
| A phone on mobile data can be given a working address | the QR SVG was decoded in Chromium/jsQR to the exact public URL |
| A temporary owner can sign in and reach every owner screen | `/api/login` 200; employees, patients, academy, voic3 conversations and meetings, contracts, audit all 200 |
| Backups are real and restorable | a snapshot was taken, then the database was restored from it, then **decrypted** — 1 908 736 bytes of valid SQLite |
| Backups run on their own | Windows task **"N3XUS Nightly Backup"**, next run 23:00, status Ready |
| The suite still passes | 187 tests, 1 skipped |

---

## 5. What is still not sovereign

| Gap | Why it matters | Fix |
|---|---|---|
| **TURN relay not running** | calls between two mobile networks will fail | coturn in WSL2 — config ready in `docs/turn-setup.md` |
| **The laptop must stay awake** | the server *is* this PC; sleep = the switchboard is down | Power Options: never sleep when plugged in |
| **Quick tunnel name changes on restart** | a new URL each time the tunnel restarts | a named tunnel, or DuckDNS + Caddy |
| **The temp owner exists** | a shared password is a shared door | delete `OWNER-TEST` when your own owner login is confirmed |
| **Backups are on the same machine** | one disk failure takes the data *and* the backup | copy `C:\N3XUS_BACKUP` to a second disk or drive |
| **No git remote** | 59 commits live on one disk only | push to a repo you control |

None of these are purchases. All of them are settings or one more free component.

---

## 6. The one-line version

> **This build runs on your computer, keeps its data in your encrypted database,
> talks to your people directly, backs itself up every night, and costs R0 a month.
> The only things it needs from the outside world are a free tunnel, two free STUN
> servers and your internet connection — and none of them hold a key to anything.**

---

## 7. Temporary credentials — handle with care

```
Owner console   username: OWNER-TEST
                password: Nexus Owner 2026!erWi
```

This account was created for tonight's test. It is an `Administrator`. **Delete it as
soon as your own owner login is confirmed** — I can remove it in one command.
It is not written anywhere except this file, so do not leave this file in a shared
folder.
