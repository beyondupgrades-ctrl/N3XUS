# Your laptop's RAM — exactly what to buy

## The machine

**HP ProBook 650 G4** — Intel Core i5-8250U

## What is inside it right now

| | |
|---|---|
| Installed | **8 GB in one stick** |
| Slot it is in | `Bottom-Slot 2 (under)` |
| Type | **DDR4 SODIMM** (laptop memory) |
| Speed | **2400 MHz** |
| Part number | Samsung `M471A1K43CB1-CTD` |
| **Empty slots** | **1 — the other slot is free** |

## What it can take

| | |
|---|---|
| Total slots | **2** |
| Maximum RAM | **32 GB** |
| Best simple upgrade | **add one 8 GB DDR4-2400 SODIMM → 16 GB total** |

Confirmed against HP's own QuickSpecs for the ProBook 650 G4: *"32 GB DDR4-2400
SDRAM… Both slots are customer accessible/upgradeable. Supports dual channel memory.
2 SODIMM."* Notebookcheck's review of this exact model confirms one slot ships empty.

---

## What to buy

**One stick of: 8 GB DDR4-2400 SODIMM (260-pin), non-ECC, unbuffered, 1.2 V**

Search for exactly this:

```
8GB DDR4 2400MHz SODIMM 260-pin laptop memory
```

**Match the existing stick if you can** — same speed (2400) and ideally the same
part: **Samsung M471A1K43CB1-CTD**. Mixing brands usually works, but matching is
safer and gives you dual-channel, which is a real speed gain on this CPU.

**Do not buy:**
- DDR3 or DDR5 — will not fit
- "DIMM" (desktop) memory — wrong shape entirely
- 3200 MHz or faster — it will run, but only at 2400, so you would pay for nothing

**Cost:** an 8 GB DDR4-2400 SODIMM is one of the cheapest parts you can buy for a
laptop. It is a one-time purchase, not a subscription.

---

## Fitting it

The ProBook 650 G4 has a **bottom service cover** — you do not take the whole laptop
apart.

1. Shut down, unplug, and remove the battery if it is removable
2. Undo the screws on the bottom cover
3. The empty slot is the one **not** holding the current stick
4. Slide the new stick in at an angle, then press it flat until the clips click
5. Refit the cover, power on, and check: **Task Manager → Performance → Memory** should
   read **16.0 GB**

If you would rather not open it, any PC shop will fit it in minutes — the part is the
expensive bit, not the labour.

---

## One honest note

**You do not need this for N3XUS.** The app uses 16 MB. You need it because the rest of
the machine — browsers, VLC, antivirus — is fighting over 8 GB, and that is what makes
the laptop feel slow and makes the Android emulator impossible.

Buy it for the laptop's comfort, not for N3XUS. N3XUS already runs.
