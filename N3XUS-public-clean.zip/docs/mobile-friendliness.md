# N3XUS phone app — user-friendliness review

Reviewed on a real phone-sized browser (412 × 900) against the live app, signed in
as a staff account, walking every tab.

## What was wrong, and what changed

| # | Problem found | What it did to the user | Fixed |
|---|---|---|---|
| 1 | The **Update** button downloaded an old APK (v5.2.6 from a different build folder) | Tapping Update installed an older app, so the update bar never went away | Yes — the server now serves the APK it actually ships (`tools/N3XUS.apk`) and reads its real version |
| 2 | The **SOS** button was a floating red circle pinned 86 px above the bar | It sat on top of the right-hand tabs and hid them | Yes — SOS is now the last item **inside** the tab bar, red, nothing overlaps |
| 3 | The staff home printed a literal **`/section>`** on the screen | Looked broken and unprofessional | Yes — a broken tag in the template |
| 4 | **Settings** said "managed by your employer" and offered no way to change a password | A user who forgot or wanted to change their password had to phone the office | Yes — **Change my password** button, with current-password check and a 10-character minimum |
| 5 | The tab bar holds up to 10 tabs | On a narrow phone the last tabs were cut off | Already handled — the bar scrolls sideways; verified SOS is reachable by scrolling |

## What was already good (left alone)

- Every empty state tells the user what to do next ("No patient is assigned to your
  account. Ask an administrator to assign patient access.").
- Tabs the account is not allowed to use are collapsed to zero width, not shown greyed out.
- The theme choice is remembered on the device.
- Sign out is on the Settings screen with a warning about shared phones.
- Calls use an in-page colleague picker, so nothing depends on a browser popup.

## Still open (needs the owner, not code)

- The two-phone call test: Phone A on Wi-Fi, Phone B on mobile data. This is the one
  thing that proves the relay works from outside the building.
- The browser shows a "Privacy error" on `https://127.0.0.1:64281/` because the
  certificate is self-signed. It is safe to click through on your own laptop.
