# TURN setup — reviewed, with the traps fixed

The blueprint is **good and mostly correct**. I verified it against this machine and
found **two traps that would have cost you a day**, plus **one code change it missed**
(which I have now made). Below is the corrected version.

---

## What the blueprint gets right

| Claim | Verdict |
|---|---|
| Run UDP and TCP on the same listener | **Correct and important** — this is the single best resilience move in the plan |
| ICE falls back to TURN over TCP when UDP is blocked | **Correct** |
| Check for CGNAT before blaming the router | **Correct** — and I already checked: your public IP `YOUR_PUBLIC_IP` is **not CGNAT**, so port forwarding can work here |
| `chrome://webrtc-internals` shows the winning candidate pair | **Correct** — `host`/`srflx` = direct, `relay` = TURN carried it |
| Trickle ICE page to verify before calling | **Correct** — fastest possible confirmation |
| `networkingMode=mirrored` for WSL2 | **Correct and the right choice** — it makes WSL2 share `YOUR_SERVER_IP`, so no `netsh` proxy rules |
| Narrow relay range (100 ports) | **Good call** — far less to forward |

---

## Trap 1 — the config blocks your own phones

The blueprint's `turnserver.conf` contains:

```
denied-peer-ip=YOUR_LAN_IP-YOUR_LAN_IP
denied-peer-ip=10.0.0.0-10.255.255.255
```

Your phones are on **YOUR_LAN_SUBNET.x**. These lines tell the relay it may not connect to
them. A Wi-Fi phone relaying through this TURN server would be **refused**, and you
would spend hours blaming the router.

**Fix:** remove those three `denied-peer-ip` lines for the office network. Keep
`no-loopback-peers` and `no-multicast-peers`, which are safe and useful.

---

## Trap 2 — a typo that would break the ICE list

The blueprint's Python snippet has:

```python
"iceServers": [
    {"urls": "stun:://google.com"},          # <- malformed
```

`stun:://` is not a valid URI. A browser rejects the **whole** `iceServers` array if
one entry is malformed, which would silently take out STUN *and* TURN.

**Fix:** we already use `stun:stun.l.google.com:19302` and
`stun:stun.cloudflare.com:3478`. Leave those alone.

---

## The thing it missed — now fixed

The blueprint wires the TURN URLs into `/api/voic3/rtc/capabilities`. Our server
builds the ICE list in **`/api/voic3/ice-config`**, and that is the endpoint the phone
actually calls — so the blueprint's change would have gone to the wrong place and the
phone would never have received the relay.

More importantly, our code took **one** TURN URL and could not hand out UDP and TCP
together. **That is now fixed** (`3a54bd3`):

- `VOIC3_TURN_URL` accepts a **comma-separated list** and hands both out as one relay,
  so ICE can fall back exactly as the blueprint describes.
- New `VOIC3_TURN_USER` / `VOIC3_TURN_PASS` support the blueprint's
  `lt-cred-mech` style of fixed username and password.
- Verified output:
  ```json
  {"urls": ["turn:v.example.org:3478?transport=udp",
            "turn:v.example.org:3478?transport=tcp"],
   "username": "voic3user", "credential": "***"}
  ```

**So the code side is done. Only the relay and the forwarding remain.**

---

## Corrected `turnserver.conf`

Changes from the blueprint are marked.

```ini
listening-port=3478
listening-ip=0.0.0.0
# The address phones outside your office will reach. Use the raw public IPv4
# for the first test; a DuckDNS name works on Ubuntu 22.04/24.04 coturn.
external-ip=CHANGE_ME_PUBLIC_IP

min-port=49152
max-port=49252

lt-cred-mech
fingerprint
user=voic3user:CHANGE_ME_STRONG_PASSWORD
realm=voic3.local

# --- Security ---
no-loopback-peers
no-multicast-peers
# FIX: the blueprint denies YOUR_LAN_IP/16 and 10.0.0.0/8, which is where your
# own phones live. Leave them out or the office cannot relay.
denied-peer-ip=127.0.0.0-127.255.255.255
denied-peer-ip=169.254.0.0-169.254.255.255

log-file=/var/log/turnserver.log
simple-log
no-cli
```

---

## The exact steps, corrected

1. **WSL2 + coturn**
   `wsl --install -d Ubuntu`, then `sudo apt update && sudo apt install coturn`.
2. **Mirrored networking**
   `C:\Users\<you>\.wslconfig` → `[wsl2]` / `networkingMode=mirrored`, then
   `wsl --shutdown` and reopen Ubuntu.
3. **Config** — use the file above, not the original.
4. **Enable and start** — `TURNSERVER_ENABLED=1`, `sudo service coturn restart`,
   then `sudo ss -tulnp | grep turnserver` and confirm **both** `udp` and `tcp` on 3478.
5. **Windows Firewall** — allow inbound UDP+TCP 3478 and UDP 49152–49252.
6. **Router** — forward 3478 TCP+UDP and 49152–49252 UDP to `YOUR_SERVER_IP`.
7. **Point VOIC3 at it** — three environment variables:
   ```
   VOIC3_TURN_URL=turn:CHANGE_ME:3478?transport=udp,turn:CHANGE_ME:3478?transport=tcp
   VOIC3_TURN_USER=voic3user
   VOIC3_TURN_PASS=CHANGE_ME_STRONG_PASSWORD
   ```
8. **Verify before calling** — Trickle ICE page, enter the relay and credentials,
   press *Gather candidates*. You need a line reading **`relay`**. If it appears, the
   router, firewall and coturn are all correct and the test call will work.
9. **Then the real test** — Phone A on Wi-Fi, Phone B on 4G, and read
   `chrome://webrtc-internals` to see whether `srflx` or `relay` won.

---

## Will this work?

**The setup will work, with two conditions I cannot check until it is running:**

1. **The ISP must allow inbound UDP on 3478 and 49152–49252.** Your address is not
   CGNAT, which is the main obstacle cleared. If inbound UDP is blocked, the TCP
   fallback in step 7 covers most cases — that is exactly why it is worth keeping.
2. **The router must be yours to configure.** Nothing is forwarded today (port 80 on
   your public IP does not answer), so step 6 needs the router admin login.

**Effort:** about 1–2 hours, most of it the WSL2 install and the router.
**Cost:** R0. No account, no API key, no subscription.
