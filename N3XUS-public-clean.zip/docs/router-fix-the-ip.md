# STOP — two fields on that screen are wrong

Your screenshot shows the **Add New Service** form. The name, the type, the protocol
and both ports are correct. **Two things will send the calls to the wrong machine.**

---

## What is wrong

| Field | On your screen | Must be |
|---|---|---|
| **Device name** | `deco-S7` | **This laptop** — pick the entry that is *not* deco-S7 |
| **Host IP address** | `YOUR_LAN_IP` | **`YOUR_SERVER_IP`** |

### Why this matters

I checked the network. `YOUR_LAN_IP` is **not this laptop**:

```
YOUR_LAN_IP   MAC 20:e1:5d:d8:c9:e8   → TP-Link Systems Inc.   (a Deco mesh unit)
YOUR_SERVER_IP     this laptop, Wi-Fi adapter, answers in <1 ms
```

So the rule as it stands would forward your calls to a **TP-Link Deco mesh node**,
which knows nothing about N3XUS. Calls would fail, and it would look like the relay
was broken when it was the rule.

**The laptop is `YOUR_SERVER_IP`.** That is the only address that should be in that box.

---

## What to do

1. **Device name** — open the dropdown and choose this laptop. It may appear as
   `your-user`, `DESKTOP-…`, or the PC's name. If the laptop is not listed, leave the
   device name as it is and just fix the IP — the IP is what actually matters.
2. **Host IP address** — clear it and type **`YOUR_SERVER_IP`**
3. **Protocol** — `TCP/UDP` is fine. UDP is what we need and it is included.
4. **Internal port** `3478`, **External port** `3478` — already correct.
5. **Save / Apply.**

---

## Then tell me

Say "done" and I will test port 3478 from outside this network. If it answers, we go
straight to the two-phone call test.

---

## One thing worth knowing about your setup

You have a **TP-Link Deco mesh** behind the ZTE router. That is fine, but it means
there are two layers of network. If the forwarding rule still does not work after
fixing the IP, the Deco is the next suspect — and the fix is to put the Deco in
**Access Point mode**, or to forward the port on the Deco as well. Do not change that
yet; test first.
