# You are signed in — where to click next

Your screenshot shows the **ZTE Home page**: *Connect to Internet · My Wi-Fi ·
Manage Device · **More Functions***, with the router's live stats. You are in. Nothing
is broken.

I probed this router's admin paths directly to confirm which one exists — and the
answer is that your router's menu lives under **More Functions**. There is no
`/html/network.html` or `/html/security.html` on it; the forwarding screen is reached
through that tab.

---

## What to do, in order

### Step 1 — Tap **More Functions** (the ☰ icon, far right)

That opens a sub-menu. Port forwarding on this ZTE family is under one of:

- **Application** → **Port Forwarding**
- **Advanced** → **NAT** → **Virtual Server**
- **Security** → **Port Forwarding**
- **Network** → **NAT** → **Port Mapping**

### Step 2 — Add the rule

| Field | What to type |
|---|---|
| Name | `N3XUS TURN` |
| Protocol | **UDP** |
| WAN / External port | `3478` |
| LAN / Internal port | `3478` |
| Internal / Local IP | **`YOUR_SERVER_IP`** |
| Enable | **On** |

### Step 3 — Save, then Apply

ZTE usually needs **both**. If there is an "Apply" or "OK" button after Save, press it.
The rule is not live until it appears in the list.

---

## While you are in **Manage Device**

This is where the other two useful things live:

1. **DHCP → Address Reservation** — pin `YOUR_SERVER_IP` to this laptop, so the rule never
   points at the wrong machine.
2. **Firewall / Security level** — if you find a setting like "Firewall: High", note
   it. If the forwarding rule does not work after saving, this is the first suspect.

---

## If you cannot find a forwarding screen at all

Take a screenshot of the **More Functions** menu and send it — I will read it and tell
you the exact next click. Your router's menus are rendered by JavaScript, so I cannot
crawl them from here; a picture is the fastest way.

And if it genuinely has no forwarding screen, say so: I will switch the relay to
**TCP mode** and we try the other route. Still R0.

---

## Do not change anything else

You do **not** need to touch: My Wi-Fi, Connect to Internet, the Wi-Fi password, the
network name, or the 2.4G/5G settings. One port, one rule, nothing else.
