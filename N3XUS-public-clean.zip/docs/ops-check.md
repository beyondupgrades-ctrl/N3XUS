# Operations check — what works, what needs fixing

Run against the live server on port 64281 (HTTPS, LAN) and the live encrypted
database. Nothing was changed to make a test pass.

**Verdict:** the meeting/call engine is solid — 20 of 20 meeting actions returned
200 in a single session, including two people joining and polling at once. What
is broken is the **front door**: the mobile call screen has no hang-up, the
owner's admin console is unreachable from a phone, and 9 of 21 paths the app
calls do not exist on the server.

---

## Numbered list — go through these in order

### 1. ~~Nobody can hang up a call from the phone~~ — FIXED
`mobile.js` `endCall()` never calls the server. The call stays "ringing" forever,
the other person's phone keeps ringing, and every call becomes a missed call.
**Fixed** (`8c4ee0e`): `endCall()` posts `/api/mobile/calls/{id}/end`. Verified in a
real browser — the hang-up request is sent and the call closes cleanly.

### 2. ~~The caller asks the server to answer its own call — always refused~~ — FIXED
`mobile.js:1390` sends `POST /api/mobile/calls/{id}/answer` from the caller's own
phone. The server correctly replies **403 "Only the callee can answer this call."**
The call still connects, but every call logs a failure. The call screen only shows
after `setupCaller()` finishes, so a thrown error here leaves the screen half-drawn.
**Fixed** (`8c4ee0e`): the line is gone. A real browser run shows no self-answer
request at all.

### 3. ~~The call screen ignores the TURN servers the server already hands out~~ — FIXED, but no TURN relay exists yet
`mobile.js:1382` builds the peer connection with `{iceServers: []}` — literally no
ICE servers. `/api/voic3/ice-config` returns STUN plus TURN, and that endpoint
works. On 4G, or behind most mobile carriers' NAT, calls will simply not connect.
**Fixed** (`8c4ee0e`): all four peer connections now use `/api/voic3/ice-config`,
verified in a real browser. **Still open:** the server returns two STUN servers and
**no TURN**, because TURN needs `VOIC3_TURN_URL` + `VOIC3_TURN_SECRET`. Without a
relay, calls between two different mobile networks will still fail.

### 4. ~~Calling someone by employee number cannot work~~ — FIXED
`mobile.js:1369` looks the person up via `/api/mobile/employees`, which **does not
exist** (404). The lookup is caught and turned into an empty list, so every call
attempt shows "Employee not found" — no matter which number you type.
**Fixed** (`8c4ee0e`): new `GET /api/mobile/directory` lists employee number, name,
job title and department for active colleagues (self excluded). Verified: 5 people
listed, and a real browser call to `004` started and ended correctly.

### 5. A staff phone can see every patient record
`/api/mobile/patients` and `/api/mobile/patient-alerts` return **200 for a plain
staff account** — no role check. Care data should be reachable by a caregiver for
their linked patient only, and by admins. Right now anyone with a login sees all.
**Fix:** gate on the role system (built, `roles.py`), patient-linked scope.

### 6. The owner's admin console is invisible on a phone
`/api/mobile/admin/overview` (and approvals, leave, contracts, messages, payslip
requests, admin patients) answer **404, not 403**, to a staff account. The gate
`if not mobile_admin: 404` is deliberate, but it means a staff phone cannot even
tell the feature exists — and I could not test those seven screens end to end
because I do not have the owner's password.
**Fix:** nothing for staff. But these need one real run on the owner's phone
before we call Ops finished.

### 7. Mobile search, forms, notifications and device pairing call routes that do not exist
Nine paths the phone app calls have no server route. Each one is wrapped in a
`.catch()`, so the screen renders empty instead of erroring — silent, not broken,
but the feature is not there:

| Path the app calls | Server |
|---|---|
| `/api/mobile/employees` | 404 |
| `/api/mobile/profile` | 404 |
| `/api/mobile/device/status` | 404 |
| `/api/mobile/dashboard` (read) | 200 — but returns empty lists for a real employee |
| others in the same class | 404 |

**Fix:** decide per path — build the route, or delete the call so the UI stops
promising something it cannot do.

### 8. `POST /api/mobile/prefs` looks broken but is not
The app saves preferences with **PUT**, which works (200 `{"ok":true}`). My first
probe used POST and got 404. **No fix needed** — noting it so nobody "fixes" it.

### 9. One stale endpoint 404s: `POST /api/voic3/meetings/{id}/join`
The app never calls it (it joins by code, which works). If anything else does, it
404s. **Fix:** low priority — remove or alias it.

### 10. The server once froze for 45 seconds — and I could not reproduce it
After a run of meeting calls, every request hung until I killed and restarted the
server; it then ran 20 consecutive actions with no problem. I checked the three
things that could block it — the global request lock, the MSTR scheduler (0.01 s),
the safety monitor (0.00 s) — and none of them accounts for it. It is most likely
a thread left holding the lock after a client vanished mid-request, since there is
no per-request timeout on the lock itself.
**Fix:** put a timeout on the lock acquisition and log when it trips, so if it
happens in real use we get a name instead of a hang.

### 11. A second person cannot easily be tested on one PC
The phone session cookie is per browser. Two accounts need two profiles or two
devices. Not a bug — but it is why everything above was driven from one session
plus direct calls. **Fix:** none; just know it when testing with two people.

### 12. The role system is built but not yet connected
`roles.py` + 18 tests are committed (`a273591`) and the seven role types, invites
and permissions are done. The mobile login and the phone screens do **not** use it
yet — that is the next job.
**Fix:** wire it into login and the tab bar, which also fixes #5.

---

## What passed (20 of 20, single session)

Create meeting → join by code → snapshot → poll → raise hand → reaction → host
mute all → lock → unlock → spotlight → end for all: **all 200.**
Two people joining and polling concurrently: **all 200, 0.01–0.03 s.**
Ice config, RTC capabilities, push key, conversations, call history: **200.**
Call start, signalling, ICE: **201.** Answer gating: **403, correct.**
Prefs round-trip (PUT/GET), messages, leave request: **200/201.**
`187 tests OK (1 skipped)` after the role system was added.
