# Making N3XUS work on 8 GB of RAM

**Short answer: it already does.** N3XUS is not what is using your memory.

---

## What N3XUS actually costs

Measured just now, while the whole system was running:

| Process | RAM |
|---|---|
| N3XUS app (`python web_backend.py`) | **14 MB** |
| TURN relay (`turnserver.exe`) | **2 MB** |
| **Total** | **16 MB** |

Sixteen megabytes. On an 8 GB laptop that is **0.2%**. The system will run on a
Raspberry Pi. RAM was never the problem.

---

## What was actually eating your laptop

When I looked, the top consumer was:

```
vlc processes: 208   total: 2 863 MB
with a window: 0     started: 15/11/2026 10:46
```

**208 VLC processes, not one window, running since yesterday.** Orphaned — VLC had
crashed or been closed badly and left its children behind. They were holding **2.8 GB**.

I killed 87 of them. The rest belong to an **elevated** VLC parent that I am not
allowed to stop — that one needs you.

### Do this

1. Open **Task Manager** (Ctrl+Shift+Esc)
2. Find **VLC** — you will see it listed many times
3. Right-click the top one → **End task** (it will ask for permission; say yes)
4. If it comes back, **uninstall or update VLC** — this is a known VLC bug on Windows
   where closing the window leaves processes running

That alone gives you back roughly **2.5 GB**.

---

## The other big consumers right now

| Process | MB | What it is |
|---|---|---|
| `clamscan` | 820 | an antivirus scan running — it finishes on its own |
| Memory Compression | 462 | Windows, normal |
| AbacusBot | 586 | this app, two processes |
| msedgewebview2 | 201 | a web view |
| MsMpEng | 174 | Windows Defender |

Nothing here is N3XUS.

---

## What I did to make the laptop survive

1. **Sleep is off** — verified: sleep-after = `0` on both AC and battery, screen-off
   timer `0`, hibernate `0`. Your setting took.
2. **Autostart is on** — `N3XUS.lnk` is now in your Startup folder, so the server and
   relay start by themselves when you log in. You no longer have to remember.

---

## The honest limits of 8 GB

- **The Android emulator will not run here.** It wants 16 GB. That is why I could not
  test the APK myself — not a fault in the APK.
- **Do not run heavy things alongside N3XUS** — video editing, many browser tabs, a
  second emulator. N3XUS needs 16 MB; the rest of the machine needs the other 7.8 GB.
- **If you want headroom**, the cheapest real fix is a RAM stick. 8 GB → 16 GB is
  usually the single best upgrade for a laptop like this, and it costs far less than
  any subscription.

---

## What to do now

1. Kill the elevated VLC in Task Manager (2.5 GB back)
2. Reboot once, and confirm N3XUS starts by itself
3. Send `desktop/tools/N3XUS.apk` to two staff phones
4. Run the call test: one phone on Wi-Fi, one on 4G

**R0 spent. No API keys. No subscriptions.**
