# Forward UDP 3478 on your router — step by step

Your router is at **`YOUR_LAN_IP`**. I identified it from its login page: it is a
**ZTE** router (the "fake for iphone internet detect" page and the
`/html/index.html#/login` admin path are ZTE's own). It answers on both
`http://YOUR_LAN_IP` and `https://YOUR_LAN_IP`.

I cannot log in for you — I do not have the admin password, and I should not.

---

## Before you start, you need three numbers

| What | Value |
|---|---|
| Router admin address | **`YOUR_LAN_IP`** |
| The PC that runs N3XUS | **`YOUR_SERVER_IP`** ← this is the "Internal / Local IP" |
| The port to open | **3478** |

If you do not know the admin password, it is usually printed on a sticker on the
bottom or back of the router, next to "Username / Password" (often `admin` / `admin`,
or a long password unique to that router).

---

## The steps

1. On the laptop, open a browser and go to **`http://YOUR_LAN_IP`**
2. Sign in with the admin username and password from the sticker.
3. Look for one of these menus — ZTE routers name it slightly differently:
   - **Application** → **Port Forwarding**
   - **Internet** → **Security** → **Port Forwarding**
   - **Advanced** → **NAT** → **Virtual Server** / **Port Mapping**
   - **Network** → **NAT** → **Port Forwarding**
4. Add a new rule:

   | Field | What to type |
   |---|---|
   | Name / Comment | `N3XUS TURN` |
   | Protocol | **UDP** (not TCP, not "both") |
   | External / WAN port | `3478` |
   | Internal / LAN port | `3478` |
   | Internal / Local IP address | `YOUR_SERVER_IP` |
   | Enable / Status | **On** |

5. **Save** and then **Apply** (ZTE usually needs both — Save alone does not commit).
6. Reboot the router if it offers that, otherwise it takes effect immediately.

---

## How you will know it worked

Come back and tell me, and I will test it from outside. Or test it yourself:

On a phone with **Wi-Fi turned off**, go to this page:

```
https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/
```

- Remove any server in the list
- **Server:** `turn:YOUR_PUBLIC_IP:3478`
- **Username / Password:** ask me — I will print a valid pair that expires in
  12 hours (there is deliberately no permanent password)
- Press **Gather candidates**

If a line appears saying **`relay`**, the forwarding works and carrier-to-carrier
calls will connect.

---

## If your router has no port-forwarding screen, or the ISP blocks UDP

Some fibre and mobile ISPs block inbound UDP on consumer lines. Tell me and I will
switch the relay to **TCP mode** — it is one flag on the relay and a minute of work.
TCP through a forwarded port works on almost every router, and for voice and video
between two people the difference is not noticeable.

If the router screen has no forwarding at all, the remaining free options are a
**named Cloudflare tunnel** (needs a free Cloudflare account) or **DuckDNS + Caddy**
(needs ports 80 and 443 forwarded instead). Both are R0.

---

## Optional but worth doing while you are in there

**Reserve the PC's address.** If the router hands out `YOUR_SERVER_IP` to something else
one day, the forwarding rule points at the wrong machine and calls stop working.

Look for **DHCP** → **Address Reservation** (or **Static Lease**) and reserve
`YOUR_SERVER_IP` for this laptop. Two minutes, and it prevents a very confusing failure
later.
