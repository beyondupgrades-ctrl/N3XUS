# Your whole house runs on Deco — here is what that changes

Good news first: **it changes almost nothing about tonight.** The forwarding rule you
were filling in is on the **ZTE**, and the ZTE is still the router that owns your
internet connection. I confirmed that from this laptop:

```
default route:  0.0.0.0/0  →  YOUR_LAN_IP   (the ZTE)
laptop:         YOUR_SERVER_IP
Deco node:      YOUR_LAN_IP
```

Everything — the ZTE, the Deco, and this laptop — is on **one flat network,
`YOUR_LAN_SUBNET.x`**. The Deco is not creating a second network. That is the good case.

---

## So the rule is still right, with one correction

| Field | Value |
|---|---|
| Service name | `N3XUS TURN` |
| Service type | Port Forwarding |
| Protocol | `TCP/UDP` |
| Internal port | `3478` |
| External port | `3478` |
| **Host IP address** | **`YOUR_SERVER_IP`** ← not `.219` |

The dropdown offering `deco-S7` is just the ZTE listing the devices it can see. The
Deco is one of them. **This laptop is another.** Pick the laptop, or simply type
`YOUR_SERVER_IP` into the Host IP box.

---

## Why the Deco does not need its own rule

A Deco in **Access Point mode** (which yours is, since everything shares `YOUR_LAN_SUBNET.x`)
is a *bridge* — it passes traffic through without routing it. Port forwarding is a
router job, and the router here is the ZTE. One rule, on the ZTE, is enough.

If it turns out your Deco is in **Router mode** instead, then there would be two
routers and the rule would need to exist on both. We will know within a minute of
testing — and the fix is one setting in the Deco app (*Operation Mode → Access Point*).

---

## What I could not do, and why

You said the TP-Link ID is open on your phone. **I cannot see your phone.** I have no
access to it, and the Deco's admin interface is drawn entirely by JavaScript behind a
login — I probed it directly and every API path returns 404 until authenticated.

So: **you are my eyes on the Deco.** If we need to look at it, send me a screenshot,
exactly as you did with the ZTE — that worked perfectly.

---

## Do this now

1. On the ZTE screen you already have open: set **Host IP address** to `YOUR_SERVER_IP`
2. **Save / Apply**
3. Tell me "done"

I will then test port 3478 from outside your network. If it answers, we go straight to
the two-phone call. If it does not, the Deco's mode is the next thing to check — and I
will tell you exactly which screen to screenshot.
