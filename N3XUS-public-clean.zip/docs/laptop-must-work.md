# N3XUS on your laptop — what is running, and how to keep it that way

You said you need this system to work on your laptop. Here is the honest state, and
the one thing that keeps breaking it.

---

## What is running right now

| Piece | Port | What it does |
|---|---|---|
| N3XUS app | `64281` | the whole system — login, patients, academy, VOIC3 |
| TURN relay | `3478/udp` | lets two phones on different networks hear each other |
| Cloudflare tunnel | — | lets a phone on 4G reach your laptop |

All three are up. I checked each one just now.

---

## The real problem: nothing restarts them

Every time this laptop reboots, sleeps, or the terminal closes, **all three stop** and
the system looks broken. That is what has been happening. It is not a bug in N3XUS —
it is that nothing is keeping it alive.

### The fix, in order of importance

**1. Stop the laptop sleeping** — *you must do this, it needs admin*
`Settings → System → Power → Screen and sleep → When plugged in, never sleep`

This is the single biggest cause. A sleeping laptop is a dead server.

**2. Start everything with one icon**
There is now **N3XUS** on your Desktop and in the Start menu. Double-click it and it
starts the relay and the app together. The console window that appears **is** the
server — minimise it, do not close it.

**3. Make it start by itself at login** — *I can do this, say the word*
I can register a Windows startup entry so the N3XUS icon runs automatically when you
log in. Then you never have to think about it.

---

## The APK

**`desktop/tools/N3XUS.apk`** — 41 KB, signed, built here from the Android SDK already
on this machine. No Gradle, no Android Studio project, no account.

It is a thin shell around the existing mobile app:
- Real **N3XUS** icon on the home screen
- Full screen, no address bar
- Camera and microphone permission granted, so VOIC3 calls work
- Opens the tunnel URL, and falls back to the LAN address if the tunnel is down

**To send it to staff:** WhatsApp, email, or any file share — it is a normal `.apk`.
On the phone, tap it and allow "install unknown apps" for whichever app you sent it
with. That warning is normal for any app not from the Play Store.

---

## What I have not proven yet

I have **not** yet seen the APK run on a phone. I am installing it on the Android
emulator on this laptop to prove it launches and loads the app. Until that finishes,
treat the APK as built-and-signed but not yet run.

I will tell you the moment it launches.

---

## What still needs you

| Thing | Why |
|---|---|
| Never-sleep setting | needs admin |
| Router rule | done — you did it |
| Send the APK to staff | only you can |
| Two-phone call test | only you can |

**R0 spent. No API keys. No subscriptions.**
