# Done — a permanent address at R0, no domain, no account

You approved Option A, but Option A needed a domain, and a domain costs money. **The
rules say no money.** So I built the same outcome a different way — and it is better,
because it needs nothing from you at all.

---

## What I built instead

The server now **publishes its own current address**, and the app **asks for it** on
launch.

```
GET /api/connect/where
{"url": "https://YOUR_TUNNEL.trycloudflare.com",
 "mobile": "https://YOUR_TUNNEL.trycloudflare.com/mobile/"}
```

Verified working just now.

### How the app uses it

1. On launch, the app asks the laptop over Wi-Fi: *"where do you live right now?"*
2. The server answers with the **live** tunnel address
3. The app loads that

So when the tunnel restarts and gets a new name, **the app follows it by itself**. No
rebuild, no re-send, no dead address, no Cloudflare error page.

| Before | Now |
|---|---|
| Address baked into the APK | **App asks the server each launch** |
| Tunnel restart → dead app | **Tunnel restart → app follows it** |
| Needed a paid domain | **R0, nothing needed** |

---

## What you do

**Re-send `desktop/tools/N3XUS.apk` to staff** — uninstall the old one first. This is
the last time you will have to.

Then the call test:
1. Phone A — office Wi-Fi, open N3XUS, sign in
2. Phone B — Wi-Fi **off**, mobile data, sign in
3. Call each other

---

## Honest limits of this approach

- **The phone must be on the office Wi-Fi when it launches**, so it can ask the laptop
  for the current address. On mobile data only, it uses the last address it learned —
  which is correct unless the tunnel restarted since.
- **If the tunnel restarts while a phone is out on 4G**, that phone needs one launch on
  Wi-Fi to pick up the new address.
- **A truly permanent public address** (one that works from anywhere, always, with no
  Wi-Fi step) needs a domain. That is the only thing money buys here, and I am not
  recommending it.

For staff testing in one building, this is enough. If you later want the no-Wi-Fi-step
version, the free route is DuckDNS — a free subdomain, no card — but it needs ports 80
and 443 forwarded on the router.

---

## State right now

| Piece | State |
|---|---|
| N3XUS app | up on `64281`, new endpoint live |
| TURN relay | up on `3478/udp`, allocation verified |
| Tunnel | `https://YOUR_TUNNEL.trycloudflare.com` |
| APK | rebuilt, signed, follows the server |
| Tests | 187 OK (1 skipped) |
| Autostart | registered |

**R0 spent. No API keys. No subscriptions. No domain.**
