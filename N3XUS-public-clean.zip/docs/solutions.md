# Solutions to every open gap — all free, no accounts, no subscriptions

Each gap below has a chosen solution, what it costs (**always R0**), what it needs
from you, and how we will know it worked.

---

## Gap 1 — Calls fail between two different mobile networks

**Cause:** no TURN relay. STUN (which we have) only works when both phones can reach
each other directly. Two phones on different carriers usually cannot.

**What I checked today:**
- No free Windows build of coturn exists (`winget` and `chocolatey` both return nothing;
  the official release is Docker-only and Docker is not installed).
- The free public relay `staticauth.openrelay.metered.ca` is **dead** — ports 3478,
  443 and 80 all time out.
- **Your outbound UDP is fine** — both Google and Cloudflare STUN servers replied to a
  real binding request. So the network is not the problem.

**Solution — in order of preference:**

| Option | Cost | Needs | Works when |
|---|---|---|---|
| **A. Cloudflare Tunnel (free "quick tunnel")** | R0 | one 30 MB download, no account | laptop on, any network — both phones get a *public HTTPS* address, so media flows over one path and there is no NAT to cross |
| **B. Self-hosted coturn, built from source** | R0 | MSYS2 + ~1 hour build | laptop on, router allows the ports |
| **C. Do nothing, accept Wi-Fi only** | R0 | nothing | same Wi-Fi only |

**Recommendation: A.** It solves the TURN problem *and* the certificate problem
*and* the "works on 4G" problem in one move. `cloudflared` downloads straight from
Cloudflare's GitHub release with no sign-up.

---

## Gap 2 — Every phone shows a scary certificate warning

**Cause:** the certificate is self-signed, because the server has to mint its own.

**Solution — two together:**

| Step | Cost | What it does |
|---|---|---|
| **A. Cloudflare Tunnel** (same as Gap 1) | R0 | gives a **real, publicly trusted** certificate on a `*.trycloudflare.com` name — no warning at all, on any phone, nothing to install |
| **B. `mkcert` for the Wi-Fi address** | R0 | makes a private CA and a certificate that is trusted on *your* phones. `mkcert` 1.4.4 is available through Chocolatey and needs no account |

**Recommendation: A for anything off-site, B for the office.** A tunnel name changes
if you restart the tunnel, so for the office the fixed LAN address with mkcert is
steadier. Both are free; neither needs a subscription.

---

## Gap 3 — Nothing is backed up off this computer

**Cause:** there is no backup job. One disk failure and everything is gone.

**Solution:** a scheduled copy of `Beyond Registration\Data`, encrypted as it already
is, to a **second disk or USB drive**, keeping the last 30 days. A script on a
Windows scheduled task. Free, no cloud, no account.

**If you want it off-site too:** the same archive copied to a free cloud drive you
already have — still R0, still no new account.

**How we will know it worked:** I restore one file from the backup and open it.

---

## Gap 4 — The test account is still live

**Solution:** deactivate `TST-9001` in one command. It keeps its history; it just
cannot sign in. I will do it the moment you say so.

---

## Gap 5 — The owner's seven admin screens are untested

**Cause:** I do not have the owner password, and I should not.

**Solution:** you sign in once on your phone while I watch the requests. Ten
minutes. If a screen fails I fix it on the spot.

**Interim:** the gate itself is proven — staff gets 404, admin gets 200.

---

## Gap 6 — A freeze could still happen, but no longer silently

**Already solved** (`6761cc7`): a bounded lock wait, then a 503 and a log line naming
the request that held it. 20 parallel requests all answered in under 0.24 s.

---

## Order I would do them in

1. **Backup** — cheapest, protects everything else, no risk.
2. **Cloudflare Tunnel** — kills gaps 1 and 2 together.
3. **mkcert on the office Wi-Fi** — no more warnings indoors.
4. **Deactivate `TST-9001`.**
5. **Your owner sign-in** — last, because it needs you.

Steps 1–4 are mine to do and touch nothing that already works. Nothing in this list
costs money, needs an API key, or requires a subscription.
