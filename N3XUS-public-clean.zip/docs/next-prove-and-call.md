# Rule saved — now prove it, then make the call

Everything is still running: relay on **3478/udp**, app on **64281**, tunnel up.

---

## Step 1 — Prove the port is open (2 minutes, on a phone)

**Turn Wi-Fi OFF on your phone** (mobile data only — this is the whole point).

Open this page:

```
https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/
```

1. Delete any server already in the list
2. **Server:** `turn:YOUR_PUBLIC_IP:3478`
3. **Username:** `1794900551`
4. **Password:** `8WGSnTc7MXIkXzQ1mwd2oThMcis=`
5. Press **Gather candidates**
6. Wait ~10 seconds

**What you are looking for:** a line that says **`relay`** with an address like
`136.18.x.x`.

| Result | Meaning |
|---|---|
| `relay` appears | **The port is open. Carrier-to-carrier calls will work.** |
| Only `srflx` / `host`, no `relay` | The rule is not reaching the relay — tell me and I will check the Deco |
| Nothing at all | Same as above |

*These credentials expire in 12 hours. That is deliberate — there is no permanent
password to leak.*

---

## Step 2 — The real call test

1. **Phone A:** join your office Wi-Fi → `https://YOUR_TUNNEL.trycloudflare.com/mobile` → sign in
2. **Phone B:** Wi-Fi **off**, mobile data only → same link → sign in
3. On Phone A, find Phone B in the directory → start a video call
4. Answer on Phone B

**Tell me exactly what happens:**
- Did it ring?
- Did it connect?
- Audio both ways? Video both ways?
- Did hang-up work?

If it fails, tell me **which phone** showed the spinner and whether it connected with
no sound or never connected at all — those are two different faults.

---

## Step 3 — While you test, do this on the laptop

**Settings → System → Power → Screen and sleep → "When plugged in, never sleep"**

I cannot change this myself (it needs admin). If the laptop sleeps, the relay and the
app both stop and every call drops. This is the single most likely cause of "it worked
yesterday and not today".

---

## What is still not sovereign, honestly

| Gap | State |
|---|---|
| TURN relay | **Done** — running, verified |
| Laptop sleeping | **One click from you** (Step 3) |
| Tunnel name changes on restart | Not fixed — free tunnels always do |
| `OWNER-TEST` account | Still there for the test; say the word and it goes |
| Backups on same disk | Plug in a USB drive and I will add the second copy |
| No git remote | Needs a repo you control; free |

**R0 spent. No API keys. No subscriptions. No account with anybody.**
