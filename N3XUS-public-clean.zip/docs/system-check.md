# N3XUS — Full System Check

Run against the live server on port 64281 and the live database.
Everything below was executed, not assumed. Timestamps are server time.

---

## 1. Completed jobs

| # | Job | Evidence |
|---|-----|----------|
| 1 | VOIC3 Section 10 — meetings front end (lobby, waiting room, grid, spotlight, toolbars, chat, whiteboard) | committed `6ece175` |
| 2 | Section 11 — EVOLV3 module artwork | `da0ccb8` |
| 3 | Section 12 — Web Push (VAPID) | `da0ccb8`, live key returns |
| 4 | Section 13 — offline outbox + weak-4G audio priority | `76127af` |
| 5 | Section 14 — workflow cards + compliance export | `ec2a678` |
| 6 | Section 15 — LiveKit SFU, E2EE keys, local transcription | `446c852`, `1f6a355` |
| 7 | CORTEX — one local model, chosen to fit this PC's RAM | `a1e3c3a` |
| 8 | EVOLV3 certificate redesign (wording byte-identical) | `f2795fc`, `a82f00c` |
| 9 | QR encoder — scratch-written, decoder-verified | `52e4066` |
| 10 | Movable tabs — press and hold to drag, saved per device | `52e4066` |
| 11 | Mobile tab bar — no clipped labels, scrolling strip | `fe060c0` |
| 12 | Pair-device sheet can be dismissed (was trapping the screen) | `fe060c0` |
| 13 | LAN + HTTPS module (`br_connect.py`) | tested, **not yet wired in** |

Test suite: **169 tests, OK (1 skipped)** at every commit above.

---

## 2. Not completed

| # | Job | Status |
|---|-----|--------|
| A | Wire `br_connect` into the server (auto LAN bind + HTTPS + QR on screen) | module tested, **not connected** |
| B | Role system — 7 roles (Owner, Admin, HR, Executive, Rep, Patient, Company-phone) | **not started** |
| C | Mobile look overhaul | **partly done** (tab bar only) |
| D | Push to a git remote | **blocked — no remote configured** |
| E | 4G access from anywhere | **blocked — needs a free tunnel + laptop awake** |
| F | Test account `TST-9001` cleanup | **not done** (needs deactivating at the end) |

---

## 3. Live feature test — every endpoint

### Mobile API — 16 of 16 answering

`/me` · `/dashboard` · `/leave` · `/payslips` · `/documents` · `/messages` · `/alerts`
`/contracts` · `/academy/summary` · `/academy/certificates` · `/calls` · `/prefs`
`/reports` · `/patient-alerts` · `/checkin/status` · `/devices`

### VOIC3 API — 12 checked, all correct

| Endpoint | Result |
|----------|--------|
| `/api/voic3/conversations` | 200 |
| `/api/voic3/conversations/5/messages` | 200 |
| `/api/voic3/meetings` | 200 |
| `/api/voic3/ice-config` | 200 — 2 STUN servers |
| `/api/voic3/rtc/capabilities` | 200 — E2EE on, SFU off, transcription off |
| `/api/voic3/presence` | 200 |
| `/api/voic3/templates` | 200 |
| `/api/voic3/calls/history` | 200 |
| `/api/voic3/push/vapid-public-key` | 200 — enabled |
| `/api/voic3/messages/search` | 200 |
| `/api/voic3/compliance/export` | 403 for staff (correct — admin only) |
| `/api/voic3/events` (live stream) | opens and holds — correct for SSE |

### Write actions — 10 tried

| Action | Result | Verdict |
|--------|--------|---------|
| Open a DM | 201, id 5 | works |
| Create a meeting | 201, code `HU5PVAVX` | works |
| Join with a bad code | 404 "Meeting not found." | correct guard |
| **Upload a recording** | **201 — 3 files saved and played back** | **works** |
| Recording with no data | 400 "Recording data required." | correct guard |
| Push subscribe | 201 | works |
| Academy enrol | 200 | works |
| Leave request, bad dates | 400 "Choose valid leave dates." | correct guard |
| Workflow card, bad type | 400 "Unknown card type." | correct guard |
| Stock/supply message | saved and visible in the hub | works |

---

## 4. Live data in the system

| Area | Rows |
|------|------|
| Employees | 6 |
| Mobile accounts | 6 |
| Conversations | 4 |
| Meetings | 0 (before this check) |
| Recordings | 3 |
| Academy courses / cards / certificates | 2 / 70 / 1 |
| Patients | 2 |
| Patient access grants | 3 |
| Emergency alerts | 1 |

Database: **150 tables**, encrypted at rest, opened correctly.

---

## 5. Faults found during the check

1. **The server hung once** during a very large recording upload
   (~540 KB of base64 in a single JSON body). It stopped answering until
   restarted. Small and medium uploads are fine; the fault is the unbounded
   body. **Real risk for long recordings.**
2. **Meeting join timed out** when joining with a valid code on a
   just-created meeting — needs a closer look, may be the same hang.
3. **`voic3_meetings` had 0 rows** before this check — the meeting feature had
   never actually been exercised with real data until now.

---

## 6. What I recommend next, in order

1. Cap the recording upload size and stream it — remove the hang.
2. Re-test meeting join after that fix.
3. Wire `br_connect` in (LAN, HTTPS, QR).
4. Build the role system.
