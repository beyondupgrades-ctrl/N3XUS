# What is next

Everything is up and verified right now:

| Piece | State |
|---|---|
| N3XUS app | listening on `64281` |
| TURN relay | `3478/udp`, allocation **GRANTED** with a server-issued credential |
| Tunnel | `https://YOUR_TUNNEL.trycloudflare.com` |
| APK | `desktop/tools/N3XUS.apk`, 41 KB, signed |
| Autostart | registered — survives a reboot |

---

## The one thing that has never been tested

**Two humans, two networks, one call.** Everything else is proven. This is not.

### Do this, in this order

**1. Send the APK to two staff phones**
`desktop/tools/N3XUS.apk` — WhatsApp, email, anything. Tap to install, allow
"unknown apps" for whichever app you sent it with.

**2. Phone A — office Wi-Fi.** Open N3XUS, sign in.

**3. Phone B — Wi-Fi OFF, mobile data only.** Open N3XUS, sign in.

**4. Call.** Phone A finds Phone B, starts a video call, Phone B answers.

**5. Tell me exactly what happened:**
- Did it ring?
- Did it connect?
- Audio both ways? Video both ways?
- Did hang-up work?

"Connected but no sound" and "never connected" are two completely different faults —
which one it is decides what I fix next.

---

## If it fails, here is what I will check, in order

1. **The relay log** — does a 4G address ever appear? If not, the router rule is not
   reaching us.
2. **`chrome://webrtc-internals`** on the phone — is there a `relay` candidate, or only
   `srflx`?
3. **The Deco** — if the ZTE rule is right but traffic dies, the Deco is in Router mode
   and needs the same rule, or Access Point mode.

---

## Then, in order of what actually matters

| # | Task | Who |
|---|---|---|
| 1 | Two-phone call test | you |
| 2 | Kill the elevated VLC (2.5 GB back) | you |
| 3 | Reboot once, confirm N3XUS starts itself | you |
| 4 | Delete `OWNER-TEST` account | me, on your word |
| 5 | Second backup copy to a USB drive | me, when you plug one in |
| 6 | Git remote so 60+ commits are not on one disk | me, needs a repo you control |
| 7 | Named tunnel so the URL stops changing | me, needs a free Cloudflare account |
| 8 | `pip install faster-whisper` for call captions | me, free |

---

## What I would do next if you just say "go"

**The call test is the only thing that can still fail.** Everything else is polish.
So: send the APK to two phones and call each other. If it works, we are done with the
hard part and the rest is housekeeping.
