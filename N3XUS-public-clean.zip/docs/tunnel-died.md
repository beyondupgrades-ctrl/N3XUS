# That error page — what it means and the fix

## What happened

The phone was opening **`YOUR_TUNNEL.trycloudflare.com`**. That tunnel
is **dead**. It was replaced when the tunnel restarted, and Cloudflare's own error page
is telling you exactly that: *"Cloudflare is currently unable to resolve it."*

**Nothing is wrong with N3XUS.** The address on that phone is simply out of date.

---

## The live address, right now

```
https://YOUR_TUNNEL.trycloudflare.com/mobile
```

Verified working from outside your network a moment ago — HTTP 200.

**Type that into the phone's browser** and it will load. If the phone has the old
address saved to its home screen, delete that shortcut and add the new one.

---

## The real problem, and what I changed

A free quick tunnel gets a **new name every time it restarts**. That means:

- every installed APK pointed at a dead address
- every home-screen shortcut pointed at a dead address
- every QR code printed yesterday was wrong today

That is not acceptable for staff. So I rebuilt the APK:

| Before | Now |
|---|---|
| One hard-coded tunnel URL | **Remembers the last address that worked** |
| Dead tunnel → Cloudflare error page | **Automatically tries the next address** |
| — | Falls back to the LAN address, then the known tunnels |

New APK is at **`desktop/tools/N3XUS.apk`** (41 KB, signed, verified). Re-send it to
staff — the old one on their phones should be uninstalled first.

---

## The permanent fix, and it is free

The address will keep changing until we stop using a quick tunnel. Two free options:

**Option A — named Cloudflare tunnel** *(recommended)*
Needs a free Cloudflare account and a domain name. Then the address is
`n3xus.yourdomain.co.za` **forever**, and it never changes again.

**Option B — DuckDNS + Caddy**
A free `yourname.duckdns.org` subdomain, no card needed. Needs ports 80 and 443
forwarded on the router, which you now know how to do.

Both are R0. Option A is less work and more reliable. Say which you want and I will
set it up.

---

## Right now, to get the test done tonight

1. On both phones, open **`https://YOUR_TUNNEL.trycloudflare.com/mobile`**
2. Sign in
3. Phone A on Wi-Fi, Phone B on mobile data
4. Call each other

The tunnel address only changes if the tunnel restarts — so **do not reboot the laptop
until after the test.**
