# You cannot type the IP — that is the router, not you

The **Host IP address** box is greyed out because it is **filled in from the Device
name dropdown**. On this ZTE firmware you do not type the IP; you pick the device and
the router writes the IP for you.

So the fix is not in the IP box. **It is in the dropdown.**

---

## Do this

1. Click the **Device name** dropdown (currently `deco-S7`)
2. Look for this laptop in the list. It will appear as one of:
   - **`Beyond-Josling`** ← this is this laptop's actual network name
   - `your-user`
   - a MAC address starting **`98-2C-BC-96-19-5F`**
3. Select it. The **Host IP address** will change to **`YOUR_SERVER_IP`** by itself.
4. Check the IP now reads `YOUR_SERVER_IP`, then press **Save**.

If the laptop is not in the dropdown, the router has not listed it yet — see below.

---

## If `Beyond-Josling` is not in the list

The ZTE only lists devices it has seen recently. Two ways to make it appear:

**Option A — reconnect (30 seconds)**
Turn the laptop's Wi-Fi off and on again, wait 20 seconds, then reopen the dropdown.

**Option B — reserve the address first (better, and worth doing anyway)**
1. Go to **More Functions → Manage Device → DHCP → Address Reservation**
   (or **LAN → DHCP Static**)
2. Add a reservation for MAC **`98-2C-BC-96-19-5F`** → IP **`YOUR_SERVER_IP`**
3. Save, then come back to Port Forwarding — the laptop will now be in the dropdown

Option B also stops the address changing later, which would silently break the rule.

---

## Why this matters so much

`deco-S7` at `YOUR_LAN_IP` is a **Deco mesh node**. Saving that rule sends your calls
to a device that knows nothing about N3XUS. It would look like the relay was broken
when the rule was simply pointing at the wrong machine.

The laptop is **`YOUR_SERVER_IP`**, name **`Beyond-Josling`**, MAC
**`98-2C-BC-96-19-5F`**. Those three all mean the same machine — this one.

---

## If the dropdown has no laptop at all, and no reservation screen

Screenshot the dropdown open and send it. I will tell you which entry to pick from the
picture. That has worked every time so far.
