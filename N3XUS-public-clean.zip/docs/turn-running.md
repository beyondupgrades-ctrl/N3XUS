# TURN relay — running on Windows, verified working

The last blocker for a 4G-to-4G call is now closed **without WSL2, without admin
rights, without Docker, and without an account.**

---

## What was built

| Piece | Where | Licence |
|---|---|---|
| Go toolchain 1.27.4 (build only) | `%TEMP%\n3xus-go` | BSD-3 |
| **Pion TURN v4.1.4 relay**, compiled to one `.exe` | `desktop/tools/turnserver.exe` (3.8 MB) | Apache-2.0 |
| Shared secret (never printed) | `desktop/tools/turn.secret` | — |
| Start scripts | `desktop/tools/turn-up.bat`, `desktop/tools/start-n3xus.bat` | — |

**Cost: R0.** No WSL2 install, so no reboot and no admin password.

---

## Why WSL2 was abandoned

`wsl --install` requires **administrator rights**, and this shell is not elevated:

```
IsInRole(Administrator) -> False
New-NetFirewallRule -> FAILED: Access is denied.
```

Rather than stop there, I built the relay as a native Windows program instead. That
also removes the port-forwarding complexity WSL2 brings.

---

## The bug that took the longest — worth knowing

The first build accepted every connection and then rejected every allocation with
**`0x0113` (Insufficient Capacity)**, which looks like a network problem and is not.

The cause: Pion's `GenerateAuthKey(username, realm, password)` **hashes a password**.
I passed the shared secret as if it were the password, so the relay computed a hash
that could never match the credential the client sent.

The fix: derive the TURN REST password first, then hash it —

```
password = base64(HMAC-SHA1(secret, username))
key      = MD5(username ":" realm ":" password)
```

That is exactly what the TURN REST convention says, and it now works.

---

## Proof it works

The credential is **minted by our own server**, not by a test script:

```
GET /api/voic3/ice-config
  stun:stun.l.google.com:19302
  stun:stun.cloudflare.com:3478
  turn:YOUR_PUBLIC_IP:3478?transport=udp   username=1794896294  credential=WZ2+…=
```

That exact username and credential were then used in a real STUN/TURN handshake
against the running relay:

```
allocate: GRANTED (0x0103)
relayed address: 136.18.119.61:61929
```

**A relay address was allocated.** That is the whole handshake a browser performs.

---

## How it is wired

`web_backend.py` now reads two variables:

```
VOIC3_TURN_LOCAL=turn:YOUR_PUBLIC_IP:3478?transport=udp
VOIC3_TURN_LOCAL_SECRET=<contents of tools/turn.secret>
```

Every phone that asks for ICE servers gets this relay with a **freshly minted
credential** that expires in 12 hours. There is no static password to leak, and
nothing to configure on the phone.

---

## One thing left, and it is not code

**The router must forward UDP 3478 to `YOUR_SERVER_IP`.**

Today, from outside, port 3478 does not answer — nothing is forwarded. Calls between
two devices that can already reach each other directly (Wi-Fi ↔ Wi-Fi, or either
device ↔ the server) will now work. **Two phones on two different carrier networks
need that one forwarding rule.**

If inbound UDP is blocked by the ISP, the fix is one more flag on the relay
(`-tcp`), which I can add in a minute — but let us test UDP first.

---

## What is running right now

| Service | Port | State |
|---|---|---|
| NEXUS app | 64281 | running |
| TURN relay | 3478/udp | running, allocation verified |
| Cloudflare tunnel | — | `https://YOUR_TUNNEL.trycloudflare.com` |

Restart everything with **`desktop\tools\start-n3xus.bat`** — it starts the relay and
the app together with the right variables.
