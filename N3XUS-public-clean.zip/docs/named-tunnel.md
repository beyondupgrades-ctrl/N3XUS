# Option A — a permanent N3XUS address

A named Cloudflare tunnel gives you **one address that never changes**, instead of a
new random name every restart. Free. No card.

I have started the login. **It needs you for two minutes**, because it is your account.

---

## Step 1 — Authorise (you, now)

A browser window should have opened. If it did not, open this in your browser:

```
https://dash.cloudflare.com/argotunnel?aud=&callback=https%3A%2F%2Flogin.cloudflareaccess.org%2FCMJ9hYx_0uBUM-ZipM81VQP38h2p_wttke0_sTt8pCc%3D
```

1. **Sign in** to Cloudflare — or **create a free account** if you do not have one
   (email + password, no card required)
2. Pick the domain you want to use
3. Press **Authorize**

When it works, the page says the certificate was saved and the terminal finishes.

**If you do not own a domain yet**, you need one first — Cloudflare can only route a
tunnel to a domain on your account. A `.co.za` domain is roughly R100/year from any
registrar, and it is the only paid thing in this whole build. If you would rather stay
at exactly R0, say so and we switch to **Option B (DuckDNS)** instead — free subdomain,
no card, but it needs ports 80 and 443 forwarded on the router.

---

## Step 2 — I do the rest

Once you have authorised, tell me and I will:

1. Create the tunnel: `cloudflared tunnel create n3xus`
2. Route a hostname to it, e.g. `n3xus.yourdomain.co.za`
3. Write `config.yml` pointing at `https://127.0.0.1:64281`
4. Install it as a **Windows service** so it starts with the machine and survives
   reboots — no console window to keep open
5. Rebuild the APK with that permanent address baked in
6. Update the QR code and the launcher

After that, **the address never changes again**, and staff can keep the app installed
forever.

---

## What you need to tell me

1. **The domain** you authorised (e.g. `your-userdregistration.co.za`)
2. **The subdomain** you want — I suggest `n3xus`, giving `n3xus.your-userdregistration.co.za`

---

## Meanwhile, tonight's test still works

The quick tunnel is live right now:

```
https://YOUR_TUNNEL.trycloudflare.com/mobile
```

Use that for the two-phone call test. The named tunnel replaces it afterwards — it does
not block the test.
