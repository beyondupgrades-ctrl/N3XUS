@echo off
rem ============================================================
rem  _env.bat - find a JDK and the Android SDK on THIS machine.
rem  Replaces paths hard-coded to one laptop ("Android Studio1",
rem  C:\Users\your-user\...). Order: what is already set, then the
rem  usual Android Studio install locations.
rem  Use from another script:  call "%~dp0_env.bat" || exit /b 1
rem ============================================================
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" goto have_java
for %%P in ("%ProgramFiles%\Android\Android Studio\jbr" "%ProgramFiles%\Android\Android Studio1\jbr" "%LOCALAPPDATA%\Programs\Android Studio\jbr") do (
    if exist "%%~P\bin\java.exe" (
        set "JAVA_HOME=%%~P"
        goto have_java
    )
)
echo   ERROR: no JDK found. Install Android Studio, or set JAVA_HOME to a JDK 17 or newer.
exit /b 1
:have_java
set "PATH=%JAVA_HOME%\bin;%PATH%"
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
exit /b 0
