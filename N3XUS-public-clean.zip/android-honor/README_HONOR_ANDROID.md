# Beyond Registration — HONOR Android wrapper project

This is a native Android WebView shell for the Beyond Registration employee mobile web app (currently v5.2.1, `compileSdk 37`, `targetSdk 35`, `minSdk 23`). It gives the employee a normal Android launcher icon/app window and a first-run screen to enter the Windows server address. It does not replace the Windows server or database.

## Build the APK

```
cd android-honor
gradlew.bat assembleDebug
```

If `JAVA_HOME` is not set, point it at the Android Studio JBR, e.g.
`C:\Program Files\Android\Android Studio\jbr`. Output: `app\build\outputs\apk\debug\app-debug.apk` (the installable app; `app-debug-androidTest.apk` is a test artifact — do not install it).

For a signed release APK use Android Studio **Build > Generate Signed Bundle / APK** and keep the keystore private.

## Connect to the Windows system

1. Start Beyond Registration on the Windows PC via `NEXUS_LAUNCHER.bat` (binds `0.0.0.0:64281` for LAN when `BR_ALLOW_LAN=yes`).
2. Keep the phone and PC on the same Wi-Fi.
3. Find the PC's LAN IPv4 address (`ipconfig`), e.g. `YOUR_LAN_IP`.
4. In the app enter `http://PC-IP:64281/mobile/` — **private-LAN HTTP is permitted** by the app (cleartext is allowed for RFC1918/loopback hosts only; arbitrary HTTP hosts are rejected). HTTPS is still preferred for anything your-userd a trusted LAN.
5. Sign in with the employee mobile account provisioned by the Windows administrator (or pair the device with a company pairing code for Ops/SOS features).

Note: Chrome on the phone has its own "Always use secure connections" setting that blocks `http://` even when the app allows it — disable it for testing or use the app itself.

Restrict Windows Firewall to the private network. Never expose this listener to the public internet.

## HONOR installation notes

If Android blocks installation, open Settings and search for **Install unknown apps**. Allow the Files app or browser used to open the APK, install it, then turn that permission off again if desired. Menu wording varies by MagicOS version.

## Scope and limitations

- This project is an Android WebView wrapper around the existing mobile PWA served by Windows; all business data lives on the Windows server.
- The app needs network access to the Windows system for live data. An offline SOS outbox queues safety-critical posts (SOS, location pings, check-ins) in the WebView and retries on reconnect, but a force-stopped app or dead battery cannot guarantee delivery — Android/OEM restrictions apply.
- Native BootReceiver SOS, encrypted on-device queue, and launcher icon are not yet implemented.
- `allowBackup="false"` is set; cleartext is permitted for private LAN hosts only.
