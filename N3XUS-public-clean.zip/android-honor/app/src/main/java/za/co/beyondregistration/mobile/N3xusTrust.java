package za.co.your-userdregistration.mobile;

import android.content.Context;
import android.net.Uri;

import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Trust for the N3XUS server, for BOTH of the addresses it can be reached on.
 *
 * There are two doors into the same server, and they need two different kinds
 * of trust:
 *
 *   1. The LAN address (YOUR_SERVER_IP, 10.x, *.local). The desktop mints its own
 *      HTTPS certificate - free, offline, no account, no authority - so a stock
 *      phone refuses it with "Trust anchor for certification path not found".
 *      res/raw/br_lan_ca.pem is that certificate, copied into the app at build
 *      time, and it is trusted here.
 *
 *   2. A public address (*.trycloudflare.com, a duckdns name). That certificate
 *      is signed by a real authority and is already in Android's own root store;
 *      it must keep being checked against those roots and nothing else.
 *
 * The previous version of this file handed the LAN certificate to every https
 * address, which REPLACED Android's public roots instead of adding to them - so
 * the tunnel answered "certificate not trusted" on the phone while the same
 * address verified perfectly on the desktop. That is the bug this fixes.
 *
 * What is trusted now, and when:
 *   - private/LAN host: the LAN certificate AND Android's public roots, so the
 *     server's certificate is accepted exactly as it presents it, and nothing
 *     that a public authority signed is refused while on the LAN;
 *   - any other host: Android's public roots only, through the platform's own
 *     trust manager - the app gains nothing it did not already have.
 *
 * Nothing else is weakened, on either door:
 *   - hostnames are still verified (the LAN certificate carries every address),
 *   - public sites still need a real, publicly trusted certificate,
 *   - no trust-all manager, no hostname verifier that always says yes.
 *
 * When the desktop regenerates its certificate, the app must ship the new one:
 * the build script copies desktop/cert.pem into res/raw before every build.
 */
final class N3xusTrust {

    private static volatile SSLSocketFactory lanFactory;
    private static volatile SSLSocketFactory publicFactory;
    private static volatile boolean attempted;

    private N3xusTrust() { }

    /** The factory that trusts the N3XUS certificate in addition to the public roots. */
    static SSLSocketFactory socketFactory(Context context) {
        load(context);
        return lanFactory;
    }

    /**
     * Open a connection that trusts the N3XUS certificate. Returns null when the
     * app has no certificate to trust, so the caller can fall back to the default.
     */
    static HttpsURLConnection open(Context context, URL url) throws java.io.IOException {
        return open(context, url, true);
    }

    /**
     * Open a connection with the right trust for this address: the LAN
     * certificate as well as the public roots for a private host, the public
     * roots alone for everything else.
     */
    static HttpsURLConnection open(Context context, URL url, boolean lanHost) throws java.io.IOException {
        if (url == null) return null;
        load(context);
        SSLSocketFactory f = lanHost ? lanFactory : publicFactory;
        if (f == null || !(url.openConnection() instanceof HttpsURLConnection)) return null;
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        connection.setSSLSocketFactory(f);
        return connection;
    }

    /**
     * True when this address is the machine on the local network rather than a
     * public name. Same rule the app uses for its own routing, kept here so the
     * trust decision never drifts from it.
     */
    static boolean isPrivateHost(String url) {
        try {
            String host = Uri.parse(url).getHost();
            if (host == null) return false;
            host = host.toLowerCase(java.util.Locale.ROOT);
            if (host.equals("localhost") || host.endsWith(".local") || host.endsWith(".lan")) return true;
            String[] p = host.split("\\.");
            if (p.length != 4) return false;
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
            if (a == 10) return true;
            if (a == 192 && b == 168) return true;
            if (a == 172 && b >= 16 && b <= 31) return true;
            if (a == 127) return true;
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private static void load(Context context) {
        if (attempted) return;
        synchronized (N3xusTrust.class) {
            if (attempted) return;
            attempted = true;
            try {
                // Android's own roots, exactly as the platform would use them.
                TrustManagerFactory system = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm());
                system.init((KeyStore) null);
                X509TrustManager systemManager = firstX509(system.getTrustManagers());
                publicFactory = contextFrom(new TrustManager[]{systemManager});

                // The same roots, plus this server's own certificate.
                KeyStore store = KeyStore.getInstance(KeyStore.getDefaultType());
                store.load(null, null);
                InputStream pem = context.getResources().openRawResource(R.raw.br_lan_ca);
                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                int index = 0;
                for (java.security.cert.Certificate certificate : cf.generateCertificates(pem)) {
                    store.setCertificateEntry("n3xus-" + (index++), certificate);
                }
                pem.close();
                TrustManagerFactory own = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm());
                own.init(store);
                X509TrustManager ownManager = firstX509(own.getTrustManagers());
                lanFactory = contextFrom(new TrustManager[]{
                        new Composite(systemManager, ownManager)});
            } catch (Exception e) {
                // No LAN certificate shipped, or the platform refused the store:
                // fall back to the public roots alone, which is the platform's
                // own behaviour and never less safe than no app at all.
                lanFactory = publicFactory;
            }
        }
    }

    private static SSLSocketFactory contextFrom(TrustManager[] managers) throws Exception {
        SSLContext ssl = SSLContext.getInstance("TLS");
        ssl.init(null, managers, null);
        return ssl.getSocketFactory();
    }

    private static X509TrustManager firstX509(TrustManager[] managers) {
        for (TrustManager m : managers) {
            if (m instanceof X509TrustManager) return (X509TrustManager) m;
        }
        throw new IllegalStateException("No X509TrustManager on this platform.");
    }

    /**
     * Accepts a certificate that EITHER the platform or the app's own store
     * trusts. Each half still does a full check - chain, signature, validity -
     * and a failure on one side is only forgiven if the other side accepts it.
     */
    private static final class Composite implements X509TrustManager {
        private final X509TrustManager system;
        private final X509TrustManager own;

        Composite(X509TrustManager system, X509TrustManager own) {
            this.system = system;
            this.own = own;
        }

        @Override public void checkClientTrusted(X509Certificate[] chain, String authType)
                throws java.security.cert.CertificateException {
            try { system.checkClientTrusted(chain, authType); }
            catch (java.security.cert.CertificateException e) { own.checkClientTrusted(chain, authType); }
        }

        @Override public void checkServerTrusted(X509Certificate[] chain, String authType)
                throws java.security.cert.CertificateException {
            try { system.checkServerTrusted(chain, authType); }
            catch (java.security.cert.CertificateException e) { own.checkServerTrusted(chain, authType); }
        }

        @Override public X509Certificate[] getAcceptedIssuers() {
            X509Certificate[] a = system.getAcceptedIssuers();
            X509Certificate[] b = own.getAcceptedIssuers();
            X509Certificate[] both = Arrays.copyOf(a, a.length + b.length);
            System.arraycopy(b, 0, both, a.length, b.length);
            return both;
        }
    }

    /** For a diagnostic line: the fingerprint of the certificate the app trusts. */
    static String trustedSubject(Context context) {
        try {
            InputStream pem = context.getResources().openRawResource(R.raw.br_lan_ca);
            X509Certificate certificate = (X509Certificate) CertificateFactory
                    .getInstance("X.509").generateCertificate(pem);
            pem.close();
            return certificate.getSubjectX500Principal().getName();
        } catch (Exception e) {
            return "";
        }
    }
}
