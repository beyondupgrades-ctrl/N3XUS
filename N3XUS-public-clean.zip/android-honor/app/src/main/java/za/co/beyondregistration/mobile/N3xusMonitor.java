package za.co.your-userdregistration.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The living status light.
 *
 * This is the piece that makes the light honest when nobody is looking at the
 * app. It runs on its own clock, forever, and asks the N3XUS server every so
 * often whether it is really there:
 *
 *   every 30 seconds  while the app is on screen
 *   every 60 seconds  while it runs in the background (foreground service)
 *
 * It changes the light in three places at once, so a caregiver can see the state
 * without touching anything:
 *
 *   the coloured dot on the app's notification (always visible while running)
 *   the dot on the splash screen, when the app is open
 *   the saved state the next launch starts from
 *
 * It also reacts immediately to the phone's own network events - Wi-Fi to mobile
 * data, losing signal, getting it back - instead of waiting for the next tick.
 *
 * Red means the patient's phone is not reaching N3XUS. That is a safety signal,
 * so the light is never left green on a guess: green is only set after a real
 * answer from the server.
 */
public final class N3xusMonitor {

    public static final String CHANNEL_ID = "br_link";
    private static final int NOTIF_ID = 4202;

    private static final long INTERVAL_FOREGROUND_MS = 30_000L;
    private static final long INTERVAL_BACKGROUND_MS = 60_000L;
    private static final int PROBE_TIMEOUT_MS = 4000;

    private static N3xusMonitor instance;

    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final SharedPreferences prefs;

    private volatile boolean running;
    private volatile boolean appVisible;
    private volatile boolean checking;
    private volatile boolean lastHealthy;
    private volatile long lastCheckAt;
    private ConnectivityManager.NetworkCallback networkCallback;

    private N3xusMonitor(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(AppIcon.PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized N3xusMonitor get(Context context) {
        if (instance == null) instance = new N3xusMonitor(context);
        return instance;
    }

    /** Start watching. Safe to call on every launch and every page load. */
    public synchronized void start() {
        createChannel();
        registerNetworkWatch();
        if (!running) {
            running = true;
            ui.post(tick);
        }
    }

    /** The app came to the front: check more often. */
    public void setAppVisible(boolean visible) {
        appVisible = visible;
        if (visible && running) checkNow();
    }

    /** Ask for a check right away (a page loaded, the screen woke up). */
    public void checkNow() {
        if (!running) start();
        ui.removeCallbacks(tick);
        ui.post(tick);
    }

    /** True when the last real answer from the server said it is reachable. */
    public boolean isHealthy() { return lastHealthy; }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            check();
            ui.postDelayed(this, appVisible ? INTERVAL_FOREGROUND_MS : INTERVAL_BACKGROUND_MS);
        }
    };

    /** One check: probe the server, set the light, show the result. */
    private void check() {
        if (checking) return;
        if (!hasNetwork()) {
            checking = false;
            publish(false, "No network");
            return;
        }
        checking = true;
        lastCheckAt = System.currentTimeMillis();
        final List<String> candidates = new ArrayList<>();
        String saved = prefs.getString("server_url", "");
        if (saved != null && !saved.isEmpty()) candidates.add(saved);
        candidates.add("https://your-userd-dean.duckdns.org/mobile/");
        new Thread(() -> {
            boolean healthy = false;
            String working = null;
            for (String candidate : candidates) {
                if (probe(candidate)) { healthy = true; working = candidate; break; }
            }
            checking = false;
            if (healthy && working != null) {
                prefs.edit().putString("server_url", working).apply();
            }
            publish(healthy, healthy ? "Connected" : "Not connected");
        }, "n3xus-monitor").start();
    }

    /** Move the light, the notification and the saved state together. */
    private void publish(boolean healthy, String text) {
        boolean changed = healthy != lastHealthy;
        lastHealthy = healthy;
        final String state = healthy ? AppIcon.GREEN : AppIcon.RED;
        if (!state.equals(AppIcon.state(context))) {
            prefs.edit().putString(AppIcon.KEY_STATE, state).apply();
        }
        showNotification(state, text);
        if (changed) {
            // The screen the caregiver is looking at, if any.
            ui.post(() -> {
                if (appVisible) MainActivity.onMonitorResult(healthy);
            });
            if (!healthy) MainActivity.onMonitorLost();
        }
    }

    private void showNotification(String state, String text) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(context, 0, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context);
            nm.notify(NOTIF_ID, b.setSmallIcon(android.R.drawable.presence_online)
                    .setContentTitle(AppIcon.GREEN.equals(state) ? "N3XUS connected" : "N3XUS not connected")
                    .setContentText(AppIcon.GREEN.equals(state)
                            ? "Connected to the N3XUS server"
                            : "Cannot reach the N3XUS server - tap to reconnect")
                    .setContentIntent(pi)
                    .setColor(OpsService.lightColour(state))
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setPriority(Notification.PRIORITY_LOW)
                    .build());
        } catch (Exception ignored) {
            // No notification permission: the in-app light still tells the truth.
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Connection status",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Shows whether this phone can reach the N3XUS server");
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        } catch (Exception ignored) { }
    }

    /** React to the phone changing network, instead of waiting for the next tick. */
    private void registerNetworkWatch() {
        if (networkCallback != null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { ui.postDelayed(N3xusMonitor.this::checkNow, 1500); }
                @Override public void onLost(Network network) { ui.post(() -> publish(false, "Network lost")); }
            };
            NetworkRequest request = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            cm.registerNetworkCallback(request, networkCallback);
        } catch (Exception ignored) { }
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return true;
        }
    }

    /**
     * The status light asks the same question the app asks, with the same trust:
     * the desktop's own certificate for a LAN address, the public roots for a
     * tunnel address. A light that goes red on a good server is a safety signal
     * that lies.
     */
    private HttpURLConnection openTrusted(URL url) throws Exception {
        if (url != null && "https".equalsIgnoreCase(url.getProtocol())) {
            javax.net.ssl.HttpsURLConnection trusted = N3xusTrust.open(context, url, N3xusTrust.isPrivateHost(url.toString()));
            if (trusted != null) return trusted;
        }
        return (HttpURLConnection) url.openConnection();
    }

    private boolean probe(String url) {
        HttpURLConnection connection = null;
        try {
            URL marker = new URL(url.replace("/mobile/", "/api/mobile/app-version"));
            connection = openTrusted(marker);
            connection.setConnectTimeout(PROBE_TIMEOUT_MS);
            connection.setReadTimeout(PROBE_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Connection", "close");
            if (connection.getResponseCode() != 200) return false;
            InputStream in = connection.getInputStream();
            byte[] buffer = new byte[1024];
            int read = in.read(buffer);
            in.close();
            if (read <= 0) return false;
            return new String(buffer, 0, read, "UTF-8").contains("\"apk_available\"");
        } catch (Exception e) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    /** Keep the device awake long enough for a check to finish when it matters. */
    @SuppressWarnings("unused")
    private void holdWakeLock(PowerManager.WakeLock lock) {
        try {
            if (lock != null && !lock.isHeld()) lock.acquire(10_000L);
        } catch (Exception ignored) { }
        finally {
            try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        }
    }
}
