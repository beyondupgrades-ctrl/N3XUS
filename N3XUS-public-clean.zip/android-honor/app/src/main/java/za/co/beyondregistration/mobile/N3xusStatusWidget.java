package za.co.your-userdregistration.mobile;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * The 1x1 home-screen status light.
 *
 * A glowing N that is green while the phone can reach the N3XUS server, amber
 * while it is connecting, and coral when it cannot. The colour is read from the
 * same "nexus_state" preference the persistent notification uses (AppIcon), so
 * the widget and the status-bar dot can never disagree, and both are visible
 * when the app is closed.
 *
 * The state is redrawn whenever the app changes it (AppIcon.set -> refresh) and
 * whenever the launcher asks for an update. Nothing is fetched here, nothing is
 * sent anywhere, and the widget costs nothing to run.
 */
public class N3xusStatusWidget extends AppWidgetProvider {

    /** Repaint every placed widget from the remembered connection state. */
    public static void refresh(Context ctx) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, N3xusStatusWidget.class));
            if (ids == null || ids.length == 0) return;
            for (int id : ids) mgr.updateAppWidget(id, build(ctx));
        } catch (Exception ignored) {
            // The launcher is not running, or no widget has been placed yet.
        }
    }

    private static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_n3xus_status);
        String state = AppIcon.state(ctx);

        int icon = R.drawable.ic_n3xus_n_red;
        String label = ctx.getString(R.string.widget_state_offline);
        if (AppIcon.GREEN.equals(state)) {
            icon = R.drawable.ic_n3xus_n_green;
            label = ctx.getString(R.string.widget_state_connected);
        } else if (AppIcon.YELLOW.equals(state)) {
            icon = R.drawable.ic_n3xus_n_amber;
            label = ctx.getString(R.string.widget_state_connecting);
        }

        v.setImageViewResource(R.id.n3xus_widget_n, icon);
        v.setTextViewText(R.id.n3xus_widget_label, label);
        v.setContentDescription(R.id.n3xus_widget_n, label);

        Intent open = new Intent(ctx, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.n3xus_widget_n, pi);
        v.setOnClickPendingIntent(R.id.n3xus_widget_label, pi);
        return v;
    }

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] appWidgetIds) {
        for (int id : appWidgetIds) mgr.updateAppWidget(id, build(ctx));
    }
}
