package za.co.your-userdregistration.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

/**
 * The connection state the app shows as its indicator light.
 *
 * The light is drawn on the splash screen the moment the app opens, and it is
 * the colour of the app's own notification while the app runs in the background,
 * so the state is visible without opening the app:
 *
 *   red     the phone cannot reach the N3XUS server
 *   yellow  it is looking for the server, or loading the page
 *   green   the server is connected and the app is live
 *
 * The state lives in the "nexus_state" preference so it survives the app being
 * closed, and OpsService repaints the notification from it.
 *
 * It deliberately does NOT switch launcher icons: on Honor / Android 15 the
 * alias swap disables the visible icon before enabling the next one, which left
 * a blank app on the home screen. One fixed icon, one live light.
 *
 * Nothing here costs anything and nothing leaves the phone.
 */
public final class AppIcon {

    public static final String PREFS = "br_mobile";
    public static final String KEY_STATE = "nexus_state";

    public static final String RED = "red";
    public static final String YELLOW = "yellow";
    public static final String GREEN = "green";

    private AppIcon() { }

    /** The state the light is currently showing. */
    public static String state(Context context) {
        try {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_STATE, RED);
        } catch (Exception e) {
            return RED;
        }
    }

    /** Remember this state, and let the running notification pick it up. */
    public static void set(Context context, String state) {
        if (!RED.equals(state) && !YELLOW.equals(state) && !GREEN.equals(state)) state = RED;
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_STATE, state).apply();
        } catch (Exception ignored) { }
        OpsService.repaint(context);
        // The status-bar light and the 1x1 home-screen widget show the same state,
        // repainted from this one write, so all three can never disagree.
        NexusIndicatorService.ensure(context);
        NexusIndicatorService.repaint(context);
        N3xusStatusWidget.refresh(context);
    }

    /** For an administrator or a test: say what the light is showing right now. */
    static void announce(Activity activity) {
        String state = state(activity);
        String text = GREEN.equals(state) ? "Light: green (connected)"
                : YELLOW.equals(state) ? "Light: yellow (connecting)"
                : "Light: red (not connected)";
        Toast.makeText(activity, text, Toast.LENGTH_SHORT).show();
    }
}
