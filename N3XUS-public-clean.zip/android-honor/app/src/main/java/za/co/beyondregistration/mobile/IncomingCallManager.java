package za.co.your-userdregistration.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

/**
 * Rings the phone for a VOIC3 call that arrives while the app is not on screen.
 *
 * CallEventListener already holds the event stream open from OpsService; this
 * class only turns "call.incoming" into something the person can see and hear
 * (a notification with Answer and Decline, and the phone's own ringtone) and
 * takes it away again when the caller hangs up.
 *
 * Free and local: a normal Android notification, the phone's own notification
 * sound, and the same N3XUS server. No push gateway, no account, no key.
 */
final class IncomingCallManager {
    private static final String TAG = "N3XUS-EVENTS";
    static final String CHANNEL_ID = "n3xus_calls";
    static final int NOTIFICATION_ID = 4310;

    private IncomingCallManager() {
    }

    static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "VOIC3 calls", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("An incoming VOIC3 call while the app is in the background");
        channel.enableVibration(true);
        channel.setShowBadge(true);
        // The ringtone is the phone's own, so it costs nothing and works offline.
        channel.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                new android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
        manager.createNotificationChannel(channel);
    }

    /** Shows (or refreshes) the ringing notification for an incoming call. */
    static void start(Context context, JSONObject info) {
        if (context == null) return;
        if (info == null) info = new JSONObject();
        ensureChannel(context);
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        int callId = info.optInt("callId", 0);
        String callerName = info.optString("callerName", "");
        if (callerName.isEmpty()) callerName = "A colleague";
        String callType = info.optString("callType", "Voice");
        String callerRole = info.optString("callerRole", "");
        String body = callType + " call" + (callerRole.isEmpty() ? "" : " · " + callerRole);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra("voic3_action", "answer");
        open.putExtra("voic3_call_id", callId);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(context, NOTIFICATION_ID, open, flags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle(callerName + " is calling")
                .setContentText(body)
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(Notification.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setOngoing(true)
                .setOnlyAlertOnce(false)
                .setDefaults(Notification.DEFAULT_ALL)
                .setContentIntent(contentIntent);
        try {
            manager.notify(NOTIFICATION_ID, builder.build());
        } catch (Exception ignored) {
            // A refused notification must never take the service down.
        }
    }

    /** Removes the ringing notification once the call ended, was declined or was answered. */
    static void callerHungUp(Context context) {
        if (context == null) return;
        try {
            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(NOTIFICATION_ID);
        } catch (Exception ignored) {
        }
    }
}
