package za.co.your-userdregistration.mobile;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Generic Bluetooth Low Energy vitals reader.
 *
 * It only uses the published Bluetooth SIG services, so it works with any
 * band, watch or chest strap that follows the standard:
 *   - Heart Rate          0x180D (measurement 0x2A37)
 *   - Pulse Oximeter      0x1822 (spot-check 0x2A5E, continuous 0x2A5F)
 *   - Health Thermometer  0x1809 (measurement 0x2A1C)
 *   - Blood Pressure      0x1810 (measurement 0x2A35)
 *   - Battery             0x180F (level 0x2A19)
 *
 * Nothing leaves the phone: readings are pushed into the WebView and the app
 * decides what to store. No vendor app, no cloud account, no paid SDK.
 */
public final class VitalsBle {

    public static final UUID SVC_HEART_RATE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    public static final UUID CHR_HR_MEASUREMENT = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    public static final UUID SVC_PLX = UUID.fromString("00001822-0000-1000-8000-00805f9b34fb");
    public static final UUID CHR_PLX_SPOT = UUID.fromString("00002a5e-0000-1000-8000-00805f9b34fb");
    public static final UUID CHR_PLX_CONT = UUID.fromString("00002a5f-0000-1000-8000-00805f9b34fb");
    public static final UUID SVC_THERMO = UUID.fromString("00001809-0000-1000-8000-00805f9b34fb");
    public static final UUID CHR_TEMP = UUID.fromString("00002a1c-0000-1000-8000-00805f9b34fb");
    public static final UUID SVC_BP = UUID.fromString("00001810-0000-1000-8000-00805f9b34fb");
    public static final UUID CHR_BP = UUID.fromString("00002a35-0000-1000-8000-00805f9b34fb");
    public static final UUID SVC_BATTERY = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    public static final UUID CHR_BATTERY = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");
    public static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static BluetoothLeScanner scanner;
    private static WebView target;
    private static BluetoothGatt gatt;
    private static String connectedName = "";
    private static String connectedAddress = "";
    private static final Map<String, String> found = new LinkedHashMap<>();
    private static boolean scanning = false;

    private VitalsBle() {
    }

    public static void attach(WebView webView) {
        target = webView;
        webView.addJavascriptInterface(new Bridge(), "NexusBle");
    }

    // ---------------------------------------------------------------- helpers

    private static Context ctx() {
        return target != null ? target.getContext() : null;
    }

    private static BluetoothAdapter adapter() {
        Context c = ctx();
        if (c == null) return null;
        BluetoothManager m = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
        return m != null ? m.getAdapter() : null;
    }

    private static void emit(String name, JSONObject payload) {
        final String js = "window.NexusVitals&&window.NexusVitals." + name + "(" + payload + ");";
        MAIN.post(new Runnable() {
            @Override public void run() {
                if (target != null) target.evaluateJavascript(js, null);
            }
        });
    }

    private static void toast(String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("message", message);
            emit("onStatus", o);
        } catch (Exception ignored) {
        }
    }

    public static boolean hasPermissions() {
        Context c = ctx();
        if (c == null) return false;
        if (Build.VERSION.SDK_INT >= 31) {
            return c.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    // ------------------------------------------------------------------- scan

    private static final ScanCallback SCAN_CALLBACK = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = d.getName();
            if (name == null || name.trim().isEmpty()) name = "Unnamed device";
            String key = d.getAddress();
            found.put(key, name);
            try {
                JSONObject o = new JSONObject();
                o.put("address", key);
                o.put("name", name);
                o.put("rssi", result.getRssi());
                o.put("hasHeartRate", result.getScanRecord() != null
                        && result.getScanRecord().getServiceUuids() != null
                        && result.getScanRecord().getServiceUuids().contains(new ParcelUuid(SVC_HEART_RATE)));
                o.put("hasPulseOx", result.getScanRecord() != null
                        && result.getScanRecord().getServiceUuids() != null
                        && result.getScanRecord().getServiceUuids().contains(new ParcelUuid(SVC_PLX)));
                emit("onDevice", o);
            } catch (Exception ignored) {
            }
        }

        @Override public void onScanFailed(int errorCode) {
            scanning = false;
            toast("Bluetooth scan failed (" + errorCode + "). Check that Bluetooth is on.");
        }
    };

    public static void startScan() {
        BluetoothAdapter a = adapter();
        if (a == null || !a.isEnabled()) { toast("Bluetooth is off. Turn it on and try again."); return; }
        if (!hasPermissions()) { toast("Bluetooth permission is needed to read a band."); return; }
        scanner = a.getBluetoothLeScanner();
        if (scanner == null) { toast("This phone cannot scan for Bluetooth devices."); return; }
        found.clear();
        List<ScanFilter> filters = new ArrayList<>();
        filters.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SVC_HEART_RATE)).build());
        filters.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SVC_PLX)).build());
        filters.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SVC_BP)).build());
        filters.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SVC_THERMO)).build());
        ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        scanning = true;
        toast("Searching for bands, watches and chest straps…");
        scanner.startScan(filters, settings, SCAN_CALLBACK);
        // If nothing advertises a known service, widen the search once.
        MAIN.postDelayed(new Runnable() {
            @Override public void run() {
                if (scanning && found.isEmpty() && scanner != null) {
                    try {
                        scanner.stopScan(SCAN_CALLBACK);
                        scanner.startScan(null, settings, SCAN_CALLBACK);
                    } catch (Exception ignored) {
                    }
                }
            }
        }, 6000);
    }

    public static void stopScan() {
        scanning = false;
        try {
            if (scanner != null) scanner.stopScan(SCAN_CALLBACK);
        } catch (Exception ignored) {
        }
        toast("Scan stopped.");
    }

    // ---------------------------------------------------------------- connect

    private static final BluetoothGattCallback GATT_CALLBACK = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                toast("Connected. Reading services…");
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                toast("Band disconnected.");
                try {
                    JSONObject o = new JSONObject();
                    o.put("connected", false);
                    emit("onConnection", o);
                } catch (Exception ignored) {
                }
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            boolean any = false;
            any |= subscribe(g, SVC_HEART_RATE, CHR_HR_MEASUREMENT);
            any |= subscribe(g, SVC_PLX, CHR_PLX_SPOT);
            any |= subscribe(g, SVC_PLX, CHR_PLX_CONT);
            any |= subscribe(g, SVC_THERMO, CHR_TEMP);
            any |= subscribe(g, SVC_BP, CHR_BP);
            any |= subscribe(g, SVC_BATTERY, CHR_BATTERY);
            try {
                JSONObject o = new JSONObject();
                o.put("connected", true);
                o.put("name", connectedName);
                o.put("address", connectedAddress);
                o.put("standard", any);
                emit("onConnection", o);
            } catch (Exception ignored) {
            }
            if (!any) {
                toast("This device does not expose standard vitals services. "
                        + "It may need its own app; readings can still be entered by hand.");
            }
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic ch) {
            parse(ch.getUuid(), ch.getValue());
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic ch, int status) {
            parse(ch.getUuid(), ch.getValue());
        }
    };

    private static boolean subscribe(BluetoothGatt g, UUID service, UUID characteristic) {
        BluetoothGattService s = g.getService(service);
        if (s == null) return false;
        BluetoothGattCharacteristic c = s.getCharacteristic(characteristic);
        if (c == null) return false;
        g.setCharacteristicNotification(c, true);
        BluetoothGattDescriptor d = c.getDescriptor(CCCD);
        if (d != null) {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            } else {
                d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(d);
            }
        }
        return true;
    }

    public static void connect(String address) {
        BluetoothAdapter a = adapter();
        if (a == null) { toast("Bluetooth is not available on this phone."); return; }
        if (!hasPermissions()) { toast("Bluetooth permission is needed to read a band."); return; }
        try {
            stopScan();
            if (gatt != null) { gatt.close(); gatt = null; }
            BluetoothDevice device = a.getRemoteDevice(address);
            connectedAddress = address;
            connectedName = found.containsKey(address) ? found.get(address) : device.getName();
            if (connectedName == null) connectedName = "Band";
            gatt = Build.VERSION.SDK_INT >= 23
                    ? device.connectGatt(ctx(), false, GATT_CALLBACK, BluetoothDevice.TRANSPORT_LE)
                    : device.connectGatt(ctx(), false, GATT_CALLBACK);
        } catch (Exception e) {
            toast("Could not connect: " + e.getMessage());
        }
    }

    public static void disconnect() {
        try {
            if (gatt != null) { gatt.disconnect(); gatt.close(); gatt = null; }
        } catch (Exception ignored) {
        }
        toast("Disconnected.");
    }

    // ------------------------------------------------------------------ parse

    private static void parse(UUID chr, byte[] v) {
        if (v == null || v.length == 0) return;
        try {
            JSONObject o = new JSONObject();
            if (CHR_HR_MEASUREMENT.equals(chr)) {
                int flags = v[0] & 0xff;
                int hr = (flags & 0x01) != 0 && v.length >= 3
                        ? ((v[1] & 0xff) | ((v[2] & 0xff) << 8))
                        : (v[1] & 0xff);
                o.put("heart_rate", hr);
            } else if (CHR_PLX_SPOT.equals(chr) || CHR_PLX_CONT.equals(chr)) {
                o.put("spo2", round1(sfloat(v, 1)));
                double pr = sfloat(v, 3);
                if (!Double.isNaN(pr)) o.put("heart_rate", (int) Math.round(pr));
            } else if (CHR_TEMP.equals(chr)) {
                o.put("temperature", round1(floatLe(v, 1)));
            } else if (CHR_BP.equals(chr)) {
                o.put("systolic", (int) Math.round(sfloat(v, 1)));
                o.put("diastolic", (int) Math.round(sfloat(v, 3)));
                o.put("map", (int) Math.round(sfloat(v, 5)));
            } else if (CHR_BATTERY.equals(chr)) {
                o.put("battery", v[0] & 0xff);
            } else {
                return;
            }
            o.put("device", connectedName);
            o.put("address", connectedAddress);
            o.put("at", System.currentTimeMillis());
            emit("onReading", o);
        } catch (Exception ignored) {
        }
    }

    private static double sfloat(byte[] b, int offset) {
        if (b.length < offset + 2) return Double.NaN;
        int raw = (b[offset] & 0xff) | ((b[offset + 1] & 0xff) << 8);
        int mantissa = raw & 0x0fff;
        int exponent = raw >> 12;
        if (exponent >= 0x0008) exponent = -1 * (0x000f + 1 - exponent);
        if (mantissa >= 0x0800) mantissa = -1 * (0x0fff + 1 - mantissa);
        return mantissa * Math.pow(10, exponent);
    }

    private static double floatLe(byte[] b, int offset) {
        if (b.length < offset + 4) return Double.NaN;
        int bits = (b[offset] & 0xff) | ((b[offset + 1] & 0xff) << 8)
                | ((b[offset + 2] & 0xff) << 16) | ((b[offset + 3] & 0xff) << 24);
        return Float.intBitsToFloat(bits);
    }

    private static double round1(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return Double.NaN;
        return Math.round(value * 10.0) / 10.0;
    }

    // ----------------------------------------------------------------- bridge

    public static class Bridge {
        @JavascriptInterface public void startScan() { VitalsBle.startScan(); }
        @JavascriptInterface public void stopScan() { VitalsBle.stopScan(); }
        @JavascriptInterface public void connect(String address) { VitalsBle.connect(address); }
        @JavascriptInterface public void disconnect() { VitalsBle.disconnect(); }
        @JavascriptInterface public boolean isSupported() { return adapter() != null; }
        @JavascriptInterface public boolean hasPermission() { return hasPermissions(); }
        @JavascriptInterface public String connectedName() { return connectedName; }
        @JavascriptInterface public String connectedAddress() { return connectedAddress; }
    }

    /** Ask for the runtime Bluetooth permissions from the host activity. */
    public static void requestPermissions(Activity activity, int requestCode) {
        if (hasPermissions()) return;
        if (Build.VERSION.SDK_INT >= 31) {
            activity.requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT}, requestCode);
        } else {
            activity.requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION}, requestCode);
        }
    }
}
