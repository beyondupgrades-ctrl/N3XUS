package za.co.your-userdregistration.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Lights the connection indicator again after the phone reboots or after the app
 * is updated, so the status-bar dot and the 1x1 widget come back on their own
 * instead of waiting for the app to be opened.
 *
 * It shows the remembered state and nothing more: the dot goes green again only
 * when the app next reaches the server and says so.
 */
public class NexusIndicatorBoot extends BroadcastReceiver {

    @Override public void onReceive(Context ctx, Intent intent) {
        try {
            String action = intent == null ? "" : intent.getAction();
            if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                    || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                    || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
                NexusIndicatorService.ensure(ctx);
                N3xusStatusWidget.refresh(ctx);
            }
        } catch (Exception ignored) {
            // Nothing to do: the indicators will light when the app is next opened.
        }
    }
}
