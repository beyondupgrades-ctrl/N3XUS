package za.co.your-userdregistration.mobile;

import android.app.Activity;
import android.app.DownloadManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.ValueCallback;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * The N3XUS phone app.
 *
 * It opens straight onto the login screen. There is nothing to search for and
 * nothing to tap twice: on launch it finds the server by itself, in this order:
 *
 *   1. the address that worked last time (remembered on this phone);
 *   2. the laptop answering the N3XUS discovery probe on the office Wi-Fi
 *      (a UDP broadcast on 64282, answered by desktop/lan_discovery.py);
 *   3. the fixed addresses the app has always shipped with (LAN and tunnel);
 *   4. a sweep of this phone's own subnet, port 64281.
 *
 * The first address that answers is opened at once. A status light in the
 * title bar shows what is happening:
 *
 *   RED    not connected - nothing answered, or the connection dropped
 *   YELLOW connecting - looking for the server, or loading the page
 *   GREEN  connected - the login screen (or any page) is live
 *
 * The screen a caregiver sees is a "splash": the light, the N3XUS name and one
 * line of plain text. There is no address box, no FIND button and no error
 * page in the normal path - it retries by itself, with a back-off, while the
 * phone is awake.
 */
public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 4102;
    private static final int LOCATION_REQUEST = 4103;

    /** A probe must answer this quickly, otherwise the address is treated as dead. */
    private static final int PAGE_TIMEOUT_MS = 20000;
    private static final int PROBE_TIMEOUT_MS = 8000;
    private static final String LAN_BOOTSTRAP_ADDRESS = "https://YOUR_SERVER_IP:64281/";

    /** First retry after a failed round; doubles up to the cap, never longer. */
    private static final long RETRY_FIRST_MS = 4000L;
    private static final long RETRY_MAX_MS = 60000L;

    /** How many addresses the sweep of this phone's own subnet may try. */
    private static final int SWEEP_MAX_HOSTS = 40;
    private static final int SWEEP_THREADS = 16;
    private static final long SWEEP_BUDGET_MS = 2000L;

    /** The port the N3XUS server always uses. */
    private static final int SERVER_PORT = 64281;

    /** UDP port the desktop answers the discovery probe on (lan_discovery.py). */
    private static final int DISCOVERY_PORT = 64282;
    private static final byte[] DISCOVERY_PROBE = "N3XUS?v1".getBytes(java.nio.charset.StandardCharsets.US_ASCII);

    /**
     * The one name that never changes: publish-tunnel.py writes the current free
     * tunnel host into this DuckDNS TXT record, so a cold launch can find the
     * server from any network without a typed address, a LAN or an intent flag.
     */
    private static final String DISCOVERY_NAME = "YOUR_DUCKDNS_DOMAIN.duckdns.org";
    private static final String DOH_QUERY = "https://cloudflare-dns.com/dns-query?name="
            + DISCOVERY_NAME + "&type=TXT";
    /** A DNS answer is reused for a minute, so retries do not hammer the resolver. */
    private static final long DISCOVERY_TTL_MS = 60000L;
    private String discoveredPublicUrl;
    private long discoveredPublicAt;

    /** Fixed LAN addresses are last-resort candidates; quick-tunnel names are never baked in. */
    private static final String[] FALLBACK_HOSTS = {
            "YOUR_SERVER_IP:64281",
            "YOUR_SERVER_IP:64281"
    };

    // Warm cream, the same canvas the pages use, so the native chrome never
    // flashes a dark-blue band above a cream page.
    private static final int COLOR_BG = Color.rgb(250, 247, 242);
    private static final int COLOR_CARD = Color.rgb(243, 237, 226);
    private static final int COLOR_RED = Color.rgb(229, 57, 53);
    private static final int COLOR_YELLOW = Color.rgb(255, 193, 7);
    private static final int COLOR_GREEN = Color.rgb(32, 201, 151);

    private static volatile WebView activeWebView;

    /** The activity on screen, so the background monitor can update its light. */
    private static volatile MainActivity current;

    private WebView webView;
    private FrameLayout host;
    private static final int PAGE_LOADED_TAG = 0x6e337573;
    private ValueCallback<Uri[]> fileCallback;
    /** Request code for the VOIC3 mic/camera runtime prompt. */
    private static final int REQ_MEDIA = 4812;
    /** An address handed to the app by a launch intent or a deep link. */
    private String launchServerUrl;

    /** Set while a WebView getUserMedia() request waits on the system prompt. */
    private Runnable pendingMediaGrant;

    private SharedPreferences prefs;
    private android.webkit.GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private String currentUrl;
    private boolean currentLoadFailed;

    // --- the splash (shown until the login screen is live) -----------------
    private LinearLayout splash;
    private TextView statusLine;
    private TextView detailLine;
    private TextView statusLight;
    private Button settingsToggle;
    private LinearLayout advancedPanel;

    // --- connection state --------------------------------------------------
    private volatile boolean destroyed;
    private int connectRound;
    private long retryDelay = RETRY_FIRST_MS;
    private Runnable pendingRetry;
    private final List<String> retryQueue = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        startIndicator();
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        setLightSystemBars();
        current = this;
        prefs = getSharedPreferences("br_mobile", MODE_PRIVATE);
        buildSplash();
        // Clicking the icon is all a caregiver should ever have to do.
        N3xusMonitor.get(this).start();
        // Read the address before the first attempt, so a launch intent is honoured
        // on the very first try instead of being overridden by the LAN sweep.
        adoptLaunchAddress(getIntent());
        autoConnect();
    }

    // ====================================================================== //
    //  Splash: status light + name + one line. No searching, no buttons.     //
    // ====================================================================== //
    private void buildSplash() {
        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setBackgroundColor(COLOR_BG);
        splash.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(24);
        splash.setPadding(pad, dp(64), pad, pad);

        statusLight = new TextView(this);
        statusLight.setText("\u25CF"); // a filled circle
        statusLight.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64);
        statusLight.setGravity(Gravity.CENTER);
        statusLight.setTextColor(COLOR_RED);
        splash.addView(statusLight, new LinearLayout.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText("N3XUS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(4));
        splash.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Beyond Registration");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        subtitle.setGravity(Gravity.CENTER);
        splash.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        statusLine = new TextView(this);
        statusLine.setText("Starting...");
        statusLine.setTextColor(Color.LTGRAY);
        statusLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        statusLine.setGravity(Gravity.CENTER);
        statusLine.setPadding(0, dp(28), 0, 0);
        splash.addView(statusLine, new LinearLayout.LayoutParams(-1, -2));

        detailLine = new TextView(this);
        detailLine.setText("");
        detailLine.setTextColor(Color.GRAY);
        detailLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        detailLine.setGravity(Gravity.CENTER);
        detailLine.setPadding(dp(16), dp(14), dp(16), 0);
        splash.addView(detailLine, new LinearLayout.LayoutParams(-1, -2));

        // The address box exists, but folded away: it is for an administrator
        // on a network where the automatic search cannot work, not for daily use.
        settingsToggle = new Button(this);
        settingsToggle.setText("Server address");
        settingsToggle.setAllCaps(false);
        settingsToggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        settingsToggle.setBackgroundColor(Color.TRANSPARENT);
        settingsToggle.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, dp(40));
        tp.topMargin = dp(24);
        splash.addView(settingsToggle, tp);

        advancedPanel = buildAdvancedPanel();
        advancedPanel.setVisibility(View.GONE);
        splash.addView(advancedPanel, new LinearLayout.LayoutParams(-1, -2));

        settingsToggle.setOnClickListener(v -> {
            boolean showing = advancedPanel.getVisibility() == View.VISIBLE;
            advancedPanel.setVisibility(showing ? View.GONE : View.VISIBLE);
        });

        setContentView(splash);
    }

    private LinearLayout buildAdvancedPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(0, dp(8), 0, 0);

        final EditText serverInput = new EditText(this);
        serverInput.setSingleLine(true);
        serverInput.setTextColor(Color.WHITE);
        serverInput.setHintTextColor(Color.GRAY);
        serverInput.setHint("https://your-server:64281/mobile/");
        serverInput.setText(prefs.getString("server_url", ""));
        serverInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        serverInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        serverInput.setBackgroundColor(COLOR_CARD);
        panel.addView(serverInput, new LinearLayout.LayoutParams(-1, dp(58)));

        Button save = new Button(this);
        save.setText("USE THIS ADDRESS");
        save.setOnClickListener(v -> {
            String typed = serverInput.getText().toString().trim();
            if (typed.isEmpty()) {
                Toast.makeText(this, "Type the server address first", Toast.LENGTH_SHORT).show();
                return;
            }
            String url = normaliseAddress(typed);
            if (url == null) {
                serverInput.setError("Plain http is only allowed on a private network (192.168.x.x, 10.x.x.x, 172.16-31.x.x). Use https otherwise.");
                return;
            }
            prefs.edit().putString("server_url", url).apply();
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(serverInput.getWindowToken(), 0);
            advancedPanel.setVisibility(View.GONE);
            connectTo(url);
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(50));
        bp.topMargin = dp(10);
        panel.addView(save, bp);

        TextView note = new TextView(this);
        note.setText("Leave this empty and the app finds the server by itself.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        note.setPadding(0, dp(10), 0, 0);
        panel.addView(note, new LinearLayout.LayoutParams(-1, -2));
        return panel;
    }

    /**
     * RED / YELLOW / GREEN, on the splash and on the home-screen icon at once.
     * The icon is not decoration: AppIcon switches the launcher alias, so the dot
     * on the home screen stays the truth even when the app is closed.
     */
    private void setLight(int colour, String text) {
        if (destroyed) return;
        currentLight = colour;
        if (statusLight != null) statusLight.setTextColor(colour);
        if (statusLine != null) statusLine.setText(text);
        if (splash != null && splash.getParent() == null) setContentView(splash);
        String state = colour == COLOR_GREEN ? AppIcon.GREEN
                : colour == COLOR_YELLOW ? AppIcon.YELLOW
                : AppIcon.RED;
        if (!state.equals(lastLightState)) {
            lastLightState = state;
            AppIcon.set(this, state);
        }
    }

    /** The state last written, so the preference is only touched on a real change. */
    private String lastLightState;

    /**
     * Light the status-bar dot and the 1x1 home-screen widget as soon as the app
     * starts and keep them lit while it runs, so the connection is visible at a
     * glance even after the app is closed. AppIcon.set() repaints all of them
     * from one value, so they can never disagree.
     */
    private void startIndicator() {
        try {
            NexusIndicatorService.ensure(this);
            NexusIndicatorService.repaint(this);
            N3xusStatusWidget.refresh(this);
        } catch (Exception ignored) { }
    }

    /**
     * Dark status-bar and navigation-bar icons, because the canvas behind them is
     * warm cream. Done by hand for every API level the app supports, rather than
     * only through the theme, so a phone that keeps a cached window still gets it.
     */
    @SuppressWarnings("deprecation")
    private void setLightSystemBars() {
        try {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (Build.VERSION.SDK_INT >= 23) flags |= 0x00002000; // LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags |= 0x00000010; // LIGHT_NAVIGATION_BAR
            getWindow().getDecorView().setSystemUiVisibility(flags);
        } catch (Exception ignored) { }
    }
    private String lastDetail = "";
    private String lastDetailAll = "";

    /** The reason the last round failed, in the phone's own words. */
    private void setDetail(String text) {
        lastDetail = text == null ? "" : text;
        if (detailLine != null && !destroyed) detailLine.setText(lastDetail);
    }

    /** Bring the splash back over the page (the connection was lost). */
    private void showSplash() {
        if (splash != null) splash.setVisibility(View.VISIBLE);
    }

    private void hideSplash() {
        if (splash != null) splash.setVisibility(View.GONE);
    }

    private void showSplashAgain() {
        if (destroyed) return;
        if (splash != null && splash.getParent() != null) {
            showSplash();
            if (detailLine != null) detailLine.setText(lastDetail);
            return;
        }
        setContentView(splash);
        if (advancedPanel != null) advancedPanel.setVisibility(View.GONE);
    }

    // ====================================================================== //
    //  Finding the server, with nobody tapping anything                     //
    // ====================================================================== //
    private void autoConnect() {
        connectRound++;
        final int round = connectRound;
        cancelRetry();
        currentLoadFailed = false;
        // The status light is fed by the monitor from here on: it goes green the
        // moment the server answers, on any network, without this screen running.
        N3xusMonitor.get(this).start();
        setLight(COLOR_YELLOW, "Connecting...");
        new Thread(() -> {
            List<String> candidates = collectCandidates();
            android.util.Log.i("N3XUS", "round " + round + " candidates: " + candidates);
            if (destroyed || round != connectRound) return;
            // Probe them together, not one after another: an address that is not
            // there costs the full timeout, and six of those in a row looks like
            // a frozen app. The first answer wins, in list order on a tie.
            final java.util.concurrent.CountDownLatch done =
                    new java.util.concurrent.CountDownLatch(candidates.size());
            final java.util.concurrent.atomic.AtomicBoolean found =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            for (String candidate : candidates) {
                Thread t = new Thread(() -> {
                    try {
                        if (found.get()) return;
                        String why = probeReason(candidate);
                        if (why == null) {
                            if (found.compareAndSet(false, true)) {
                                prefs.edit().putString("server_url", candidate).apply();
                                // Amber the instant a server answers: the page is on
                                // its way. Green only when onPageFinished fires.
                                ui.post(() -> { if (!destroyed) setLight(COLOR_YELLOW, "Loading..."); });
                                ui.post(() -> {
                                    if (!destroyed && round == connectRound) connectTo(candidate);
                                });
                            }
                        } else {
                            android.util.Log.i("N3XUS", "probe failed " + candidate + " : " + why);
                            ui.post(() -> appendTried(candidate, why));
                        }
                    } finally {
                        done.countDown();
                    }
                }, "n3xus-probe");
                t.setDaemon(true);
                t.start();
            }
            try { done.await(9, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            if (found.get()) return;
            ui.post(() -> {
                if (destroyed || round != connectRound) return;
                scheduleRetry();
            });
        }, "n3xus-connect").start();
    }

    /**
     * Every address worth trying, best first, without repeating one.
     *
     * The rule is simple on purpose: if this app knows an address it trusts - one
     * the user typed, one a launch intent gave it, or one that has already served
     * the page - it tries ONLY that. Guessing about the LAN afterwards is what put
     * the app in a red "Not connected" loop: on this network the LAN drops packets
     * silently, so every guess burned its timeout and then overrode a working
     * address. Guessing is now the last resort, never the default.
     */
    private List<String> collectCandidates() {
        List<String> known = new ArrayList<>();

        String saved = normaliseAddress(prefs.getString("server_url", ""));
        if (saved != null) known.add(saved);

        String launched = normaliseAddress(launchServerUrl);
        if (launched != null && !known.contains(launched)) known.add(launched);

        for (String remembered : rememberedPublicUrls()) {
            if (!known.contains(remembered)) known.add(remembered);
        }

        // The DNS record first, whatever else is known: on mobile data the tunnel is
        // the only way in, and a tunnel host that changed since last launch is
        // exactly what a remembered address would miss.
        String published = discoverPublicUrl();
        if (published != null) {
            known.remove(published);
            known.add(0, published);
        }

        // A saved LAN address that stops answering must not strand the phone. This is
        // the "red light forever" bug seen on the handset: YOUR_SERVER_IP was saved once,
        // the phone moved to Wi-Fi, and the list held that one dead address - the
        // LAN probe, the fixed hosts and the subnet sweep were never reached because
        // anything "known" short-circuited the list.
        if (!known.isEmpty()) {
            if (published != null) return known;
            String first = known.get(0);
            boolean looksLocal = isPrivateLanHost(first);
            if (!looksLocal) return known;
            List<String> fallbacks = fallbackCandidates();
            for (String one : fallbacks) {
                if (!known.contains(one)) known.add(one);
            }
            return known;
        }

        return fallbackCandidates();
    }

    /** Discovery and last-resort addresses, used when nothing known answers. */
    private List<String> fallbackCandidates() {
        Set<String> ordered = new LinkedHashSet<>();
        for (String discovered : discoverOnLan()) {
            String url = normaliseAddress(discovered);
            if (url != null) ordered.add(url);
        }
        for (String host : FALLBACK_HOSTS) {
            String url = normaliseAddress(host);
            if (url != null) ordered.add(url);
        }
        for (String swept : sweepOwnSubnet()) {
            String url = normaliseAddress(swept);
            if (url != null) ordered.add(url);
        }
        return new ArrayList<>(ordered);
    }

    /**
     * The tunnel host published in the DuckDNS TXT record right now, as a page
     * address, or null when there is none.
     *
     * Asked over DNS-over-HTTPS, which needs nothing but HTTPS - no DNS library, no
     * account, no key - and answers even when the carrier's own DNS is useless. The
     * answer is cached for a minute and kept as a candidate if the query fails, so
     * a flaky resolver costs one slow launch, never a broken one.
     */
    private synchronized String discoverPublicUrl() {
        long now = System.currentTimeMillis();
        if (discoveredPublicUrl != null && (now - discoveredPublicAt) < DISCOVERY_TTL_MS) {
            return discoveredPublicUrl;
        }
        HttpURLConnection connection = null;
        try {
            URL url = new URL(DOH_QUERY);
            connection = openTrusted(url);
            connection.setConnectTimeout(4000);
            connection.setReadTimeout(4000);
            connection.setRequestProperty("Accept", "application/dns-json");
            connection.setRequestProperty("Connection", "close");
            if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 400) return null;
            InputStream in = connection.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[2048];
            int read;
            while ((read = in.read(chunk)) > 0 && buffer.size() < 65536) buffer.write(chunk, 0, read);
            in.close();
            org.json.JSONArray answers = new org.json.JSONObject(buffer.toString("UTF-8")).optJSONArray("Answer");
            android.util.Log.i("N3XUS", "discovery answers: " + buffer.toString("UTF-8"));
            if (answers == null) return discoveredPublicUrl;
            for (int i = 0; i < answers.length(); i++) {
                String value = answers.optJSONObject(i) == null ? "" : answers.optJSONObject(i).optString("data", "");
                value = value.replace("\"", "").trim();
                if (value.endsWith(".trycloudflare.com")) {
                    // The tunnel only speaks https: asking it for http earns a 301 that
                    // the probe refuses (it does not follow redirects), so the address
                    // was thrown away as "not an N3XUS server".
                    String candidate = normaliseAddress("https://" + value);
                    if (candidate != null) {
                        discoveredPublicUrl = candidate;
                        discoveredPublicAt = now;
                        return candidate;
                    }
                }
            }
            return discoveredPublicUrl;
        } catch (Exception e) {
            // Offline, or the resolver refused: keep the last good answer.
            android.util.Log.i("N3XUS", "discovery failed: " + e);
            return discoveredPublicUrl;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    /**
     * Every public (tunnel) address this phone has successfully loaded the app
     * from, newest first. Remembering them means a reconnect never has to guess:
     * the tunnel that worked last time is tried before the LAN that did not.
     */
    private List<String> rememberedPublicUrls() {
        List<String> found = new ArrayList<>();
        try {
            org.json.JSONArray saved = new org.json.JSONArray(prefs.getString("known_public_urls", "[]"));
            for (int i = 0; i < saved.length(); i++) {
                String url = normaliseAddress(saved.optString(i, ""));
                if (url != null && !found.contains(url)) found.add(url);
            }
        } catch (Exception ignored) {
            // A corrupt value simply means "nothing remembered yet".
        }
        return found;
    }

    /** Records a public address that just answered, newest first, capped at eight. */
    private void rememberPublicUrl(String url) {
        String clean = normaliseAddress(url);
        if (clean == null || clean.startsWith("https://192.168.") || clean.startsWith("https://10.")) return;
        try {
            List<String> next = new ArrayList<>();
            next.add(clean);
            for (String old : rememberedPublicUrls()) {
                if (!old.equals(clean) && next.size() < 8) next.add(old);
            }
            org.json.JSONArray array = new org.json.JSONArray();
            for (String one : next) array.put(one);
            prefs.edit().putString("known_public_urls", array.toString()).apply();
        } catch (Exception ignored) {
            // Remembering is a convenience; never let it break a connection.
        }
    }

    /**
     * Asks the LAN backend for the addresses it is reachable on right now - above
     * all the current quick-tunnel address. This bootstrap is only needed on Wi-Fi;
     * public addresses learned on prior launches remain subject to probing.
     */
    private List<String> knownFromServer() {
        List<String> found = new ArrayList<>();
        HttpURLConnection connection = null;
        try {
            // On Wi-Fi, ask the LAN backend for its current quick-tunnel URL and
            // reachable LAN addresses. If the LAN is unavailable (mobile data), this
            // times out quickly; remembered/publicly discovered candidates still apply.
            URL url = new URL(LAN_BOOTSTRAP_ADDRESS + "api/mobile/app-version");
            connection = openTrusted(url);
            connection.setConnectTimeout(1800);
            connection.setReadTimeout(1800);
            InputStream in = connection.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[2048];
            int read;
            while ((read = in.read(chunk)) > 0 && buffer.size() < 16384) buffer.write(chunk, 0, read);
            in.close();
            org.json.JSONArray urls = new org.json.JSONObject(buffer.toString("UTF-8")).optJSONArray("urls");
            if (urls != null) {
                for (int i = 0; i < urls.length(); i++) {
                    String candidate = urls.optString(i, "");
                    if (candidate.startsWith("https://") && !found.contains(candidate)) found.add(candidate);
                }
            }
        } catch (Exception ignored) {
            // The tunnel is down or the phone is offline; the fixed list still applies.
        } finally {
            if (connection != null) connection.disconnect();
        }
        return found;
    }

    /**
     * Asks the N3XUS desktop on this Wi-Fi where it is: one UDP broadcast, one
     * small JSON reply. Returns the https:// addresses it names, nearest first.
     * Returns an empty list when there is no desktop on this network.
     */
    private List<String> discoverOnLan() {
        List<String> found = new ArrayList<>();
        java.net.DatagramSocket socket = null;
        try {
            socket = new java.net.DatagramSocket();
            socket.setBroadcast(true);
            socket.setSoTimeout(1500);
            java.net.DatagramPacket out = new java.net.DatagramPacket(
                    DISCOVERY_PROBE, DISCOVERY_PROBE.length,
                    java.net.InetAddress.getByName("255.255.255.255"), DISCOVERY_PORT);
            socket.send(out);
            long deadline = System.currentTimeMillis() + 1600L;
            byte[] buffer = new byte[2048];
            while (System.currentTimeMillis() < deadline) {
                java.net.DatagramPacket in = new java.net.DatagramPacket(buffer, buffer.length);
                try {
                    socket.receive(in);
                } catch (java.net.SocketTimeoutException timeout) {
                    break;
                }
                String body = new String(in.getData(), 0, in.getLength(), "UTF-8");
                if (!body.contains("\"nexus\"")) continue;
                org.json.JSONArray urls = new org.json.JSONObject(body).optJSONArray("urls");
                if (urls == null) continue;
                for (int i = 0; i < urls.length(); i++) {
                    String url = urls.optString(i, "");
                    if (url.startsWith("https://") && !found.contains(url)) found.add(url);
                }
            }
        } catch (Exception ignored) {
            // No broadcast (mobile data, locked-down Wi-Fi) - the other steps cover it.
        } finally {
            if (socket != null) socket.close();
        }
        return found;
    }

    /**
     * A last resort that needs no discovery at all: try the N3XUS port on the
     * other addresses of this phone's own /24, a few at a time. Skipped unless
     * the phone is on Wi-Fi, and never run twice in the same round.
     */
    private List<String> sweepOwnSubnet() {
        List<String> found = new ArrayList<>();
        String self = wifiIpv4();
        if (self == null) return found;
        String[] parts = self.split("\\.");
        if (parts.length != 4) return found;
        final String prefix = parts[0] + "." + parts[1] + "." + parts[2] + ".";
        final int myLast = Integer.parseInt(parts[3]);

        // Nearest addresses first: the router hands out neighbouring numbers.
        List<Integer> order = new ArrayList<>();
        for (int step = 1; step <= 254 && order.size() < SWEEP_MAX_HOSTS; step++) {
            if (myLast - step > 0) order.add(myLast - step);
            if (myLast + step < 255 && order.size() < SWEEP_MAX_HOSTS) order.add(myLast + step);
        }
        final List<Integer> hosts = order;
        final java.util.concurrent.atomic.AtomicBoolean hit = new java.util.concurrent.atomic.AtomicBoolean(false);
        final java.util.concurrent.ConcurrentLinkedQueue<String> answers = new java.util.concurrent.ConcurrentLinkedQueue<>();
        final java.util.concurrent.atomic.AtomicInteger cursor = new java.util.concurrent.atomic.AtomicInteger(0);

        Runnable worker = () -> {
            while (!hit.get()) {
                int index = cursor.getAndIncrement();
                if (index >= hosts.size()) return;
                String candidate = "https://" + prefix + hosts.get(index) + ":" + SERVER_PORT + "/mobile/";
                if (probe(candidate)) {
                    answers.add(candidate);
                    hit.set(true);
                    return;
                }
            }
        };
        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < SWEEP_THREADS; i++) {
            Thread thread = new Thread(worker, "n3xus-sweep-" + i);
            thread.setDaemon(true);
            threads.add(thread);
            thread.start();
        }
        long deadline = System.currentTimeMillis() + SWEEP_BUDGET_MS;
        for (Thread thread : threads) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) break;
            try { thread.join(left); } catch (InterruptedException ignored) { }
        }
        hit.set(true);
        found.addAll(answers);
        return found;
    }

    /** This phone's own IPv4 address on Wi-Fi, or null when it is on mobile data. */
    private String wifiIpv4() {
        try {
            android.net.wifi.WifiManager wifi =
                    (android.net.wifi.WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi == null || !wifi.isWifiEnabled()) return null;
            int address = wifi.getConnectionInfo().getIpAddress();
            if (address == 0) return null;
            return String.format(java.util.Locale.US, "%d.%d.%d.%d",
                    (address & 0xff), (address >> 8) & 0xff, (address >> 16) & 0xff, (address >> 24) & 0xff);
        } catch (Exception e) {
            return null;
        }
    }

    /** The certificate the app trusts, for the diagnostic line. */
    private String trustedNote() {
        String subject = N3xusTrust.trustedSubject(this);
        return subject.isEmpty() ? "no certificate shipped in this build"
                : "trusting: " + subject;
    }

    /** One line per address tried, newest last, on the splash for diagnosis. */
    private void appendTried(String candidate, String reason) {
        String host = candidate.replace("https://", "").replace("/mobile/", "");
        String line = host + " - " + reason;
        String existing = lastDetail == null ? "" : lastDetail;
        if (existing.contains(host)) return;
        String combined = existing.isEmpty() ? line : existing + "\n" + line;
        if (combined.length() > 900) combined = combined.substring(combined.length() - 900);
        lastDetailAll = combined;
        // The splash stays calm: one short line. The full list is behind
        // "Server address" for whoever is diagnosing it.
        setDetail("Last try: " + host + " - " + reason);
    }

    /**
     * Like probe(), but says WHY it failed: "no answer", "certificate refused",
     * "HTTP 404", "not an N3XUS server". Null means it answered correctly.
     */
    private String probeReason(String url) {
        HttpURLConnection connection = null;
        try {
            URL base = new URL(url);
            URL marker = new URL(base.getProtocol(), base.getHost(), "/api/mobile/app-version");
            connection = openTrusted(marker);
            connection.setConnectTimeout(PROBE_TIMEOUT_MS);
            connection.setReadTimeout(PROBE_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Connection", "close");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 400) return "HTTP " + code;
            InputStream in = connection.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[1024];
            int read;
            while ((read = in.read(chunk)) > 0 && buffer.size() < 8192) buffer.write(chunk, 0, read);
            in.close();
            return buffer.toString("UTF-8").contains("\"apk_available\"") ? null : "not an N3XUS server";
        } catch (javax.net.ssl.SSLException e) {
            // The phone refuses this machine's self-signed certificate until it is
            // installed, which is exactly the state a fresh install is in. Say so
            // in words that can be acted on, with the reason attached.
            return "certificate not trusted (" + e.getClass().getSimpleName()
                    + (e.getMessage() == null ? "" : ": " + e.getMessage().split("\\n")[0]) + ")";
        } catch (java.net.SocketTimeoutException e) {
            return "no answer";
        } catch (java.net.UnknownHostException e) {
            return "no such host";
        } catch (Exception e) {
            return e.getClass().getSimpleName();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    /** True when this address really is an N3XUS server and not a router login page. */
    private boolean probe(String url) {
        HttpURLConnection connection = null;
        try {
            URL base = new URL(url);
            URL marker = new URL(base.getProtocol(), base.getHost(), "/api/mobile/app-version");
            connection = openTrusted(marker);
            connection.setConnectTimeout(PROBE_TIMEOUT_MS);
            connection.setReadTimeout(PROBE_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Connection", "close");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 400) return false;
            InputStream in = connection.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[1024];
            int read;
            while ((read = in.read(chunk)) > 0 && buffer.size() < 8192) buffer.write(chunk, 0, read);
            in.close();
            String body = buffer.toString("UTF-8");
            return body.contains("\"apk_available\"");
        } catch (Exception e) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    /** How many failed rounds in a row re-read the DNS record instead of waiting for it to expire. */
    private int failedRounds;

    /** Try again on its own. Never gives up, never grows past RETRY_MAX_MS. */
    private void scheduleRetry() {
        if (destroyed) return;
        setLight(COLOR_RED, "Not connected. Retrying...");
        cancelRetry();
        // After two failed rounds in a row the tunnel may simply have restarted with
        // a new hostname, so forget the cached DNS answer and ask again: a stale
        // host is the one thing that makes every retry fail for the same reason.
        failedRounds++;
        if (failedRounds >= 2) {
            synchronized (this) {
                discoveredPublicUrl = null;
                discoveredPublicAt = 0;
            }
        }
        pendingRetry = () -> {
            pendingRetry = null;
            if (destroyed) return;
            autoConnect();
        };
        ui.postDelayed(pendingRetry, retryDelay);
        retryDelay = Math.min(RETRY_MAX_MS, retryDelay * 2);
    }

    private void cancelRetry() {
        if (pendingRetry != null) {
            ui.removeCallbacks(pendingRetry);
            pendingRetry = null;
        }
    }

    // ====================================================================== //
    //  The live app                                                          //
    // ====================================================================== //
    private void connectTo(String url) {
        cancelRetry();
        android.util.Log.i("N3XUS", "connectTo " + url);
        retryDelay = RETRY_FIRST_MS;
        retryQueue.clear();
        // A page that loads again proves the server is there: start the backoff fresh.
        failedRounds = 0;
        for (String candidate : collectKnown()) {
            if (!candidate.equals(url)) retryQueue.add(candidate);
        }
        setLight(COLOR_YELLOW, "Connecting...");
        showWebView(url);
        // If the page does not come up, this fires: a blank yellow screen is never
        // left standing while the phone is, in fact, not connected.
        final String watchdogUrl = url;
        ui.postDelayed(() -> {
            if (destroyed || currentUrl == null || !watchdogUrl.equals(currentUrl)) return;
            if (webView == null || webView.getParent() == null) return;
            if (COLOR_YELLOW != currentLight) return;      // already settled
            handleLoadFailure("timeout");
        }, 12000);
    }

    /** The colour currently shown, so callers can tell a settled light from a pending one. */
    private int currentLight = COLOR_RED;

    /** Addresses already known (no sweep), used when a live page stops answering. */
    private List<String> collectKnown() {
        Set<String> ordered = new LinkedHashSet<>();
        String saved = normaliseAddress(prefs.getString("server_url", ""));
        if (saved != null) ordered.add(saved);
        for (String host : FALLBACK_HOSTS) {
            String url = normaliseAddress(host);
            if (url != null) ordered.add(url);
        }
        return new ArrayList<>(ordered);
    }

    /**
     * The background monitor found the server again (or found it for the first
     * time on another network). Called on the main thread.
     */
    static void onMonitorResult(boolean healthy) {
        MainActivity activity = current;
        if (activity == null) return;
        activity.ui.post(() -> {
            if (activity.destroyed) return;
            if (healthy) {
                activity.setLight(COLOR_GREEN, "Connected");
                if (activity.webView == null || activity.webView.getParent() == null) {
                    String url = activity.prefs.getString("server_url", "");
                    if (url != null && !url.isEmpty()) activity.connectTo(url);
                }
            } else {
                activity.setLight(COLOR_RED, "Not connected. Retrying...");
            }
        });
    }

    /** The monitor lost the server: say so at once, wherever the app is. */
    static void onMonitorLost() {
        MainActivity activity = current;
        if (activity == null) return;
        activity.ui.post(() -> {
            if (activity.destroyed) return;
            activity.setLight(COLOR_RED, "Not connected. Retrying...");
            if (activity.webView != null && activity.webView.getParent() != null) {
                activity.showSplashAgain();
            }
        });
    }

    /** Called by OpsService on the main thread; asks the live page to run its JS tick. */
    public static void tickWebView() {
        WebView w = activeWebView;
        if (w != null) w.evaluateJavascript("window.brNativeTick&&window.brNativeTick()", null);
    }

    private void showWebView(String url) {
        // Reuse the WebView across a reconnect so the session (cookies, login)
        // survives a Wi-Fi drop: only the address changes, not the browser.
        if (webView == null) {
            webView = new WebView(this);
            configureWebView(webView);
        }
        activeWebView = webView;
        boolean pageAlreadyLive = Boolean.TRUE.equals(webView.getTag(PAGE_LOADED_TAG));
        String previousUrl = currentUrl;
        currentUrl = url;
        currentLoadFailed = false;
        // A live page for this same server: reconnect the page, do not re-fetch
        // it. Re-fetching from the network on every connect tick is what made the
        // app reload itself in a loop and never settle.
        if (pageAlreadyLive && previousUrl != null && previousUrl.equals(url)) {
            OpsService.start(this);
            webView.reload();
            return;
        }
        // The splash is an overlay ON the WebView, never a replacement for it.
        // Detaching a WebView and re-attaching it later leaves a blank page on
        // Android; adding and removing an overlay does not. And a view can only
        // have one parent, so the overlay is re-parented explicitly, never added
        // twice (which crashed the app).
        FrameLayout host = this.host;
        if (host == null) {
            host = new FrameLayout(this);
            this.host = host;
            setContentView(host);
        }
        if (webView.getParent() != host) {
            if (webView.getParent() instanceof android.view.ViewGroup) {
                ((android.view.ViewGroup) webView.getParent()).removeView(webView);
            }
            // The page sits UNDER the overlay, whatever order things arrived in.
            host.addView(webView, 0, new FrameLayout.LayoutParams(-1, -1));
        }
        if (splash != null && splash.getParent() != host) {
            if (splash.getParent() instanceof android.view.ViewGroup) {
                ((android.view.ViewGroup) splash.getParent()).removeView(splash);
            }
            host.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        }
        if (splash != null && splash.getParent() == null) {
            // First start only: the splash is shown before a page exists. After
            // that it is a GONE overlay on the host, so leave its visibility to
            // onPageFinished (a recycled activity keeps the page it already had).
            showSplash();
        }
        OpsService.start(this);
        // Tell the page which APK is really installed, so it never offers an update
        // it already has. The address we remember stays clean (no query string).
        String installed = installedVersion();
        String withVersion = installed.isEmpty() ? url
                : url + (url.contains("?") ? "&" : "?") + "appv=" + Uri.encode(installed);
        // The page is fetched here, with the app's trust, and then handed to the
        // WebView as data at the page's own address. Chromium would otherwise
        // fetch it itself and refuse the server's certificate (net_error -202),
        // which is why the app could be green and still show a blank page.
        final String pageUrl = url;
        final String loadTarget = withVersion;
        new Thread(() -> {
            String html = null;
            String base = null;
            try {
                java.net.URL target = new java.net.URL(loadTarget);
                javax.net.ssl.HttpsURLConnection connection =
                        N3xusTrust.open(this, target, N3xusTrust.isPrivateHost(target.toString()));
                if (connection == null) connection = (javax.net.ssl.HttpsURLConnection) target.openConnection();
                connection.setConnectTimeout(PAGE_TIMEOUT_MS);
                connection.setReadTimeout(PAGE_TIMEOUT_MS);
                connection.setRequestProperty("Accept", "text/html,application/xhtml+xml");
                connection.setRequestProperty("User-Agent", userAgent());
                String cookie = CookieManager.getInstance().getCookie(loadTarget);
                if (cookie != null && !cookie.isEmpty()) connection.setRequestProperty("Cookie", cookie);
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 400) {
                    html = readAll(connection.getInputStream());
                    base = connection.getURL().toString();
                }
            } catch (Exception ignored) {
                html = null;
            }
            final String page = html;
            final String pageBase = base;
            runOnUiThread(() -> {
                if (destroyed) return;
                if (page != null && !page.trim().isEmpty()) {
                    // Load the page as the server served it. Its scripts are what
                    // check the login state and swap in the login screen, so they
                    // must run - an app that strips scripts shows an empty shell.
                    webView.getSettings().setJavaScriptEnabled(true);
                    webView.getSettings().setDomStorageEnabled(true);
                    webView.setTag(PAGE_LOADED_TAG, Boolean.TRUE);
                    webView.loadDataWithBaseURL(pageBase == null ? pageUrl : pageBase,
                            injectPageHelpers(page), "text/html", "utf-8", null);
                } else {
                    // Fetch failed here: let Chromium try the address itself.
                    webView.loadUrl(loadTarget);
                }
            });
        }, "n3xus-page").start();
    }

    /** The content type for a path, for responses the server did not label. */
    private static String guessMime(String path) {
        String lower = path == null ? "" : path.toLowerCase();
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "application/javascript";
        if (lower.endsWith(".json") || lower.endsWith(".webmanifest")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".ttf")) return "font/ttf";
        if (lower.endsWith(".ico")) return "image/x-icon";
        if (lower.endsWith(".mp3")) return "audio/mpeg";
        if (lower.endsWith(".wav")) return "audio/wav";
        if (lower.endsWith(".mp4")) return "video/mp4";
        return "application/octet-stream";
    }

    /** Read a whole response body as UTF-8 text. */
    private static String readAll(java.io.InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
        in.close();
        return new String(out.toByteArray(), "utf-8");
    }

    /**
     * One way to open every connection to the server, so no call site can forget
     * the trust again.
     *
     * https:// to this machine gets N3xusTrust's socket factory, so the desktop's
     * own self-signed certificate (YOUR_LAN_SUBNET.x, 10.x, *.local) is accepted exactly
     * as the server presents it. Everything else - a public *.trycloudflare.com
     * address, a duckdns name, or a plain http:// address - gets an ordinary
     * connection and therefore needs a real, publicly trusted certificate. Nothing
     * is weakened: hostnames are still verified, and only the certificate shipped
     * inside the app is added to the trust.
     */
    private HttpURLConnection openTrusted(URL url) throws java.io.IOException {
        if (url != null && "https".equalsIgnoreCase(url.getProtocol())) {
            javax.net.ssl.HttpsURLConnection trusted = N3xusTrust.open(this, url, N3xusTrust.isPrivateHost(url.toString()));
            if (trusted != null) return trusted;
        }
        return (HttpURLConnection) url.openConnection();
    }

    /**
     * Adds two things to the page the server sent, without changing its own scripts:
     *  1. A toast, so the app can say out loud why a sign-in did not happen. Silent
     *     failures on a phone are the worst kind: nobody knows whether it is broken
     *     or they typed something wrong.
     *  2. A keep-clear strip at the bottom while a keyboard is open, so the keyboard
     *     can never cover the button the person needs to press next.
     */
    private String injectPageHelpers(String html) {
        String script = "<script>(function(){"
            + "if(window.__n3xusToast)return;window.__n3xusToast=true;"
            + "window.brToast=function(m){try{var d=document.createElement('div');"
            + "d.textContent=String(m);d.style.cssText='position:fixed;left:12px;right:12px;bottom:24px;z-index:2147483647;"
            + "background:#12203a;color:#fff;border:1px solid #2f4a7a;border-radius:12px;padding:12px 14px;"
            + "font:14px/1.35 system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.45)';"
            + "document.body.appendChild(d);setTimeout(function(){d.remove()},3600)}catch(e){}};"
            + "var realFetch=window.fetch?window.fetch.bind(window):null;"
            + "window.fetch=function(input,init){"
            + "try{var url=typeof input==='string'?input:(input&&input.url)||'';"
            + "var abs=new URL(url,location.href);"
            + "if(abs.protocol==='https:'&&window.N3XUS&&window.N3XUS.call){"
            + "var o=init||{};var body=o.body==null?'':(typeof o.body==='string'?o.body:'');"
            + "var m=(o.method||'GET').toUpperCase();"
            + "return window.N3XUS.call(abs.href,m,body).then(function(raw){"
            + "var st=200;try{st=window.N3XUS.lastStatus()}catch(e){}"
            + "return new Response(raw,{status:st,headers:{'Content-Type':'application/json'}})});"
            + "}}catch(e){}"
            + "return realFetch?realFetch(input,init):Promise.reject(new Error('No fetch'));};"
            + "window.addEventListener('error',function(e){try{window.brToast('App error: '+(e.message||'unknown'))}catch(x){}});"
            + "window.addEventListener('unhandledrejection',function(e){try{window.brToast('App error: '+((e.reason&&e.reason.message)||e.reason||'unknown'))}catch(x){}});"
            + "function fit(){var h=(window.visualViewport?window.visualViewport.height:window.innerHeight);"
            + "var k=Math.max(0,window.innerHeight-h);"
            + "document.documentElement.style.setProperty('--kb',k+'px');"
            + "document.body.style.paddingBottom=(k?k+96:0)+'px';}"
            + "function reveal(){var a=document.activeElement;"
            + "if(a&&(a.tagName==='INPUT'||a.tagName==='SELECT'||a.tagName==='TEXTAREA')){"
            + "try{a.scrollIntoView({block:'center',behavior:'smooth'})}catch(e){}}}"
            + "document.addEventListener('focusin',function(){setTimeout(reveal,120);setTimeout(reveal,450)});"
            + "document.addEventListener('click',function(){setTimeout(reveal,250)});"
            + "if(window.visualViewport){window.visualViewport.addEventListener('resize',fit);window.visualViewport.addEventListener('scroll',fit);}"
            + "window.addEventListener('resize',fit);setTimeout(fit,50);setTimeout(fit,400);"
            + "})();</script>";
        int idx = html.toLowerCase().lastIndexOf("</body>");
        if (idx < 0) return html + script;
        return html.substring(0, idx) + script + html.substring(idx);
    }

    /**
     * The app's own way for the page to talk to the server. Chromium cannot be given
     * this server's certificate and cannot carry the body of a POST, so a request the
     * page makes itself - a sign-in, a saved form, a list - is made here instead, on a
     * background thread, with the same trust the connection test uses. The reply is
     * returned to the page unchanged, and a failure is returned as a failure the page
     * can show, never as silence.
     */
    private class ServerBridge {
        private volatile int lastCode = 200;

        /** The status the last call came back with, for the page to judge. */
        @JavascriptInterface
        public int lastStatus() {
            return lastCode;
        }

        /**
         * The page tells the app what it can see of the connection, and the app
         * makes that the single truth for every indicator: the status-bar dot in
         * the persistent notification and the 1x1 home-screen widget both repaint
         * from it, so they can never disagree with the screen in front of you.
         *
         *   "connected"    the server answered
         *   "reconnecting" the request failed or is still going
         *   "offline"      the phone has no network at all
         */
        @JavascriptInterface
        public void setStatus(String state) {
            String mapped = AppIcon.GREEN;
            if ("offline".equals(state)) mapped = AppIcon.RED;
            else if ("reconnecting".equals(state)) mapped = AppIcon.YELLOW;
            final String next = mapped;
            runOnUiThread(() -> {
                try { AppIcon.set(MainActivity.this, next); } catch (Exception ignored) { }
            });
        }

        /** What the indicators are showing right now, for the page to match. */
        @JavascriptInterface
        public String getStatus() {
            try { return AppIcon.state(MainActivity.this); } catch (Exception e) { return AppIcon.RED; }
        }

        @JavascriptInterface
        public String call(String target, String method, String body) {
            lastCode = 200;
            try {
                if (target == null || !target.startsWith("https://")) {
                    return "{\"error\":\"Only the N3XUS server can be reached.\"}";
                }
                java.net.URL url = new java.net.URL(target);
                String host = url.getHost();
                if (host == null || host.isEmpty() || host.startsWith("www.")) {
                    if (host == null || host.isEmpty()) {
                        return "{\"error\":\"Bad address.\"}";
                    }
                    url = new java.net.URL("https://" + host.substring(4) + url.getFile());
                }
                if (!(isPrivateLanHost(url.toString()) || host.endsWith(".trycloudflare.com")
                        || host.equals("your-userd-dean.duckdns.org"))) {
                    return "{\"error\":\"Only the N3XUS server can be reached.\"}";
                }
                HttpURLConnection connection = openTrusted(url);
                connection.setConnectTimeout(PAGE_TIMEOUT_MS);
                connection.setReadTimeout(PAGE_TIMEOUT_MS);
                connection.setRequestProperty("Accept", "application/json, text/plain, */*");
                connection.setRequestProperty("User-Agent", userAgent());
                connection.setRequestProperty("Content-Type", "application/json");
                String cookie = CookieManager.getInstance().getCookie(url.toString());
                if (cookie != null && !cookie.isEmpty()) {
                    connection.setRequestProperty("Cookie", cookie);
                }
                String verb = method == null ? "GET" : method.toUpperCase(java.util.Locale.ROOT);
                if (!"GET".equals(verb)) {
                    connection.setRequestMethod(verb);
                    connection.setDoOutput(true);
                    if (body != null && !body.isEmpty()) {
                        java.io.OutputStream out = connection.getOutputStream();
                        out.write(body.getBytes("UTF-8"));
                        out.flush();
                        out.close();
                    }
                }
                int code = connection.getResponseCode();
                java.io.InputStream in = code >= 400
                        ? connection.getErrorStream() : connection.getInputStream();
                String text = in == null ? "" : readAll(in);
                // A cookie the server set has to be kept, or the next call is a stranger.
                java.util.List<String> setCookie = connection.getHeaderFields().get("Set-Cookie");
                if (setCookie != null) {
                    for (String one : setCookie) CookieManager.getInstance().setCookie(url.toString(), one);
                }
                if (text == null || text.trim().isEmpty()) {
                    text = code >= 400 ? "{\"error\":\"The server refused this request (" + code + ").\"}"
                                       : "{}";
                }
                if (code >= 400 && !text.trim().startsWith("{")) {
                    text = "{\"error\":" + JSONObject.quote(text) + "}";
                }
                lastCode = code;
                android.util.Log.i("N3XUS", "bridge " + verb + " " + url + " -> " + code);
                return text;
            } catch (Exception e) {
                String reason = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                android.util.Log.e("N3XUS", "bridge failed: " + target + " : " + reason, e);
                lastCode = 503;
                return "{\"error\":" + JSONObject.quote("Could not reach the server: " + reason) + "}";
            }
        }
    }

    /**
     * Fingerprint and face, straight from the phone.
     *
     * The page cannot use the browser's own unlock here: it needs a certificate
     * this phone does not trust, so the browser reports no fingerprint or face at
     * all. This bridge asks Android itself instead - the fingerprint sensor, or
     * the face the phone already knows - and tells the page only "yes" or "no".
     * Nothing about the finger or the face ever leaves the phone, and no service,
     * key or subscription is involved.
     */
    private class BiometricBridge {
        @JavascriptInterface
        public boolean available() {
            try {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return false;
                android.hardware.biometrics.BiometricManager manager =
                        getSystemService(android.hardware.biometrics.BiometricManager.class);
                if (manager == null) return false;
                // 0x0F = a strong fingerprint or face; 0xFF = anything the phone offers.
                int allowed = 0x0F | 0xFF;
                return manager.canAuthenticate(allowed)
                        == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        /** Blocks this call only, on a background thread, until the person answers. */
        @JavascriptInterface
        public boolean ask() {
            if (!available()) return false;
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            final java.util.concurrent.atomic.AtomicBoolean ok =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            ui.post(() -> {
                try {
                    android.hardware.biometrics.BiometricPrompt.Builder builder =
                            new android.hardware.biometrics.BiometricPrompt.Builder(MainActivity.this)
                                    .setTitle("N3XUS sign in")
                                    .setSubtitle("Use your fingerprint or face")
                                    .setNegativeButton("Use password", getMainExecutor(),
                                            (dialog, which) -> done.countDown());
                    builder.build().authenticate(new android.os.CancellationSignal(), getMainExecutor(),
                            new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                                @Override public void onAuthenticationSucceeded(
                                        android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                                    ok.set(true);
                                    done.countDown();
                                }
                                @Override public void onAuthenticationError(int code, CharSequence message) {
                                    done.countDown();
                                }
                                @Override public void onAuthenticationFailed() {
                                    // A finger that is not recognised: the prompt stays up.
                                }
                            });
                } catch (Exception e) {
                    done.countDown();
                }
            });
            try {
                done.await(90, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException ignored) { }
            return ok.get();
        }
    }

    /** The app's own user agent, for the page fetch. */
    private String userAgent() {
        try { return android.webkit.WebSettings.getDefaultUserAgent(this); }
        catch (Exception e) { return "N3XUS-Android"; }
    }

    private void configureWebView(WebView view) {
        view.setBackgroundColor(COLOR_BG);
        // DevTools over adb: `adb forward tcp:9222 localabstract:webview_devtools_remote_<pid>`
        // then read the page's console. Without it a blank page is a guess; with it
        // the actual JavaScript error is one curl away.
        try { WebView.setWebContentsDebuggingEnabled(true); } catch (Exception ignored) { }
        // Never serve a stale broken script: the page changes between launches, and
        // a cached copy is what makes a fix look like it did nothing.
        try { view.clearCache(true); } catch (Exception ignored) { }
        view.getSettings().setJavaScriptEnabled(true);
        view.getSettings().setGeolocationEnabled(true);
        view.getSettings().setDomStorageEnabled(true);
        view.getSettings().setAllowFileAccess(false);
        view.getSettings().setMediaPlaybackRequiresUserGesture(true);
        // Generic Bluetooth vitals reader (any band, watch or chest strap).
        // Attached, but NOT requested here: a permission dialog over the login
        // screen is a wall a caregiver has to clear before the app is usable.
        // The page asks when it needs the reader (window.brRequestVitals).
        VitalsBle.attach(view);
        // Downloads (certificates, documents): hand the file to the system DownloadManager
        // so a PDF lands in Downloads instead of being rendered (blank) inside the WebView.
        view.setDownloadListener((rawUrl, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                if (rawUrl == null) return;
                Uri target = Uri.parse(rawUrl);
                String scheme = target.getScheme();
                if (scheme == null) return;
                if ("http".equals(scheme) && !isPrivateLanHost(rawUrl)) return;
                if (!"http".equals(scheme) && !"https".equals(scheme)) return;
                String name = URLUtil.guessFileName(rawUrl, contentDisposition, mimeType);
                if (name == null || name.trim().isEmpty()) name = "N3XUS-download";
                DownloadManager.Request request = new DownloadManager.Request(target);
                if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
                request.setTitle(name);
                request.setDescription("N3XUS download");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                String cookie = CookieManager.getInstance().getCookie(rawUrl);
                if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
                if (userAgent != null && !userAgent.isEmpty()) request.addRequestHeader("User-Agent", userAgent);
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (manager != null) {
                    manager.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Downloading " + name, Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Download failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        // The page itself is fetched by Chromium's network stack, which does not
        // use the trust set up in N3xusTrust. A handler of our own fetches the
        // page with that trust and hands the HTML to the WebView, so the server's
        // own certificate is accepted exactly as it is by the probes. Only the
        // first document goes this way; everything it then loads (scripts,
        // styles, API calls) uses the session cookie this fetch establishes.
        view.addJavascriptInterface(new ServerBridge(), "N3XUS");
        view.addJavascriptInterface(new BiometricBridge(), "N3XUS_BIO");
        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request) {
                // Chromium refuses this server's certificate (net_error -202), so every
                // request to it - the page, its styles, its scripts, its icons - is
                // fetched here with the trust set up in N3xusTrust and handed back.
                // Without this the app showed a bare, unstyled fragment of the page.
                try {
                    if (request == null) return null;
                    String target = request.getUrl().toString();
                    // "www." is added by the page's own fetch; it is the same server.
                    if (target.startsWith("https://www.")) {
                        target = "https://" + target.substring("https://www.".length());
                    }
                    if (!target.startsWith("https://")) return null;
                    java.net.URL url = new java.net.URL(target);
                    String host = url.getHost();
                    if (host == null || host.isEmpty()) return null;
                    // Only the N3XUS server, never the wider internet.
                    boolean lan = isPrivateLanHost(target) || host.endsWith(".trycloudflare.com")
                            || host.equals("your-userd-dean.duckdns.org");
                    if (!lan) return null;
                    HttpURLConnection connection = openTrusted(url);
                    connection.setConnectTimeout(PAGE_TIMEOUT_MS);
                    connection.setReadTimeout(PAGE_TIMEOUT_MS);
                    connection.setRequestProperty("Accept", "*/*");
                    connection.setRequestProperty("User-Agent", userAgent());
                    String method = request.getMethod();
                    if (method != null && !"GET".equalsIgnoreCase(method)) {
                        connection.setRequestMethod(method.toUpperCase(java.util.Locale.ROOT));
                        connection.setDoOutput(true);
                    }
                    String cookie = CookieManager.getInstance().getCookie(target);
                    if (cookie != null && !cookie.isEmpty()) connection.setRequestProperty("Cookie", cookie);
                    int code = connection.getResponseCode();
                    String contentType = connection.getContentType();
                    String mime = "text/html";
                    String charset = "utf-8";
                    if (contentType != null) {
                        String[] parts = contentType.split(";");
                        mime = parts[0].trim();
                        for (int i = 1; i < parts.length; i++) {
                            String part = parts[i].trim();
                            if (part.toLowerCase().startsWith("charset=")) {
                                charset = part.substring(8).trim();
                            }
                        }
                    }
                    if (mime.isEmpty()) mime = guessMime(url.getPath());
                    java.io.ByteArrayOutputStream reply = new java.io.ByteArrayOutputStream();
                    java.io.InputStream in = connection.getInputStream();
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = in.read(buffer)) > 0) reply.write(buffer, 0, read);
                    in.close();
                    java.util.Map<String, String> headers = new java.util.HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("Access-Control-Allow-Origin", "*");
                    headers.put("Access-Control-Allow-Credentials", "true");
                    return new WebResourceResponse(mime, charset, code, "OK", headers,
                            new java.io.ByteArrayInputStream(reply.toByteArray()));
                } catch (Exception e) {
                    // Say so plainly instead of handing the request back to Chromium,
                    // which would refuse the certificate and report nothing useful.
                    java.util.Map<String, String> headers = new java.util.HashMap<>();
                    headers.put("Access-Control-Allow-Origin", "*");
                    headers.put("Access-Control-Allow-Credentials", "true");
                    headers.put("Cache-Control", "no-store");
                    return new WebResourceResponse("text/plain", "utf-8", 503,
                            "Server unreachable", headers,
                            new java.io.ByteArrayInputStream("{}".getBytes()));
                }
            }

            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if ("https".equals(scheme)) return false;
                if ("http".equals(scheme)) return !isPrivateLanHost(request.getUrl().toString());
                return true;
            }

            @Override public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request == null || !request.isForMainFrame()) return;
                CharSequence description = error == null ? "" : error.getDescription();
                handleLoadFailure(description == null ? "" : description.toString());
            }

            @Override public void onReceivedHttpError(WebView v, WebResourceRequest request, WebResourceResponse response) {
                if (request == null || !request.isForMainFrame() || response == null) return;
                if (response.getStatusCode() >= 400) handleLoadFailure("HTTP " + response.getStatusCode());
            }

            @Override public void onPageStarted(WebView v, String loadedUrl, android.graphics.Bitmap favicon) {
                setLight(COLOR_YELLOW, "Connecting...");
            }

            @Override public void onPageFinished(WebView v, String loadedUrl) {
                if (currentLoadFailed) return;
                // Remember the address we chose (not the followed redirect target) so the
                // saved value stays a clean .../mobile/ root for the next launch.
                if (currentUrl != null && currentUrl.startsWith("http")) {
                    prefs.edit().putString("server_url", currentUrl).apply();
                    rememberPublicUrl(currentUrl);
                }
                retryDelay = RETRY_FIRST_MS;
                setDetail("");
                setLight(COLOR_GREEN, "Connected");
                // The page has arrived: swap the splash for it. The light stays on
                // in the app's notification, and the splash comes back the moment
                // the connection is lost.
                hideSplash();
                maybeAutoUpdate();
            }
        });
        view.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
            /**
             * Without this override Android's WebView refuses every getUserMedia()
             * call silently - no prompt, just NotAllowedError - so VOIC3 could ring
             * but never carry audio. The app asks the system for the matching
             * runtime permission and only then grants the page's request.
             */
            @Override public void onPermissionRequest(final android.webkit.PermissionRequest request) {
                final java.util.List<String> wanted = new java.util.ArrayList<>();
                boolean needsRuntime = false;
                for (String res : request.getResources()) {
                    if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                        wanted.add(res);
                        if (!hasPermission(android.Manifest.permission.RECORD_AUDIO)) needsRuntime = true;
                    } else if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) {
                        wanted.add(res);
                        if (!hasPermission(android.Manifest.permission.CAMERA)) needsRuntime = true;
                    }
                }
                if (wanted.isEmpty()) { request.deny(); return; }
                Runnable grant = () -> {
                    boolean audioOk = !wanted.contains(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                            || hasPermission(android.Manifest.permission.RECORD_AUDIO);
                    boolean videoOk = !wanted.contains(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                            || hasPermission(android.Manifest.permission.CAMERA);
                    if (audioOk && videoOk) request.grant(wanted.toArray(new String[0]));
                    else request.deny();
                };
                if (!needsRuntime) { grant.run(); return; }
                java.util.List<String> ask = new java.util.ArrayList<>();
                if (!hasPermission(android.Manifest.permission.RECORD_AUDIO)) ask.add(android.Manifest.permission.RECORD_AUDIO);
                if (!hasPermission(android.Manifest.permission.CAMERA)) ask.add(android.Manifest.permission.CAMERA);
                if (ask.isEmpty()) { grant.run(); return; }
                pendingMediaGrant = grant;
                MainActivity.this.requestPermissions(ask.toArray(new String[0]), REQ_MEDIA);
            }

            @Override public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                Uri requested = Uri.parse(origin);
                Uri configured = Uri.parse(prefs.getString("server_url", ""));
                boolean trustedOrigin = requested.getHost() != null
                        && requested.getHost().equalsIgnoreCase(configured.getHost())
                        && effectivePort(requested) == effectivePort(configured)
                        && ("https".equalsIgnoreCase(requested.getScheme()) || isPrivateLanHost(requested.toString()));
                if (!trustedOrigin) { callback.invoke(origin, false, false); return; }
                if (Build.VERSION.SDK_INT < 23 || (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    callback.invoke(origin, true, false); return;
                }
                geoCallback = callback;
                geoOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST);
            }
        });
    }

    /**
     * The live page stopped answering. Walk the known addresses quietly; when
     * none answers, go back to the splash with a red light and keep retrying.
     */
    private void handleLoadFailure(String reason) {
        // A 502/503 means the tunnel is up but the server behind it is not answering
        // yet (it restarts, it is busy, cloudflared has no origin). That is a "wait
        // and ask again", not an address to cross off: retrying the same address is
        // what turns a transient blip into a permanent red screen.
        boolean transientFailure = reason != null && (reason.contains("502") || reason.contains("503")
                || reason.contains("504") || reason.contains("timeout"));
        if (currentLoadFailed) return;
        currentLoadFailed = true;
        if (!retryQueue.isEmpty()) {
            final String next = retryQueue.remove(0);
            if (next.equals(currentUrl)) {
                currentLoadFailed = false;
                handleLoadFailure(reason);
                return;
            }
            currentUrl = next;
            currentLoadFailed = false;
            ui.postDelayed(() -> {
                if (webView == null || destroyed) return;
                showWebView(next);
            }, 400);
            return;
        }
        if (transientFailure && currentUrl != null) {
            // The address is good; give it one more turn before falling back to the
            // splash, so a 503 never lands the phone on a blank page.
            currentLoadFailed = false;
            showSplashAgain();
            scheduleRetry();
            return;
        }
        showSplashAgain();
        scheduleRetry();
    }

    /** Accepts "1.2.3.4:port", "http://host", "host/mobile/" and returns a usable mobile URL, or null. */
    private String normaliseAddress(String raw) {
        if (raw == null) return null;
        String url = raw.trim();
        if (url.isEmpty()) return null;
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }
        if (url.startsWith("http://") && !isPrivateLanHost(url) && !url.contains("duckdns.org")) return null;
        if (!url.endsWith("/")) url += "/";
        if (!url.endsWith("/mobile/")) {
            if (url.endsWith("/mobile")) url += "/";
            else url += "mobile/";
        }
        return url;
    }

    private boolean isPrivateLanHost(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase();
            if (host.equals("localhost") || host.endsWith(".local") || host.endsWith(".lan")) return true;
            String[] p = host.split("\\.");
            if (p.length != 4) return false;
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
            if (a == 10) return true;
            if (a == 192 && b == 168) return true;
            if (a == 172 && b >= 16 && b <= 31) return true;
            if (a == 127) return true;
            return false;
        } catch (Exception e) { return false; }
    }

    private int effectivePort(Uri uri) {
        return uri.getPort() >= 0 ? uri.getPort() : ("https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80);
    }

    // ====================================================================== //
    //  Auto-update: a new build installs itself, nobody taps "update".      //
    // ====================================================================== //
    private long lastUpdateCheck;
    private boolean updateInProgress;

    /**
     * Runs on every successful page load, at most once every ten minutes. The
     * server publishes its current version at /api/mobile/app-version; when that
     * versionCode is higher than the installed one, the new APK is downloaded and
     * the system installer is opened straight away. No button, no prompt in the
     * normal path: the app updates itself the first time it reaches the server
     * after a new build, and the page reloads onto the new build.
     */
    private void maybeAutoUpdate() {
        if (updateInProgress) return;
        long now = System.currentTimeMillis();
        if (now - lastUpdateCheck < 10L * 60L * 1000L) return;
        lastUpdateCheck = now;
        final String base = currentUrl == null ? null : currentUrl.replace("/mobile/", "/");
        if (base == null) return;
        new Thread(() -> {
            try {
                URL url = new URL(base + "api/mobile/app-version");
                HttpURLConnection connection = openTrusted(url);
                connection.setConnectTimeout(PROBE_TIMEOUT_MS);
                connection.setReadTimeout(PROBE_TIMEOUT_MS);
                InputStream in = connection.getInputStream();
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] chunk = new byte[2048];
                int read;
                while ((read = in.read(chunk)) > 0 && buffer.size() < 16384) buffer.write(chunk, 0, read);
                in.close();
                connection.disconnect();
                org.json.JSONObject info = new org.json.JSONObject(buffer.toString("UTF-8"));
                int remote = info.optInt("version_code", 0);
                int local = installedVersionCode();
                boolean available = info.optBoolean("apk_available", false);
                String apkUrl = info.optString("apk_url", "");
                if (!available || remote <= local || apkUrl.isEmpty()) return;
                ui.post(() -> downloadAndInstall(base + (apkUrl.startsWith("/") ? apkUrl.substring(1) : apkUrl)));
            } catch (Exception ignored) {
                // Offline, or the server is an older build: try again on a later load.
            }
        }, "n3xus-update-check").start();
    }

    /** Downloads the new APK through DownloadManager, then opens the installer. */
    private void downloadAndInstall(String apkUrl) {
        if (updateInProgress || destroyed) return;
        updateInProgress = true;
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
            request.setMimeType("application/vnd.android.package-archive");
            request.setTitle("N3XUS update");
            request.setDescription("Installing the new N3XUS build");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "nexus-update.apk");
            String cookie = CookieManager.getInstance().getCookie(apkUrl);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            final DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (manager == null) { updateInProgress = false; return; }
            final long id = manager.enqueue(request);

            Toast.makeText(this, "Updating N3XUS...", Toast.LENGTH_SHORT).show();
            final android.content.BroadcastReceiver done = new android.content.BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) {
                    if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                    try { unregisterReceiver(this); } catch (Exception ignored) { }
                    try {
                        Uri apk = manager.getUriForDownloadedFile(id);
                        if (apk == null) { updateInProgress = false; return; }
                        Intent install = new Intent(Intent.ACTION_VIEW);
                        install.setDataAndType(apk, "application/vnd.android.package-archive");
                        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(install);
                    } catch (Exception e) {
                        updateInProgress = false;
                    }
                }
            };
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(done, new android.content.IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                        Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(done, new android.content.IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
            }
        } catch (Exception e) {
            updateInProgress = false;
        }
    }

    /** versionCode of the APK running on this phone; 0 when it cannot be read. */
    @SuppressWarnings("deprecation")
    private int installedVersionCode() {
        try {
            android.content.pm.PackageInfo info =
                    getPackageManager().getPackageInfo(getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28
                    ? (int) info.getLongVersionCode()
                    : info.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    /** versionName of the APK actually running on this phone, e.g. "5.2.7". */
    private String installedVersion() {
        try {
            return String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
        } catch (Exception e) {
            return "";
        }
    }

    /** True when the user has already granted a runtime permission. */
    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA) {
            Runnable pending = pendingMediaGrant;
            pendingMediaGrant = null;
            if (pending != null) pending.run();
            return;
        }
        if (requestCode == LOCATION_REQUEST && geoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            geoCallback.invoke(geoOrigin, granted, false);
            geoCallback = null;
            geoOrigin = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    /** Back out of the app the usual way; a page with history goes back one page. */
    @Override public void onBackPressed() {
        if (webView != null && webView.getParent() != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    /** Waking the phone after a sleep is exactly when a dropped link should mend itself. */
    @Override protected void onResume() {
        super.onResume();
        current = this;
        N3xusMonitor.get(this).setAppVisible(true);
        if (webView != null && webView.getParent() != null && currentUrl != null
                && splash != null && splash.getVisibility() != View.VISIBLE) {
            // The page is on screen, which says nothing about right now. Ask the
            // server, and let the answer set the light. Amber until it replies.
            setLight(COLOR_YELLOW, "Checking...");
            N3xusMonitor.get(this).checkNow();
            recheckSoon(2500);
        } else if (pendingRetry == null) {
            autoConnect();
        }
    }

    /** Says something inside the page that is on screen, if it can. */
    private void toastToPage(String message) {
        if (webView == null || webView.getParent() == null) return;
        String js = "try{window.brToast&&window.brToast(" + JSONObject.quote(message) + ")}catch(e){}";
        try { webView.evaluateJavascript(js, null); } catch (Exception ignored) { }
    }

    /** One extra check shortly after waking, so the light is current within seconds. */
    private void recheckSoon(long delayMs) {
        ui.postDelayed(() -> {
            if (!destroyed) N3xusMonitor.get(this).checkNow();
        }, delayMs);
    }

    /** After an update installed by the app itself: reload onto the new build. */
    /**
     * An address from a launch intent (`-e server <url>`) or a deep link
     * (ACTION_VIEW <url>). It is remembered as the address to use, so the app never
     * has to guess afterwards - this is the "just open THIS server" path.
     */
    private void adoptLaunchAddress(Intent intent) {
        if (intent == null) return;
        String candidate = null;
        try {
            String extra = intent.getStringExtra("server");
            if (extra == null) extra = intent.getStringExtra("server_url");
            if (extra != null) candidate = extra;
            if (candidate == null && intent.getDataString() != null) candidate = intent.getDataString();
        } catch (Exception ignored) {
            // A malformed intent simply means "no address given".
        }
        String clean = normaliseAddress(candidate);
        if (clean == null) return;
        launchServerUrl = clean;
        prefs.edit().putString("server_url", clean).apply();
        rememberPublicUrl(clean);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getBooleanExtra("just_updated", false)) {
            updateInProgress = false;
            lastUpdateCheck = 0;
            if (currentUrl != null) showWebView(currentUrl);
            return;
        }
        adoptLaunchAddress(intent);
        if (launchServerUrl != null) autoConnect();
    }

    @Override protected void onPause() {
        super.onPause();
        N3xusMonitor.get(this).setAppVisible(false);
    }

    @Override protected void onDestroy() {
        destroyed = true;
        if (current == this) current = null;
        connectRound++;
        cancelRetry();
        if (activeWebView == webView) activeWebView = null;
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.destroy();
            } catch (Exception ignored) { }
            webView = null;
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
