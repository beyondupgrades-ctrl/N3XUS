package za.co.your-userdregistration.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * NAVIQ operations foreground service.
 * Keeps the app process alive and fires a native tick every 30 minutes.
 * The tick asks the live WebView (when present) to run its JS check-in /
 * location routines, so company-device check-ins keep working while the
 * app is in the background. When no WebView is alive the service simply
 * maintains the persistent notification — it never fabricates check-ins.
 */
public class OpsService extends Service {
    public static final String CHANNEL_ID = "br_ops";
    private static final int NOTIF_ID = 4201;
    private static final long TICK_MS = 30L * 60L * 1000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable tick;
    /** Rings incoming calls while the WebView is in the background (no Push API in WebView). */
    private CallEventListener events;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = buildNotification(AppIcon.state(this));
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIF_ID, n);
        tick = new Runnable() {
            @Override public void run() {
                MainActivity.tickWebView();
                handler.postDelayed(this, TICK_MS);
            }
        };
        handler.postDelayed(tick, 60_000L);
        events = new CallEventListener(this);
        events.start();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        if (events != null) events.stop();
        super.onDestroy();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Operations", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Keeps device check-ins and safety monitoring alive");
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String state) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(lightIcon(state))
                .setContentTitle(lightTitle(state))
                .setContentText(lightText(state))
                .setContentIntent(pi)
                .setColor(lightColour(AppIcon.state(this)))
                .setOngoing(true)
                .build();
    }

    /** The live indicator: red not connected, yellow connecting, green connected. */
    static int lightColour(String state) {
        if (AppIcon.GREEN.equals(state)) return android.graphics.Color.rgb(32, 201, 151);
        if (AppIcon.YELLOW.equals(state)) return android.graphics.Color.rgb(255, 193, 7);
        return android.graphics.Color.rgb(229, 57, 53);
    }

    /**
     * The small icon shown in the status bar. A solid dot, drawn by the system
     * from a shape - not a picture and not art. It is coloured by the state, so
     * the light in the status bar IS the connection: green while the server is
     * reachable, amber while connecting, red when it is not.
     */
    static int lightIcon(String state) {
        if (AppIcon.GREEN.equals(state)) return R.drawable.ic_dot_green;
        if (AppIcon.YELLOW.equals(state)) return R.drawable.ic_dot_amber;
        return R.drawable.ic_dot_red;
    }

    /** The notification title: says the state in words too, for colour-blind users. */
    static String lightTitle(String state) {
        if (AppIcon.GREEN.equals(state)) return "N3XUS - connected";
        if (AppIcon.YELLOW.equals(state)) return "N3XUS - connecting";
        return "N3XUS - NOT connected";
    }

    static String lightText(String state) {
        if (AppIcon.GREEN.equals(state)) return "Connected";
        if (AppIcon.YELLOW.equals(state)) return "Connecting...";
        return "Not connected - retrying";
    }

    /**
     * Repaint the notification from the remembered state. Called by AppIcon
     * whenever the connection changes, so the colour on the phone's status bar
     * is the real state, not a picture of one.
     */
    public static void repaint(Context ctx) {
        try {
            String state = AppIcon.state(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(ctx, CHANNEL_ID)
                    : new Notification.Builder(ctx);
            Intent open = new Intent(ctx, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            nm.notify(NOTIF_ID, b.setSmallIcon(lightIcon(state))
                    .setContentTitle(lightTitle(state))
                    .setContentText(lightText(state))
                    .setContentIntent(pi)
                    .setColor(lightColour(state))
                .setShowWhen(false)
                    .setOngoing(true)
                    .build());
        } catch (Exception ignored) {
            // No notification permission yet, or the service is not running.
        }
    }

    public static void start(Context ctx) {
        Intent i = new Intent(ctx, OpsService.class);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, OpsService.class));
    }
}
