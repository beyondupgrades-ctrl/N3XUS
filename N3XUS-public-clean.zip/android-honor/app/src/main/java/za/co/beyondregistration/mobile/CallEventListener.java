package za.co.your-userdregistration.mobile;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.CookieManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Keeps one server-sent-events connection to /api/voic3/events open from the
 * foreground OpsService, so an incoming VOIC3 call rings even when the WebView
 * is backgrounded, frozen or closed. Android System WebView has no Push API,
 * so before this a call only rang while the app was on screen.
 *
 * Free and local: the same N3XUS server, the same br_mobile session cookie the
 * WebView already holds, no push gateway, no account, no key.
 */
final class CallEventListener {
    private static final String TAG = "N3XUS-EVENTS";
    private static final int CONNECT_TIMEOUT_MS = 8000;
    private static final int READ_TIMEOUT_MS = 45000;      // server sends ": keepalive" every 15 s
    private static final long MIN_BACKOFF_MS = 2000L;
    private static final long MAX_BACKOFF_MS = 60000L;
    private static final long NOT_SIGNED_IN_WAIT_MS = 15000L;

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running;
    private volatile HttpURLConnection current;
    private Thread thread;

    CallEventListener(Context context) {
        this.context = context.getApplicationContext();
    }

    synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop, "n3xus-events");
        thread.setDaemon(true);
        thread.start();
    }

    synchronized void stop() {
        running = false;
        HttpURLConnection c = current;
        if (c != null) {
            try { c.disconnect(); } catch (Exception ignored) { }
        }
        if (thread != null) thread.interrupt();
        thread = null;
    }

    private void loop() {
        long backoff = MIN_BACKOFF_MS;
        while (running) {
            String origin = serverOrigin();
            String cookie = null;
            try {
                cookie = origin == null ? null : CookieManager.getInstance().getCookie(origin);
            } catch (Exception ignored) { }
            if (origin == null || cookie == null || !cookie.contains("br_mobile=")) {
                pause(NOT_SIGNED_IN_WAIT_MS);              // not signed in yet
                continue;
            }
            try {
                listen(origin, cookie);
                backoff = MIN_BACKOFF_MS;                  // clean close: reconnect quickly
            } catch (Exception e) {
                Log.i(TAG, "event stream closed: " + e.getMessage());
            }
            if (!running) break;
            pause(backoff);
            backoff = Math.min(MAX_BACKOFF_MS, backoff * 2);
        }
    }

    /**
     * The same trust the app's own page and probes use. Without this the event
     * stream to the desktop's self-signed certificate fails and an incoming call
     * never rings; a public tunnel address still needs its real certificate.
     */
    private HttpURLConnection openTrusted(URL url) throws Exception {
        if (url != null && "https".equalsIgnoreCase(url.getProtocol())) {
            javax.net.ssl.HttpsURLConnection trusted = N3xusTrust.open(context, url, N3xusTrust.isPrivateHost(url.toString()));
            if (trusted != null) return trusted;
        }
        return (HttpURLConnection) url.openConnection();
    }

    private void listen(String origin, String cookie) throws Exception {
        HttpURLConnection c = openTrusted(new URL(origin + "/api/voic3/events"));
        current = c;
        try {
            c.setConnectTimeout(CONNECT_TIMEOUT_MS);
            c.setReadTimeout(READ_TIMEOUT_MS);
            c.setUseCaches(false);
            c.setRequestProperty("Accept", "text/event-stream");
            c.setRequestProperty("Cache-Control", "no-cache");
            c.setRequestProperty("Cookie", cookie);
            int code = c.getResponseCode();
            if (code != 200) throw new IllegalStateException("HTTP " + code);
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                String event = null;
                StringBuilder data = new StringBuilder();
                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.isEmpty()) {                  // blank line ends one event
                        if (event != null) dispatch(event, data.toString());
                        event = null;
                        data.setLength(0);
                    } else if (line.startsWith("event:")) {
                        event = line.substring(6).trim();
                    } else if (line.startsWith("data:")) {
                        if (data.length() > 0) data.append('\n');
                        data.append(line.substring(5).trim());
                    }                                      // ":" lines are keepalives
                }
            }
        } finally {
            current = null;
            c.disconnect();
        }
    }

    private void dispatch(String event, String data) {
        // On screen, the page itself rings through window.N3XUS.incomingCall().
        if (appInForeground()) return;
        try {
            JSONObject payload = new JSONObject(data.isEmpty() ? "{}" : data);
            if ("call.incoming".equals(event)) {
                final JSONObject info = new JSONObject();
                info.put("callId", payload.optInt("call_id", 0));
                info.put("callType", "video".equalsIgnoreCase(payload.optString("call_type", "")) ? "Video" : "Voice");
                JSONObject caller = payload.optJSONObject("caller");
                if (caller != null) {
                    String role = caller.optString("role", "");
                    String dept = caller.optString("department", "");
                    info.put("caller", caller);
                    info.put("callerName", caller.optString("name", ""));
                    info.put("callerRole", role.isEmpty() ? dept : (dept.isEmpty() ? role : role + " · " + dept));
                    info.put("initials", caller.optString("initials", ""));
                }
                main.post(() -> IncomingCallManager.start(context, info));
            } else if ("call.state".equals(event)) {
                String status = payload.optString("status", "");
                if ("ended".equals(status) || "declined".equals(status)) {
                    main.post(() -> IncomingCallManager.callerHungUp(context));
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "unreadable event " + event, e);
        }
    }

    /** https://host:port of the server the WebView last loaded, or null. */
    private String serverOrigin() {
        SharedPreferences prefs = context.getSharedPreferences("br_mobile", Context.MODE_PRIVATE);
        String saved = prefs.getString("server_url", "");
        if (saved == null || !saved.startsWith("https://")) return null;   // never send the cookie in clear
        try {
            URL u = new URL(saved);
            return u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean appInForeground() {
        ActivityManager.RunningAppProcessInfo info = new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(info);
        return info.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND;
    }

    private void pause(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
