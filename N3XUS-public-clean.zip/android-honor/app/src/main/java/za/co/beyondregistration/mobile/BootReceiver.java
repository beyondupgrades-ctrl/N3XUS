package za.co.your-userdregistration.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Brings OpsService (company-device check-ins and the background call
 * listener) back after the phone restarts or the app is updated over the air.
 * Before this, both stayed dead until someone opened the app by hand.
 *
 * Only a phone that has already connected to a N3XUS server is started, so a
 * fresh install never runs a service nobody asked for.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }
        SharedPreferences prefs = context.getSharedPreferences("br_mobile", Context.MODE_PRIVATE);
        String url = prefs.getString("server_url", "");
        if (url == null || url.isEmpty()) return;
        try {
            OpsService.start(context);   // BOOT_COMPLETED / MY_PACKAGE_REPLACED may start a foreground service
        } catch (Exception ignored) {
            // A refused start must never crash the boot broadcast.
        }
    }
}
