package za.co.your-userdregistration.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * The live connection light, carried by a foreground service.
 *
 * One persistent, silent, ongoing notification whose SMALL ICON is a solid dot
 * drawn from a shape (ic_dot_green / ic_dot_amber / ic_dot_red) - never a
 * picture and never generated art. The dot is repainted from the real
 * connection state by AppIcon.set(), so the colour in the status bar IS the
 * state: emerald green while the server answers, warm amber while it is
 * connecting, coral red when it is not.
 *
 * The same state is written in the notification's title as well, so the
 * indicator still works for anyone who cannot tell the colours apart, and the
 * 1x1 home-screen widget (N3xusStatusWidget) is repainted from the same value -
 * one truth, three places, visible even with the app closed.
 *
 * The service does nothing else: it holds no wakelock, fetches nothing, and
 * talks to no outside service. It costs nothing to run.
 */
public class NexusIndicatorService extends Service {
    public static final String CHANNEL_ID = "nexus_indicator";
    private static final int NOTIF_ID = 4301;

    /** Start the light if it is not already lit. Safe to call any number of times. */
    public static void ensure(Context ctx) {
        try {
            Intent i = new Intent(ctx, NexusIndicatorService.class);
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Exception ignored) {
            // Notifications refused or the process is going away: the widget still shows the state.
        }
    }

    /** Stop the light and drop the notification. */
    public static void stop(Context ctx) {
        try { ctx.stopService(new Intent(ctx, NexusIndicatorService.class)); } catch (Exception ignored) { }
    }

    /** Repaint from the remembered state - the one path every indicator uses. */
    public static void repaint(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            nm.notify(NOTIF_ID, build(ctx, AppIcon.state(ctx)));
        } catch (Exception ignored) {
            // No permission, or the service is not running.
        }
    }

    private static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "N3XUS connection light",
                NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("A dot that shows whether this phone can reach the N3XUS server.");
        ch.setShowBadge(false);
        ch.enableVibration(false);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    /** The small icon: a shape, coloured by the state. */
    static int dotIcon(String state) {
        if (AppIcon.GREEN.equals(state)) return R.drawable.ic_dot_green;
        if (AppIcon.YELLOW.equals(state)) return R.drawable.ic_dot_amber;
        return R.drawable.ic_dot_red;
    }

    /** The same state in words, for anyone the colour does not reach. */
    static String dotTitle(String state) {
        if (AppIcon.GREEN.equals(state)) return "N3XUS - connected";
        if (AppIcon.YELLOW.equals(state)) return "N3XUS - connecting";
        return "N3XUS - NOT connected";
    }

    static String dotText(String state) {
        if (AppIcon.GREEN.equals(state)) return "The server is reachable.";
        if (AppIcon.YELLOW.equals(state)) return "Reaching the server...";
        return "Not connected - retrying.";
    }

    static int dotColour(String state) {
        if (AppIcon.GREEN.equals(state)) return 0xFF10B981;
        if (AppIcon.YELLOW.equals(state)) return 0xFFF59E0B;
        return 0xFFEF4444;
    }

    private static Notification build(Context ctx, String state) {
        Intent open = new Intent(ctx, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(ctx, CHANNEL_ID)
                : new Notification.Builder(ctx);
        return b.setSmallIcon(dotIcon(state))
                .setContentTitle(dotTitle(state))
                .setContentText(dotText(state))
                .setContentIntent(pi)
                .setColor(dotColour(state))
                .setShowWhen(false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    @Override public void onCreate() {
        super.onCreate();
        createChannel(this);
        Notification n = build(this, AppIcon.state(this));
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        repaint(this);
        // Not sticky: if the process is killed the notification goes with it, so a
        // dot is never left on screen claiming a state nobody is checking.
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
