# Beyond Registration - firewall hardening
# Run as Administrator: right-click -> Run with PowerShell (approve prompt)
# Reversible: re-enable with Enable-NetFirewallRule -Name <rule>

Write-Host "=== Before ===" -ForegroundColor Cyan
Get-NetFirewallRule -Direction Inbound -Action Allow -Enabled True |
  Where-Object { $_.DisplayName -match "Python|Beyond" } |
  ForEach-Object {
    $f = $_ | Get-NetFirewallPortFilter
    "{0} | {1} | {2} | {3}" -f $_.DisplayName, $f.Protocol, $f.LocalPort, $_.Profile
  }

Write-Host "`nDisabling broad Python rules (any port/protocol, Public profile)..." -ForegroundColor Yellow
Get-NetFirewallRule -DisplayName "Python" |
  Where-Object { $_.Profile -eq "Public" } |
  Disable-NetFirewallRule -ErrorAction Continue

Write-Host "`n=== After ===" -ForegroundColor Cyan
Get-NetFirewallRule -Direction Inbound -Action Allow -Enabled True |
  Where-Object { $_.DisplayName -match "Python|Beyond" } |
  ForEach-Object {
    $f = $_ | Get-NetFirewallPortFilter
    "{0} | {1} | {2} | {3}" -f $_.DisplayName, $f.Protocol, $f.LocalPort, $_.Profile
  }

Write-Host "`nDone. Expected: only 'Beyond Registration' rules remain, port 64281 only." -ForegroundColor Green
pause
