$ErrorActionPreference = 'Stop'
# 64281 speaks TLS (mkcert certificate for localhost/127.0.0.1), never plain http.
$base = Read-Host 'Beyond Registration API URL (default https://127.0.0.1:64281)'
if ([string]::IsNullOrWhiteSpace($base)) { $base = 'https://127.0.0.1:64281' }
$base = $base.TrimEnd('/')
$admin = Read-Host 'Administrator username'
$secureAdmin = Read-Host 'Administrator password' -AsSecureString
$adminPass = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureAdmin))
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
try {
  $login = @{ username=$admin; password=$adminPass } | ConvertTo-Json
  Invoke-RestMethod -Uri "$base/api/login" -Method Post -WebSession $session -ContentType 'application/json' -Body $login | Out-Null
  $employees = (Invoke-RestMethod -Uri "$base/api/employees" -WebSession $session).items
  if (-not $employees) { throw 'No employees were returned. Check that employee records exist.' }
  $employees | Select-Object employee_no,first_name,last_name,job_title | Format-Table -AutoSize
  $number = Read-Host 'Enter the employee number to enable'
  $employee = $employees | Where-Object { $_.employee_no -eq $number } | Select-Object -First 1
  if (-not $employee) { throw 'Employee number not found.' }
  $secureMobile = Read-Host 'Set temporary mobile password (minimum 4 characters)' -AsSecureString
  $mobilePass = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureMobile))
  if ($mobilePass.Length -lt 4) { throw 'Password must contain at least 4 characters.' }
  $body = @{ employee_id=[int]$employee.id; password=$mobilePass } | ConvertTo-Json
  Invoke-RestMethod -Uri "$base/api/mobile/accounts" -Method Post -WebSession $session -ContentType 'application/json' -Body $body | Out-Null
  Write-Host "Mobile access enabled for $($employee.first_name) $($employee.last_name) ($number). Share the password securely." -ForegroundColor Green
} finally { $adminPass=$null; $mobilePass=$null }
