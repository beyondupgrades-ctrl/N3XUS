"""EVOLV3 certificate documents - on-screen, print and PDF.

Everything is produced locally: the QR image is generated offline with the
`qrcode` package, the PDF with ReportLab, and no external service is called.

Cream / teal EVOLV3 sub-brand, A4 landscape.
"""
from __future__ import annotations

import html
import io

CREAM = "#F7F4EA"
CARD = "#FFFFFF"
INK = "#0F172A"
MUTED = "#5B6B7C"
TEAL = "#0F766E"
TEAL_LIGHT = "#14B8A6"
TEAL_TINT = "#E6F4F1"
SAND = "#F3EADA"
BORDER = "#DCE7E1"

COMPANY = "BEYOND REGISTRATION (PTY) LTD"
REG_NO = "2026721121"
TAGLINE = "CARE. KNOWLEDGE. CONFIDENCE."
MOTTO = "EVOLV3 - MORE KNOWLEDGE. GREATER CONFIDENCE. BETTER CARE."
DISCLAIMER = ("This certificate recognises completion of supplementary online learning "
              "and skills development through EVOLV3.")
SIGNATURE = ("Digitally issued by EVOLV3 AI on behalf of Beyond Registration (Pty) Ltd")

MARK_SVG = """<svg width="{size}" height="{size}" viewBox="0 0 36 36" fill="none" aria-hidden="true">
<rect width="36" height="36" rx="10" fill="url(#ev3)"/>
<path d="M11 12H25M11 18H21M11 24H25" stroke="white" stroke-width="2.8" stroke-linecap="round"/>
<defs><linearGradient id="ev3" x1="0" y1="0" x2="36" y2="36" gradientUnits="userSpaceOnUse">
<stop stop-color="{teal}"/><stop offset="1" stop-color="{light}"/></linearGradient></defs></svg>"""


def _e(value):
    return html.escape("" if value is None else str(value))


def _score_line(detail):
    percent = detail.get("percent")
    if percent is None:
        return "COURSE COMPLETED"
    if percent >= 80:
        return "FINAL ASSESSMENT RESULT: {}% - SUCCESSFULLY COMPLETED".format(percent)
    return "FINAL ASSESSMENT RESULT: {}%".format(percent)


def qr_png(payload):
    """Return PNG bytes for the verification payload, or b'' if unavailable."""
    try:
        import qrcode
        img = qrcode.make(payload)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return b""


def html_page(detail, qr_url, pdf_url):
    mark = MARK_SVG.format(size=34, teal=TEAL, light=TEAL_LIGHT)
    qr_block = ('<img class="qr" src="' + _e(qr_url) + '" alt="Certificate QR code">'
                if qr_url else "")
    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{no} - EVOLV3 Certificate</title>
<style>
  @page {{ size: A4 landscape; margin: 0; }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  html, body {{ background: #E7EAE3; }}
  body {{ font-family: "Segoe UI", system-ui, -apple-system, sans-serif; color: {ink};
         display: flex; justify-content: center; padding: 18px 10px 90px; }}
  .actions {{ position: fixed; top: 0; left: 0; right: 0; display: flex; gap: 10px;
             flex-wrap: wrap; justify-content: center; padding: 10px; background: #0B2B27; z-index: 20; }}
  .actions button, .actions a {{ font: inherit; font-size: 13px; font-weight: 700; color: #fff;
             background: {teal}; border: 1px solid {light}; border-radius: 999px;
             padding: 8px 18px; cursor: pointer; text-decoration: none; }}
  .actions .ghost {{ background: transparent; border-color: #ffffff55; }}
  .sheet {{ width: 297mm; min-height: 210mm; flex: 0 0 auto; background: {cream}; padding: 14mm;
            display: flex; flex-direction: column; justify-content: space-between;
            gap: 5mm; box-shadow: 0 18px 50px #0003; position: relative; overflow: hidden;
            transform-origin: top left; }}
  .header {{ display: flex; align-items: center; justify-content: space-between;
             background: {card}; border: 1px solid {border}; border-radius: 20px;
             padding: 4mm 7mm; }}
  .brand {{ display: flex; align-items: center; gap: 4mm; }}
  .brand b {{ font-size: 22px; font-weight: 800; letter-spacing: 2px; }}
  .pill {{ background: linear-gradient(135deg,{teal},{light}); color: #fff;
           font-size: 10px; font-weight: 800; letter-spacing: 1.4px;
           padding: 3mm 6mm; border-radius: 999px; white-space: nowrap; }}
  .hero {{ background: {card}; border: 1px solid {border}; border-radius: 24px;
           padding: 8mm 10mm; text-align: center; flex: 1; display: flex;
           flex-direction: column; align-items: center; justify-content: center; position: relative; }}
  .kicker {{ color: {teal}; font-size: 11px; font-weight: 800; letter-spacing: 3.2px;
             text-transform: uppercase; margin-bottom: 3mm; }}
  .presented {{ color: {muted}; font-size: 11px; margin-bottom: 1.5mm; }}
  .name {{ font-size: 30px; font-weight: 800; letter-spacing: -0.5px; line-height: 1.05;
           margin-bottom: 4mm; overflow-wrap: anywhere; }}
  .recognition {{ color: #475569; font-size: 10.5px; line-height: 1.45;
                  max-width: 170mm; margin: 0 auto 2.5mm; }}
  .course {{ font-size: 17px; font-weight: 800; margin-bottom: 4mm; }}
  .score {{ display: inline-block; background: {teal}; color: #fff; border-radius: 999px;
            font-size: 11.5px; font-weight: 800; letter-spacing: 0.4px; padding: 3mm 7mm; }}
  .issued {{ margin-top: 3.5mm; color: {muted}; font-size: 8px; }}
  .seal {{ position: absolute; right: 8mm; bottom: 8mm; width: 22mm; height: 22mm;
           border: 1.2mm solid {light}; border-radius: 50%; display: grid; place-items: center;
           color: {teal}; font-size: 7px; font-weight: 800; letter-spacing: 1px; text-align: center; }}
  .footer {{ display: grid; grid-template-columns: 1.1fr 1fr 1.1fr; gap: 4mm; }}
  .tab {{ border-radius: 18px; padding: 4mm 5mm; display: flex; flex-direction: column;
          justify-content: center; border: 1px solid {border}; }}
  .mint {{ background: {teal_tint}; border-color: #BFE3DA; }}
  .qr-tab {{ background: {card}; flex-direction: row; align-items: center; gap: 4mm; }}
  .sand {{ background: {sand}; border-color: #E4D6BE; }}
  .label {{ font-size: 7.5px; font-weight: 800; letter-spacing: 0.9px; text-transform: uppercase;
            color: #3C5A54; }}
  .value {{ font-size: 11px; font-weight: 800; margin: 0.5mm 0 2.5mm; }}
  .qr {{ width: 22mm; height: 22mm; }}
  .qr-title {{ font-size: 9.5px; font-weight: 800; margin-bottom: 1mm; }}
  .small {{ font-size: 8px; color: {muted}; line-height: 1.35; }}
  .motto {{ font-size: 8.5px; font-weight: 800; line-height: 1.35; margin-bottom: 2mm; color: #234B45; }}
  .disclaimer {{ font-size: 7px; color: #6B5B45; line-height: 1.35; }}
  .code {{ font-family: Consolas, "Courier New", monospace; font-size: 7.5px;
           letter-spacing: 0.4px; margin-top: 1.5mm; color: #3C5A54; }}
  /* Phones: re-flow the certificate instead of shrinking A4 until the text is
     unreadable. Print and PDF still use the true A4 landscape layout. */
  @media screen and (max-width: 760px) {{
    body {{ display: block; padding: 76px 0 24px; }}
    .actions {{ gap: 8px; }}
    .actions button, .actions a {{ font-size: 12px; padding: 7px 14px; }}
    .sheet {{ width: 100%; min-height: 0; padding: 12px; gap: 9px; box-shadow: none; }}
    .header {{ flex-direction: column; align-items: flex-start; gap: 8px;
               padding: 12px 14px; border-radius: 16px; }}
    .brand b {{ font-size: 18px; letter-spacing: 1.6px; }}
    .pill {{ font-size: 8.5px; padding: 6px 12px; letter-spacing: 1.1px; }}
    .hero {{ padding: 20px 14px; border-radius: 18px; }}
    .kicker {{ font-size: 9.5px; letter-spacing: 2.2px; margin-bottom: 8px; }}
    .presented {{ font-size: 10px; }}
    .name {{ font-size: 25px; margin-bottom: 9px; }}
    .recognition {{ font-size: 10px; max-width: none; margin-bottom: 8px; }}
    .course {{ font-size: 15px; margin-bottom: 9px; }}
    .score {{ font-size: 9.5px; padding: 8px 12px; max-width: 100%;
              line-height: 1.35; white-space: normal; text-align: center; }}
    .issued {{ font-size: 8px; margin-top: 12px; }}
    .seal {{ position: static; margin: 14px auto 0; width: 68px; height: 68px;
             border-width: 4px; font-size: 7px; }}
    .footer {{ grid-template-columns: 1fr; gap: 8px; }}
    .tab {{ padding: 12px 14px; border-radius: 14px; }}
    .qr {{ width: 66px; height: 66px; }}
    .label {{ font-size: 8px; }}
    .value {{ font-size: 12px; margin: 2px 0 8px; }}
    .small {{ font-size: 9px; }}
    .motto {{ font-size: 10px; }}
    .disclaimer {{ font-size: 8.5px; }}
    .code {{ font-size: 8px; word-break: break-all; }}
  }}
  @media print {{
    html, body {{ background: #fff; padding: 0; display: block; }}
    .actions {{ display: none; }}
    .sheet {{ width: 297mm; height: 210mm; min-height: 0; box-shadow: none; margin: 0;
              transform: none !important; zoom: 1 !important; }}
    * {{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
  }}
</style></head>
<body>
<div class="actions">
  <button onclick="window.print()">Print</button>
  <a href="{pdf}">Download PDF</a>
  <button class="ghost" onclick="history.back()">Back</button>
</div>
<div class="sheet">
  <div class="header">
    <div class="brand">{mark}<b>EVOLV3</b></div>
    <div class="pill">{tagline}</div>
  </div>

  <div class="hero">
    <div class="kicker">Certificate of Completion</div>
    <div class="presented">This certificate is proudly presented to:</div>
    <div class="name">{name}</div>
    <div class="recognition">In recognition of successfully completing the following online
      self-improvement and skills-development programme:</div>
    <div class="course">{course}</div>
    <div class="score">{score}</div>
    <div class="issued">Issued digitally by EVOLV3 AI on behalf of {company}<br>
      REG. NO. {reg} &middot; {issued}</div>
    <div class="seal">EVOLV3<br>DIGITAL<br>SEAL</div>
  </div>

  <div class="footer">
    <div class="tab mint">
      <div class="label">Date of Completion</div>
      <div class="value">{issued}</div>
      <div class="label">Certificate Reference</div>
      <div class="value" style="margin-bottom:0">{no}</div>
    </div>
    <div class="tab qr-tab">
      {qr}
      <div>
        <div class="qr-title">Verify Authenticity</div>
        <div class="small">Scan, or check this code in the app under EVOLV3 &rarr; Verify a certificate.</div>
        <div class="code">{verify}</div>
      </div>
    </div>
    <div class="tab sand">
      <div class="motto">{motto}</div>
      <div class="disclaimer">{disclaimer}</div>
    </div>
  </div>
</div>
<script>
(function(){{
  var sheet = document.querySelector('.sheet');
  if (!sheet) return;
  function fit() {{
    sheet.style.zoom = '';
    var avail = document.documentElement.clientWidth - 14;
    var w = sheet.getBoundingClientRect().width || 1122;
    if (w > avail) sheet.style.zoom = String(Math.max(0.2, avail / w));
  }}
  fit();
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', function(){{ setTimeout(fit, 220); }});
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
}})();
</script>
</body></html>""".format(
        no=_e(detail.get("certificate_no")), name=_e(detail.get("staff_name")),
        course=_e(detail.get("course_title")), score=_e(_score_line(detail)),
        issued=_e(detail.get("issued_at")), company=_e(COMPANY), reg=_e(REG_NO),
        verify=_e(detail.get("verification_code")), tagline=_e(TAGLINE),
        motto=_e(MOTTO), disclaimer=_e(DISCLAIMER), mark=mark, qr=qr_block,
        pdf=_e(pdf_url), qr_url=_e(qr_url),
        cream=CREAM, card=CARD, ink=INK, muted=MUTED, teal=TEAL,
        light=TEAL_LIGHT, teal_tint=TEAL_TINT, sand=SAND, border=BORDER)


# ---------------------------------------------------------------------------
# PDF (ReportLab canvas, exact A4 landscape)
# ---------------------------------------------------------------------------

def _wrap(canvas, text, font, size, width):
    words = str(text).split()
    lines, line = [], ""
    for word in words:
        trial = (line + " " + word).strip()
        if canvas.stringWidth(trial, font, size) <= width:
            line = trial
        else:
            if line:
                lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines


def pdf_bytes(detail, qr_png_data=None):
    from reportlab.lib.colors import HexColor
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas as pdfcanvas
    from reportlab.lib.units import mm

    page_w, page_h = landscape(A4)
    buf = io.BytesIO()
    c = pdfcanvas.Canvas(buf, pagesize=(page_w, page_h))
    c.setTitle("EVOLV3 Certificate " + str(detail.get("certificate_no", "")))
    c.setAuthor(COMPANY)

    cream = HexColor(CREAM)
    card = HexColor(CARD)
    ink = HexColor(INK)
    muted = HexColor(MUTED)
    teal = HexColor(TEAL)
    light = HexColor(TEAL_LIGHT)
    tint = HexColor(TEAL_TINT)
    sand = HexColor(SAND)
    border = HexColor(BORDER)

    W = page_w
    H = page_h
    margin = 14 * mm

    # background
    c.setFillColor(cream)
    c.rect(0, 0, W, H, fill=1, stroke=0)

    def card_rect(x, y, w, h, radius=6 * mm, fill=card, stroke=border):
        c.setFillColor(fill)
        c.setStrokeColor(stroke)
        c.setLineWidth(0.8)
        c.roundRect(x, y, w, h, radius, fill=1, stroke=1)

    # ---------------- header ----------------
    header_h = 20 * mm
    header_y = H - margin - header_h
    card_rect(margin, header_y, W - 2 * margin, header_h, 5 * mm)
    # mark
    mx = margin + 7 * mm
    my = header_y + 4 * mm
    c.setFillColor(teal)
    c.roundRect(mx, my, 12 * mm, 12 * mm, 2.6 * mm, fill=1, stroke=0)
    c.setStrokeColor(card)
    c.setLineWidth(1.6)
    for i, frac in enumerate((0.30, 0.50, 0.70)):
        c.line(mx + 3 * mm, my + 12 * mm * (1 - frac), mx + 9 * mm, my + 12 * mm * (1 - frac))
    c.setFillColor(ink)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(mx + 17 * mm, header_y + 6.4 * mm, "EVOLV3")
    # tagline pill
    pill_w = 78 * mm
    pill_h = 9 * mm
    px = W - margin - 7 * mm - pill_w
    py = header_y + (header_h - pill_h) / 2
    c.setFillColor(teal)
    c.roundRect(px, py, pill_w, pill_h, pill_h / 2, fill=1, stroke=0)
    c.setFillColor(card)
    c.setFont("Helvetica-Bold", 8.5)
    c.drawCentredString(px + pill_w / 2, py + 3.2 * mm, TAGLINE)

    # ---------------- footer ----------------
    footer_h = 40 * mm
    footer_y = margin
    gap = 4 * mm
    total_w = W - 2 * margin
    col_w = (total_w - 2 * gap) / 3.1
    widths = [col_w * 1.05, col_w, col_w * 1.05]
    widths[1] = total_w - widths[0] - widths[2] - 2 * gap

    # mint tab
    x = margin
    card_rect(x, footer_y, widths[0], footer_h, 5 * mm, fill=tint, stroke=HexColor("#BFE3DA"))
    c.setFillColor(HexColor("#3C5A54"))
    c.setFont("Helvetica-Bold", 6.4)
    c.drawString(x + 5 * mm, footer_y + footer_h - 8 * mm, "DATE OF COMPLETION")
    c.setFillColor(ink)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(x + 5 * mm, footer_y + footer_h - 14 * mm, str(detail.get("issued_at", "")))
    c.setFillColor(HexColor("#3C5A54"))
    c.setFont("Helvetica-Bold", 6.4)
    c.drawString(x + 5 * mm, footer_y + footer_h - 22 * mm, "CERTIFICATE REFERENCE")
    c.setFillColor(ink)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(x + 5 * mm, footer_y + footer_h - 28 * mm, str(detail.get("certificate_no", "")))

    # QR tab
    x += widths[0] + gap
    card_rect(x, footer_y, widths[1], footer_h, 5 * mm)
    qr_size = 24 * mm
    if qr_png_data:
        try:
            c.drawImage(ImageReader(io.BytesIO(qr_png_data)),
                        x + 4 * mm, footer_y + (footer_h - qr_size) / 2,
                        qr_size, qr_size, preserveAspectRatio=True, mask="auto")
        except Exception:
            pass
    tx = x + 4 * mm + (qr_size + 3 * mm if qr_png_data else 0)
    c.setFillColor(ink)
    c.setFont("Helvetica-Bold", 8.4)
    c.drawString(tx, footer_y + footer_h - 9 * mm, "Verify Authenticity")
    c.setFillColor(muted)
    c.setFont("Helvetica", 6.2)
    lines = _wrap(c, "Scan this code, or check it in the app under EVOLV3 - Verify a certificate.",
                  "Helvetica", 6.2, widths[1] - (tx - x) - 4 * mm)
    yy = footer_y + footer_h - 14 * mm
    for line in lines[:3]:
        c.drawString(tx, yy, line)
        yy -= 3 * mm
    c.setFillColor(HexColor("#3C5A54"))
    c.setFont("Courier-Bold", 6.0)
    c.drawString(tx, footer_y + 4 * mm, str(detail.get("verification_code", ""))[:40])

    # sand tab
    x += widths[1] + gap
    card_rect(x, footer_y, widths[2], footer_h, 5 * mm, fill=sand, stroke=HexColor("#E4D6BE"))
    c.setFillColor(HexColor("#234B45"))
    c.setFont("Helvetica-Bold", 7.4)
    yy = footer_y + footer_h - 9 * mm
    for line in _wrap(c, MOTTO, "Helvetica-Bold", 7.4, widths[2] - 10 * mm)[:3]:
        c.drawString(x + 5 * mm, yy, line)
        yy -= 3.4 * mm
    c.setFillColor(HexColor("#6B5B45"))
    c.setFont("Helvetica", 5.9)
    yy -= 1 * mm
    for line in _wrap(c, DISCLAIMER, "Helvetica", 5.9, widths[2] - 10 * mm)[:4]:
        c.drawString(x + 5 * mm, yy, line)
        yy -= 2.8 * mm

    # ---------------- hero ----------------
    hero_top = header_y - 5 * mm
    hero_bottom = footer_y + footer_h + 5 * mm
    hero_h = hero_top - hero_bottom
    card_rect(margin, hero_bottom, total_w, hero_h, 7 * mm)

    cx = W / 2
    y = hero_top - 22 * mm
    c.setFillColor(teal)
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(cx, y, "CERTIFICATE OF COMPLETION")

    y -= 7 * mm
    c.setFillColor(muted)
    c.setFont("Helvetica", 8.5)
    c.drawCentredString(cx, y, "This certificate is proudly presented to:")

    y -= 12 * mm
    name = str(detail.get("staff_name", "Employee"))
    name_size = 26
    while name_size > 14 and c.stringWidth(name, "Helvetica-Bold", name_size) > total_w - 40 * mm:
        name_size -= 1
    c.setFillColor(ink)
    c.setFont("Helvetica-Bold", name_size)
    c.drawCentredString(cx, y, name)

    y -= 7 * mm
    c.setFillColor(HexColor("#475569"))
    c.setFont("Helvetica", 8.2)
    for line in _wrap(c, "In recognition of successfully completing the following online "
                         "self-improvement and skills-development programme:",
                      "Helvetica", 8.2, 170 * mm)[:2]:
        c.drawCentredString(cx, y, line)
        y -= 4 * mm

    y -= 1 * mm
    course = str(detail.get("course_title", "EVOLV3 Course"))
    course_size = 14
    while course_size > 9 and c.stringWidth(course, "Helvetica-Bold", course_size) > total_w - 50 * mm:
        course_size -= 1
    c.setFillColor(HexColor("#1E293B"))
    c.setFont("Helvetica-Bold", course_size)
    c.drawCentredString(cx, y, course)

    # score pill
    y -= 11 * mm
    score_text = _score_line(detail)
    c.setFont("Helvetica-Bold", 8.5)
    pill_w = c.stringWidth(score_text, "Helvetica-Bold", 8.5) + 18 * mm
    pill_h = 9 * mm
    c.setFillColor(teal)
    c.roundRect(cx - pill_w / 2, y - 2 * mm, pill_w, pill_h, pill_h / 2, fill=1, stroke=0)
    c.setFillColor(card)
    c.drawCentredString(cx, y + 1.1 * mm, score_text)

    # signature / digital issue - sits under the score, in the content flow
    c.setFillColor(muted)
    c.setFont("Helvetica", 6.6)
    c.drawCentredString(cx, y - 15 * mm,
                        "Issued digitally by EVOLV3 AI on behalf of " + COMPANY)
    c.drawCentredString(cx, y - 18.5 * mm, "REG. NO. " + REG_NO)

    # digital seal
    seal_r = 12 * mm
    sx = margin + total_w - 20 * mm
    sy = hero_bottom + 14 * mm
    c.setStrokeColor(light)
    c.setLineWidth(2.2)
    c.circle(sx, sy, seal_r, fill=0, stroke=1)
    c.setFillColor(teal)
    c.setFont("Helvetica-Bold", 5.4)
    c.drawCentredString(sx, sy + 3 * mm, "EVOLV3")
    c.setFont("Helvetica-Bold", 4.6)
    c.drawCentredString(sx, sy - 0.5 * mm, "DIGITAL")
    c.drawCentredString(sx, sy - 4 * mm, "SEAL")

    c.showPage()
    c.save()
    return buf.getvalue()
