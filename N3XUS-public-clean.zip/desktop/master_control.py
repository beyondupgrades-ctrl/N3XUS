"""BEYOND MASTER CONTROL - central customer, subscription, billing and
entitlement authority for the BEYOND REGISTRATION ecosystem.

100% in-house. No paid payment gateway. Bank transfers are recorded manually and
verified by the owner. Suspension never happens automatically: overdue accounts
raise an alert and wait for an explicit owner decision.
"""
from __future__ import annotations

import base64
import json
import os
import secrets
from datetime import date, datetime, timedelta
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

PRODUCTS = ["N3XUS", "VOIC3", "NAV!Q", "CYB3RAX", "EVOLV3", "CORTEX", "V3CTOR", "CN3CT"]

PRODUCT_MODULES = {
    "N3XUS": ["Dashboard", "Employees", "HR", "Leave", "Attendance", "Payroll", "Inventory",
              "Accounting", "Projects", "Requests & Procurement", "Academy"],
    "VOIC3": ["Messaging", "Payslips", "Notifications"],
    "NAV!Q": ["Tracking", "Safety", "Satellite SOS"],
    "CYB3RAX": ["Security centre", "Audit", "Alerts"],
    "EVOLV3": ["Courses", "Assessments", "Certificates"],
    "CORTEX": ["Local AI", "Agents", "Vision"],
    "V3CTOR": ["Cameras", "Recordings", "Monitoring"],
    "CN3CT": ["Networks", "Devices", "Gateways", "Policies"],
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS mc_customers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_no TEXT NOT NULL UNIQUE,
  customer_type TEXT NOT NULL DEFAULT 'Business',
  name TEXT NOT NULL,
  registration_no TEXT DEFAULT '',
  contact_name TEXT DEFAULT '',
  email TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  billing_address TEXT DEFAULT '',
  service_address TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Active',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mc_subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL,
  product TEXT NOT NULL,
  package TEXT DEFAULT 'Standard',
  modules_json TEXT DEFAULT '[]',
  billing_period TEXT NOT NULL DEFAULT 'Monthly',
  amount REAL NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'ZAR',
  start_date TEXT NOT NULL,
  end_date TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Active',
  next_invoice_date TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(customer_id) REFERENCES mc_customers(id)
);
CREATE TABLE IF NOT EXISTS mc_invoices(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL,
  subscription_id INTEGER,
  period_start TEXT DEFAULT '',
  period_end TEXT DEFAULT '',
  issue_date TEXT NOT NULL,
  due_date TEXT NOT NULL,
  subtotal REAL NOT NULL DEFAULT 0,
  tax_rate REAL NOT NULL DEFAULT 0,
  tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL DEFAULT 0,
  amount_paid REAL NOT NULL DEFAULT 0,
  balance REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Awaiting payment',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(customer_id) REFERENCES mc_customers(id)
);
CREATE TABLE IF NOT EXISTS mc_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  invoice_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  method TEXT DEFAULT 'Bank transfer',
  reference TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Reported',
  reported_at TEXT NOT NULL,
  verified_by TEXT DEFAULT '',
  verified_at TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  FOREIGN KEY(invoice_id) REFERENCES mc_invoices(id)
);
CREATE TABLE IF NOT EXISTS mc_entitlements(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  subscription_id INTEGER NOT NULL,
  product TEXT NOT NULL,
  modules_json TEXT DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'Active',
  issued_at TEXT NOT NULL,
  valid_until TEXT NOT NULL,
  token TEXT NOT NULL,
  signature TEXT DEFAULT '',
  revoked_at TEXT DEFAULT '',
  revoke_reason TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS mc_alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alert_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  customer_id INTEGER,
  invoice_id INTEGER,
  subscription_id INTEGER,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Open',
  created_at TEXT NOT NULL,
  acknowledged_at TEXT DEFAULT '',
  acknowledged_by TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS mc_owner_actions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  customer_id INTEGER,
  subscription_id INTEGER,
  invoice_id INTEGER,
  reason TEXT DEFAULT '',
  step_up_confirmed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mc_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT DEFAULT '',
  action TEXT NOT NULL,
  entity_type TEXT DEFAULT '',
  entity_id TEXT DEFAULT '',
  detail TEXT DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mc_settings(
  key TEXT PRIMARY KEY,
  value TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_mc_sub_customer ON mc_subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_mc_inv_customer ON mc_invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_mc_inv_status ON mc_invoices(status);
CREATE INDEX IF NOT EXISTS idx_mc_pay_invoice ON mc_payments(invoice_id);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _today() -> str:
    return date.today().isoformat()


_DEFAULT_DIR = None


def set_data_dir(path) -> None:
    """Point signing keys at a specific data directory (server or tests)."""
    global _DEFAULT_DIR
    _DEFAULT_DIR = Path(path) if path else None


def _event(conn, actor, action, entity_type="", entity_id="", detail=""):
    conn.execute("INSERT INTO mc_events(actor,action,entity_type,entity_id,detail,created_at) VALUES(?,?,?,?,?,?)",
                 (actor or "", action, entity_type or "", str(entity_id or ""), detail or "", _now()))


def _json(v, default="[]"):
    try:
        return json.dumps(v if v is not None else json.loads(default))
    except Exception:
        return default


def ensure_schema(conn) -> None:
    conn.executescript(SCHEMA)
    # idempotent currency columns
    for tbl in ("mc_customers", "mc_invoices"):
        cols = [r[1] for r in conn.execute(f"PRAGMA table_info({tbl})").fetchall()]
        if "currency" not in cols:
            conn.execute(f"ALTER TABLE {tbl} ADD COLUMN currency TEXT NOT NULL DEFAULT 'ZAR'")
    conn.execute("""CREATE TABLE IF NOT EXISTS mc_exchange_rates(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        base_currency TEXT NOT NULL,
        quote_currency TEXT NOT NULL,
        rate REAL NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT DEFAULT '',
        UNIQUE(base_currency, quote_currency)
    )""")
    for base, quote, rate in (("ZAR","ZAR",1.0),("USD","ZAR",18.5),("EUR","ZAR",20.0),("GBP","ZAR",23.0)):
        conn.execute("INSERT OR IGNORE INTO mc_exchange_rates(base_currency,quote_currency,rate,updated_at,updated_by) VALUES(?,?,?,?,?)",
                     (base, quote, rate, _now(), "system"))
    conn.execute("INSERT OR IGNORE INTO mc_settings(key,value) VALUES('owner_username',?)",
                 (os.environ.get("NEXUS_OWNER_USERNAME", "dean"),))
    conn.execute("INSERT OR IGNORE INTO mc_settings(key,value) VALUES('owner_display_name','DEAN BROWN')")
    conn.commit()


def setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM mc_settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key, value):
    conn.execute("INSERT INTO mc_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
    conn.commit()
    return setting(conn, key)


def resolve_owner(conn):
    """Return the username of the one account allowed to suspend or restore service.

    Priority: configured owner_username, then an account named DEAN BROWN, then the
    earliest active Administrator. The fallback keeps a fresh install usable while
    never inventing an owner out of thin air.
    """
    configured = str(setting(conn, "owner_username", "") or "").strip()
    if configured:
        row = conn.execute("SELECT username FROM admins WHERE username=? COLLATE NOCASE AND active=1",
                           (configured,)).fetchone()
        if row:
            return row["username"]
    row = conn.execute(
        "SELECT username FROM admins WHERE active=1 AND "
        "(lower(username) LIKE '%dean%' OR lower(full_name) LIKE '%dean%brown%') ORDER BY id LIMIT 1").fetchone()
    if row:
        return row["username"]
    row = conn.execute("SELECT username FROM admins WHERE active=1 ORDER BY id LIMIT 1").fetchone()
    return row["username"] if row else ""


def is_owner(conn, actor):
    owner = resolve_owner(conn)
    return bool(owner and actor and str(actor).casefold() == str(owner).casefold())


def owner_profile(conn, actor):
    owner = resolve_owner(conn)
    configured = str(setting(conn, "owner_username", "") or "").strip()
    if configured and owner and configured.casefold() == str(owner).casefold():
        source = "configured"
    elif owner and "dean" in str(owner).casefold():
        source = "dean_brown"
    elif owner:
        source = "fallback_first_admin"
    else:
        source = "none"
    row = conn.execute("SELECT username,full_name FROM admins WHERE username=? COLLATE NOCASE",
                       (owner,)).fetchone() if owner else None
    return {
        "owner_username": owner,
        "owner_full_name": row["full_name"] if row else setting(conn, "owner_display_name", "DEAN BROWN"),
        "owner_source": source,
        "fallback_used": source == "fallback_first_admin",
        "actor": actor,
        "is_owner": bool(owner and actor and str(actor).casefold() == str(owner).casefold()),
        "suspension_authority": "Platform Owner only",
    }


# ---------------------------------------------------------------- keys/tokens

def _key_path(data_dir=None) -> Path:
    if data_dir:
        base = Path(data_dir)
    elif _DEFAULT_DIR:
        base = Path(_DEFAULT_DIR)
    else:
        if os.name == "nt":
            base = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data"
        else:
            base = Path.home() / ".your-userd_registration" / "Data"
    base.mkdir(parents=True, exist_ok=True)
    return base


def signing_key(data_dir=None) -> Ed25519PrivateKey:
    """Load or create the Ed25519 signing key, sealed with Windows DPAPI."""
    path = _key_path(data_dir) / "master_control.key"
    if os.name == "nt":
        from communications import SecretVault
        vault = SecretVault(path)
        raw = vault.get("ed25519_private")
        if isinstance(raw, str) and raw:
            return Ed25519PrivateKey.from_private_bytes(base64.b64decode(raw))
        key = Ed25519PrivateKey.generate()
        pem = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                serialization.NoEncryption())
        vault.set("ed25519_private", base64.b64encode(pem).decode("ascii"))
        return key
    legacy = path.with_suffix(".raw")
    if legacy.exists():
        return Ed25519PrivateKey.from_private_bytes(legacy.read_bytes())
    key = Ed25519PrivateKey.generate()
    legacy.write_bytes(key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                         serialization.NoEncryption()))
    try:
        legacy.chmod(0o600)
    except Exception:
        pass
    return key


def public_key_b64(data_dir=None) -> str:
    raw = signing_key(data_dir).public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return base64.urlsafe_b64encode(raw).decode("ascii")


def _sign(payload: dict, data_dir=None) -> tuple[str, str]:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    sig = signing_key(data_dir).sign(raw)
    body = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    return body, base64.urlsafe_b64encode(sig).decode("ascii").rstrip("=")


def issue_entitlement(conn, customer_id, subscription_id, days=30, data_dir=None):
    sub = conn.execute("SELECT * FROM mc_subscriptions WHERE id=?", (int(subscription_id),)).fetchone()
    if not sub:
        raise ValueError("Subscription not found.")
    cust = conn.execute("SELECT * FROM mc_customers WHERE id=?", (int(customer_id),)).fetchone()
    if not cust:
        raise ValueError("Customer not found.")
    if sub["status"] != "Active" or cust["status"] != "Active":
        raise ValueError("Only active customers and subscriptions receive entitlements.")
    now = datetime.now()
    payload = {
        "iss": "BEYOND MASTER CONTROL",
        "org": int(customer_id),
        "org_no": cust["customer_no"],
        "sub": int(subscription_id),
        "sub_ref": sub["ref"],
        "product": sub["product"],
        "modules": json.loads(sub["modules_json"] or "[]"),
        "iat": int(now.timestamp()),
        "nbf": int(now.timestamp()),
        "exp": int((now + timedelta(days=int(days or 30))).timestamp()),
        "nonce": secrets.token_hex(8),
    }
    body, sig = _sign(payload, data_dir)
    token = f"{body}.{sig}"
    conn.execute("UPDATE mc_entitlements SET status='Superseded' WHERE subscription_id=? AND status='Active'",
                 (int(subscription_id),))
    conn.execute("INSERT INTO mc_entitlements(customer_id,subscription_id,product,modules_json,status,issued_at,valid_until,token,signature) "
                 "VALUES(?,?,?,?,?,?,?,?,?)",
                 (int(customer_id), int(subscription_id), sub["product"], sub["modules_json"] or "[]",
                  "Active", _now(), datetime.fromtimestamp(payload["exp"]).isoformat(timespec="seconds"), token, sig))
    conn.commit()
    return {"token": token, "payload": payload, "public_key": public_key_b64(data_dir)}


def validate_entitlement(conn, token, data_dir=None, grace_seconds=0, online=True):
    try:
        body, sig = token.split(".", 1)
        raw = base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))
        signature = base64.urlsafe_b64decode(sig + "=" * (-len(sig) % 4))
        pub_raw = base64.urlsafe_b64decode(public_key_b64(data_dir) + "=" * (-len(public_key_b64(data_dir)) % 4))
        Ed25519PublicKey.from_public_bytes(pub_raw).verify(signature, raw)
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        return {"valid": False, "reason": "signature"}
    now = int(datetime.now().timestamp())
    if now > int(payload.get("exp", 0)) + int(grace_seconds or 0):
        return {"valid": False, "reason": "expired", "payload": payload}
    if now < int(payload.get("nbf", 0)) - 60:
        return {"valid": False, "reason": "not_yet_valid", "payload": payload}
    if online:
        sub = conn.execute("SELECT status FROM mc_subscriptions WHERE id=?", (int(payload["sub"]),)).fetchone()
        if not sub or sub["status"] != "Active":
            return {"valid": False, "reason": "revoked", "payload": payload}
    return {"valid": True, "reason": "ok", "payload": payload}


def revoke_entitlements(conn, customer_id=None, subscription_id=None, reason=""):
    sql = "UPDATE mc_entitlements SET status='Revoked',revoked_at=?,revoke_reason=? WHERE status='Active'"
    args = [_now(), reason or ""]
    if subscription_id:
        sql += " AND subscription_id=?"; args.append(int(subscription_id))
    elif customer_id:
        sql += " AND customer_id=?"; args.append(int(customer_id))
    conn.execute(sql, args)
    conn.commit()


# ---------------------------------------------------------------- customers

def _next_no(conn, prefix, table, column, fmt="%Y%m%d"):
    day = date.today().strftime(fmt)
    row = conn.execute(f"SELECT COUNT(*) c FROM {table} WHERE {column} LIKE ?", (f"{prefix}-{day}-%",)).fetchone()
    return f"{prefix}-{day}-{int(row['c']) + 1:04d}"


def create_customer(conn, payload, actor=""):
    name = str(payload.get("name") or "").strip()
    if not name:
        raise ValueError("Customer name is required.")
    no = str(payload.get("customer_no") or "").strip() or _next_no(conn, "CUS", "mc_customers", "customer_no")
    currency = str(payload.get("currency") or "ZAR").upper()
    if len(currency) != 3:
        raise ValueError("Currency must be a 3-letter ISO code.")
    cur = conn.execute(
        "INSERT INTO mc_customers(customer_no,customer_type,name,registration_no,contact_name,email,phone,"
        "billing_address,service_address,status,notes,currency,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (no, payload.get("customer_type") or "Business", name, payload.get("registration_no") or "",
         payload.get("contact_name") or "", payload.get("email") or "", payload.get("phone") or "",
         payload.get("billing_address") or "", payload.get("service_address") or "",
         payload.get("status") or "Active", payload.get("notes") or "", currency, _now(), _now()))
    _event(conn, actor, "Customer created", "customer", cur.lastrowid, no)
    conn.commit()
    return get_customer(conn, cur.lastrowid)


def update_customer(conn, customer_id, payload, actor=""):
    allowed = ["customer_type", "name", "registration_no", "contact_name", "email", "phone",
               "billing_address", "service_address", "status", "notes", "currency"]
    if "currency" in payload and payload.get("currency") is not None:
        c = str(payload.get("currency")).upper()
        if len(c) != 3:
            raise ValueError("Currency must be a 3-letter ISO code.")
        payload = dict(payload); payload["currency"] = c
    fields = [k for k in allowed if k in payload]
    if not fields:
        return get_customer(conn, customer_id)
    sql = "UPDATE mc_customers SET " + ",".join(f"{k}=?" for k in fields) + ",updated_at=? WHERE id=?"
    conn.execute(sql, [payload[k] for k in fields] + [_now(), int(customer_id)])
    _event(conn, actor, "Customer updated", "customer", customer_id, ",".join(fields))
    conn.commit()
    return get_customer(conn, customer_id)


def list_customers(conn, status=None, search=""):
    sql = "SELECT * FROM mc_customers WHERE 1=1"; args = []
    if status:
        sql += " AND status=?"; args.append(status)
    if search:
        sql += " AND (name LIKE ? OR customer_no LIKE ? OR email LIKE ?)"
        like = f"%{search}%"; args += [like, like, like]
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def get_customer(conn, customer_id):
    row = conn.execute("SELECT * FROM mc_customers WHERE id=?", (int(customer_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["subscriptions"] = [dict(r) for r in conn.execute(
        "SELECT * FROM mc_subscriptions WHERE customer_id=? ORDER BY id DESC", (int(customer_id),)).fetchall()]
    item["invoices"] = [dict(r) for r in conn.execute(
        "SELECT * FROM mc_invoices WHERE customer_id=? ORDER BY id DESC", (int(customer_id),)).fetchall()]
    item["payments"] = [dict(r) for r in conn.execute(
        "SELECT * FROM mc_payments WHERE customer_id=? ORDER BY id DESC", (int(customer_id),)).fetchall()]
    item["balance"] = round(sum(float(i["balance"] or 0) for i in item["invoices"]
                               if i["status"] not in ("Paid", "Cancelled", "Refunded")), 2)
    item["events"] = [dict(r) for r in conn.execute(
        "SELECT * FROM mc_owner_actions WHERE customer_id=? ORDER BY id DESC", (int(customer_id),)).fetchall()]
    return item


# ---------------------------------------------------------------- subscriptions

def create_subscription(conn, payload, actor=""):
    customer_id = int(payload.get("customer_id") or 0)
    if not conn.execute("SELECT id FROM mc_customers WHERE id=?", (customer_id,)).fetchone():
        raise ValueError("Choose a valid customer.")
    product = str(payload.get("product") or "").strip()
    if product not in PRODUCTS:
        raise ValueError("Choose a valid product.")
    amount = float(payload.get("amount") or 0)
    start = payload.get("start_date") or _today()
    ref = str(payload.get("ref") or "").strip() or _next_no(conn, "SUB", "mc_subscriptions", "ref")
    modules = payload.get("modules") or PRODUCT_MODULES.get(product, [])
    cur = conn.execute(
        "INSERT INTO mc_subscriptions(ref,customer_id,product,package,modules_json,billing_period,amount,currency,"
        "start_date,end_date,status,next_invoice_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (ref, customer_id, product, payload.get("package") or "Standard", _json(modules),
         payload.get("billing_period") or "Monthly", amount, payload.get("currency") or "ZAR",
         start, payload.get("end_date") or "", payload.get("status") or "Active",
         payload.get("next_invoice_date") or start, _now(), _now()))
    _event(conn, actor, "Subscription created", "subscription", cur.lastrowid, f"{ref} {product}")
    conn.commit()
    return get_subscription(conn, cur.lastrowid)


def get_subscription(conn, subscription_id):
    row = conn.execute("SELECT * FROM mc_subscriptions WHERE id=?", (int(subscription_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    try:
        item["modules"] = json.loads(item["modules_json"] or "[]")
    except Exception:
        item["modules"] = []
    item["customer"] = dict(conn.execute("SELECT * FROM mc_customers WHERE id=?", (int(row["customer_id"]),)).fetchone() or {})
    item["entitlement"] = None
    ent = conn.execute("SELECT * FROM mc_entitlements WHERE subscription_id=? ORDER BY id DESC LIMIT 1",
                       (int(subscription_id),)).fetchone()
    if ent:
        item["entitlement"] = dict(ent)
    return item


def list_subscriptions(conn, customer_id=None, status=None):
    sql = "SELECT s.*,c.name customer_name,c.customer_no FROM mc_subscriptions s JOIN mc_customers c ON c.id=s.customer_id WHERE 1=1"
    args = []
    if customer_id:
        sql += " AND s.customer_id=?"; args.append(int(customer_id))
    if status:
        sql += " AND s.status=?"; args.append(status)
    sql += " ORDER BY s.id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def set_subscription_status(conn, subscription_id, status, actor="", reason=""):
    if status not in ("Active", "Suspended", "Cancelled", "Expired"):
        raise ValueError("Invalid subscription status.")
    conn.execute("UPDATE mc_subscriptions SET status=?,updated_at=? WHERE id=?",
                 (status, _now(), int(subscription_id)))
    if status != "Active":
        revoke_entitlements(conn, subscription_id=int(subscription_id), reason=reason or status)
    _event(conn, actor, f"Subscription {status.lower()}", "subscription", subscription_id, reason or "")
    conn.commit()
    return get_subscription(conn, subscription_id)


# ---------------------------------------------------------------- invoices/payments

def create_invoice(conn, payload, actor=""):
    customer_id = int(payload.get("customer_id") or 0)
    customer = conn.execute("SELECT * FROM mc_customers WHERE id=?", (customer_id,)).fetchone()
    if not customer:
        raise ValueError("Choose a valid customer.")
    sub = None
    if payload.get("subscription_id"):
        sub = conn.execute("SELECT * FROM mc_subscriptions WHERE id=?", (int(payload["subscription_id"]),)).fetchone()
        if not sub:
            raise ValueError("Subscription not found.")
    subtotal = float(payload.get("subtotal") if payload.get("subtotal") is not None
                     else (sub["amount"] if sub else 0))
    tax_rate = float(payload.get("tax_rate") or 0)
    tax = round(subtotal * tax_rate / 100.0, 2)
    total = round(subtotal + tax, 2)
    issue = payload.get("issue_date") or _today()
    due = payload.get("due_date") or (date.today() + timedelta(days=int(payload.get("due_days") or 7))).isoformat()
    no = str(payload.get("invoice_no") or "").strip() or _next_no(conn, "INV", "mc_invoices", "invoice_no", "%Y%m")
    currency = str(payload.get("currency") or (customer["currency"] if "currency" in customer.keys() else "ZAR") or "ZAR").upper()
    if len(currency) != 3:
        raise ValueError("Currency must be a 3-letter ISO code.")
    cur = conn.execute(
        "INSERT INTO mc_invoices(invoice_no,customer_id,subscription_id,period_start,period_end,issue_date,due_date,"
        "subtotal,tax_rate,tax,total,amount_paid,balance,status,notes,currency,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (no, customer_id, (sub["id"] if sub else None), payload.get("period_start") or "",
         payload.get("period_end") or "", issue, due, subtotal, tax_rate, tax, total, 0.0, total,
         "Awaiting payment", payload.get("notes") or "", currency, _now(), _now()))
    _event(conn, actor, "Invoice created", "invoice", cur.lastrowid, f"{no} {total}")
    conn.commit()
    return get_invoice(conn, cur.lastrowid)


def get_invoice(conn, invoice_id):
    row = conn.execute("SELECT i.*,c.name customer_name,c.customer_no,c.email customer_email "
                       "FROM mc_invoices i JOIN mc_customers c ON c.id=i.customer_id WHERE i.id=?",
                       (int(invoice_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["payments"] = [dict(r) for r in conn.execute(
        "SELECT * FROM mc_payments WHERE invoice_id=? ORDER BY id DESC", (int(invoice_id),)).fetchall()]
    return item


def list_invoices(conn, customer_id=None, status=None):
    sql = "SELECT i.*,c.name customer_name,c.customer_no FROM mc_invoices i JOIN mc_customers c ON c.id=i.customer_id WHERE 1=1"
    args = []
    if customer_id:
        sql += " AND i.customer_id=?"; args.append(int(customer_id))
    if status:
        sql += " AND i.status=?"; args.append(status)
    sql += " ORDER BY i.id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def record_payment(conn, invoice_id, amount, method="Bank transfer", reference="", actor="",
                   customer_reported=False, notes=""):
    inv = conn.execute("SELECT * FROM mc_invoices WHERE id=?", (int(invoice_id),)).fetchone()
    if not inv:
        raise ValueError("Invoice not found.")
    amount = float(amount or 0)
    if amount <= 0:
        raise ValueError("Payment amount must be greater than zero.")
    status = "Reported" if customer_reported else "Pending verification"
    cur = conn.execute("INSERT INTO mc_payments(customer_id,invoice_id,amount,method,reference,status,reported_at,notes) "
                       "VALUES(?,?,?,?,?,?,?,?)",
                       (int(inv["customer_id"]), int(invoice_id), amount, method or "Bank transfer",
                        reference or "", status, _now(), notes or ""))
    conn.execute("UPDATE mc_invoices SET status=?,updated_at=? WHERE id=?",
                 ("Payment reported" if customer_reported else "Payment verification pending", _now(), int(invoice_id)))
    _event(conn, actor, "Payment recorded", "invoice", invoice_id, f"{amount} {status}")
    _alert(conn, "payment_reported", "info", inv["customer_id"], int(invoice_id), None,
           f"Payment of {amount:.2f} recorded for {inv['invoice_no']} ({status}).")
    conn.commit()
    return get_invoice(conn, invoice_id)


def verify_payment(conn, payment_id, actor="", approve=True, reason=""):
    pay = conn.execute("SELECT * FROM mc_payments WHERE id=?", (int(payment_id),)).fetchone()
    if not pay:
        raise ValueError("Payment not found.")
    if pay["status"] == "Verified":
        raise ValueError("This payment is already verified.")
    if not approve:
        conn.execute("UPDATE mc_payments SET status='Rejected',verified_by=?,verified_at=?,notes=? WHERE id=?",
                     (actor, _now(), reason or "", int(payment_id)))
        _event(conn, actor, "Payment rejected", "payment", payment_id, reason or "")
        conn.commit()
        return get_invoice(conn, int(pay["invoice_id"]))
    conn.execute("UPDATE mc_payments SET status='Verified',verified_by=?,verified_at=? WHERE id=?",
                 (actor, _now(), int(payment_id)))
    inv = conn.execute("SELECT * FROM mc_invoices WHERE id=?", (int(pay["invoice_id"]),)).fetchone()
    paid = float(inv["amount_paid"] or 0) + float(pay["amount"] or 0)
    total = float(inv["total"] or 0)
    balance = round(max(total - paid, 0), 2)
    status = "Paid" if balance <= 0.009 else ("Partially paid" if paid > 0 else inv["status"])
    conn.execute("UPDATE mc_invoices SET amount_paid=?,balance=?,status=?,updated_at=? WHERE id=?",
                 (paid, balance, status, _now(), int(inv["id"])))
    _event(conn, actor, "Payment verified", "payment", payment_id, f"{pay['amount']}")
    _alert(conn, "payment_verified", "success", inv["customer_id"], int(inv["id"]), None,
           f"Payment verified for {inv['invoice_no']}. Balance {balance:.2f}.")
    if balance <= 0.009:
        _alert(conn, "restoration_pending", "warning", inv["customer_id"], int(inv["id"]), None,
               f"{inv['invoice_no']} is fully paid. Review for restoration if the account is suspended.")
    conn.commit()
    return get_invoice(conn, int(pay["invoice_id"]))


def overdue_scan(conn):
    today = _today()
    rows = conn.execute(
        "SELECT * FROM mc_invoices WHERE due_date<? AND balance>0.009 AND status NOT IN ('Paid','Cancelled','Refunded','Disputed','Payment reported')",
        (today,)).fetchall()
    created = 0
    for inv in rows:
        conn.execute("UPDATE mc_invoices SET status='Overdue',updated_at=? WHERE id=?", (_now(), int(inv["id"])))
        exists = conn.execute(
            "SELECT id FROM mc_alerts WHERE alert_type='overdue' AND invoice_id=? AND created_at LIKE ?",
            (int(inv["id"]), today + "%")).fetchone()
        if not exists:
            days = (date.today() - date.fromisoformat(str(inv["due_date"])[:10])).days
            _alert(conn, "overdue", "warning", inv["customer_id"], int(inv["id"]), inv["subscription_id"],
                   f"{inv['invoice_no']} is {days} day(s) overdue. Outstanding {inv['balance']:.2f}. "
                   "No automatic suspension: owner decision required.")
            created += 1
    conn.commit()
    return {"checked": len(rows), "alerts_created": created}


def _alert(conn, alert_type, severity, customer_id, invoice_id, subscription_id, message):
    cur = conn.execute("INSERT INTO mc_alerts(alert_type,severity,customer_id,invoice_id,subscription_id,message,status,created_at) "
                       "VALUES(?,?,?,?,?,?,?,?)",
                       (alert_type, severity, customer_id, invoice_id, subscription_id, message, "Open", _now()))
    conn.commit()
    return cur.lastrowid


def list_alerts(conn, status="Open"):
    sql = "SELECT a.*,c.name customer_name FROM mc_alerts a LEFT JOIN mc_customers c ON c.id=a.customer_id WHERE 1=1"
    args = []
    if status:
        sql += " AND a.status=?"; args.append(status)
    sql += " ORDER BY a.id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def acknowledge_alert(conn, alert_id, actor=""):
    conn.execute("UPDATE mc_alerts SET status='Acknowledged',acknowledged_at=?,acknowledged_by=? WHERE id=?",
                 (_now(), actor or "", int(alert_id)))
    conn.commit()
    return dict(conn.execute("SELECT * FROM mc_alerts WHERE id=?", (int(alert_id),)).fetchone())


# ---------------------------------------------------------------- owner actions

def _owner_action(conn, actor, action, customer_id=None, subscription_id=None, invoice_id=None, reason=""):
    cur = conn.execute("INSERT INTO mc_owner_actions(actor,action,customer_id,subscription_id,invoice_id,reason,step_up_confirmed,created_at) "
                       "VALUES(?,?,?,?,?,?,?,?)",
                       (actor, action, customer_id, subscription_id, invoice_id, reason or "", 1, _now()))
    _event(conn, actor, action, "customer" if customer_id else "system",
           customer_id or subscription_id or invoice_id or "", reason or "")
    conn.commit()
    return cur.lastrowid


def suspend(conn, customer_id, subscription_id=None, actor="", reason="", scope="all"):
    if not str(reason or "").strip():
        raise ValueError("A reason is required for suspension.")
    cust = conn.execute("SELECT * FROM mc_customers WHERE id=?", (int(customer_id),)).fetchone()
    if not cust:
        raise ValueError("Customer not found.")
    if scope == "all":
        conn.execute("UPDATE mc_subscriptions SET status='Suspended',updated_at=? WHERE customer_id=? AND status='Active'",
                     (_now(), int(customer_id)))
        conn.execute("UPDATE mc_customers SET status='Suspended',updated_at=? WHERE id=?", (_now(), int(customer_id)))
        revoke_entitlements(conn, customer_id=int(customer_id), reason=reason)
        affected = [r["id"] for r in conn.execute("SELECT id FROM mc_subscriptions WHERE customer_id=?", (int(customer_id),)).fetchall()]
    else:
        if not subscription_id:
            raise ValueError("Choose the subscription to suspend.")
        conn.execute("UPDATE mc_subscriptions SET status='Suspended',updated_at=? WHERE id=?", (_now(), int(subscription_id)))
        revoke_entitlements(conn, subscription_id=int(subscription_id), reason=reason)
        affected = [int(subscription_id)]
    _owner_action(conn, actor, "SUSPEND", int(customer_id), subscription_id, None, reason)
    _alert(conn, "suspended", "warning", int(customer_id), None, subscription_id,
           f"Service suspended by {actor}. Reason: {reason}")
    return {"customer": get_customer(conn, customer_id), "affected_subscriptions": affected}


def restore(conn, customer_id, subscription_id=None, actor="", reason="", scope="all"):
    if not str(reason or "").strip():
        raise ValueError("A reason is required for restoration.")
    if scope == "all":
        conn.execute("UPDATE mc_customers SET status='Active',updated_at=? WHERE id=?", (_now(), int(customer_id)))
        subs = conn.execute("SELECT id FROM mc_subscriptions WHERE customer_id=? AND status='Suspended'",
                            (int(customer_id),)).fetchall()
    else:
        if not subscription_id:
            raise ValueError("Choose the subscription to restore.")
        subs = conn.execute("SELECT id FROM mc_subscriptions WHERE id=? AND status='Suspended'",
                            (int(subscription_id),)).fetchall()
    issued = []
    for sub in subs:
        conn.execute("UPDATE mc_subscriptions SET status='Active',updated_at=? WHERE id=?", (_now(), int(sub["id"])))
        try:
            issued.append(issue_entitlement(conn, int(customer_id), int(sub["id"])))
        except Exception:
            pass
    _owner_action(conn, actor, "RESTORE", int(customer_id), subscription_id, None, reason)
    _alert(conn, "restored", "success", int(customer_id), None, subscription_id,
           f"Service restored by {actor}. Reason: {reason}")
    conn.commit()
    return {"customer": get_customer(conn, customer_id), "entitlements": issued}


def owner_centre(conn):
    def scalar(sql, args=()):
        return conn.execute(sql, args).fetchone()[0]

    mrr = float(scalar("SELECT COALESCE(SUM(amount),0) FROM mc_subscriptions WHERE status='Active' AND billing_period='Monthly'") or 0)
    annual = float(scalar("SELECT COALESCE(SUM(amount),0) FROM mc_subscriptions WHERE status='Active' AND billing_period='Annual'") or 0)
    mrr += annual / 12.0
    return {
        "customers_total": int(scalar("SELECT COUNT(*) FROM mc_customers") or 0),
        "customers_active": int(scalar("SELECT COUNT(*) FROM mc_customers WHERE status='Active'") or 0),
        "customers_suspended": int(scalar("SELECT COUNT(*) FROM mc_customers WHERE status='Suspended'") or 0),
        "subscriptions_active": int(scalar("SELECT COUNT(*) FROM mc_subscriptions WHERE status='Active'") or 0),
        "subscriptions_suspended": int(scalar("SELECT COUNT(*) FROM mc_subscriptions WHERE status='Suspended'") or 0),
        "mrr": round(mrr, 2),
        "arr": round(mrr * 12, 2),
        "outstanding": round(float(scalar("SELECT COALESCE(SUM(balance),0) FROM mc_invoices WHERE status NOT IN ('Paid','Cancelled','Refunded')") or 0), 2),
        "overdue": int(scalar("SELECT COUNT(*) FROM mc_invoices WHERE status='Overdue'") or 0),
        "overdue_value": round(float(scalar("SELECT COALESCE(SUM(balance),0) FROM mc_invoices WHERE status='Overdue'") or 0), 2),
        "payments_pending": int(scalar("SELECT COUNT(*) FROM mc_payments WHERE status IN ('Reported','Pending verification')") or 0),
        "payments_received": round(float(scalar("SELECT COALESCE(SUM(amount),0) FROM mc_payments WHERE status='Verified'") or 0), 2),
        "restoration_pending": int(scalar("SELECT COUNT(*) FROM mc_alerts WHERE alert_type='restoration_pending' AND status='Open'") or 0),
        "suspension_pending": int(scalar("SELECT COUNT(*) FROM mc_alerts WHERE alert_type='overdue' AND status='Open'") or 0),
        "alerts_open": int(scalar("SELECT COUNT(*) FROM mc_alerts WHERE status='Open'") or 0),
        "products": PRODUCTS,
        "public_key": public_key_b64(),
    }


def report(conn, date_from="", date_to=""):
    args = []
    where = "1=1"
    if date_from:
        where += " AND issue_date>=?"; args.append(date_from)
    if date_to:
        where += " AND issue_date<=?"; args.append(date_to)
    rows = conn.execute(
        f"SELECT status,COUNT(*) n,COALESCE(SUM(total),0) total,COALESCE(SUM(balance),0) balance "
        f"FROM mc_invoices WHERE {where} GROUP BY status", args).fetchall()
    by_product = conn.execute(
        "SELECT product,COUNT(*) subscriptions,COALESCE(SUM(amount),0) value FROM mc_subscriptions "
        "WHERE status='Active' GROUP BY product ORDER BY value DESC").fetchall()
    return {
        "invoices_by_status": [dict(r) for r in rows],
        "active_by_product": [dict(r) for r in by_product],
        "suspended_accounts": int(conn.execute("SELECT COUNT(*) FROM mc_customers WHERE status='Suspended'").fetchone()[0]),
        "cancelled_agreements": int(conn.execute("SELECT COUNT(*) FROM mc_subscriptions WHERE status='Cancelled'").fetchone()[0]),
    }
def list_currencies(conn):
    rows = conn.execute("SELECT * FROM mc_exchange_rates ORDER BY base_currency, quote_currency").fetchall()
    return [dict(r) for r in rows]

def set_exchange_rate(conn, base_currency, quote_currency, rate, actor=""):
    base = str(base_currency or "").upper()
    quote = str(quote_currency or "").upper()
    if len(base) != 3 or len(quote) != 3:
        raise ValueError("Currency codes must be 3 letters.")
    r = float(rate)
    if r <= 0:
        raise ValueError("Rate must be positive.")
    conn.execute("INSERT INTO mc_exchange_rates(base_currency,quote_currency,rate,updated_at,updated_by) VALUES(?,?,?,?,?) "
                 "ON CONFLICT(base_currency,quote_currency) DO UPDATE SET rate=excluded.rate, updated_at=excluded.updated_at, updated_by=excluded.updated_by",
                 (base, quote, r, _now(), actor or ""))
    conn.commit()
    _event(conn, actor, "Exchange rate updated", "exchange_rate", f"{base}/{quote}", f"{r}")
    return {"base_currency": base, "quote_currency": quote, "rate": r}

def convert_amount(conn, amount, from_currency, to_currency):
    fc = str(from_currency or "").upper()
    tc = str(to_currency or "").upper()
    if fc == tc:
        return float(amount)
    row = conn.execute("SELECT rate FROM mc_exchange_rates WHERE base_currency=? AND quote_currency=?", (fc, tc)).fetchone()
    if not row:
        raise ValueError(f"No exchange rate for {fc}->{tc}.")
    return round(float(amount) * float(row["rate"]), 2)

def build_customer_statement(conn, customer_id, date_from=None, date_to=None):
    cust = conn.execute("SELECT * FROM mc_customers WHERE id=?", (int(customer_id),)).fetchone()
    if not cust:
        raise ValueError("Customer not found.")
    cust = dict(cust)
    currency = cust.get("currency") or "ZAR"
    inv_sql = "SELECT * FROM mc_invoices WHERE customer_id=?"
    args = [int(customer_id)]
    if date_from:
        inv_sql += " AND issue_date>=?"; args.append(date_from)
    if date_to:
        inv_sql += " AND issue_date<=?"; args.append(date_to)
    inv_sql += " ORDER BY issue_date, id"
    invoices = [dict(r) for r in conn.execute(inv_sql, args).fetchall()]
    pay_sql = "SELECT p.*, i.invoice_no FROM mc_payments p JOIN mc_invoices i ON i.id=p.invoice_id WHERE i.customer_id=? AND p.status='Verified'"
    pargs = [int(customer_id)]
    if date_from:
        pay_sql += " AND p.reported_at>=?"; pargs.append(date_from)
    if date_to:
        pay_sql += " AND p.reported_at<=?"; pargs.append(date_to)
    pay_sql += " ORDER BY p.reported_at, p.id"
    payments = [dict(r) for r in conn.execute(pay_sql, pargs).fetchall()]
    ledger = []
    for inv in invoices:
        ledger.append({"date": inv.get("issue_date"), "type": "Invoice", "reference": inv.get("invoice_no"), "debit": float(inv.get("total") or 0), "credit": 0.0})
    for pay in payments:
        ledger.append({"date": str(pay.get("reported_at") or "")[:10], "type": "Payment", "reference": pay.get("invoice_no"), "debit": 0.0, "credit": float(pay.get("amount") or 0)})
    ledger.sort(key=lambda x: (x["date"] or "", ))
    opening = 0.0
    balance = opening
    for e in ledger:
        balance = round(balance + e["debit"] - e["credit"], 2)
        e["balance"] = balance
    closing = balance
    from datetime import date as _date, datetime as _dt
    today = _date.today()
    buckets = {"current": 0.0, "days_30": 0.0, "days_60": 0.0, "days_90_plus": 0.0}
    for inv in invoices:
        bal = float(inv.get("balance") or 0)
        if bal <= 0:
            continue
        due = inv.get("due_date") or inv.get("issue_date")
        try:
            due_d = _dt.fromisoformat(due).date()
        except Exception:
            due_d = today
        age = (today - due_d).days
        if age <= 0:
            buckets["current"] = round(buckets["current"] + bal, 2)
        elif age <= 30:
            buckets["days_30"] = round(buckets["days_30"] + bal, 2)
        elif age <= 60:
            buckets["days_60"] = round(buckets["days_60"] + bal, 2)
        else:
            buckets["days_90_plus"] = round(buckets["days_90_plus"] + bal, 2)
    return {
        "customer": cust,
        "currency": currency,
        "date_from": date_from,
        "date_to": date_to,
        "opening_balance": opening,
        "ledger": ledger,
        "closing_balance": closing,
        "aging": buckets,
    }

def render_customer_statement_pdf(conn, customer_id, date_from=None, date_to=None):
    import io
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    stmt = build_customer_statement(conn, customer_id, date_from, date_to)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph("BEYOND MASTER CONTROL - CUSTOMER STATEMENT", styles["Title"]))
    story.append(Paragraph("Currency: " + stmt["currency"], styles["Normal"]))
    c = stmt["customer"]
    story.append(Paragraph("Customer: " + str(c.get("name")) + " (" + str(c.get("customer_no")) + ")", styles["Normal"]))
    story.append(Paragraph("Period: " + str(stmt["date_from"] or "start") + " to " + str(stmt["date_to"] or "today"), styles["Normal"]))
    story.append(Spacer(1, 12))
    data = [["Date", "Type", "Reference", "Debit", "Credit", "Balance"]]
    for e in stmt["ledger"]:
        data.append([str(e["date"] or ""), e["type"], str(e["reference"] or ""), f"{e['debit']:.2f}", f"{e['credit']:.2f}", f"{e['balance']:.2f}"])
    data.append(["", "", "Closing balance", "", "", f"{stmt['closing_balance']:.2f}"])
    t = Table(data)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                           ("GRID", (0, 0), (-1, -1), 0.5, colors.black)]))
    story.append(t)
    story.append(Spacer(1, 12))
    story.append(Paragraph("Aging: " + ", ".join(f"{k}={v}" for k, v in stmt["aging"].items()), styles["Normal"]))
    doc.build(story)
    buf.seek(0)
    return buf.read()
