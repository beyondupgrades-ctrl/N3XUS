"""Employee resource requests, approvals, procurement and asset allocation.

100% in-house. Uses the existing N3XUS employees, inventory, notifications and
audit services. No external service or paid API.
"""
from __future__ import annotations

from datetime import date, datetime
import json

import inventory
import notifications

SCHEMA = """
CREATE TABLE IF NOT EXISTS resource_requests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  employee_id INTEGER,
  employee_no TEXT DEFAULT '',
  employee_name TEXT DEFAULT '',
  department TEXT DEFAULT '',
  position TEXT DEFAULT '',
  category TEXT DEFAULT 'General',
  item TEXT NOT NULL,
  description TEXT DEFAULT '',
  specifications TEXT DEFAULT '',
  quantity REAL NOT NULL DEFAULT 1,
  size TEXT DEFAULT '',
  reason TEXT DEFAULT '',
  priority TEXT DEFAULT 'Normal',
  needed_by TEXT DEFAULT '',
  delivery_pref TEXT DEFAULT 'Collection',
  status TEXT NOT NULL DEFAULT 'Submitted',
  estimated_cost REAL NOT NULL DEFAULT 0,
  approved_cost REAL NOT NULL DEFAULT 0,
  budget_code TEXT DEFAULT '',
  stock_item_id INTEGER,
  asset_id INTEGER,
  procurement_id INTEGER,
  current_approver TEXT DEFAULT '',
  created_by TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  decided_by TEXT DEFAULT '',
  decided_at TEXT DEFAULT '',
  decline_reason TEXT DEFAULT '',
  info_request TEXT DEFAULT '',
  fulfilled_at TEXT DEFAULT '',
  notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS resource_request_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL,
  action TEXT NOT NULL, actor TEXT DEFAULT '', detail TEXT DEFAULT '',
  created_at TEXT NOT NULL, FOREIGN KEY(request_id) REFERENCES resource_requests(id));
CREATE TABLE IF NOT EXISTS resource_request_settings(
  key TEXT PRIMARY KEY, value TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS resource_approval_rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT, department TEXT DEFAULT '',
  min_amount REAL NOT NULL DEFAULT 0, max_amount REAL NOT NULL DEFAULT 1000000000,
  approver_role TEXT NOT NULL DEFAULT 'Manager', active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS resource_procurement(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ref TEXT NOT NULL UNIQUE,
  request_id INTEGER NOT NULL, supplier TEXT DEFAULT '', status TEXT DEFAULT 'Awaiting order',
  total REAL NOT NULL DEFAULT 0, ordered_at TEXT DEFAULT '', expected_at TEXT DEFAULT '',
  received_at TEXT DEFAULT '', notes TEXT DEFAULT '',
  FOREIGN KEY(request_id) REFERENCES resource_requests(id));
CREATE TABLE IF NOT EXISTS resource_assets(
  id INTEGER PRIMARY KEY AUTOINCREMENT, asset_no TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL, serial_no TEXT DEFAULT '', employee_id INTEGER,
  employee_name TEXT DEFAULT '', request_id INTEGER,
  issue_date TEXT DEFAULT '', condition TEXT DEFAULT 'New',
  warranty_until TEXT DEFAULT '', replacement_due TEXT DEFAULT '',
  acknowledged_at TEXT DEFAULT '', acknowledged_by TEXT DEFAULT '',
  returned_at TEXT DEFAULT '', return_condition TEXT DEFAULT '',
  notes TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_rr_employee ON resource_requests(employee_id);
CREATE INDEX IF NOT EXISTS idx_rr_status ON resource_requests(status);
"""

STATUSES = ["Draft", "Submitted", "Awaiting approval", "Additional information required",
            "Approved", "Declined", "Awaiting procurement", "Ordered", "Partially fulfilled",
            "Ready for collection", "Delivered", "Completed", "Cancelled"]

CATEGORIES = ["Safety footwear", "Uniforms & protective clothing", "Safety equipment & PPE",
              "Tools & machinery", "Computers & monitors", "Mobile phones & accessories",
              "Stationery & office supplies", "Software & application access",
              "Equipment repairs & replacements", "Office furniture", "Vehicle equipment",
              "Other work-related resources"]


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _today() -> str:
    return date.today().isoformat()


def ensure_schema(conn) -> None:
    conn.executescript(SCHEMA)
    if conn.execute("SELECT COUNT(*) c FROM resource_approval_rules").fetchone()["c"] == 0:
        conn.executemany(
            "INSERT INTO resource_approval_rules(department,min_amount,max_amount,approver_role,active) VALUES(?,?,?,?,1)",
            [("", 0, 5000, "Manager"), ("", 5000, 1000000000, "Administrator")])
    conn.execute("INSERT OR IGNORE INTO resource_request_settings(key,value) VALUES('allow_self_approval','no')")
    conn.execute("INSERT OR IGNORE INTO resource_request_settings(key,value) VALUES('employee_collection_note','Collect from the stores office with your employee card.')")
    conn.commit()


def _next_ref(conn, prefix: str, table: str, column: str) -> str:
    day = date.today().strftime("%Y%m%d")
    row = conn.execute(f"SELECT COUNT(*) c FROM {table} WHERE {column} LIKE ?", (f"{prefix}-{day}-%",)).fetchone()
    return f"{prefix}-{day}-{int(row['c']) + 1:04d}"


def _employee(conn, employee_id):
    if not employee_id:
        return None
    return conn.execute(
        "SELECT id,employee_no,first_name,last_name,job_title,department,email "
        "FROM employees WHERE id=?", (int(employee_id),)).fetchone()


def _event(conn, request_id, action, actor="", detail=""):
    conn.execute("INSERT INTO resource_request_events(request_id,action,actor,detail,created_at) "
                 "VALUES(?,?,?,?,?)", (int(request_id), action, actor or "", detail or "", _now()))


def _notify(conn, recipient, title, body="", level="info"):
    try:
        notifications.push(conn, recipient or "management", title, body, level)
    except Exception:
        pass


def approver_for(conn, department="", amount=0):
    row = conn.execute(
        "SELECT approver_role FROM resource_approval_rules WHERE active=1 "
        "AND min_amount<=? AND max_amount>=? AND (department='' OR department=?) "
        "ORDER BY CASE WHEN department='' THEN 1 ELSE 0 END, max_amount ASC LIMIT 1",
        (float(amount or 0), float(amount or 0), department or "")).fetchone()
    return row["approver_role"] if row else "Manager"


def create_request(conn, payload, actor=""):
    employee_id = int(payload.get("employee_id") or 0) or None
    emp = _employee(conn, employee_id)
    item = str(payload.get("item") or "").strip()
    if not item:
        raise ValueError("Describe the item or service you are requesting.")
    if not emp and not str(payload.get("employee_name") or "").strip():
        raise ValueError("Choose an employee or provide a name.")
    qty = float(payload.get("quantity") or 1)
    if qty <= 0:
        raise ValueError("Quantity must be greater than zero.")
    status = "Draft" if str(payload.get("draft") or "").lower() in ("1", "true", "yes") else "Submitted"
    name = (f"{emp['first_name']} {emp['last_name']}".strip() if emp else str(payload.get("employee_name") or "").strip())
    ref = _next_ref(conn, "RR", "resource_requests", "ref")
    est = float(payload.get("estimated_cost") or 0)
    approver = approver_for(conn, emp["department"] if emp else payload.get("department"), est)
    cur = conn.execute(
        "INSERT INTO resource_requests(ref,employee_id,employee_no,employee_name,department,position,category,item,"
        "description,specifications,quantity,size,reason,priority,needed_by,delivery_pref,status,estimated_cost,"
        "approved_cost,budget_code,current_approver,created_by,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (ref, employee_id, (emp["employee_no"] if emp else payload.get("employee_no")) or "",
         name, (emp["department"] if emp else payload.get("department")) or "",
         (emp["job_title"] if emp else payload.get("position")) or "",
         str(payload.get("category") or "General"), item, str(payload.get("description") or ""),
         str(payload.get("specifications") or ""), qty, str(payload.get("size") or ""),
         str(payload.get("reason") or ""), str(payload.get("priority") or "Normal"),
         str(payload.get("needed_by") or ""), str(payload.get("delivery_pref") or "Collection"),
         status, est, 0.0, str(payload.get("budget_code") or ""), approver, actor or "", _now(), _now()))
    rid = cur.lastrowid
    _event(conn, rid, "Created", actor, f"{ref} - {item}")
    if status == "Submitted":
        _event(conn, rid, "Submitted", actor, f"Routed to {approver}")
        _notify(conn, "management", f"New resource request {ref}",
                f"{name} requested {qty:g} x {item}. Approver: {approver}.", "info")
        if emp and emp["email"]:
            _notify(conn, emp["employee_no"], f"Request {ref} submitted",
                    f"Your request for {item} was submitted and is awaiting approval.", "info")
    conn.commit()
    return get_request(conn, rid)


def list_requests(conn, employee_id=None, status=None, department=None, search="", limit=200):
    sql = "SELECT * FROM resource_requests WHERE 1=1"
    args = []
    if employee_id:
        sql += " AND employee_id=?"; args.append(int(employee_id))
    if status:
        sql += " AND status=?"; args.append(status)
    if department:
        sql += " AND department=?"; args.append(department)
    if search:
        sql += " AND (ref LIKE ? OR item LIKE ? OR employee_name LIKE ?)"
        like = f"%{search}%"; args += [like, like, like]
    sql += " ORDER BY id DESC LIMIT ?"; args.append(int(limit))
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def get_request(conn, rid):
    row = conn.execute("SELECT * FROM resource_requests WHERE id=?", (int(rid),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["events"] = [dict(r) for r in conn.execute(
        "SELECT * FROM resource_request_events WHERE request_id=? ORDER BY id", (int(rid),)).fetchall()]
    item["asset"] = None
    if item.get("asset_id"):
        a = conn.execute("SELECT * FROM resource_assets WHERE id=?", (int(item["asset_id"]),)).fetchone()
        item["asset"] = dict(a) if a else None
    item["procurement"] = None
    if item.get("procurement_id"):
        p = conn.execute("SELECT * FROM resource_procurement WHERE id=?", (int(item["procurement_id"]),)).fetchone()
        item["procurement"] = dict(p) if p else None
    return item


def _self_approval_allowed(conn):
    row = conn.execute("SELECT value FROM resource_request_settings WHERE key='allow_self_approval'").fetchone()
    return bool(row and str(row["value"]).lower() in ("yes", "1", "true"))


def _stock_match(conn, req):
    sku = str(req.get("specifications") or "").strip()
    row = conn.execute(
        "SELECT * FROM inventory_items WHERE (sku!='' AND sku=?) OR lower(name)=lower(?) ORDER BY id LIMIT 1",
        (sku, req.get("item") or "")).fetchone()
    return row


def decide(conn, rid, decision, actor, actor_role="Manager", reason="", approved_cost=None,
           self_authorised=False):
    req = conn.execute("SELECT * FROM resource_requests WHERE id=?", (int(rid),)).fetchone()
    if not req:
        raise ValueError("Request not found.")
    req = dict(req)
    if req["status"] not in ("Submitted", "Awaiting approval", "Additional information required", "Approved"):
        raise ValueError(f"This request is already {req['status']}.")
    decision = str(decision or "").strip()
    if actor and req["created_by"] and actor == req["created_by"] and not (self_authorised or _self_approval_allowed(conn)):
        raise PermissionError("You cannot approve your own request unless self-approval is authorised in settings.")
    if decision == "Declined":
        if not str(reason or "").strip():
            raise ValueError("A reason is required when declining a request.")
        conn.execute("UPDATE resource_requests SET status='Declined',decided_by=?,decided_at=?,decline_reason=?,updated_at=? WHERE id=?",
                     (actor, _now(), reason, _now(), int(rid)))
        _event(conn, rid, "Declined", actor, reason)
        _notify(conn, req["employee_no"] or "management", f"Request {req['ref']} declined",
                f"{req['item']} was declined. Reason: {reason}", "warning")
        conn.commit()
        return get_request(conn, rid)
    if decision == "Additional information required":
        if not str(reason or "").strip():
            raise ValueError("Describe the additional information required.")
        conn.execute("UPDATE resource_requests SET status='Additional information required',current_approver=?,info_request=?,updated_at=? WHERE id=?",
                     (actor, reason, _now(), int(rid)))
        _event(conn, rid, "Additional information requested", actor, reason)
        _notify(conn, req["employee_no"] or "management", f"Information needed for {req['ref']}",
                reason, "warning")
        conn.commit()
        return get_request(conn, rid)
    if decision != "Approved":
        raise ValueError("Decision must be Approved, Declined or Additional information required.")

    cost = float(approved_cost if approved_cost is not None else (req.get("approved_cost") or req.get("estimated_cost") or 0))
    stock = _stock_match(conn, req)
    if stock and float(stock["qty_on_hand"] or 0) >= float(req["quantity"] or 0):
        inventory.adjust_stock(conn, int(stock["id"]), -float(req["quantity"]), "reserved",
                               f"Resource request {req['ref']}")
        conn.execute("UPDATE resource_requests SET status='Ready for collection',decided_by=?,decided_at=?,approved_cost=?,stock_item_id=?,updated_at=? WHERE id=?",
                     (actor, _now(), cost, int(stock["id"]), _now(), int(rid)))
        _event(conn, rid, "Approved from stock", actor, f"Reserved {req['quantity']:g} from {stock['name']}")
        _notify(conn, req["employee_no"] or "management", f"Request {req['ref']} approved",
                f"{req['item']} is ready for collection. Stock was reserved for you.", "success")
        conn.commit()
        return get_request(conn, rid)

    ref = _next_ref(conn, "PO", "resource_procurement", "ref")
    cur = conn.execute("INSERT INTO resource_procurement(ref,request_id,supplier,status,total,notes) VALUES(?,?,?,?,?,?)",
                       (ref, int(rid), "", "Awaiting order", cost, "Created automatically after approval."))
    conn.execute("UPDATE resource_requests SET status='Awaiting procurement',decided_by=?,decided_at=?,approved_cost=?,procurement_id=?,updated_at=? WHERE id=?",
                 (actor, _now(), cost, cur.lastrowid, _now(), int(rid)))
    _event(conn, rid, "Approved - procurement required", actor, f"Procurement {ref}")
    _notify(conn, "procurement", f"Procurement required {ref}",
            f"{req['quantity']:g} x {req['item']} for {req['employee_name']} ({req['department']}).", "info")
    _notify(conn, req["employee_no"] or "management", f"Request {req['ref']} approved",
            f"{req['item']} was approved and is being procured.", "success")
    conn.commit()
    return get_request(conn, rid)


def provide_information(conn, rid, actor, detail):
    if not str(detail or "").strip():
        raise ValueError("Add the requested information before resubmitting.")
    conn.execute("UPDATE resource_requests SET status='Awaiting approval',notes=?,updated_at=? WHERE id=?",
                 (detail, _now(), int(rid)))
    _event(conn, rid, "Information supplied", actor, detail)
    conn.commit()
    return get_request(conn, rid)


def order_procurement(conn, rid, supplier, total, expected_at="", actor="", notes=""):
    req = conn.execute("SELECT * FROM resource_requests WHERE id=?", (int(rid),)).fetchone()
    if not req or not req["procurement_id"]:
        raise ValueError("This request has no procurement record.")
    conn.execute("UPDATE resource_procurement SET supplier=?,total=?,status='Ordered',ordered_at=?,expected_at=?,notes=? WHERE id=?",
                 (supplier or "", float(total or 0), _today(), expected_at or "", notes or "", int(req["procurement_id"])))
    conn.execute("UPDATE resource_requests SET status='Ordered',approved_cost=?,updated_at=? WHERE id=?",
                 (float(total or 0), _now(), int(rid)))
    _event(conn, rid, "Ordered", actor, f"{supplier} - {total}")
    _notify(conn, req["employee_no"] or "management", f"Request {req['ref']} ordered",
            f"{req['item']} was ordered from {supplier or 'supplier'}.", "info")
    conn.commit()
    return get_request(conn, rid)


def receive_procurement(conn, rid, supplier="", total=None, actor="", notes=""):
    req = conn.execute("SELECT * FROM resource_requests WHERE id=?", (int(rid),)).fetchone()
    if not req or not req["procurement_id"]:
        raise ValueError("This request has no procurement record.")
    po = conn.execute("SELECT * FROM resource_procurement WHERE id=?", (int(req["procurement_id"]),)).fetchone()
    amount = float(total if total is not None else (po["total"] or 0))
    conn.execute("UPDATE resource_procurement SET status='Received',received_at=?,supplier=COALESCE(NULLIF(?, ''),supplier),total=?,notes=COALESCE(NULLIF(?, ''),notes) WHERE id=?",
                 (_today(), supplier or "", amount, notes or "", int(po["id"])))
    stock = _stock_match(conn, dict(req))
    if stock:
        inventory.adjust_stock(conn, int(stock["id"]), float(req["quantity"]), "received",
                               f"Resource request {req['ref']}")
        stock_id = int(stock["id"])
    else:
        stock_id = inventory.save_item(conn, req["item"], f"RR-{req['ref']}", "Stores",
                                       float(req["quantity"]), 0, "each", amount / max(float(req["quantity"]), 1))
    conn.execute("UPDATE resource_requests SET status='Ready for collection',stock_item_id=?,approved_cost=?,updated_at=? WHERE id=?",
                 (stock_id, amount, _now(), int(rid)))
    _event(conn, rid, "Procurement received", actor, f"{amount}")
    _notify(conn, req["employee_no"] or "management", f"Request {req['ref']} ready",
            f"{req['item']} has arrived and is ready for collection.", "success")
    conn.commit()
    return get_request(conn, rid)


def allocate_asset(conn, rid, payload, actor=""):
    req = conn.execute("SELECT * FROM resource_requests WHERE id=?", (int(rid),)).fetchone()
    if not req:
        raise ValueError("Request not found.")
    req = dict(req)
    asset_no = str(payload.get("asset_no") or "").strip() or _next_ref(conn, "AST", "resource_assets", "asset_no")
    cur = conn.execute(
        "INSERT INTO resource_assets(asset_no,description,serial_no,employee_id,employee_name,request_id,"
        "issue_date,condition,warranty_until,replacement_due,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (asset_no, payload.get("description") or req["item"], payload.get("serial_no") or "",
         req.get("employee_id"), req.get("employee_name") or "", int(rid), payload.get("issue_date") or _today(),
         payload.get("condition") or "New", payload.get("warranty_until") or "",
         payload.get("replacement_due") or "", payload.get("notes") or "", _now()))
    aid = cur.lastrowid
    conn.execute("UPDATE resource_requests SET status='Delivered',asset_id=?,fulfilled_at=?,updated_at=? WHERE id=?",
                 (aid, _now(), _now(), int(rid)))
    _event(conn, rid, "Asset allocated", actor, f"{asset_no} issued to {req.get('employee_name')}")
    _notify(conn, req.get("employee_no") or "management", f"Equipment issued {asset_no}",
            f"{req['item']} was issued to you. Please acknowledge receipt in the portal.", "success")
    conn.commit()
    return {"request": get_request(conn, rid), "asset_id": aid, "asset_no": asset_no}


def acknowledge_asset(conn, asset_id, actor="", employee_id=None):
    row = conn.execute("SELECT * FROM resource_assets WHERE id=?", (int(asset_id),)).fetchone()
    if not row:
        raise ValueError("Asset not found.")
    if employee_id and row["employee_id"] and int(row["employee_id"]) != int(employee_id):
        raise PermissionError("This asset is not allocated to you.")
    conn.execute("UPDATE resource_assets SET acknowledged_at=?,acknowledged_by=? WHERE id=?",
                 (_now(), actor or row["employee_name"], int(asset_id)))
    if row["request_id"]:
        _event(conn, row["request_id"], "Receipt acknowledged", actor, row["asset_no"])
    conn.commit()
    return dict(conn.execute("SELECT * FROM resource_assets WHERE id=?", (int(asset_id),)).fetchone())


def return_asset(conn, asset_id, condition="", actor=""):
    conn.execute("UPDATE resource_assets SET returned_at=?,return_condition=? WHERE id=?",
                 (_today(), condition or "", int(asset_id)))
    row = conn.execute("SELECT * FROM resource_assets WHERE id=?", (int(asset_id),)).fetchone()
    if row and row["request_id"]:
        _event(conn, row["request_id"], "Asset returned", actor, condition or "")
    conn.commit()
    return dict(row) if row else None


def complete_request(conn, rid, actor=""):
    conn.execute("UPDATE resource_requests SET status='Completed',fulfilled_at=COALESCE(NULLIF(fulfilled_at,''),?),updated_at=? WHERE id=?",
                 (_now(), _now(), int(rid)))
    _event(conn, rid, "Completed", actor, "")
    conn.commit()
    return get_request(conn, rid)


def cancel_request(conn, rid, actor="", reason=""):
    conn.execute("UPDATE resource_requests SET status='Cancelled',notes=?,updated_at=? WHERE id=?",
                 (reason or "", _now(), int(rid)))
    _event(conn, rid, "Cancelled", actor, reason or "")
    conn.commit()
    return get_request(conn, rid)


def list_assets(conn, employee_id=None):
    if employee_id:
        rows = conn.execute("SELECT * FROM resource_assets WHERE employee_id=? ORDER BY id DESC", (int(employee_id),)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM resource_assets ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]


def report(conn):
    def count(where="1=1", args=()):
        return int(conn.execute(f"SELECT COUNT(*) c FROM resource_requests WHERE {where}", args).fetchone()["c"])
    total = count()
    by_status = {r["status"]: int(r["c"]) for r in conn.execute(
        "SELECT status,COUNT(*) c FROM resource_requests GROUP BY status").fetchall()}
    by_department = [dict(r) for r in conn.execute(
        "SELECT COALESCE(NULLIF(department,''),'Unassigned') department,COUNT(*) requests,"
        "ROUND(SUM(COALESCE(approved_cost,0)),2) approved_value "
        "FROM resource_requests GROUP BY department ORDER BY requests DESC").fetchall()]
    avg = conn.execute(
        "SELECT AVG((julianday(decided_at)-julianday(created_at))*24) h FROM resource_requests "
        "WHERE decided_at!=''").fetchone()["h"]
    return {
        "total": total,
        "pending": count("status IN ('Submitted','Awaiting approval','Additional information required')"),
        "approved": count("status IN ('Approved','Awaiting procurement','Ordered','Partially fulfilled','Ready for collection','Delivered','Completed')"),
        "declined": count("status='Declined'"),
        "awaiting_procurement": count("status='Awaiting procurement'"),
        "outstanding_delivery": count("status IN ('Ordered','Partially fulfilled')"),
        "by_status": by_status,
        "by_department": by_department,
        "approved_spend": float(conn.execute("SELECT COALESCE(SUM(approved_cost),0) v FROM resource_requests WHERE status NOT IN ('Declined','Cancelled','Draft')").fetchone()["v"]),
        "assets_issued": int(conn.execute("SELECT COUNT(*) c FROM resource_assets").fetchone()["c"]),
        "assets_outstanding": int(conn.execute("SELECT COUNT(*) c FROM resource_assets WHERE returned_at=''").fetchone()["c"]),
        "unacknowledged_assets": int(conn.execute("SELECT COUNT(*) c FROM resource_assets WHERE acknowledged_at='' AND returned_at=''").fetchone()["c"]),
        "avg_approval_hours": round(float(avg or 0), 1),
        "low_stock": len(inventory.low_stock(conn)),
        "categories": CATEGORIES,
    }
