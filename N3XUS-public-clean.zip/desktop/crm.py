"""CRM / lead & opportunity pipeline (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS crm_leads(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, company TEXT DEFAULT '',
  email TEXT DEFAULT '', phone TEXT DEFAULT '', source TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'New', notes TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS crm_opportunities(
  id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, title TEXT NOT NULL,
  stage TEXT NOT NULL DEFAULT 'Prospect', value REAL DEFAULT 0, close_date TEXT DEFAULT '',
  notes TEXT DEFAULT '', created_at TEXT NOT NULL,
  FOREIGN KEY(lead_id) REFERENCES crm_leads(id));
CREATE TABLE IF NOT EXISTS crm_activities(
  id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, opp_id INTEGER,
  activity_type TEXT NOT NULL, notes TEXT DEFAULT '', created_at TEXT NOT NULL);
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_leads(conn, status=None):
    sql = "SELECT * FROM crm_leads"
    args = []
    if status:
        sql += " WHERE status=?"; args.append(status)
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def save_lead(conn, name, company="", email="", phone="", source="", notes=""):
    cur = conn.execute("INSERT INTO crm_leads(name,company,email,phone,source,notes,created_at) VALUES(?,?,?,?,?,?,?)",
                       (name, company, email, phone, source, notes, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def list_opportunities(conn, stage=None):
    sql = "SELECT * FROM crm_opportunities"
    args = []
    if stage:
        sql += " WHERE stage=?"; args.append(stage)
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def save_opportunity(conn, title, lead_id=None, stage="Prospect", value=0, close_date="", notes=""):
    cur = conn.execute("INSERT INTO crm_opportunities(lead_id,title,stage,value,close_date,notes,created_at) VALUES(?,?,?,?,?,?,?)",
                       (lead_id, title, stage, float(value), close_date, notes, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def log_activity(conn, activity_type, notes="", lead_id=None, opp_id=None):
    conn.execute("INSERT INTO crm_activities(lead_id,opp_id,activity_type,notes,created_at) VALUES(?,?,?,?,?)",
                 (lead_id, opp_id, activity_type, notes, date.today().isoformat()))
    conn.commit()