"""Document management with versioning (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS dm_documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT DEFAULT 'General',
  current_version INTEGER NOT NULL DEFAULT 1, created_by TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS dm_versions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, version INTEGER NOT NULL,
  file_name TEXT DEFAULT '', mime_type TEXT DEFAULT '', content BLOB, notes TEXT DEFAULT '',
  uploaded_by TEXT DEFAULT '', created_at TEXT NOT NULL,
  FOREIGN KEY(document_id) REFERENCES dm_documents(id));
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_docs(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM dm_documents ORDER BY title").fetchall()]


def create_doc(conn, title, category="General", created_by=""):
    cur = conn.execute("INSERT INTO dm_documents(title,category,created_by,created_at) VALUES(?,?,?,?)",
                       (title, category, created_by, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def add_version(conn, doc_id, file_name, content, mime_type="", notes="", uploaded_by=""):
    row = conn.execute("SELECT current_version FROM dm_documents WHERE id=?", (doc_id,)).fetchone()
    ver = (row["current_version"] if row else 0) + 1
    conn.execute("INSERT INTO dm_versions(document_id,version,file_name,mime_type,content,notes,uploaded_by,created_at) VALUES(?,?,?,?,?,?,?,?)",
                 (doc_id, ver, file_name, mime_type, content, notes, uploaded_by, date.today().isoformat()))
    conn.execute("UPDATE dm_documents SET current_version=? WHERE id=?", (ver, doc_id))
    conn.commit()
    return ver


def get_versions(conn, doc_id):
    return [dict(r) for r in conn.execute("SELECT id,version,file_name,mime_type,notes,uploaded_by,created_at FROM dm_versions WHERE document_id=? ORDER BY version DESC", (doc_id,)).fetchall()]