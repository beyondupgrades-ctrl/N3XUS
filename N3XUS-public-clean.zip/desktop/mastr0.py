"""M4STR0 — QUOT3FLOW autonomous orchestration engine.

Modes: assisted (propose only), supervised (auto low-risk, gate sensitive),
full (blocked until a trusted payment provider is verified — enforced in code).
No external AI or paid services required. All actions are audited via qf3_events
and mstr_runs.
"""
import json
import sqlite3
from datetime import date, datetime, timedelta

MODES = ("assisted", "supervised", "full")

AGENTS = {
    "quote_follower": "Quotes sent but unanswered — propose follow-ups.",
    "invoice_monitor": "Issued/overdue invoices — propose reminders and escalate exceptions.",
    "payment_watch": "Pending payments and promises — reconcile status, flag stale promises.",
    "receipt_keeper": "Confirmed payments — ensure receipts exist (auto-created by quoteflow).",
    "exception_manager": "Failed/voided/bounced records — raise exceptions for review.",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS mstr_agents(
  name TEXT PRIMARY KEY, responsibility TEXT, enabled INTEGER DEFAULT 1,
  last_run_at TEXT, last_status TEXT, runs INTEGER DEFAULT 0, failures INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS mstr_rules(
  rule_key TEXT PRIMARY KEY, enabled INTEGER DEFAULT 1, config_json TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS mstr_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, agent TEXT, trigger TEXT,
  detail TEXT, status TEXT, mode TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS mstr_proposals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, ref_table TEXT, ref_id INTEGER,
  title TEXT, detail TEXT, payload_json TEXT DEFAULT '{}',
  status TEXT DEFAULT 'pending', created_at TEXT,
  decided_by TEXT, decided_at TEXT, decision_note TEXT);
CREATE TABLE IF NOT EXISTS mstr_settings(
  key TEXT PRIMARY KEY, value TEXT);
"""


def ensure_schema(conn, commit=True):
    """Create the M4STR0 tables and seed settings.

    ``commit=False`` leaves the writes for the caller's own commit, which is
    what a cycle wants: the whole pass then reaches disk once.
    """
    conn.executescript(SCHEMA)
    for name, resp in AGENTS.items():
        conn.execute("INSERT OR IGNORE INTO mstr_agents(name,responsibility) VALUES(?,?)", (name, resp))
    for key, default in (("mode", "assisted"), ("paused", "0"), ("provider_verified", "0"),
                         ("followup_days", "3"), ("overdue_days", "0"), ("escalate_days", "7")):
        conn.execute("INSERT OR IGNORE INTO mstr_settings(key,value) VALUES(?,?)", (key, default))
    if commit:
        conn.commit()


def _setting(conn, key, default=""):
    r = conn.execute("SELECT value FROM mstr_settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def _set(conn, key, value):
    conn.execute("INSERT INTO mstr_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def _now():
    return datetime.now().isoformat(timespec="seconds")


def _today():
    return date.today().isoformat()


def mode(conn):
    m = _setting(conn, "mode", "assisted")
    return m if m in MODES else "assisted"


def set_mode(conn, actor, new_mode):
    new_mode = str(new_mode or "").lower()
    if new_mode not in MODES:
        raise ValueError("Mode must be assisted, supervised or full.")
    if new_mode == "full" and _setting(conn, "provider_verified") != "1":
        raise PermissionError(
            "Full Autopilot is locked: no trusted payment provider verification is configured. "
            "Complete Phase 4 provider integration first.")
    _set(conn, "mode", new_mode)
    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                 ("orchestrator", "mode_change", f"mode set to {new_mode}", "ok", new_mode, _now()))
    conn.commit()
    return new_mode


def paused(conn):
    return _setting(conn, "paused") == "1"


def set_paused(conn, actor, pause):
    _set(conn, "paused", "1" if pause else "0")
    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                 ("orchestrator", "pause" if pause else "resume", actor, "ok", mode(conn), _now()))
    conn.commit()


def emergency_stop(conn, actor):
    _set(conn, "paused", "1")
    _set(conn, "mode", "assisted")
    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                 ("orchestrator", "emergency_stop", actor, "ok", "assisted", _now()))
    conn.commit()


def status(conn):
    agents = [dict(r) for r in conn.execute("SELECT * FROM mstr_agents ORDER BY name")]
    pending = conn.execute("SELECT COUNT(*) FROM mstr_proposals WHERE status='pending'").fetchone()[0]
    recent = [dict(r) for r in conn.execute(
        "SELECT * FROM mstr_runs ORDER BY id DESC LIMIT 15")]
    return {"mode": mode(conn), "paused": paused(conn),
            "provider_verified": _setting(conn, "provider_verified") == "1",
            "agents": agents, "pending_proposals": pending, "recent_runs": recent,
            "settings": {k: _setting(conn, k) for k in
                         ("followup_days", "overdue_days", "escalate_days")}}


def list_proposals(conn, status_filter=None, limit=200):
    sql = "SELECT * FROM mstr_proposals"
    args = []
    if status_filter:
        sql += " WHERE status=?"; args.append(status_filter)
    sql += " ORDER BY id DESC LIMIT ?"; args.append(int(limit))
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def _propose(conn, kind, table, rid, title, detail, payload=None):
    """Duplicate prevention: same open proposal for same record is not re-created."""
    dup = conn.execute(
        "SELECT id FROM mstr_proposals WHERE kind=? AND ref_table=? AND ref_id=? AND status='pending'",
        (kind, table, int(rid))).fetchone()
    if dup:
        return None
    conn.execute(
        "INSERT INTO mstr_proposals(kind,ref_table,ref_id,title,detail,payload_json,status,created_at) VALUES(?,?,?,?,?,?,'pending',?)",
        (kind, table, int(rid), title[:300], detail[:2000],
         json.dumps(payload or {}), _now()))
    return True


def _run(conn, agent, trigger, detail, ok=True):
    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                 (agent, trigger, str(detail)[:500], "ok" if ok else "fail", mode(conn), _now()))
    conn.execute("UPDATE mstr_agents SET last_run_at=?,last_status=?,runs=runs+1,failures=failures+? WHERE name=?",
                 (_now(), "ok" if ok else "fail", 0 if ok else 1, agent))


# ------------------------------------------------------------------ agents --

def agent_quote_follower(conn):
    days = int(_setting(conn, "followup_days", "3"))
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    rows = conn.execute(
        "SELECT q.id,q.quote_no,q.valid_until,c.name AS client FROM qf3_quotes q "
        "JOIN qf3_clients c ON c.id=q.client_id WHERE q.status='sent' AND q.updated_at<?",
        (cutoff,)).fetchall()
    n = 0
    for r in rows:
        if _propose(conn, "quote_followup", "qf3_quotes", r["id"],
                    f"Follow up quote {r['quote_no']} — {r['client']}",
                    f"Quote sent over {days} days ago with no response. "
                    f"Valid until {r['valid_until']}. Portal link is on the quote record.",
                    {"quote_no": r["quote_no"]}):
            n += 1
    _run(conn, "quote_follower", "scan", f"{len(rows)} stale sent quotes, {n} new proposals")
    return n


def agent_invoice_monitor(conn):
    esc = int(_setting(conn, "escalate_days", "7"))
    today = _today()
    rows = conn.execute(
        "SELECT i.id,i.invoice_no,i.due_date,i.status,c.name AS client "
        "FROM qf3_invoices i JOIN qf3_clients c ON c.id=i.client_id "
        "WHERE i.status IN ('issued','part_paid')").fetchall()
    n = 0
    for r in rows:
        overdue = r["due_date"] and r["due_date"] < today
        if overdue:
            days_over = (date.today() - date.fromisoformat(r["due_date"])).days
            kind = "invoice_escalation" if days_over >= esc else "invoice_reminder"
            title = (f"ESCALATE overdue invoice {r['invoice_no']} — {days_over} days" if kind == "invoice_escalation"
                     else f"Payment reminder — invoice {r['invoice_no']} ({r['client']})")
            if _propose(conn, kind, "qf3_invoices", r["id"], title,
                        f"Invoice {r['invoice_no']} for {r['client']} due {r['due_date']} is unpaid.",
                        {"invoice_no": r["invoice_no"], "days_over": days_over}):
                n += 1
    _run(conn, "invoice_monitor", "scan", f"{len(rows)} open invoices, {n} new proposals")
    return n


def agent_payment_watch(conn):
    today = _today()
    rows = conn.execute(
        "SELECT p.id,p.amount,p.promise_date,p.status,i.invoice_no,c.name AS client "
        "FROM qf3_payments p JOIN qf3_invoices i ON i.id=p.invoice_id "
        "JOIN qf3_clients c ON c.id=i.client_id WHERE p.status='pending'").fetchall()
    n = 0
    for r in rows:
        if r["promise_date"] and r["promise_date"] < today:
            if _propose(conn, "broken_promise", "qf3_payments", r["id"],
                        f"Payment promise broken — {r['client']} · {r['invoice_no']}",
                        f"Promised {r['promise_date']}, amount {r['amount']}. Follow up or record outcome.",
                        {"invoice_no": r["invoice_no"], "amount": r["amount"]}):
                n += 1
        elif not r["promise_date"]:
            age = conn.execute("SELECT created_at FROM qf3_payments WHERE id=?", (r["id"],)).fetchone()
            if age and age["created_at"][:10] < (date.today() - timedelta(days=2)).isoformat():
                if _propose(conn, "stale_pending", "qf3_payments", r["id"],
                            f"Unverified pending payment — {r['client']} · {r['invoice_no']}",
                            f"Pending payment of {r['amount']} recorded over 2 days ago with no confirmation. Verify or mark failed.",
                            {"invoice_no": r["invoice_no"], "amount": r["amount"]}):
                    n += 1
    _run(conn, "payment_watch", "scan", f"{len(rows)} pending payments, {n} new proposals")
    return n


def agent_exception_manager(conn):
    n = 0
    for r in conn.execute("SELECT id,invoice_no,void_reason FROM qf3_invoices WHERE status='void'").fetchall():
        if _propose(conn, "voided_invoice", "qf3_invoices", r["id"],
                    f"Voided invoice {r['invoice_no']} needs review",
                    f"Reason: {r['void_reason'] or 'none recorded'}",
                    {"invoice_no": r["invoice_no"]}):
            n += 1
    for r in conn.execute("SELECT id,quote_no FROM qf3_quotes WHERE status='declined'").fetchall():
        if _propose(conn, "declined_quote", "qf3_quotes", r["id"],
                    f"Quote {r['quote_no']} was declined by client",
                    "Review pricing or follow up with an alternative offer.",
                    {"quote_no": r["quote_no"]}):
            n += 1
    _run(conn, "exception_manager", "scan", f"{n} new exception proposals")
    return n


AGENT_FUNCS = {
    "quote_follower": agent_quote_follower,
    "invoice_monitor": agent_invoice_monitor,
    "payment_watch": agent_payment_watch,
    "receipt_keeper": lambda c: (_run(c, "receipt_keeper", "scan", "receipts auto-issued on confirmation"), 0)[1],
    "exception_manager": agent_exception_manager,
}


def run_cycle(conn, lock=None):
    """One orchestration pass. Returns counts of new proposals.

    ``lock`` is the server's data lock. When it is given, each agent runs under
    its own short hold and the whole cycle ends with ONE commit, instead of the
    caller holding the lock for the entire cycle. Each commit re-encrypts and
    rewrites the whole database, so committing once per agent (and once per
    proposal) was the expensive part: a phone signing in during a scan waited
    for all of it. Without a lock this behaves exactly as before, which is what
    the tests and any direct caller get.
    """
    ensure_schema(conn, commit=lock is None)
    if paused(conn):
        return {"paused": True, "proposals": 0}
    # One commit for the whole cycle, at the end: a scan reaches disk once.
    total = 0
    for name, fn in AGENT_FUNCS.items():
        if lock is not None:
            with lock:
                agent = conn.execute("SELECT enabled FROM mstr_agents WHERE name=?", (name,)).fetchone()
                if agent and not agent["enabled"]:
                    continue
                try:
                    total += fn(conn)
                except Exception as exc:  # agent failure must not kill the cycle
                    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                                 (name, "scan", f"error: {exc}"[:400], "fail", mode(conn), _now()))
                    conn.execute("UPDATE mstr_agents SET failures=failures+1 WHERE name=?", (name,))
            continue
        agent = conn.execute("SELECT enabled FROM mstr_agents WHERE name=?", (name,)).fetchone()
        if agent and not agent["enabled"]:
            continue
        try:
            total += fn(conn)
        except Exception as exc:  # agent failure must not kill the cycle
            conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                         (name, "scan", f"error: {exc}"[:400], "fail", mode(conn), _now()))
            conn.execute("UPDATE mstr_agents SET failures=failures+1 WHERE name=?", (name,))
    # Step 2 autonomy: auto-approve routine proposals when autonomy level >= 3.
    try:
        row = conn.execute("SELECT value FROM attendance_settings WHERE key='autonomy_level'").fetchone()
        lvl = int(row["value"]) if row and row["value"] else 2
    except Exception:
        lvl = 2
    if lvl >= 3:
        routine = {"quote_followup", "invoice_reminder", "stale_pending"}
        pending = [dict(r) for r in conn.execute(
            "SELECT id, kind FROM mstr_proposals WHERE status='pending'").fetchall()]
        for p in pending:
            if p["kind"] in routine:
                try:
                    if lock is not None:
                        with lock:
                            decide_proposal(conn, "autonomy", p["id"], True, "auto-approved (autonomy level 3)")
                    else:
                        decide_proposal(conn, "autonomy", p["id"], True, "auto-approved (autonomy level 3)")
                except Exception:
                    pass
    if lock is not None:
        with lock:
            conn.commit()
    else:
        conn.commit()
    return {"paused": False, "proposals": total, "mode": mode(conn)}


# ------------------------------------------------------------- proposals ----

def decide_proposal(conn, actor, proposal_id, approve, note=""):
    p = conn.execute("SELECT * FROM mstr_proposals WHERE id=?", (int(proposal_id),)).fetchone()
    if not p:
        raise KeyError("Proposal not found.")
    if p["status"] != "pending":
        raise PermissionError("This proposal was already decided.")
    stamp = _now()
    if not approve:
        conn.execute("UPDATE mstr_proposals SET status='rejected',decided_by=?,decided_at=?,decision_note=? WHERE id=?",
                     (actor, stamp, str(note)[:500], int(proposal_id)))
        conn.execute("INSERT INTO qf3_events(entity,entity_id,action,actor,detail,created_at) VALUES(?,?,?,?,?,?)",
                     ("mstr_proposal", int(proposal_id), "proposal_rejected", actor,
                      f"{p['kind']} · {p['title']}", stamp))
        conn.commit()
        return {"status": "rejected"}

    m = mode(conn)
    # In assisted mode approvals only acknowledge — actions still require explicit
    # per-record operations in QUOT3FLOW (send link, record payment) by a user.
    # In supervised mode low-risk kinds auto-apply bookkeeping.
    applied = False
    if m == "supervised" and p["kind"] in ("quote_followup", "invoice_reminder", "stale_pending"):
        applied = True
        conn.execute("INSERT INTO qf3_events(entity,entity_id,action,actor,detail,created_at) VALUES(?,?,?,?,?,?)",
                     (p["ref_table"], int(p["ref_id"]), "mstr_action", actor,
                      f"{p['kind']} applied by M4STR0 ({p['title']})", stamp))
    conn.execute("UPDATE mstr_proposals SET status=?,decided_by=?,decided_at=?,decision_note=? WHERE id=?",
                 ("approved" if applied else "acknowledged", actor, stamp, str(note)[:500], int(proposal_id)))
    conn.execute("INSERT INTO qf3_events(entity,entity_id,action,actor,detail,created_at) VALUES(?,?,?,?,?,?)",
                 ("mstr_proposal", int(proposal_id), "proposal_approved", actor,
                  f"{p['kind']} · {p['title']} · applied={applied}", stamp))
    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                 ("orchestrator", "proposal_decision", f"{p['kind']} id={proposal_id} applied={applied}", "ok", m, stamp))
    conn.commit()
    return {"status": "approved" if applied else "acknowledged", "applied": applied}


def set_agent(conn, actor, name, enabled):
    if name not in AGENTS:
        raise KeyError("Unknown agent.")
    conn.execute("UPDATE mstr_agents SET enabled=? WHERE name=?", (1 if enabled else 0, name))
    conn.commit()
