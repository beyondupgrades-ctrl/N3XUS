"""BR Connect — free, self-hosted phone access.

Everything here is built with the Python standard library plus `cryptography`
(already installed). No certificate authority, no paid service, no API key and
no monthly fee is involved anywhere in this module.

What it does:

* `local_addresses()` — every IPv4 address this computer answers on, so the app
  can tell the phone (and the owner) where to connect.
* `lan_url()` / `loopback_url()` — the two URLs the phone can actually open.
* `qr_svg()` — an SVG QR code for the LAN URL, drawn from scratch (no library,
  no network), so the phone can be paired by scanning a screen.
* `ensure_certificate()` — a self-signed TLS certificate for this computer's
  own IP addresses and hostname, minted on first run and reused afterwards.
  This is what makes the phone's camera and microphone usable: browsers only
  grant them on https (or on localhost).

The certificate is self-signed, which is the honest trade for costing nothing:
the phone shows a one-time "not private" warning the owner taps through. Every
later visit is clean.

Nothing in this module binds a port or starts a thread; `web_backend` owns that.
"""

from __future__ import annotations

import datetime as _dt
import ipaddress
import os
import socket
import ssl
from pathlib import Path

# RSA-2048 is the smallest key every Android and iOS root store accepts; it
# signs in milliseconds on the CPU this app already targets.
_RSA_BITS = 2048
_VALID_DAYS = 825  # Apple's documented ceiling for TLS leaf certificates.
_MIN_VALID_DAYS = 7


# --------------------------------------------------------------------------- #
# Where this computer can be reached
# --------------------------------------------------------------------------- #
def local_addresses() -> list[str]:
    """IPv4 addresses other devices on the LAN can reach, LAN-first.

    The UDP connect below asks the routing table which interface would carry
    traffic to the internet. It sends no packet, so it works with no network
    access at all; it only fails when there is no route, which we treat as
    "no LAN address" and answer with an empty list.
    """
    found: list[str] = []

    def _add(value: str) -> None:
        value = (value or "").strip()
        try:
            ip = ipaddress.IPv4Address(value)
        except Exception:
            return
        if ip.is_loopback or ip.is_link_local or ip.is_unspecified:
            return
        if not ip.is_private:
            # A public address here means the computer is directly internet
            # facing; still reachable, so keep it, but never claim it as LAN.
            pass
        if value not in found:
            found.append(value)

    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("192.0.2.1", 9))  # TEST-NET-1, never routed
            _add(probe.getsockname()[0])
        finally:
            probe.close()
    except Exception:
        pass

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            _add(info[4][0])
    except Exception:
        pass

    return found


def primary_address() -> str:
    """The address to hand out first, or "" when the computer is offline."""
    addresses = local_addresses()
    return addresses[0] if addresses else ""


def lan_url(port: int, address: str = "", https: bool = True) -> str:
    """The URL to put on the phone. Empty string when there is no LAN address."""
    host = (address or primary_address()).strip()
    if not host:
        return ""
    scheme = "https" if https else "http"
    return f"{scheme}://{host}:{int(port)}/mobile"


def loopback_url(port: int, https: bool = True) -> str:
    scheme = "https" if https else "http"
    return f"{scheme}://127.0.0.1:{int(port)}/mobile"


def hostname() -> str:
    try:
        return socket.gethostname() or "localhost"
    except Exception:
        return "localhost"


# Version -> (data codewords per block, ecc codewords per block, number of blocks)
_SPECS = {
    1: [(19, 7, 1)],
    2: [(34, 10, 1)],
    3: [(55, 15, 1)],
    # Versions 4-6 at level L. A public tunnel address is far longer than a LAN
    # address, so the encoder has to reach past version 3 to draw it.
    4: [(80, 20, 1)],
    5: [(108, 26, 1)],
    6: [(136, 18, 2)],
}


def _block_layout(version: int) -> list[tuple[int, int, int]]:
    """(data codewords, ecc codewords, block count) groups for this version."""
    return _SPECS[version]


def _total_codewords(version: int) -> int:
    return sum((d + e) * n for d, e, n in _block_layout(version))


def _total_data_codewords(version: int) -> int:
    return sum(d * n for d, e, n in _block_layout(version))


# Version -> alignment pattern centre coordinates
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34]}

# ECC level L indicator bits
_L_LEVEL_BITS = 0b01


def _gf_mul(a: int, b: int) -> int:
    """Multiply in GF(256) with the QR polynomial x^8 + x^4 + x^3 + x^2 + 1."""
    result = 0
    while b:
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 0x100:
            a ^= 0x11D
    return result


def _generator_poly(degree: int) -> list[int]:
    """The Reed-Solomon generator polynomial, highest power first."""
    poly = [1]
    for i in range(degree):
        root = 1
        for _ in range(i):
            root = _gf_mul(root, 2)
        nxt = [0] * (len(poly) + 1)
        for j, coef in enumerate(poly):
            nxt[j] ^= coef
            nxt[j + 1] ^= _gf_mul(coef, root)
        poly = nxt
    return poly


def _reed_solomon(data: list[int], ecc_len: int) -> list[int]:
    """ECC codewords for one block: the remainder of data*x^n / generator."""
    gen = _generator_poly(ecc_len)
    message = list(data) + [0] * ecc_len
    for i in range(len(data)):
        lead = message[i]
        if lead:
            for j, coef in enumerate(gen):
                message[i + j] ^= _gf_mul(coef, lead)
    return message[len(data):]


def _choose_version(payload_len: int) -> int:
    for version in sorted(_SPECS):
        data_cw = _total_data_codewords(version)
        header = 4 + (8 if version < 10 else 16)
        if payload_len * 8 + header <= data_cw * 8:
            return version
    raise ValueError("payload too long for this encoder")


def _bitstream(payload: bytes, version: int) -> list[int]:
    """Mode indicator, character count, data, terminator and pad codewords."""
    data_cw = _total_data_codewords(version)
    bits: list[int] = []

    def push(value: int, length: int) -> None:
        for shift in range(length - 1, -1, -1):
            bits.append((value >> shift) & 1)

    push(0b0100, 4)                      # byte mode
    push(len(payload), 8 if version < 10 else 16)
    for byte in payload:
        push(byte, 8)

    # Terminator: up to four zero bits, truncated at the capacity boundary.
    push(0, min(4, data_cw * 8 - len(bits)))
    while len(bits) % 8:
        bits.append(0)

    codewords = []
    for i in range(0, len(bits), 8):
        value = 0
        for bit in bits[i:i + 8]:
            value = (value << 1) | bit
        codewords.append(value)

    for pad in (0xEC, 0x11) * data_cw:
        if len(codewords) >= data_cw:
            break
        codewords.append(pad)
    return codewords


def _interleave(codewords: list[int], version: int) -> list[int]:
    """Split into blocks, add ECC per block, then interleave as the spec says."""
    groups = _block_layout(version)
    data_blocks: list[list[int]] = []
    ecc_blocks: list[list[int]] = []
    offset = 0
    for data_len, ecc_len, count in groups:
        for _ in range(count):
            chunk = codewords[offset:offset + data_len]
            offset += data_len
            data_blocks.append(chunk)
            ecc_blocks.append(_reed_solomon(chunk, ecc_len))

    longest = max(len(block) for block in data_blocks)
    result: list[int] = []
    for index in range(longest):
        for block in data_blocks:
            if index < len(block):
                result.append(block[index])
    for index in range(max(len(block) for block in ecc_blocks)):
        for block in ecc_blocks:
            if index < len(block):
                result.append(block[index])
    return result


def _mask(mask_id: int, row: int, col: int) -> bool:
    if mask_id == 0: return (row + col) % 2 == 0
    if mask_id == 1: return row % 2 == 0
    if mask_id == 2: return col % 3 == 0
    if mask_id == 3: return (row + col) % 3 == 0
    if mask_id == 4: return (row // 2 + col // 3) % 2 == 0
    if mask_id == 5: return (row * col) % 2 + (row * col) % 3 == 0
    if mask_id == 6: return ((row * col) % 2 + (row * col) % 3) % 2 == 0
    return ((row + col) % 2 + (row * col) % 3) % 2 == 0


def _format_word(mask_id: int) -> int:
    """The 15-bit format information BCH code for ECC level L."""
    value = (_L_LEVEL_BITS << 3) | mask_id
    remainder = value
    for _ in range(10):
        remainder = (remainder << 1) ^ ((remainder >> 9) * 0x537)
    return ((value << 10) | remainder) ^ 0x5412


def _penalty(grid: list[list[bool]], size: int) -> int:
    score = 0
    lines = [grid[r] for r in range(size)]
    lines += [[grid[r][c] for r in range(size)] for c in range(size)]
    for line in lines:
        run = 1
        for i in range(1, size):
            if line[i] == line[i - 1]:
                run += 1
            else:
                if run >= 5:
                    score += 3 + (run - 5)
                run = 1
        if run >= 5:
            score += 3 + (run - 5)
    for r in range(size - 1):
        for c in range(size - 1):
            if grid[r][c] == grid[r][c + 1] == grid[r + 1][c] == grid[r + 1][c + 1]:
                score += 3
    finder_like = [True, False, True, True, True, False, True]
    for line in lines:
        for i in range(size - 10):
            window = line[i:i + 11]
            if window[:7] == finder_like and not any(window[7:]):
                score += 40
            if not any(window[:4]) and window[4:] == finder_like:
                score += 40
    dark = sum(1 for row in grid for cell in row if cell)
    percent = dark * 100 // (size * size)
    score += 10 * (abs(percent - 50) // 5)
    return score


def _build_matrix(payload: bytes) -> list[list[bool]]:
    version = _choose_version(len(payload))
    size = version * 4 + 17
    codewords = _bitstream(payload, version)
    stream = _interleave(codewords, version)

    grid = [[False] * size for _ in range(size)]
    is_function = [[False] * size for _ in range(size)]

    def place(row: int, col: int, dark: bool) -> None:
        grid[row][col] = dark
        is_function[row][col] = True

    def reserve(row: int, col: int) -> None:
        is_function[row][col] = True

    # Finder patterns plus their separators.
    for top, left in ((0, 0), (0, size - 7), (size - 7, 0)):
        for dr in range(-1, 8):
            for dc in range(-1, 8):
                r, c = top + dr, left + dc
                if not (0 <= r < size and 0 <= c < size):
                    continue
                inside = 0 <= dr <= 6 and 0 <= dc <= 6
                dark = inside and (dr in (0, 6) or dc in (0, 6) or (2 <= dr <= 4 and 2 <= dc <= 4))
                place(r, c, dark)

    # Timing patterns: alternating modules between the finders.
    for i in range(8, size - 8):
        place(6, i, i % 2 == 0)
        place(i, 6, i % 2 == 0)

    # Alignment patterns (none in version 1).
    centres = _ALIGN[version]
    for row in centres:
        for col in centres:
            if (row < 9 and col < 9) or (row < 9 and col > size - 10) or (row > size - 10 and col < 9):
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    place(row + dr, col + dc, max(abs(dr), abs(dc)) != 1)

    # Reserve the format information areas (filled in after masking).
    for i in range(9):
        reserve(8, i)
        reserve(i, 8)
    for i in range(8):
        reserve(8, size - 1 - i)
        reserve(size - 1 - i, 8)
    place(size - 8, 8, True)          # the dark module

    # Versions 7 and above carry a version-information block. Version 4 does not,
    # so nothing is reserved here for our supported versions.


    # Data placement: two-module-wide columns, right to left, alternating up/down.
    bits: list[int] = []
    for word in stream:
        for shift in range(7, -1, -1):
            bits.append((word >> shift) & 1)

    index = 0
    col = size - 1
    going_up = True
    while col > 0:
        if col == 6:                  # the vertical timing column is never data
            col -= 1
        rows = range(size - 1, -1, -1) if going_up else range(size)
        for row in rows:
            for offset in (0, 1):
                current = col - offset
                if current < 0 or is_function[row][current]:
                    continue
                grid[row][current] = bool(bits[index]) if index < len(bits) else False
                index += 1
        going_up = not going_up
        col -= 2

    # Try every mask and keep the lowest penalty, per the specification.
    best: tuple[int, list[list[bool]]] | None = None
    for mask_id in range(8):
        trial = [row[:] for row in grid]
        for r in range(size):
            for c in range(size):
                if not is_function[r][c] and _mask(mask_id, r, c):
                    trial[r][c] = not trial[r][c]

        word = _format_word(mask_id)
        bit_at = lambda position: bool((word >> position) & 1)

        # Format copy A: around the top-left finder.
        copy_a = [(8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 8),
                  (7, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (0, 8)]
        for position, (r, c) in enumerate(copy_a):
            trial[r][c] = bit_at(14 - position)
        # Format copy B: split between the other two finders.
        # The vertical strip sits under the bottom-left finder (rows size-8..size-2)
        # and the horizontal strip ends at the top-right finder's separator.
        for position in range(7):
            trial[size - 8 + position][8] = bit_at(position + 7)
        for position in range(7):
            trial[8][size - 8 + position] = bit_at((position + 5) % 7)
        trial[size - 8][8] = True

        if version >= 7:
            remainder = version
            for _ in range(12):
                remainder = (remainder << 1) ^ ((remainder >> 11) * 0x1F25)
            version_word = (version << 12) | remainder
            for i in range(18):
                bit = bool((version_word >> i) & 1)
                trial[size - 11 + i % 3][i // 3] = bit
                trial[i // 3][size - 11 + i % 3] = bit

        score = _penalty(trial, size)
        if best is None or score < best[0]:
            best = (score, trial)

    return best[1]


def qr_matrix(text: str) -> list[list[bool]]:
    return _build_matrix(text.encode("utf-8"))


def qr_svg(text: str, module_px: int = 6, quiet: int = 4,
        dark: str = "#0B1220", light: str = "#FFFFFF") -> str:
    grid = qr_matrix(text)
    size = len(grid)
    total = size + quiet * 2
    segments: list[str] = []
    for row in range(size):
        col = 0
        while col < size:
            if not grid[row][col]:
                col += 1
                continue
            start = col
            while col < size and grid[row][col]:
                col += 1
            segments.append(f"M{start + quiet} {row + quiet}h{col - start}v1h-{col - start}z")
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total} {total}" '
        f'width="{total * module_px}" height="{total * module_px}" '
        f'shape-rendering="crispEdges" role="img" aria-label="QR code">'
        f'<rect width="{total}" height="{total}" fill="{light}"/>'
        f'<path fill="{dark}" d="{"".join(segments)}"/></svg>'
    )
# --------------------------------------------------------------------------- #
# Self-signed certificate, minted locally, free forever
# --------------------------------------------------------------------------- #
def _hosts_for_certificate() -> tuple[list[str], list[str]]:
    """(dns names, ip addresses) the certificate must cover."""
    names: list[str] = ["localhost"]
    ips: list[str] = ["127.0.0.1"]
    machine = hostname()
    if machine and machine not in names:
        names.append(machine)
    suffix = os.environ.get("BR_HOST_SUFFIX", "").strip().lower()
    if suffix and f"{machine}.{suffix}" not in names:
        names.append(f"{machine}.{suffix}")
    for address in local_addresses():
        if address not in ips:
            ips.append(address)
    return names, ips


def certificate_paths(data_home: str | Path) -> tuple[Path, Path]:
    base = Path(data_home) / "tls"
    return base / "br-lan.crt", base / "br-lan.key"


def _certificate_is_usable(cert_file: Path, key_file: Path, names: list[str], ips: list[str]) -> bool:
    """True when the cached certificate still covers every current host."""
    from cryptography import x509
    from cryptography.x509.oid import ExtensionOID

    if not (cert_file.is_file() and key_file.is_file()):
        return False
    try:
        cert = x509.load_pem_x509_certificate(cert_file.read_bytes())
        not_after = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after
        now = _dt.datetime.now(_dt.timezone.utc)
        if not_after.tzinfo is None:
            not_after = not_after.replace(tzinfo=_dt.timezone.utc)
        if (not_after - now).days < _MIN_VALID_DAYS:
            return False
        san = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME).value
        covered_dns = {entry.lower() for entry in san.get_values_for_type(x509.DNSName)}
        covered_ips = {str(entry) for entry in san.get_values_for_type(x509.IPAddress)}
        if not set(name.lower() for name in names) <= covered_dns:
            return False
        if not set(ips) <= covered_ips:
            return False
        return True
    except Exception:
        return False


def ensure_certificate(data_home: str | Path, force: bool = False) -> tuple[Path, Path]:
    """Return (cert, key) paths, minting a self-signed pair when needed.

    Called on every start. It is cheap: the certificate is only regenerated when
    it is missing, near expiry, or the computer's address changed (which happens
    every time the router hands out a new IP). Nothing is fetched from anywhere.
    """
    names, ips = _hosts_for_certificate()
    cert_file, key_file = certificate_paths(data_home)
    if not force and _certificate_is_usable(cert_file, key_file, names, ips):
        return cert_file, key_file

    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=_RSA_BITS)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, hostname()),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Beyond Registration (Pty) Ltd"),
        x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, "BR Connect (self-signed, local)"),
    ])
    san_entries: list[x509.GeneralName] = [x509.DNSName(name) for name in names]
    san_entries += [x509.IPAddress(ipaddress.ip_address(ip)) for ip in ips]
    now = _dt.datetime.now(_dt.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - _dt.timedelta(days=1))
        .not_valid_after(now + _dt.timedelta(days=_VALID_DAYS))
        .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=False, key_encipherment=True,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .sign(key, hashes.SHA256())
    )

    cert_file.parent.mkdir(parents=True, exist_ok=True)
    key_file.write_bytes(key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ))
    cert_file.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    try:
        os.chmod(key_file, 0o600)
    except Exception:
        pass
    return cert_file, key_file


def ssl_context(data_home: str | Path) -> ssl.SSLContext:
    """A server TLS context using the self-signed certificate."""
    cert_file, key_file = ensure_certificate(data_home)
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile=str(cert_file), keyfile=str(key_file))
    # TLS 1.2 is the floor: older protocol versions are refused outright.
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    return context


def fingerprint(cert_file: str | Path) -> str:
    """SHA-256 fingerprint, grouped like Windows shows it, for phone comparison."""
    import hashlib

    try:
        der = ssl.PEM_cert_to_DER_cert(Path(cert_file).read_text("ascii"))
        digest = hashlib.sha256(der).hexdigest().upper()
    except Exception:
        return ""
    return ":".join(digest[i:i + 2] for i in range(0, len(digest), 2))
