"""General ledger (100% free, in-house, double-entry).

Tables: gl_accounts, gl_journals, gl_entries. All amounts in the company currency.
No external service or paid API is used.
"""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS gl_accounts(
  code TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL,
  parent_code TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS gl_journals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, entry_date TEXT NOT NULL, memo TEXT DEFAULT '',
  posted_by TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS gl_entries(
  id INTEGER PRIMARY KEY AUTOINCREMENT, journal_id INTEGER NOT NULL,
  account_code TEXT NOT NULL, debit REAL NOT NULL DEFAULT 0, credit REAL NOT NULL DEFAULT 0,
  FOREIGN KEY(journal_id) REFERENCES gl_journals(id) ON DELETE CASCADE,
  FOREIGN KEY(account_code) REFERENCES gl_accounts(code));
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    # Seed a minimal chart of accounts if empty.
    if conn.execute("SELECT COUNT(*) c FROM gl_accounts").fetchone()["c"] == 0:
        seed = [
            ("1000", "Cash", "asset"), ("1100", "Bank", "asset"),
            ("1200", "Accounts receivable", "asset"), ("1500", "Equipment", "asset"),
            ("2000", "Accounts payable", "liability"), ("2100", "VAT payable", "liability"),
            ("2200", "Loans payable", "liability"), ("3000", "Owner equity", "equity"),
            ("3100", "Retained earnings", "equity"), ("4000", "Revenue", "revenue"),
            ("4100", "Other income", "revenue"), ("5000", "Salaries expense", "expense"),
            ("5100", "Rent expense", "expense"), ("5200", "Utilities expense", "expense"),
            ("5300", "Supplies expense", "expense"),
        ]
        for code, name, typ in seed:
            conn.execute("INSERT OR IGNORE INTO gl_accounts(code,name,type,created_at) VALUES(?,?,?,?)",
                         (code, name, typ, date.today().isoformat()))
    conn.commit()


def list_accounts(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM gl_accounts ORDER BY code").fetchall()]


def save_account(conn, code, name, typ, parent_code=None):
    conn.execute("INSERT INTO gl_accounts(code,name,type,parent_code,created_at) VALUES(?,?,?,?,?) "
                 "ON CONFLICT(code) DO UPDATE SET name=excluded.name,type=excluded.type,parent_code=excluded.parent_code",
                 (code, name, typ, parent_code, date.today().isoformat()))
    conn.commit()


def post_journal(conn, entry_date, memo, entries, posted_by=""):
    # entries: list of {account_code, debit, credit}
    total_d = round(sum(float(e.get("debit", 0)) for e in entries), 2)
    total_c = round(sum(float(e.get("credit", 0)) for e in entries), 2)
    if total_d != total_c:
        raise ValueError("Journal not balanced: debits %s != credits %s" % (total_d, total_c))
    if not entries:
        raise ValueError("Journal needs at least one entry.")
    cur = conn.execute("INSERT INTO gl_journals(entry_date,memo,posted_by,created_at) VALUES(?,?,?,?)",
                       (entry_date, memo, posted_by, date.today().isoformat()))
    jid = cur.lastrowid
    for e in entries:
        conn.execute("INSERT INTO gl_entries(journal_id,account_code,debit,credit) VALUES(?,?,?,?)",
                     (jid, e["account_code"], float(e.get("debit", 0)), float(e.get("credit", 0))))
    conn.commit()
    return jid


def list_journals(conn, limit=100):
    rows = conn.execute("SELECT * FROM gl_journals ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["entries"] = [dict(e) for e in conn.execute(
            "SELECT * FROM gl_entries WHERE journal_id=?", (r["id"],)).fetchall()]
        out.append(d)
    return out


def trial_balance(conn):
    rows = conn.execute(
        "SELECT a.code,a.name,a.type, COALESCE(SUM(e.debit),0) d, COALESCE(SUM(e.credit),0) c "
        "FROM gl_accounts a LEFT JOIN gl_entries e ON e.account_code=a.code "
        "GROUP BY a.code ORDER BY a.code").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        net = float(d["d"]) - float(d["c"])
        d["balance"] = net
        out.append(d)
    return out