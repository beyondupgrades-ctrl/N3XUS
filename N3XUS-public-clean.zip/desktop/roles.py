"""Role system for the mobile app.

Seven kinds of account, each with its own home screen and its own reach. Nothing
here replaces the existing staff/admin login: those keep working exactly as they
did, and a staff or admin account is mapped onto the role list below.

The point of the roles is that a caregiver should not be able to see a payslip,
and a patient should not be able to see another patient's vitals. The rules live
in one place (ROLES) so the phone and the server always agree.

Free and offline: standard library only.
"""

from __future__ import annotations

import secrets
import string
from datetime import datetime, timedelta, timezone

# --------------------------------------------------------------------------- #
# The seven roles
# --------------------------------------------------------------------------- #

OWNER = "owner"
ADMIN = "admin"
HR = "hr"
EXECUTIVE = "executive"
REPRESENTATIVE = "representative"
PATIENT = "patient"
COMPANY_PHONE = "company_phone"
FAMILY = "family"

# `home` is the tab a person lands on. `tabs` is what they may reach at all.
# `staff` and `admin` are the two legacy profiles, kept so nothing breaks.
ROLES: dict[str, dict] = {
    OWNER: {
        "label": "Owner",
        "group": "Company",
        "home": "home",
        "tabs": ["home", "patients", "academy", "leave", "payslips", "vault", "settings",
                 "messages", "contracts", "approvals", "ops"],
        "can": ["all", "approve", "payslips", "patients", "meetings", "contracts", "compliance"],
    },
    ADMIN: {
        "label": "Admin",
        "group": "Company",
        "home": "home",
        "tabs": ["home", "patients", "academy", "leave", "payslips", "vault", "settings",
                 "messages", "contracts", "approvals", "ops"],
        "can": ["all", "approve", "payslips", "patients", "meetings", "contracts", "compliance"],
    },
    HR: {
        "label": "HR",
        "group": "Company",
        "home": "home",
        "tabs": ["home", "academy", "leave", "payslips", "vault", "settings",
                 "messages", "contracts", "approvals", "ops"],
        "can": ["approve", "payslips", "leave", "contracts", "staff_records", "meetings"],
    },
    EXECUTIVE: {
        "label": "Executive",
        "group": "Company",
        "home": "home",
        "tabs": ["home", "patients", "academy", "vault", "settings", "messages", "ops"],
        "can": ["oversight", "patients", "meetings", "compliance", "reports"],
    },
    REPRESENTATIVE: {
        "label": "Representative",
        "group": "Company",
        "home": "home",
        "tabs": ["home", "patients", "academy", "vault", "settings", "messages"],
        "can": ["request", "patients", "meetings", "sos"],
    },
    PATIENT: {
        "label": "Patient",
        "group": "Care",
        "home": "care",
        "tabs": ["care", "vitals", "messages", "settings"],
        "can": ["sos", "tracker", "vitals_own", "messages", "medication_own", "requests"],
    },
    COMPANY_PHONE: {
        "label": "Company phone",
        "group": "Care",
        "home": "care",
        "tabs": ["care", "vitals", "messages", "settings"],
        "can": ["sos", "tracker", "vitals_own", "messages", "medication_own", "checkin"],
    },
    FAMILY: {
        "label": "Family / Caregiver",
        "group": "Care",
        "home": "care",
        "tabs": ["care", "vitals", "messages", "settings"],
        "can": ["sos", "tracker", "vitals_linked", "messages", "medication_linked", "requests"],
    },
}

# The legacy profiles map onto these, so one code path answers for everyone.
LEGACY_MAP = {"staff": REPRESENTATIVE, "admin": ADMIN, "owner": OWNER}

# Which roles may read a given patient's record.
CARE_ROLES = {PATIENT, COMPANY_PHONE, FAMILY}


def resolve(profile: str | None, role: str | None = None) -> str:
    """Turn whatever the account carries into one of the seven roles."""
    if role and role in ROLES:
        return role
    key = (profile or "").strip().lower()
    if key in ROLES:
        return key
    return LEGACY_MAP.get(key, REPRESENTATIVE)


def spec(role: str) -> dict:
    return ROLES.get(resolve(None, role), ROLES[REPRESENTATIVE])


def can(role: str, ability: str) -> bool:
    abilities = spec(role).get("can", [])
    return "all" in abilities or ability in abilities


def tabs_for(role: str) -> list[str]:
    return list(spec(role).get("tabs", []))


def home_for(role: str) -> str:
    return spec(role).get("home", "home")


def is_care_role(role: str) -> bool:
    return resolve(None, role) in CARE_ROLES


def describe(role: str) -> dict:
    role = resolve(None, role)
    item = ROLES[role]
    return {
        "role": role,
        "label": item["label"],
        "group": item["group"],
        "home": item["home"],
        "tabs": list(item["tabs"]),
        "can": list(item["can"]),
    }


def all_roles() -> list[dict]:
    return [describe(role) for role in ROLES]


# --------------------------------------------------------------------------- #
# Invites
# --------------------------------------------------------------------------- #

_ALPHABET = string.ascii_uppercase + string.digits


def invite_code() -> str:
    """A short code a person can read aloud, without look-alike characters."""
    safe = _ALPHABET.translate(str.maketrans("", "", "O0I1"))
    return "".join(secrets.choice(safe) for _ in range(8))


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def expiry(days: int = 14) -> str:
    return (datetime.now(timezone.utc) + timedelta(days=days)).replace(microsecond=0).isoformat()


def ensure_schema(conn) -> None:
    """Idempotent: the tables are created by the main schema too."""
    conn.execute("""
    CREATE TABLE IF NOT EXISTS mobile_role_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        login TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL,
        display_name TEXT NOT NULL DEFAULT '',
        phone TEXT DEFAULT '',
        email TEXT DEFAULT '',
        linked_patient_id INTEGER,
        linked_employee_id INTEGER,
        created_by TEXT DEFAULT '',
        invite_code TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'Active',
        created_at TEXT NOT NULL,
        last_login_at TEXT DEFAULT ''
    );
    """)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS mobile_role_invites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        role TEXT NOT NULL,
        display_name TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        linked_patient_id INTEGER,
        created_by TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        expires_at TEXT DEFAULT '',
        used_at TEXT DEFAULT '',
        used_login TEXT DEFAULT ''
    );
    """)
    conn.commit()


def create_invite(conn, *, role: str, created_by: str, display_name: str = "",
                  phone: str = "", linked_patient_id: int | None = None,
                  days: int = 14) -> dict:
    role = resolve(None, role)
    if role not in ROLES:
        raise ValueError("Unknown role.")
    code = invite_code()
    while conn.execute("SELECT 1 FROM mobile_role_invites WHERE code=?", (code,)).fetchone():
        code = invite_code()
    conn.execute(
        "INSERT INTO mobile_role_invites(code,role,display_name,phone,linked_patient_id,created_by,created_at,expires_at)"
        " VALUES(?,?,?,?,?,?,?,?)",
        (code, role, display_name, phone, linked_patient_id, created_by, now(), expiry(days)),
    )
    conn.commit()
    return {"code": code, "role": role, "label": ROLES[role]["label"],
            "expires_at": expiry(days), "linked_patient_id": linked_patient_id}


def pending_invites(conn) -> list[dict]:
    rows = conn.execute(
        "SELECT id,code,role,display_name,phone,linked_patient_id,created_by,created_at,expires_at"
        " FROM mobile_role_invites WHERE used_at='' ORDER BY id DESC"
    ).fetchall()
    out = []
    for row in rows:
        item = dict(row) if hasattr(row, "keys") else {
            "id": row[0], "code": row[1], "role": row[2], "display_name": row[3],
            "phone": row[4], "linked_patient_id": row[5], "created_by": row[6],
            "created_at": row[7], "expires_at": row[8]}
        item["label"] = ROLES.get(item["role"], {}).get("label", item["role"])
        out.append(item)
    return out


def redeem_invite(conn, code: str, login: str, password_hash: str,
                  display_name: str = "") -> dict:
    """Turn an invite into a real account. One use only."""
    code = (code or "").strip().upper()
    row = conn.execute(
        "SELECT id,role,display_name,phone,linked_patient_id,expires_at,used_at"
        " FROM mobile_role_invites WHERE code=? COLLATE NOCASE", (code,)
    ).fetchone()
    if not row:
        raise PermissionError("That invite code is not valid.")
    invite = dict(row) if hasattr(row, "keys") else {
        "id": row[0], "role": row[1], "display_name": row[2], "phone": row[3],
        "linked_patient_id": row[4], "expires_at": row[5], "used_at": row[6]}
    if invite.get("used_at"):
        raise PermissionError("That invite code has already been used.")
    expires = invite.get("expires_at") or ""
    if expires and expires < now():
        raise PermissionError("That invite code has expired.")
    if conn.execute("SELECT 1 FROM mobile_role_accounts WHERE login=? COLLATE NOCASE", (login,)).fetchone():
        raise ValueError("That username is already taken.")
    role = resolve(None, invite["role"])
    name = display_name or invite.get("display_name") or login
    conn.execute(
        "INSERT INTO mobile_role_accounts(login,password_hash,role,display_name,phone,"
        "linked_patient_id,invite_code,created_at) VALUES(?,?,?,?,?,?,?,?)",
        (login, password_hash, role, name, invite.get("phone") or "",
         invite.get("linked_patient_id"), code, now()),
    )
    conn.execute("UPDATE mobile_role_invites SET used_at=?,used_login=? WHERE id=?",
                 (now(), login, invite["id"]))
    conn.commit()
    return {"login": login, "role": role, "label": ROLES[role]["label"],
            "display_name": name, "linked_patient_id": invite.get("linked_patient_id")}


def account_for(conn, login: str):
    row = conn.execute(
        "SELECT id,login,password_hash,role,display_name,phone,email,linked_patient_id,"
        "linked_employee_id,status FROM mobile_role_accounts WHERE login=? COLLATE NOCASE",
        (login,),
    ).fetchone()
    if not row:
        return None
    return dict(row) if hasattr(row, "keys") else {
        "id": row[0], "login": row[1], "password_hash": row[2], "role": row[3],
        "display_name": row[4], "phone": row[5], "email": row[6],
        "linked_patient_id": row[7], "linked_employee_id": row[8], "status": row[9]}


def mark_login(conn, login: str) -> None:
    conn.execute("UPDATE mobile_role_accounts SET last_login_at=? WHERE login=? COLLATE NOCASE",
                 (now(), login))
    conn.commit()


def accounts(conn) -> list[dict]:
    rows = conn.execute(
        "SELECT id,login,role,display_name,phone,linked_patient_id,status,created_at,last_login_at"
        " FROM mobile_role_accounts ORDER BY id"
    ).fetchall()
    out = []
    for row in rows:
        item = dict(row) if hasattr(row, "keys") else {
            "id": row[0], "login": row[1], "role": row[2], "display_name": row[3],
            "phone": row[4], "linked_patient_id": row[5], "status": row[6],
            "created_at": row[7], "last_login_at": row[8]}
        item["label"] = ROLES.get(item["role"], {}).get("label", item["role"])
        out.append(item)
    return out


def set_status(conn, login: str, status: str) -> None:
    if status not in ("Active", "Suspended"):
        raise ValueError("Status must be Active or Suspended.")
    conn.execute("UPDATE mobile_role_accounts SET status=? WHERE login=? COLLATE NOCASE",
                 (status, login))
    conn.commit()
