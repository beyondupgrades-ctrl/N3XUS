"""Simple rule engine (100% free, in-house).

Rules are plain Python functions that inspect the DB and return a list of
"findings" (dicts). The runner logs each finding and, if autonomy >= 3,
creates an M4STR0 proposal automatically. No external service needed.
"""
from __future__ import annotations


def rule_overdue_invoices(conn):
    rows = conn.execute(
        "SELECT id, invoice_no, due_date FROM qf3_invoices WHERE status IN ('issued','part_paid')").fetchall()
    today = __import__("datetime").date.today().isoformat()
    out = []
    for r in rows:
        if r["due_date"] and r["due_date"] < today:
            out.append({"rule": "overdue_invoice", "ref": r["id"],
                        "title": "Overdue invoice " + str(r["invoice_no"]),
                        "detail": "Due " + str(r["due_date"])})
    return out


def rule_pending_leave(conn):
    rows = conn.execute("SELECT COUNT(*) c FROM leave_records WHERE status='Pending'").fetchone()
    c = rows["c"] if rows else 0
    if c and c >= 3:
        return [{"rule": "pending_leave_backlog", "ref": 0,
                 "title": "Leave backlog", "detail": str(c) + " pending leave requests"}]
    return []


def rule_low_stock(conn):
    try:
        rows = conn.execute("SELECT id,name FROM inventory_items WHERE qty_on_hand <= reorder_level").fetchall()
    except Exception:
        return []
    return [{"rule": "low_stock", "ref": r["id"],
             "title": "Low stock: " + str(r["name"]), "detail": "Reorder needed"} for r in rows]


def rule_fatigue(conn):
    try:
        rows = conn.execute("SELECT employee_id, COUNT(*) c FROM attendance_daily WHERE total_hours > 10 GROUP BY employee_id").fetchall()
    except Exception:
        return []
    out = []
    for r in rows:
        if r["c"] and r["c"] >= 3:
            out.append({"rule": "fatigue_risk", "ref": int(r["employee_id"]),
                        "title": "Fatigue risk: employee " + str(r["employee_id"]),
                        "detail": str(r["c"]) + " days over 10 hours"})
    return out


def rule_backup_health(conn):
    # Flag if no backup in the last 7 days (best-effort: check audit_log)
    try:
        row = conn.execute("SELECT created_at FROM audit_log WHERE action='Created full backup' ORDER BY id DESC LIMIT 1").fetchone()
    except Exception:
        return []
    if not row:
        return [{"rule": "backup_overdue", "ref": 0, "title": "No backup on record",
                 "detail": "Create a backup to protect business data."}]
    try:
        from datetime import datetime, timedelta
        last = datetime.fromisoformat(str(row["created_at"]).replace(" ", "T"))
        if last < datetime.now() - timedelta(days=7):
            return [{"rule": "backup_overdue", "ref": 0, "title": "Backup overdue",
                     "detail": "Last backup was " + str(row["created_at"])}]
    except Exception:
        pass
    return []


def rule_anomaly_large_payment(conn):
    try:
        rows = conn.execute("SELECT id, amount FROM qf3_payments WHERE amount > 100000 AND status='pending'").fetchall()
    except Exception:
        return []
    return [{"rule": "anomaly_large_payment", "ref": r["id"],
             "title": "Unusually large pending payment", "detail": "Amount " + str(r["amount"])} for r in rows]


RULES = [rule_overdue_invoices, rule_pending_leave, rule_low_stock,
         rule_fatigue, rule_backup_health, rule_anomaly_large_payment]


# Step 2: confidence scoring + auto-approval helpers
def confidence(finding):
    # Simple rule-based confidence: routine findings = high, anomalies = low
    if "anomaly" in finding.get("rule", ""):
        return 0.4
    if finding.get("rule") in ("overdue_invoice", "pending_leave_backlog"):
        return 0.85
    return 0.7


def should_auto_approve(finding, autonomy_level):
    if autonomy_level < 3:
        return False
    if "anomaly" in finding.get("rule", ""):
        return False
    return confidence(finding) >= 0.8


def evaluate(conn):
    findings = []
    for r in RULES:
        try:
            findings.extend(r(conn) or [])
        except Exception:
            pass
    return findings


def run(conn, service=None):
    findings = evaluate(conn)
    # autonomy level from DB
    try:
        row = conn.execute("SELECT value FROM attendance_settings WHERE key='autonomy_level'").fetchone()
        lvl = int(row["value"]) if row and row["value"] else 2
    except Exception:
        lvl = 2
    for f in findings:
        try:
            dup = conn.execute(
                "SELECT id FROM mstr_proposals WHERE kind=? AND ref_table='rule' AND ref_id=? AND status='pending'",
                (f["rule"], int(f["ref"]))).fetchone()
            if dup:
                continue
            status = "pending"
            if should_auto_approve(f, lvl):
                status = "acknowledged"
            conn.execute(
                "INSERT INTO mstr_proposals(kind,ref_table,ref_id,title,detail,status,created_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (f["rule"], "rule", int(f["ref"]), f["title"][:300], f["detail"][:2000], status,
                 __import__("datetime").datetime.now().isoformat(timespec="seconds")))
        except Exception:
            pass
    try:
        conn.commit()
    except Exception:
        pass
    if service is not None:
        try:
            service.store.log("rules", "Rule engine ran", "rules", 0, str(len(findings)) + " findings")
            service.store.conn.commit()
        except Exception:
            pass
    return findings