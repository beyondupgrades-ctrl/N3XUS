"""Apply the lock fixes to web_backend.py and mastr0.py, one guarded edit at a time.

Each step asserts that its anchor exists exactly once, so a partial or mistaken
edit cannot pass silently. Run from the desktop folder on C:.
"""
import io
import sys

WEB = "web_backend.py"
MSTR = "mastr0.py"


def patch(path, pairs):
    text = io.open(path, encoding="utf-8").read()
    for old, new in pairs:
        count = text.count(old)
        if count != 1:
            raise SystemExit(f"{path}: anchor found {count} times, expected 1:\n{old[:120]}")
        text = text.replace(old, new, 1)
    io.open(path, "w", encoding="utf-8", newline="").write(text)
    print(f"{path}: applied {len(pairs)} edit(s)")


SLOW_LOCK = '''class SlowLock(threading.RLock):
    """The one data lock, but it says so when a hold runs long.

    Every request takes this lock, so one slow holder stalls every phone behind
    it. Without a trace, a stall is invisible until someone waits out the whole
    BR_LOCK_WAIT and gets a 503. Anything held longer than SLOW_LOCK_SECONDS is
    logged with the endpoint that held it, which is what a support question
    needs. RLock, so a nested acquire on the same thread still works, and the
    outermost hold is the one timed.
    """

    SLOW_LOCK_SECONDS = float(os.environ.get("BR_SLOW_LOCK", "2"))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._depth = 0
        self._started = 0.0

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc_info):
        self.release()
        return False

    def acquire(self, blocking=True, timeout=-1):
        started = time.monotonic()
        acquired = super().acquire(blocking, timeout)
        if acquired:
            waited = time.monotonic() - started
            if waited >= self.SLOW_LOCK_SECONDS:
                holder = getattr(SERVICE, "_lock_holder", None) or "another request"
                print(f"[BR lock] waited {waited:.1f}s for the data lock, held by {holder}", flush=True)
            self._depth += 1
            if self._depth == 1:
                self._started = time.monotonic()
        return acquired

    def release(self):
        self._depth = max(0, self._depth - 1)
        outermost = self._depth == 0
        started = self._started
        super().release()
        if outermost and started:
            held = time.monotonic() - started
            self._started = 0.0
            if held >= self.SLOW_LOCK_SECONDS:
                holder = getattr(SERVICE, "_lock_holder", None) or "an unlabelled section"
                print(f"[BR lock] held {held:.1f}s by {holder}", flush=True)


'''

SIGN_IN = '''SIGN_IN_WAIT_SECONDS = float(os.environ.get("BR_SIGNIN_WAIT", "3"))


def _sign_in_row(load):
    """Run a sign-in read without queueing behind a long write.

    Signing in only reads one row (admins, or employees JOIN mobile_accounts).
    Those rows are already in memory, but the global lock may be held by a
    background cycle, and waiting out the full BR_LOCK_WAIT is what turns a
    busy server into a 503 on the sign-in screen. So: take the lock if it is
    free within a few seconds, and if it is not, read anyway. The worst case is
    comparing one password hash from a moment ago - the person simply tries
    again - which is far better than refusing everyone who signs in during a
    scan.
    """
    lock = getattr(SERVICE, "lock", None)
    held = False
    if lock is not None:
        try:
            held = lock.acquire(timeout=SIGN_IN_WAIT_SECONDS)
        except Exception:
            held = False
        if not held:
            print("[BR lock] sign-in answered without the data lock (held by "
                  f"{getattr(SERVICE, '_lock_holder', None) or 'a background cycle'})", flush=True)
    try:
        return load()
    finally:
        if held:
            lock.release()


'''

web_edits = [
    # 1. the lock itself
    ("        self.lock = threading.RLock()\n", "        self.lock = SlowLock()\n"),
    # 2. the lock class, defined before AppService uses it
    ("class AppService:\n", SLOW_LOCK + "class AppService:\n"),
    # 3. the fast sign-in helper, next to the other lock helpers
    ("LOCK_WAIT_SECONDS = float(os.environ.get(\"BR_LOCK_WAIT\", \"90\"))\n",
     SIGN_IN + "LOCK_WAIT_SECONDS = float(os.environ.get(\"BR_LOCK_WAIT\", \"90\"))\n"),
    # 4. safety monitor: lock per alert, not for the whole tick
    ('''        due = self.query("SELECT id,escalation_stage FROM safety_alerts WHERE status IN ('Open','Escalated') AND next_escalate_at!='' AND next_escalate_at<=? AND escalation_stage<3", (now,))
        for row in due:
            self.escalate_safety_alert(int(row["id"]), int(row["escalation_stage"]) + 1)''',
     '''        due = self.query("SELECT id,escalation_stage FROM safety_alerts WHERE status IN ('Open','Escalated') AND next_escalate_at!='' AND next_escalate_at<=? AND escalation_stage<3", (now,))
        for row in due:
            with self.lock:
                self.escalate_safety_alert(int(row["id"]), int(row["escalation_stage"]) + 1)'''),
    ('''            if age_min > 15:
                self.raise_safety_alert(pid, "inactivity", "warning", f"No check-in for {int(age_min)} minutes during active walk.", "system")''',
     '''            if age_min > 15:
                with self.lock:
                    self.raise_safety_alert(pid, "inactivity", "warning", f"No check-in for {int(age_min)} minutes during active walk.", "system")'''),
    ('''                if page > 10:
                    self.raise_safety_alert(pid, "gps_loss", "warning", f"No GPS update for {int(page)} minutes.", "system")''',
     '''                if page > 10:
                    with self.lock:
                        self.raise_safety_alert(pid, "gps_loss", "warning", f"No GPS update for {int(page)} minutes.", "system")'''),
    ('''                if bat is not None and float(bat) < 20:
                    self.raise_safety_alert(pid, "low_battery", "warning", f"Device battery at {float(bat):.0f}%.", "system")''',
     '''                if bat is not None and float(bat) < 20:
                    with self.lock:
                        self.raise_safety_alert(pid, "low_battery", "warning", f"Device battery at {float(bat):.0f}%.", "system")'''),
    ('''                        if 0 < dt < 120 and dist > 150:
                            self.raise_safety_alert(pid, "unexpected_movement", "warning", f"Position jumped {int(dist)}m in {int(dt)}s.", "system")''',
     '''                        if 0 < dt < 120 and dist > 150:
                            with self.lock:
                                self.raise_safety_alert(pid, "unexpected_movement", "warning", f"Position jumped {int(dist)}m in {int(dt)}s.", "system")'''),
    ('''                if g:
                    self.raise_safety_alert(pid, g, "warning", f"Outside designated safe area at {ping['latitude']},{ping['longitude']}.", "system")''',
     '''                if g:
                    with self.lock:
                        self.raise_safety_alert(pid, g, "warning", f"Outside designated safe area at {ping['latitude']},{ping['longitude']}.", "system")'''),
    # 5. safety loop: no global hold around the tick
    ('''    def _safety_loop(self):
        # Run an immediate tick on startup so overdue escalations are not delayed
        # by up to 60s after a restart (durability across restarts).
        try:
            with self.lock:
                self.safety_monitor_tick()
        except Exception as exc:
            print(f"[NAVIQ safety monitor] {exc}")
        while not self._safety_stop.wait(60):
            try:
                with self.lock:
                    self.safety_monitor_tick()
            except Exception as exc:''',
     '''    def _safety_loop(self):
        # Run an immediate tick on startup so overdue escalations are not delayed
        # by up to 60s after a restart (durability across restarts).
        # The tick does not run under the global lock: it takes the lock once per
        # alert it raises (see safety_monitor_tick), so a request waits for one
        # alert at most, never for the whole sweep.
        try:
            self.safety_monitor_tick()
        except Exception as exc:
            print(f"[NAVIQ safety monitor] {exc}")
        while not self._safety_stop.wait(60):
            try:
                self.safety_monitor_tick()
            except Exception as exc:'''),
    # 6. M4STR0 scheduler: per-agent holds, one commit per cycle
    ('''                with SERVICE.lock:
                    if not mastr0.paused(SERVICE.store.conn):
                        mastr0.run_cycle(SERVICE.store.conn)''',
     '''                # One agent at a time, each under its own short hold, and a single
                # commit for the whole cycle (see mastr0.run_cycle). Holding the
                # lock for the entire cycle put every request behind a scan.
                with SERVICE.lock:
                    if not getattr(SERVICE, "_qf3_ready", False):
                        quoteflow.ensure_schema(SERVICE.store.conn)
                        mastr0.ensure_schema(SERVICE.store.conn)
                        SERVICE._qf3_ready = True
                    paused = mastr0.paused(SERVICE.store.conn)
                if not paused:
                    mastr0.run_cycle(SERVICE.store.conn, lock=SERVICE.lock)'''),
    ('''                if not getattr(SERVICE, "_qf3_ready", False):
                    quoteflow.ensure_schema(SERVICE.store.conn)
                    mastr0.ensure_schema(SERVICE.store.conn)
                    SERVICE._qf3_ready = True
                # One agent at a time''',
     '''                # One agent at a time'''),
    # 7. fast sign-in at the three sign-in reads
    ('            row=SERVICE.store.authenticate(username,str(data.get("password") or ""))',
     '            row=_sign_in_row(lambda: SERVICE.store.authenticate(username,str(data.get("password") or "")))'),
    ('''            row=SERVICE.store.conn.execute("SELECT e.id,e.employee_no,e.first_name,e.last_name,a.password_hash,a.mobile_profile FROM employees e JOIN mobile_accounts a ON a.employee_id=e.id WHERE e.employee_no=? COLLATE NOCASE AND a.active=1 AND e.employment_status='Active'",(employee_no,)).fetchone()''',
     '''            row=_sign_in_row(lambda: SERVICE.store.conn.execute("SELECT e.id,e.employee_no,e.first_name,e.last_name,a.password_hash,a.mobile_profile FROM employees e JOIN mobile_accounts a ON a.employee_id=e.id WHERE e.employee_no=? COLLATE NOCASE AND a.active=1 AND e.employment_status='Active'",(employee_no,)).fetchone())'''),
    ('''                matches = SERVICE.query("""SELECT e.id,e.employee_no,e.first_name,e.last_name,a.password_hash,a.mobile_profile''',
     '''                matches = _sign_in_row(lambda: SERVICE.query("""SELECT e.id,e.employee_no,e.first_name,e.last_name,a.password_hash,a.mobile_profile'''),
    ('''                                             AND TRIM(e.first_name||' '||e.last_name)=? COLLATE NOCASE""",(wanted,))''',
     '''                                             AND TRIM(e.first_name||' '||e.last_name)=? COLLATE NOCASE""",(wanted,)))'''),
    ('''            rows=SERVICE.store.conn.execute("SELECT username,full_name FROM admins WHERE active=1 ORDER BY full_name COLLATE NOCASE,username COLLATE NOCASE").fetchall()''',
     '''            rows=_sign_in_row(lambda: SERVICE.store.conn.execute("SELECT username,full_name FROM admins WHERE active=1 ORDER BY full_name COLLATE NOCASE,username COLLATE NOCASE").fetchall())'''),
]

mstr_edits = [
    ('''def run_cycle(conn):
    """One orchestration pass. Returns counts of new proposals."""
    ensure_schema(conn)
    if paused(conn):
        return {"paused": True, "proposals": 0}
    total = 0
    for name, fn in AGENT_FUNCS.items():
        agent = conn.execute("SELECT enabled FROM mstr_agents WHERE name=?", (name,)).fetchone()
        if agent and not agent["enabled"]:
            continue
        try:
            total += fn(conn)
        except Exception as exc:  # agent failure must not kill the cycle
            conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                         (name, "scan", f"error: {exc}"[:400], "fail", mode(conn), _now()))
            conn.execute("UPDATE mstr_agents SET failures=failures+1 WHERE name=?", (name,))''',
     '''def run_cycle(conn, lock=None):
    """One orchestration pass. Returns counts of new proposals.

    ``lock`` is the server's data lock. Given one, each agent runs under its own
    short hold and the cycle ends with ONE commit, instead of the caller holding
    the lock for the whole cycle. Every commit re-encrypts and rewrites the
    entire database, so a commit per agent (and per proposal) was the expensive
    part: a phone signing in during a scan waited for all of it. Without a lock
    this behaves exactly as before, which is what tests and direct callers get.
    """
    ensure_schema(conn)
    if paused(conn):
        return {"paused": True, "proposals": 0}
    total = 0
    for name, fn in AGENT_FUNCS.items():
        if lock is not None:
            with lock:
                agent = conn.execute("SELECT enabled FROM mstr_agents WHERE name=?", (name,)).fetchone()
                if agent and not agent["enabled"]:
                    continue
                try:
                    total += fn(conn)
                except Exception as exc:  # agent failure must not kill the cycle
                    conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                                 (name, "scan", f"error: {exc}"[:400], "fail", mode(conn), _now()))
                    conn.execute("UPDATE mstr_agents SET failures=failures+1 WHERE name=?", (name,))
            continue
        agent = conn.execute("SELECT enabled FROM mstr_agents WHERE name=?", (name,)).fetchone()
        if agent and not agent["enabled"]:
            continue
        try:
            total += fn(conn)
        except Exception as exc:  # agent failure must not kill the cycle
            conn.execute("INSERT INTO mstr_runs(agent,trigger,detail,status,mode,created_at) VALUES(?,?,?,?,?,?)",
                         (name, "scan", f"error: {exc}"[:400], "fail", mode(conn), _now()))
            conn.execute("UPDATE mstr_agents SET failures=failures+1 WHERE name=?", (name,))'''),
    ('''        for p in pending:
            if p["kind"] in routine:
                try:
                    decide_proposal(conn, "autonomy", p["id"], True, "auto-approved (autonomy level 3)")
                except Exception:
                    pass
    conn.commit()
    return {"paused": False, "proposals": total, "mode": mode(conn)}''',
     '''        for p in pending:
            if p["kind"] in routine:
                try:
                    if lock is not None:
                        with lock:
                            decide_proposal(conn, "autonomy", p["id"], True, "auto-approved (autonomy level 3)")
                    else:
                        decide_proposal(conn, "autonomy", p["id"], True, "auto-approved (autonomy level 3)")
                except Exception:
                    pass
    # One commit for the whole cycle: each commit rewrites the encrypted file.
    if lock is not None:
        with lock:
            conn.commit()
    else:
        conn.commit()
    return {"paused": False, "proposals": total, "mode": mode(conn)}'''),
]

if __name__ == "__main__":
    patch(WEB, web_edits)
    patch(MSTR, mstr_edits)
    print("done")
