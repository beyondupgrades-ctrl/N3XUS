"""EVOLV3 weekly self-evolving curriculum engine.

Additive-only evolution for the in-house Beyond Registration Academy:

* one new eldercare / dementia module every seven days,
* three new evaluation items (short question, quiz, mini assignment),
* one new clinical library protocol.

Nothing is ever replaced or deleted. Every row has a stable id derived from the
week number, so a repeated run is a no-op instead of a duplicate. The generator
uses Gemini when ``GEMINI_API_KEY`` / ``GOOGLE_API_KEY`` is configured, but a
complete rotating clinical curriculum is always available offline.
"""
from __future__ import annotations

import json
import os
import re
import urllib.parse
import urllib.request
from datetime import datetime, timedelta

import notifications

VERSION = "2.0.0"
SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000
GEMINI_MODEL = os.environ.get("EVOLV3_GEMINI_MODEL", "gemini-3.8-flash").strip() or "gemini-3.8-flash"

SCHEMA = """
CREATE TABLE IF NOT EXISTS evolv3_evolution_state(
  id INTEGER PRIMARY KEY CHECK(id=1),
  version TEXT NOT NULL DEFAULT '2.0.0',
  week_number INTEGER NOT NULL DEFAULT 1,
  last_evolved_at TEXT NOT NULL,
  auto_update_on_wifi INTEGER NOT NULL DEFAULT 1,
  changelog TEXT NOT NULL DEFAULT '[]',
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS evolv3_week_modules(
  id TEXT PRIMARY KEY, week_added INTEGER NOT NULL, title TEXT NOT NULL,
  category TEXT NOT NULL, hours REAL NOT NULL DEFAULT 10, description TEXT DEFAULT '',
  highlights TEXT DEFAULT '[]', hazards TEXT DEFAULT '[]', video TEXT DEFAULT '[]',
  source TEXT DEFAULT 'local', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS evolv3_week_evaluations(
  id TEXT PRIMARY KEY, week_added INTEGER NOT NULL, kind TEXT NOT NULL,
  module_id TEXT DEFAULT '', module_title TEXT DEFAULT '', prompt TEXT NOT NULL,
  options TEXT DEFAULT '[]', answer TEXT DEFAULT '', expected TEXT DEFAULT '',
  keywords TEXT DEFAULT '[]', tips TEXT DEFAULT '[]', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS evolv3_week_protocols(
  id TEXT PRIMARY KEY, week_added INTEGER NOT NULL, title TEXT NOT NULL,
  category TEXT DEFAULT 'Clinical', urgency TEXT DEFAULT 'Routine',
  summary TEXT DEFAULT '', steps TEXT DEFAULT '[]', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS evolv3_learner_state(
  user TEXT PRIMARY KEY, state TEXT NOT NULL, updated_at TEXT NOT NULL
);
"""

# ---------------------------------------------------------------------------
# Rotating local curriculum. Each entry is a complete, clinically reviewed-ish
# internal module used when no valid Gemini credential is present.
# ---------------------------------------------------------------------------
WEEKLY_TEMPLATES = [
    {
        "title": "IDDSI Dysphagia Food Thickening",
        "category": "Safety & First Aid",
        "hours": 10,
        "description": "Texture-modified nutrition using the International Dysphagia Diet Standardisation Initiative framework, covering thickening levels 0-4, safe utensil loading and mealtime supervision.",
        "highlights": [
            "IDDSI levels 0-4 explained with practical kitchen checks",
            "Fork drip, spoon tilt and syringe flow tests",
            "Positioning, chin-tuck and 30-minute mealtime rule",
        ],
        "hazards": ["Silent aspiration", "Over-thickening dehydration", "Unsafe mixed textures"],
        "video": [
            {"t": "00:00", "label": "Level 0-4 syrup comparison", "av": "Visual: viscosity ladder · Audio: narration"},
            {"t": "06:20", "label": "Fork drip test demonstration", "av": "Visual: close-up hands · Audio: ambient kitchen"},
            {"t": "13:40", "label": "Mealtime positioning and cueing", "av": "Visual: seated posture · Audio: slow coaching"},
        ],
        "short": {
            "prompt": "A resident with Parkinson's coughs after every second spoon of thin soup. Describe your immediate IDDSI response.",
            "expected": "Stop feeding, keep the resident upright, assess for aspiration, request a speech-language pathology review, thicken fluids to the prescribed IDDSI level, and document the incident.",
            "keywords": ["stop", "upright", "aspiration", "speech", "thicken", "iddsi", "document"],
            "tips": ["Name the immediate stop-feed step first.", "Mention SLP referral and prescribed IDDSI level."],
        },
        "quiz": {
            "prompt": "Which IDDSI level is a mildly thick fluid that drips slowly through a fork?",
            "options": ["Level 0 Thin", "Level 1 Slightly Thick", "Level 2 Mildly Thick", "Level 4 Extremely Thick"],
            "answer": "Level 2 Mildly Thick",
            "expected": "Level 2 Mildly Thick drips slowly through a fork and is prescribed for mild dysphagia.",
            "keywords": ["level 2", "mildly thick", "fork", "drip"],
        },
        "assignment": {
            "prompt": "Write a 120-word mealtime care plan for a frail resident on IDDSI Level 3 fluids with a history of silent aspiration.",
            "expected": "Include upright 90-degree positioning, prescribed Level 3 fluids, small spoonfuls, chin tuck, no mixed textures, 30-minute limit, supervision, oral care, and documentation of intake and any cough or wet voice.",
            "keywords": ["upright", "level 3", "small", "chin tuck", "mixed texture", "30", "supervision", "oral care", "document"],
            "tips": ["Include positioning and supervision.", "Add oral care and intake documentation."],
        },
    },
    {
        "title": "Sundowning & Circadian Light Therapy",
        "category": "Dementia Care",
        "hours": 12,
        "description": "Evidence-based non-pharmacological management of late-day agitation using bright morning light, routine anchoring, noise control and sleep hygiene.",
        "highlights": [
            "Morning bright-light exposure protocol (30-60 minutes)",
            "Evening dimming and blue-light reduction",
            "Routine anchoring and snack timing",
        ],
        "hazards": ["Falls in low light", "Melatonin overuse", "Missed pain or infection"],
        "video": [
            {"t": "00:00", "label": "Sundowning timeline", "av": "Visual: 24-hour clock · Audio: calm narration"},
            {"t": "07:10", "label": "Bright-light session setup", "av": "Visual: lounge lighting · Audio: ambient room"},
            {"t": "15:30", "label": "Evening de-escalation walk-through", "av": "Visual: dimmed corridor · Audio: quiet coaching"},
        ],
        "short": {
            "prompt": "A resident becomes agitated every day at 17:30. List four non-drug measures you would start today.",
            "expected": "Bright morning light, consistent routine and meal timing, reduced evening noise and clutter, pain and infection screening, gentle orientation and a calming activity before sunset.",
            "keywords": ["morning light", "routine", "evening", "noise", "pain", "infection", "orientation", "activity"],
            "tips": ["Cover light exposure and routine first.", "Include a medical cause screen (pain, infection, constipation)."],
        },
        "quiz": {
            "prompt": "What is the first-line approach to sundowning in dementia care?",
            "options": ["Increase sedative dose", "Restrain the resident", "Non-pharmacological routine and light therapy", "Keep the resident in bed"],
            "answer": "Non-pharmacological routine and light therapy",
            "expected": "Non-pharmacological routine, bright morning light and sleep hygiene are first-line before any medication review.",
            "keywords": ["non-pharmacological", "routine", "light", "sleep"],
        },
        "assignment": {
            "prompt": "Design a 24-hour light and routine plan for a resident with vascular dementia and late-day agitation.",
            "expected": "Morning outdoor or bright light 30-60 minutes, regular meals and activities, evening dimming, no daytime napping over 30 minutes, pain screen, calming bedtime routine, and documented behaviour log.",
            "keywords": ["morning", "light", "30", "routine", "dim", "nap", "pain", "bedtime", "log"],
            "tips": ["Quantify light exposure minutes.", "Add a behaviour log for the care team."],
        },
    },
    {
        "title": "Preventing Silent Aspiration in Frail Seniors",
        "category": "Safety & First Aid",
        "hours": 12,
        "description": "Recognising the quiet signs of aspiration - wet voice, micro-cough, low-grade fever and reduced oxygen saturation - before pneumonia develops.",
        "highlights": [
            "Wet-voice and micro-cough screening",
            "SpO2 and temperature trend watching",
            "Oral care as pneumonia prevention",
        ],
        "hazards": ["Aspiration pneumonia", "Missed fever", "Unsafe oral medication rounds"],
        "video": [
            {"t": "00:00", "label": "Silent aspiration signs", "av": "Visual: annotated mouth/throat · Audio: clinical narration"},
            {"t": "05:50", "label": "Wet voice listening exercise", "av": "Visual: waveform · Audio: voice samples"},
            {"t": "12:15", "label": "Oral care and medication round", "av": "Visual: bedside demo · Audio: step-by-step"},
        ],
        "short": {
            "prompt": "What four quiet signs suggest silent aspiration after a meal?",
            "expected": "Wet or gurgly voice, a weak or absent cough, falling oxygen saturation, and low-grade fever or new confusion after eating.",
            "keywords": ["wet voice", "gurgly", "cough", "oxygen", "saturation", "fever", "confusion"],
            "tips": ["Name the voice change.", "Add observations rather than only symptoms."],
        },
        "quiz": {
            "prompt": "Which observation most strongly suggests silent aspiration?",
            "options": ["Loud productive cough", "Wet gurgly voice after swallowing", "Refusing vegetables", "Slow walking"],
            "answer": "Wet gurgly voice after swallowing",
            "expected": "A wet gurgly voice after swallowing is a classic sign of material sitting near the vocal folds.",
            "keywords": ["wet", "gurgly", "voice", "swallow"],
        },
        "assignment": {
            "prompt": "Write a post-meal observation checklist for a care team managing a resident with recurrent chest infections.",
            "expected": "Check voice quality, cough, breathing rate, SpO2, temperature, oral intake, positioning and any new confusion; escalate to nursing if two or more signs are present and document each meal.",
            "keywords": ["voice", "cough", "breathing", "spo2", "temperature", "position", "confusion", "escalate", "document"],
            "tips": ["Include objective measurements.", "State the escalation threshold."],
        },
    },
    {
        "title": "Post-Fall Neurological Monitoring",
        "category": "Safety & First Aid",
        "hours": 10,
        "description": "The first 24-48 hours after a fall: neurological observations, anticoagulant risk, spinal precautions and safe mobilisation decisions.",
        "highlights": [
            "GCS, pupils and limb-strength checks",
            "Anticoagulant and antiplatelet escalation",
            "Delayed intracranial bleed warning signs",
        ],
        "hazards": ["Delayed intracranial bleed", "Undetected fracture", "Second fall"],
        "video": [
            {"t": "00:00", "label": "Immediate post-fall check", "av": "Visual: body sweep · Audio: calm instruction"},
            {"t": "08:05", "label": "Neurological observation set", "av": "Visual: GCS chart · Audio: clinical narration"},
            {"t": "16:20", "label": "Safe transfer decision", "av": "Visual: hoist setup · Audio: team call-outs"},
        ],
        "short": {
            "prompt": "A resident on warfarin falls and hits their head but initially seems fine. What is your escalation?",
            "expected": "Do not leave them alone, perform neurological observations, contact the clinician immediately because of anticoagulation, arrange urgent assessment or CT, and monitor for headache, vomiting, drowsiness or pupil change.",
            "keywords": ["warfarin", "anticoagulant", "neuro", "observations", "clinician", "urgent", "ct", "headache", "vomiting", "drowsiness"],
            "tips": ["Anticoagulation changes the urgency.", "List delayed bleed signs."],
        },
        "quiz": {
            "prompt": "Which finding after a head strike requires immediate escalation?",
            "options": ["Mild bruise", "New drowsiness and unequal pupils", "Request for water", "A single sneeze"],
            "answer": "New drowsiness and unequal pupils",
            "expected": "New drowsiness with unequal pupils suggests raised intracranial pressure and needs emergency escalation.",
            "keywords": ["drowsiness", "unequal pupils", "emergency"],
        },
        "assignment": {
            "prompt": "Create a 24-hour post-fall observation schedule for a resident on apixaban.",
            "expected": "Neurological observations at set intervals (e.g. 15, 30, 60 minutes then hourly), blood pressure and pulse, pain and mobility checks, warning-sign education for staff, and clear escalation to the clinician or emergency services.",
            "keywords": ["15", "30", "hourly", "blood pressure", "pulse", "pain", "escalate", "apixaban"],
            "tips": ["Give a concrete schedule.", "Include vital signs and escalation."],
        },
    },
    {
        "title": "Infection Control & Catheter Hygiene",
        "category": "Daily Care & Mobility",
        "hours": 10,
        "description": "Catheter-associated urinary tract infection prevention, aseptic technique, drainage management and early sepsis recognition.",
        "highlights": [
            "Aseptic insertion and daily meatal care",
            "Closed drainage and bag positioning",
            "CAUTI and sepsis red flags",
        ],
        "hazards": ["CAUTI", "Urosepsis", "Blocked catheter"],
        "video": [
            {"t": "00:00", "label": "Aseptic catheter care", "av": "Visual: gloved technique · Audio: procedural narration"},
            {"t": "06:45", "label": "Bag positioning and sampling", "av": "Visual: bedside setup · Audio: instruction"},
            {"t": "14:10", "label": "Sepsis red flags", "av": "Visual: observation chart · Audio: urgent coaching"},
        ],
        "short": {
            "prompt": "List four actions that reduce catheter-associated urinary tract infection.",
            "expected": "Only catheterise when indicated, use aseptic insertion, maintain a closed system with the bag below bladder level, perform regular meatal hygiene, and review the need for the catheter daily.",
            "keywords": ["indication", "aseptic", "closed", "below bladder", "hygiene", "daily review", "remove"],
            "tips": ["Start with appropriate indication.", "Mention daily review or early removal."],
        },
        "quiz": {
            "prompt": "Where should a urinary drainage bag sit?",
            "options": ["Above bladder level", "On the bed beside the hip", "Below bladder level without touching the floor", "On the resident's lap"],
            "answer": "Below bladder level without touching the floor",
            "expected": "Below bladder level and off the floor to prevent backflow and contamination.",
            "keywords": ["below bladder", "floor", "backflow"],
        },
        "assignment": {
            "prompt": "Write a daily catheter checklist for a care assistant working in a frail-care unit.",
            "expected": "Check indication, patency, bag position, meatal hygiene, urine appearance, hydration, temperature, pain and confusion; document and escalate cloudy, offensive urine with fever or new confusion.",
            "keywords": ["indication", "patency", "bag", "hygiene", "urine", "hydration", "temperature", "confusion", "escalate"],
            "tips": ["Make it a checklist, not a paragraph.", "Include sepsis red flags."],
        },
    },
    {
        "title": "Polypharmacy Side-Effect Triage",
        "category": "Fundamentals",
        "hours": 14,
        "description": "Recognising medication-related falls, confusion, constipation and hypotension in residents taking five or more medicines.",
        "highlights": [
            "Anticholinergic burden and sedation risk",
            "Orthostatic blood pressure checks",
            "Medication review escalation pathway",
        ],
        "hazards": ["Orthostatic hypotension", "Sedation-related falls", "Missed drug interaction"],
        "video": [
            {"t": "00:00", "label": "Polypharmacy risk map", "av": "Visual: medication wheel · Audio: clinical narration"},
            {"t": "09:30", "label": "Orthostatic BP measurement", "av": "Visual: lying-to-standing demo · Audio: coaching"},
            {"t": "18:00", "label": "Medication review conversation", "av": "Visual: GP consult · Audio: dialogue"},
        ],
        "short": {
            "prompt": "A resident on eight medicines becomes newly confused and unsteady. What medication-related causes do you screen for?",
            "expected": "Recent medicine changes, sedatives and anticholinergics, orthostatic hypotension, hypoglycaemia, electrolyte disturbance, infection and drug interactions; check blood pressure lying and standing and request a medication review.",
            "keywords": ["recent change", "sedative", "anticholinergic", "orthostatic", "hypoglycaemia", "infection", "interaction", "medication review"],
            "tips": ["Screen for recent changes first.", "Include lying and standing blood pressure."],
        },
        "quiz": {
            "prompt": "Which class most commonly contributes to falls through sedation?",
            "options": ["Topical emollients", "Benzodiazepines", "Inhaled saline", "Vitamin D"],
            "answer": "Benzodiazepines",
            "expected": "Benzodiazepines increase sedation, confusion and fall risk, especially in older adults.",
            "keywords": ["benzodiazepine", "sedation", "fall"],
        },
        "assignment": {
            "prompt": "Write a 100-word note requesting a medication review for a resident with two falls this month.",
            "expected": "State the falls, relevant medicines (sedatives, antihypertensives, anticholinergics), lying and standing blood pressure, new confusion, and a clear request for review and deprescribing consideration.",
            "keywords": ["falls", "sedative", "antihypertensive", "blood pressure", "confusion", "review", "deprescribing"],
            "tips": ["Be specific about the medicines.", "Ask directly for a review."],
        },
    },
    {
        "title": "Pressure Injury Prevention & Repositioning",
        "category": "Daily Care & Mobility",
        "hours": 12,
        "description": "Risk assessment, 2-hourly repositioning, pressure-redistribution surfaces, skin inspection and moisture management.",
        "highlights": [
            "Braden and Waterlow risk scoring",
            "Repositioning schedules and 30-degree tilt",
            "Stage 1 pressure injury recognition",
        ],
        "hazards": ["Deep tissue injury", "Unstageable pressure ulcer", "Moisture-associated skin damage"],
        "video": [
            {"t": "00:00", "label": "Pressure points map", "av": "Visual: body diagram · Audio: narration"},
            {"t": "07:20", "label": "30-degree tilt and pillow placement", "av": "Visual: bed demonstration · Audio: coaching"},
            {"t": "14:45", "label": "Skin inspection routine", "av": "Visual: close-up checks · Audio: checklist"},
        ],
        "short": {
            "prompt": "How often should an immobile resident be repositioned, and what else must be checked each time?",
            "expected": "At least every two hours (or per assessed schedule), checking skin over pressure points, moisture, nutrition, pain, equipment and correct 30-degree positioning.",
            "keywords": ["two hours", "skin", "pressure points", "moisture", "position", "pain"],
            "tips": ["Give the two-hour baseline.", "List what is inspected."],
        },
        "quiz": {
            "prompt": "What is the recommended side-lying angle to reduce pressure on the hip?",
            "options": ["90 degrees", "60 degrees", "30 degrees", "Flat on the back"],
            "answer": "30 degrees",
            "expected": "A 30-degree tilt avoids direct pressure on the trochanter while keeping the resident comfortable.",
            "keywords": ["30 degrees", "tilt", "trochanter"],
        },
        "assignment": {
            "prompt": "Build a repositioning chart for a high-risk resident with limited mobility.",
            "expected": "Two-hourly turns with left/back/right rotation, 30-degree tilt, heel offloading, skin inspection, moisture checks, nutrition and hydration notes, and escalation for non-blanching redness.",
            "keywords": ["two-hourly", "left", "back", "right", "30", "heel", "skin", "moisture", "escalate"],
            "tips": ["Use a rotation sequence.", "Include escalation for non-blanching redness."],
        },
    },
    {
        "title": "Delirium vs Dementia: Acute Confusion Triage",
        "category": "Dementia Care",
        "hours": 12,
        "description": "Separating acute delirium from established dementia using the 4AT, identifying reversible causes and escalating safely.",
        "highlights": [
            "4AT screening in under two minutes",
            "Reversible causes: infection, pain, constipation, drugs",
            "Hypoactive delirium recognition",
        ],
        "hazards": ["Missed sepsis", "Unsafe sedation", "Missed urinary retention"],
        "video": [
            {"t": "00:00", "label": "Delirium vs dementia", "av": "Visual: timeline comparison · Audio: clinical narration"},
            {"t": "06:15", "label": "4AT walkthrough", "av": "Visual: screening form · Audio: question-by-question"},
            {"t": "13:50", "label": "Hypoactive delirium at the bedside", "av": "Visual: quiet resident · Audio: tonal guidance"},
        ],
        "short": {
            "prompt": "A care home resident becomes acutely confused overnight. What is your first-hour assessment?",
            "expected": "Screen with 4AT, check for infection, pain, constipation, urinary retention, dehydration, hypoxia and new medicines; obtain baseline dementia history, monitor vitals, and escalate to a clinician urgently.",
            "keywords": ["4at", "infection", "pain", "constipation", "urinary retention", "dehydration", "hypoxia", "medicine", "escalate"],
            "tips": ["Name the screening tool.", "Cover reversible causes systematically."],
        },
        "quiz": {
            "prompt": "Which feature most suggests delirium rather than dementia?",
            "options": ["Gradual 3-year decline", "Acute onset with fluctuating attention", "Stable word-finding difficulty", "Long-standing personality"],
            "answer": "Acute onset with fluctuating attention",
            "expected": "Delirium has an acute onset with fluctuating attention and awareness; dementia is usually gradual and progressive.",
            "keywords": ["acute", "fluctuating", "attention", "gradual"],
        },
        "assignment": {
            "prompt": "Write an escalation note for a resident with suspected hypoactive delirium.",
            "expected": "Document acute change, 4AT score, vitals, hydration, urine output, bowel history, pain, medicines, baseline cognition and the clinical escalation time and response.",
            "keywords": ["acute", "4at", "vitals", "hydration", "urine", "bowel", "pain", "medicines", "baseline", "escalate"],
            "tips": ["Include the 4AT score.", "Record the escalation time."],
        },
    },
]

WEEKLY_PROTOCOLS = [
    {
        "title": "Suspected Aspiration During a Meal",
        "category": "Airway & Breathing",
        "urgency": "Emergency",
        "summary": "Stop feeding, sit upright, assess the airway and call for clinical help if breathing is noisy, wet or laboured.",
        "steps": [
            "Stop the meal immediately and remove food from the mouth if visible.",
            "Sit the resident upright at 90 degrees and encourage a gentle cough.",
            "Check breathing, voice and colour; call the nurse or clinician.",
            "If breathing stops, start CPR and call emergency services.",
            "Document the event, food consistency and vital signs.",
        ],
    },
    {
        "title": "Sundowning Escalation Pathway",
        "category": "Dementia & Behaviour",
        "urgency": "Urgent",
        "summary": "A calm, low-stimulation response to late-day agitation with a medical cause screen before any drug request.",
        "steps": [
            "Reduce noise, bright overhead light and crowd size.",
            "Use a calm voice, open palms and the person's preferred name.",
            "Offer a snack, drink or toileting opportunity.",
            "Check pain, constipation, infection and new medicines.",
            "Escalate if agitation is new, severe or unsafe.",
        ],
    },
    {
        "title": "Post-Fall Head Strike (Anticoagulated)",
        "category": "Falls & Trauma",
        "urgency": "Emergency",
        "summary": "Any head strike on an anticoagulant needs same-day clinical assessment even if the resident initially seems well.",
        "steps": [
            "Do not move the resident until spinal injury is excluded.",
            "Check response, pupils, limb strength and vital signs.",
            "Apply a cold pack to the head bump while assessing.",
            "Contact the clinician and arrange urgent assessment or CT.",
            "Record neurological observations at 15, 30 and 60 minutes.",
        ],
    },
    {
        "title": "Catheter Blockage or Bypass",
        "category": "Infection & Hygiene",
        "urgency": "Urgent",
        "summary": "A blocked catheter can cause retention, pain and sepsis; never flush forcefully without an order.",
        "steps": [
            "Check tubing for kinks and confirm the bag is below bladder level.",
            "Palpate the bladder and ask about pain or urgency.",
            "Check urine colour, odour and volume.",
            "Contact the nurse or clinician for a catheter review.",
            "Escalate immediately for fever, rigors or new confusion.",
        ],
    },
    {
        "title": "Suspected Delirium (4AT)",
        "category": "Dementia & Behaviour",
        "urgency": "Urgent",
        "summary": "Acute confusion with fluctuating attention is a medical emergency until proven otherwise.",
        "steps": [
            "Complete the 4AT and record the score and time.",
            "Check temperature, pulse, blood pressure, SpO2 and glucose.",
            "Screen for pain, constipation, retention and dehydration.",
            "Review medicines started in the last two weeks.",
            "Escalate to a clinician the same day.",
        ],
    },
]

STOPWORDS = set("""a an the and or but if then than that this these those is are was were be been being
of to in on at by for with from as it its their they them he she his her you your we our i me my
do does did done can could should would may might must not no yes very really just also more most
about into over under between during before after above below up down out off again further once
what which who whom whose when where why how all any both each few many some such only own same so
too s t will don't should've now d ll m o re ve y ain aren couldn didn doesn hadn hasn haven isn
ma mightn mustn needn shan shouldn wasn weren won wouldn""".split())


def _now():
    return datetime.now().isoformat(timespec="seconds")


def _json(value, fallback):
    try:
        parsed = json.loads(value)
        return parsed if parsed is not None else fallback
    except Exception:
        return fallback


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    # Section 11: additive nullable column for generated module artwork.
    # ADD COLUMN only, guarded, so existing databases and clients are untouched.
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(evolv3_week_modules)").fetchall()}
        if "image_url" not in cols:
            conn.execute("ALTER TABLE evolv3_week_modules ADD COLUMN image_url TEXT DEFAULT ''")
            conn.commit()
    except Exception:
        pass
    notifications.ensure_schema(conn)
    try:
        row = conn.execute("SELECT id FROM evolv3_evolution_state WHERE id=1").fetchone()
        if not row:
            conn.execute(
                "INSERT INTO evolv3_evolution_state(id,version,week_number,last_evolved_at,"
                "auto_update_on_wifi,changelog,updated_at) VALUES(1,?,?,?,?,?,?)",
                (VERSION, 1, _now(), 1, "[]", _now()),
            )
    except Exception:
        pass
    conn.commit()


def get_state(conn):
    ensure_schema(conn)
    row = conn.execute("SELECT * FROM evolv3_evolution_state WHERE id=1").fetchone()
    if not row:
        return {
            "version": VERSION,
            "weekNumber": 1,
            "lastEvolvedAt": _now(),
            "autoUpdateOnWifi": True,
            "changelog": [],
        }
    return {
        "version": row["version"] or VERSION,
        "weekNumber": int(row["week_number"] or 1),
        "lastEvolvedAt": row["last_evolved_at"] or _now(),
        "autoUpdateOnWifi": bool(row["auto_update_on_wifi"]),
        "changelog": _json(row["changelog"], []),
    }


def set_auto_update(conn, enabled):
    ensure_schema(conn)
    conn.execute(
        "UPDATE evolv3_evolution_state SET auto_update_on_wifi=?, updated_at=? WHERE id=1",
        (1 if enabled else 0, _now()),
    )
    conn.commit()
    return get_state(conn)


def should_run_weekly_evolution(state=None):
    if not state or not state.get("autoUpdateOnWifi"):
        return False
    try:
        last = datetime.fromisoformat(str(state.get("lastEvolvedAt")))
    except Exception:
        return True
    return (datetime.now() - last).total_seconds() * 1000 >= SEVEN_DAYS_MS


def next_run_at(state):
    try:
        last = datetime.fromisoformat(str((state or {}).get("lastEvolvedAt")))
        return (last + timedelta(days=7)).isoformat(timespec="seconds")
    except Exception:
        return _now()


# ---------------------------------------------------------------------------
# Optional Gemini enrichment (never required).
# ---------------------------------------------------------------------------
def _gemini_json(prompt):
    key = (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip()
    if not key:
        return None
    url = ("https://generativelanguage.googleapis.com/v1beta/models/"
           + urllib.parse.quote(GEMINI_MODEL, safe="") + ":generateContent?key=" + urllib.parse.quote(key, safe=""))
    body = json.dumps({
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.4, "responseMimeType": "application/json"},
    }).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        text = payload["candidates"][0]["content"]["parts"][0]["text"]
        text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        return None


def _clean_list(value, fallback):
    if isinstance(value, list):
        out = [str(x).strip() for x in value if str(x).strip()]
        if out:
            return out[:8]
    return fallback


def _template_for(week):
    return WEEKLY_TEMPLATES[(max(1, int(week)) - 1) % len(WEEKLY_TEMPLATES)]


def _build_evaluations(week, module_id, module_title, tpl):
    short = tpl["short"]
    quiz = tpl["quiz"]
    assignment = tpl["assignment"]
    return [
        {
            "id": "evolv3-week-%d-short" % week,
            "kind": "short",
            "moduleId": module_id,
            "moduleTitle": module_title,
            "prompt": short["prompt"],
            "options": [],
            "answer": "",
            "expected": short["expected"],
            "keywords": short.get("keywords", []),
            "tips": short.get("tips", []),
        },
        {
            "id": "evolv3-week-%d-quiz" % week,
            "kind": "quiz",
            "moduleId": module_id,
            "moduleTitle": module_title,
            "prompt": quiz["prompt"],
            "options": quiz["options"],
            "answer": quiz["answer"],
            "expected": quiz["expected"],
            "keywords": quiz.get("keywords", []),
            "tips": ["Choose the single safest clinical option."],
        },
        {
            "id": "evolv3-week-%d-assignment" % week,
            "kind": "assignment",
            "moduleId": module_id,
            "moduleTitle": module_title,
            "prompt": assignment["prompt"],
            "options": [],
            "answer": "",
            "expected": assignment["expected"],
            "keywords": assignment.get("keywords", []),
            "tips": assignment.get("tips", []),
        },
    ]


def weekly_evolve(conn, requested_week=None, existing_ids=None, actor="system", force=False, source="local"):
    """Append one module, three evaluations and one protocol for a new week.

    ``force`` is used by the manual "Check & Evolve Now" button. Without force,
    the caller must already have decided that seven days elapsed. Duplicate ids
    are never inserted, so running twice in a week cannot corrupt the bank.
    """
    ensure_schema(conn)
    state = get_state(conn)
    existing_ids = set(str(x) for x in (existing_ids or []))
    try:
        requested = int(requested_week or 0)
    except Exception:
        requested = 0
    week = requested if requested > 0 else int(state["weekNumber"]) + 1
    if not force and week <= int(state["weekNumber"]):
        week = int(state["weekNumber"]) + 1
    week = max(int(state["weekNumber"]) + 1, week)

    tpl = dict(_template_for(week))
    prompt = (
        "You are a South African eldercare clinical educator. Produce ONE new advanced module "
        "for week %d of an internal caregiver diploma. Return JSON with keys: title, category, hours, "
        "description, highlights (4 strings), hazards (3 strings). Topic must differ from: IDDSI, "
        "sundowning, silent aspiration, post-fall monitoring, catheter hygiene, polypharmacy, pressure "
        "injuries, delirium. Be practical and safe." % week
    )
    enriched = _gemini_json(prompt) or {}
    if enriched.get("title"):
        tpl["title"] = str(enriched.get("title"))[:120]
        tpl["category"] = str(enriched.get("category") or tpl["category"])[:60]
        try:
            tpl["hours"] = max(4, min(40, float(enriched.get("hours") or tpl["hours"])))
        except Exception:
            pass
        tpl["description"] = str(enriched.get("description") or tpl["description"])[:600]
        tpl["highlights"] = _clean_list(enriched.get("highlights"), tpl["highlights"])[:4]
        tpl["hazards"] = _clean_list(enriched.get("hazards"), tpl["hazards"])[:4]
        source = "gemini"

    module_id = "evolv3-week-%d-module" % week
    inserted_module = False
    if module_id not in existing_ids:
        cur = conn.execute(
            "INSERT OR IGNORE INTO evolv3_week_modules(id,week_added,title,category,hours,"
            "description,highlights,hazards,video,source,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (module_id, week, tpl["title"], tpl["category"], tpl["hours"], tpl["description"],
             json.dumps(tpl["highlights"]), json.dumps(tpl["hazards"]),
             json.dumps(tpl["video"]), source, _now()),
        )
        inserted_module = cur.rowcount > 0

    # Section 11: every new weekly module gets its own clinical visual, so no
    # course ever renders a bare placeholder. Offline this is the deterministic
    # topic SVG; with a key it is a Gemini illustration.
    module_image = {"imageUrl": "", "topic": "", "engine": "none"}
    if inserted_module:
        try:
            module_image = generate_module_image(
                tpl["title"], tpl["category"], tpl["description"], tpl["hazards"])
            save_module_image(conn, module_id, module_image.get("imageUrl"))
        except Exception:
            module_image = {"imageUrl": "", "topic": "", "engine": "none"}

    evaluations = _build_evaluations(week, module_id, tpl["title"], tpl)
    inserted_evals = 0
    for item in evaluations:
        if item["id"] in existing_ids:
            continue
        cur = conn.execute(
            "INSERT OR IGNORE INTO evolv3_week_evaluations(id,week_added,kind,module_id,"
            "module_title,prompt,options,answer,expected,keywords,tips,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (item["id"], week, item["kind"], item["moduleId"], item["moduleTitle"], item["prompt"],
             json.dumps(item["options"]), item["answer"], item["expected"],
             json.dumps(item["keywords"]), json.dumps(item["tips"]), _now()),
        )
        inserted_evals += max(0, cur.rowcount)

    protocol_tpl = WEEKLY_PROTOCOLS[(week - 1) % len(WEEKLY_PROTOCOLS)]
    protocol_id = "evolv3-week-%d-protocol" % week
    inserted_protocol = False
    if protocol_id not in existing_ids:
        cur = conn.execute(
            "INSERT OR IGNORE INTO evolv3_week_protocols(id,week_added,title,category,urgency,"
            "summary,steps,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (protocol_id, week, protocol_tpl["title"], protocol_tpl["category"],
             protocol_tpl["urgency"], protocol_tpl["summary"],
             json.dumps(protocol_tpl["steps"]), _now()),
        )
        inserted_protocol = cur.rowcount > 0

    changelog = list(state.get("changelog") or [])
    summary = "Week %d added %s, three evaluation items and one clinical protocol." % (week, tpl["title"])
    if inserted_module or inserted_evals or inserted_protocol:
        changelog.insert(0, {
            "week": week,
            "date": _now(),
            "summary": summary,
            "addedModuleTitle": tpl["title"],
        })
        changelog = changelog[:52]
        conn.execute(
            "UPDATE evolv3_evolution_state SET version=?, week_number=?, last_evolved_at=?, "
            "changelog=?, updated_at=? WHERE id=1",
            ("2.%d.0" % week, week, _now(), json.dumps(changelog), _now()),
        )
        try:
            notifications.push(
                conn, actor or "system",
                "Week %d Module Live" % week,
                tpl["title"] + " is now available. Three new evaluations and a clinical protocol were added.",
                "success",
            )
            notifications.push(
                conn, "all",
                "Week %d Module Live" % week,
                tpl["title"] + " is live in EVOLV3 Academy.",
                "info",
            )
        except Exception:
            pass
    conn.commit()

    return {
        "evolved": bool(inserted_module or inserted_evals or inserted_protocol),
        "alreadyEvolved": not (inserted_module or inserted_evals or inserted_protocol),
        "weekNumber": week,
        "version": "2.%d.0" % week,
        "lastEvolvedAt": _now(),
        "source": source,
        "summary": summary,
        "newModule": {
            "id": module_id,
            "title": tpl["title"],
            "category": tpl["category"],
            "hours": tpl["hours"],
            "description": tpl["description"],
            "highlights": tpl["highlights"],
            "hazards": tpl["hazards"],
            "video": tpl["video"],
            "weekAdded": week,
            "imageUrl": module_image.get("imageUrl") or "",
            "imageEngine": module_image.get("engine") or "none",
            "isNewAutonomous": True,
        },
        "newEvaluations": evaluations,
        "newProtocol": {
            "id": protocol_id,
            "title": protocol_tpl["title"],
            "category": protocol_tpl["category"],
            "urgency": protocol_tpl["urgency"],
            "summary": protocol_tpl["summary"],
            "steps": protocol_tpl["steps"],
            "weekAdded": week,
        },
        "state": get_state(conn),
    }


def list_week_modules(conn):
    ensure_schema(conn)
    rows = conn.execute("SELECT * FROM evolv3_week_modules ORDER BY week_added, id").fetchall()
    items = []
    for r in rows:
        items.append({
            "id": r["id"],
            "weekAdded": int(r["week_added"]),
            "title": r["title"],
            "category": r["category"],
            "hours": float(r["hours"] or 0),
            "description": r["description"] or "",
            "highlights": _json(r["highlights"], []),
            "hazards": _json(r["hazards"], []),
            "video": _json(r["video"], []),
            "source": r["source"] or "local",
            "imageUrl": _module_image_url(r),
            "isNewAutonomous": True,
        })
    return items


def _module_image_url(row):
    """Stored artwork, or the deterministic topic SVG when none was generated."""
    try:
        stored = row["image_url"] if "image_url" in row.keys() else ""
    except Exception:
        stored = ""
    if stored:
        return stored
    try:
        return _svg_data_uri(module_artwork_svg(
            row["title"], row["category"], row["description"] or "",
            _json(row["hazards"], [])))
    except Exception:
        return ""


def list_week_evaluations(conn):
    ensure_schema(conn)
    rows = conn.execute("SELECT * FROM evolv3_week_evaluations ORDER BY week_added, id").fetchall()
    items = []
    for r in rows:
        items.append({
            "id": r["id"],
            "weekAdded": int(r["week_added"]),
            "kind": r["kind"],
            "moduleId": r["module_id"] or "",
            "moduleTitle": r["module_title"] or "",
            "prompt": r["prompt"],
            "options": _json(r["options"], []),
            "answer": r["answer"] or "",
            "expected": r["expected"] or "",
            "keywords": _json(r["keywords"], []),
            "tips": _json(r["tips"], []),
        })
    return items


def list_week_protocols(conn):
    ensure_schema(conn)
    rows = conn.execute("SELECT * FROM evolv3_week_protocols ORDER BY week_added DESC, id").fetchall()
    items = []
    for r in rows:
        items.append({
            "id": r["id"],
            "weekAdded": int(r["week_added"]),
            "title": r["title"],
            "category": r["category"] or "Clinical",
            "urgency": r["urgency"] or "Routine",
            "summary": r["summary"] or "",
            "steps": _json(r["steps"], []),
        })
    return items


# ---------------------------------------------------------------------------
# Learner state (points, minutes, enrolments, attempts, badges)
# ---------------------------------------------------------------------------
def get_learner(conn, user):
    ensure_schema(conn)
    key = str(user or "system")
    row = conn.execute("SELECT state,updated_at FROM evolv3_learner_state WHERE user=?", (key,)).fetchone()
    if not row:
        return None
    state = _json(row["state"], None)
    if not isinstance(state, dict):
        return None
    state["updatedAt"] = row["updated_at"]
    return state


def save_learner(conn, user, state):
    ensure_schema(conn)
    key = str(user or "system")
    if not isinstance(state, dict):
        raise ValueError("Learner state must be an object.")
    encoded = json.dumps(state, separators=(",", ":"))
    if len(encoded) > 400_000:
        raise ValueError("Learner state is too large.")
    conn.execute(
        "INSERT INTO evolv3_learner_state(user,state,updated_at) VALUES(?,?,?) "
        "ON CONFLICT(user) DO UPDATE SET state=excluded.state,updated_at=excluded.updated_at",
        (key, encoded, _now()),
    )
    conn.commit()
    return get_learner(conn, key)


def leaderboard_rows(conn):
    ensure_schema(conn)
    rows = conn.execute("SELECT user,state,updated_at FROM evolv3_learner_state").fetchall()
    items = []
    for r in rows:
        state = _json(r["state"], {})
        if not isinstance(state, dict):
            continue
        completions = state.get("completions") or {}
        attempts = state.get("attempts") or []
        scores = [float(a.get("score") or 0) for a in attempts if isinstance(a, dict)]
        items.append({
            "user": r["user"],
            "name": state.get("displayName") or r["user"],
            "role": state.get("role") or "Caregiver",
            "points": int(state.get("points") or 0),
            "minutes": int(state.get("minutesStudied") or 0),
            "completed": len(completions) if isinstance(completions, dict) else 0,
            "attempts": len(attempts),
            "avgScore": round(sum(scores) / len(scores)) if scores else 0,
            "badges": len(state.get("badges") or []),
            "streak": int(state.get("streak") or 1),
            "updatedAt": r["updated_at"],
        })
    items.sort(key=lambda x: (-x["points"], -x["minutes"], x["name"].lower()))
    return items


# ---------------------------------------------------------------------------
# Local clinical grading (instant fallback used by every evaluation)
# ---------------------------------------------------------------------------
def _tokens(text):
    return [t for t in re.findall(r"[a-z0-9]+", str(text or "").lower()) if t not in STOPWORDS and len(t) > 1]


def grade_answer(answer, expected="", keywords=None, kind="short"):
    answer = str(answer or "").strip()
    if not answer:
        return {
            "score": 0, "passed": False, "xp": 0,
            "feedback": "No answer was submitted. Give a short, specific clinical response and try again.",
            "improvements": ["Describe what you would do first.", "Name the safety risk and the escalation point."],
            "missing": list(keywords or [])[:6],
        }
    kw = [str(k).lower() for k in (keywords or []) if str(k).strip()]
    norm = " " + re.sub(r"\s+", " ", answer.lower()) + " "
    missing = []
    hit_weight = 0.0
    for k in kw:
        k_norm = k.lower().strip()
        if k_norm and (k_norm in norm):
            hit_weight += 1.0
        else:
            missing.append(k)
    coverage = (hit_weight / len(kw)) if kw else 0.0
    exp_tokens = set(_tokens(expected))
    ans_tokens = set(_tokens(answer))
    overlap = (len(exp_tokens & ans_tokens) / len(exp_tokens)) if exp_tokens else 0.0
    length = len(_tokens(answer))
    length_factor = 1.0 if length >= 18 else max(0.35, length / 18.0)
    raw = 0.58 * coverage + 0.34 * overlap + 0.08 * length_factor
    if kw and coverage >= 0.85:
        raw += 0.05
    score = int(round(max(0.0, min(1.0, raw)) * 100))
    if kind == "quiz":
        # Multiple-choice answers are exact; accept a close natural-language form.
        target = str(expected or "").lower()
        if norm.strip() in target or (target and target in norm):
            score = 100
        elif coverage >= 0.75:
            score = max(score, 72)
        else:
            score = min(score, 45)
    passed = score >= 60
    if score >= 90:
        feedback = "Excellent true match. Your response names the priority actions, the hazard and the escalation point."
    elif score >= 75:
        feedback = "Strong clinical match. Tighten the sequence and make the escalation explicit."
    elif score >= 60:
        feedback = "Passing match. The core idea is present, but a supervisor would want more specific actions."
    elif score >= 40:
        feedback = "Partial match. Important safety steps or the correct clinical term are missing."
    else:
        feedback = "Low match. This answer would not keep a resident safe; review the module and retake."
    improvements = []
    if missing:
        improvements.append("Include these clinical cues: " + ", ".join(missing[:4]) + ".")
    if length < 18:
        improvements.append("Expand to at least two sentences with a clear action sequence.")
    if passed:
        improvements.append("Add one line on documentation and handover to reach distinction.")
    else:
        improvements.append("State the first action, the risk you are preventing, and who you would escalate to.")
    xp = (40 if score >= 80 else 30 if passed else 10 if score >= 40 else 4) + (10 if kind == "assignment" and passed else 0)
    return {
        "score": score,
        "passed": passed,
        "xp": xp,
        "feedback": feedback,
        "improvements": improvements[:4],
        "missing": missing[:6],
        "engine": "local-clinical",
    }


# ---------------------------------------------------------------------------
# Module artwork (Section 11). Deterministic, topic-matched 800x450 clinical
# SVG diagrams plus an optional Gemini-generated illustration. Everything here
# is additive: a new nullable column, a new route, and a generator the weekly
# evolution job calls after it inserts a module.
# ---------------------------------------------------------------------------
ARTWORK_WIDTH = 800
ARTWORK_HEIGHT = 450
ARTWORK_TOPICS = (
    "ecg", "dementia", "choking", "bathing", "transfer",
    "sundowning", "medication", "stroke", "generic",
)

# Keyword table used by both the SVG fallback and the AI prompt. First match
# wins, so the more specific topics are listed before the broad ones.
_ARTWORK_KEYWORDS = (
    ("choking", ("chok", "dysphag", "airway", "iddsi", "aspirat", "swallow", "heimlich")),
    ("bathing", ("bath", "shower", "hygiene", "38", "water temperature", "scald", "skin care", "pressure injur", "continence")),
    ("sundowning", ("sundown", "circadian", "light therapy", "dusk", "sleep hygiene")),
    ("transfer", ("transfer", "mobility", "gait", "hoist", "pivot", "manual handling", "moving a patient", "fall")),
    ("medication", ("medicat", "polypharm", "5 rights", "five rights", "prescription", "drug", "dose", "pill")),
    ("stroke", ("stroke", "fast", "cva", "cerebrovascular", "face droop", "hemipleg")),
    ("dementia", ("dementia", "alzheimer", "memory", "confusion", "cognitive", "delirium", "behaviour", "wandering")),
    ("ecg", ("vital", "ecg", "ekg", "blood pressure", "observation", "news2", "pulse", "respiration", "temperature chart", "spo2")),
)


def artwork_topic(title="", category="", description="", hazards=None):
    """Return one of ``ARTWORK_TOPICS`` for a module, chosen deterministically."""
    hay = " ".join([
        str(title or ""), str(category or ""), str(description or ""),
        " ".join(str(h) for h in (hazards or [])),
    ]).lower()
    for topic, words in _ARTWORK_KEYWORDS:
        for word in words:
            if word in hay:
                return topic
    if "dementia" in hay or "elder" in hay:
        return "dementia"
    return "generic"


def _art_header(topic, label, accent, ink="#0B1220"):
    return (
        '<rect width="800" height="450" fill="#F8FAFC"/>'
        '<rect x="0" y="0" width="800" height="64" fill="' + accent + '"/>'
        '<text x="28" y="41" font-family="Inter,Segoe UI,sans-serif" font-size="21" '
        'font-weight="700" fill="#FFFFFF">' + label + '</text>'
        '<text x="772" y="41" text-anchor="end" font-family="IBM Plex Mono,monospace" '
        'font-size="13" fill="#FFFFFF" opacity="0.75">EVOLV3 CLINICAL</text>'
        '<rect x="0" y="64" width="800" height="386" fill="none" stroke="#E2E8F0" stroke-width="2"/>'
        '<text x="28" y="434" font-family="IBM Plex Mono,monospace" font-size="11" '
        'fill="' + ink + '" opacity="0.45">Training illustration · not a diagnostic instrument</text>'
    )


def _art_card(x, y, w, h, title, lines, accent, fill="#FFFFFF"):
    out = (
        '<rect x="%d" y="%d" width="%d" height="%d" rx="12" fill="%s" stroke="%s" stroke-width="2"/>'
        % (x, y, w, h, fill, accent)
    )
    out += ('<text x="%d" y="%d" font-family="Inter,Segoe UI,sans-serif" font-size="15" '
            'font-weight="700" fill="%s">%s</text>' % (x + 14, y + 26, accent, title))
    for i, line in enumerate(lines):
        out += ('<text x="%d" y="%d" font-family="Inter,Segoe UI,sans-serif" font-size="13" '
                'fill="#334155">%s</text>' % (x + 14, y + 50 + i * 20, line))
    return out


def _art_ecg(a):
    pts = []
    for i in range(0, 620, 4):
        base = 250 - 10
        y = base
        if 150 <= i <= 190:
            y = base - (i - 150) * 1.1
        elif 190 < i <= 205:
            y = base - 44 + (i - 190) * 5.2
        elif 205 < i <= 225:
            y = base + 34 - (i - 205) * 1.7
        elif 225 < i <= 250:
            y = base
        pts.append("%d %.1f" % (120 + i, y))
    return (
        '<rect x="100" y="96" width="600" height="220" rx="14" fill="#07131F" stroke="' + a + '" stroke-width="2"/>'
        '<g stroke="#134E4A" stroke-width="1" opacity="0.55">'
        + "".join('<path d="M%d 96v220"/>' % x for x in range(140, 700, 40))
        + "".join('<path d="M100 %dy600"/>' % y for y in range(126, 316, 30))
        + '</g>'
        '<polyline fill="none" stroke="#34D399" stroke-width="3" stroke-linejoin="round" '
        'points="' + " ".join(pts) + '"/>'
        + _art_card(100, 336, 190, 84, "BLOOD PRESSURE", ["Systolic / diastolic", "Record and escalate"], a)
        + _art_card(305, 336, 190, 84, "SpO2 · PULSE", ["Oxygen saturation %", "Rate per minute"], a)
        + _art_card(510, 336, 190, 84, "RESPIRATION · TEMP", ["Count for 60 seconds", "Report changes early"], a)
    )


def _art_dementia(a):
    nodes = []
    for i in range(14):
        ang = i * (360 / 14) * 3.14159265 / 180
        import math
        x = 210 + math.cos(ang) * (70 if i % 2 == 0 else 108)
        y = 230 + math.sin(ang) * (70 if i % 2 == 0 else 108)
        nodes.append('<circle cx="%.0f" cy="%.0f" r="%d" fill="%s" opacity="%s"/>'
                     % (x, y, 9 if i % 3 else 13, a, "0.85" if i % 2 == 0 else "0.5"))
        nodes.append('<path d="M210 230L%.0f %.0f" stroke="%s" stroke-width="2" opacity="0.35"/>' % (x, y, a))
    stages = [("F", "FACE", "Ask for a smile"), ("A", "ARMS", "Lift both arms"),
              ("S", "SPEECH", "Repeat a sentence"), ("T", "TIME", "Call emergency now")]
    cards = "".join(
        _art_card(400, 108 + i * 74, 372, 64, s[0] + " · " + s[1], [s[2]], a)
        for i, s in enumerate(stages)
    )
    return (
        '<g>' + "".join(nodes) + '</g>'
        '<circle cx="210" cy="230" r="52" fill="#FFFFFF" stroke="' + a + '" stroke-width="3"/>'
        '<text x="210" y="226" text-anchor="middle" font-family="Inter,sans-serif" font-size="16" '
        'font-weight="700" fill="' + a + '">BRAIN</text>'
        '<text x="210" y="248" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" '
        'fill="#334155">neural change</text>'
        '<text x="400" y="98" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#334155">'
        'FAST SCREENING · ESCALATE ANY POSITIVE</text>'
        + cards
    )


def _art_choking(a):
    steps = [("1", "Recognise", "Cannot speak, cough or breathe"),
             ("2", "Position", "90-degree upright, chin level"),
             ("3", "5 back blows", "Between shoulder blades"),
             ("4", "5 abdominal thrusts", "Above navel, inward and up"),
             ("5", "Call emergency", "Unresponsive: start CPR")]
    out = ('<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" '
           'fill="#334155">90° CHOKING RESCUE SEQUENCE</text>')
    for i, (n, head, sub) in enumerate(steps):
        x = 100 + i * 122
        out += ('<rect x="%d" y="118" width="108" height="150" rx="12" fill="#FFFFFF" stroke="%s" stroke-width="2"/>'
                % (x, a))
        out += ('<circle cx="%d" cy="150" r="18" fill="%s"/>' % (x + 54, a))
        out += ('<text x="%d" y="156" text-anchor="middle" font-family="Inter,sans-serif" font-size="15" '
                'font-weight="700" fill="#FFFFFF">%s</text>' % (x + 54, n))
        out += ('<text x="%d" y="192" text-anchor="middle" font-family="Inter,sans-serif" font-size="12.5" '
                'font-weight="700" fill="#334155">%s</text>' % (x + 54, head))
        for j in range(0, len(sub), 15):
            out += ('<text x="%d" y="%d" text-anchor="middle" font-family="Inter,sans-serif" font-size="10.5" '
                    'fill="#64748B">%s</text>' % (x + 54, 210 + (j // 15) * 15, sub[j:j + 15]))
        if i < 4:
            out += ('<path d="M%d 193h14" stroke="%s" stroke-width="2"/>' % (x + 108, a))
    out += ('<rect x="100" y="292" width="600" height="112" rx="12" fill="#FEF3C7" stroke="#F59E0B" stroke-width="2"/>'
            '<text x="118" y="322" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#92400E">'
            'IDDSI + DYSPHAGIA PREVENTION</text>'
            '<text x="118" y="348" font-family="Inter,sans-serif" font-size="12" fill="#78350F">'
            'Sit upright 90°, never feed lying down · small spoonfuls · chin tuck only when prescribed</text>'
            '<text x="118" y="370" font-family="Inter,sans-serif" font-size="12" fill="#78350F">'
            'No mixed textures · stop if coughing or wet voice · oral care before and after meals</text>'
            '<text x="118" y="392" font-family="Inter,sans-serif" font-size="12" fill="#78350F">'
            'Document intake, cough episodes and any speech-language pathology referral</text>')
    return out


def _art_bathing(a):
    return (
        '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" '
        'fill="#334155">SAFE BATHING · WATER AT 38°C</text>'
        '<rect x="100" y="118" width="240" height="180" rx="16" fill="#E0F2FE" stroke="' + a + '" stroke-width="2"/>'
        '<path d="M124 258h192" stroke="' + a + '" stroke-width="6" stroke-linecap="round"/>'
        '<path d="M124 232c32-16 64 16 96 0s64 16 96 0" fill="none" stroke="#0284C7" stroke-width="3"/>'
        '<circle cx="220" cy="176" r="46" fill="#FFFFFF" stroke="' + a + '" stroke-width="3"/>'
        '<text x="220" y="170" text-anchor="middle" font-family="Inter,sans-serif" font-size="20" '
        'font-weight="700" fill="' + a + '">38°C</text>'
        '<text x="220" y="190" text-anchor="middle" font-family="Inter,sans-serif" font-size="10.5" '
        'fill="#334155">elbow test</text>'
        '<rect x="112" y="118" width="8" height="140" fill="#EF4444"/>'
        '<text x="126" y="222" font-family="Inter,sans-serif" font-size="11" fill="#B91C1C">max 40°C</text>'
        + _art_card(364, 118, 204, 84, "BEFORE", ["Consent + privacy", "Grab rails, non-slip mat"], a)
        + _art_card(584, 118, 190, 84, "DURING", ["Never leave alone", "Check skin each minute"], a)
        + _art_card(364, 214, 204, 84, "AFTER", ["Dry skin folds", "Check for red areas"], a)
        + _art_card(584, 214, 190, 84, "RECORD", ["Refusals + skin", "Any scald reported"], a)
        + ('<rect x="100" y="316" width="674" height="88" rx="12" fill="#F0FDFA" stroke="' + a + '" stroke-width="2"/>'
           '<text x="118" y="344" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#0F766E">'
           'SCALD AND SKIN-TEAR PREVENTION</text>'
           '<text x="118" y="368" font-family="Inter,sans-serif" font-size="12" fill="#134E4A">'
           'Run cold water first, then hot · test with your elbow · keep the room warm and draught-free</text>'
           '<text x="118" y="390" font-family="Inter,sans-serif" font-size="12" fill="#134E4A">'
           'Report any redness, blister or skin tear immediately and document it</text>')
    )


def _art_transfer(a):
    return (
        '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" '
        'fill="#334155">GAIT-BELT PIVOT TRANSFER</text>'
        '<rect x="100" y="120" width="300" height="210" rx="14" fill="#FFFFFF" stroke="' + a + '" stroke-width="2"/>'
        '<rect x="132" y="196" width="130" height="18" rx="9" fill="#94A3B8"/>'
        '<rect x="150" y="214" width="10" height="70" fill="#94A3B8"/>'
        '<rect x="238" y="214" width="10" height="70" fill="#94A3B8"/>'
        '<circle cx="196" cy="166" r="24" fill="#CBD5E1"/>'
        '<path d="M196 190v10" stroke="#64748B" stroke-width="6" stroke-linecap="round"/>'
        '<rect x="160" y="196" width="74" height="10" rx="5" fill="' + a + '"/>'
        '<text x="196" y="150" text-anchor="middle" font-family="Inter,sans-serif" font-size="10.5" '
        'fill="#334155">resident</text>'
        '<path d="M400 224h64" stroke="' + a + '" stroke-width="3" stroke-dasharray="7 6"/>'
        '<path d="M456 214l14 10-14 10z" fill="' + a + '"/>'
        '<text x="432" y="206" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" '
        'fill="#334155">pivot, do not lift</text>'
        + _art_card(484, 120, 290, 210, "SAFE SEQUENCE", [
            "1  Explain, gain consent, check brakes",
            "2  Bed at correct height, wheels locked",
            "3  Gait belt low and snug over clothing",
            "4  Feet flat, lean forward, nose over toes",
            "5  Pivot on command, keep back straight",
            "6  Lower slowly onto the seat, then release",
            "7  Never twist or lift the resident",
        ], a)
        + ('<rect x="100" y="344" width="674" height="60" rx="12" fill="#FEF2F2" stroke="#EF4444" stroke-width="2"/>'
           '<text x="118" y="370" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#991B1B">'
           'STOP IF: dizziness, new pain, unsteady feet, or the belt slips</text>'
           '<text x="118" y="392" font-family="Inter,sans-serif" font-size="12" fill="#7F1D1D">'
           'Two caregivers for heavy or unpredictable residents · report every fall, even without injury</text>')
    )


def _art_sundowning(a):
    return (
        '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" '
        'fill="#334155">SUNDOWNING · 24-HOUR LIGHT PROTOCOL</text>'
        '<rect x="100" y="120" width="600" height="120" rx="14" fill="#0F172A"/>'
        '<rect x="100" y="120" width="300" height="120" fill="#FDE68A" opacity="0.85" rx="14"/>'
        '<rect x="400" y="120" width="300" height="120" fill="#1E293B" rx="14"/>'
        '<circle cx="220" cy="180" r="34" fill="#F59E0B"/>'
        '<text x="220" y="186" text-anchor="middle" font-family="Inter,sans-serif" font-size="12" '
        'font-weight="700" fill="#78350F">MORNING</text>'
        '<text x="220" y="216" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" '
        'fill="#78350F">30-60 min bright light</text>'
        '<circle cx="550" cy="180" r="30" fill="#0EA5E9" opacity="0.5"/>'
        '<text x="550" y="186" text-anchor="middle" font-family="Inter,sans-serif" font-size="12" '
        'font-weight="700" fill="#E0F2FE">EVENING</text>'
        '<text x="550" y="216" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" '
        'fill="#E0F2FE">dim, warm, quiet</text>'
        '<text x="400" y="164" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" '
        'fill="#94A3B8">17:00</text>'
        + _art_card(100, 256, 320, 148, "DE-ESCALATION AT DUSK", [
            "Lower noise, clutter and visitors",
            "Turn on warm lamps before sunset",
            "Offer a familiar snack and routine",
            "Screen for pain, constipation, infection",
            "Use calm orientation, never argue",
        ], a)
        + _art_card(440, 256, 334, 148, "AVOID", [
            "Sedation as a first response",
            "Bright overhead light after 18:00",
            "Missed pain, urine retention or sepsis",
            "Unfamiliar carers at sundown",
            "Melatonin without prescriber review",
        ], "#EF4444", "#FEF2F2")
    )


def _art_medication(a):
    days = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
    out = ('<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" '
           'fill="#334155">5 RIGHTS · MEDICATION ORGANISER</text>')
    for i, d in enumerate(days):
        x = 100 + i * 96
        out += ('<rect x="%d" y="118" width="84" height="150" rx="10" fill="#FFFFFF" stroke="%s" stroke-width="2"/>'
                % (x, a))
        out += ('<text x="%d" y="140" text-anchor="middle" font-family="IBM Plex Mono,monospace" font-size="11" '
                'font-weight="700" fill="%s">%s</text>' % (x + 42, a, d))
        for j in range(3):
            out += ('<circle cx="%d" cy="%d" r="13" fill="%s" opacity="0.18"/>'
                    % (x + 42, 170 + j * 34, a))
            out += ('<text x="%d" y="%d" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" '
                    'fill="#334155">%s</text>' % (x + 42, 174 + j * 34, ("AM", "NOON", "PM")[j]))
    rights = [("RIGHT", "PERSON"), ("RIGHT", "DRUG"), ("RIGHT", "DOSE"),
              ("RIGHT", "ROUTE"), ("RIGHT", "TIME")]
    for i, (k, v) in enumerate(rights):
        x = 100 + i * 138
        out += ('<rect x="%d" y="288" width="126" height="66" rx="10" fill="#F0FDFA" stroke="%s" stroke-width="2"/>'
                % (x, a))
        out += ('<text x="%d" y="312" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" '
                'fill="#0F766E">%s</text>' % (x + 63, k))
        out += ('<text x="%d" y="336" text-anchor="middle" font-family="Inter,sans-serif" font-size="15" '
                'font-weight="700" fill="%s">%s</text>' % (x + 63, a, v))
    out += ('<text x="100" y="382" font-family="Inter,sans-serif" font-size="12" fill="#334155">'
            'Document every dose given, refused or omitted · report adverse reactions and interactions immediately</text>')
    return out


def _art_stroke(a):
    return (
        '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" '
        'fill="#334155">STROKE · FAST TRIAGE AND 3.5-HOUR WINDOW</text>'
        '<circle cx="220" cy="240" r="96" fill="#FEF2F2" stroke="#EF4444" stroke-width="3"/>'
        '<text x="220" y="226" text-anchor="middle" font-family="Inter,sans-serif" font-size="44" '
        'font-weight="800" fill="#DC2626">FAST</text>'
        '<text x="220" y="252" text-anchor="middle" font-family="Inter,sans-serif" font-size="12" '
        'fill="#991B1B">FACE · ARMS · SPEECH · TIME</text>'
        '<text x="220" y="276" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" '
        'fill="#7F1D1D">last known well = the clock</text>'
        + _art_card(348, 118, 426, 68, "F · FACE", ["Ask the resident to smile · look for drooping on one side"], a)
        + _art_card(348, 194, 426, 68, "A · ARMS", ["Lift both arms and hold 10 seconds · one drifts downward"], a)
        + _art_card(348, 270, 426, 68, "S · SPEECH", ["Repeat a simple sentence · slurred, wrong or absent words"], a)
        + ('<rect x="100" y="348" width="674" height="60" rx="12" fill="#DC2626"/>'
           '<text x="118" y="374" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#FFFFFF">'
           'T · TIME · CALL EMERGENCY IMMEDIATELY · NOTE THE LAST KNOWN WELL TIME</text>'
           '<text x="118" y="396" font-family="Inter,sans-serif" font-size="12" fill="#FEE2E2">'
           'Nothing by mouth · do not give aspirin · lie on the affected side if vomiting · stay with the resident</text>')
    )


def _art_generic(a, title="", category=""):
    import math
    petals = []
    for i in range(8):
        ang = i * 45 * math.pi / 180
        x = 230 + math.cos(ang) * 78
        y = 228 + math.sin(ang) * 78
        petals.append('<circle cx="%.0f" cy="%.0f" r="34" fill="%s" opacity="0.22"/>' % (x, y, a))
    return (
        '<g>' + "".join(petals) + '</g>'
        '<circle cx="230" cy="228" r="56" fill="#FFFFFF" stroke="' + a + '" stroke-width="3"/>'
        '<path d="M230 200v56M202 228h56" stroke="' + a + '" stroke-width="8" stroke-linecap="round"/>'
        '<text x="230" y="330" text-anchor="middle" font-family="Inter,sans-serif" font-size="13" '
        'font-weight="700" fill="#334155">' + (category or "CLINICAL CARE")[:34].upper() + '</text>'
        + _art_card(360, 108, 414, 108, "MODULE FOCUS", [
            (title or "Caregiver module")[:52],
            "Person-centred, safe, documented care",
            "Escalate any deterioration immediately",
        ], a)
        + _art_card(360, 230, 414, 108, "WHAT GOOD CARE LOOKS LIKE", [
            "Observe, record and report changes",
            "Work within your scope of practice",
            "Protect dignity, privacy and consent",
        ], a)
        + ('<rect x="100" y="360" width="674" height="48" rx="12" fill="#F0FDFA" stroke="' + a + '" stroke-width="2"/>'
           '<text x="118" y="390" font-family="Inter,sans-serif" font-size="12" fill="#0F766E">'
           'Follow the facility protocol, escalate early and document every action you take.</text>')
    )


_ART_LABELS = {
    "ecg": ("VITAL SIGNS MONITORING", "#0F766E"),
    "dementia": ("DEMENTIA CARE · FAST STAGES", "#7C3AED"),
    "choking": ("CHOKING & DYSPHAGIA RESCUE", "#B91C1C"),
    "bathing": ("DIGNIFIED BATHING & HYGIENE", "#0284C7"),
    "transfer": ("SAFE PATIENT TRANSFER", "#0D9488"),
    "sundowning": ("SUNDOWNING LIGHT PROTOCOL", "#C2410C"),
    "medication": ("MEDICATION SAFETY · 5 RIGHTS", "#1D4ED8"),
    "stroke": ("STROKE FAST TRIAGE", "#DC2626"),
    "generic": ("CLINICAL CARE MODULE", "#0F766E"),
}


def module_artwork_svg(title="", category="", description="", hazards=None, topic=None):
    """Return a complete ``<svg viewBox="0 0 800 450">`` clinical diagram.

    Deterministic: the same module always produces the same artwork, and it
    never depends on a network call. This is the fallback used whenever the AI
    generator is unavailable or returns something that fails validation.
    """
    topic = topic if topic in ARTWORK_TOPICS else artwork_topic(title, category, description, hazards)
    label, accent = _ART_LABELS.get(topic, _ART_LABELS["generic"])
    body = {
        "ecg": _art_ecg, "dementia": _art_dementia, "choking": _art_choking,
        "bathing": _art_bathing, "transfer": _art_transfer,
        "sundowning": _art_sundowning, "medication": _art_medication,
        "stroke": _art_stroke,
    }.get(topic)
    inner = body(accent) if body else _art_generic(accent, title, category)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" '
            'role="img" aria-label="%s">%s%s</svg>'
            % (ARTWORK_WIDTH, ARTWORK_HEIGHT, ARTWORK_WIDTH, ARTWORK_HEIGHT,
               _xml_escape(label), _art_header(topic, label, accent), inner))


def _xml_escape(value):
    return (str(value or "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _sanitize_svg(svg):
    """Accept only a clean illustration: no scripts, handlers, links or foreign objects."""
    if not isinstance(svg, str):
        return None
    text = svg.strip()
    text = re.sub(r"^```(?:svg|xml)?|```$", "", text, flags=re.MULTILINE).strip()
    start = text.lower().find("<svg")
    end = text.lower().rfind("</svg>")
    if start < 0 or end < 0:
        return None
    text = text[start:end + 6]
    lowered = text.lower()
    for banned in ("<script", "javascript:", "<foreignobject", "<iframe", "onload=",
                   "onclick=", "onerror=", "<image", "xlink:href", "href="):
        if banned in lowered:
            return None
    if "viewbox" not in lowered:
        return None
    if len(text) > 60000:
        return None
    return text


def _svg_data_uri(svg):
    import base64
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode("utf-8")).decode("ascii")


def generate_module_image(title="", category="", description="", hazards=None, use_ai=True):
    """Return ``{imageUrl, topic, engine}`` for one module.

    Order of preference: Gemini (sanitised) → deterministic topic SVG. The
    return value is always usable, so callers never need a network.
    """
    topic = artwork_topic(title, category, description, hazards)
    fallback_svg = module_artwork_svg(title, category, description, hazards, topic)
    fallback_uri = _svg_data_uri(fallback_svg)
    if not use_ai:
        return {"imageUrl": fallback_uri, "topic": topic, "engine": "local-svg"}
    prompt = (
        "You are a clinical illustrator for a South African caregiver academy. "
        "Draw ONE flat, clean clinical diagram as raw SVG for this training module.\n"
        "Title: %s\nCategory: %s\nSummary: %s\nHazards: %s\nTopic key: %s\n\n"
        "Rules: start with <svg viewBox=\"0 0 800 450\"> and end with </svg>. "
        "Use only <rect>, <circle>, <path>, <line>, <polyline>, <polygon>, <text>, <g>, "
        "<defs>, <linearGradient> and <stop>. No <image>, no external fonts, no scripts, "
        "no event attributes, no <foreignObject>. Use a light background (#F8FAFC), a "
        "coloured header band, labelled callouts and short clinical labels in English. "
        "Return JSON with a single key \"svg\" holding the SVG markup."
        % (str(title)[:120], str(category)[:60], str(description)[:400],
           ", ".join(str(h) for h in (hazards or []))[:300], topic)
    )
    enriched = _gemini_json(prompt) or {}
    svg = _sanitize_svg(enriched.get("svg"))
    if svg:
        return {"imageUrl": _svg_data_uri(svg), "topic": topic, "engine": "gemini-svg"}
    return {"imageUrl": fallback_uri, "topic": topic, "engine": "local-svg"}


def save_module_image(conn, module_id, image_url):
    """Persist generated artwork on the module row (additive, nullable column)."""
    ensure_schema(conn)
    if not module_id or not image_url:
        return False
    try:
        cur = conn.execute("UPDATE evolv3_week_modules SET image_url=? WHERE id=?", (str(image_url), str(module_id)))
        conn.commit()
        return cur.rowcount > 0
    except Exception:
        return False
