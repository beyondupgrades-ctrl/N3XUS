"""In-house knowledge base / wiki (100% free, no external service)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS kb_articles(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, slug TEXT UNIQUE,
  body TEXT DEFAULT '', category TEXT DEFAULT 'General', author TEXT DEFAULT '',
  version INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS kb_versions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER NOT NULL, version INTEGER NOT NULL,
  body TEXT NOT NULL, edited_by TEXT DEFAULT '', created_at TEXT NOT NULL,
  FOREIGN KEY(article_id) REFERENCES kb_articles(id));
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_articles(conn, category=None):
    sql = "SELECT * FROM kb_articles"
    args = []
    if category:
        sql += " WHERE category=?"; args.append(category)
    sql += " ORDER BY title"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def save_article(conn, title, body="", category="General", author="", slug=None):
    slug = slug or title.lower().replace(" ", "-")[:60]
    now = date.today().isoformat()
    cur = conn.execute("INSERT INTO kb_articles(title,slug,body,category,author,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                       (title, slug, body, category, author, now, now))
    aid = cur.lastrowid
    conn.execute("INSERT INTO kb_versions(article_id,version,body,edited_by,created_at) VALUES(?,?,?,?,?)",
                 (aid, 1, body, author, now))
    conn.commit()
    return aid


def update_article(conn, aid, body, author=""):
    now = date.today().isoformat()
    row = conn.execute("SELECT version FROM kb_articles WHERE id=?", (aid,)).fetchone()
    ver = (row["version"] if row else 0) + 1
    conn.execute("UPDATE kb_articles SET body=?,version=?,updated_at=? WHERE id=?", (body, ver, now, aid))
    conn.execute("INSERT INTO kb_versions(article_id,version,body,edited_by,created_at) VALUES(?,?,?,?,?)",
                 (aid, ver, body, author, now))
    conn.commit()


def search(conn, query):
    q = "%" + query + "%"
    return [dict(r) for r in conn.execute(
        "SELECT * FROM kb_articles WHERE title LIKE ? OR body LIKE ? ORDER BY title", (q, q)).fetchall()]