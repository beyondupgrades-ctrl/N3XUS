"""Role-based access decisions and employee-data masking for Beyond Registration."""
from __future__ import annotations


class PermissionMaskingEngine:
    """Central permission policy for Administrator, Manager and Staff/Caregiver roles."""

    PERMISSION_CATALOG = {
        "employees": ("view", "add", "edit", "delete", "export"),
        "hr": ("view", "add", "edit", "delete", "approve"),
        "payroll": ("view", "calculate", "edit", "approve", "release", "export"),
        "payslips": ("generate", "publish", "view", "download", "resend"),
        "leave": ("view", "submit", "approve", "edit", "cancel"),
        "attendance": ("view", "record", "correct", "approve", "export"),
        "documents": ("view", "upload", "download", "edit", "delete", "share"),
        "performance": ("view", "create", "edit", "approve"),
        "patients": ("view", "create", "edit", "archive"),
        "vitals_wheelchair": ("view", "record", "correct", "review"),
        "emergency": ("activate", "acknowledge", "manage_contacts", "review_events"),
        "reports_audit": ("view", "export", "manage_retention"),
        "integrations": ("view", "configure", "connect", "disconnect", "manage_secrets"),
        "backups": ("create", "inspect", "restore"),
        "cameras": ("view", "register", "edit", "delete"),
        "ai": ("view", "use", "configure", "approve"),
        "quoteflow": ("view", "create", "edit", "approve", "delete", "export"),
        "banking": ("view", "manage", "reveal"),
    }

    ROLE_ALIASES = {
        "admin": "Administrator", "administrator": "Administrator",
        "manager": "Manager", "staff": "Staff", "caregiver": "Caregiver",
    }

    def __init__(self, user_role: str, grants=None, scope_type="all", scope_values=None):
        raw = str(user_role or "Staff").strip().lower()
        self.user_role = self.ROLE_ALIASES.get(raw, "Staff")
        self.has_explicit_policy = grants is not None
        self.grants = grants if isinstance(grants, dict) else {}
        self.scope_type = scope_type if scope_type in ("all", "departments", "employees") else "all"
        self.scope_values = {str(v) for v in (scope_values or ())}

    def allows(self, module: str, action: str) -> bool:
        if self.user_role == "Administrator":
            return True
        if self.has_explicit_policy:
            return action in self.grants.get(module, ())
        if module == "payroll" and action in ("view", "calculate", "export"):
            return self.user_role in ("Manager",)
        if module == "reports_audit" and action in ("view", "export", "manage_retention"):
            return self.user_role == "Administrator"
        # Patient safety and clinical information are private by default. A
        # non-administrator must receive an explicit grant for each action.
        if module in ("patients", "vitals_wheelchair", "emergency"):
            return False
        return True

    def employee_in_scope(self, employee_id: int, department: str = "") -> bool:
        if not self.has_explicit_policy or self.scope_type == "all":
            return True
        if self.scope_type == "employees":
            return str(employee_id) in self.scope_values
        return str(department or "") in self.scope_values

    def can_view_payroll(self) -> bool:
        if self.has_explicit_policy:
            return self.allows("payroll", "view")
        return self.user_role in ("Administrator", "Manager")

    def can_view_audit_ledger(self) -> bool:
        if self.has_explicit_policy:
            return self.allows("reports_audit", "view")
        return self.user_role == "Administrator"

    def can_modify_system_settings(self) -> bool:
        if self.has_explicit_policy:
            return self.allows("integrations", "configure")
        return self.user_role == "Administrator"

    def filter_employee_record(self, employee_data: dict) -> dict:
        """Return a copy with sensitive administrative fields removed for staff."""
        filtered_data = dict(employee_data or {})
        if self.user_role not in ("Administrator", "Manager"):
            for field in (
                "salary_structure", "salary", "gross_pay", "net_pay",
                "id_number", "private_admin_notes", "admin_notes",
            ):
                filtered_data.pop(field, None)
            filtered_data["status_note"] = "Restricted view: Administrative metadata hidden."
        return filtered_data
