"""Optional service extensions for Beyond Registration 5.5.0-VOIC3-MESSENGER-BENTO-OWNER-TEST owner testing.

These modules are importable building blocks. They are not silently wired into
production payroll, employee, login, or UI flows; callers must explicitly
configure and integrate each service.
"""

__version__ = "5.5.0-VOIC3-MESSENGER-BENTO-OWNER-TEST"

from .database import get_connection, initialize_database
from .security import SecurityManager
from .document_vault import DocumentVault, REQUIRED_CATEGORIES
from .payroll import SouthAfricanPayrollEngine
from .anomaly_shield import AnomalyShield
from .wheelchair_tracker import WheelchairActivityTracker
from .offline_sync import OfflineSyncManager
from .backup_recovery import BackupRecoveryManager
from .in_app_upgrader import InAppUpgrader

__all__ = [
    "get_connection", "initialize_database", "SecurityManager",
    "DocumentVault", "REQUIRED_CATEGORIES", "SouthAfricanPayrollEngine",
    "AnomalyShield", "WheelchairActivityTracker",
    "OfflineSyncManager", "BackupRecoveryManager", "InAppUpgrader",
]
