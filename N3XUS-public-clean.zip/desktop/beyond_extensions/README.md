# Beyond Registration optional extensions (5.5.0-VOIC3-MESSENGER-BENTO-OWNER-TEST)

The ten owner-submitted code modules are included as a separately importable Python package:

1. SQLite schema foundation (`database.py`)
2. Administrator checks and audit-entry hashing (`security.py`)
3. Document categories, SHA-256 and OCR quarantine copy (`document_vault.py`)
4. Overtime calculator and generic ACB-layout export builder (`payroll.py`)
5. Rule-based anomaly classification (`anomaly_shield.py`)
6. WhatsApp Cloud API payslip sender (`whatsapp.py`)
7. Restricted wheelchair walk tracker (`wheelchair_tracker.py`)
8. Durable offline queue with callback-based sync (`offline_sync.py`)
9. Fernet-encrypted SQLite backup and integrity-checked restore (`backup_recovery.py`)
10. Administrator-authorized, syntax-checked upgrade staging (`in_app_upgrader.py`)

## Important integration boundary

These are service building blocks, not a claim that the existing desktop UI, live payroll, employee database, or Android application now calls them. The existing application source and business database schema were deliberately left unchanged to avoid an unsafe automatic migration. The extension database defaults to `your-userd_registration_extensions.db`; pass an explicit path if a controlled integration is later approved.

## Safety and operational notes

- Test against copied data. Do not point restore operations at the only live database.
- Keep Fernet keys outside the project folder and never commit or share them. Losing the key makes encrypted backups unrecoverable.
- The ACB text builder is a generic fixed-width draft, not a bank-certified payment file. Confirm the target bank's current specification and test with the bank before use.
- WhatsApp requires a valid Meta Cloud API token, phone-number ID, recipient consent and an HTTPS-hosted PDF. Credentials must be supplied securely at runtime.
- Offline sync requires a real processor callback. Without it, the queue is intentionally retained; it never declares records synced merely because the device is online.
- Wheelchair tracking state is in memory in this package. Production use requires persistent storage, scheduled check-in delivery, escalation and audit integration.
- Upgrade code is only syntax-checked and staged as `.pending`; it is never executed or installed automatically.
- Document intake copies the original into a quarantine folder; it does not claim OCR, malware scanning or identity verification.

Run extension tests from `desktop`:

```bash
python -m unittest -v tests.test_your-userd_extensions
```
