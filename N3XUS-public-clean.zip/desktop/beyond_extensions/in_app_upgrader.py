"""Safely stages administrator-supplied Python modules; does not execute them."""
from __future__ import annotations
import ast
import hashlib
import os
import re
import tempfile
import zipfile
from io import BytesIO
from pathlib import Path
from typing import Callable
from .security import DEFAULT_ADMINS

_HARDCODED_CREDENTIAL = re.compile(r"(?im)\b(?:password|passwd|secret|api[_-]?key|access[_-]?token|refresh[_-]?token|private[_-]?key)\b\s*[:=]\s*([\"'])([^\r\n\"']{8,})\1")
_PRIVATE_KEY_BLOCK = re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")


class InAppUpgrader:
    def __init__(self, target_dir="desktop/upgrades", admin_validator: Callable[[str], bool] | None = None):
        self.target_dir = Path(target_dir).expanduser().resolve()
        self.target_dir.mkdir(parents=True, exist_ok=True)
        self.admin_validator = admin_validator

    def verify_admin_authorization(self, username: str) -> bool:
        if self.admin_validator is not None:
            return bool(self.admin_validator(username))
        return username in DEFAULT_ADMINS

    def _pending_path(self, filename: str) -> Path:
        if not isinstance(filename, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,63}\.py\.pending", filename):
            raise ValueError("Invalid pending upgrade filename.")
        target = (self.target_dir / filename).resolve()
        if target.parent != self.target_dir:
            raise ValueError("Invalid pending upgrade path.")
        return target

    def list_pending(self) -> list[dict]:
        items = []
        for path in self.target_dir.glob("*.py.pending"):
            try:
                path.resolve().relative_to(self.target_dir)
                content = path.read_bytes()
                items.append({"filename":path.name,"bytes":len(content),"sha256":hashlib.sha256(content).hexdigest(),"updated_at":path.stat().st_mtime})
            except (OSError, ValueError):
                continue
        return sorted(items, key=lambda item: item["filename"].casefold())

    def read_pending(self, filename: str) -> dict:
        path = self._pending_path(filename)
        content = path.read_bytes()
        if len(content) > 2_000_000:
            raise ValueError("Pending file exceeds the 2 MB review limit.")
        text = content.decode("utf-8")
        return {"filename":path.name,"content":text,"sha256":hashlib.sha256(content).hexdigest()}

    def delete_pending(self, filename: str) -> None:
        self._pending_path(filename).unlink(missing_ok=False)

    def export_pending_zip(self) -> tuple[bytes, dict]:
        """Bundle only reviewed-pending Python files; the archive is never executed."""
        files=[]
        total_bytes=0
        for item in self.list_pending():
            filename=item["filename"]
            candidate=self.target_dir/filename
            if candidate.is_symlink():
                raise ValueError("A linked pending file cannot be included in a script archive.")
            path=self._pending_path(filename)
            if path.parent!=self.target_dir or not path.is_file():
                raise ValueError("A pending script has an unsafe archive path.")
            content=path.read_bytes()
            if len(content)>2_000_000:
                raise ValueError("A pending script exceeds the 2 MB archive limit.")
            try:
                source=content.decode("utf-8")
                ast.parse(source,filename=filename)
            except (UnicodeDecodeError,SyntaxError) as exc:
                raise ValueError("A pending script failed UTF-8 or syntax verification; review it before export.") from exc
            if _HARDCODED_CREDENTIAL.search(source) or _PRIVATE_KEY_BLOCK.search(source):
                raise ValueError("A staged script may contain a hard-coded credential. Remove it before exporting the ZIP.")
            total_bytes+=len(content)
            if total_bytes>20_000_000:
                raise ValueError("Pending scripts exceed the 20 MB archive limit.")
            files.append((filename.removesuffix(".pending"),content,hashlib.sha256(content).hexdigest()))
        if not files:
            raise ValueError("There are no staged Python scripts to export.")
        manifest=[
            "Beyond Registration staged script bundle",
            "These files are pending review only. The application did not execute or install them.",
            "Verify each SHA-256 digest before any separate release or installation step.",
            "",
        ]
        for filename,content,digest in files:
            manifest.append(f"{filename}\t{len(content)} bytes\tSHA-256 {digest}")
        buffer=BytesIO()
        with zipfile.ZipFile(buffer,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
            for filename,content,_ in files:
                archive.writestr(filename,content)
            archive.writestr("STAGED_SCRIPTS_MANIFEST.txt","\n".join(manifest)+"\n")
        return buffer.getvalue(),{"files":len(files),"source_bytes":total_bytes}

    def apply_code_upgrade(self, username: str, filename: str, code_content: str) -> dict:
        if not self.verify_admin_authorization(username):
            return {"status": "unauthorized", "message": "Only designated administrators may stage upgrades."}
        if not isinstance(filename, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,63}\.py", filename):
            return {"status": "error", "message": "Use a simple Python module filename; paths are not accepted."}
        if not isinstance(code_content, str) or len(code_content.encode("utf-8")) > 2_000_000:
            return {"status": "error", "message": "Upgrade content is invalid or exceeds 2 MB."}
        try: ast.parse(code_content, filename=filename)
        except SyntaxError as exc:
            return {"status": "error", "message": f"Python syntax validation failed at line {exc.lineno}."}
        if _HARDCODED_CREDENTIAL.search(code_content) or _PRIVATE_KEY_BLOCK.search(code_content):
            return {"status":"error","message":"Potential hard-coded credentials were blocked. Read secrets from a protected local environment instead."}
        destination = (self.target_dir / f"{filename}.pending").resolve()
        if destination.parent != self.target_dir:
            return {"status": "error", "message": "Invalid upgrade destination."}
        if destination.exists():
            return {"status": "error", "message": "A pending upgrade with this name already exists."}
        fd, temp_name = tempfile.mkstemp(prefix="upgrade_", suffix=".tmp", dir=str(self.target_dir))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(code_content); stream.flush(); os.fsync(stream.fileno())
            os.replace(temp_name, destination)
            code_hash=hashlib.sha256(destination.read_bytes()).hexdigest()
            return {"status": "staged", "file": destination.name, "sha256":code_hash,
                    "message": "Syntax-checked upgrade staged for separate review; it was not executed or installed."}
        finally:
            if os.path.exists(temp_name): os.unlink(temp_name)
