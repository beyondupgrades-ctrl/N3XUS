"""Isolated extension database schema; pass the intended data path explicitly."""
from __future__ import annotations
import sqlite3
from contextlib import closing
from pathlib import Path
from typing import Union

PathLike = Union[str, Path]
DEFAULT_DB_NAME = "your-userd_registration_extensions.db"


def get_connection(db_path: PathLike = DEFAULT_DB_NAME) -> sqlite3.Connection:
    path = Path(db_path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


def initialize_database(db_path: PathLike = DEFAULT_DB_NAME) -> None:
    with closing(get_connection(db_path)) as conn:
        with conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER PRIMARY KEY,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS employees (
                employee_id TEXT PRIMARY KEY,
                full_name TEXT NOT NULL,
                id_number TEXT UNIQUE NOT NULL,
                email TEXT,
                phone TEXT,
                status TEXT DEFAULT 'Active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS audit_ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                user TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT,
                hash TEXT
            );
            INSERT OR IGNORE INTO schema_version(version) VALUES (1);
            """)
