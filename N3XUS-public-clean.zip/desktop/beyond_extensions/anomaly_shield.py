"""Simple rule-based payroll/security anomaly classification."""
from datetime import datetime, timezone


class AnomalyShield:
    RULES = {
        "retroactive_salary_change": ("Critical", True, "Retroactive salary adjustment detected. Administrative override required."),
        "rapid_deletions": ("High", True, "Multiple rapid record deletions flagged."),
        "unexpected_bank_details": ("Critical", True, "Banking details changed prior to payroll run."),
    }

    def evaluate(self, event_type: str, details: dict) -> dict:
        severity, override, message = self.RULES.get(
            event_type, ("Information", False, "Event logged normally."))
        return {"timestamp": datetime.now(timezone.utc).isoformat(), "event_type": event_type,
                "severity": severity, "requires_override": override,
                "details": details or {}, "message": message}
