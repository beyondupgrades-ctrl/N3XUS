"""Overtime calculator and generic ACB-layout export builder (bank validation required)."""
from __future__ import annotations
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP


def _money(value) -> Decimal:
    amount = Decimal(str(value))
    if not amount.is_finite() or amount < 0:
        raise ValueError("Payment amounts and hours must be finite and non-negative.")
    return amount


class SouthAfricanPayrollEngine:
    def __init__(self, base_hourly_rate: float):
        self.base_hourly_rate = _money(base_hourly_rate)

    def calculate_gross_pay(self, hours: dict) -> float:
        multipliers = {"weekday": Decimal("1"), "saturday": Decimal("1.5"),
                       "sunday": Decimal("2"), "public_holiday": Decimal("2")}
        total = sum((_money(hours.get(day, 0)) * self.base_hourly_rate * multiplier
                     for day, multiplier in multipliers.items()), Decimal("0"))
        return float(total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

    def generate_acb_file(self, company_name: str, payments: list) -> str:
        if not company_name or "\n" in company_name or "\r" in company_name:
            raise ValueError("A valid single-line company name is required.")
        date_str = datetime.now().strftime("%Y%m%d")
        header = f"H{company_name[:30]:<30}{date_str}\n"
        body, total_cents = [], 0
        for index, payment in enumerate(payments, 1):
            cents_decimal = (_money(payment.get("net", 0)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
            cents = int(cents_decimal)
            if cents > 99999999999:
                raise ValueError("Payment exceeds the supported field width.")
            total_cents += cents
            name = str(payment.get("name", "Employee")).replace("\n", " ").replace("\r", " ")[:30]
            account = str(payment.get("account", "00000000000"))
            branch = str(payment.get("branch", "000000"))
            if not account.isdigit() or len(account) > 11 or not branch.isdigit() or len(branch) > 6:
                raise ValueError("Account and branch fields must contain digits within their field widths.")
            if index > 999999 or total_cents > 999999999999:
                raise ValueError("Payment batch exceeds the supported ACB field width.")
            body.append(f"D{index:06d}{branch:0>6}{account:0>11}{cents:011d}{name:<30}\n")
        trailer = f"T{len(payments):06d}{total_cents:012d}\n"
        return header + "".join(body) + trailer
