"""Encrypted SQLite backups and integrity-checked restoration."""
from __future__ import annotations
import os
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken
import base64 as _b64


def _fernet_key(encryption_key):
    # Accept either a raw 32-byte key or an already url-safe base64-encoded Fernet key.
    if isinstance(encryption_key, str):
        encryption_key = encryption_key.encode("ascii")
    if len(encryption_key) == 32:
        return _b64.urlsafe_b64encode(encryption_key)
    return encryption_key

class BackupRecoveryManager:
    def __init__(self, db_path="your-userd_registration.db", backup_dir="secure_backups"):
        self.db_path = Path(db_path).expanduser().resolve()
        self.backup_dir = Path(backup_dir).expanduser().resolve()
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def create_encrypted_backup(self, encryption_key: bytes) -> dict:
        if not self.db_path.is_file(): return {"status": "error", "message": "Source database not found."}
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = self.backup_dir / f"backup_{timestamp}.enc"
        fd, temp_path = tempfile.mkstemp(suffix=".sqlite", dir=str(self.backup_dir)); os.close(fd)
        source = None
        try:
            with self.db_path.open("rb") as probe:
                header = probe.read(6)
            if header == b"BRDB1\n":
                # The live database is AES-GCM encrypted at rest; open it through
                # the application's decrypting connection instead of raw sqlite3.
                try:
                    from database_encryption import connect_database
                    # Read-only view: a backup must never claim the single-writer
                    # lock that the running server already holds.
                    source = connect_database(self.db_path, self.db_path.parent, exclusive=False)
                except Exception as exc:
                    return {"status": "error", "message": f"Backup failed: encrypted database could not be unlocked ({type(exc).__name__})"}
            else:
                source = sqlite3.connect(str(self.db_path))
            target = sqlite3.connect(temp_path)
            try: source.backup(target)
            finally:
                target.close()
                # A read-only connection opened no writer lock: closing it must
                # not overwrite the file the live server is writing.
                try: source._persist_enabled = False
                except Exception: pass
                source.close()
            with open(temp_path, "rb") as stream: encrypted = Fernet(_fernet_key(encryption_key)).encrypt(stream.read())
            with open(backup_path, "xb") as stream: stream.write(encrypted)
            return {"status": "success", "backup_file": str(backup_path), "timestamp": timestamp,
                    "message": "Encrypted SQLite-consistent backup created."}
        except Exception as exc:
            return {"status": "error", "message": f"Backup failed: {type(exc).__name__}"}
        finally:
            try: os.unlink(temp_path)
            except FileNotFoundError: pass

    def restore_encrypted_backup(self, backup_file: str, encryption_key: bytes) -> dict:
        source = Path(backup_file).expanduser().resolve()
        if not source.is_file(): return {"status": "error", "message": "Backup file not found."}
        fd, temp_path = tempfile.mkstemp(suffix=".sqlite", dir=str(self.db_path.parent)); os.close(fd)
        try:
            with source.open("rb") as stream: raw = Fernet(_fernet_key(encryption_key)).decrypt(stream.read())
            with open(temp_path, "wb") as stream: stream.write(raw)
            check = sqlite3.connect(temp_path)
            try:
                result = check.execute("PRAGMA integrity_check").fetchone()[0]
                if result != "ok": raise ValueError("SQLite integrity check failed.")
            finally: check.close()
            os.replace(temp_path, self.db_path)
            return {"status": "success", "message": "Backup decrypted, verified, and restored."}
        except (InvalidToken, ValueError, sqlite3.DatabaseError) as exc:
            return {"status": "error", "message": f"Restore rejected: {type(exc).__name__}"}
        finally:
            try: os.unlink(temp_path)
            except FileNotFoundError: pass
