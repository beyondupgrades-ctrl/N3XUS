"""Administrator checks and SHA-256 audit-entry helpers."""
from __future__ import annotations
import hashlib
import json
from contextlib import closing
from datetime import datetime, timezone
from .database import get_connection

DEFAULT_ADMINS = ("Dean Brown", "Heidelise Josling-Brown", "Administrator")


class SecurityManager:
    def __init__(self, admins=None):
        self.admins = frozenset(admins or DEFAULT_ADMINS)

    def verify_admin_access(self, username: str) -> bool:
        return isinstance(username, str) and username in self.admins

    def create_audit_entry(self, user: str, action: str, details, db_path=None) -> dict:
        timestamp = datetime.now(timezone.utc).isoformat()
        details_text = details if isinstance(details, str) else json.dumps(details, sort_keys=True, default=str)
        raw = f"{timestamp}|{user}|{action}|{details_text}"
        entry = {"timestamp": timestamp, "user": user, "action": action,
                 "details": details_text, "hash": hashlib.sha256(raw.encode("utf-8")).hexdigest()}
        if db_path is not None:
            with closing(get_connection(db_path)) as conn:
                with conn:
                    conn.execute("INSERT INTO audit_ledger(timestamp,user,action,details,hash) VALUES(?,?,?,?,?)",
                                 (entry["timestamp"], user, action, details_text, entry["hash"]))
        return entry
