"""In-memory wheelchair walk tracker with access checks and check-in deadlines."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import RLock


class WheelchairActivityTracker:
    ADMINS = {"Dean Brown", "Heidelise Josling-Brown", "Administrator"}

    def __init__(self, user_role: str, is_designated_company_phone: bool):
        self.user_role = user_role
        self.is_company_phone = bool(is_designated_company_phone)
        self._walks = {}
        self._lock = RLock()

    def verify_access(self) -> bool:
        return self.user_role in self.ADMINS or self.is_company_phone

    def start_walk(self, employee_id: str, location_info: str) -> dict:
        if not self.verify_access():
            return {"status": "access_denied", "message": "Unauthorized access to wheelchair tracker."}
        if not employee_id:
            return {"status": "error", "message": "Employee ID is required."}
        now = datetime.now(timezone.utc)
        with self._lock:
            if employee_id in self._walks:
                return {"status": "error", "message": "An active walk already exists for this employee."}
            record = {"status": "walk_started", "employee_id": employee_id,
                      "start_time": now.isoformat(), "location": location_info,
                      "check_in_due_at": (now + timedelta(minutes=15)).isoformat()}
            self._walks[employee_id] = record
        return {**record, "message": "Walk started. A 15-minute safety check-in is due."}

    def end_walk(self, employee_id: str, photo_path: str) -> dict:
        if not self.verify_access():
            return {"status": "access_denied", "message": "Unauthorized access."}
        if not photo_path or not Path(photo_path).is_file():
            return {"status": "error", "message": "A valid end-of-walk photo file is required."}
        with self._lock:
            if employee_id not in self._walks:
                return {"status": "error", "message": "No active walk found for this employee."}
            record = self._walks.pop(employee_id)
        return {"status": "walk_completed", "employee_id": employee_id,
                "start_time": record["start_time"], "end_time": datetime.now(timezone.utc).isoformat(),
                "photo_verified": True, "photo_path": str(Path(photo_path).resolve()),
                "message": "Walk ended and completion details returned for secure logging."}
