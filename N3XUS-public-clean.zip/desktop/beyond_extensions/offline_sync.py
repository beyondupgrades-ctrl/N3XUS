"""Durable offline queue; items are removed only after processor success."""
from __future__ import annotations
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock


class OfflineSyncManager:
    def __init__(self, queue_file="offline_queue.json"):
        self.queue_file = Path(queue_file).expanduser().resolve()
        self.queue_file.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()

    def _read(self):
        if not self.queue_file.exists(): return []
        try:
            data = json.loads(self.queue_file.read_text(encoding="utf-8"))
            if not isinstance(data, list): raise ValueError("Offline queue must contain a list.")
            return data
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError("Offline queue is corrupt; it has been preserved for recovery.") from exc

    def _write(self, queue):
        fd, temp_name = tempfile.mkstemp(prefix="offline_queue_", suffix=".tmp", dir=str(self.queue_file.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(queue, stream, indent=2, ensure_ascii=False)
                stream.flush(); os.fsync(stream.fileno())
            os.replace(temp_name, self.queue_file)
        finally:
            if os.path.exists(temp_name): os.unlink(temp_name)

    def queue_submission(self, payload: dict) -> dict:
        if not isinstance(payload, dict): raise TypeError("Queued submission must be a dictionary.")
        with self._lock:
            queue = self._read()
            item = dict(payload)
            item["queued_at"] = datetime.now(timezone.utc).isoformat()
            queue.append(item); self._write(queue)
            return {"status": "queued_offline", "pending_items": len(queue)}

    def process_sync_queue(self, is_online: bool, processor=None) -> dict:
        if not is_online:
            return {"status": "offline", "message": "No connection; queued submissions retained."}
        if processor is None:
            return {"status": "error", "message": "A real sync processor is required; queue retained."}
        with self._lock:
            queue = self._read()
            if not queue: return {"status": "empty", "synced_items": 0}
            remaining, processed = [], 0
            for item in queue:
                try:
                    success = processor(item)
                except Exception:
                    success = False
                if success: processed += 1
                else: remaining.append(item)
            self._write(remaining)
            return {"status": "sync_complete" if not remaining else "partial",
                    "synced_items": processed, "pending_items": len(remaining),
                    "message": "Only successfully processed submissions were removed from the queue."}
