"""Document intake with category validation, hashing, and non-destructive quarantine copy."""
from __future__ import annotations
import hashlib
import os
import re
import shutil
import uuid
from pathlib import Path

REQUIRED_CATEGORIES = [
    "Timesheets", "Observation sheet", "Chart", "Handover sheet", "Incident report",
    "Room handover form", "Medication information administration", "Vital signs",
    "Daily routine report", "Contract", "Identity card", "Proof of bank account",
    "Proof of residence", "CV", "Qualifications"
]


class DocumentVault:
    def __init__(self, storage_dir="document_vault_storage"):
        self.storage_dir = Path(storage_dir).expanduser().resolve()
        self.quarantine_dir = self.storage_dir / "OCR_quarantine"
        for category in REQUIRED_CATEGORIES:
            (self.quarantine_dir / category).mkdir(parents=True, exist_ok=True)

    def process_upload(self, file_path: str, category: str) -> dict:
        if category not in REQUIRED_CATEGORIES:
            return {"status": "error", "message": "Invalid document category."}
        source = Path(file_path).expanduser()
        if not source.is_file():
            return {"status": "error", "message": "File path does not exist."}
        digest = hashlib.sha256()
        with source.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", source.name)[:120] or "document"
        destination = self.quarantine_dir / category / f"{uuid.uuid4().hex}_{safe_name}"
        shutil.copy2(source, destination)
        return {"status": "quarantined", "category": category,
                "sha256": digest.hexdigest(), "quarantine_path": str(destination),
                "message": "File validated, hashed, and copied to OCR quarantine; original retained."}
