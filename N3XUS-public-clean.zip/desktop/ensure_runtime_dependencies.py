"""Verify and repair mandatory PDF support before launching the app.

The native pywebview shell is optional because desktop_app.py has a browser fallback.
ReportLab is mandatory for payroll PDF generation, so it is checked independently.
"""
from __future__ import annotations
import importlib.util
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    auto_install = "--auto-install" in sys.argv
    if sys.version_info < (3, 10):
        print("Beyond Registration requires Python 3.10 or newer.")
        print(f"Detected: {sys.version.split()[0]}")
        return 2

    if importlib.util.find_spec("reportlab") is None:
        if not auto_install:
            print("Payroll PDF support (ReportLab) is missing. Re-run with --auto-install to install it, or install manually.")
            return 3
        print("Payroll PDF support (ReportLab) is missing. Repairing it now...")
        command = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "reportlab>=4.0,<5"]
        try:
            result = subprocess.run(command, check=False)
        except Exception as exc:
            print(f"Could not start the PDF component installer: {exc}")
            return 3
        if result.returncode != 0:
            print("PDF component installation failed. Check internet access and Python's pip installation, then run this launcher again.")
            return result.returncode or 4
        if importlib.util.find_spec("reportlab") is None:
            print("ReportLab installation finished but the module is still unavailable. PDF generation is not ready.")
            return 5
        print("Payroll PDF support installed and verified.")
    else:
        print("Payroll PDF support check passed (ReportLab is available).")

    if importlib.util.find_spec("cryptography") is None:
        if not auto_install:
            print("Encrypted backup support (cryptography) is missing. Re-run with --auto-install to install it, or install manually.")
            return 6
        print("Encrypted backup support (cryptography) is missing. Repairing it now...")
        command = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "cryptography>=42,<47"]
        try:
            result = subprocess.run(command, check=False)
        except Exception as exc:
            print(f"Could not start the encrypted-backup dependency installer: {exc}")
            return 6
        if result.returncode != 0 or importlib.util.find_spec("cryptography") is None:
            print("Encrypted backup dependency installation failed. Check internet access and pip.")
            return result.returncode or 7
        print("Encrypted backup dependency installed and verified.")
    else:
        print("Encrypted backup dependency check passed (cryptography is available).")

    if importlib.util.find_spec("webview") is None:
        print("Note: pywebview is not installed. The application will use its supported browser fallback.")
    else:
        print("Native desktop shell component is available.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
