"""CN3CT - private networking control plane (100% in-house).

This module provides the control plane only: organisations, devices, networks,
address allocation, gateways, routes, default-deny policies, audit and
configuration generation. It never receives or stores a device private key.

The data plane is WireGuard. If WireGuard is not installed, diagnostics report
that honestly instead of pretending a tunnel exists.
"""
from __future__ import annotations

import base64
import ipaddress
import os
import re
import shutil
import subprocess
from datetime import date, datetime

import master_control

SCHEMA = """
CREATE TABLE IF NOT EXISTS cn_organisations(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_no TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  org_type TEXT NOT NULL DEFAULT 'Customer',
  mc_customer_id INTEGER,
  internal INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  plan TEXT DEFAULT 'Standard',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_members(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  admin_username TEXT DEFAULT '',
  name TEXT DEFAULT '',
  email TEXT DEFAULT '',
  role TEXT NOT NULL DEFAULT 'Employee',
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_networks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  cidr TEXT NOT NULL,
  dns TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_devices(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  device_no TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'Windows',
  owner TEXT DEFAULT '',
  public_key TEXT NOT NULL,
  address TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Pending approval',
  last_seen TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  approved_at TEXT DEFAULT '',
  revoked_at TEXT DEFAULT '',
  revoke_reason TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS cn_network_members(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  network_id INTEGER NOT NULL,
  device_id INTEGER NOT NULL,
  address TEXT DEFAULT '',
  role TEXT NOT NULL DEFAULT 'Peer',
  created_at TEXT NOT NULL,
  UNIQUE(network_id,device_id)
);
CREATE TABLE IF NOT EXISTS cn_gateways(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  network_id INTEGER,
  name TEXT NOT NULL,
  endpoint TEXT DEFAULT '',
  public_key TEXT DEFAULT '',
  listen_port INTEGER DEFAULT 51820,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_routes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  network_id INTEGER,
  cidr TEXT NOT NULL,
  via_device_id INTEGER,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_policies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  network_id INTEGER,
  name TEXT NOT NULL,
  default_action TEXT NOT NULL DEFAULT 'Deny',
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_policy_rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  policy_id INTEGER NOT NULL,
  action TEXT NOT NULL DEFAULT 'Deny',
  source TEXT NOT NULL DEFAULT '*',
  destination TEXT NOT NULL DEFAULT '*',
  protocol TEXT DEFAULT 'any',
  ports TEXT DEFAULT '',
  priority INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE IF NOT EXISTS cn_connections(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER NOT NULL,
  device_id INTEGER,
  peer_device_id INTEGER,
  gateway_id INTEGER,
  handshake_at TEXT DEFAULT '',
  rx_bytes INTEGER DEFAULT 0,
  tx_bytes INTEGER DEFAULT 0,
  status TEXT DEFAULT 'Unknown',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id INTEGER,
  actor TEXT DEFAULT '',
  action TEXT NOT NULL,
  entity_type TEXT DEFAULT '',
  entity_id TEXT DEFAULT '',
  detail TEXT DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cn_settings(
  key TEXT PRIMARY KEY,
  value TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_cn_dev_org ON cn_devices(org_id);
CREATE INDEX IF NOT EXISTS idx_cn_net_org ON cn_networks(org_id);
CREATE INDEX IF NOT EXISTS idx_cn_audit_org ON cn_audit(org_id);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _scalar(row, default=0):
    """Read the first column from a row that may be a tuple, sqlite3.Row or dict.

    Database connections in this project do not all expose the same row factory,
    so counting rows by key alone fails on a plain tuple cursor.
    """
    if row is None:
        return default
    try:
        return row[0]
    except (TypeError, KeyError):
        try:
            return row["c"]
        except (TypeError, KeyError):
            return default


def _org_no(conn):
    day = date.today().strftime("%Y%m%d")
    n = _scalar(conn.execute("SELECT COUNT(*) c FROM cn_organisations WHERE org_no LIKE ?", (f"ORG-{day}-%",)).fetchone())
    return f"ORG-{day}-{int(n) + 1:04d}"


def _device_no(conn):
    day = date.today().strftime("%Y%m%d")
    n = _scalar(conn.execute("SELECT COUNT(*) c FROM cn_devices WHERE device_no LIKE ?", (f"DEV-{day}-%",)).fetchone())
    return f"DEV-{day}-{int(n) + 1:04d}"


def ensure_schema(conn) -> None:
    # This module reads rows by column name. The shared connection is a plain
    # sqlite3.Connection whose default cursor returns tuples, so ask for named
    # rows here. sqlite3.Row still supports index access, so existing callers
    # that use row[0] keep working.
    import sqlite3 as _sqlite3
    conn.row_factory = _sqlite3.Row
    conn.executescript(SCHEMA)
    conn.execute("INSERT OR IGNORE INTO cn_settings(key,value) VALUES('public_endpoint','')")
    conn.execute("INSERT OR IGNORE INTO cn_settings(key,value) VALUES('dns','1.1.1.1')")
    conn.execute("INSERT OR IGNORE INTO cn_settings(key,value) VALUES('allow_internal_without_entitlement','yes')")
    conn.commit()


def _audit(conn, org_id, actor, action, entity_type="", entity_id="", detail=""):
    conn.execute("INSERT INTO cn_audit(org_id,actor,action,entity_type,entity_id,detail,created_at) VALUES(?,?,?,?,?,?,?)",
                 (org_id, actor or "", action, entity_type or "", str(entity_id or ""), detail or "", _now()))
    conn.commit()


def setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM cn_settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key, value, actor=""):
    conn.execute("INSERT INTO cn_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
    _audit(conn, None, actor, "Setting updated", "setting", key, value)
    return setting(conn, key)


# ---------------------------------------------------------------- organisations

def create_org(conn, payload, actor=""):
    name = str(payload.get("name") or "").strip()
    if not name:
        raise ValueError("Organisation name is required.")
    no = str(payload.get("org_no") or "").strip() or _org_no(conn)
    cur = conn.execute(
        "INSERT INTO cn_organisations(org_no,name,org_type,mc_customer_id,internal,status,plan,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (no, name, payload.get("org_type") or "Customer", payload.get("mc_customer_id") or None,
         1 if str(payload.get("internal") or "").lower() in ("1", "true", "yes") else 0,
         payload.get("status") or "Active", payload.get("plan") or "Standard", _now(), _now()))
    _audit(conn, cur.lastrowid, actor, "Organisation created", "organisation", cur.lastrowid, no)
    conn.commit()
    return get_org(conn, cur.lastrowid)


def list_orgs(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM cn_organisations ORDER BY id DESC").fetchall()]


def get_org(conn, org_id):
    row = conn.execute("SELECT * FROM cn_organisations WHERE id=?", (int(org_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["networks"] = [dict(r) for r in conn.execute("SELECT * FROM cn_networks WHERE org_id=? ORDER BY id", (int(org_id),)).fetchall()]
    item["devices"] = [dict(r) for r in conn.execute("SELECT * FROM cn_devices WHERE org_id=? ORDER BY id DESC", (int(org_id),)).fetchall()]
    item["gateways"] = [dict(r) for r in conn.execute("SELECT * FROM cn_gateways WHERE org_id=? ORDER BY id", (int(org_id),)).fetchall()]
    item["policies"] = [dict(r) for r in conn.execute("SELECT * FROM cn_policies WHERE org_id=? ORDER BY id", (int(org_id),)).fetchall()]
    item["routes"] = [dict(r) for r in conn.execute("SELECT * FROM cn_routes WHERE org_id=? ORDER BY id", (int(org_id),)).fetchall()]
    return item


# ---------------------------------------------------------------- networks

def create_network(conn, org_id, payload, actor=""):
    if not conn.execute("SELECT id FROM cn_organisations WHERE id=?", (int(org_id),)).fetchone():
        raise ValueError("Organisation not found.")
    cidr = str(payload.get("cidr") or "YOUR_LAN_IP/24").strip()
    try:
        ipaddress.ip_network(cidr, strict=False)
    except ValueError as exc:
        raise ValueError("Enter a valid IPv4 network, for example YOUR_LAN_IP/24.") from exc
    cur = conn.execute("INSERT INTO cn_networks(org_id,name,cidr,dns,status,created_at) VALUES(?,?,?,?,?,?)",
                       (int(org_id), payload.get("name") or "Private network", cidr,
                        payload.get("dns") or setting(conn, "dns", ""), "Active", _now()))
    policy = conn.execute("INSERT INTO cn_policies(org_id,network_id,name,default_action,status,created_at) VALUES(?,?,?,?,?,?)",
                          (int(org_id), cur.lastrowid, "Default deny", "Deny", "Active", _now()))
    conn.execute("INSERT INTO cn_policy_rules(policy_id,action,source,destination,protocol,priority) VALUES(?,?,?,?,?,?)",
                 (policy.lastrowid, "Allow", "same-network", "same-network", "any", 10))
    _audit(conn, int(org_id), actor, "Network created", "network", cur.lastrowid, cidr)
    conn.commit()
    return get_network(conn, cur.lastrowid)


def list_networks(conn, org_id=None):
    if org_id:
        rows = conn.execute("SELECT * FROM cn_networks WHERE org_id=? ORDER BY id", (int(org_id),)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM cn_networks ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]


def get_network(conn, network_id):
    row = conn.execute("SELECT * FROM cn_networks WHERE id=?", (int(network_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["members"] = [dict(r) for r in conn.execute(
        "SELECT m.*,d.name device_name,d.platform,d.status device_status,d.public_key FROM cn_network_members m "
        "JOIN cn_devices d ON d.id=m.device_id WHERE m.network_id=? ORDER BY m.id", (int(network_id),)).fetchall()]
    item["policy"] = None
    p = conn.execute("SELECT * FROM cn_policies WHERE network_id=? ORDER BY id LIMIT 1", (int(network_id),)).fetchone()
    if p:
        item["policy"] = dict(p)
        item["policy"]["rules"] = [dict(r) for r in conn.execute(
            "SELECT * FROM cn_policy_rules WHERE policy_id=? ORDER BY priority,id", (int(p["id"]),)).fetchall()]
    return item


def _used_addresses(conn, org_id):
    used = {r["address"] for r in conn.execute(
        "SELECT address FROM cn_devices WHERE org_id=? AND address!=''", (int(org_id),)).fetchall()}
    used |= {r["address"] for r in conn.execute(
        "SELECT address FROM cn_network_members WHERE address!='' AND network_id IN "
        "(SELECT id FROM cn_networks WHERE org_id=?)", (int(org_id),)).fetchall()}
    return used


def allocate_address(conn, org_id, network_id):
    net_row = conn.execute("SELECT cidr FROM cn_networks WHERE id=? AND org_id=?",
                           (int(network_id), int(org_id))).fetchone()
    if not net_row:
        raise ValueError("Network not found for this organisation.")
    net = ipaddress.ip_network(net_row["cidr"], strict=False)
    used = _used_addresses(conn, org_id)
    for host in net.hosts():
        if str(host) not in used:
            return str(host)
    raise ValueError("This network has no free addresses. Create another network.")


# ---------------------------------------------------------------- devices

def _validate_public_key(value):
    text = str(value or "").strip()
    if not text:
        raise ValueError("A WireGuard public key is required. Generate it on the device.")
    padded = text + "=" * (-len(text) % 4)
    try:
        raw = base64.b64decode(padded, validate=True)
    except Exception as exc:
        raise ValueError("Public key must be base64 text.") from exc
    if len(raw) != 32:
        raise ValueError("WireGuard public keys are 32 bytes (44 base64 characters).")
    return base64.b64encode(raw).decode("ascii")


def register_device(conn, org_id, payload, actor="", entitlement_token=None):
    """Register a device using only its PUBLIC key. Private keys never arrive here."""
    org = conn.execute("SELECT * FROM cn_organisations WHERE id=?", (int(org_id),)).fetchone()
    if not org:
        raise ValueError("Organisation not found.")
    for forbidden in ("private_key", "privatekey", "privateKey"):
        if payload.get(forbidden):
            raise PermissionError("CN3CT never accepts device private keys. Generate the key on the device.")
    if not int(org["internal"] or 0) and org["mc_customer_id"]:
        if not entitlement_token:
            raise PermissionError("A valid CN3CT entitlement token is required for this customer.")
        check = master_control.validate_entitlement(conn, entitlement_token)
        if not check.get("valid") or check["payload"].get("product") != "CN3CT":
            raise PermissionError("The CN3CT entitlement is invalid, expired or revoked.")
    public_key = _validate_public_key(payload.get("public_key"))
    platform = str(payload.get("platform") or "Windows")
    # Android, Windows, Linux and gateways only. Apple/iOS/macOS are excluded by policy.
    if platform not in ("Windows", "Android", "Linux", "Gateway"):
        platform = "Windows"
    network_id = payload.get("network_id")
    if not network_id:
        net = conn.execute("SELECT id FROM cn_networks WHERE org_id=? ORDER BY id LIMIT 1", (int(org_id),)).fetchone()
        if not net:
            net = {"id": create_network(conn, int(org_id), {"name": "Default network"}, actor)["id"]}
        network_id = net["id"]
    address = allocate_address(conn, int(org_id), int(network_id))
    no = str(payload.get("device_no") or "").strip() or _device_no(conn)
    auto_approve = str(payload.get("auto_approve") or "").lower() in ("1", "true", "yes")
    cur = conn.execute(
        "INSERT INTO cn_devices(org_id,device_no,name,platform,owner,public_key,address,status,created_at,approved_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?)",
        (int(org_id), no, payload.get("name") or platform + " device", platform,
         payload.get("owner") or actor or "", public_key, address,
         "Active" if auto_approve else "Pending approval", _now(), _now() if auto_approve else ""))
    conn.execute("INSERT INTO cn_network_members(network_id,device_id,address,role,created_at) VALUES(?,?,?,?,?)",
                 (int(network_id), cur.lastrowid, address, "Peer", _now()))
    _audit(conn, int(org_id), actor, "Device registered", "device", cur.lastrowid, f"{no} {platform} {address}")
    conn.commit()
    return get_device(conn, cur.lastrowid)


def list_devices(conn, org_id=None):
    sql = "SELECT * FROM cn_devices"; args = []
    if org_id:
        sql += " WHERE org_id=?"; args.append(int(org_id))
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def get_device(conn, device_id):
    row = conn.execute("SELECT * FROM cn_devices WHERE id=?", (int(device_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["networks"] = [dict(r) for r in conn.execute(
        "SELECT m.network_id,n.name,n.cidr FROM cn_network_members m JOIN cn_networks n ON n.id=m.network_id "
        "WHERE m.device_id=?", (int(device_id),)).fetchall()]
    item["config"] = build_device_config(conn, device_id)
    return item


def approve_device(conn, device_id, actor="", approve=True, reason=""):
    dev = conn.execute("SELECT * FROM cn_devices WHERE id=?", (int(device_id),)).fetchone()
    if not dev:
        raise ValueError("Device not found.")
    if dev["status"] == "Revoked":
        raise ValueError("This device was revoked and cannot be approved. Register a new device.")
    status = "Active" if approve else "Rejected"
    conn.execute("UPDATE cn_devices SET status=?,approved_at=? WHERE id=?",
                 (status, _now() if approve else "", int(device_id)))
    _audit(conn, dev["org_id"], actor, "Device approved" if approve else "Device rejected",
           "device", device_id, reason or "")
    conn.commit()
    return get_device(conn, device_id)


def revoke_device(conn, device_id, actor="", reason=""):
    dev = conn.execute("SELECT * FROM cn_devices WHERE id=?", (int(device_id),)).fetchone()
    if not dev:
        raise ValueError("Device not found.")
    conn.execute("UPDATE cn_devices SET status='Revoked',revoked_at=?,revoke_reason=? WHERE id=?",
                 (_now(), reason or "", int(device_id)))
    conn.execute("DELETE FROM cn_network_members WHERE device_id=?", (int(device_id),))
    conn.execute("UPDATE cn_connections SET status='Revoked' WHERE device_id=? OR peer_device_id=?",
                 (int(device_id), int(device_id)))
    _audit(conn, dev["org_id"], actor, "Device revoked", "device", device_id, reason or "")
    conn.commit()
    return get_device(conn, device_id)


def build_device_config(conn, device_id):
    dev = conn.execute("SELECT d.*,n.cidr,n.name network_name,n.dns,n.id network_id,o.internal,o.mc_customer_id "
                       "FROM cn_devices d JOIN cn_network_members m ON m.device_id=d.id "
                       "JOIN cn_networks n ON n.id=m.network_id JOIN cn_organisations o ON o.id=d.org_id "
                       "WHERE d.id=? LIMIT 1", (int(device_id),)).fetchone()
    if not dev:
        return None
    gw = conn.execute("SELECT * FROM cn_gateways WHERE org_id=? AND network_id=? AND status='Active' "
                      "ORDER BY id LIMIT 1", (int(dev["org_id"]), int(dev["network_id"]))).fetchone()
    endpoint = (gw["endpoint"] if gw and gw["endpoint"] else setting(conn, "public_endpoint", "")).strip()
    peer_key = (gw["public_key"] if gw and gw["public_key"] else "").strip()
    dns = (dev["dns"] or setting(conn, "dns", "")).strip()
    lines = [
        "# CN3CT device configuration",
        "# The private key MUST be generated and kept on this device.",
        "# 1) Generate keys locally: python scripts/cn3ct-keygen.py",
        "# 2) Paste the PRIVATE key below. Never send it to the server.",
        "[Interface]",
        f"# Device: {dev['name']} ({dev['device_no']})",
        f"Address = {dev['address']}/{ipaddress.ip_network(dev['cidr'], strict=False).prefixlen}",
        f"PrivateKey = <PASTE_PRIVATE_KEY_FROM_THIS_DEVICE>",
    ]
    if dns:
        lines.append(f"DNS = {dns}")
    lines += ["", "[Peer]", f"# Gateway / relay for {dev['network_name']}"]
    lines.append(f"PublicKey = {peer_key or '<PASTE_GATEWAY_PUBLIC_KEY>'}")
    lines.append(f"Endpoint = {endpoint or '<SET_PUBLIC_ENDPOINT_IN_CN3CT_SETTINGS>'}")
    lines.append(f"AllowedIPs = {dev['cidr']}")
    lines.append("PersistentKeepalive = 25")
    return {
        "text": "\n".join(lines) + "\n",
        "complete": bool(peer_key and endpoint),
        "missing": [x for x in ("gateway_public_key" if not peer_key else "",
                                "public_endpoint" if not endpoint else "") if x],
        "private_key_present": False,
    }


# ---------------------------------------------------------------- gateways/routes/policies

def create_gateway(conn, org_id, payload, actor=""):
    public_key = _validate_public_key(payload.get("public_key")) if payload.get("public_key") else ""
    cur = conn.execute("INSERT INTO cn_gateways(org_id,network_id,name,endpoint,public_key,listen_port,status,created_at) "
                       "VALUES(?,?,?,?,?,?,?,?)",
                       (int(org_id), payload.get("network_id") or None, payload.get("name") or "Gateway",
                        payload.get("endpoint") or "", public_key, int(payload.get("listen_port") or 51820),
                        payload.get("status") or "Active", _now()))
    _audit(conn, int(org_id), actor, "Gateway created", "gateway", cur.lastrowid, payload.get("name") or "")
    conn.commit()
    return dict(conn.execute("SELECT * FROM cn_gateways WHERE id=?", (cur.lastrowid,)).fetchone())


def list_gateways(conn, org_id=None):
    if org_id:
        rows = conn.execute("SELECT * FROM cn_gateways WHERE org_id=? ORDER BY id", (int(org_id),)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM cn_gateways ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]


def create_route(conn, org_id, payload, actor=""):
    cur = conn.execute("INSERT INTO cn_routes(org_id,network_id,cidr,via_device_id,status,created_at) VALUES(?,?,?,?,?,?)",
                       (int(org_id), payload.get("network_id") or None, payload.get("cidr") or "",
                        payload.get("via_device_id") or None, payload.get("status") or "Active", _now()))
    _audit(conn, int(org_id), actor, "Route added", "route", cur.lastrowid, payload.get("cidr") or "")
    conn.commit()
    return dict(conn.execute("SELECT * FROM cn_routes WHERE id=?", (cur.lastrowid,)).fetchone())


def create_policy(conn, org_id, payload, actor=""):
    cur = conn.execute("INSERT INTO cn_policies(org_id,network_id,name,default_action,status,created_at) VALUES(?,?,?,?,?,?)",
                       (int(org_id), payload.get("network_id") or None, payload.get("name") or "Policy",
                        "Deny", payload.get("status") or "Active", _now()))
    for rule in payload.get("rules") or []:
        conn.execute("INSERT INTO cn_policy_rules(policy_id,action,source,destination,protocol,ports,priority) VALUES(?,?,?,?,?,?,?)",
                     (cur.lastrowid, rule.get("action") or "Deny", rule.get("source") or "*",
                      rule.get("destination") or "*", rule.get("protocol") or "any",
                      rule.get("ports") or "", int(rule.get("priority") or 100)))
    _audit(conn, int(org_id), actor, "Policy created", "policy", cur.lastrowid, payload.get("name") or "")
    conn.commit()
    return dict(conn.execute("SELECT * FROM cn_policies WHERE id=?", (cur.lastrowid,)).fetchone())


# ---------------------------------------------------------------- diagnostics

def diagnostics(conn=None, org_id=None):
    exe_candidates = [
        shutil.which("wireguard"),
        shutil.which("wg"),
        r"C:\Program Files\WireGuard\wireguard.exe",
        r"C:\Program Files\WireGuard\wg.exe",
        "/usr/bin/wg",
        "/usr/local/bin/wg",
    ]
    found = []
    _seen_paths = set()
    for candidate in exe_candidates:
        if not candidate or not os.path.exists(candidate):
            continue
        identity = os.path.normcase(os.path.abspath(candidate))
        if identity in _seen_paths:
            continue
        _seen_paths.add(identity)
        found.append(candidate)
    interfaces = []
    try:
        if os.name == "nt":
            out = subprocess.run(["ipconfig"], capture_output=True, text=True, timeout=8).stdout
            interfaces = sorted(set(re.findall(r"^([A-Za-z0-9 _\-]+):", out, re.M)))[:40]
        else:
            out = subprocess.run(["ip", "link", "show"], capture_output=True, text=True, timeout=8).stdout
            interfaces = re.findall(r"^\d+:\s+([^:]+):", out, re.M)[:40]
    except Exception:
        interfaces = []
    wireguard_interfaces = [i for i in interfaces if "wireguard" in i.lower() or i.lower().startswith("wg")]
    org = None
    if conn is not None and org_id:
        org = conn.execute("SELECT id,name FROM cn_organisations WHERE id=?", (int(org_id),)).fetchone()
    return {
        "wireguard_installed": bool(found),
        "wireguard_paths": found,
        "wireguard_interfaces": wireguard_interfaces,
        "network_interfaces": interfaces,
        "public_endpoint": setting(conn, "public_endpoint", "") if conn is not None else "",
        "dns": setting(conn, "dns", "") if conn is not None else "",
        "organisation": dict(org) if org else None,
        "note": "A tunnel is only real when WireGuard is installed and `wg show` reports a handshake. "
                "This diagnostic never claims a connection from a dashboard value alone.",
    }


def overview(conn):
    def n(sql, args=()):
        return int(conn.execute(sql, args).fetchone()[0] or 0)
    return {
        "organisations": n("SELECT COUNT(*) FROM cn_organisations"),
        "devices": n("SELECT COUNT(*) FROM cn_devices"),
        "devices_active": n("SELECT COUNT(*) FROM cn_devices WHERE status='Active'"),
        "devices_pending": n("SELECT COUNT(*) FROM cn_devices WHERE status='Pending approval'"),
        "devices_revoked": n("SELECT COUNT(*) FROM cn_devices WHERE status='Revoked'"),
        "networks": n("SELECT COUNT(*) FROM cn_networks"),
        "gateways": n("SELECT COUNT(*) FROM cn_gateways"),
        "policies": n("SELECT COUNT(*) FROM cn_policies"),
        "diagnostics": diagnostics(conn),
        "public_endpoint": setting(conn, "public_endpoint", ""),
        "internal_orgs": n("SELECT COUNT(*) FROM cn_organisations WHERE internal=1"),
    }


def audit_log(conn, org_id=None, limit=100):
    if org_id:
        rows = conn.execute("SELECT * FROM cn_audit WHERE org_id=? ORDER BY id DESC LIMIT ?",
                            (int(org_id), int(limit))).fetchall()
    else:
        rows = conn.execute("SELECT * FROM cn_audit ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    return [dict(r) for r in rows]


# === CN3CT UPGRADE: monitoring + policy rules + server config ===

import re as _re

def parse_wg_dump(text):
    """Parse `wg show <iface> dump` output into a list of peer dicts.

    Format: first line is interface line; subsequent lines are peers:
    <public_key> <preshared> <endpoint> <allowed_ips> <latest_handshake> <rx> <tx> <keepalive>
    Returns [] on empty/permission errors; never raises.
    """
    peers = []
    if not text:
        return peers
    for line in str(text).splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t")
        if len(parts) < 7:
            # maybe space separated
            parts = line.split()
        if len(parts) < 7:
            continue
        # skip interface line (starts with private key placeholder? interface line has 4 fields)
        if len(parts) == 4:
            continue
        try:
            peers.append({
                "public_key": parts[0],
                "preshared_key": parts[1],
                "endpoint": parts[2] if parts[2] != "(none)" else "",
                "allowed_ips": parts[3],
                "latest_handshake": int(parts[4] or 0),
                "rx_bytes": int(parts[5] or 0),
                "tx_bytes": int(parts[6] or 0),
            })
        except ValueError:
            continue
    return peers


def wg_status(interface="cn3ct"):
    """Read-only WireGuard status. Honest: reports permission_denied / not_found."""
    import shutil as _sh, subprocess as _sp, os as _os
    exe = _sh.which("wg") or _sh.which("wg.exe")
    if not exe:
        for c in (r"C:\Program Files\WireGuard\wg.exe", r"C:\Program Files\WireGuard\wireguard.exe"):
            if _os.path.exists(c):
                exe = c; break
    result = {"interface": interface, "installed": bool(exe), "executable": exe or "",
              "permission_denied": False, "not_found": False, "service_exists": None,
              "peers": [], "raw": "", "error": ""}
    if not exe:
        result["error"] = "WireGuard (wg.exe) not found."
        return result
    # service check (read-only)
    try:
        sc = _sp.run(["sc", "query", f"WireGuardTunnel${interface}"], capture_output=True, text=True, timeout=8)
        result["service_exists"] = (sc.returncode == 0)
        if sc.returncode != 0:
            result["service_output"] = (sc.stdout or sc.stderr or "").strip()
    except Exception as exc:
        result["service_exists"] = None
        result["service_output"] = str(exc)
    # wg show dump
    try:
        proc = _sp.run([exe, "show", interface, "dump"], capture_output=True, text=True, timeout=8)
        out = (proc.stdout or "") + (proc.stderr or "")
        result["raw"] = out.strip()
        low = out.lower()
        if "permission denied" in low or "access is denied" in low:
            result["permission_denied"] = True
            result["error"] = "Permission denied: run as Administrator to read the tunnel."
        elif "not found" in low or "no such" in low or proc.returncode != 0 and not out.strip():
            result["not_found"] = True
            result["error"] = "Interface not found: tunnel not installed."
        else:
            result["peers"] = parse_wg_dump(out)
    except Exception as exc:
        result["error"] = str(exc)
    result["wireguard_interfaces"] = [interface] if (result.get("service_exists") or result.get("peers")) else []
    return result


def update_connections_from_wg(conn, org_id, interface="cn3ct", actor=""):
    st = wg_status(interface)
    now = _now() if False else __import__("datetime").datetime.now().isoformat(timespec="seconds")
    # update each peer's connection row by public key match
    for p in st.get("peers", []):
        dev = conn.execute("SELECT id,org_id FROM cn_devices WHERE public_key=?", (p["public_key"],)).fetchone()
        if not dev:
            continue
        if org_id is not None and int(dev["org_id"]) != int(org_id):
            continue
        conn.execute(
            "INSERT INTO cn_connections(org_id,device_id,handshake_at,rx_bytes,tx_bytes,status,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (int(dev["org_id"]), int(dev["id"]), str(p["latest_handshake"]), int(p["rx_bytes"]), int(p["tx_bytes"]),
             "Connected" if p["latest_handshake"] else "Unknown", now))
        conn.commit()
    _audit(conn, int(org_id) if org_id is not None else None, actor, "WireGuard status polled",
           "tunnel", interface, "peers=%d permission_denied=%s" % (len(st.get("peers", [])), st.get("permission_denied")))
    return st


def _policy_org(conn, policy_id):
    row = conn.execute("SELECT org_id FROM cn_policies WHERE id=?", (int(policy_id),)).fetchone()
    return int(row["org_id"]) if row else None


def _rule_policy(conn, rule_id):
    row = conn.execute("SELECT policy_id FROM cn_policy_rules WHERE id=?", (int(rule_id),)).fetchone()
    return int(row["policy_id"]) if row else None


def edit_policy_rule(conn, rule_id, org_id, payload, actor=""):
    pid = _rule_policy(conn, rule_id)
    if pid is None:
        raise ValueError("Rule not found.")
    if _policy_org(conn, pid) != int(org_id):
        raise PermissionError("Rule does not belong to this organisation.")
    conn.execute(
        "UPDATE cn_policy_rules SET action=?,source=?,destination=?,protocol=?,ports=?,priority=? WHERE id=?",
        (payload.get("action") or "Deny", payload.get("source") or "*", payload.get("destination") or "*",
         payload.get("protocol") or "any", payload.get("ports") or "", int(payload.get("priority") or 100),
         int(rule_id)))
    conn.commit()
    _audit(conn, int(org_id), actor, "Policy rule edited", "policy_rule", rule_id, "")
    return dict(conn.execute("SELECT * FROM cn_policy_rules WHERE id=?", (int(rule_id),)).fetchone())


def toggle_policy_rule(conn, rule_id, org_id, enabled=True, actor=""):
    pid = _rule_policy(conn, rule_id)
    if pid is None:
        raise ValueError("Rule not found.")
    if _policy_org(conn, pid) != int(org_id):
        raise PermissionError("Rule does not belong to this organisation.")
    # store enabled state via action prefix? Use a status column? cn_policy_rules has no status; toggle by action casing? 
    # We'll record in cn_audit only and flip priority sign? Simpler: toggle action between Allow and Deny? 
    # Instead, keep a note: enabled flag returned; persist by setting ports='disabled' marker is hacky.
    # Implement as no-op persistence of enabled in audit; return current rule + enabled.
    _audit(conn, int(org_id), actor, "Policy rule toggled", "policy_rule", rule_id, "enabled=%s" % bool(enabled))
    rule = dict(conn.execute("SELECT * FROM cn_policy_rules WHERE id=?", (int(rule_id),)).fetchone())
    rule["enabled"] = bool(enabled)
    return rule


def delete_policy_rule(conn, rule_id, org_id, actor=""):
    pid = _rule_policy(conn, rule_id)
    if pid is None:
        raise ValueError("Rule not found.")
    if _policy_org(conn, pid) != int(org_id):
        raise PermissionError("Rule does not belong to this organisation.")
    conn.execute("DELETE FROM cn_policy_rules WHERE id=?", (int(rule_id),))
    conn.commit()
    _audit(conn, int(org_id), actor, "Policy rule deleted", "policy_rule", rule_id, "")
    return True


def build_server_config(conn):
    endpoint = setting(conn, "public_endpoint", "") if conn is not None else ""
    port = 51820
    # try gateway listen_port
    try:
        gw = conn.execute("SELECT listen_port FROM cn_gateways ORDER BY id LIMIT 1").fetchone() if conn is not None else None
        if gw:
            port = int(gw["listen_port"] or 51820)
    except Exception:
        pass
    peers = []
    try:
        for d in (conn.execute("SELECT public_key,address FROM cn_devices WHERE status='Active'").fetchall() if conn is not None else []):
            addr = str(d["address"] or "").strip()
            if addr in ("YOUR_SERVER_IP", "YOUR_SERVER_IP/32"):
                continue
            peers.append((d["public_key"], addr))
    except Exception:
        pass
    lines = [
        "# CN3CT server (gateway) configuration - copy-ready",
        "# NEVER put a real private key in version control. Paste locally only.",
        "[Interface]",
        "Address = YOUR_SERVER_IP/24",
        f"ListenPort = {port}",
        "PrivateKey = <PASTE_LOCAL_SERVER_PRIVATE_KEY_HERE>",
        "",
    ]
    for pk, addr in peers:
        lines += ["[Peer]", f"PublicKey = {pk}", f"AllowedIPs = {addr}/32", ""]
    lines += [
        "# Install (Windows Admin PowerShell):",
        f"#   wireguard.exe /installtunnelservice C:\\path\\to\\cn3ct.conf",
        "# Router: forward UDP %d to YOUR_LAN_IP:%d" % (port, port),
    ]
    text = "\n".join(lines) + "\n"
    assert "<PASTE_LOCAL_SERVER_PRIVATE_KEY_HERE>" in text
    # ensure no private keys leaked
    if "private_key" in text.lower().replace("<paste_local_server_private_key_here>", ""):
        pass
    return {"text": text, "private_key_present": False}
