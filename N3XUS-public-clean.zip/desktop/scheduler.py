"""Simple in-house task scheduler (100% free, no external deps).

Runs a background thread that ticks once per minute and runs registered jobs
when their scheduled time arrives. Jobs are plain Python callables that receive
the AppService. All execution is guarded by SERVICE.lock and logged to audit_log.
"""
from __future__ import annotations
import threading
import time
from datetime import datetime, timedelta


class Scheduler:
    def __init__(self, service):
        self.service = service
        self.jobs = []          # list of dict: {name, hour, minute, weekday, last_run, enabled, fn}
        self.lock = threading.RLock()
        self._stop = False
        self._thread = None

    def register(self, name, fn, hour=0, minute=0, weekday=None, enabled=True, every=None):
        with self.lock:
            self.jobs.append({
                "name": name, "fn": fn, "hour": hour, "minute": minute,
                "weekday": weekday, "enabled": enabled, "last_run": None,
                "every": every,
            })

    def set_enabled(self, name, enabled):
        with self.lock:
            for j in self.jobs:
                if j["name"] == name:
                    j["enabled"] = bool(enabled)

    def status(self):
        with self.lock:
            out = []
            for j in self.jobs:
                out.append({
                    "name": j["name"], "enabled": j["enabled"],
                    "hour": j["hour"], "minute": j["minute"],
                    "weekday": j["weekday"], "last_run": j["last_run"],
                })
            return {"jobs": out, "running": self._thread is not None and self._thread.is_alive()}

    def run_now(self, name):
        with self.lock:
            job = next((j for j in self.jobs if j["name"] == name), None)
        if job is None:
            raise KeyError("Unknown scheduled job: " + name)
        return self._run_job(job)

    def _run_job(self, job):
        try:
            with self.service.lock:
                result = job["fn"](self.service)
            try:
                self.service.store.log("scheduler", "Scheduled job ran", "scheduler", 0,
                                       job["name"] + ": " + str(result)[:200])
                self.service.store.conn.commit()
            except Exception:
                pass
            job["last_run"] = datetime.now().isoformat(timespec="seconds")
            return {"ok": True, "job": job["name"], "result": result}
        except Exception as exc:
            try:
                self.service.store.log("scheduler", "Scheduled job failed", "scheduler", 0,
                                       job["name"] + ": " + type(exc).__name__ + ": " + str(exc)[:200])
                self.service.store.conn.commit()
            except Exception:
                pass
            return {"ok": False, "job": job["name"], "error": str(exc)}

    def _tick(self):
        now = datetime.now()
        with self.lock:
            due = []
            for j in self.jobs:
                if not j["enabled"]:
                    continue
                if j["weekday"] is not None and now.weekday() != j["weekday"]:
                    continue
                if j["hour"] is not None and now.hour != j["hour"]:
                    continue
                if j["minute"] is not None and now.minute != j["minute"]:
                    continue
                if j.get("every") and (now.minute % j["every"]) != 0:
                    continue
                # Avoid running twice in the same minute
                if j["last_run"] and j["last_run"][:16] == now.isoformat(timespec="minutes"):
                    continue
                due.append(j)
        for j in due:
            self._run_job(j)

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        self._thread = threading.Thread(target=self._loop, daemon=True, name="nexus-scheduler")
        self._thread.start()

    def stop(self):
        self._stop = True

    def _loop(self):
        while not self._stop:
            try:
                self._tick()
            except Exception:
                pass
            time.sleep(60)


# ---- Default jobs (all free, all in-house) ----

def job_nightly_backup(svc):
    target = svc.store.backup_bundle()
    return "backup created: " + str(target.name)

def job_daily_attendance_rebuild(svc):
    svc.store.rebuild_attendance("scheduler")
    return "attendance rebuilt"

def job_weekly_report(svc):
    counts = svc.dashboard().get("counts", {})
    svc.store.log("scheduler", "Weekly summary generated", "report", 0, str(counts))
    svc.store.conn.commit()
    return "weekly summary logged: " + str(counts)

def job_rules(svc):
    import rules
    findings = rules.run(svc.store.conn, svc)
    return str(len(findings)) + " rule findings"

def job_auto_approve_leave(svc):
    import autonomy
    if autonomy.level_for(svc) < 3:
        return "autonomy < 3, skipped"
    try:
        rows = svc.store.conn.execute(
            "SELECT id, employee_id, days FROM leave_records WHERE status='Pending'").fetchall()
    except Exception:
        return "no leave table"
    approved = 0
    for r in rows:
        try:
            days = float(r["days"] or 0)
            if days <= 3:
                svc.store.conn.execute(
                    "UPDATE leave_records SET status='Approved', decision_by='autonomy', decision_at=? WHERE id=?",
                    (__import__("datetime").datetime.now().isoformat(timespec="seconds"), r["id"]))
                approved += 1
        except Exception:
            pass
    svc.store.conn.commit()
    if approved:
        svc.store.log("autonomy", "Auto-approved leave", "leave", 0, str(approved) + " requests")
        svc.store.conn.commit()
    return "auto-approved " + str(approved) + " leave requests"


def job_evolv3_evolve(svc):
    import academy
    try:
        llm = getattr(svc, "_evolve_llm", None) or getattr(svc, "_llm_chat", None)
        if llm is None:
            return "no llm available, skipped"
        result = academy.evolve(svc.store.conn, llm, "dementia", 2, 2, "scheduler",
                                db_lock=getattr(svc, "lock", None))
        return str(result.get("summary") or result.get("status")) + " (run " + str(result.get("run_id")) + ")"
    except Exception as exc:
        return "evolution failed: " + type(exc).__name__ + ": " + str(exc)[:120]
    sched = Scheduler(service)
    sched.register("nightly_backup", job_nightly_backup, hour=2, minute=0)
    sched.register("daily_attendance_rebuild", job_daily_attendance_rebuild, hour=0, minute=30)
    sched.register("weekly_report", job_weekly_report, hour=6, minute=0, weekday=0)
    sched.register("rule_engine", job_rules, hour=None, minute=None, every=5)
    sched.register("auto_approve_leave", job_auto_approve_leave, hour=None, minute=None, every=10)
    sched.register("evolv3_evolve", job_evolv3_evolve, hour=2, minute=30, weekday=6)
    service.scheduler = sched
    sched.start()
    return sched