"""EVOLV3 knowledge content: dementia pack (expanded).

Plain-English fact cards and mini emergency cards for staff and family.
Bodies are intentionally detailed so a reader learns something new from
every card, while staying free of jargon.
"""

from __future__ import annotations

PACK = "dementia"

DISCLAIMER = (
    "EVOLV3 teaches general awareness so you can act with confidence. It is not "
    "medical advice and does not replace a doctor, nurse or emergency dispatcher. "
    "When in doubt, call for help early."
)

EMERGENCY_NUMBERS = [
    {"label": "Ambulance (landline)", "number": "10177", "tel": "10177",
     "note": "State ambulance service."},
    {"label": "Emergency (any cellphone)", "number": "112", "tel": "112",
     "note": "Free from any cellphone, even without airtime."},
    {"label": "Police", "number": "10111", "tel": "10111",
     "note": "Crime, abuse and missing-person reports."},
    {"label": "Poison helpline", "number": "0861 555 777", "tel": "0861555777",
     "note": "24-hour poisons information, Tygerberg."},
]

CARDS = [
    {
        "slug": "what-dementia-is",
        "kind": "fact", "category": "Understanding dementia",
        "title": "Dementia is a set of symptoms, not one disease",
        "teaser": "Memory, thinking and behaviour change together.",
        "body": (
            "Dementia is an umbrella word for a group of symptoms: memory loss, "
            "difficulty thinking, changes in mood and trouble with everyday tasks. "
            "It is caused by damage to brain cells, and there are many different "
            "causes. Alzheimer's disease is the most common, causing roughly 6 to 7 "
            "out of every 10 cases worldwide. Other causes include vascular dementia "
            "(after small strokes), Lewy body dementia and frontotemporal dementia. "
            "Two people with dementia can look very different, because the affected "
            "brain areas differ. That is why care must be tailored to the person, "
            "not to a label."
        ),
        "tip": "Say \"a person living with dementia\", not \"a demented person\". The person comes first.",
        "icon": "🧠", "minutes": 2,
    },
    {
        "slug": "not-normal-ageing",
        "kind": "fact", "category": "Understanding dementia",
        "title": "Dementia is not a normal part of ageing",
        "teaser": "Forgetting where you parked is normal. Forgetting what a car is, is not.",
        "body": (
            "Getting slower or occasionally forgetting a name happens to most of us "
            "and does not stop us managing our lives. Dementia is different: it "
            "steadily interferes with daily life. Someone may forget how to use a "
            "kettle, get lost on their own street, or not recognise a familiar face. "
            "The changes worsen over months and years, not days. That pattern needs "
            "a medical assessment, not just \"old age\". Early assessment matters "
            "because some causes are treatable (thyroid, vitamin B12, medication "
            "side effects, depression)."
        ),
        "tip": "If changes are getting worse over months, book a doctor's visit and write down examples first.",
        "icon": "🌱", "minutes": 2,
    },
    {
        "slug": "more-than-memory",
        "kind": "fact", "category": "Understanding dementia",
        "title": "It is more than memory",
        "teaser": "Language, judgement, mood and movement can all change.",
        "body": (
            "Dementia can affect how someone speaks, understands, plans, judges "
            "risk, controls emotions and even walks. Someone may struggle to find "
            "the right word, become easily upset, or put on a jersey in the heat. "
            "They may misjudge distances, lose the concept of money, or no longer "
            "recognise danger. These are symptoms of brain change, not stubbornness "
            "or bad manners. Expecting the person to \"try harder\" only causes "
            "shame."
        ),
        "tip": "When behaviour changes, ask \"what is the brain struggling with right now?\"",
        "icon": "🧩", "minutes": 2,
    },
    {
        "slug": "person-not-problem",
        "kind": "fact", "category": "Understanding dementia",
        "title": "The person is not \"being difficult\"",
        "teaser": "Behaviour is communication when words fail.",
        "body": (
            "Hitting out, shouting or refusing a bath is usually a message: I am "
            "in pain, I am frightened, I do not understand, I need the toilet, or "
            "I am overwhelmed. The brain can no longer say it in words, so the "
            "body says it instead. Look for the cause behind the behaviour before "
            "you try to stop it. Common triggers: pain, a full bladder, hunger, "
            "thirst, noise, a new face, or a change of routine."
        ),
        "tip": "Ask: is there pain, noise, hunger, thirst, a wet pad, or a new face in the room?",
        "icon": "💬", "minutes": 2,
    },
    {
        "slug": "short-vs-long-term-memory",
        "kind": "fact", "category": "Understanding dementia",
        "title": "Yesterday fades, but 1965 can be vivid",
        "teaser": "Long-term memories often outlast short-term ones.",
        "body": (
            "Short-term memory is usually hit first, so the same question comes "
            "back every few minutes. Long-term memories from youth may stay sharp "
            "for years. That is why old songs, childhood stories and familiar "
            "routines can still bring comfort and connection. It also explains why "
            "someone may not recognise their own adult children but remembers a "
            "parent who died decades ago."
        ),
        "tip": "Use the past as a bridge: old photos, songs and stories often calm and connect.",
        "icon": "📻", "minutes": 2,
    },
    {
        "slug": "routine-calms",
        "kind": "fact", "category": "Daily care",
        "title": "Routine is brain-friendly",
        "teaser": "Predictable days need less thinking.",
        "body": (
            "Dementia makes it hard to work out what comes next. A steady rhythm "
            "- wake, wash, breakfast, walk, lunch, rest, supper, bed - removes "
            "hundreds of small decisions. Meals, medication and sleep all improve "
            "when the day is predictable. Even the order of putting on clothes "
            "matters. Change the routine only when you have to, and explain the "
            "change simply and early."
        ),
        "tip": "Keep the same order for meals, washing and bedtime, even on weekends.",
        "icon": "🔁", "minutes": 2,
    },
    {
        "slug": "one-thing-at-a-time",
        "kind": "fact", "category": "Communication",
        "title": "One instruction at a time",
        "teaser": "Short, simple, slow.",
        "body": (
            "A long sentence with three steps is easy to lose. Say one thing, "
            "wait, then say the next. \"Here is your tea.\" Pause. \"Sit down, "
            "please.\" Demonstrate with your hands if words do not land. Give the "
            "person time to process - up to 10 seconds. Repeating the same words "
            "louder does not help; simpler words do."
        ),
        "tip": "Speak one idea per sentence, and give the person time to answer.",
        "icon": "🗣️", "minutes": 1,
    },
    {
        "slug": "never-i-told-you",
        "kind": "fact", "category": "Communication",
        "title": "Never say \"I already told you\"",
        "teaser": "It is true, and it still does not help.",
        "body": (
            "The person is not doing it on purpose and cannot store the answer. "
            "Correcting them can cause shame and anger, and the shame may last long "
            "after the fact is forgotten. Answer calmly and move the conversation "
            "somewhere else, or give a written note they can keep and re-read."
        ),
        "tip": "Answer the question again, then redirect: \"Here's your tea - come help me fold this.\"",
        "icon": "🤝", "minutes": 1,
    },
    {
        "slug": "validate-feelings",
        "kind": "fact", "category": "Communication",
        "title": "Validate the feeling, not the fact",
        "teaser": "\"You miss your mother\" beats \"she died 20 years ago\".",
        "body": (
            "If someone believes a late parent is coming to fetch them, arguing "
            "with the facts causes fresh grief each time - and they will forget "
            "your correction but remember the distress. Join the feeling instead: "
            "\"You really miss her. Tell me about her.\" The emotion is real even "
            "when the fact is wrong. Validation reduces agitation faster than "
            "correction."
        ),
        "tip": "Name the feeling, then ask a gentle question about the memory.",
        "icon": "❤️", "minutes": 2,
    },
    {
        "slug": "choices-not-questions",
        "kind": "fact", "category": "Communication",
        "title": "Offer choices, not open questions",
        "teaser": "\"Tea or coffee?\" is easier than \"What do you want?\"",
        "body": (
            "Open questions demand memory and planning that dementia takes away. "
            "Two clear options keep control and dignity without overwhelming. Hold "
            "up the two items so the person can point. Avoid \"why\" questions. "
            "If both options are acceptable to you, the person keeps real control."
        ),
        "tip": "Limit to two options, and show them as well as naming them.",
        "icon": "☕", "minutes": 1,
    },
    {
        "slug": "sundowning",
        "kind": "fact", "category": "Behaviour",
        "title": "Sundowning: late-day restlessness",
        "teaser": "Confusion often worsens in the late afternoon and evening.",
        "body": (
            "Many people with dementia become more confused, restless or irritable "
            "as daylight fades. It is linked to body-clock changes, tiredness and "
            "low light. Bright morning light, an active day, fewer late naps and a "
            "calm, lit evening usually help. Caffeine and alcohol late in the day "
            "make it worse. So does a noisy or busy evening."
        ),
        "tip": "Close curtains and switch on lamps before dusk, and keep evenings quiet.",
        "icon": "🌇", "minutes": 2,
    },
    {
        "slug": "pain-looks-like-behaviour",
        "kind": "fact", "category": "Health",
        "title": "Pain often shows up as behaviour",
        "teaser": "Someone who cannot say \"it hurts\" may hit out or stop walking.",
        "body": (
            "Dementia can make it hard to report pain. Watch for new grimacing, "
            "guarding an arm, refusing to move, moaning, aggression or disturbed "
            "sleep. Treating pain early often settles the behaviour. Common "
            "sources: constipation, urine infection, arthritis, ill-fitting "
            "dentures, pressure sores, and shoes that no longer fit."
        ),
        "tip": "Ask the nurse to review pain relief before assuming the behaviour is \"just dementia\".",
        "icon": "🩹", "minutes": 2,
    },
    {
        "slug": "sudden-confusion-is-emergency",
        "kind": "fact", "category": "Health",
        "title": "Sudden confusion is a medical alarm",
        "teaser": "Hours-to-days change = think delirium, not dementia.",
        "body": (
            "Dementia changes slowly over years. A sudden drop over hours or days "
            "- more confused, drowsy, hallucinating or not recognising people - is "
            "delirium and needs urgent medical review. Common triggers are urine "
            "infections, chest infections, constipation, dehydration, pain and new "
            "medication. Delirium is usually reversible if the cause is found "
            "quickly."
        ),
        "tip": "Note when the change started and get a same-day medical review. It is treatable.",
        "icon": "🚨", "minutes": 2,
    },
    {
        "slug": "water-and-fibre",
        "kind": "fact", "category": "Health",
        "title": "Water and fibre prevent a lot of trouble",
        "teaser": "Dehydration and constipation both look like worsening dementia.",
        "body": (
            "Older adults often feel less thirsty. Too little fluid causes "
            "confusion, falls and infections; too little fibre causes constipation, "
            "which causes agitation and delirium. Offer small drinks through the "
            "day and include fruit, vegetables and whole grains. A simple target: "
            "pale yellow urine means enough fluid."
        ),
        "tip": "Offer a drink every time you offer food, and keep a jug within reach.",
        "icon": "💧", "minutes": 1,
    },
    {
        "slug": "sleep-and-daylight",
        "kind": "fact", "category": "Daily care",
        "title": "Daylight builds a better night",
        "teaser": "Morning light and movement set the body clock.",
        "body": (
            "Spending time outside or near a bright window in the morning helps "
            "night-time sleep. Long afternoon naps and late caffeine make nights "
            "worse. A short, safe walk most days improves mood, strength and sleep. "
            "Dim the lights and reduce noise an hour before bed."
        ),
        "tip": "Aim for 30 minutes outdoors before lunch, and avoid caffeine after 2 pm.",
        "icon": "☀️", "minutes": 1,
    },
    {
        "slug": "hearing-and-vision",
        "kind": "fact", "category": "Daily care",
        "title": "Check ears and eyes first",
        "teaser": "Untreated hearing loss can look exactly like confusion.",
        "body": (
            "If someone cannot hear the question, they cannot answer it. Wax "
            "build-up, a broken hearing aid or out-of-date glasses causes "
            "frustration that is easily mistaken for dementia. Have both checked "
            "and keep aids charged and clean. Clean glasses daily."
        ),
        "tip": "Before any conversation, make sure the hearing aid is on and the room is quiet.",
        "icon": "👓", "minutes": 1,
    },
    {
        "slug": "wandering",
        "kind": "fact", "category": "Safety",
        "title": "Wandering is not running away",
        "teaser": "The person is usually looking for something familiar.",
        "body": (
            "Up to 6 in 10 people with dementia will wander at some point. They "
            "may be looking for a former home, a late spouse, or the toilet. Locks "
            "out of sight, a door alarm, an ID bracelet and a recent photo greatly "
            "reduce the risk. Never restrain or shame someone for it. Wandering is "
            "often triggered by boredom, pain or a need to use the toilet."
        ),
        "tip": "Keep a current photo, a list of places they might go, and an ID card in their pocket.",
        "icon": "🚪", "minutes": 2,
    },
    {
        "slug": "music-and-memory",
        "kind": "fact", "category": "Connection",
        "title": "Music reaches parts words cannot",
        "teaser": "A familiar song can wake up a whole person.",
        "body": (
            "Musical memory often survives dementia. A song from the person's "
            "twenties can prompt singing, dancing and conversation when nothing "
            "else works. Choose music from their youth, keep the volume "
            "comfortable, and stop if it causes distress. Music can also reduce "
            "agitation and the need for medication."
        ),
        "tip": "Build a 20-minute playlist from their teenage years and play it at the same time daily.",
        "icon": "🎵", "minutes": 1,
    },
    {
        "slug": "dignity-in-personal-care",
        "kind": "fact", "category": "Daily care",
        "title": "Dignity during washing and dressing",
        "teaser": "Cover, explain, and let them do what they still can.",
        "body": (
            "Being undressed by a stranger is frightening when you cannot remember "
            "why. Explain each step, keep a towel over the body, warm the room, and "
            "let the person hold the flannel or choose the shirt. Do the hard "
            "parts quickly and quietly. Preserve choice wherever possible."
        ),
        "tip": "Lay clothes out in the order they go on, and give one item at a time.",
        "icon": "🧼", "minutes": 2,
    },
    {
        "slug": "eating-and-swallowing",
        "kind": "fact", "category": "Health",
        "title": "Mealtimes: slower, smaller, upright",
        "teaser": "Choking risk rises when eating is rushed.",
        "body": (
            "Sit upright, at eye level, with no television. Small bites, soft "
            "moist food and a spoon between bites reduce choking risk. Check that "
            "dentures fit and that the person is awake enough to eat. Never rush "
            "or force food. A speech therapist can advise on thickened fluids if "
            "swallowing is unsafe."
        ),
        "tip": "Sit down to eat with the person - eating together slows the pace naturally.",
        "icon": "🍽️", "minutes": 2,
    },
    {
        "slug": "medication-safety",
        "kind": "fact", "category": "Health",
        "title": "Medication: same time, same dose, no guessing",
        "teaser": "Doubling a dose is a common and dangerous mistake.",
        "body": (
            "Use a weekly pill organiser and tick off each dose. Never adjust a "
            "dose yourself, and never give someone else's medicine. Keep a single "
            "up-to-date list of everything taken, including over-the-counter pills "
            "and traditional medicine, for every doctor visit. Sedatives and "
            "sleeping pills raise fall and confusion risk in older adults."
        ),
        "tip": "Keep one medicine list on the fridge and update it after every prescription.",
        "icon": "💊", "minutes": 2,
    },
    {
        "slug": "driving-judgement",
        "kind": "fact", "category": "Safety",
        "title": "Driving is a judgement question",
        "teaser": "Getting lost on a known route is a warning sign.",
        "body": (
            "Dementia slows reaction time and affects judgement, which is "
            "dangerous behind the wheel. Warning signs include getting lost on "
            "familiar roads, near-misses and confusing pedals. A doctor or driving "
            "assessment can advise. Plan alternatives early, while the person can "
            "still agree. Raising it early preserves dignity."
        ),
        "tip": "Raise driving early and gently, and offer a lift rather than an argument.",
        "icon": "🚗", "minutes": 2,
    },
    {
        "slug": "money-and-scams",
        "kind": "fact", "category": "Safety",
        "title": "Money and scams",
        "teaser": "Dementia makes people trusting and repetitively generous.",
        "body": (
            "Reduced judgement makes someone an easy target for phone scams, "
            "door-to-door sellers and repeated donations. Watch for unusual "
            "withdrawals, new \"friends\", or gifts to strangers. Reduce risk with "
            "bank alerts and limits, while preserving as much independence as "
            "possible. Consider a second signature for large transactions."
        ),
        "tip": "Set bank notifications for large withdrawals and keep cash at home small.",
        "icon": "🏦", "minutes": 2,
    },
    {
        "slug": "carer-burnout",
        "kind": "fact", "category": "You, the carer",
        "title": "Carer burnout is real, and it is not weakness",
        "teaser": "You cannot pour from an empty cup.",
        "body": (
            "Caring is physically and emotionally exhausting. Warning signs "
            "include constant irritability, poor sleep, hopelessness and getting "
            "sick often. Take breaks, accept help, keep your own doctor's "
            "appointments, and tell someone when you are struggling. A burnt-out "
            "carer cannot care well - looking after yourself is part of the job."
        ),
        "tip": "Book one real break this week - not a chore, a break.",
        "icon": "🫂", "minutes": 2,
    },
    {
        "slug": "capacity-and-consent",
        "kind": "fact", "category": "Rights and law (SA)",
        "title": "Capacity and consent in South Africa",
        "teaser": "Assume capacity unless there is good reason not to.",
        "body": (
            "In South African law an adult is presumed to have capacity. Capacity "
            "is decision-specific: someone may manage their money but not consent "
            "to surgery. A person can only be treated without consent when they "
            "lack capacity and the law's substitute-decision rules apply. "
            "Document what was explained and how the person responded."
        ),
        "tip": "Explain in plain words, check understanding, and write down the decision and date.",
        "icon": "⚖️", "minutes": 2,
    },
    {
        "slug": "advance-directive",
        "kind": "fact", "category": "Rights and law (SA)",
        "title": "Advance directives and living wills",
        "teaser": "Write wishes down while they can still be discussed.",
        "body": (
            "Under the National Health Act 61 of 2003, an advance directive lets "
            "a person record treatment wishes for a time when they cannot speak "
            "for themselves. It should be discussed with family and the doctor, "
            "signed, dated and kept where carers can find it. It is not the same "
            "as euthanasia - it records wishes about treatment."
        ),
        "tip": "Keep a signed copy with the patient file and give one to the GP.",
        "icon": "📝", "minutes": 2,
    },
    {
        "slug": "curator-bonis",
        "kind": "fact", "category": "Rights and law (SA)",
        "title": "When money can no longer be managed",
        "teaser": "South Africa has no enduring power of attorney.",
        "body": (
            "If someone can no longer manage their finances, a family member can "
            "apply to the Master of the High Court for a curator bonis to manage "
            "the estate under supervision. It is a formal court process, so start "
            "early and keep clear records. A simpler first step is a joint bank "
            "account or a mandate, set up while capacity remains."
        ),
        "tip": "Speak to a lawyer before money runs into trouble - it is much harder after.",
        "icon": "🏛️", "minutes": 2,
    },
    {
        "slug": "older-persons-act",
        "kind": "fact", "category": "Rights and law (SA)",
        "title": "Abuse of older people is a crime",
        "teaser": "The Older Persons Act protects dignity and safety.",
        "body": (
            "The Older Persons Act 13 of 2006 protects older people from abuse, "
            "neglect and exploitation - including financial abuse and being "
            "locked away. If you suspect abuse, report it to the police (10111) "
            "and to the Department of Social Development. You do not need proof to "
            "raise a concern. Abuse includes shouting, withholding food or "
            "medicine, and stealing pension money."
        ),
        "tip": "Record dates, what you saw and who you told. A written timeline protects the person.",
        "icon": "🛡️", "minutes": 2,
    },
]

# Emergency cards and quizzes are unchanged from the original (already detailed).
# Re-import them from the previous content by keeping the same slugs; seed_cards
# upserts, so re-running is safe. We re-define them here for a single source.

CARDS += [
    # ---- EMERGENCIES (dementia) ----
    {
        "slug": "choking-conscious",
        "kind": "emergency", "category": "Airway",
        "title": "Choking: person is conscious",
        "teaser": "Cough it out, then 5 back blows and 5 abdominal thrusts.",
        "body": (
            "If they can cough or speak, encourage coughing and stay with them. "
            "If the cough is silent or they cannot breathe, act at once: 5 firm "
            "back blows between the shoulder blades, then 5 abdominal thrusts. "
            "Alternate until the object comes out or help arrives. Do not give "
            "water or hit the back randomly."
        ),
        "steps": [
            "Ask loudly: \"Are you choking?\" If they can cough, encourage coughing.",
            "If they cannot breathe or speak, call 112 or 10177 and put the phone on speaker.",
            "Lean them forward and give 5 firm back blows between the shoulder blades with the heel of your hand.",
            "If that fails, give 5 abdominal thrusts: stand behind, fist just above the navel, pull sharply inward and upward.",
            "Alternate 5 back blows and 5 abdominal thrusts until the object clears.",
            "If they become unconscious, lower them to the floor and start CPR.",
            "Anyone who received abdominal thrusts must be checked by a doctor afterwards.",
        ],
        "call": "Call 112 (cellphone) or 10177 now if they cannot breathe.",
        "icon": "🫁", "minutes": 3,
    },
    {
        "slug": "choking-unconscious",
        "kind": "emergency", "category": "Airway",
        "title": "Choking: person is unconscious",
        "teaser": "Start CPR. Do not waste time looking in the mouth.",
        "body": (
            "Lower them gently to the floor, call for help and start chest "
            "compressions. A blind finger sweep can push the object deeper. "
            "Compressions often force the object out. Continue until the person "
            "breathes normally or medics take over."
        ),
        "steps": [
            "Shout for help and call 112 or 10177 on speaker.",
            "Lay the person on their back on a firm, flat surface.",
            "Place the heel of one hand in the centre of the chest, the other on top, fingers linked.",
            "Push hard and fast: about 5-6 cm deep, 100-120 times a minute.",
            "Give 30 compressions, then 2 rescue breaths if you are trained and willing.",
            "Check the mouth only if you can clearly see the object - never do a blind finger sweep.",
            "Keep going until the person breathes, or the ambulance crew takes over.",
        ],
        "call": "Call 112 or 10177 and start CPR immediately.",
        "icon": "🫀", "minutes": 3,
    },
    {
        "slug": "cardiac-arrest",
        "kind": "emergency", "category": "Heart",
        "title": "Not breathing or no pulse: CPR",
        "teaser": "Push hard and fast in the centre of the chest.",
        "body": (
            "If the person is unresponsive and not breathing normally, start CPR "
            "at once. Chest compressions keep blood moving to the brain. Do not "
            "wait for the ambulance to arrive before you start. Hands-only CPR is "
            "acceptable if you are not trained."
        ),
        "steps": [
            "Check for a response and normal breathing for no more than 10 seconds.",
            "Call 112 or 10177 on speaker, or ask someone else to call.",
            "Place the person on their back on a firm surface.",
            "Push hard and fast in the centre of the chest: 5-6 cm deep, 100-120 per minute.",
            "If trained: 30 compressions, then 2 rescue breaths. If not: keep doing compressions only.",
            "Swap with another person every 2 minutes if you can - it is tiring.",
            "Continue until the person breathes normally or medics take over. Use an AED if one is available and follow its voice prompts.",
        ],
        "call": "Call 112 or 10177 now.",
        "icon": "❤️‍🔥", "minutes": 3,
    },
    {
        "slug": "stroke-fast",
        "kind": "emergency", "category": "Brain",
        "title": "Stroke: think FAST",
        "teaser": "Face, Arms, Speech, Time. Every minute matters.",
        "body": (
            "A stroke happens when blood flow to part of the brain is blocked or "
            "bleeds. Treatment works best within about 4.5 hours, so speed is "
            "everything. Use FAST: Face drooping, Arm weakness, Speech slurred, "
            "Time to call. Note the exact time symptoms started."
        ),
        "steps": [
            "Face: ask the person to smile. Does one side droop?",
            "Arms: ask them to lift both arms. Does one drift down?",
            "Speech: ask them to repeat a simple sentence. Is it slurred or muddled?",
            "Time: note the exact time symptoms started, or when you last saw them well.",
            "Call 112 or 10177 immediately and say \"possible stroke\".",
            "Do not give food, drink or aspirin - the person may choke or it may be a bleed.",
            "Lie them on their side if unconscious, keep them warm, and stay with them.",
        ],
        "call": "Call 112 or 10177 and say \"possible stroke\".",
        "icon": "🧠", "minutes": 3,
    },
    {
        "slug": "severe-bleeding",
        "kind": "emergency", "category": "Injury",
        "title": "Severe bleeding",
        "teaser": "Press hard, keep pressing, do not peek.",
        "body": (
            "Firm direct pressure stops most bleeding. Use a clean cloth or "
            "dressing and press continuously for at least 10 minutes. Do not lift "
            "the cloth to check. If blood soaks through, add another layer on top. "
            "Watch for shock: pale, cold, sweaty, confused."
        ),
        "steps": [
            "Call 112 or 10177 for heavy or spurting bleeding.",
            "Press firmly on the wound with a clean cloth or dressing.",
            "Keep continuous pressure for at least 10 minutes - do not peek.",
            "If blood soaks through, add more cloth on top; do not remove the first layer.",
            "Raise the injured limb above heart level if you can.",
            "Lay the person down, keep them warm, and watch for shock (pale, cold, sweaty, confused).",
            "Do not remove an object stuck in the wound - press around it.",
        ],
        "call": "Call 112 or 10177 for spurting or uncontrolled bleeding.",
        "icon": "🩸", "minutes": 2,
    },
    {
        "slug": "fall-hip-injury",
        "kind": "emergency", "category": "Injury",
        "title": "Fall: do not rush to lift them",
        "teaser": "One leg turned out and shorter? Suspect a hip fracture.",
        "body": (
            "Lifting someone with a broken hip can cause severe damage. If the leg "
            "looks shortened or turned outward, or they cannot bear weight, keep "
            "them still and call an ambulance. Keep them warm and calm until help "
            "arrives. Do not give food or drink in case surgery is needed."
        ),
        "steps": [
            "Do not move the person. Kneel beside them and reassure them.",
            "Ask what hurts and check for bleeding, head injury and confusion.",
            "If a hip or leg fracture is possible, keep the leg supported in the position found.",
            "Call 112 or 10177 and describe the fall and the injury.",
            "Cover them with a blanket to prevent shock, and keep talking calmly.",
            "Do not give food or drink in case surgery is needed.",
            "If they are unhurt and can get up safely, help them to a chair slowly - but check for injury first.",
        ],
        "call": "Call 112 or 10177 for a suspected hip or leg fracture.",
        "icon": "🦴", "minutes": 2,
    },
    {
        "slug": "head-injury",
        "kind": "emergency", "category": "Injury",
        "title": "Head injury: watch for the warning signs",
        "teaser": "On blood thinners, any head knock needs a doctor.",
        "body": (
            "A bump on the head can bleed inside the skull. Warning signs include "
            "vomiting, worsening headache, drowsiness, confusion, unequal pupils, "
            "seizure or clear fluid from the nose or ear. Someone on warfarin or "
            "other blood thinners must be checked even if they seem fine."
        ),
        "steps": [
            "Call 112 or 10177 if the person was knocked out, is drowsy, vomiting or confused.",
            "Keep them still and apply gentle pressure to any scalp bleeding.",
            "Do not remove a helmet or an object stuck in the head.",
            "Watch their breathing and level of alertness constantly.",
            "If they become unconscious, place them in the recovery position and monitor breathing.",
            "Even if they seem well, arrange a same-day doctor review if they take blood thinners.",
        ],
        "call": "Call 112 or 10177 for drowsiness, vomiting or confusion after a head knock.",
        "icon": "🤕", "minutes": 2,
    },
    {
        "slug": "seizure",
        "kind": "emergency", "category": "Brain",
        "title": "Seizure: protect, time it, do not restrain",
        "teaser": "Nothing goes in the mouth. Ever.",
        "body": (
            "During a seizure the person cannot swallow their tongue, so never put "
            "anything in their mouth. Move dangerous objects away, cushion the "
            "head and time the seizure. Most stop within 2 minutes. Call an "
            "ambulance if it lasts over 5 minutes, repeats, or the person is "
            "injured or not waking up."
        ),
        "steps": [
            "Stay calm and time the seizure from the start.",
            "Move furniture and sharp objects away; do not restrain the person.",
            "Place something soft under their head.",
            "Do not put anything in their mouth, including fingers or a spoon.",
            "Loosen tight clothing around the neck.",
            "When the shaking stops, roll them into the recovery position and check breathing.",
            "Call 112 or 10177 if it lasts more than 5 minutes, happens again, or they do not wake up.",
        ],
        "call": "Call 112 or 10177 if the seizure lasts over 5 minutes or repeats.",
        "icon": "⚡", "minutes": 2,
    },
    {
        "slug": "burns",
        "kind": "emergency", "category": "Injury",
        "title": "Burns: cool for 20 minutes",
        "teaser": "Cool running water. No ice, butter or toothpaste.",
        "body": (
            "Cool the burn under cool running water for a full 20 minutes - this "
            "limits damage and pain. Remove rings and watches before swelling. "
            "Cover with cling film or a clean non-stick dressing. Never use ice, "
            "butter, oil or toothpaste."
        ),
        "steps": [
            "Stop the burning: remove the person from the source and put out flames.",
            "Cool the burn under cool running water for 20 minutes.",
            "Remove rings, watches and tight clothing near the burn before it swells.",
            "Do not burst blisters and do not apply ice, butter, oil or toothpaste.",
            "Cover loosely with cling film or a clean non-stick dressing.",
            "Call 112 or 10177 for burns bigger than the person's palm, or any burn on the face, hands, feet, genitals or airway.",
            "Keep the person warm - cooling a large burn can make them dangerously cold.",
        ],
        "call": "Call 112 or 10177 for large, deep, facial or airway burns.",
        "icon": "🔥", "minutes": 2,
    },
    {
        "slug": "poisoning",
        "kind": "emergency", "category": "Poisoning",
        "title": "Poisoning or the wrong medicine",
        "teaser": "Do not make them vomit. Call the poisons line.",
        "body": (
            "Dementia raises the risk of double doses and swallowing the wrong "
            "thing. Do not induce vomiting. Call the 24-hour Poisons Information "
            "Helpline on 0861 555 777 or 112, and keep the container or medicine "
            "box to read out."
        ),
        "steps": [
            "Move the person away from the substance and check they are breathing.",
            "Do not make them vomit.",
            "Call 0861 555 777 (poisons) or 112 for advice.",
            "Keep the container, packet or medicine box to read the label to the adviser.",
            "Note roughly how much was taken and when.",
            "If they become drowsy or unconscious, place them in the recovery position and call 112.",
            "Take the container with you to the hospital.",
        ],
        "call": "Call 0861 555 777 (poisons) or 112.",
        "icon": "☠️", "minutes": 2,
    },
    {
        "slug": "fire-evacuation",
        "kind": "emergency", "category": "Fire",
        "title": "Fire: get out, stay out",
        "teaser": "Close doors behind you and never go back in.",
        "body": (
            "Smoke kills faster than flames. Get everyone out, stay low under "
            "smoke, and close doors behind you to slow the fire. Call 10177 once "
            "you are outside. Never go back inside for belongings."
        ),
        "steps": [
            "Raise the alarm and get everyone moving towards the nearest safe exit.",
            "Stay low under smoke and cover the nose and mouth with a cloth.",
            "Close doors behind you to slow the spread.",
            "Do not use lifts. Help anyone who needs support, but do not delay the group.",
            "Get to the meeting point and count everyone.",
            "Call 10177 from outside.",
            "Never go back inside. Tell the fire service if someone is missing.",
        ],
        "call": "Call 10177 once you are safely outside.",
        "icon": "🚒", "minutes": 2,
    },
    {
        "slug": "aggression-towards-carer",
        "kind": "emergency", "category": "Behaviour",
        "title": "When anger turns physical",
        "teaser": "Create space, lower your voice, leave the room.",
        "body": (
            "Aggression is usually fear or pain, not hatred. Do not argue, corner "
            "or restrain the person. Give space, keep your voice low and slow, and "
            "remove anything that could be thrown. If you are in danger, leave the "
            "room and call for another carer."
        ),
        "steps": [
            "Stop what you are doing and step back to give at least two arm-lengths of space.",
            "Keep your voice low, slow and calm. Do not argue or correct.",
            "Move away from the doorway so the person does not feel trapped.",
            "Remove or secure anything that could be thrown or used to hit.",
            "If the person calms, offer a simple choice and redirect to a safe activity.",
            "If you are in danger, leave the room and call another carer or 10111.",
            "Afterwards, look for the cause: pain, fear, noise, a wet pad or an infection.",
        ],
        "call": "Call 10111 if someone is in immediate danger.",
        "icon": "🛑", "minutes": 2,
    },
    {
        "slug": "missing-person",
        "kind": "emergency", "category": "Safety",
        "title": "Missing: the first 30 minutes matter",
        "teaser": "Search the obvious places, then call the police.",
        "body": (
            "People with dementia often head for a former home, a shop or a bus "
            "stop. Search the house and garden first, then the immediate street. "
            "Report to the police immediately - there is no waiting period in "
            "South Africa - and share a recent photo."
        ),
        "steps": [
            "Check every room, cupboard, garden, garage and outbuilding.",
            "Check nearby streets and the places the person used to live, work or shop.",
            "Call the police on 10111 immediately - do not wait 24 hours.",
            "Give a recent photo, what they were wearing and any medical conditions.",
            "Ask neighbours to watch the street and check CCTV if available.",
            "Keep one person at home in case they return.",
            "When found, check for injury, dehydration and cold before anything else.",
        ],
        "call": "Call 10111 immediately - there is no waiting period.",
        "icon": "🔎", "minutes": 2,
    },
    {
        "slug": "pressure-injury",
        "kind": "emergency", "category": "Skin",
        "title": "Bed sores: catch them early",
        "teaser": "A red patch that does not fade is stage one damage.",
        "body": (
            "Pressure injuries form where bone presses on skin: heels, hips, base "
            "of spine, shoulders and ears. A red or purple patch that does not turn "
            "white when pressed is early damage. Do not rub or massage it - report "
            "it to the nurse the same day. Prevention: reposition every 2 hours."
        ),
        "steps": [
            "Check the whole body daily: heels, hips, tailbone, shoulders, ears and elbows.",
            "Press gently on a red patch. If it stays red, it is early pressure damage.",
            "Do not rub, massage or use a doughnut cushion.",
            "Reposition every 2 hours in bed and every hour in a chair.",
            "Keep skin clean and dry; change wet pads promptly.",
            "Report to the nurse or doctor the same day, and photograph the area with the date.",
            "If the skin is broken, oozing or black, treat it as urgent.",
        ],
        "call": "Same-day nurse review. Urgent if skin is broken or black.",
        "icon": "🩹", "minutes": 2,
    },
    {
        "slug": "chest-pain",
        "kind": "emergency", "category": "Heart",
        "title": "Chest pain: sit, rest, call",
        "teaser": "Crushing pain, sweating and nausea = emergency.",
        "body": (
            "Chest pain spreading to the arm, jaw or back, with sweating, nausea "
            "or breathlessness, may be a heart attack. Sit the person down, keep "
            "them calm and call an ambulance. Do not let them walk or drive."
        ),
        "steps": [
            "Sit the person down and keep them calm.",
            "Call 112 or 10177 and say \"possible heart attack\".",
            "Loosen tight clothing and keep them warm.",
            "Do not let them walk, climb stairs or drive.",
            "Only give aspirin if the emergency dispatcher tells you to, and they are not allergic.",
            "If they become unresponsive and stop breathing normally, start CPR.",
            "Unlock the door so the crew can get in.",
        ],
        "call": "Call 112 or 10177 immediately.",
        "icon": "💔", "minutes": 2,
    },
    {
        "slug": "low-blood-sugar",
        "kind": "emergency", "category": "Diabetes",
        "title": "Low blood sugar (hypo)",
        "teaser": "Shaky, sweaty and confused? Give sugar fast.",
        "body": (
            "A hypo can look like sudden confusion, sweating, shaking or "
            "aggression. If the person is awake and can swallow, give 15 g of "
            "fast sugar, wait 15 minutes and recheck. If they cannot swallow or "
            "become unconscious, give nothing by mouth and call an ambulance."
        ),
        "steps": [
            "If awake and able to swallow: give 15 g of fast sugar - half a glass of juice, 3 teaspoons of sugar, or glucose tablets.",
            "Wait 15 minutes and check again. Repeat if still low.",
            "Once normal, give a snack with slow-release carbohydrate, like bread.",
            "If they cannot swallow, are fitting or unconscious: give nothing by mouth.",
            "Place them in the recovery position and call 112 or 10177.",
            "Use a glucagon injection only if prescribed and you have been trained.",
            "Watch for a second drop over the next hour.",
        ],
        "call": "Call 112 or 10177 if they cannot swallow or are unconscious.",
        "icon": "🍬", "minutes": 2,
    },
    {
        "slug": "allergic-reaction",
        "kind": "emergency", "category": "Allergy",
        "title": "Allergic reaction and anaphylaxis",
        "teaser": "Swollen lips or noisy breathing = use adrenaline, call now.",
        "body": (
            "Mild reactions cause a rash or itching. Anaphylaxis is different: "
            "swollen lips or tongue, noisy breathing, hoarse voice, collapse. Use "
            "the prescribed adrenaline auto-injector immediately into the outer "
            "thigh and call an ambulance."
        ),
        "steps": [
            "Look for swelling of lips, tongue or throat, noisy breathing, or collapse.",
            "Use the adrenaline auto-injector into the outer thigh - it can go through clothing.",
            "Call 112 or 10177 immediately and say \"anaphylaxis\".",
            "Lay the person flat with legs raised. Do not let them stand or walk.",
            "If breathing is difficult, let them sit up rather than lie flat.",
            "A second dose can be given after 5 minutes if there is no improvement and it is prescribed.",
            "The person must go to hospital even if they improve - reactions can return.",
        ],
        "call": "Call 112 or 10177 immediately.",
        "icon": "🐝", "minutes": 2,
    },
    {
        "slug": "heat-stroke",
        "kind": "emergency", "category": "Heat",
        "title": "Heat stroke",
        "teaser": "Hot, dry and confused is an emergency.",
        "body": (
            "Heat stroke is a body temperature over about 40 C with confusion, "
            "hot dry skin or collapse. It is life-threatening. Move the person "
            "out of the heat, cool them actively with water and fanning, and call "
            "an ambulance."
        ),
        "steps": [
            "Move the person to shade or a cool room immediately.",
            "Call 112 or 10177 - heat stroke is life-threatening.",
            "Remove unnecessary clothing.",
            "Cool actively: wet the skin with cool water and fan it. Place cool packs at the neck, armpits and groin.",
            "Do not use ice-cold water or alcohol rubs.",
            "Give small sips of water only if fully awake and alert.",
            "If they become drowsy, place them in the recovery position and monitor breathing.",
        ],
        "call": "Call 112 or 10177 immediately.",
        "icon": "🌡️", "minutes": 2,
    },
    {
        "slug": "power-failure",
        "kind": "emergency", "category": "Home safety",
        "title": "Power failure with medical equipment",
        "teaser": "Plan the backup before the lights go out.",
        "body": (
            "Oxygen concentrators, alternating-pressure mattresses and medicine "
            "fridges need power. Know which equipment has a battery, how long it "
            "lasts, and who to call. Keep torches, a charged power bank and a "
            "printed emergency list where you can find them in the dark."
        ),
        "steps": [
            "Check which equipment has a battery backup and how many hours it lasts.",
            "Switch the person to battery equipment if needed.",
            "Call the supplier or the local clinic for urgent equipment support.",
            "Keep the medicine fridge closed - it holds temperature for several hours.",
            "Use torches, not candles, near oxygen and around a confused person.",
            "Check on the person every 30 minutes and keep them warm.",
            "If life-support equipment fails, call 112 or 10177 and say it is a life-support emergency.",
        ],
        "call": "Call 112 or 10177 if life-support equipment fails.",
        "icon": "🔌", "minutes": 2,
    },
    {
        "slug": "dehydration",
        "kind": "emergency", "category": "Heat",
        "title": "Dehydration",
        "teaser": "Dark urine and new confusion are early warnings.",
        "body": (
            "Signs include a dry mouth, dark strong-smelling urine, sunken eyes, "
            "dizziness on standing and new confusion. Offer small sips of water "
            "often. If the person cannot drink, is very drowsy or stops passing "
            "urine, get medical help."
        ),
        "steps": [
            "Offer small sips of water every 10-15 minutes.",
            "Check urine colour - pale yellow is normal, dark amber is a warning.",
            "Cool the person and move them out of the heat.",
            "If they are vomiting or cannot keep fluid down, call 112 or 10177.",
            "If they are drowsy or confused, treat it as urgent.",
            "Do not force large amounts at once - it can cause vomiting.",
            "Watch for reduced urine output over 8 hours.",
        ],
        "call": "Call 112 or 10177 if they cannot drink or become drowsy.",
        "icon": "🥤", "minutes": 2,
    },
    {
        "slug": "electric-shock",
        "kind": "emergency", "category": "Home safety",
        "title": "Electric shock",
        "teaser": "Switch off the power before you touch anyone.",
        "body": (
            "Never touch a person who is still in contact with electricity. Switch "
            "off the mains or use a dry wooden object to move the source away. "
            "Then check breathing and start CPR if needed."
        ),
        "steps": [
            "Do not touch the person while they are in contact with the electrical source.",
            "Switch off the mains at the distribution board if you can reach it safely.",
            "Otherwise move the source with a dry wooden broom handle or similar.",
            "Call 112 or 10177.",
            "Check breathing and responsiveness. Start CPR if not breathing normally.",
            "Cool any burns with running water for 20 minutes.",
            "Everyone who has had an electric shock should be checked by a doctor, even if they feel fine.",
        ],
        "call": "Call 112 or 10177 after the power is off.",
        "icon": "⚡", "minutes": 2,
    },
]

QUIZZES = [
    {
        "slug": "q-what-is-dementia",
        "question": "What is dementia?",
        "options": [
            "A normal part of getting old",
            "A group of symptoms caused by brain damage",
            "A single disease called Alzheimer's",
            "A temporary reaction to stress",
        ],
        "correct": 1,
        "explanation": "Dementia is an umbrella term for symptoms. Alzheimer's is the most common cause, but not the only one.",
        "icon": "🧠",
    },
    {
        "slug": "q-sudden-confusion",
        "question": "Ouma is her usual self, then over one day becomes much more confused and drowsy. What is the most important next step?",
        "options": [
            "Assume the dementia has moved to the next stage",
            "Give her an extra sleeping tablet",
            "Get a same-day medical review - this may be delirium",
            "Wait a week and see if it settles",
        ],
        "correct": 2,
        "explanation": "A change over hours or days is delirium, not the slow course of dementia. Infection, dehydration, constipation and medication are common, treatable causes.",
        "icon": "🚨",
    },
    {
        "slug": "q-choking",
        "question": "An adult is choking and cannot breathe or speak. What do you do first?",
        "options": [
            "Give water to wash it down",
            "Put your fingers down the throat",
            "Give 5 back blows between the shoulder blades",
            "Lay them down and wait for the ambulance",
        ],
        "correct": 2,
        "explanation": "Call for help, then 5 firm back blows, then 5 abdominal thrusts, alternating. Water or blind finger sweeps can make it worse.",
        "icon": "🫁",
    },
    {
        "slug": "q-stroke",
        "question": "What does the FAST test stand for?",
        "options": [
            "Face, Arms, Speech, Time",
            "Fever, Aches, Sweating, Tiredness",
            "Falls, Anxiety, Shock, Temperature",
            "Food, Air, Sleep, Touch",
        ],
        "correct": 0,
        "explanation": "Face drooping, Arm weakness, Speech slurred, Time to call. Note the exact time symptoms started - treatment is time-critical.",
        "icon": "🧠",
    },
    {
        "slug": "q-bed-sores",
        "question": "You notice a red patch on the heel that stays red when you press it. What should you do?",
        "options": [
            "Massage it firmly to get the blood moving",
            "Ignore it - red skin is normal",
            "Report it to the nurse the same day and keep pressure off it",
            "Put a hot water bottle on it",
        ],
        "correct": 2,
        "explanation": "A red patch that does not fade is early pressure damage. Never massage it. Reposition regularly and get a same-day nurse review.",
        "icon": "🩹",
    },
    {
        "slug": "q-sundowning",
        "question": "Sundowning is best described as:",
        "options": [
            "Confusion that gets worse in the late afternoon and evening",
            "A fear of the dark",
            "A side effect of sleeping pills only",
            "A sign that the person is dying",
        ],
        "correct": 0,
        "explanation": "Sundowning is late-day restlessness and confusion. Bright mornings, a structured day, fewer late naps and a calm lit evening help.",
        "icon": "🌇",
    },
    {
        "slug": "q-never-argue",
        "question": "Mom asks for her late husband for the fifth time today. What is the best response?",
        "options": [
            "\"I already told you, he died years ago.\"",
            "\"You miss him, don't you? Tell me about him.\"",
            "Ignore her until she stops",
            "Tell her he is at work so she stops asking",
        ],
        "correct": 1,
        "explanation": "Validate the feeling rather than the fact. Repeated corrections cause fresh grief each time. A gentle question redirects to a comforting memory.",
        "icon": "❤️",
    },
    {
        "slug": "q-pain",
        "question": "A person with dementia who cannot explain themselves suddenly refuses to be moved and cries out. What should you check first?",
        "options": [
            "Whether they are being naughty",
            "Whether they are in pain",
            "Whether the television is on the right channel",
            "Whether they want a new hairstyle",
        ],
        "correct": 1,
        "explanation": "New resistance to movement or crying out is often pain. Look for a cause and ask the nurse to review pain relief before assuming it is behaviour.",
        "icon": "🩹",
    },
    {
        "slug": "q-seizure",
        "question": "Someone is having a seizure. What must you never do?",
        "options": [
            "Cushion their head",
            "Time the seizure",
            "Put something in their mouth",
            "Move dangerous objects away",
        ],
        "correct": 2,
        "explanation": "Never put anything in the mouth - people cannot swallow their tongue. Cushion the head, clear the area, time it and call if it lasts over 5 minutes.",
        "icon": "⚡",
    },
    {
        "slug": "q-hypo",
        "question": "A diabetic is shaky, sweaty and confused but awake and able to swallow. What do you give?",
        "options": [
            "Nothing - wait for the doctor",
            "15 g of fast sugar, like half a glass of juice",
            "A cup of coffee with no sugar",
            "A large meal immediately",
        ],
        "correct": 1,
        "explanation": "Give fast sugar, wait 15 minutes and recheck. If they cannot swallow or become unconscious, give nothing by mouth and call an ambulance.",
        "icon": "🍬",
    },
    {
        "slug": "q-burns",
        "question": "What is the correct first aid for a burn?",
        "options": [
            "Butter and a bandage",
            "Ice directly on the skin",
            "Cool running water for 20 minutes",
            "Toothpaste to stop the stinging",
        ],
        "correct": 2,
        "explanation": "Cool running water for a full 20 minutes. Never use ice, butter, oil or toothpaste. Cover with cling film or a clean non-stick dressing.",
        "icon": "🔥",
    },
    {
        "slug": "q-carer",
        "question": "Which is a real warning sign of carer burnout?",
        "options": [
            "Feeling constantly irritable and hopeless",
            "Enjoying a quiet cup of tea",
            "Asking family for help",
            "Sleeping well",
        ],
        "correct": 0,
        "explanation": "Constant irritability, hopelessness, poor sleep and getting sick often are warning signs. Burnout is not weakness - book a real break and accept help.",
        "icon": "🫂",
    },
    {
        "slug": "q-emergency-number",
        "question": "Which number reaches an ambulance from any South African cellphone, even with no airtime?",
        "options": ["10111", "112", "10177", "0861 555 777"],
        "correct": 1,
        "explanation": "112 works from any cellphone, even without airtime. 10177 is the landline ambulance number and 10111 is the police.",
        "icon": "📞",
    },
    {
        "slug": "q-poison",
        "question": "Someone may have swallowed the wrong medicine. What should you NOT do?",
        "options": [
            "Call the poisons helpline",
            "Keep the medicine box",
            "Make them vomit",
            "Note how much was taken",
        ],
        "correct": 2,
        "explanation": "Never make someone vomit. Call 0861 555 777 or 112, keep the container, and note what and when.",
        "icon": "☠️",
    },
]
