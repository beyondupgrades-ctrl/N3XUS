"""VOIC3 Section 15 — LiveKit SFU join tokens, end-to-end encryption keys and
self-hosted transcription.

Everything here is optional and additive. With no LiveKit server configured the
app keeps using the existing peer-to-peer WebRTC path unchanged; with no
transcription backend it returns a clear 503 instead of failing a recording.

LiveKit is Apache-2.0 and self-hosted (``livekit-server`` container, no paid
plan needed). Its access token is an HS256 JWT signed with the server's API
secret — built here with the standard library, so no extra dependency.

E2EE is WebRTC's own insertable-streams SFrame layer (``RTCRtpScriptTransform``
in the browser). The server only ever issues a shared key to participants it has
already admitted, so it is never an endpoint of the encrypted media.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration (all optional)
# ---------------------------------------------------------------------------
DEFAULT_LIVEKIT_URL = ""          # e.g. ws://127.0.0.1:7880
DEFAULT_WHISPER_MODEL = "base"    # faster-whisper model size; "base" runs on CPU


def _env(name, default=""):
    try:
        return (os.environ.get(name) or default).strip()
    except Exception:
        return default


def livekit_url():
    """WebSocket URL of the SFU, or '' when SFU mode is off."""
    return _env("VOIC3_LIVEKIT_URL", DEFAULT_LIVEKIT_URL)


def livekit_configured():
    return bool(livekit_url() and _env("VOIC3_LIVEKIT_API_KEY") and _env("VOIC3_LIVEKIT_API_SECRET"))


def livekit_enabled():
    """SFU is used only when it is configured *and* the operator opted in."""
    return livekit_configured() and _env("VOIC3_SFU_MODE", "auto").lower() != "off"


def e2ee_enabled():
    return _env("VOIC3_E2EE", "on").lower() not in ("0", "off", "false", "no")


def whisper_backend():
    """Which local transcription engine is available: 'faster-whisper', 'whisper' or ''."""
    try:
        import importlib.util
        if importlib.util.find_spec("faster_whisper"):
            return "faster-whisper"
        if importlib.util.find_spec("whisper"):
            return "whisper"
    except Exception:
        pass
    return ""


def transcription_available():
    return bool(whisper_backend())


def capabilities():
    """What the client should use. Safe to call on every bootstrap."""
    return {
        "sfu": {"enabled": livekit_enabled(), "url": livekit_url() if livekit_enabled() else ""},
        "e2ee": {"enabled": e2ee_enabled()},
        "transcription": {"enabled": transcription_available(),
                          "engine": whisper_backend(),
                          "model": _env("VOIC3_WHISPER_MODEL", DEFAULT_WHISPER_MODEL)},
    }


# ---------------------------------------------------------------------------
# LiveKit access token (HS256 JWT)
# ---------------------------------------------------------------------------
def _b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _jwt(payload, secret):
    header = {"alg": "HS256", "typ": "JWT"}
    signing_input = (_b64url(json.dumps(header, separators=(",", ":")).encode()) + "." +
                     _b64url(json.dumps(payload, separators=(",", ":")).encode()))
    signature = hmac.new(secret.encode("utf-8"), signing_input.encode("ascii"), hashlib.sha256).digest()
    return signing_input + "." + _b64url(signature)


def room_name(meeting_id):
    return "voic3-meeting-%s" % int(meeting_id)


def access_token(meeting_id, employee_id, display_name="", can_publish=True, ttl_seconds=6 * 3600,
                 e2ee=False, admin=False):
    """Mint a LiveKit join token. Returns '' when the SFU is not configured."""
    if not livekit_configured():
        return ""
    key = _env("VOIC3_LIVEKIT_API_KEY")
    secret = _env("VOIC3_LIVEKIT_API_SECRET")
    now = int(time.time())
    identity = "emp-%d" % int(employee_id)
    grants = {
        "room": room_name(meeting_id),
        "roomJoin": True,
        "canPublish": bool(can_publish),
        "canSubscribe": True,
        "canPublishData": True,
        "roomAdmin": bool(admin),
        "roomCreate": bool(admin),
        "hidden": False,
        "recorder": False,
    }
    if e2ee:
        # Signals to LiveKit that the room is E2EE so it forwards keys, not media.
        grants["roomRecord"] = False
    payload = {
        "iss": key,
        "sub": identity,
        "nbf": now - 5,
        "exp": now + int(ttl_seconds),
        "name": (display_name or identity)[:120],
        "metadata": json.dumps({"employee_id": int(employee_id), "meeting_id": int(meeting_id)},
                               separators=(",", ":")),
        "video": grants,
    }
    return _jwt(payload, secret)


def verify_token(token):
    """Verify a token this server minted (used by the test-suite and diagnostics)."""
    try:
        header_b64, body_b64, sig_b64 = token.split(".")
    except ValueError:
        return None
    secret = _env("VOIC3_LIVEKIT_API_SECRET")
    if not secret:
        return None
    expected = _b64url(hmac.new(secret.encode("utf-8"),
                                (header_b64 + "." + body_b64).encode("ascii"), hashlib.sha256).digest())
    if not hmac.compare_digest(expected, sig_b64):
        return None
    padded = body_b64 + "=" * (-len(body_b64) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(padded))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# E2EE key material
# ---------------------------------------------------------------------------
KEY_TTL_SECONDS = 12 * 3600


def room_key(meeting_id, secret_seed=""):
    """Deterministic per-meeting key.

    Derived with HMAC-SHA256 from the deployment secret (falls back to the
    LiveKit API secret, then to a stable local file) and rotated every 12 hours,
    so the same room never shares a key across days.
    """
    seed = secret_seed or _env("VOIC3_E2EE_SECRET") or _env("VOIC3_LIVEKIT_API_SECRET") or _local_seed()
    slot = int(time.time() // KEY_TTL_SECONDS)
    material = hmac.new(seed.encode("utf-8"), ("%d:%d" % (int(meeting_id), slot)).encode("ascii"),
                        hashlib.sha256).digest()
    return _b64url(material), slot


def _local_seed():
    """Persist a random seed so keys survive a restart (no env var required)."""
    # The app's data folder, never the working directory (see voic3_push._default_data_home).
    if os.environ.get("BR_DATA_HOME"):
        home = Path(os.environ["BR_DATA_HOME"])
    elif os.name == "nt":
        home = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data"
    else:
        home = Path.home() / ".your-userd_registration" / "Data"
    path = home / "e2ee_seed.txt"
    try:
        if path.exists():
            value = path.read_text(encoding="utf-8").strip()
            if value:
                return value
        path.parent.mkdir(parents=True, exist_ok=True)
        value = base64.urlsafe_b64encode(os.urandom(32)).decode()
        path.write_text(value, encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass
        return value
    except Exception:
        return "voic3-local-e2ee-fallback"


def key_payload(meeting_id):
    key, slot = room_key(meeting_id)
    return {"key": key, "epoch": slot, "algorithm": "SFrame", "expires_at": (slot + 1) * KEY_TTL_SECONDS}


# ---------------------------------------------------------------------------
# Transcription (faster-whisper / whisper, both local and free)
# ---------------------------------------------------------------------------
def _ffmpeg():
    return shutil.which("ffmpeg") or ""


def _to_wav(audio_path):
    """Convert to 16 kHz mono WAV when ffmpeg is present; otherwise use the file as-is."""
    ffmpeg = _ffmpeg()
    if not ffmpeg:
        return audio_path, False
    try:
        out = os.path.join(tempfile.mkdtemp(prefix="voic3-stt-"), "audio.wav")
        subprocess.run([ffmpeg, "-y", "-i", audio_path, "-ac", "1", "-ar", "16000", out],
                       capture_output=True, timeout=900, check=True)
        return out, True
    except Exception:
        return audio_path, False


def _segments_from(result):
    out = []
    for seg in result or []:
        try:
            out.append({"start": round(float(getattr(seg, "start", 0)), 2),
                        "end": round(float(getattr(seg, "end", 0)), 2),
                        "text": (getattr(seg, "text", "") or "").strip()})
        except Exception:
            continue
    return [s for s in out if s["text"]]


def transcribe_file(audio_path, language=None):
    """Transcribe a recording on this machine. Raises RuntimeError when unavailable.

    Returns ``{engine, model, language, duration, segments, text}``. Nothing is
    uploaded anywhere: the model runs locally on CPU.
    """
    engine = whisper_backend()
    if not engine:
        raise RuntimeError("No local transcription engine is installed "
                           "(pip install faster-whisper). The recording is still saved.")
    if not audio_path or not os.path.exists(audio_path):
        raise RuntimeError("Recording file not found.")
    model_name = _env("VOIC3_WHISPER_MODEL", DEFAULT_WHISPER_MODEL)
    wav, converted = _to_wav(audio_path)
    started = time.time()
    try:
        if engine == "faster-whisper":
            from faster_whisper import WhisperModel  # type: ignore
            model = WhisperModel(model_name, device="cpu", compute_type="int8")
            segs, info = model.transcribe(wav, language=language or None, vad_filter=True)
            segments = _segments_from(list(segs))
            detected = getattr(info, "language", language or "")
            duration = float(getattr(info, "duration", 0) or 0)
        else:  # pragma: no cover - only when the openai-whisper package is present
            import whisper  # type: ignore
            model = whisper.load_model(model_name)
            result = model.transcribe(wav, language=language or None)
            segments = _segments_from(result.get("segments"))
            detected = result.get("language", language or "")
            duration = float(segments[-1]["end"]) if segments else 0.0
    finally:
        if converted:
            try:
                os.remove(wav)
                os.rmdir(os.path.dirname(wav))
            except Exception:
                pass
    text = " ".join(s["text"] for s in segments).strip()
    return {
        "engine": engine,
        "model": model_name,
        "language": detected,
        "duration": round(duration, 2),
        "segments": segments,
        "text": text,
        "took_seconds": round(time.time() - started, 2),
    }


def safe_language(value):
    """Only accept plain ISO-639 style codes; never pass arbitrary text to a model."""
    value = (value or "").strip().lower()
    return value if re.fullmatch(r"[a-z]{2,3}(-[a-z]{2,4})?", value) else None
