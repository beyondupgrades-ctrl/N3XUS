from __future__ import annotations

import atexit
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
import ipaddress
from urllib.parse import quote, unquote, urlsplit

from communications import SecretVault
from onvif_client import onvif_stream_url


class CameraService:
    VIDEO_SUFFIXES = {".fmp4", ".m4s", ".mkv", ".mov", ".mp4", ".mpeg", ".mpg", ".ts", ".webm"}

    def __init__(self, data_home: Path, store, relay_path: Path | None = None, vault=None):
        self.data_home = Path(data_home).resolve()
        self.store = store
        self.default_folder = self.data_home / "camera-recordings"
        self.relay_path = Path(relay_path) if relay_path else Path(__file__).resolve().parent / "tools" / "mediamtx.exe"
        self.vault = vault or SecretVault(self.data_home / "camera.vault")
        self.vlc_path = None
        self.lock = threading.RLock()
        self.process = None
        self.viewers = {}
        self.viewer_name = ""
        self._frames = {}
        self._watch = False
        self._watch_generation = 0
        atexit.register(self.stop)
        if self._cameras():
            self.restart()

    def _cameras(self):
        value = self.vault.get("camera_sources", [])
        return value if isinstance(value, list) else []

    def settings(self):
        folder = Path(self.store.attendance_setting("camera_recording_folder", str(self.default_folder))).expanduser().resolve()
        try:
            retention = int(self.store.attendance_setting("camera_retention_days", "3"))
        except (TypeError, ValueError):
            retention = 3
        if not 1 <= retention <= 30:
            retention = 3
        try:
            free_bytes = shutil.disk_usage(folder if folder.exists() else folder.parent).free
        except OSError:
            free_bytes = 0
        return {"recording_folder": str(folder), "retention_days": retention, "free_bytes": free_bytes}

    def snapshot(self):
        settings = self.settings()
        cameras = [{k: camera.get(k, "") for k in ("id", "name", "model", "path", "device_uuid")} | {"configured": bool(camera.get("source_url")), "status": self._connection_status(camera.get("id", ""))} for camera in self._cameras()]
        return {**settings, "cameras": cameras, "player": self.viewer_name, "relay_running": bool(self.process and self.process.poll() is None)}

    def _connection_status(self, camera_id):
        """Green when a live picture is arriving, yellow while VLC is still connecting, red when it is not running."""
        camera_id = str(camera_id or "")
        process = self.viewers.get(camera_id)
        if process is None or process.poll() is not None:
            return "offline"
        picture = self.data_home / "camera-vlc" / camera_id / "live.jpg"
        try:
            if time.time() - picture.stat().st_mtime > 15 or picture.stat().st_size < 5:
                return "connecting"
            with picture.open("rb") as handle:
                if handle.read(2) != b"\xff\xd8":
                    return "connecting"
        except OSError:
            return "connecting"
        return "online"

    @staticmethod
    def _login_from_source(source_url):
        parsed = urlsplit(str(source_url or "").strip())
        route = parsed.path or ""
        if parsed.query:
            route += "?" + parsed.query
        return {
            "ip": parsed.hostname or "",
            "rtsp_path": route,
            "username": unquote(parsed.username or ""),
            "password": unquote(parsed.password or ""),
            "port": parsed.port or 554,
        }

    @staticmethod
    def _validate_source(source_url):
        value = str(source_url or "").strip()
        parsed = urlsplit(value)
        if parsed.scheme.lower() != "rtsp" or not parsed.hostname:
            raise ValueError("Enter a local RTSP source URL for this camera.")
        if any(ord(char) < 32 for char in value):
            raise ValueError("The RTSP source URL contains unsupported characters.")
        host = parsed.hostname
        if ".." in host:
            collapsed = re.sub(r"\.{2,}", ".", host)
            try:
                ipaddress.ip_address(collapsed)
            except ValueError:
                collapsed = ""
            if collapsed:
                value = value.replace(host, collapsed, 1)
                host = collapsed
        try:
            ipaddress.ip_address(host)
        except ValueError as exc:
            raise ValueError("The camera IP address is not valid. Check for an extra dot, for example YOUR_LAN_IP.") from exc
        return value

    @staticmethod
    def _rtsp_route(rtsp_path):
        path = str(rtsp_path or "").strip()
        if not path:
            return "/ch=1", "subtype=1"
        if path.lower().startswith("rtsp://"):
            return "", ""
        if any(ord(char) < 32 or char in " @" for char in path):
            raise ValueError("Enter the RTSP path shown by the camera, for example /ch=1?subtype=0.")
        if not path.startswith("/"):
            path = "/" + path
        route, separator, query = path.partition("?")
        if not re.fullmatch(r"/[A-Za-z0-9_.=/-]*", route) or (separator and not re.fullmatch(r"[A-Za-z0-9_.=&%-]*", query)):
            raise ValueError("Enter the RTSP path shown by the camera, for example /ch=1?subtype=0.")
        return route, query

    @staticmethod
    def _source_from_ip(ip, username, password, rtsp_path="", port=None):
        host = str(ip or "").strip()
        path = str(rtsp_path or "").strip()
        if path.lower().startswith("rtsp://"):
            return CameraService._with_credentials(path, username, password) if username or password else CameraService._validate_source(path)
        if host.lower().startswith("rtsp://"):
            return CameraService._with_credentials(host, username, password) if username or password else CameraService._validate_source(host)
        try:
            ipaddress.ip_address(host)
        except ValueError as exc:
            raise ValueError("Enter the camera IP address from the Tenda app, for example YOUR_LAN_IP.") from exc
        if path and (not str(username or "").strip() or not str(password or "").strip()):
            raise ValueError("Enter the RTSP username and password the camera asked you to add.")
        user = quote(str(username or "").strip(), safe="")
        secret = quote(str(password or "").strip(), safe="")
        auth = f"{user}:{secret}@" if user or secret else ""
        route, query = CameraService._rtsp_route(path)
        query_part = f"?{query}" if query else ""
        try:
            port_number = int(port) if port else 554
        except (TypeError, ValueError):
            port_number = 554
        if not 1 <= port_number <= 65535:
            port_number = 554
        return f"rtsp://{auth}{host}:{port_number}{route}{query_part}"

    @staticmethod
    def _with_credentials(stream_url, username, password):
        parsed = urlsplit(str(stream_url or "").strip())
        if parsed.scheme.lower() != "rtsp" or not parsed.hostname:
            raise ValueError("The camera did not provide a usable ONVIF stream.")
        user = quote(str(username or "").strip(), safe="")
        secret = quote(str(password or "").strip(), safe="")
        auth = f"{user}:{secret}@" if user or secret else ""
        port = f":{parsed.port}" if parsed.port else ""
        query = f"?{parsed.query}" if parsed.query else ""
        return f"rtsp://{auth}{parsed.hostname}{port}{parsed.path}{query}"

    def save_settings(self, recording_folder, retention_days):
        folder = Path(str(recording_folder or "")).expanduser().resolve()
        if not str(recording_folder or "").strip():
            raise ValueError("Choose a folder for camera recordings.")
        try:
            retention = int(retention_days)
        except (TypeError, ValueError) as exc:
            raise ValueError("Retention must be a whole number of days.") from exc
        if not 1 <= retention <= 30:
            raise ValueError("Retention must be between 1 and 30 days.")
        folder.mkdir(parents=True, exist_ok=True)
        if not folder.is_dir():
            raise ValueError("The recording location must be a folder.")
        with tempfile.TemporaryFile(dir=folder):
            pass
        self.store.set_attendance_setting("camera_recording_folder", str(folder))
        self.store.set_attendance_setting("camera_retention_days", str(retention))
        if self._cameras():
            self.restart()
        return self.snapshot()

    def save_camera(self, camera_id, name, model, source_url=None, ip=None, username=None, password=None, device_uuid=None, rtsp_path=None):
        name = str(name or "").strip()
        model = str(model or "").strip().upper()
        if not name or len(name) > 60:
            raise ValueError("Enter a camera name (up to 60 characters).")
        if model not in ("CH7", "CH9"):
            raise ValueError("Choose a supported camera model: CH7 or CH9.")
        cameras = self._cameras()
        requested_id = str(camera_id or "")
        existing = next((item for item in cameras if item.get("id") == requested_id), None) if re.fullmatch(r"[a-f0-9]{12}", requested_id) else None
        if existing and not str(username or "").strip():
            username = existing.get("username") or self._login_from_source(existing.get("source_url", "")).get("username", "")
        if existing and not str(password or "").strip():
            password = existing.get("password") or self._login_from_source(existing.get("source_url", "")).get("password", "")
        remembered_port = None
        if existing and str(ip or "").strip():
            previous = self._login_from_source(existing.get("source_url", ""))
            if previous.get("ip") == str(ip).strip():
                remembered_port = previous.get("port")
        if str(rtsp_path or "").strip():
            source_url = self._source_from_ip(ip, username, password, rtsp_path, remembered_port)
        elif str(ip or "").strip():
            discovered = onvif_stream_url(str(ip).strip(), str(username or ""), str(password or ""))
            source_url = self._with_credentials(discovered, username, password) if discovered else self._source_from_ip(ip, username, password, "", remembered_port)
        elif not source_url:
            raise ValueError("Enter the camera IP address from the Tenda app.")
        source_url = self._validate_source(source_url)
        device_uuid = re.sub(r"[^A-Za-z0-9_.:-]", "", str(device_uuid or ""))[:80]
        if len(device_uuid) < 4:
            device_uuid = ""
        camera_id = requested_id or uuid.uuid4().hex[:12]
        if not re.fullmatch(r"[a-f0-9]{12}", camera_id):
            raise ValueError("The camera identifier is invalid.")
        path = "camera-" + camera_id
        login = self._login_from_source(source_url)
        camera = {
            "id": camera_id,
            "name": name,
            "model": model,
            "path": path,
            "device_uuid": device_uuid,
            "source_url": source_url,
            "ip": str(ip or "").strip() or login["ip"],
            "rtsp_path": str(rtsp_path or "").strip() or login["rtsp_path"],
            "username": str(username or "").strip() or login["username"],
            "password": str(password or "") if str(password or "") != "" else login["password"],
        }
        for index, saved in enumerate(cameras):
            if saved.get("id") == camera_id:
                cameras[index] = camera
                break
        else:
            cameras.append(camera)
        self.vault.set("camera_sources", cameras)
        self.last_saved_id = camera_id
        self.restart(refresh_id=camera_id)
        return self.snapshot()

    def camera_form(self, camera_id):
        """Return the saved setup, including the RTSP username and password, for the edit form only."""
        for camera in self._cameras():
            if camera.get("id") != str(camera_id):
                continue
            login = self._login_from_source(camera.get("source_url", ""))
            return {
                "id": camera.get("id", ""),
                "name": camera.get("name", ""),
                "model": camera.get("model", ""),
                "device_uuid": camera.get("device_uuid", ""),
                "ip": camera.get("ip") or login["ip"],
                "rtsp_path": camera.get("rtsp_path") or login["rtsp_path"],
                "username": camera.get("username") or login["username"],
                "password": camera.get("password") if camera.get("password") else login["password"],
            }
        raise KeyError("Camera not found.")

    def refresh_camera(self, camera_id):
        """Restart one camera viewer and leave the other tiles playing."""
        camera_id = str(camera_id or "")
        if not any(camera.get("id") == camera_id for camera in self._cameras()):
            raise KeyError("Camera not found.")
        self._frames.pop(camera_id, None)
        picture = self.data_home / "camera-vlc" / camera_id / "live.jpg"
        try:
            picture.unlink(missing_ok=True)
        except OSError:
            pass
        with self.lock:
            self.start_viewers(refresh_id=camera_id)
        return self.snapshot()

    def rename_camera(self, camera_id, name):
        name = str(name or "").strip()
        if not name or len(name) > 60:
            raise ValueError("Enter a camera name (up to 60 characters).")
        cameras = self._cameras()
        for camera in cameras:
            if camera.get("id") == str(camera_id):
                camera["name"] = name
                self.vault.set("camera_sources", cameras)
                return self.snapshot()
        raise KeyError("Camera not found.")

    def delete_camera(self, camera_id):
        cameras = [camera for camera in self._cameras() if camera.get("id") != str(camera_id)]
        if len(cameras) == len(self._cameras()):
            raise KeyError("Camera not found.")
        self.vault.set("camera_sources", cameras)
        self.restart()
        return self.snapshot()

    def render_config(self):
        settings = self.settings()
        folder = Path(settings["recording_folder"])
        record_path = str(folder / "%path" / "%Y-%m-%d_%H-%M-%S-%f_%z")
        # HLS stays on 8189 next to RTSP 8554 and WebRTC 8889, so the relay the
        # operations check looks for is the same relay the app runs. It is bound
        # to loopback only: nothing on the relay is reachable from the network
        # unless the owner deliberately changes these addresses.
        lines = [
            "logLevel: error", "api: no", "metrics: no", "pprof: no", "playback: no",
            "rtsp: yes", "rtspAddress: 127.0.0.1:8554",
            "hls: yes", "hlsAddress: 127.0.0.1:8189",
            "webrtc: yes", "webrtcAddress: 127.0.0.1:8889",
            # WebRTC's local ICE port sits on 8190: 8189 is HLS, and two
            # listeners cannot share one UDP port.
            "webrtcLocalUDPAddress: 127.0.0.1:8190", "webrtcIPsFromInterfaces: no",
            "webrtcAdditionalHosts: [127.0.0.1]", "record: yes",
            f"recordPath: {json.dumps(record_path)}", "recordFormat: fmp4",
            "recordPartDuration: 1s", "recordSegmentDuration: 1h",
            f"recordDeleteAfter: {settings['retention_days'] * 24}h",
            "pathDefaults:",
            "  record: yes",
            f"  recordDeleteAfter: {settings['retention_days'] * 24}h",
            "paths:",
        ]
        for camera in self._cameras():
            if not camera.get("source_url"):
                continue
            lines.extend((f"  {camera['path']}:", f"    source: {json.dumps(camera['source_url'])}", "    sourceOnDemand: true", "    record: yes"))
        return "\n".join(lines) + "\n"

    def _relay_ports_in_use(self, relay_path=None):
        """True when the fixed relay ports are already bound on this machine.

        MediaMTX takes RTSP 8554, WebRTC 8889 and UDP 8000. When this application
        (or a stale relay) already holds them, a second relay cannot start, so the
        caller can report that instead of appearing to fail for no reason.
        """
        if os.name != "nt":
            return False
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        listing = ""
        for protocol in ("TCP", "UDP"):
            try:
                result = subprocess.run(["netstat", "-ano", "-p", protocol], capture_output=True, text=True, timeout=8, check=False, creationflags=flags)
                listing += result.stdout or ""
            except (OSError, subprocess.SubprocessError):
                return False
        for line in listing.splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            local = parts[1]
            if local.endswith(":8554") or local.endswith(":8889") or local.endswith(":8000"):
                return True
        return False

    def render_standalone_config(self):
        """The relay's configuration for a start from outside the app.

        Same ports and same loopback-only bindings as render_config(), with no
        camera paths: a relay with nothing configured is idle and costs nothing,
        and the operations check can see the ports the cameras will use.
        """
        settings = self.settings()
        folder = Path(settings["recording_folder"])
        record_path = str(folder / "%path" / "%Y-%m-%d_%H-%M-%S-%f_%z")
        return "\n".join([
            "logLevel: error", "api: no", "metrics: no", "pprof: no", "playback: no",
            "rtsp: yes", "rtspAddress: 127.0.0.1:8554",
            "hls: yes", "hlsAddress: 127.0.0.1:8189",
            "webrtc: yes", "webrtcAddress: 127.0.0.1:8889",
            "webrtcLocalUDPAddress: 127.0.0.1:8190", "webrtcIPsFromInterfaces: no",
            "webrtcAdditionalHosts: [127.0.0.1]",
            "record: yes", f"recordPath: {json.dumps(record_path)}", "recordFormat: fmp4",
            "recordPartDuration: 1s", "recordSegmentDuration: 1h",
            f"recordDeleteAfter: {settings['retention_days'] * 24}h",
            "pathDefaults:", "  record: yes",
            f"  recordDeleteAfter: {settings['retention_days'] * 24}h",
            "paths:", "",
        ])

    def restart(self, refresh_id=None):
        with self.lock:
            self._stop_relay()
            if not self._cameras():
                self.stop_viewers()
                return False
            if not self.relay_path.is_file():
                raise RuntimeError("The local camera relay is missing from this package.")
            config_path = None
            try:
                with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".yml", delete=False) as config:
                    config.write(self.render_config())
                    config_path = Path(config.name)
                validation = subprocess.run([str(self.relay_path), f"--validate-conf={config_path}"], capture_output=True, text=True, timeout=15, check=False)
                if validation.returncode:
                    raise RuntimeError("The local camera relay rejected its configuration.")
                if not self._spawn_relay(config_path):
                    self._release_leftover_relay()
                    time.sleep(0.3)
                    if not self._spawn_relay(config_path):
                        self.start_viewers(refresh_id=refresh_id)
                        return False
                self.start_viewers(refresh_id=refresh_id)
                return True
            except subprocess.TimeoutExpired as exc:
                raise RuntimeError("The local camera relay did not respond to configuration validation.") from exc
            finally:
                if config_path:
                    config_path.unlink(missing_ok=True)

    def _spawn_relay(self, config_path):
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.process = subprocess.Popen([str(self.relay_path), str(config_path)], cwd=str(self.data_home), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)
        time.sleep(0.35)
        if self.process.poll() is not None:
            self.process = None
            return False
        return True

    def _release_leftover_relay(self):
        """Stop a relay left behind by an earlier run so this start can use its ports."""
        if os.name != "nt" or not self.relay_path.is_file():
            return
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        query = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_Process -Filter \"Name='mediamtx.exe'\" | ForEach-Object { \"$($_.ProcessId)`t$($_.ExecutablePath)\" }"], capture_output=True, text=True, timeout=8, check=False, creationflags=flags)
        target = str(self.relay_path.resolve()).casefold()
        for line in query.stdout.splitlines():
            pid_text, separator, path = line.partition("\t")
            if not separator or not pid_text.strip().isdigit() or not path.strip():
                continue
            try:
                if str(Path(path.strip()).resolve()).casefold() != target:
                    continue
            except OSError:
                continue
            subprocess.run(["taskkill", "/PID", pid_text.strip(), "/F"], capture_output=True, check=False, creationflags=flags)

    def find_vlc(self):
        if self.vlc_path and Path(self.vlc_path).is_file():
            return Path(self.vlc_path)
        candidates = [
            Path(os.environ.get("PROGRAMFILES", "")) / "VideoLAN" / "VLC" / "vlc.exe",
            Path(os.environ.get("PROGRAMFILES(X86)", "")) / "VideoLAN" / "VLC" / "vlc.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "VideoLAN" / "VLC" / "vlc.exe",
        ]
        found = shutil.which("vlc")
        if found:
            candidates.append(Path(found))
        return next((candidate for candidate in candidates if candidate.is_file()), None)

    def _viewer_command(self, vlc, camera):
        camera_id = str(camera["id"])
        folder = self.data_home / "camera-vlc"
        picture_dir = folder / camera_id
        picture_dir.mkdir(parents=True, exist_ok=True)
        playlist = folder / f"{camera_id}.m3u"
        playlist.write_text("#EXTM3U\n" + str(camera["source_url"]) + "\n", encoding="utf-8")
        return [
            str(vlc), "--ignore-config", "--no-one-instance", "-I", "dummy", "-V", "dummy",
            "--avcodec-hw=none", "--dummy-quiet", "--no-video-title-show", "--no-audio",
            "--no-qt-privacy-ask", "--rtsp-tcp", "--network-caching=500",
            "--video-filter=scene", "--scene-replace", "--scene-format=jpg", "--scene-ratio=30",
            "--scene-width=1280", "--scene-height=720", "--scene-prefix=live", f"--scene-path={picture_dir}",
            str(playlist),
        ]

    def _start_one_viewer(self, vlc, camera):
        """Open a separate VLC for this camera and leave every other camera running."""
        camera_id = str(camera["id"])
        self._stop_process(self.viewers.get(camera_id))
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        folder = self.data_home / "camera-vlc"
        folder.mkdir(parents=True, exist_ok=True)
        self.viewers[camera_id] = subprocess.Popen(self._viewer_command(vlc, camera), cwd=str(folder), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)

    def start_viewers(self, refresh_id=None):
        """Show each camera through its own VLC. A new camera does not close the ones already open."""
        vlc = self.find_vlc()
        cameras = [camera for camera in self._cameras() if camera.get("source_url")]
        wanted = {str(camera["id"]) for camera in cameras}
        for camera_id in list(self.viewers):
            if camera_id not in wanted:
                self._stop_process(self.viewers.pop(camera_id))
                playlist = self.data_home / "camera-vlc" / f"{camera_id}.m3u"
                playlist.unlink(missing_ok=True)
        if not vlc or not cameras:
            self.viewer_name = ""
            return
        refresh_id = str(refresh_id) if refresh_id else ""
        for camera in cameras:
            camera_id = str(camera["id"])
            process = self.viewers.get(camera_id)
            if camera_id != refresh_id and process is not None and process.poll() is None:
                continue
            self._start_one_viewer(vlc, camera)
        self.viewer_name = "vlc"
        if not self._watch:
            self._watch_generation += 1
            generation = self._watch_generation
            self._watch = True
            threading.Thread(target=self._watch_viewers, args=(generation,), name="your-userd-vlc", daemon=True).start()

    def _watch_viewers(self, generation):
        while self._watch and self._watch_generation == generation:
            time.sleep(3)
            if not self._watch or self._watch_generation != generation:
                return
            with self.lock:
                if not self._watch or self._watch_generation != generation:
                    return
                if any(isinstance(process.poll(), int) for process in self.viewers.values()):
                    self.start_viewers()

    def latest_frame(self, camera_id):
        key = str(camera_id)
        path = self.data_home / "camera-vlc" / key / "live.jpg"
        try:
            stat = path.stat()
            if time.time() - stat.st_mtime > 5:
                self._frames.pop(key, None)
                return b""
            data = path.read_bytes()
        except OSError:
            data = b""
        if len(data) > 4 and data.startswith(b"\xff\xd8") and data.endswith(b"\xff\xd9"):
            self._frames[key] = data
        return self._frames.get(key, b"")

    def _stop_process(self, process):
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=3)

    def stop_viewers(self):
        self._watch = False
        processes = list(self.viewers.values())
        self.viewers = {}
        self.viewer_name = ""
        for process in processes:
            self._stop_process(process)
        folder = self.data_home / "camera-vlc"
        if folder.exists():
            for playlist in folder.glob("*.m3u"):
                playlist.unlink(missing_ok=True)

    def _stop_relay(self):
        process = self.process
        self.process = None
        self._stop_process(process)

    def stop(self):
        self.stop_viewers()
        self._stop_relay()

    def _matching_footage(self, month="", start="", end=""):
        root = Path(self.settings()["recording_folder"]).resolve()
        if month:
            try:
                month_start = datetime.strptime(month, "%Y-%m")
            except ValueError as exc:
                raise ValueError("Choose a valid month.") from exc
            month_end = (month_start.replace(day=28) + timedelta(days=4)).replace(day=1)
            start_at, end_at = month_start, month_end
        else:
            if not start or not end:
                raise ValueError("Choose a month or a start and end time.")
            try:
                start_at, end_at = datetime.fromisoformat(start), datetime.fromisoformat(end)
            except ValueError as exc:
                raise ValueError("Choose valid start and end times.") from exc
            if end_at <= start_at:
                raise ValueError("The end time must be after the start time.")
        selected = []
        if root.is_dir():
            for candidate in root.rglob("*"):
                if not candidate.is_file() or candidate.suffix.lower() not in self.VIDEO_SUFFIXES:
                    continue
                try:
                    candidate.resolve().relative_to(root)
                    captured = self._clip_timestamp(candidate)
                except (OSError, ValueError):
                    continue
                if start_at <= captured < end_at:
                    selected.append(candidate)
        selected.sort(key=lambda item: item.stat().st_mtime)
        return root, selected

    @staticmethod
    def _clip_timestamp(candidate):
        match = re.search(r"(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}-\d{1,6}_[+-]\d{4})$", candidate.stem)
        if match:
            try:
                return datetime.strptime(match.group(1), "%Y-%m-%d_%H-%M-%S-%f_%z").astimezone().replace(tzinfo=None)
            except ValueError:
                pass
        return datetime.fromtimestamp(candidate.stat().st_mtime)

    def footage_preview(self, month="", start="", end=""):
        root, selected = self._matching_footage(month, start, end)
        return {"count": len(selected), "bytes": sum(item.stat().st_size for item in selected), "files": [str(item.relative_to(root)) for item in selected[:100]], "more": max(0, len(selected) - 100)}

    def delete_footage(self, month="", start="", end="", confirm=False):
        if confirm is not True:
            raise ValueError("Confirm the footage deletion after reviewing the preview.")
        root, selected = self._matching_footage(month, start, end)
        bytes_to_delete = sum(item.stat().st_size for item in selected)
        deleted = 0
        failures = 0
        for target in selected:
            try:
                target.relative_to(root)
                target.unlink()
                deleted += 1
            except (OSError, ValueError):
                failures += 1
        return {"count": len(selected), "bytes": bytes_to_delete, "deleted": deleted, "failed": failures}