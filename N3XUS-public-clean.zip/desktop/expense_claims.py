"""Expense claims with approval workflow (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS expense_claims(
  id INTEGER PRIMARY KEY AUTOINCREMENT, employee TEXT NOT NULL, amount REAL NOT NULL,
  category TEXT DEFAULT 'General', description TEXT DEFAULT '', receipt_path TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Pending', decision_by TEXT DEFAULT '', decision_at TEXT DEFAULT '',
  created_at TEXT NOT NULL);
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_claims(conn, status=None):
    sql = "SELECT * FROM expense_claims"
    args = []
    if status:
        sql += " WHERE status=?"; args.append(status)
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def submit(conn, employee, amount, category="General", description="", receipt_path=""):
    cur = conn.execute("INSERT INTO expense_claims(employee,amount,category,description,receipt_path,status,created_at) VALUES(?,?,?,?,?,?,?)",
                       (employee, float(amount), category, description, receipt_path, "Pending", date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def decide(conn, cid, decision, decided_by=""):
    conn.execute("UPDATE expense_claims SET status=?,decision_by=?,decision_at=? WHERE id=?",
                 (decision, decided_by, date.today().isoformat(), cid))
    conn.commit()