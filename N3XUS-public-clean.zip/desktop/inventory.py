"""Inventory management (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS inventory_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT DEFAULT '', name TEXT NOT NULL,
  location TEXT DEFAULT 'Main', qty_on_hand REAL NOT NULL DEFAULT 0,
  reorder_level REAL NOT NULL DEFAULT 0, unit TEXT DEFAULT 'each',
  unit_cost REAL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stock_movements(
  id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL, qty REAL NOT NULL,
  movement_type TEXT NOT NULL, reference TEXT DEFAULT '', created_at TEXT NOT NULL,
  FOREIGN KEY(item_id) REFERENCES inventory_items(id));
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_items(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM inventory_items ORDER BY name").fetchall()]


def save_item(conn, name, sku="", location="Main", qty=0, reorder=0, unit="each", cost=0):
    cur = conn.execute("INSERT INTO inventory_items(sku,name,location,qty_on_hand,reorder_level,unit,unit_cost,created_at) VALUES(?,?,?,?,?,?,?,?)",
                       (sku, name, location, float(qty), float(reorder), unit, float(cost), date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def adjust_stock(conn, item_id, qty, movement_type="adjustment", reference=""):
    conn.execute("INSERT INTO stock_movements(item_id,qty,movement_type,reference,created_at) VALUES(?,?,?,?,?)",
                 (item_id, float(qty), movement_type, reference, date.today().isoformat()))
    conn.execute("UPDATE inventory_items SET qty_on_hand=qty_on_hand+? WHERE id=?", (float(qty), item_id))
    conn.commit()


def low_stock(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM inventory_items WHERE qty_on_hand <= reorder_level").fetchall()]