"""QUOT3FLOW — quotation-to-payment lifecycle for Beyond Registration (PTY) Ltd.

Local-first module: clients, quotes, invoices, payments, receipts, banking
accounts and payment-provider registry. All financial state changes are
append-only audited in qf3_events and the shared audit_log.

Hard rules enforced here:
- A payment can only become 'confirmed' via an authorised manual confirmation
  (Phase 1) or a provider-verified webhook (Phase 4). Nothing else may set it.
- Issued invoices and sent quotes are immutable; corrections use void + reissue.
- Portal tokens are random, single-document and expiring.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
from datetime import date, datetime, timedelta
from io import BytesIO

SCHEMA = """
CREATE TABLE IF NOT EXISTS qf3_clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact_name TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  vat_registered INTEGER NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qf3_quotes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quote_no TEXT NOT NULL UNIQUE,
  client_id INTEGER NOT NULL REFERENCES qf3_clients(id),
  status TEXT NOT NULL DEFAULT 'draft',
  issue_date TEXT NOT NULL,
  valid_until TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'ZAR',
  tax_rate REAL NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT '',
  portal_token TEXT,
  portal_expires TEXT,
  created_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qf3_quote_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quote_id INTEGER NOT NULL REFERENCES qf3_quotes(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  qty REAL NOT NULL DEFAULT 1,
  unit_price REAL NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS qf3_invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no TEXT NOT NULL UNIQUE,
  quote_id INTEGER REFERENCES qf3_quotes(id),
  client_id INTEGER NOT NULL REFERENCES qf3_clients(id),
  status TEXT NOT NULL DEFAULT 'issued',
  issue_date TEXT NOT NULL,
  due_date TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'ZAR',
  tax_rate REAL NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT '',
  portal_token TEXT,
  portal_expires TEXT,
  void_reason TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qf3_invoice_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL REFERENCES qf3_invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  qty REAL NOT NULL DEFAULT 1,
  unit_price REAL NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS qf3_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL REFERENCES qf3_invoices(id),
  receipt_no TEXT NOT NULL DEFAULT '',
  amount REAL NOT NULL,
  method TEXT NOT NULL DEFAULT 'manual',
  provider TEXT NOT NULL DEFAULT 'manual',
  provider_ref TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  promise_date TEXT NOT NULL DEFAULT '',
  verified_by TEXT NOT NULL DEFAULT '',
  verified_at TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qf3_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity TEXT NOT NULL,
  entity_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  actor TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bank_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_type TEXT NOT NULL DEFAULT 'cheque',
  branch_code TEXT NOT NULL DEFAULT '',
  account_number TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'ZAR',
  provider_code TEXT NOT NULL DEFAULT 'manual',
  is_default INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  verified INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS payment_providers (
  code TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'manual',
  config_json TEXT NOT NULL DEFAULT '{}',
  webhook_secret TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qf3_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_qf3q_client ON qf3_quotes(client_id);
CREATE INDEX IF NOT EXISTS idx_qf3i_client ON qf3_invoices(client_id);
CREATE INDEX IF NOT EXISTS idx_qf3p_invoice ON qf3_payments(invoice_id);
CREATE INDEX IF NOT EXISTS idx_qf3e_entity ON qf3_events(entity, entity_id);
"""

SEED_PROVIDERS = [
    ("manual", "Manual / Bank confirmation", "manual"),
    ("yoco", "Yoco", "yoco"),
    ("fnb", "FNB", "fnb"),
    ("other", "Other provider", "other"),
]

COMPANY = {
    "name": "BEYOND REGISTRATION (PTY) LTD",
    "reg": "Reg. No. 2026721121",
    "descriptor": "AUTONOMOUS GLOBAL ECOSYSTEM",
}


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    stamp = now_iso()
    for code, name, kind in SEED_PROVIDERS:
        conn.execute(
            "INSERT OR IGNORE INTO payment_providers(code,display_name,kind,created_at) VALUES(?,?,?,?)",
            (code, name, kind, stamp),
        )
    conn.commit()


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def today() -> str:
    return date.today().isoformat()


def _rows(conn, sql, args=()):
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def _row(conn, sql, args=()):
    r = conn.execute(sql, args).fetchone()
    return dict(r) if r else None


def event(conn, entity: str, entity_id: int, action: str, actor: str = "", detail: str = ""):
    conn.execute(
        "INSERT INTO qf3_events(entity,entity_id,action,actor,detail,created_at) VALUES(?,?,?,?,?,?)",
        (entity, int(entity_id), action, actor, detail[:2000], now_iso()),
    )


def setting(conn, key: str, default: str = "") -> str:
    r = _row(conn, "SELECT value FROM qf3_settings WHERE key=?", (key,))
    return r["value"] if r else default


def set_setting(conn, key: str, value: str):
    conn.execute(
        "INSERT INTO qf3_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, str(value)),
    )


def next_number(conn, column: str, table: str, prefix: str) -> str:
    """Sequential document number, e.g. Q-0007 / I-0007 / R-0007."""
    rows = _rows(conn, f"SELECT {column} AS n FROM {table} WHERE {column} LIKE ?", (prefix + "-%",))
    mx = 0
    for r in rows:
        try:
            mx = max(mx, int(str(r["n"]).rsplit("-", 1)[-1]))
        except (ValueError, IndexError):
            pass
    return f"{prefix}-{mx + 1:04d}"


def totals(items, tax_rate: float):
    sub = round(sum(float(i.get("qty") or 0) * float(i.get("unit_price") or 0) for i in items), 2)
    tax = round(sub * float(tax_rate or 0) / 100.0, 2)
    return {"subtotal": sub, "tax": tax, "total": round(sub + tax, 2)}


# ---------------------------------------------------------------- clients --

def list_clients(conn, active_only=False):
    sql = "SELECT * FROM qf3_clients" + (" WHERE active=1" if active_only else "") + " ORDER BY name"
    return _rows(conn, sql)


def save_client(conn, actor, data, client_id=None):
    name = str(data.get("name") or "").strip()
    if not name:
        raise ValueError("Client name is required.")
    stamp = now_iso()
    fields = {
        "name": name[:200],
        "contact_name": str(data.get("contact_name") or "")[:200],
        "email": str(data.get("email") or "")[:200],
        "phone": str(data.get("phone") or "")[:60],
        "address": str(data.get("address") or "")[:2000],
        "vat_registered": 1 if data.get("vat_registered") else 0,
        "notes": str(data.get("notes") or "")[:4000],
        "active": 1 if data.get("active", True) else 0,
        "updated_at": stamp,
    }
    if client_id:
        if not _row(conn, "SELECT id FROM qf3_clients WHERE id=?", (int(client_id),)):
            raise KeyError("Client not found.")
        sets = ",".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE qf3_clients SET {sets} WHERE id=?", [*fields.values(), int(client_id)])
        event(conn, "client", client_id, "update", actor, name)
        cid = client_id
    else:
        cols = list(fields) + ["created_at"]
        conn.execute(
            f"INSERT INTO qf3_clients({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
            [*fields.values(), stamp],
        )
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        event(conn, "client", cid, "create", actor, name)
    conn.commit()
    return cid


# ----------------------------------------------------------------- quotes --

def _items(conn, table, fk, fk_id):
    return _rows(conn, f"SELECT * FROM {table} WHERE {fk}=? ORDER BY sort,id", (fk_id,))


def quote_payload(conn, q):
    items = _items(conn, "qf3_quote_items", "quote_id", q["id"])
    t = totals(items, q["tax_rate"])
    client = _row(conn, "SELECT * FROM qf3_clients WHERE id=?", (q["client_id"],)) or {}
    return {**q, "client": client, "items": items, **t}


def list_quotes(conn, status=None):
    sql = "SELECT q.*,c.name AS client_name FROM qf3_quotes q JOIN qf3_clients c ON c.id=q.client_id"
    args = []
    if status:
        sql += " WHERE q.status=?"; args.append(status)
    sql += " ORDER BY q.id DESC"
    return _rows(conn, sql, args)


def get_quote(conn, qid):
    q = _row(conn, "SELECT * FROM qf3_quotes WHERE id=?", (int(qid),))
    return quote_payload(conn, q) if q else None


def save_quote(conn, actor, data, qid=None):
    stamp = now_iso()
    items = data.get("items") or []
    clean_items = []
    for i, it in enumerate(items):
        desc = str(it.get("description") or "").strip()
        if not desc:
            continue
        clean_items.append((desc[:500], float(it.get("qty") or 1), float(it.get("unit_price") or 0), i))
    client_id = int(data.get("client_id") or 0)
    if not _row(conn, "SELECT id FROM qf3_clients WHERE id=?", (client_id,)):
        raise ValueError("Choose a valid client.")
    tax_rate = float(data.get("tax_rate") if data.get("tax_rate") is not None else 0)
    if tax_rate < 0 or tax_rate > 100:
        raise ValueError("Tax rate must be between 0 and 100.")
    issue = str(data.get("issue_date") or today())[:10]
    valid = str(data.get("valid_until") or (date.today() + timedelta(days=30)).isoformat())[:10]
    if qid:
        q = _row(conn, "SELECT * FROM qf3_quotes WHERE id=?", (int(qid),))
        if not q:
            raise KeyError("Quote not found.")
        if q["status"] != "draft":
            raise PermissionError("Only draft quotes can be edited. Void and recreate instead.")
        conn.execute(
            "UPDATE qf3_quotes SET client_id=?,issue_date=?,valid_until=?,currency=?,tax_rate=?,notes=?,updated_at=? WHERE id=?",
            (client_id, issue, valid, str(data.get("currency") or "ZAR")[:8], tax_rate,
             str(data.get("notes") or "")[:4000], stamp, int(qid)),
        )
        conn.execute("DELETE FROM qf3_quote_items WHERE quote_id=?", (int(qid),))
        event(conn, "quote", qid, "update", actor, q["quote_no"])
    else:
        qno = next_number(conn, "quote_no", "qf3_quotes", "Q")
        conn.execute(
            "INSERT INTO qf3_quotes(quote_no,client_id,status,issue_date,valid_until,currency,tax_rate,notes,created_by,created_at,updated_at) VALUES(?,?,'draft',?,?,?,?,?,?,?,?)",
            (qno, client_id, issue, valid, str(data.get("currency") or "ZAR")[:8], tax_rate,
             str(data.get("notes") or "")[:4000], actor, stamp, stamp),
        )
        qid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        event(conn, "quote", qid, "create", actor, qno)
    for desc, qty, price, sort in clean_items:
        conn.execute(
            "INSERT INTO qf3_quote_items(quote_id,description,qty,unit_price,sort) VALUES(?,?,?,?,?)",
            (int(qid), desc, qty, price, sort),
        )
    conn.commit()
    return get_quote(conn, qid)


def transition_quote(conn, actor, qid, action):
    """send / cancel for staff-side transitions."""
    q = _row(conn, "SELECT * FROM qf3_quotes WHERE id=?", (int(qid),))
    if not q:
        raise KeyError("Quote not found.")
    stamp = now_iso()
    if action == "send":
        if q["status"] != "draft":
            raise PermissionError("Only draft quotes can be sent.")
        token = secrets.token_urlsafe(32)
        expires = (date.today() + timedelta(days=45)).isoformat()
        conn.execute(
            "UPDATE qf3_quotes SET status='sent',portal_token=?,portal_expires=?,updated_at=? WHERE id=?",
            (token, expires, stamp, int(qid)),
        )
        event(conn, "quote", qid, "send", actor, q["quote_no"])
    elif action == "cancel":
        if q["status"] in ("accepted",):
            raise PermissionError("An accepted quote cannot be cancelled; void its invoice instead.")
        conn.execute("UPDATE qf3_quotes SET status='cancelled',updated_at=? WHERE id=?", (stamp, int(qid)))
        event(conn, "quote", qid, "cancel", actor, q["quote_no"])
    else:
        raise ValueError("Unknown quote action.")
    conn.commit()
    return get_quote(conn, qid)


def portal_decision(conn, token, decision):
    """Public client accept/decline. Returns (doc dict, error)."""
    decision = str(decision or "").lower()
    if decision not in ("accept", "decline"):
        return None, "Invalid decision."
    q = _row(conn, "SELECT * FROM qf3_quotes WHERE portal_token=?", (str(token),))
    kind = "quote"
    if not q:
        q = _row(conn, "SELECT * FROM qf3_invoices WHERE portal_token=?", (str(token),))
        kind = "invoice"
    if not q:
        return None, "This link is invalid or has expired."
    exp = q.get("portal_expires") or ""
    if exp and exp < today():
        return None, "This link has expired. Please request a new one."
    stamp = now_iso()
    if kind == "quote":
        if q["status"] not in ("sent",):
            return None, "This quotation is no longer open for a decision."
        new = "accepted" if decision == "accept" else "declined"
        conn.execute("UPDATE qf3_quotes SET status=?,updated_at=? WHERE id=?", (new, stamp, q["id"]))
        event(conn, "quote", q["id"], f"portal_{decision}", "client", q["quote_no"])
        conn.commit()
        return {"kind": kind, "number": q["quote_no"], "status": new}, None
    # invoice portal decision is not an acceptance channel; only informational.
    return None, "Invoices cannot be accepted through this link."


# --------------------------------------------------------------- invoices --

def invoice_payload(conn, inv):
    items = _items(conn, "qf3_invoice_items", "invoice_id", inv["id"])
    t = totals(items, inv["tax_rate"])
    client = _row(conn, "SELECT * FROM qf3_clients WHERE id=?", (inv["client_id"],)) or {}
    payments = _rows(conn, "SELECT * FROM qf3_payments WHERE invoice_id=? ORDER BY id", (inv["id"],))
    paid = round(sum(float(p["amount"]) for p in payments if p["status"] == "confirmed"), 2)
    return {**inv, "client": client, "items": items, **t, "paid": paid,
            "balance": round(t["total"] - paid, 2), "payments": payments}


def list_invoices(conn, status=None):
    sql = "SELECT i.*,c.name AS client_name FROM qf3_invoices i JOIN qf3_clients c ON c.id=i.client_id"
    args = []
    if status:
        sql += " WHERE i.status=?"; args.append(status)
    sql += " ORDER BY i.id DESC"
    return _rows(conn, sql, args)


def get_invoice(conn, iid):
    inv = _row(conn, "SELECT * FROM qf3_invoices WHERE id=?", (int(iid),))
    return invoice_payload(conn, inv) if inv else None


def create_invoice_from_quote(conn, actor, qid, due_days=14):
    q = get_quote(conn, qid)
    if not q:
        raise KeyError("Quote not found.")
    if q["status"] != "accepted":
        raise PermissionError("Only accepted quotes can be invoiced.")
    existing = _row(conn, "SELECT id FROM qf3_invoices WHERE quote_id=? AND status!='void'", (int(qid),))
    if existing:
        raise PermissionError("An active invoice already exists for this quote.")
    stamp = now_iso()
    inv_no = next_number(conn, "invoice_no", "qf3_invoices", "I")
    issue = today()
    due = (date.today() + timedelta(days=int(due_days))).isoformat()
    conn.execute(
        "INSERT INTO qf3_invoices(invoice_no,quote_id,client_id,status,issue_date,due_date,currency,tax_rate,notes,portal_token,portal_expires,created_by,created_at,updated_at) VALUES(?,?,?,'issued',?,?,?,?,?,?,?,?,?,?)",
        (inv_no, int(qid), q["client_id"], issue, due, q["currency"], q["tax_rate"],
         q.get("notes") or "", secrets.token_urlsafe(32),
         (date.today() + timedelta(days=60)).isoformat(), actor, stamp, stamp),
    )
    iid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    for it in q["items"]:
        conn.execute(
            "INSERT INTO qf3_invoice_items(invoice_id,description,qty,unit_price,sort) VALUES(?,?,?,?,?)",
            (iid, it["description"], it["qty"], it["unit_price"], it["sort"]),
        )
    conn.execute("UPDATE qf3_quotes SET status='invoiced',updated_at=? WHERE id=?", (stamp, int(qid)))
    event(conn, "invoice", iid, "create", actor, f"{inv_no} from {q['quote_no']}")
    conn.commit()
    return get_invoice(conn, iid)


def void_invoice(conn, actor, iid, reason=""):
    inv = _row(conn, "SELECT * FROM qf3_invoices WHERE id=?", (int(iid),))
    if not inv:
        raise KeyError("Invoice not found.")
    if inv["status"] == "void":
        raise PermissionError("Invoice is already void.")
    pays = _rows(conn, "SELECT * FROM qf3_payments WHERE invoice_id=? AND status='confirmed'", (int(iid),))
    if pays:
        raise PermissionError("Cannot void an invoice with confirmed payments. Refund or adjust first.")
    conn.execute("UPDATE qf3_invoices SET status='void',void_reason=?,updated_at=? WHERE id=?",
                 (str(reason)[:500], now_iso(), int(iid)))
    event(conn, "invoice", iid, "void", actor, inv["invoice_no"] + " — " + str(reason)[:200])
    conn.commit()
    return get_invoice(conn, iid)


def _refresh_invoice_status(conn, invoice_id):
    inv = invoice_payload(conn, _row(conn, "SELECT * FROM qf3_invoices WHERE id=?", (int(invoice_id),)))
    if inv["status"] in ("void", "draft"):
        return inv
    confirmed = [p for p in inv["payments"] if p["status"] == "confirmed"]
    paid = round(sum(float(p["amount"]) for p in confirmed), 2)
    new = "paid" if inv["total"] > 0 and paid >= inv["total"] - 0.005 else ("part_paid" if paid > 0 else "issued")
    if new != inv["status"]:
        conn.execute("UPDATE qf3_invoices SET status=?,updated_at=? WHERE id=?", (new, now_iso(), int(invoice_id)))
        event(conn, "invoice", invoice_id, f"status_{new}", "system", f"paid {paid} of {inv['total']}")
    return invoice_payload(conn, _row(conn, "SELECT * FROM qf3_invoices WHERE id=?", (int(invoice_id),)))


# --------------------------------------------------------------- payments --

def list_payments(conn, invoice_id=None):
    sql = "SELECT p.*,i.invoice_no,c.name AS client_name FROM qf3_payments p JOIN qf3_invoices i ON i.id=p.invoice_id JOIN qf3_clients c ON c.id=i.client_id"
    args = []
    if invoice_id:
        sql += " WHERE p.invoice_id=?"; args.append(int(invoice_id))
    sql += " ORDER BY p.id DESC"
    return _rows(conn, sql, args)


def record_payment(conn, actor, data, payment_id=None):
    """Record a payment expectation or confirmed receipt.

    status='confirmed' is ONLY allowed here because this function is called
    exclusively from the authenticated admin API (manual confirmation) —
    provider webhooks use confirm_provider_payment() in Phase 4.
    """
    invoice_id = int(data.get("invoice_id") or 0)
    inv = _row(conn, "SELECT * FROM qf3_invoices WHERE id=?", (invoice_id,))
    if not inv or inv["status"] == "void":
        raise KeyError("Invoice not found or void.")
    amount = round(float(data.get("amount") or 0), 2)
    if amount <= 0:
        raise ValueError("Payment amount must be greater than zero.")
    status = str(data.get("status") or "pending")
    if status not in ("pending", "confirmed", "failed", "promise"):
        raise ValueError("Invalid payment status.")
    if status == "promise":
        status = "pending"
    method = str(data.get("method") or "manual")[:40]
    provider = str(data.get("provider") or "manual")[:40]
    provider_ref = str(data.get("provider_ref") or "")[:200]
    note = str(data.get("note") or "")[:2000]
    promise = str(data.get("promise_date") or "")[:10]
    stamp = now_iso()
    if payment_id:
        p = _row(conn, "SELECT * FROM qf3_payments WHERE id=?", (int(payment_id),))
        if not p or int(p["invoice_id"]) != invoice_id:
            raise KeyError("Payment not found.")
        if p["status"] == "confirmed" and status != "confirmed":
            raise PermissionError("A confirmed payment cannot be un-confirmed. Issue a refund/adjustment instead.")
        conn.execute(
            "UPDATE qf3_payments SET amount=?,method=?,provider=?,provider_ref=?,status=?,promise_date=?,note=? WHERE id=?",
            (amount, method, provider, provider_ref, status, promise, note, int(payment_id)),
        )
        pid = payment_id
        action = "update"
        if status == "confirmed" and not p["verified_at"]:
            conn.execute("UPDATE qf3_payments SET verified_by=?,verified_at=? WHERE id=?", (actor, stamp, int(payment_id)))
            action = "confirm"
    else:
        # Duplicate prevention: identical pending/confirmed amount+ref on same invoice is rejected.
        dup = _row(
            conn,
            "SELECT id FROM qf3_payments WHERE invoice_id=? AND amount=? AND provider_ref=? AND status IN ('pending','confirmed')",
            (invoice_id, amount, provider_ref),
        )
        if dup and provider_ref:
            raise PermissionError("A matching payment already exists for this invoice (duplicate prevention).")
        conn.execute(
            "INSERT INTO qf3_payments(invoice_id,amount,method,provider,provider_ref,status,promise_date,note,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (invoice_id, amount, method, provider, provider_ref, status, promise, note, actor, stamp),
        )
        pid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        action = "create" + ("_confirmed" if status == "confirmed" else "")
        if status == "confirmed":
            conn.execute("UPDATE qf3_payments SET verified_by=?,verified_at=? WHERE id=?", (actor, stamp, pid))
            conn.execute(
                "UPDATE qf3_payments SET receipt_no=? WHERE id=?",
                (next_number(conn, "receipt_no", "qf3_payments", "R"), pid),
            )
    event(conn, "payment", pid, action, actor, f"invoice {inv['invoice_no']} · {amount}")
    _refresh_invoice_status(conn, invoice_id)
    conn.commit()
    return {"id": pid, "invoice": get_invoice(conn, invoice_id)}


def confirm_provider_payment(conn, provider_code, provider_ref, invoice_no, amount, actor="webhook"):
    """Phase 4 entry point: only provider-verified events may call this.

    Verifies the invoice exists and is not void, prevents duplicates by
    provider_ref, and records a confirmed payment. Returns payment id or raises.
    """
    inv = _row(conn, "SELECT * FROM qf3_invoices WHERE invoice_no=?", (str(invoice_no),))
    if not inv or inv["status"] == "void":
        raise KeyError("Invoice not found for provider payment.")
    dup = _row(conn, "SELECT id FROM qf3_payments WHERE provider=? AND provider_ref=? AND status='confirmed'",
               (provider_code, str(provider_ref)))
    if dup:
        return dup["id"]  # idempotent: same provider event never double-posts
    data = {"invoice_id": inv["id"], "amount": amount, "method": provider_code,
            "provider": provider_code, "provider_ref": provider_ref, "status": "confirmed",
            "note": "Provider-verified payment"}
    return record_payment(conn, actor, data)["id"]


# ------------------------------------------------------------ receipts -----

def list_receipts(conn):
    return _rows(conn, """
      SELECT p.id,p.receipt_no,p.amount,p.method,p.provider,p.verified_at,p.created_at,
             i.invoice_no,i.client_id,c.name AS client_name
      FROM qf3_payments p
      JOIN qf3_invoices i ON i.id=p.invoice_id
      JOIN qf3_clients c ON c.id=i.client_id
      WHERE p.status='confirmed' ORDER BY p.id DESC""")


# ----------------------------------------------------------------- PDFs ----

def _pdf_bytes(lines):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    y = h - 25 * mm
    c.setFont("Helvetica-Bold", 16)
    c.drawString(20 * mm, y, COMPANY["name"]); y -= 7 * mm
    c.setFont("Helvetica", 9)
    c.drawString(20 * mm, y, f"{COMPANY['reg']}  ·  {COMPANY['descriptor']}  ·  QUOT3FLOW"); y -= 12 * mm
    for size, text in lines:
        if y < 25 * mm:
            c.showPage(); y = h - 25 * mm
        c.setFont("Helvetica-Bold" if size == "h" else "Helvetica", {"h": 12, "b": 10, "n": 9}[size])
        c.drawString(20 * mm, y, text); y -= {"h": 7, "b": 6, "n": 5}[size] * mm
    c.showPage(); c.save()
    return buf.getvalue()


def doc_pdf(conn, kind, doc_id):
    """Return (filename, pdf_bytes) for quote/invoice/receipt views."""
    if kind == "quote":
        q = get_quote(conn, doc_id)
        if not q: raise KeyError("Quote not found.")
        lines = [("h", f"QUOTATION {q['quote_no']}"), ("n", f"Client: {q['client'].get('name','')}  ·  Date: {q['issue_date']}  ·  Valid until: {q['valid_until']}")]
        for it in q["items"]:
            lines.append(("b", f"{it['description']}  —  {it['qty']} x {it['unit_price']:.2f}"))
        t = totals(q["items"], q["tax_rate"])
        lines += [("b", f"Subtotal: {q['currency']} {t['subtotal']:.2f}"),
                  ("b", f"Tax ({q['tax_rate']}%): {q['currency']} {t['tax']:.2f}"),
                  ("h", f"TOTAL: {q['currency']} {t['total']:.2f}")]
        return f"{q['quote_no']}.pdf", _pdf_bytes(lines)
    if kind == "invoice":
        inv = get_invoice(conn, doc_id)
        if not inv: raise KeyError("Invoice not found.")
        lines = [("h", f"TAX INVOICE {inv['invoice_no']}"), ("n", f"Client: {inv['client'].get('name','')}  ·  Issued: {inv['issue_date']}  ·  Due: {inv['due_date']}  ·  Status: {inv['status']}")]
        for it in inv["items"]:
            lines.append(("b", f"{it['description']}  —  {it['qty']} x {it['unit_price']:.2f}"))
        lines += [("b", f"Subtotal: {inv['currency']} {inv['subtotal']:.2f}"),
                  ("b", f"Tax ({inv['tax_rate']}%): {inv['currency']} {inv['tax']:.2f}"),
                  ("h", f"TOTAL: {inv['currency']} {inv['total']:.2f}"),
                  ("b", f"Paid: {inv['currency']} {inv['paid']:.2f}  ·  Balance: {inv['currency']} {inv['balance']:.2f}")]
        return f"{inv['invoice_no']}.pdf", _pdf_bytes(lines)
    if kind == "receipt":
        p = _row(conn, "SELECT * FROM qf3_payments WHERE id=?", (int(doc_id),))
        if not p or p["status"] != "confirmed": raise KeyError("Receipt not found.")
        inv = _row(conn, "SELECT * FROM qf3_invoices WHERE id=?", (p["invoice_id"],))
        lines = [("h", f"RECEIPT {p['receipt_no'] or 'R-' + str(p['id'])}"),
                 ("n", f"Invoice: {inv['invoice_no'] if inv else ''}  ·  Date: {(p['verified_at'] or p['created_at'])[:10]}  ·  Method: {p['method']}"),
                 ("h", f"AMOUNT RECEIVED: {inv['currency'] if inv else 'ZAR'} {p['amount']:.2f}")]
        return f"receipt-{p['id']}.pdf", _pdf_bytes(lines)
    raise ValueError("Unknown document kind.")


# ---------------------------------------------------------------- banking --

def mask_account(number: str) -> str:
    n = str(number or "")
    return ("*" * max(0, len(n) - 4) + n[-4:]) if len(n) > 4 else "****"


def list_bank_accounts(conn, reveal=False):
    rows = _rows(conn, "SELECT * FROM bank_accounts ORDER BY is_default DESC, bank_name, label")
    for r in rows:
        if not reveal:
            r["account_number"] = mask_account(r["account_number"])
    return rows


def save_bank_account(conn, actor, data, account_id=None):
    label = str(data.get("label") or "").strip()
    bank = str(data.get("bank_name") or "").strip()
    number = str(data.get("account_number") or "").strip()
    if not label or not bank:
        raise ValueError("Account label and bank name are required.")
    if not account_id and not number:
        raise ValueError("Account number is required for a new account.")
    stamp = now_iso()
    provider = str(data.get("provider_code") or "manual")[:40]
    prov = _row(conn, "SELECT code FROM payment_providers WHERE code=?", (provider,))
    if not prov:
        provider = "manual"
    is_default = 1 if data.get("is_default") else 0
    if is_default:
        conn.execute("UPDATE bank_accounts SET is_default=0")
    if account_id:
        conn.execute(
            """UPDATE bank_accounts SET label=?,bank_name=?,account_type=?,branch_code=?,account_number=?,currency=?,provider_code=?,is_default=?,active=?,verified=?,updated_at=? WHERE id=?""",
            (label[:120], bank[:120], str(data.get("account_type") or "cheque")[:30],
             str(data.get("branch_code") or "")[:20], number or _row(conn, "SELECT account_number FROM bank_accounts WHERE id=?", (int(account_id),))["account_number"],
             str(data.get("currency") or "ZAR")[:8], provider, is_default,
             1 if data.get("active", True) else 0, 1 if data.get("verified") else 0, stamp, int(account_id)),
        )
        event(conn, "bank_account", account_id, "update", actor, label)
    else:
        conn.execute(
            """INSERT INTO bank_accounts(label,bank_name,account_type,branch_code,account_number,currency,provider_code,is_default,active,verified,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (label[:120], bank[:120], str(data.get("account_type") or "cheque")[:30],
             str(data.get("branch_code") or "")[:20], number[:60], str(data.get("currency") or "ZAR")[:8],
             provider, is_default, 1, 1 if data.get("verified") else 0, stamp, stamp),
        )
        account_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        event(conn, "bank_account", account_id, "create", actor, f"{label} · {bank} · {mask_account(number)}")
    conn.commit()
    return account_id


def list_providers(conn):
    return _rows(conn, "SELECT code,display_name,kind,active,created_at FROM payment_providers ORDER BY display_name")


def portal_doc(conn, token):
    """Public portal payload for a quote token."""
    q = _row(conn, "SELECT * FROM qf3_quotes WHERE portal_token=?", (str(token),))
    if q:
        payload = quote_payload(conn, q)
        payload["kind"] = "quote"
        return payload
    inv = _row(conn, "SELECT * FROM qf3_invoices WHERE portal_token=?", (str(token),))
    if inv:
        payload = invoice_payload(conn, inv)
        payload["kind"] = "invoice"
        return payload
    return None
