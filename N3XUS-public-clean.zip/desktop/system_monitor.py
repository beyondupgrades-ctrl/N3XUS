"""Read-only operational health checks for the local Beyond Registration service."""
from __future__ import annotations

import sqlite3
import shutil
from datetime import datetime
from pathlib import Path


class SystemMonitor:
    def __init__(self, connection: sqlite3.Connection, data_home: Path, backup_dir: Path):
        self.connection = connection
        self.data_home = Path(data_home)
        self.backup_dir = Path(backup_dir)

    def snapshot(self, camera_relay_running: bool = False) -> dict:
        try:
            integrity = str(self.connection.execute("PRAGMA quick_check").fetchone()[0])
        except sqlite3.Error:
            integrity = "unavailable"

        try:
            free_bytes = shutil.disk_usage(self.data_home if self.data_home.exists() else self.data_home.parent).free
        except OSError:
            free_bytes = None

        backup_files = []
        try:
            backup_files = [item for item in self.backup_dir.iterdir() if item.is_file() and item.suffix.lower() in (".zip", ".db")]
        except OSError:
            pass
        latest = max(backup_files, key=lambda item: item.stat().st_mtime, default=None)
        latest_at = datetime.fromtimestamp(latest.stat().st_mtime).astimezone().isoformat(timespec="minutes") if latest else ""

        return {
            "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "database": {"status": "healthy" if integrity == "ok" else "check", "integrity": integrity},
            "storage": {"free_bytes": free_bytes},
            "backups": {"count": len(backup_files), "latest_at": latest_at},
            "camera_relay": "running" if camera_relay_running else "stopped",
            "weather": {"status": "not_configured", "message": "Company location and a licensed weather provider are required."},
            "autonomy": {"status": "paused", "global_pause": True, "execution_enabled": False, "level": 0},
        }