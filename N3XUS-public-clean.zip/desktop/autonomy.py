"""Autonomy levels for the NEXUS ecosystem (100% free, in-house).

Level 1 - Read only: observe and report, never act.
Level 2 - Prepare: create drafts, never save or send.
Level 3 - Auto-approve routine: execute low-risk actions automatically,
          queue anything unusual for human review.
Level 4 - Restricted: human only (money movement, deletes, permission changes).

The default is Level 2 (safe). The owner raises it via settings when ready.
"""
from __future__ import annotations

# Actions considered routine (low-risk) and safe to auto-execute at Level 3+.
ROUTINE_ACTIONS = {
    "quote_followup", "invoice_reminder", "stale_pending",
    "attendance_rebuild", "nightly_backup", "weekly_report",
    "leave_auto_approve", "payslip_draft",
}

# Actions that ALWAYS require a human, regardless of level.
HUMAN_ONLY = {
    "payment_release", "void_invoice", "delete_record",
    "banking_change", "permission_change", "salary_finalize",
}


def level_for(service):
    try:
        row = service.store.conn.execute(
            "SELECT value FROM attendance_settings WHERE key='autonomy_level'").fetchone()
        if row and row["value"]:
            return int(row["value"])
    except Exception:
        pass
    return 2


def set_level(service, level):
    level = max(1, min(4, int(level)))
    service.store.conn.execute(
        "INSERT INTO attendance_settings(key,value) VALUES('autonomy_level',?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(level),))
    service.store.conn.commit()
    service.store.log("system", "Autonomy level changed", "autonomy", 0, "level=" + str(level))
    service.store.conn.commit()
    return level


def is_routine(action_type):
    return action_type in ROUTINE_ACTIONS


def should_auto_execute(service, action_type):
    if action_type in HUMAN_ONLY:
        return False
    lvl = level_for(service)
    if lvl < 3:
        return False
    return is_routine(action_type)


def status(service):
    lvl = level_for(service)
    names = {1: "Read only", 2: "Prepare (default)", 3: "Auto-approve routine", 4: "Restricted (human only)"}
    return {"level": lvl, "name": names.get(lvl, "Unknown"),
            "routine_actions": sorted(ROUTINE_ACTIONS),
            "human_only": sorted(HUMAN_ONLY)}