"""POPIA/GDPR consent register (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS consent_records(
  id INTEGER PRIMARY KEY AUTOINCREMENT, subject_type TEXT NOT NULL, subject_id INTEGER NOT NULL,
  consent_type TEXT NOT NULL, granted INTEGER NOT NULL DEFAULT 0, granted_at TEXT DEFAULT '',
  granted_by TEXT DEFAULT '', withdrawn_at TEXT DEFAULT '', notes TEXT DEFAULT '',
  created_at TEXT NOT NULL);
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def grant(conn, subject_type, subject_id, consent_type, granted_by="", notes=""):
    cur = conn.execute("INSERT INTO consent_records(subject_type,subject_id,consent_type,granted,granted_at,granted_by,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",
                       (subject_type, subject_id, consent_type, 1, date.today().isoformat(), granted_by, notes, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def withdraw(conn, cid, withdrawn_by=""):
    conn.execute("UPDATE consent_records SET granted=0, withdrawn_at=?, notes=notes||' Withdrawn by '||? WHERE id=?",
                 (date.today().isoformat(), withdrawn_by, cid))
    conn.commit()


def list_for(conn, subject_type, subject_id):
    return [dict(r) for r in conn.execute("SELECT * FROM consent_records WHERE subject_type=? AND subject_id=? ORDER BY id DESC", (subject_type, subject_id)).fetchall()]


def all_consents(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM consent_records ORDER BY id DESC").fetchall()]