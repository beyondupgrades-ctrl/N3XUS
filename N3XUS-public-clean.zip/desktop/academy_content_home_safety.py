"""EVOLV3 knowledge content: home-safety pack (expanded).

Plain-English fact and mini emergency cards for staff and family about
keeping a home safe for vulnerable people.
"""

from __future__ import annotations

PACK = "home_safety"

DISCLAIMER = (
    "EVOLV3 teaches general awareness so you can act with confidence. It is not "
    "medical advice and does not replace a doctor, nurse or emergency dispatcher. "
    "When in doubt, call for help early."
)

EMERGENCY_NUMBERS = [
    {"label": "Ambulance (landline)", "number": "10177", "tel": "10177",
     "note": "State ambulance service."},
    {"label": "Emergency (any cellphone)", "number": "112", "tel": "112",
     "note": "Free from any cellphone, even without airtime."},
    {"label": "Police", "number": "10111", "tel": "10111",
     "note": "Crime, abuse and missing-person reports."},
    {"label": "Poison helpline", "number": "0861 555 777", "tel": "0861555777",
     "note": "24-hour poisons information, Tygerberg."},
    {"label": "Fire", "number": "10177", "tel": "10177",
     "note": "Fire and rescue services."},
]

CARDS = [
    {
        "slug": "hs-falls-most-common",
        "kind": "fact", "category": "Falls",
        "title": "Falls are the most common home accident",
        "teaser": "One in three older adults falls each year.",
        "body": (
            "Falls are the leading cause of injury at home, especially for older "
            "adults. Most falls happen in the bathroom, bedroom and on stairs. "
            "Good lighting, clear floors and grab rails prevent more falls than any "
            "medicine. A single fall can lead to a hip fracture, loss of "
            "independence and fear of moving, which makes the next fall more "
            "likely. Preventing falls is one of the highest-value things a carer "
            "can do."
        ),
        "tip": "Walk through the home once a month and remove one trip hazard each time.",
        "icon": "🚶", "minutes": 2,
    },
    {
        "slug": "hs-trip-hazards",
        "kind": "fact", "category": "Falls",
        "title": "Common trip hazards",
        "teaser": "Rugs, cords and clutter cause most falls.",
        "body": (
            "Loose rugs, trailing electrical cords, wet floors, poor lighting and "
            "clutter on stairs cause most home falls. Secure rugs with non-slip "
            "backing, tape cords along walls, wipe spills immediately and keep "
            "stairs clear. Shoes that fit well and have non-slip soles matter too. "
            "Pets underfoot are a frequent cause of falls."
        ),
        "tip": "Remove or secure every loose rug today - it takes five minutes.",
        "icon": "🧹", "minutes": 1,
    },
    {
        "slug": "hs-bathroom-safety",
        "kind": "fact", "category": "Falls",
        "title": "Bathroom safety",
        "teaser": "Wet surfaces and standing up are the danger.",
        "body": (
            "The bathroom is the most dangerous room. Install grab rails by the "
            "toilet and in the shower, use a non-slip mat, keep a night light on, "
            "and never leave a frail person alone in the bath. A shower chair and "
            "hand-held shower help a lot. Raised toilet seats and bath boards "
            "reduce the effort of standing."
        ),
        "tip": "Put a non-slip mat in the bath and a grab rail within arm's reach.",
        "icon": "🚿", "minutes": 2,
    },
    {
        "slug": "hs-medication-storage",
        "kind": "fact", "category": "Medication",
        "title": "Store medicines safely",
        "teaser": "Locked, labelled, out of reach of children.",
        "body": (
            "Keep all medicines in a locked cupboard, in original containers with "
            "labels. Keep them away from heat and moisture. Never store medicines "
            "in the bathroom cabinet if children visit. Check expiry dates twice a "
            "year and return old medicines to a pharmacy. Never share prescription "
            "medicine between people."
        ),
        "tip": "Do a medicine cupboard clear-out every six months.",
        "icon": "💊", "minutes": 1,
    },
    {
        "slug": "hs-fire-safety",
        "kind": "fact", "category": "Fire",
        "title": "Fire safety basics",
        "teaser": "Smoke alarms, escape plan, never smoke in bed.",
        "body": (
            "Most fatal home fires start at night. Install smoke alarms on every "
            "level and test them monthly. Have a written escape plan and practise "
            "it. Never smoke in bed, never leave cooking unattended, and keep "
            "matches and lighters away from children. A fire blanket and small "
            "extinguisher in the kitchen help."
        ),
        "tip": "Test every smoke alarm today and replace batteries once a year.",
        "icon": "🔥", "minutes": 2,
    },
    {
        "slug": "hs-electrical-safety",
        "kind": "fact", "category": "Electrical",
        "title": "Electrical safety",
        "teaser": "Overloaded plugs and damaged cords start fires.",
        "body": (
            "Do not overload multi-plugs. Replace frayed cords. Keep appliances "
            "away from water. Unplug heaters when not in use. If a plug feels hot "
            "or sparks, stop using it and call an electrician. Never run cords "
            "under carpets. Water and electricity never mix."
        ),
        "tip": "Check every multi-plug today: one plug per socket, no daisy chains.",
        "icon": "🔌", "minutes": 1,
    },
    {
        "slug": "hs-poison-prevention",
        "kind": "fact", "category": "Poisoning",
        "title": "Poison prevention",
        "teaser": "Cleaning products and medicines look like drinks to a child.",
        "body": (
            "Store cleaning products, pesticides and medicines locked away and in "
            "original containers - never in drink bottles. Keep the poison "
            "helpline number (0861 555 777) on the fridge. Never mix cleaning "
            "chemicals; bleach plus acid cleaners release toxic gas. Even a "
            "mouthful can be dangerous for a small child."
        ),
        "tip": "Move all cleaning products to a locked cupboard at child height or above.",
        "icon": "☠️", "minutes": 2,
    },
    {
        "slug": "hs-water-safety",
        "kind": "fact", "category": "Water",
        "title": "Water safety at home",
        "teaser": "A bucket of water can drown a toddler.",
        "body": (
            "Empty buckets, baths and basins immediately after use. Never leave a "
            "young child or a frail adult alone near water, even for a minute. "
            "Cover or fence pools and ponds. Check that the geyser temperature "
            "is not scalding. Drowning is silent - there is usually no splashing."
        ),
        "tip": "Empty the bath and buckets the moment you are done with them.",
        "icon": "💧", "minutes": 1,
    },
    {
        "slug": "hs-kitchen-safety",
        "kind": "fact", "category": "Kitchen",
        "title": "Kitchen safety",
        "teaser": "Turn pot handles inward and keep knives out of reach.",
        "body": (
            "Turn pot handles toward the back of the stove. Keep hot drinks away "
            "from table edges. Store knives and sharp tools out of reach of "
            "children. Clean grease from the stove - grease fires spread fast. "
            "Keep a fire blanket within reach and know how to use it."
        ),
        "tip": "Make 'handles inward' a habit every time you cook.",
        "icon": "🍳", "minutes": 1,
    },
    {
        "slug": "hs-first-aid-kit",
        "kind": "fact", "category": "Preparedness",
        "title": "A home first-aid kit",
        "teaser": "Keep it stocked, in date, and easy to find.",
        "body": (
            "A basic kit: plasters, sterile dressings, bandages, antiseptic, "
            "disposable gloves, scissors, tweezers, a digital thermometer and a "
            "first-aid guide. Check it every six months and replace used or "
            "expired items. Keep it where everyone can find it, and tell everyone "
            "where it is."
        ),
        "tip": "Put the kit in the same place in every home you care for.",
        "icon": "🩹", "minutes": 1,
    },
    {
        "slug": "hs-night-safety",
        "kind": "fact", "category": "Falls",
        "title": "Night-time safety",
        "teaser": "Most falls happen getting up at night.",
        "body": (
            "Keep a night light on the path from bed to bathroom. Clear the floor "
            "of slippers and cords. Keep a torch next to the bed in case of power "
            "cuts. Encourage the person to sit on the edge of the bed before "
            "standing. A bedside commode can prevent risky night trips."
        ),
        "tip": "Put a motion-sensor night light in the hallway tonight.",
        "icon": "🌙", "minutes": 1,
    },
    {
        "slug": "hs-security",
        "kind": "fact", "category": "Security",
        "title": "Home security basics",
        "teaser": "Locks, lights and neighbours.",
        "body": (
            "Lock doors and windows at night and when out. Keep outside lights on. "
            "Know your neighbours and share contact numbers. Do not hide spare "
            "keys outside. If you feel unsafe, call 10111 and keep the number "
            "handy. A simple check-in routine with a neighbour costs nothing."
        ),
        "tip": "Agree a simple check-in routine with a neighbour.",
        "icon": "🔒", "minutes": 1,
    },
]

# Emergency cards
CARDS += [
    {
        "slug": "hs-choking-child",
        "kind": "emergency", "category": "Airway",
        "title": "Choking: baby or small child",
        "teaser": "Back blows and chest thrusts - never abdominal thrusts on a baby.",
        "body": (
            "For a baby under one year, give up to 5 back blows then up to 5 "
            "chest thrusts, alternating. For a child over one, use the same "
            "5-and-5 as an adult but gentler. Call 112 if the object does not "
            "clear. Never do a blind finger sweep."
        ),
        "steps": [
            "If the child can cough or cry, encourage coughing and stay close.",
            "If they cannot breathe, call 112 or 10177 on speaker.",
            "Baby under 1 year: lay face-down along your forearm, head lower than chest, and give 5 firm back blows between the shoulder blades.",
            "Turn the baby over and give 5 chest thrusts with two fingers in the centre of the chest.",
            "Alternate 5 back blows and 5 chest thrusts until the object clears.",
            "Child over 1 year: use 5 back blows then 5 abdominal thrusts (gentler than for an adult).",
            "If they become unconscious, start CPR and call 112.",
        ],
        "call": "Call 112 or 10177 if the child cannot breathe.",
        "icon": "👶", "minutes": 3,
    },
    {
        "slug": "hs-drowning",
        "kind": "emergency", "category": "Water",
        "title": "Drowning",
        "teaser": "Get them out, check breathing, start CPR if needed.",
        "body": (
            "Drowning is silent. Get the person out of the water as fast as you "
            "can, call for help, and check breathing. Start CPR if they are not "
            "breathing. Even if they seem fine, they need a hospital check - "
            "water in the lungs can cause problems hours later."
        ),
        "steps": [
            "Get the person out of the water without putting yourself in danger.",
            "Call 112 or 10177 on speaker.",
            "Check breathing and responsiveness for no more than 10 seconds.",
            "If not breathing normally, start CPR: 30 compressions, then 2 breaths.",
            "If breathing, place them in the recovery position and keep them warm.",
            "Everyone who was submerged needs a hospital check, even if they feel fine.",
        ],
        "call": "Call 112 or 10177 immediately.",
        "icon": "🏊", "minutes": 2,
    },
    {
        "slug": "hs-electric-shock-home",
        "kind": "emergency", "category": "Electrical",
        "title": "Electric shock at home",
        "teaser": "Switch off the power before you touch anyone.",
        "body": (
            "Never touch a person still in contact with electricity. Switch off "
            "the mains first. Then check breathing and start CPR if needed. "
            "Anyone who has had a shock needs a doctor, even if they feel fine - "
            "internal injuries can be hidden."
        ),
        "steps": [
            "Do not touch the person while they are in contact with the electrical source.",
            "Switch off the mains at the distribution board if you can reach it safely.",
            "Otherwise move the source with a dry wooden object.",
            "Call 112 or 10177.",
            "Check breathing and responsiveness. Start CPR if not breathing normally.",
            "Cool any burns with running water for 20 minutes.",
            "Everyone who has had an electric shock must be checked by a doctor.",
        ],
        "call": "Call 112 or 10177 after the power is off.",
        "icon": "⚡", "minutes": 2,
    },
    {
        "slug": "hs-poisoning-child",
        "kind": "emergency", "category": "Poisoning",
        "title": "A child may have swallowed something",
        "teaser": "Do not make them vomit. Call the poisons line.",
        "body": (
            "Do not induce vomiting. Call the 24-hour Poisons Information "
            "Helpline on 0861 555 777 or 112. Keep the container and note how "
            "much was taken and when. If they become drowsy, place them in the "
            "recovery position. Even a mouthful can be dangerous for a small child."
        ),
        "steps": [
            "Move the child away from the substance and check they are breathing.",
            "Do not make them vomit.",
            "Call 0861 555 777 (poisons) or 112 for advice.",
            "Keep the container or packet to read the label to the adviser.",
            "Note roughly how much was taken and when.",
            "If they become drowsy or unconscious, place them in the recovery position and call 112.",
            "Take the container with you to the hospital.",
        ],
        "call": "Call 0861 555 777 (poisons) or 112.",
        "icon": "☠️", "minutes": 2,
    },
    {
        "slug": "hs-burns-home",
        "kind": "emergency", "category": "Burns",
        "title": "Burns at home",
        "teaser": "Cool for 20 minutes. No ice, butter or toothpaste.",
        "body": (
            "Cool the burn under cool running water for a full 20 minutes. Remove "
            "rings and watches before swelling. Cover with cling film or a clean "
            "non-stick dressing. Never use ice, butter, oil or toothpaste. Cool "
            "water limits the damage and the pain."
        ),
        "steps": [
            "Stop the burning: remove the person from the source and put out flames.",
            "Cool the burn under cool running water for 20 minutes.",
            "Remove rings, watches and tight clothing near the burn before it swells.",
            "Do not burst blisters and do not apply ice, butter, oil or toothpaste.",
            "Cover loosely with cling film or a clean non-stick dressing.",
            "Call 112 or 10177 for burns bigger than the person's palm, or any burn on the face, hands, feet, genitals or airway.",
            "Keep the person warm - cooling a large burn can make them dangerously cold.",
        ],
        "call": "Call 112 or 10177 for large, deep, facial or airway burns.",
        "icon": "🔥", "minutes": 2,
    },
    {
        "slug": "hs-fall-older-adult",
        "kind": "emergency", "category": "Falls",
        "title": "An older adult has fallen",
        "teaser": "Do not rush to lift them. Check first.",
        "body": (
            "Lifting someone with a broken hip can cause severe damage. If the leg "
            "looks shortened or turned outward, or they cannot bear weight, keep "
            "them still and call an ambulance. Keep them warm and calm until help "
            "arrives. Do not give food or drink in case surgery is needed."
        ),
        "steps": [
            "Do not move the person. Kneel beside them and reassure them.",
            "Ask what hurts and check for bleeding, head injury and confusion.",
            "If a hip or leg fracture is possible, keep the leg supported in the position found.",
            "Call 112 or 10177 and describe the fall and the injury.",
            "Cover them with a blanket to prevent shock, and keep talking calmly.",
            "Do not give food or drink in case surgery is needed.",
            "If they are unhurt and can get up safely, help them to a chair slowly.",
        ],
        "call": "Call 112 or 10177 for a suspected hip or leg fracture.",
        "icon": "🦴", "minutes": 2,
    },
    {
        "slug": "hs-fire-evacuation",
        "kind": "emergency", "category": "Fire",
        "title": "Fire at home: get out, stay out",
        "teaser": "Close doors behind you and never go back in.",
        "body": (
            "Smoke kills faster than flames. Get everyone out, stay low under "
            "smoke, and close doors behind you to slow the fire. Call 10177 once "
            "you are outside. Never go back inside for belongings. Plan an escape "
            "route in advance."
        ),
        "steps": [
            "Raise the alarm and get everyone moving towards the nearest safe exit.",
            "Stay low under smoke and cover the nose and mouth with a cloth.",
            "Close doors behind you to slow the spread.",
            "Do not use lifts. Help anyone who needs support, but do not delay the group.",
            "Get to the meeting point and count everyone.",
            "Call 10177 from outside.",
            "Never go back inside. Tell the fire service if someone is missing.",
        ],
        "call": "Call 10177 once you are safely outside.",
        "icon": "🚒", "minutes": 2,
    },
    {
        "slug": "hs-heat-stroke-home",
        "kind": "emergency", "category": "Heat",
        "title": "Heat stroke",
        "teaser": "Hot, dry and confused is an emergency.",
        "body": (
            "Heat stroke is a body temperature over about 40 C with confusion, "
            "hot dry skin or collapse. It is life-threatening. Move the person "
            "out of the heat, cool them actively with water and fanning, and call "
            "an ambulance. Older adults and the very young are most at risk."
        ),
        "steps": [
            "Move the person to shade or a cool room immediately.",
            "Call 112 or 10177 - heat stroke is life-threatening.",
            "Remove unnecessary clothing.",
            "Cool actively: wet the skin with cool water and fan it. Place cool packs at the neck, armpits and groin.",
            "Do not use ice-cold water or alcohol rubs.",
            "Give small sips of water only if fully awake and alert.",
            "If they become drowsy, place them in the recovery position and monitor breathing.",
        ],
        "call": "Call 112 or 10177 immediately.",
        "icon": "🌡️", "minutes": 2,
    },
]

QUIZZES = [
    {
        "slug": "hs-q-falls",
        "question": "Which is the most common cause of falls at home?",
        "options": ["Loose rugs and clutter", "Bad weather", "Loud music", "Bright colours"],
        "correct": 0,
        "explanation": "Loose rugs, trailing cords and clutter cause most home falls. Remove or secure them.",
        "icon": "🚶",
    },
    {
        "slug": "hs-q-poison",
        "question": "You think a child swallowed cleaning liquid. What should you NOT do?",
        "options": ["Call the poisons helpline", "Keep the container", "Make them vomit", "Note how much was taken"],
        "correct": 2,
        "explanation": "Never make someone vomit. Call 0861 555 777 or 112 and keep the container.",
        "icon": "☠️",
    },
    {
        "slug": "hs-q-burns",
        "question": "What is the correct first aid for a burn?",
        "options": ["Butter and a bandage", "Ice directly on the skin", "Cool running water for 20 minutes", "Toothpaste"],
        "correct": 2,
        "explanation": "Cool running water for a full 20 minutes. Never use ice, butter, oil or toothpaste.",
        "icon": "🔥",
    },
    {
        "slug": "hs-q-fire",
        "question": "During a house fire you should:",
        "options": ["Go back in for valuables", "Stay low under smoke and close doors", "Use the lift", "Open all windows"],
        "correct": 1,
        "explanation": "Stay low under smoke, close doors behind you, get out and stay out. Call 10177 from outside.",
        "icon": "🚒",
    },
    {
        "slug": "hs-q-medicines",
        "question": "Where should medicines be stored?",
        "options": ["In a drink bottle on the counter", "In a locked cupboard in original containers", "In the bathroom cabinet", "In a child's reach"],
        "correct": 1,
        "explanation": "Locked cupboard, original containers, out of reach of children. Check expiry dates twice a year.",
        "icon": "💊",
    },
    {
        "slug": "hs-q-electric",
        "question": "Someone is in contact with live electricity. What do you do first?",
        "options": ["Pull them away with your hands", "Switch off the mains", "Pour water on them", "Shout at them to let go"],
        "correct": 1,
        "explanation": "Never touch them. Switch off the mains first, then check breathing and call 112.",
        "icon": "⚡",
    },
    {
        "slug": "hs-q-drowning",
        "question": "After a near-drowning, even if the person feels fine, you should:",
        "options": ["Send them home", "Give them a big meal", "Take them to hospital for a check", "Let them sleep it off"],
        "correct": 2,
        "explanation": "Everyone who was submerged needs a hospital check, even if they feel fine.",
        "icon": "🏊",
    },
    {
        "slug": "hs-q-emergency",
        "question": "Which number reaches an ambulance from any South African cellphone, even with no airtime?",
        "options": ["10111", "112", "10177", "0861 555 777"],
        "correct": 1,
        "explanation": "112 works from any cellphone, even without airtime.",
        "icon": "📞",
    },
]
