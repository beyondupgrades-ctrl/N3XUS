"""Incident reporting with photos (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
  location TEXT DEFAULT '', severity TEXT DEFAULT 'Medium', status TEXT DEFAULT 'Open',
  reporter TEXT DEFAULT '', photo_name TEXT DEFAULT '', photo_path TEXT DEFAULT '',
  created_at TEXT NOT NULL, resolved_at TEXT DEFAULT '');
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_incidents(conn, status=None):
    sql = "SELECT * FROM incidents"
    args = []
    if status:
        sql += " WHERE status=?"; args.append(status)
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def report(conn, title, description="", location="", severity="Medium", reporter="", photo_name="", photo_path=""):
    cur = conn.execute("INSERT INTO incidents(title,description,location,severity,status,reporter,photo_name,photo_path,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                       (title, description, location, severity, "Open", reporter, photo_name, photo_path, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def resolve(conn, iid, resolved_by=""):
    conn.execute("UPDATE incidents SET status='Resolved', resolved_at=? WHERE id=?", (date.today().isoformat(), iid))
    conn.commit()