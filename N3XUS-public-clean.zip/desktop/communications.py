﻿"""VOIC3 in-house communication connector.

Delivers internal messages and payslip PDFs inside the app. Secrets are protected
with Windows DPAPI when running on Windows. On non-Windows platforms secrets remain
in process memory only; the production desktop target is Windows.
No external messaging service or paid API is used.
"""
from __future__ import annotations

import base64
import ctypes
import hashlib
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any


class SecretVault:
    def __init__(self, path: Path):
        self.path = Path(path)
        self._memory: dict[str, Any] = {}
        self._lock = threading.RLock()

    @staticmethod
    def _dpapi(data: bytes, protect: bool) -> bytes:
        if os.name != "nt":
            raise RuntimeError("Persistent credential protection is available in the Windows desktop build only.")
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.c_ulong), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        blob_ptr = ctypes.POINTER(DATA_BLOB)
        crypt32.CryptProtectData.argtypes = [blob_ptr, ctypes.c_wchar_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, blob_ptr]
        crypt32.CryptProtectData.restype = ctypes.c_int
        crypt32.CryptUnprotectData.argtypes = [blob_ptr, ctypes.POINTER(ctypes.c_wchar_p), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, blob_ptr]
        crypt32.CryptUnprotectData.restype = ctypes.c_int
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        kernel32.LocalFree.restype = ctypes.c_void_p
        source_buf = ctypes.create_string_buffer(data)
        source = DATA_BLOB(len(data), ctypes.cast(source_buf, ctypes.POINTER(ctypes.c_ubyte)))
        output = DATA_BLOB()
        flags = 0x1  # CRYPTPROTECT_UI_FORBIDDEN
        if protect:
            ok = crypt32.CryptProtectData(ctypes.byref(source), "Beyond Registration communications", None, None, None, flags, ctypes.byref(output))
        else:
            ok = crypt32.CryptUnprotectData(ctypes.byref(source), None, None, None, None, flags, ctypes.byref(output))
        if not ok:
            raise OSError("Windows credential protection failed.")
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(output.pbData)

    def read_all(self) -> dict[str, Any]:
        with self._lock:
            if os.name != "nt":
                return dict(self._memory)
            if not self.path.exists():
                return {}
            raw = self._dpapi(self.path.read_bytes(), False)
            value = json.loads(raw.decode("utf-8"))
            return value if isinstance(value, dict) else {}

    def write_all(self, value: dict[str, Any]) -> None:
        with self._lock:
            if os.name != "nt":
                self._memory = dict(value)
                return
            self.path.parent.mkdir(parents=True, exist_ok=True)
            raw = json.dumps(value, ensure_ascii=False).encode("utf-8")
            protected = self._dpapi(raw, True)
            temp = self.path.with_suffix(".tmp")
            temp.write_bytes(protected)
            os.replace(temp, self.path)

    def get(self, key: str, default=None):
        return self.read_all().get(key, default)

    def set(self, key: str, value: Any) -> None:
        all_values = self.read_all()
        if value is None or value == "":
            all_values.pop(key, None)
        else:
            all_values[key] = value
        self.write_all(all_values)


class CommunicationsService:
    """VOIC3 in-house communication connector (no external service or paid API)."""

    def __init__(self, data_home: Path):
        self.data_home = Path(data_home)
        self.config_path = self.data_home / "communications_config.json"
        self.vault = SecretVault(self.data_home / "communications.vault")
        self.lock = threading.RLock()
        self.config = {"delivery_mode": "in_app"}
        try:
            saved = json.loads(self.config_path.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                self.config.update({k: str(saved.get(k, "")) for k in self.config})
        except (OSError, ValueError, TypeError):
            pass

    def save_config(self, payload: dict) -> dict:
        return self.public_config()

    def public_config(self) -> dict:
        return {
            **self.config,
            "delivery_mode": "in_app",
            "secure_vault": "Windows DPAPI" if os.name == "nt" else "session memory (development only)",
        }

    def status(self) -> dict:
        return {"config": self.public_config(), "connected": True, "provider": "VOIC3 in-house"}

    def disconnect(self, provider: str):
        return {"ok": True}
