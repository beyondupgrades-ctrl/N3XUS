"""Read a local ONVIF camera stream address. No cloud account is used."""
from __future__ import annotations

import base64
import hashlib
import os
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

DEVICE_NS = "http://www.onvif.org/ver10/device/wsdl"
MEDIA_NS = "http://www.onvif.org/ver10/media/wsdl"
SCHEMA_NS = "http://www.onvif.org/ver10/schema"
WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
WSU = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _text(element: ET.Element, name: str) -> str:
    for child in element.iter():
        if _local(child.tag) == name and child.text and child.text.strip():
            return child.text.strip()
    return ""


def choose_profile_token(payload: str) -> str:
    """Prefer the smallest H.264 profile. The desktop player can show that stream."""
    try:
        root = ET.fromstring(payload)
    except ET.ParseError:
        root = ET.fromstring(f"<ProfilesResponse>{payload}</ProfilesResponse>")
    ranked = []
    for profile in root.iter():
        if _local(profile.tag) != "Profiles":
            continue
        token = profile.attrib.get("token") or _text(profile, "token")
        if not token:
            continue
        encoding = ""
        width = 10**9
        for child in profile.iter():
            if _local(child.tag) == "Encoding" and child.text:
                encoding = child.text.strip().upper()
            if _local(child.tag) == "Width" and (child.text or "").strip().isdigit():
                width = min(width, int(child.text.strip()))
        ranked.append((0 if encoding == "H264" else 1, width, token))
    if not ranked:
        return ""
    ranked.sort()
    return ranked[0][2]


def _security_header(username: str, password: str) -> str:
    nonce = os.urandom(16)
    created = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    digest = base64.b64encode(hashlib.sha1(nonce + created.encode("utf-8") + password.encode("utf-8")).digest()).decode("ascii")
    nonce_b64 = base64.b64encode(nonce).decode("ascii")
    safe_user = (username or "").replace("&", "&amp;").replace("<", "&lt;")
    return (
        f'<Security s:mustUnderstand="1" xmlns="{WSSE}">'
        f"<UsernameToken><Username>{safe_user}</Username>"
        f'<Password Type="{WSSE}#PasswordDigest">{digest}</Password>'
        f'<Nonce EncodingType="{WSSE}#Base64Binary">{nonce_b64}</Nonce>'
        f'<Created xmlns="{WSU}">{created}</Created>'
        f"</UsernameToken></Security>"
    )


def _envelope(username: str, password: str, body: str) -> bytes:
    header = _security_header(username, password) if username or password else ""
    return (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">'
        f"<s:Header>{header}</s:Header><s:Body>{body}</s:Body></s:Envelope>"
    ).encode("utf-8")


def _post(url: str, username: str, password: str, body: str, timeout: float) -> str:
    request = Request(url, data=_envelope(username, password, body), method="POST")
    request.add_header("Content-Type", "application/soap+xml; charset=utf-8")
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.read().decode("utf-8", errors="replace")
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise ConnectionError(detail[:300] or str(exc)) from exc


def _media_address(device_url: str, capabilities: str) -> str:
    root = ET.fromstring(capabilities)
    for element in root.iter():
        if _local(element.tag) == "XAddr" and element.text and "media" in element.text.lower():
            return element.text.strip()
    parsed = urlsplit(device_url)
    return f"{parsed.scheme}://{parsed.netloc}/onvif/media_service"


def _stream_uri(payload: str) -> str:
    root = ET.fromstring(payload)
    for element in root.iter():
        if _local(element.tag) == "Uri" and element.text and element.text.strip().lower().startswith("rtsp://"):
            return element.text.strip()
    return ""


def onvif_stream_url(host: str, username: str = "", password: str = "", timeout: float = 3) -> str:
    """Return the camera's own RTSP address from ONVIF, or an empty string."""
    host = str(host or "").strip()
    if not host:
        return ""
    device_urls = (f"http://{host}/onvif/device_service", f"http://{host}:8000/onvif/device_service")
    capabilities_body = f'<GetCapabilities xmlns="{DEVICE_NS}"><Category>Media</Category></GetCapabilities>'
    profiles_body = f'<GetProfiles xmlns="{MEDIA_NS}"/>'
    for device_url in device_urls:
        try:
            capabilities = _post(device_url, username, password, capabilities_body, timeout)
            media_url = _media_address(device_url, capabilities)
            profiles = _post(media_url, username, password, profiles_body, timeout)
            token = choose_profile_token(profiles)
            if not token:
                continue
            safe_token = token.replace("&", "&amp;").replace("<", "&lt;")
            stream_body = (
                f'<GetStreamUri xmlns="{MEDIA_NS}"><StreamSetup>'
                f'<Stream xmlns="{SCHEMA_NS}">RTP-Unicast</Stream>'
                f'<Transport xmlns="{SCHEMA_NS}"><Protocol>RTSP</Protocol></Transport>'
                f"</StreamSetup><ProfileToken>{safe_token}</ProfileToken></GetStreamUri>"
            )
            uri = _stream_uri(_post(media_url, username, password, stream_body, timeout))
            if uri:
                return uri
        except (ConnectionError, ET.ParseError, TimeoutError, URLError, OSError):
            continue
    return ""
