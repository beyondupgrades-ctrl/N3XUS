"""Test employee sign-in on both addresses: LAN and the live public tunnel.

Run on C: only. Nothing is written except two small files:
  proof\\server_proof.json   raw status codes and cookie names per address
  (a set of phone screenshots taken separately with adb)

What it proves:
  1. /api/login and /api/mobile/login accept the test password on this server;
  2. the same session cookie is accepted on the LAN address AND on the public
     tunnel address, i.e. the session carries over with no second sign-in;
  3. every authenticated /api/mobile/* dashboard call answers 200 on both.

The cookie is sent as the app's own cookie would be, without a Domain attribute,
so a host-only cookie is re-sent to both hosts exactly as a browser or the
Android app would re-send it.
"""
from __future__ import annotations

import json
import ssl
import sys
import time
import urllib.error
import urllib.request
from http.cookies import SimpleCookie
from pathlib import Path

CTX = ssl._create_unverified_context()
OUT = Path(__file__).resolve().parent / "proof"
OUT.mkdir(exist_ok=True)

PASSWORD = sys.argv[1] if len(sys.argv) > 1 else "0000"
LAN = "https://YOUR_SERVER_IP:64281"
DASHBOARD = [
    "/api/mobile/app-version",
    "/api/mobile/people",
    "/api/mobile/me",
    "/api/mobile/admin/approvals",
    "/api/mobile/admin/leave",
    "/api/mobile/notifications",
    "/api/connect/where",
]


def call(url: str, body: dict | None = None, cookie: str | None = None, timeout: float = 30.0):
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Content-Type": "application/json"} if data else {}
    if cookie:
        headers["Cookie"] = cookie
    request = urllib.request.Request(url, data=data, headers=headers,
                                     method="POST" if data else "GET")
    try:
        with urllib.request.urlopen(request, context=CTX, timeout=timeout) as response:
            return response.status, response.read().decode("utf-8", "replace"), response.headers.get_all("Set-Cookie") or []
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace"), exc.headers.get_all("Set-Cookie") or []
    except Exception as exc:                                    # noqa: BLE001
        return 0, f"{type(exc).__name__}: {exc}", []


def host_only_cookie(set_cookie_lines: list[str]) -> str:
    """Name=value only: what the app re-sends, so both hosts get the same token."""
    if not set_cookie_lines:
        return ""
    jar = SimpleCookie()
    for line in set_cookie_lines:
        jar.load(line.split(";")[0])
    return "; ".join(f"{k}={v.value}" for k, v in jar.items())


def main() -> int:
    proof: dict = {"password": "***", "started": time.strftime("%Y-%m-%d %H:%M:%S")}

    status, body, _ = call(LAN + "/api/connect/where")
    if status != 200:
        print("Server not answering on the LAN address:", status, body[:120])
        return 1
    where = json.loads(body)
    tunnel = (where.get("url") or "").rstrip("/")
    proof["tunnel"] = tunnel

    # ---- 1. desktop sign-in on the LAN -------------------------------------
    status, body, cookies = call(LAN + "/api/login", {"username": "Heidelise", "password": PASSWORD})
    proof["desktop_login_lan"] = {"status": status, "body": body[:300]}
    if status != 200:
        print("desktop /api/login failed:", status, body[:200])
        return 1
    sid = host_only_cookie(cookies)
    proof["cookie"] = sid.split("=")[0]
    print("desktop sign-in on LAN:", status, "cookie:", sid.split("=")[0])

    # ---- 2. the same session on both addresses -----------------------------
    for label, base in (("lan", LAN), ("tunnel", tunnel)):
        if not base:
            proof[f"desktop_session_{label}"] = {"status": 0, "note": "no tunnel advertised"}
            continue
        status, body, _ = call(base + "/api/system/health", cookie=sid)
        proof[f"desktop_session_{label}"] = {"status": status}
        print(f"  desktop session on {label}: {status}")

    # ---- 3. mobile sign-in, then the dashboard calls on both --------------
    employee = sys.argv[2] if len(sys.argv) > 2 else "001"
    status, body, cookies = call(LAN + "/api/mobile/login", {"employee_no": employee, "password": PASSWORD})
    proof["mobile_login_lan"] = {"employee_no": employee, "status": status, "body": body[:200]}
    if status != 200:
        print("mobile /api/mobile/login failed:", status, body[:200])
        return 1
    token = host_only_cookie(cookies)
    proof["mobile_cookie"] = token.split("=")[0]
    print("mobile sign-in on LAN:", status, "cookie:", token.split("=")[0])

    for label, base in (("lan", LAN), ("tunnel", tunnel)):
        results = {}
        for path in DASHBOARD:
            if not base:
                results[path] = 0
                continue
            status, _body, _ = call(base + path, cookie=token)
            results[path] = status
        proof[f"mobile_{label}"] = results
        print(f"  mobile dashboard on {label}:", " ".join(f"{p.split('/')[-1]}={s}" for p, s in results.items()))

    (OUT / "server_proof.json").write_text(json.dumps(proof, indent=2), encoding="utf-8")
    print("\nwritten:", OUT / "server_proof.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
