"""Beyond Security Suite — local defensive posture checks.

Read-only status reporting plus on-demand Windows Defender quick scans.
Never disables Defender, Firewall or any protection; quarantine/remediation
stays with the OS vendor tooling. ClamAV/YARA are reported as
'not_configured' until installed — the app does not pretend coverage it
does not have.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def _run(cmd, timeout=20):
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    except Exception as exc:
        return -1, f"{type(exc).__name__}: {exc}"


def defender_status():
    ".Parse Get-MpComputerStatus via PowerShell (Windows only)."
    if sys.platform != "win32":
        return {"available": False, "reason": "not_windows"}
    ps = ("Get-MpComputerStatus | Select-Object AMServiceEnabled,AntispywareEnabled,"
          "RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,"
          "AntivirusSignatureLastUpdated,AntispywareSignatureLastUpdated,QuickScanAge | ConvertTo-Json -Compress")
    code, out = _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=30)
    if code != 0:
        return {"available": False, "reason": "powershell_failed", "detail": out.strip()[:300]}
    try:
        data = json.loads(out.strip().splitlines()[-1])
    except Exception:
        return {"available": False, "reason": "parse_failed", "detail": out.strip()[:300]}
    return {"available": True, **{k: data.get(k) for k in (
        "AMServiceEnabled", "AntispywareEnabled", "RealTimeProtectionEnabled",
        "BehaviorMonitorEnabled", "IoavProtectionEnabled",
        "AntivirusSignatureLastUpdated", "AntispywareSignatureLastUpdated", "QuickScanAge")}}


CLAMAV_SCAN = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "ClamAV" / "clamscan.exe"
CLAMAV_DB = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data" / "clamav_db"
CLAMAV_WORK = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data" / "clamav"
CLAMAV_CUSTOM_SIGS = CLAMAV_WORK / "custom_sigs"
SCAN_RESULTS = CLAMAV_WORK / "scan_results.json"
DATA_HOME_SCAN = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data"
MAX_SCAN_BYTES = 100 * 1024 * 1024


def clamav_ready():
    """True when clamscan.exe exists and virus definitions are downloaded."""
    return CLAMAV_SCAN.is_file() and (CLAMAV_DB / "main.cvd").is_file()


def _clamav_db_age():
    try:
        newest = max((p.stat().st_mtime for p in CLAMAV_DB.glob("*.cvd")), default=0)
        return round((time.time() - newest) / 86400, 1) if newest else None
    except OSError:
        return None


def scan_file(path, timeout=120):
    """Scan one file with clamscan. Returns a result dict; never raises."""
    if not clamav_ready():
        return {"engine": "clamav", "result": "unavailable", "detail": "ClamAV or definitions not installed."}
    cmd = [str(CLAMAV_SCAN), "-d", str(CLAMAV_DB)]
    if CLAMAV_CUSTOM_SIGS.is_dir() and any(CLAMAV_CUSTOM_SIGS.iterdir()):
        cmd += ["-d", str(CLAMAV_CUSTOM_SIGS)]
    cmd += ["--no-summary", "-i", str(path)]
    code, out = _run(cmd, timeout=timeout)
    if code == 0:
        return {"engine": "clamav", "result": "clean", "path": str(path)}
    if code == 1:
        sig = ""
        for line in out.splitlines():
            if " FOUND" in line:
                sig = line.rsplit(" ", 2)[-2] if line.count(" ") >= 2 else line.strip()
                break
        return {"engine": "clamav", "result": "infected", "signature": sig or "unknown", "path": str(path)}
    return {"engine": "clamav", "result": "error", "detail": out.strip()[:300]}


def scan_bytes(content: bytes, filename: str = "upload.bin", timeout=120):
    """Scan raw bytes via a temp file. Returns the same result dict as scan_file."""
    if not clamav_ready():
        return {"engine": "clamav", "result": "unavailable", "detail": "ClamAV or definitions not installed."}
    if not content:
        return {"engine": "clamav", "result": "error", "detail": "Empty content."}
    if len(content) > MAX_SCAN_BYTES:
        return {"engine": "clamav", "result": "error", "detail": "File exceeds scan size limit."}
    CLAMAV_WORK.mkdir(parents=True, exist_ok=True)
    safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in filename)[:80] or "upload.bin"
    tmp = CLAMAV_WORK / f"scan_{os.getpid()}_{int(time.time()*1000)}_{safe}"
    try:
        tmp.write_bytes(content)
        return scan_file(tmp, timeout=timeout)
    finally:
        tmp.unlink(missing_ok=True)


def last_scan():
    try:
        return json.loads(SCAN_RESULTS.read_text(encoding="utf-8"))
    except Exception:
        return None


def scan_data_home(timeout_per_file=60):
    """Scheduled sweep of the Beyond Registration data folder. Writes scan_results.json."""
    started = time.time()
    summary = {"scanned_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "files": 0, "bytes": 0,
               "infected": [], "errors": 0, "skipped_large": 0}
    if not clamav_ready():
        summary["status"] = "unavailable"
        SCAN_RESULTS.parent.mkdir(parents=True, exist_ok=True)
        SCAN_RESULTS.write_text(json.dumps(summary), encoding="utf-8")
        return summary
    root = DATA_HOME_SCAN
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != "clamav_db"]
        for name in filenames:
            p = Path(dirpath) / name
            try:
                size = p.stat().st_size
            except OSError:
                continue
            if size > MAX_SCAN_BYTES:
                summary["skipped_large"] += 1
                continue
            summary["files"] += 1
            summary["bytes"] += size
            res = scan_file(p, timeout=timeout_per_file)
            if res["result"] == "infected":
                summary["infected"].append({"path": res["path"], "signature": res.get("signature")})
            elif res["result"] == "error":
                summary["errors"] += 1
    summary["duration_s"] = round(time.time() - started, 1)
    summary["status"] = "threats_found" if summary["infected"] else ("errors" if summary["errors"] else "clean")
    SCAN_RESULTS.parent.mkdir(parents=True, exist_ok=True)
    SCAN_RESULTS.write_text(json.dumps(summary), encoding="utf-8")
    return summary


def clamav_status():
    if CLAMAV_SCAN.is_file() and (CLAMAV_DB / "main.cvd").is_file():
        return {"status": "available", "engine": "ClamAV",
                "db_age_days": _clamav_db_age(),
                "note": "Definitions refresh via freshclam (Checks 24)."}
    if CLAMAV_SCAN.is_file():
        return {"status": "installed_no_definitions"}
    svc = Path(r"C:\Program Files\ClamWin\bin\clamscan.exe")
    if svc.is_file():
        return {"status": "available", "version": "installed (ClamWin path)"}
    return {"status": "not_configured"}


def yara_status():
    if shutil.which("yara") or shutil.which("yara64"):
        return {"status": "available"}
    return {"status": "not_configured"}


def recent_threats(limit=10):
    """Recent Defender threat detections (read-only)."""
    if sys.platform != "win32":
        return []
    ps = ("Get-MpThreatDetection -ErrorAction SilentlyContinue | Sort-Object InitialDetectionTime -Descending | "
          "Select-Object -First " + str(int(limit)) + " ThreatID,DomainUser,Resources,InitialDetectionTime | ConvertTo-Json -Compress")
    code, out = _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=30)
    if code != 0 or not out.strip():
        return []
    try:
        data = json.loads(out.strip().splitlines()[-1])
        if isinstance(data, dict):
            data = [data]
        return [{"threat_id": t.get("ThreatID"), "domain_user": t.get("DomainUser"),
                 "detected": t.get("InitialDetectionTime")} for t in data if isinstance(t, dict)]
    except Exception:
        return []


def status():
    return {
        "defender": defender_status(),
        "clamav": clamav_status(),
        "yara": yara_status(),
        "recent_threats": recent_threats(),
        "last_scan": last_scan(),
        "note": "Local defensive posture only. Beyond Registration never weakens OS protections.",
        "checked_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }


def quick_scan():
    """Launch a Windows Defender quick scan (async — Defender runs it)."""
    if sys.platform != "win32":
        raise RuntimeError("Quick scans require Windows.")
    exe = Path(os_environ_programfiles()) / "Windows Defender" / "MpCmdRun.exe"
    if not exe.is_file():
        raise RuntimeError("Windows Defender command-line scanner was not found.")
    proc = subprocess.Popen([str(exe), "-Scan", "-ScanType", "1"],
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return {"started": True, "pid": proc.pid, "scan": "quick"}


def os_environ_programfiles():
    import os
    return os.environ.get("ProgramFiles", r"C:\Program Files")
