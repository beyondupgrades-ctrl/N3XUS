"""Accounts Payable & Receivable (100% free, in-house, no external service)."""
from __future__ import annotations
from datetime import date, timedelta

SCHEMA = """
CREATE TABLE IF NOT EXISTS ap_invoices(
  id INTEGER PRIMARY KEY AUTOINCREMENT, supplier TEXT NOT NULL, invoice_no TEXT DEFAULT '',
  amount REAL NOT NULL DEFAULT 0, due_date TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Open',
  paid_amount REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ar_invoices(
  id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL, invoice_no TEXT DEFAULT '',
  amount REAL NOT NULL DEFAULT 0, due_date TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Open',
  paid_amount REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ap_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, amount REAL NOT NULL,
  paid_date TEXT NOT NULL, method TEXT DEFAULT 'bank', notes TEXT DEFAULT '',
  FOREIGN KEY(invoice_id) REFERENCES ap_invoices(id));
CREATE TABLE IF NOT EXISTS ar_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, amount REAL NOT NULL,
  paid_date TEXT NOT NULL, method TEXT DEFAULT 'bank', notes TEXT DEFAULT '',
  FOREIGN KEY(invoice_id) REFERENCES ar_invoices(id));
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_ap(conn, status=None):
    sql = "SELECT * FROM ap_invoices"
    args = []
    if status:
        sql += " WHERE status=?"; args.append(status)
    sql += " ORDER BY due_date"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def list_ar(conn, status=None):
    sql = "SELECT * FROM ar_invoices"
    args = []
    if status:
        sql += " WHERE status=?"; args.append(status)
    sql += " ORDER BY due_date"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def save_ap(conn, supplier, amount, due_date="", invoice_no="", notes=""):
    cur = conn.execute("INSERT INTO ap_invoices(supplier,invoice_no,amount,due_date,notes,created_at) VALUES(?,?,?,?,?,?)",
                       (supplier, invoice_no, float(amount), due_date, notes, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def save_ar(conn, customer, amount, due_date="", invoice_no="", notes=""):
    cur = conn.execute("INSERT INTO ar_invoices(customer,invoice_no,amount,due_date,notes,created_at) VALUES(?,?,?,?,?,?)",
                       (customer, invoice_no, float(amount), due_date, notes, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def pay_ap(conn, invoice_id, amount, paid_date=None, method="bank", notes=""):
    paid_date = paid_date or date.today().isoformat()
    conn.execute("INSERT INTO ap_payments(invoice_id,amount,paid_date,method,notes) VALUES(?,?,?,?,?)",
                 (invoice_id, float(amount), paid_date, method, notes))
    inv = conn.execute("SELECT amount,paid_amount FROM ap_invoices WHERE id=?", (invoice_id,)).fetchone()
    if inv:
        new_paid = float(inv["paid_amount"]) + float(amount)
        status = "Paid" if new_paid >= float(inv["amount"]) else "Partial"
        conn.execute("UPDATE ap_invoices SET paid_amount=?,status=? WHERE id=?", (new_paid, status, invoice_id))
    conn.commit()


def pay_ar(conn, invoice_id, amount, paid_date=None, method="bank", notes=""):
    paid_date = paid_date or date.today().isoformat()
    conn.execute("INSERT INTO ar_payments(invoice_id,amount,paid_date,method,notes) VALUES(?,?,?,?,?)",
                 (invoice_id, float(amount), paid_date, method, notes))
    inv = conn.execute("SELECT amount,paid_amount FROM ar_invoices WHERE id=?", (invoice_id,)).fetchone()
    if inv:
        new_paid = float(inv["paid_amount"]) + float(amount)
        status = "Paid" if new_paid >= float(inv["amount"]) else "Partial"
        conn.execute("UPDATE ar_invoices SET paid_amount=?,status=? WHERE id=?", (new_paid, status, invoice_id))
    conn.commit()


def aging_report(conn, table="ar"):
    tbl = "ar_invoices" if table == "ar" else "ap_invoices"
    today = date.today().isoformat()
    rows = conn.execute(f"SELECT * FROM {tbl} WHERE status IN ('Open','Partial')").fetchall()
    buckets = {"current": 0, "30": 0, "60": 0, "90": 0, "over90": 0}
    for r in rows:
        due = r["due_date"] or today
        try:
            from datetime import datetime
            days = (datetime.now().date() - datetime.fromisoformat(due).date()).days
        except Exception:
            days = 0
        bal = float(r["amount"]) - float(r["paid_amount"])
        if days <= 0: buckets["current"] += bal
        elif days <= 30: buckets["30"] += bal
        elif days <= 60: buckets["60"] += bal
        elif days <= 90: buckets["90"] += bal
        else: buckets["over90"] += bal
    return buckets