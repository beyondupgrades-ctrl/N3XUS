"""Project management (100% free, in-house)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Active',
  start_date TEXT DEFAULT '', end_date TEXT DEFAULT '', budget REAL DEFAULT 0,
  description TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS project_tasks(
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Todo', assignee TEXT DEFAULT '', due_date TEXT DEFAULT '',
  hours REAL DEFAULT 0, created_at TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(id));
CREATE TABLE IF NOT EXISTS time_entries(
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, task_id INTEGER,
  employee TEXT DEFAULT '', hours REAL NOT NULL, entry_date TEXT NOT NULL, notes TEXT DEFAULT '',
  FOREIGN KEY(project_id) REFERENCES projects(id));
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def list_projects(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM projects ORDER BY id DESC").fetchall()]


def save_project(conn, name, status="Active", start_date="", end_date="", budget=0, description=""):
    cur = conn.execute("INSERT INTO projects(name,status,start_date,end_date,budget,description,created_at) VALUES(?,?,?,?,?,?,?)",
                       (name, status, start_date, end_date, float(budget), description, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def list_tasks(conn, project_id=None):
    sql = "SELECT * FROM project_tasks"
    args = []
    if project_id:
        sql += " WHERE project_id=?"; args.append(project_id)
    sql += " ORDER BY id"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def save_task(conn, project_id, title, status="Todo", assignee="", due_date="", hours=0):
    cur = conn.execute("INSERT INTO project_tasks(project_id,title,status,assignee,due_date,hours,created_at) VALUES(?,?,?,?,?,?,?)",
                       (project_id, title, status, assignee, due_date, float(hours), date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def log_time(conn, project_id, hours, employee="", task_id=None, entry_date=None, notes=""):
    entry_date = entry_date or date.today().isoformat()
    conn.execute("INSERT INTO time_entries(project_id,task_id,employee,hours,entry_date,notes) VALUES(?,?,?,?,?,?)",
                 (project_id, task_id, employee, float(hours), entry_date, notes))
    conn.commit()