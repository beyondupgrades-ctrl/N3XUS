import json, os, sqlite3, sys, tempfile, threading, time, unittest, urllib.request, urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import web_backend
import Beyond_Registration as legacy

class FakeStore:
    def __init__(self):
        self.conn=sqlite3.connect(':memory:',check_same_thread=False); self.conn.row_factory=sqlite3.Row
        self.conn.executescript('''CREATE TABLE employees(id INTEGER PRIMARY KEY,employee_no TEXT,first_name TEXT,last_name TEXT,job_title TEXT,department TEXT,email TEXT,employment_status TEXT); CREATE TABLE mobile_accounts(employee_id INTEGER PRIMARY KEY,password_hash TEXT,active INTEGER,mobile_profile TEXT DEFAULT 'staff',created_at TEXT,updated_at TEXT); CREATE TABLE voic3_calls(id INTEGER PRIMARY KEY AUTOINCREMENT,caller_employee_id INTEGER NOT NULL,callee_employee_id INTEGER NOT NULL,call_type TEXT NOT NULL DEFAULT 'audio',status TEXT NOT NULL DEFAULT 'ringing',created_at TEXT NOT NULL,answered_at TEXT DEFAULT '',ended_at TEXT DEFAULT '',ended_reason TEXT DEFAULT ''); CREATE TABLE voic3_signals(id INTEGER PRIMARY KEY AUTOINCREMENT,call_id INTEGER NOT NULL,sender_employee_id INTEGER NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL); CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT); CREATE TABLE admin_permission_overrides(admin_id INTEGER PRIMARY KEY,grants_json TEXT,scope_type TEXT,scope_values_json TEXT,updated_by TEXT,updated_at TEXT); CREATE TABLE payroll_records(id INTEGER PRIMARY KEY,employee_id INTEGER,pay_period TEXT,pay_date TEXT,gross_pay REAL,total_deductions REAL,net_pay REAL,status TEXT); INSERT INTO admins VALUES(1,'Test Admin','admin','hash','',1,'Administrator'); INSERT INTO admins VALUES(2,'Test Manager','manager','hash','',1,'Manager');''')
        # VOIC3 (Sections 6-10) tables. The production schema lives in Store._schema();
        # the in-memory store mirrors the columns these API tests touch.
        self.conn.executescript('''
            CREATE TABLE voic3_presence(employee_id INTEGER PRIMARY KEY,status TEXT NOT NULL DEFAULT 'offline',custom_note TEXT DEFAULT '',updated_at TEXT NOT NULL);
            CREATE TABLE voic3_conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,name TEXT DEFAULT '',department TEXT DEFAULT '',created_by INTEGER,is_announcement_only INTEGER NOT NULL DEFAULT 0,pinned_message_id INTEGER,created_at TEXT NOT NULL);
            CREATE TABLE voic3_members(conversation_id INTEGER NOT NULL,employee_id INTEGER NOT NULL,role TEXT NOT NULL DEFAULT 'member',last_read_message_id INTEGER DEFAULT 0,joined_at TEXT NOT NULL,PRIMARY KEY (conversation_id, employee_id));
            CREATE TABLE voic3_receipts(message_id INTEGER NOT NULL,employee_id INTEGER NOT NULL,delivered_at TEXT,read_at TEXT,PRIMARY KEY (message_id, employee_id));
            CREATE TABLE voic3_reactions(message_id INTEGER NOT NULL,employee_id INTEGER NOT NULL,emoji TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY (message_id, employee_id, emoji));
            CREATE TABLE voic3_templates(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT DEFAULT '',body TEXT NOT NULL,created_by INTEGER,created_at TEXT NOT NULL);
            CREATE TABLE voic3_auto_reply(target_id INTEGER PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 0,away_message TEXT DEFAULT '',work_hours_json TEXT DEFAULT '{}');
            CREATE TABLE voic3_attachments(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER NOT NULL,filename TEXT NOT NULL,mime_type TEXT NOT NULL,size_bytes INTEGER NOT NULL,storage_path TEXT NOT NULL,created_at TEXT NOT NULL,transcript_json TEXT);
            CREATE TABLE voic3_meetings(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL UNIQUE,title TEXT NOT NULL,host_employee_id INTEGER NOT NULL,conversation_id INTEGER,scheduled_for TEXT DEFAULT '',waiting_room_enabled INTEGER NOT NULL DEFAULT 1,is_locked INTEGER NOT NULL DEFAULT 0,spotlight_employee_id INTEGER,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL);
            CREATE TABLE voic3_meeting_participants(meeting_id INTEGER NOT NULL,employee_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'waiting',is_muted_by_host INTEGER NOT NULL DEFAULT 0,hand_raised INTEGER NOT NULL DEFAULT 0,joined_at TEXT,left_at TEXT,PRIMARY KEY (meeting_id, employee_id));
            CREATE TABLE hub_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,recipient_label TEXT NOT NULL,employee_id INTEGER,department TEXT,subject TEXT NOT NULL,body TEXT NOT NULL,payroll_id INTEGER,attachment_name TEXT,attachment_mime TEXT,attachment_data BLOB,created_at TEXT NOT NULL,read_at TEXT,conversation_id INTEGER,reply_to_id INTEGER,message_type TEXT DEFAULT 'text',edited_at TEXT,deleted_at TEXT,idempotency_key TEXT,metadata_json TEXT);
            CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,actor TEXT,action TEXT,entity_type TEXT,entity_id TEXT,details TEXT,created_at TEXT,entry_hash TEXT);
        ''')
        self.conn.execute('INSERT INTO employees VALUES(1,?,?,?,?,?,?,?)',('E100','Test','Employee','Caregiver','Care','test@example.com','Active'))
        self.conn.execute('INSERT INTO employees VALUES(2,?,?,?,?,?,?,?)',('E200','Other','Employee','Caregiver','Care','other@example.com','Active'))
        self.conn.execute('INSERT INTO mobile_accounts(employee_id,password_hash,active,mobile_profile,created_at,updated_at) VALUES(1,?,1,?,?,?)',(legacy.hash_password('CorrectHorseBattery9'),'staff','','')); self.conn.commit()
        self.conn.execute("INSERT INTO payroll_records VALUES(70,1,'2026-10','2026-10-31',1000,100,900,'Approved')")
        self.conn.execute("INSERT INTO payroll_records VALUES(80,2,'2026-10','2026-10-31',2000,200,1800,'Approved')")
        self.conn.commit()
        # Mirror the VOIC3 default templates seeded by Store._schema() (Section 7).
        self.seed_voic3_templates()

    def seed_voic3_templates(self):
        defaults = [
            ("Leave Request Acknowledgement", "HR", "Thank you for your leave request. It has been received and will be reviewed by your manager within 2 business days."),
            ("Safety Incident Report", "Safety", "A safety incident has been logged. Please ensure the area is secured and report to your supervisor immediately."),
            ("Payslip Query", "Payroll", "Your payslip query has been received. Our payroll team will respond within 3 business days."),
            ("Shift Swap Request", "HR", "Your shift swap request has been submitted for approval."),
        ]
        for title, category, body in defaults:
            self.conn.execute("INSERT INTO voic3_templates(title,category,body,created_by,created_at) VALUES(?,?,?,?,?)", (title, category, body, None, '2026-11-07 08:00:00'))
        self.conn.commit()
    def employee(self,eid): return self.conn.execute('SELECT * FROM employees WHERE id=?',(eid,)).fetchone()
    def log(self,*args): pass
    def create_admin(self,full_name,username,password,role):
        self.conn.execute('INSERT INTO admins(full_name,username,password_hash,created_at,active,role) VALUES(?,?,?,?,1,?)',(full_name,username,legacy.hash_password(password),'2026-11-07',role))
        self.conn.commit()

class MobileApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_store=web_backend.SERVICE.store; cls.old_sessions=web_backend.SERVICE.mobile_sessions; cls.old_admin_sessions=web_backend.SERVICE.sessions; cls.old_upgrader=web_backend.SERVICE.upgrader
        cls.old_mobile_expiries=web_backend.SERVICE.mobile_session_expiries; cls.old_session_expiries=web_backend.SERVICE.session_expiries; cls.old_login_failures=web_backend.SERVICE.login_failures
        web_backend.SERVICE.store=FakeStore(); web_backend.SERVICE.mobile_sessions={}
        web_backend.SERVICE.mobile_session_expiries={}; web_backend.SERVICE.session_expiries={}; web_backend.SERVICE.login_failures={}
        web_backend.SERVICE.sessions={'admin-session':'admin','manager-session':'manager'}
        cls.upgrade_temp=tempfile.TemporaryDirectory()
        web_backend.SERVICE.upgrader=web_backend.InAppUpgrader(cls.upgrade_temp.name,admin_validator=lambda username:web_backend.SERVICE.role_for(username)=="Administrator")
        _saved = {k: os.environ.get(k) for k in ("BR_SERVER_PORT", "BR_TLS")}
        os.environ["BR_SERVER_PORT"] = "0"
        os.environ["BR_TLS"] = "off"
        try:
            cls.server,port=web_backend.make_server(); cls.url=f'http://127.0.0.1:{port}'
        finally:
            for k, v in _saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True); cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); web_backend.SERVICE.store=cls.old_store; web_backend.SERVICE.mobile_sessions=cls.old_sessions; web_backend.SERVICE.sessions=cls.old_admin_sessions; web_backend.SERVICE.mobile_session_expiries=cls.old_mobile_expiries; web_backend.SERVICE.session_expiries=cls.old_session_expiries; web_backend.SERVICE.login_failures=cls.old_login_failures; web_backend.SERVICE.upgrader=cls.old_upgrader; cls.upgrade_temp.cleanup()
    def request(self,path,payload=None,cookie=None,method=None):
        data=json.dumps(payload).encode() if payload is not None else None
        req=urllib.request.Request(self.url+path,data=data,headers={'Content-Type':'application/json',**({'Cookie':cookie} if cookie else {})},method=method or ('POST' if data is not None else 'GET'))
        return urllib.request.urlopen(req)
    def test_employee_login_and_profile(self):
        response=self.request('/api/mobile/login',{'employee_no':'E100','password':'CorrectHorseBattery9'})
        cookie=response.headers['Set-Cookie'].split(';',1)[0]
        self.assertIn('br_mobile=',cookie)
        profile=json.loads(self.request('/api/mobile/me',cookie=cookie).read())
        self.assertEqual(profile['employee']['employee_no'],'E100')
        self.assertEqual(profile['employee']['name'],'Test Employee')
    def test_mobile_account_provisioning_is_administrator_only(self):
        payload={'employee_id':1,'password':'NewMobilePassword123'}
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/accounts',payload,cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
        response=self.request('/api/mobile/accounts',payload,cookie='br_session=admin-session')
        self.assertEqual(response.status,200)
        self.assertEqual(response.read(),b'{"ok": true}')
    def test_mobile_account_list_is_private_and_disable_revokes_sessions(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/accounts',cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
        accounts=json.loads(self.request('/api/mobile/accounts',cookie='br_session=admin-session').read())['items']
        account=next(row for row in accounts if row['employee_no']=='E100')
        self.assertNotIn('password_hash',account)
        web_backend.SERVICE.mobile_sessions['active-token']=1
        response=self.request('/api/mobile/accounts/1/active',{'active':False},cookie='br_session=admin-session')
        self.assertEqual(json.loads(response.read()),{'ok':True,'active':False})
        self.assertNotIn('active-token',web_backend.SERVICE.mobile_sessions)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/dashboard',cookie='br_mobile=active-token')
        self.assertEqual(ctx.exception.code,401)
    def test_mobile_employee_cannot_read_another_employees_payslip(self):
        web_backend.SERVICE.mobile_sessions['employee-one-session']=1
        payslips=json.loads(self.request('/api/mobile/payslips',cookie='br_mobile=employee-one-session').read())['items']
        self.assertEqual([row['id'] for row in payslips],[70])
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/payslips/80/pdf',cookie='br_mobile=employee-one-session')
        self.assertEqual(ctx.exception.code,403)
    def test_permission_policy_api_validates_and_persists_scopes(self):
        policy=json.loads(self.request('/api/users/2/permissions',cookie='br_session=admin-session').read())
        self.assertIn('employees',policy['catalog'])
        payload={'grants':{'employees':['view','add'],'payroll':[],'reports_audit':['view'],'ai':['view','use'],'attendance':['record','correct']},'scope_type':'employees','scope_values':[1]}
        response=self.request('/api/users/2/permissions',payload,cookie='br_session=admin-session',method='PUT')
        self.assertEqual(json.loads(response.read()),{'ok':True,'scope_type':'employees','scope_values':['1']})
        permissions=web_backend.SERVICE.permissions_for('manager')
        self.assertTrue(permissions.has_explicit_policy)
        self.assertTrue(permissions.allows('employees','view'))
        self.assertFalse(permissions.allows('employees','edit'))
        self.assertTrue(permissions.employee_in_scope(1))
        self.assertFalse(permissions.employee_in_scope(2))
        employee_list=json.loads(self.request('/api/employees',cookie='br_session=manager-session').read())['items']
        self.assertEqual([row['id'] for row in employee_list],[1])
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/employees/2',cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/payroll',cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/employees',{'employee_no':'E300','first_name':'New','last_name':'Employee','department':'Care'},cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
        for path in ('/api/audit','/api/vision/status','/api/attendance/rebuild'):
            with self.subTest(path=path), self.assertRaises(urllib.error.HTTPError) as ctx:
                self.request(path,{'confirm':True} if path.endswith('/rebuild') else None,cookie='br_session=manager-session')
            self.assertEqual(ctx.exception.code,403)
    def test_vision_status_reports_model_and_config_persists_it(self):
        """CORTEX: the status payload carries the chosen model, the installed
        models and whether the assistant can answer, and Settings can save a
        model name and a local host."""
        status = json.loads(self.request('/api/vision/status', None, 'br_session=admin-session', 'GET').read().decode())
        for key in ('model', 'models', 'available', 'selected_available', 'host'):
            self.assertIn(key, status, status)
        self.assertIsInstance(status['models'], list)

        # A saved name is echoed back as `requested`. It is only used as the
        # active model when it is actually installed on this PC, so a stale name
        # can never be handed to a model that is not there.
        saved = json.loads(self.request('/api/config', {'vision_model': 'llama3.2:3b'},
                                        'br_session=admin-session', 'PUT').read().decode())
        self.assertEqual(saved['requested'], 'llama3.2:3b')
        self.assertIn('model', saved)
        again = json.loads(self.request('/api/vision/status', None, 'br_session=admin-session', 'GET').read().decode())
        installed = 'llama3.2:3b' in again['models']
        self.assertEqual(again['model'], 'llama3.2:3b' if installed else again['model'])
        self.assertIn('ram', again)

        # A local host is allowed; a remote http host is not.
        self.request('/api/config', {'ollama_host': 'http://127.0.0.1:11434'}, 'br_session=admin-session', 'PUT')
        with self.assertRaises(urllib.error.HTTPError) as remote:
            self.request('/api/config', {'ollama_host': 'http://example.com:11434'}, 'br_session=admin-session', 'PUT')
        self.assertEqual(remote.exception.code, 400)
        self.request('/api/config', {'vision_model': ''}, 'br_session=admin-session', 'PUT')

    def test_new_non_admin_user_starts_with_no_access(self):
        response=self.request('/api/users',{'full_name':'New Staff','username':'newstaff','password':'StrongTemporaryPassword99','role':'Staff'},cookie='br_session=admin-session')
        self.assertEqual(json.loads(response.read()),{'ok':True,'role':'Staff'})
        permissions=web_backend.SERVICE.permissions_for('newstaff')
        self.assertTrue(permissions.has_explicit_policy)
        self.assertFalse(permissions.allows('employees','view'))
        self.assertFalse(permissions.employee_in_scope(1))
        web_backend.SERVICE.sessions['staff-session']='newstaff'
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/employees',cookie='br_session=staff-session')
        self.assertEqual(ctx.exception.code,403)
    def test_bad_password_is_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/login',{'employee_no':'E100','password':'wrong-password'})
        self.assertEqual(ctx.exception.code,401)
    def test_expired_mobile_and_desktop_sessions_are_rejected(self):
        web_backend.SERVICE.mobile_sessions['expired-mobile-session']=1
        web_backend.SERVICE.mobile_session_expiries['expired-mobile-session']=time.time()-1
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/me',cookie='br_mobile=expired-mobile-session')
        self.assertEqual(ctx.exception.code,401)
        web_backend.SERVICE.sessions['expired-desktop-session']='manager'
        web_backend.SERVICE.session_expiries['expired-desktop-session']=time.time()-1
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/employees',cookie='br_session=expired-desktop-session')
        self.assertEqual(ctx.exception.code,401)
    def test_mobile_login_is_limited_after_five_failures(self):
        for _ in range(5):
            with self.assertRaises(urllib.error.HTTPError) as ctx:
                self.request('/api/mobile/login',{'employee_no':'RATE-LIMIT-USER','password':'wrong-password'})
            self.assertEqual(ctx.exception.code,401)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/login',{'employee_no':'RATE-LIMIT-USER','password':'wrong-password'})
        self.assertEqual(ctx.exception.code,429)
        self.assertEqual(ctx.exception.headers.get('Retry-After'),'900')
    def test_system_health_is_administrator_only(self):
        health=json.loads(self.request('/api/system/health',cookie='br_session=admin-session').read())
        self.assertEqual(health['database']['integrity'],'ok')
        self.assertIn('free_bytes',health['storage'])
        self.assertEqual(health['weather']['status'],'not_configured')
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/system/health',cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
    def test_upgrade_api_stages_reviewable_code_without_execution(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/upgrades',cookie='br_session=manager-session')
        self.assertEqual(ctx.exception.code,403)
        payload={'filename':'review.py','content':'raise RuntimeError("never executed")\n'}
        staged=json.loads(self.request('/api/upgrades',payload,cookie='br_session=admin-session').read())
        self.assertEqual(staged['status'],'staged')
        self.assertFalse(staged['execution_enabled'])
        listed=json.loads(self.request('/api/upgrades',cookie='br_session=admin-session').read())['items']
        self.assertEqual(listed[0]['filename'],'review.py.pending')
        reviewed=json.loads(self.request('/api/upgrades/review.py.pending',cookie='br_session=admin-session').read())
        self.assertIn('never executed',reviewed['content'])
        self.assertEqual(reviewed['sha256'],staged['sha256'])
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/upgrades/review.py.pending',{'confirm':False},cookie='br_session=admin-session',method='DELETE')
        self.assertEqual(ctx.exception.code,400)
        deleted=json.loads(self.request('/api/upgrades/review.py.pending',{'confirm':True},cookie='br_session=admin-session',method='DELETE').read())
        self.assertFalse(deleted['execution_enabled'])

    def test_voic3_meetings(self):
        web_backend.SERVICE.mobile_sessions['mtg-cookie'] = 1
        cookie = 'br_mobile=mtg-cookie'
        r = self.request('/api/voic3/meetings', {"title": "Standup"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        data = json.loads(r.read())
        code = data['code']
        mid = data['id']
        # join as same user (already participant) -> admitted (waiting room enabled default)
        r = self.request('/api/voic3/meetings/join', {"code": code}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        # host action by non-host (still same user is host, so allowed) lock
        r = self.request('/api/voic3/meetings/%d/host-action' % mid, {"action": "lock"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        # raise hand
        r = self.request('/api/voic3/meetings/%d/raise-hand' % mid, {"raised": True}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)

    def test_voic3_meeting_list_and_signal_relay(self):
        """Section 10 front end: the meetings list is readable and the peer
        signalling route relays offers to admitted participants only."""
        web_backend.SERVICE.mobile_sessions['sig-host'] = 1
        web_backend.SERVICE.mobile_sessions['sig-guest'] = 2
        host = 'br_mobile=sig-host'
        response = self.request('/api/voic3/meetings', {'title': 'Signal test', 'waiting_room_enabled': False}, host)
        self.assertEqual(response.status, 201)
        mid = json.loads(response.read().decode())['id']

        listing = json.loads(self.request('/api/voic3/meetings', None, host, 'GET').read().decode())
        self.assertTrue(any(int(m['id']) == int(mid) for m in listing['items']), listing)

        relayed = json.loads(self.request('/api/voic3/meetings/%d/signal' % mid,
                                          {'kind': 'offer', 'payload': '{"sdp":"v=0"}', 'target': 2}, host).read().decode())
        self.assertTrue(relayed['ok'])

        with self.assertRaises(urllib.error.HTTPError) as bad_kind:
            self.request('/api/voic3/meetings/%d/signal' % mid, {'kind': 'bogus', 'payload': 'x'}, host)
        self.assertEqual(bad_kind.exception.code, 400)

        # A guest who has not joined the meeting cannot signal into it.
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.request('/api/voic3/meetings/%d/signal' % mid, {'kind': 'offer', 'payload': 'x'},
                         'br_mobile=sig-guest')
        self.assertEqual(denied.exception.code, 403)

    def test_voic3_meeting_recording_saved_and_posted_to_conversation(self):
        """Section 10: a browser .webm recording is stored and an auth-gated link is
        posted into the meeting's conversation, visible to its members."""
        web_backend.SERVICE.mobile_sessions['rec-host'] = 1
        web_backend.SERVICE.mobile_sessions['rec-guest'] = 2
        host = 'br_mobile=rec-host'
        guest = 'br_mobile=rec-guest'
        conv = json.loads(self.request('/api/voic3/conversations', {"kind": "group", "name": "Standup room", "members": [2]}, cookie=host, method='POST').read())
        cid = conv['id']
        created = json.loads(self.request('/api/voic3/meetings', {"title": "Recorded standup", "conversation_id": cid}, cookie=host, method='POST').read())
        mid = created['id']
        # A participant joins the waiting room, then the host admits them.
        joined = json.loads(self.request('/api/voic3/meetings/join', {"code": created['code']}, cookie=guest, method='POST').read())
        self.assertEqual(joined['state'], 'waiting')
        self.request('/api/voic3/meetings/%d/admit' % mid, {"employee_id": 2}, cookie=host, method='POST')
        # Meeting detail and poll routes expose host flag, participants and waiting room.
        detail = json.loads(self.request('/api/voic3/meetings/%d' % mid, cookie=host).read())
        self.assertTrue(detail['is_host'])
        self.assertEqual(detail['participants'][0]['state'], 'admitted')
        poll = json.loads(self.request('/api/voic3/meetings/%d/poll' % mid, cookie=guest).read())
        self.assertEqual(poll['me']['state'], 'admitted')
        # Only the host may upload a recording.
        import base64
        payload = {"data": "data:video/webm;base64," + base64.b64encode(b'\x1aE\xdf\xa3webm-bytes').decode(), "filename": "standup.webm"}
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/voic3/meetings/%d/recording' % mid, payload, cookie=guest, method='POST')
        self.assertEqual(ctx.exception.code, 403)
        saved = json.loads(self.request('/api/voic3/meetings/%d/recording' % mid, payload, cookie=host, method='POST').read())
        self.assertEqual(saved['size_bytes'], len(b'\x1aE\xdf\xa3webm-bytes'))
        self.assertTrue(saved['filename'].endswith('.webm'))
        self.assertEqual(saved['conversation_id'], cid)
        self.assertTrue(saved['message_id'])
        # The recording link is auth-gated: anonymous gets 403, members get the bytes.
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request(saved['url'])
        self.assertEqual(ctx.exception.code, 403)
        stored = self.request(saved['url'], cookie=guest)
        self.assertEqual(stored.status, 200)
        self.assertEqual(stored.headers['Content-Type'], 'video/webm')
        self.assertEqual(stored.read(), b'\x1aE\xdf\xa3webm-bytes')
        # The posted message is in the conversation the meeting belongs to.
        messages = json.loads(self.request('/api/voic3/conversations/%d/messages' % cid, cookie=guest).read())
        bodies = [m.get('body') or '' for m in messages.get('items', [])]
        self.assertTrue(any(saved['url'] in b for b in bodies))

    def test_voic3_section7_templates_upload_broadcast(self):
        web_backend.SERVICE.mobile_sessions['s7-cookie'] = 1
        cookie = 'br_mobile=s7-cookie'
        r = self.request('/api/voic3/templates', cookie=cookie)
        self.assertEqual(r.status, 200)
        items = json.loads(r.read())['items']
        self.assertGreaterEqual(len(items), 4)
        r = self.request('/api/voic3/templates', {"title": "T", "body": "B", "category": "HR"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        import base64
        b64 = base64.b64encode(b'hello').decode()
        r = self.request('/api/voic3/attachments', {"filename": "t.txt", "mime_type": "text/plain", "data": b64}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        aid = json.loads(r.read())['id']
        r = self.request('/api/voic3/attachments/%d' % aid, cookie=cookie)
        self.assertEqual(r.status, 200)
        r = self.request('/api/voic3/broadcast', {"subject": "S", "body": "B"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        self.assertGreaterEqual(json.loads(r.read())['sent'], 1)
        r = self.request('/api/voic3/auto-reply', {"enabled": True, "away_message": "away", "work_hours_json": "{}"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        r = self.request('/api/voic3/auto-reply', cookie=cookie)
        self.assertEqual(r.status, 200)
        self.assertTrue(json.loads(r.read())['enabled'])

    def test_voic3_conversations_receipts_reactions(self):
        web_backend.SERVICE.mobile_sessions['conv-cookie'] = 1
        cookie = 'br_mobile=conv-cookie'
        r = self.request('/api/voic3/conversations', {"kind": "channel", "name": "Ann", "is_announcement_only": True, "members": [2]}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        cid = json.loads(r.read())['id']
        r = self.request('/api/voic3/conversations/%d/messages' % cid, {"body": "hello"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        mid = json.loads(r.read())['id']
        r = self.request('/api/voic3/messages/%d/receipt' % mid, {"kind": "read"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        r = self.request('/api/voic3/messages/%d/reaction' % mid, {"emoji": "thumbsup"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        self.assertEqual(json.loads(r.read())['action'], 'added')
        r = self.request('/api/voic3/messages/%d/reaction' % mid, {"emoji": "thumbsup"}, cookie=cookie, method='POST')
        self.assertEqual(json.loads(r.read())['action'], 'removed')
        r = self.request('/api/voic3/conversations/%d/typing' % cid, {}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        r = self.request('/api/voic3/messages/search?q=hello', cookie=cookie)
        self.assertEqual(r.status, 200)
        self.assertTrue(any(m['id'] == mid for m in json.loads(r.read())['items']))

    def test_voic3_presence_and_event_bus(self):
        web_backend.SERVICE.mobile_sessions['pres-cookie'] = 1
        cookie = 'br_mobile=pres-cookie'
        r = self.request('/api/voic3/presence', {"status": "busy", "custom_note": "in a call"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)
        data = json.loads(r.read())
        self.assertEqual(data['status'], 'busy')
        r = self.request('/api/voic3/presence', cookie=cookie)
        self.assertEqual(r.status, 200)
        items = json.loads(r.read())['items']
        self.assertTrue(any(i['status'] == 'busy' for i in items))
        import queue as _q
        q = _q.Queue()
        with web_backend._VOIC3_STREAMS_LOCK:
            web_backend._VOIC3_STREAMS.setdefault(1, []).append(q)
        web_backend.publish_voic3_event([1], 'call.incoming', {'call_id': 42})
        etype, payload = q.get(timeout=1)
        self.assertEqual(etype, 'call.incoming')
        self.assertEqual(payload['call_id'], 42)
        with web_backend._VOIC3_STREAMS_LOCK:
            if q in web_backend._VOIC3_STREAMS.get(1, []):
                web_backend._VOIC3_STREAMS[1].remove(q)

    def test_voic3_ice_config(self):
        import os
        os.environ.pop('VOIC3_TURN_URL', None)
        os.environ.pop('VOIC3_TURN_SECRET', None)
        web_backend.SERVICE.mobile_sessions['ice-test-cookie'] = 1
        cookie = 'br_mobile=ice-test-cookie'
        r = self.request('/api/voic3/ice-config', cookie=cookie)
        self.assertEqual(r.status, 200)
        data = json.loads(r.read())
        self.assertTrue(any('stun.l.google.com' in str(s.get('urls')) for s in data['iceServers']))
        # The relay list grew your-userd bare STUN (the free OpenRelay fallback is
        # hardcoded now): assert structure, not a count that goes stale.
        base_count = len(data['iceServers'])
        self.assertGreaterEqual(base_count, 2)
        # with TURN env vars
        os.environ['VOIC3_TURN_URL'] = 'turn:example.com:3478'
        os.environ['VOIC3_TURN_SECRET'] = 'secret123'
        r = self.request('/api/voic3/ice-config', cookie=cookie)
        self.assertEqual(r.status, 200)
        data = json.loads(r.read())
        self.assertEqual(len(data['iceServers']), base_count + 1)
        turn = data['iceServers'][-1]
        self.assertIn('turn:example.com:3478', str(turn['urls']))
        self.assertIn('username', turn)
        self.assertIn('credential', turn)
        os.environ.pop('VOIC3_TURN_URL', None)
        os.environ.pop('VOIC3_TURN_SECRET', None)

    def test_voic3_call_auth_and_state(self):
        web_backend.SERVICE.mobile_sessions['voic3-test-cookie'] = 1
        cookie = 'br_mobile=voic3-test-cookie'
        r = self.request('/api/mobile/calls', {"callee_employee_id": 2, "call_type": "audio"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 201)
        cid = json.loads(r.read())['id']
        r = self.request('/api/mobile/calls/%d/signal?after=0' % cid, cookie=cookie)
        self.assertEqual(r.status, 200)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/calls/%d/answer' % cid, {}, cookie=cookie, method='POST')
        self.assertEqual(ctx.exception.code, 403)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/mobile/calls/%d/decline' % cid, {}, cookie=cookie, method='POST')
        self.assertEqual(ctx.exception.code, 403)
        r = self.request('/api/mobile/calls/%d/end' % cid, {"reason": "cancelled"}, cookie=cookie, method='POST')
        self.assertEqual(r.status, 200)

    def test_evolv3_generate_module_image_returns_topic_svg_and_saves(self):
        """Section 11: additive artwork route, deterministic and offline-safe."""
        # /api/evolv3/* is gated on the admin actor (unchanged contract), so use
        # the seeded administrator session exactly as the existing suite does.
        cookie = 'br_session=admin-session'
        import evolv3_evolution
        conn = web_backend.SERVICE.store.conn
        evolv3_evolution.ensure_schema(conn)
        conn.execute(
            "INSERT OR IGNORE INTO evolv3_week_modules(id,week_added,title,category,hours,description,"
            "highlights,hazards,video,source,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            ('evolv3-art-test', 1, 'Critical Hazards: Choking & Dysphagia Prevention',
             'Safety & First Aid', 10, 'Airway and IDDSI safety.', '[]',
             json.dumps(['Silent aspiration']), '[]', 'local', '2026-01-01T00:00:00'))
        conn.commit()
        body = {"moduleId": "evolv3-art-test", "title": "Critical Hazards: Choking & Dysphagia Prevention",
                "category": "Safety & First Aid", "shortDescription": "Airway and IDDSI safety.",
                "hazardsCovered": ["Silent aspiration"], "useAi": False}
        payload = json.loads(self.request('/api/evolv3/generate-module-image', body, cookie=cookie).read())
        self.assertTrue(payload['ok'])
        self.assertEqual(payload['topic'], 'choking')
        self.assertTrue(payload['imageUrl'].startswith('data:image/svg+xml;base64,'))
        self.assertTrue(payload['saved'])
        import base64
        svg = base64.b64decode(payload['imageUrl'].split(',', 1)[1]).decode('utf-8')
        self.assertIn('viewBox="0 0 800 450"', svg)
        self.assertTrue(svg.rstrip().endswith('</svg>'))
        self.assertNotIn('<script', svg.lower())
        self.assertIn('CHOKING', svg.upper())
        stored = conn.execute("SELECT image_url FROM evolv3_week_modules WHERE id='evolv3-art-test'").fetchone()[0]
        self.assertEqual(stored, payload['imageUrl'])
        modules = evolv3_evolution.list_week_modules(conn)
        self.assertTrue(all(m.get('imageUrl') for m in modules))
        # Unauthenticated callers are refused; the route never leaks artwork.
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request('/api/evolv3/generate-module-image', body, method='POST')
        self.assertIn(ctx.exception.code, (401, 403))

    def test_voic3_push_vapid_subscribe_and_unsubscribe(self):
        """Section 12: self-hosted Web Push routes are additive and VAPID-gated."""
        import os, voic3_push
        web_backend.SERVICE.mobile_sessions['push-cookie'] = 1
        web_backend.SERVICE.mobile_session_expiries['push-cookie'] = time.time() + 3600
        cookie = 'br_mobile=push-cookie'
        conn = web_backend.SERVICE.store.conn
        voic3_push.ensure_schema(conn)
        old = {k: os.environ.get(k) for k in ('VAPID_PUBLIC_KEY', 'VAPID_PRIVATE_KEY', 'VAPID_SUBJECT')}
        try:
            pub, priv = voic3_push.generate_vapid_keys()
            os.environ['VAPID_PUBLIC_KEY'] = pub
            os.environ['VAPID_PRIVATE_KEY'] = priv
            os.environ['VAPID_SUBJECT'] = 'mailto:test@your-userd-registration.local'
            body = json.loads(self.request('/api/voic3/push/vapid-public-key', cookie=cookie).read())
            self.assertTrue(body['enabled'])
            self.assertEqual(body['publicKey'], pub)
            sub = {'endpoint': 'https://push.example.test/send/abc123',
                   'keys': {'p256dh': 'BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM',
                            'auth': 'tBHItJI5svbpez7KI4CCXg'},
                   'device_label': 'Test Android'}
            created = json.loads(self.request('/api/voic3/push/subscribe', sub, cookie=cookie).read())
            self.assertTrue(created['ok'])
            row = conn.execute("SELECT user_id,endpoint,device_label FROM push_subscriptions WHERE id=?", (created['id'],)).fetchone()
            self.assertEqual(row['user_id'], 1)
            self.assertEqual(row['device_label'], 'Test Android')
            with self.assertRaises(urllib.error.HTTPError) as ctx:
                self.request('/api/voic3/push/subscribe', {'endpoint': 'http://insecure.test/x', 'keys': sub['keys']}, cookie=cookie)
            self.assertEqual(ctx.exception.code, 400)
            gone = json.loads(self.request('/api/voic3/push/unsubscribe', {'endpoint': sub['endpoint']}, cookie=cookie, method='DELETE').read())
            self.assertTrue(gone['removed'])
            self.assertIsNone(conn.execute("SELECT id FROM push_subscriptions WHERE id=?", (created['id'],)).fetchone())
            # Without VAPID keys the route still answers and push is skipped.
            for k in ('VAPID_PUBLIC_KEY', 'VAPID_PRIVATE_KEY'):
                os.environ.pop(k, None)
            os.environ['BR_DATA_HOME'] = os.path.join(tempfile.gettempdir(), 'br-vapid-none-' + str(time.time()))
            body = json.loads(self.request('/api/voic3/push/vapid-public-key', cookie=cookie).read())
            self.assertIn('enabled', body)
        finally:
            for k, v in old.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v
            os.environ.pop('BR_DATA_HOME', None)

    def test_voic3_message_idempotency_key_prevents_duplicates(self):
        """Section 13: an offline outbox retry reuses the message instead of duplicating."""
        web_backend.SERVICE.mobile_sessions['idem-host'] = 1
        web_backend.SERVICE.mobile_session_expiries['idem-host'] = time.time() + 3600
        web_backend.SERVICE.mobile_sessions['idem-peer'] = 2
        web_backend.SERVICE.mobile_session_expiries['idem-peer'] = time.time() + 3600
        host = 'br_mobile=idem-host'
        conv = json.loads(self.request('/api/voic3/conversations', {"kind": "group", "name": "Outbox room", "members": [2]}, cookie=host, method='POST').read())
        cid = conv['id']
        body = {"body": "Queued while offline", "idempotency_key": "2f1c9a54-offline-retry"}
        first = json.loads(self.request('/api/voic3/conversations/%d/messages' % cid, body, cookie=host, method='POST').read())
        self.assertEqual(first['id'] > 0, True)
        self.assertNotIn('duplicate', first)
        again = json.loads(self.request('/api/voic3/conversations/%d/messages' % cid, body, cookie=host, method='POST').read())
        self.assertEqual(again['id'], first['id'])
        self.assertTrue(again['duplicate'])
        count = web_backend.SERVICE.store.conn.execute(
            "SELECT COUNT(*) AS c FROM hub_messages WHERE conversation_id=? AND body='Queued while offline'", (cid,)).fetchone()['c']
        self.assertEqual(count, 1)
        # Older clients that omit the key still post normally (no dedupe).
        plain = {"body": "No key from an older build"}
        a = json.loads(self.request('/api/voic3/conversations/%d/messages' % cid, plain, cookie=host, method='POST').read())
        b = json.loads(self.request('/api/voic3/conversations/%d/messages' % cid, plain, cookie=host, method='POST').read())
        self.assertNotEqual(a['id'], b['id'])

    def test_voic3_workflow_cards_and_compliance_export(self):
        """Section 14: cards write a readable text fallback + an immutable audit chain."""
        web_backend.SERVICE.mobile_sessions['card-host'] = 1
        web_backend.SERVICE.mobile_session_expiries['card-host'] = time.time() + 3600
        host = 'br_mobile=card-host'
        conv = json.loads(self.request('/api/voic3/conversations',
                                       {"kind": "group", "name": "Handover", "members": [2]},
                                       cookie=host, method='POST').read())
        cid = conv['id']

        # A leave card: fallback text must read on its own (older clients see this).
        leave = json.loads(self.request('/api/voic3/workflow/cards', {
            "conversation_id": cid, "card_type": "leave_card",
            "payload": {"employee_name": "Thandi Mokoena", "leave_type": "Sick",
                        "date_from": "2026-11-10", "date_to": "2026-11-11", "days": 2,
                        "reason": "Flu"},
            "idempotency_key": "card-leave-1"}, cookie=host, method='POST').read())
        self.assertTrue(leave['text'].startswith('Leave request'))
        self.assertIn('Thandi Mokoena', leave['text'])
        again = json.loads(self.request('/api/voic3/workflow/cards', {
            "conversation_id": cid, "card_type": "leave_card", "payload": {"employee_name": "x"},
            "idempotency_key": "card-leave-1"}, cookie=host, method='POST').read())
        self.assertEqual(again['id'], leave['id'])
        self.assertTrue(again['duplicate'])

        got = json.loads(self.request('/api/voic3/workflow/cards/%d' % leave['id'], None, cookie=host).read())
        self.assertEqual(got['card_type'], 'leave_card')
        self.assertEqual(got['payload']['leave_type'], 'Sick')
        # Deciding a leave card is manager-only: a staff session is refused...
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.request('/api/voic3/workflow/cards/%d/action' % leave['id'],
                         {"action": "approve"}, cookie=host, method='POST')
        self.assertEqual(denied.exception.code, 403)
        # ...and an Administrator session is accepted.
        decided = json.loads(self.request('/api/voic3/workflow/cards/%d/action' % leave['id'],
                                          {"action": "approve"}, cookie='br_session=admin-session',
                                          method='POST').read())
        self.assertEqual(decided['card']['status'], 'Approved')
        self.assertIn('Approved', decided['text'])

        # A safety checklist: each item is signed individually.
        check = json.loads(self.request('/api/voic3/workflow/cards', {
            "conversation_id": cid, "card_type": "safety_checklist",
            "payload": {"shift": "Night to Day", "items": [
                {"label": "Oxygen cylinders counted"}, {"label": "Keys handed over"}]}},
            cookie=host, method='POST').read())
        self.assertIn('0 of 2', check['text'])
        one = json.loads(self.request('/api/voic3/workflow/cards/%d/action' % check['id'],
                                      {"action": "toggle", "index": 1, "checked": True},
                                      cookie=host, method='POST').read())
        self.assertIn('1 of 2', one['text'])
        self.assertEqual(one['card']['status'], 'In progress')
        both = json.loads(self.request('/api/voic3/workflow/cards/%d/action' % check['id'],
                                       {"action": "toggle", "index": 2, "checked": True},
                                       cookie=host, method='POST').read())
        self.assertEqual(both['card']['status'], 'Complete')

        # SOS pin carries coordinates and lands in the audit trail.
        sos = json.loads(self.request('/api/voic3/workflow/cards', {
            "conversation_id": cid, "card_type": "sos_pin",
            "payload": {"employee_name": "Sipho Ndlovu", "place": "Ward 3",
                        "latitude": -26.2041, "longitude": 28.0473, "battery": 14}},
            cookie=host, method='POST').read())
        self.assertIn('EMERGENCY SOS', sos['text'])
        ack = json.loads(self.request('/api/voic3/workflow/cards/%d/action' % sos['id'],
                                      {"action": "acknowledge"}, cookie=host, method='POST').read())
        self.assertEqual(ack['card']['status'], 'Acknowledged')

        # Unknown card types are refused, not silently stored.
        with self.assertRaises(Exception):
            self.request('/api/voic3/workflow/cards',
                         {"conversation_id": cid, "card_type": "not_a_card", "payload": {}},
                         cookie=host, method='POST')

        # The audit chain verifies, and tampering breaks it.
        conn = web_backend.SERVICE.store.conn
        chain = web_backend.voic3_workflow.verify_chain(conn)
        self.assertTrue(chain['valid'], chain)
        self.assertGreaterEqual(chain['checked'], 4)

        # Staff may not export; an Administrator session may.
        with self.assertRaises(urllib.error.HTTPError) as staff_denied:
            self.request('/api/voic3/compliance/export?format=json', None, cookie=host)
        self.assertEqual(staff_denied.exception.code, 403)
        admin = 'br_session=admin-session'
        export = self.request('/api/voic3/compliance/export?format=json', None, cookie=admin).read()
        doc = json.loads(export)
        self.assertTrue(doc['chain']['valid'])
        self.assertGreaterEqual(doc['count'], 4)
        self.assertTrue(any(i['kind'] == 'sos_pin' for i in doc['items']))

        csv_body = self.request('/api/voic3/compliance/export?format=csv', None, cookie=admin).read().decode('utf-8')
        self.assertIn('entry_hash', csv_body.splitlines()[0])
        self.assertIn('sos_pin', csv_body)

        html_body = self.request('/api/voic3/compliance/export', None, cookie=admin).read().decode('utf-8')
        self.assertIn('Chain intact', html_body)
        self.assertIn('Sos Pin', html_body)

        conn.execute("UPDATE workflow_audit_logs SET details='edited' WHERE id=2")
        conn.commit()
        broken = web_backend.voic3_workflow.verify_chain(conn)
        self.assertFalse(broken['valid'])
        self.assertEqual(broken['first_bad'], 2)

    def test_voic3_sfu_tokens_e2ee_and_transcription(self):
        """Section 15: optional SFU token, admitted-only E2EE key, graceful STT."""
        import base64 as _b64
        import os as _os
        web_backend.SERVICE.mobile_sessions['sfu-host'] = 1
        web_backend.SERVICE.mobile_session_expiries['sfu-host'] = time.time() + 3600
        web_backend.SERVICE.mobile_sessions['sfu-guest'] = 2
        web_backend.SERVICE.mobile_session_expiries['sfu-guest'] = time.time() + 3600
        host = 'br_mobile=sfu-host'
        guest = 'br_mobile=sfu-guest'

        # 1. With no LiveKit configured everything still answers and stays p2p.
        caps = json.loads(self.request('/api/voic3/rtc/capabilities', None, cookie=host).read())
        self.assertFalse(caps['sfu']['enabled'])
        self.assertIn('e2ee', caps)
        self.assertIn('transcription', caps)

        meeting = json.loads(self.request('/api/voic3/meetings',
                                          {"title": "Handover", "waiting_room_enabled": True},
                                          cookie=host, method='POST').read())
        mid = meeting['id']
        code = meeting['code']
        joined = json.loads(self.request('/api/voic3/meetings/join', {"code": code}, cookie=guest, method='POST').read())
        self.assertEqual(joined['state'], 'waiting')

        # A waiting-room guest must not get media or a key.
        with self.assertRaises(urllib.error.HTTPError) as waiting:
            self.request('/api/voic3/meetings/%d/rtc-token' % mid, {}, cookie=guest, method='POST')
        self.assertEqual(waiting.exception.code, 403)
        with self.assertRaises(urllib.error.HTTPError) as no_key:
            self.request('/api/voic3/meetings/%d/e2ee-key' % mid, None, cookie=guest)
        self.assertEqual(no_key.exception.code, 403)

        # The host is admitted by definition and gets a key with a 12h epoch.
        key = json.loads(self.request('/api/voic3/meetings/%d/e2ee-key' % mid, None, cookie=host).read())
        self.assertTrue(key['enabled'])
        self.assertEqual(key['algorithm'], 'SFrame')
        self.assertTrue(len(key['key']) >= 40)

        # Turn the SFU on: the host now receives a verifiable join token.
        _os.environ['VOIC3_LIVEKIT_URL'] = 'ws://127.0.0.1:7880'
        _os.environ['VOIC3_LIVEKIT_API_KEY'] = 'devkey'
        _os.environ['VOIC3_LIVEKIT_API_SECRET'] = 'secret1234567890123456789012345678'
        try:
            caps2 = json.loads(self.request('/api/voic3/rtc/capabilities', None, cookie=host).read())
            self.assertTrue(caps2['sfu']['enabled'])
            tok = json.loads(self.request('/api/voic3/meetings/%d/rtc-token' % mid, {}, cookie=host, method='POST').read())
            self.assertTrue(tok['enabled'])
            self.assertEqual(tok['transport'], 'sfu')
            self.assertEqual(tok['room'], 'voic3-meeting-%d' % mid)
            self.assertEqual(tok['identity'], 'emp-1')
            claims = web_backend.voic3_sfu.verify_token(tok['token'])
            self.assertIsNotNone(claims)
            self.assertEqual(claims['sub'], 'emp-1')
            self.assertEqual(claims['video']['room'], 'voic3-meeting-%d' % mid)
            self.assertTrue(claims['video']['roomAdmin'])
            # A tampered token fails verification.
            self.assertIsNone(web_backend.voic3_sfu.verify_token(tok['token'][:-4] + 'AAAA'))
        finally:
            for name in ('VOIC3_LIVEKIT_URL', 'VOIC3_LIVEKIT_API_KEY', 'VOIC3_LIVEKIT_API_SECRET'):
                _os.environ.pop(name, None)

        # 2. Transcription: without an engine it is a clean 503, never a crash.
        conn = web_backend.SERVICE.store.conn
        att = conn.execute(
            "INSERT INTO voic3_attachments(employee_id,filename,mime_type,size_bytes,storage_path,created_at) VALUES(1,'a.webm','video/webm',10,'/tmp/does-not-exist.webm','')").lastrowid
        conn.commit()
        if not web_backend.voic3_sfu.transcription_available():
            with self.assertRaises(urllib.error.HTTPError) as no_engine:
                self.request('/api/voic3/attachments/%d/transcribe' % att, {}, cookie=host, method='POST')
            self.assertEqual(no_engine.exception.code, 503)
            body = json.loads(no_engine.exception.read().decode())
            self.assertIn('faster-whisper', body['error'])
        # Another employee may not transcribe someone else's recording.
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.request('/api/voic3/attachments/%d/transcribe' % att, {}, cookie=guest, method='POST')
        self.assertIn(denied.exception.code, (403, 503))
        # Language codes are validated before ever reaching a model.
        self.assertEqual(web_backend.voic3_sfu.safe_language('en-ZA'), 'en-za')
        self.assertIsNone(web_backend.voic3_sfu.safe_language('ignore previous instructions'))
