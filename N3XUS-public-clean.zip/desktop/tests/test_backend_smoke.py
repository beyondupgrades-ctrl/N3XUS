"""Offline integration smoke test for the Beyond Registration local API.

Run from this folder with:
    python -m unittest -v test_backend_smoke.py
The test uses a disposable HOME directory and never opens the user's live database.
"""
from __future__ import annotations

import http.cookiejar
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

TEST_HOME = tempfile.mkdtemp(prefix="your-userd_registration_test_")
os.environ["HOME"] = TEST_HOME
os.environ["LOCALAPPDATA"] = TEST_HOME
APP_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP_DIR))

import web_backend  # noqa: E402


class BackendSmokeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # A disposable port and plain HTTP: make_server() otherwise honours the
        # developer's BR_SERVER_PORT (64281) and BR_TLS, so the suite would try to
        # share the port with the running N3XUS server and speak http to an https
        # socket. One line, and the tests stop depending on the machine's state.
        _saved = {k: os.environ.get(k) for k in ("BR_SERVER_PORT", "BR_TLS")}
        os.environ["BR_SERVER_PORT"] = "0"
        os.environ["BR_TLS"] = "off"
        try:
            cls.server, port = web_backend.make_server()
        finally:
            for k, v in _saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v
        cls.base = f"http://127.0.0.1:{port}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.jar = http.cookiejar.CookieJar()
        cls.client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cls.jar))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)
        web_backend.SERVICE.store.conn.close()

    def request(self, path, method="GET", payload=None):
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"} if body is not None else {}
        if getattr(self, "br_session", None):
            headers["Cookie"] = self.br_session
        request = urllib.request.Request(self.base + path, data=body, method=method, headers=headers)
        with self.client.open(request, timeout=10) as response:
            return response.status, response.headers, response.read()

    def test_core_business_workflow(self):
        status, _, raw = self.request("/api/bootstrap")
        bootstrap = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(bootstrap["version"], web_backend.APP_VERSION)
        self.assertTrue(bootstrap["version"])
        self.assertEqual(bootstrap["app"], "Beyond Registration Full Business Profile Solution")

        # /api/setup is the one-time first-run door: it answers 200 when it creates
        # the first administrator, and 409 once an administrator already exists -
        # which is the state of any machine that has been set up, test HOME or not.
        # Signing in afterwards is what proves the account is real either way.
        status, _, _ = self.request("/api/setup", "POST", {
            "full_name": "Test Administrator",
            "username": "testadmin",
            "password": "TestPassword123!",
        })
        self.assertIn(status, (200, 409))
        status, _, raw = self.request("/api/login", "POST", {
            "username": "testadmin",
            "password": "TestPassword123!",
        })
        self.assertEqual(status, 200)
        # The session cookie the server sets is marked Secure, so a standard cookie
        # jar will not send it back over the plain-HTTP disposable server this test
        # starts. Take the cookie from the reply and send it explicitly, so the rest
        # of the workflow is signed in on any Python version.
        jar = next(cookie for cookie in self.jar if cookie.name == "br_session")
        self.br_session = f"{jar.name}={jar.value}"

        # Vision conversation history is stored in the local database and restored.
        status, _, raw = self.request("/api/vision/history")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["messages"], [])
        saved_vision = [
            {"role": "user", "content": "How many employees do we have?"},
            {"role": "assistant", "content": "There are five employees."},
        ]
        status, _, raw = self.request("/api/vision/history", "PUT", {"messages": saved_vision})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["count"], 2)
        status, _, raw = self.request("/api/vision/history")
        self.assertEqual(json.loads(raw)["messages"], saved_vision)
        status, _, raw = self.request("/api/vision/history", "DELETE")
        self.assertEqual(status, 200)
        status, _, raw = self.request("/api/vision/history")
        self.assertEqual(json.loads(raw)["messages"], [])

        status, _, raw = self.request("/api/employees", "POST", {
            "employee_no": "T001", "first_name": "Test", "last_name": "Employee",
            "job_title": "Caregiver", "employment_status": "Active", "whatsapp_number": "27821234567",
        })
        self.assertEqual(status, 201)
        employee_id = json.loads(raw)["id"]

        status, _, raw = self.request("/api/cameras")
        camera_state = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(camera_state["retention_days"], 3)
        camera_folder = str(Path(TEST_HOME) / "camera-recordings-test")
        status, _, raw = self.request("/api/cameras/settings", "PUT", {
            "recording_folder": camera_folder,
            "retention_days": 3,
        })
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["recording_folder"], camera_folder)
        status, _, raw = self.request("/api/cameras/footage/preview", "POST", {"month": "2026-11"})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["count"], 0)
        status, _, raw = self.request(f"/api/employees/{employee_id}")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["employee"]["employee_no"], "T001")

        # Audit ledger is hash-linked, verifiable, and append-only.
        status, _, raw = self.request("/api/audit/verify")
        verification = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertTrue(verification["valid"], verification)
        self.assertGreaterEqual(verification["total"], 1)
        status, _, raw = self.request("/api/audit/export")
        exported = json.loads(raw)
        self.assertTrue(exported["verification"]["valid"])
        self.assertTrue(exported["items"][-1]["entry_hash"])
        with self.assertRaises(Exception):
            web_backend.SERVICE.store.conn.execute("UPDATE audit_log SET details='tampered' WHERE id=?", (exported["items"][-1]["id"],))

        store = web_backend.SERVICE.store
        store.conn.execute(
            "INSERT INTO employee_contracts(employee_id,contract_type,title,start_date,end_date,status,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (employee_id, "Employment", "Test contract", "2026-01-01", "2026-12-31", "Active", "", "2026-01-01", "2026-01-01"),
        )
        store.conn.commit()

        status, _, raw = self.request("/api/payroll/calculate", "POST", {
            "weekday_hours": 10, "saturday_hours": 0, "sunday_hours": 0,
            "public_holiday_hours": 0, "other_deductions": 25,
        })
        calculation = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertAlmostEqual(calculation["gross_pay"], 400.00)
        self.assertAlmostEqual(calculation["uif"], 4.00)
        self.assertAlmostEqual(calculation["employer_uif"], 4.00)
        self.assertAlmostEqual(calculation["net_pay"], 371.00)

        for period, status_value, notes in (
            ("2026-10", "Paid", "Previous approved period"),
            ("2026-11", "Approved", "Test deduction explanation"),
        ):
            status, _, raw = self.request("/api/payroll", "POST", {
                "employee_id": employee_id, "pay_period": period, "pay_date": period + "-30",
                "weekday_hours": 10, "other_deductions": 25 if period == "2026-11" else 0,
                "notes": notes, "status": status_value,
            })
            self.assertEqual(status, 201)
            payroll_id = json.loads(raw)["id"]

        status, headers, pdf = self.request(f"/api/payroll/{payroll_id}/payslip")
        self.assertEqual(status, 200)
        self.assertIn("application/pdf", headers.get("Content-Type", ""))
        self.assertTrue(pdf.startswith(b"%PDF"))
        try:
            from pypdf import PdfReader
        except ImportError:
            self.skipTest("Install pypdf to run PDF layout/content assertions.")
        import io
        reader = PdfReader(io.BytesIO(pdf))
        self.assertEqual(len(reader.pages), 1)
        box = reader.pages[0].mediabox
        self.assertGreater(float(box.width), float(box.height), "Payslip must be landscape.")
        pdf_text = "\n".join(page.extract_text() or "" for page in reader.pages)
        self.assertIn("Test deduction explanation", pdf_text)
        self.assertIn("Current contract from 2026-01-01", pdf_text)
        self.assertIn("Gross earnings to date", pdf_text)
        self.assertNotIn("PAYE", pdf_text.upper())

        status, _, raw = self.request("/api/compliance")
        self.assertEqual(status, 200)
        self.assertIn("anomalies", json.loads(raw))

        status, _, raw = self.request("/api/backup", "POST", {})
        self.assertEqual(status, 200)
        backup_info = json.loads(raw)
        backup = Path(backup_info["path"])
        self.assertTrue(backup.is_file())

        status, _, raw = self.request("/api/backup", "GET")
        self.assertEqual(status, 200)
        listing = json.loads(raw)
        self.assertIn("items", listing)
        self.assertTrue(any(b["name"] == backup_info["name"] for b in listing["items"]))

        status, _, raw = self.request(f"/api/backup/download?name={backup_info['name']}", "GET")
        self.assertEqual(status, 200)
        self.assertTrue(raw.startswith(b"PK"))

        # New client without the authenticated cookie must not read business records.
        anonymous = urllib.request.build_opener()
        request = urllib.request.Request(self.base + "/api/dashboard")
        with self.assertRaises(urllib.error.HTTPError) as caught:
            anonymous.open(request, timeout=10)
        self.assertEqual(caught.exception.code, 401)

        # Simulate an administrator bypassing SQLite append-only protection: verifier must detect it.
        store.conn.execute("DROP TRIGGER IF EXISTS audit_log_no_update")
        store.conn.execute("UPDATE audit_log SET details='tampered outside application' WHERE id=(SELECT MIN(id) FROM audit_log)")
        store.conn.commit()
        status, _, raw = self.request("/api/audit/verify")
        tamper_check = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertFalse(tamper_check["valid"])
        self.assertIsNotNone(tamper_check["first_invalid_id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
