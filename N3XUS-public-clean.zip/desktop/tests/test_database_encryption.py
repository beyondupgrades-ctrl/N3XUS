"""Disposable-database checks for at-rest encryption. Never opens the live data folder."""
from __future__ import annotations

import os
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import vault_stub  # noqa: E402
vault_stub.install()

from database_encryption import (  # noqa: E402
    MAGIC,
    DatabaseBusyError,
    WriterLock,
    _LOCK_FILES,
    _pid_alive,
    _sqlite_snapshot,
    connect_database,
    decrypt_payload,
    load_or_create_key,
    write_encrypted,
    writer_lock_path,
)


class DatabaseEncryptionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db = self.root / "your-userd_registration.db"

    def tearDown(self):
        self.temp.cleanup()

    def test_new_database_is_encrypted_and_reopens(self):
        connection = connect_database(self.db, self.root)
        connection.execute("CREATE TABLE employees(id INTEGER PRIMARY KEY, name TEXT)")
        connection.execute("INSERT INTO employees(name) VALUES(?)", ("Encryption Marker",))
        connection.commit()
        connection.close()
        raw = self.db.read_bytes()
        self.assertTrue(raw.startswith(MAGIC))
        self.assertNotIn(b"Encryption Marker", raw)
        self.assertNotIn(b"SQLite format 3", raw)
        reopened = connect_database(self.db, self.root)
        try:
            row = reopened.execute("SELECT name FROM employees").fetchone()
            self.assertEqual(row[0], "Encryption Marker")
        finally:
            reopened.close()

    def test_plaintext_database_is_migrated_in_place(self):
        plain = sqlite3.connect(self.db)
        plain.execute("CREATE TABLE employees(id INTEGER PRIMARY KEY, name TEXT)")
        plain.execute("INSERT INTO employees(name) VALUES('Existing Person')")
        plain.commit()
        plain.close()
        self.assertTrue(self.db.read_bytes().startswith(b"SQLite format 3"))
        connection = connect_database(self.db, self.root)
        try:
            self.assertEqual(connection.execute("SELECT name FROM employees").fetchone()[0], "Existing Person")
        finally:
            connection.close()
        self.assertTrue(self.db.read_bytes().startswith(MAGIC))
        self.assertFalse((Path(str(self.db) + "-wal")).exists())

    def test_wal_database_can_set_memory_journal_after_open(self):
        plain = sqlite3.connect(self.db)
        plain.execute("PRAGMA journal_mode=WAL")
        plain.execute("CREATE TABLE employees(id INTEGER PRIMARY KEY, name TEXT)")
        plain.execute("INSERT INTO employees(name) VALUES('WAL Person')")
        plain.commit()
        plain.close()
        snapshot = _sqlite_snapshot(self.db)
        self.assertEqual(snapshot[18], 2)
        write_encrypted(self.db, load_or_create_key(self.root), snapshot)
        connection = connect_database(self.db, self.root)
        try:
            self.assertEqual(connection.execute("PRAGMA journal_mode = MEMORY").fetchone()[0], "memory")
            self.assertEqual(connection.execute("SELECT name FROM employees").fetchone()[0], "WAL Person")
        finally:
            connection.close()

    def test_other_windows_key_cannot_open_the_file(self):
        connection = connect_database(self.db, self.root)
        connection.execute("CREATE TABLE sample(value TEXT)")
        connection.execute("INSERT INTO sample(value) VALUES('secret-row')")
        connection.commit()
        connection.close()
        elsewhere = self.root / "other-profile"
        elsewhere.mkdir()
        copied = elsewhere / "your-userd_registration.db"
        copied.write_bytes(self.db.read_bytes())
        with self.assertRaises(ValueError):
            connect_database(copied, elsewhere)

    def test_sealed_key_decrypts_a_backup_payload(self):
        connection = connect_database(self.db, self.root)
        connection.execute("CREATE TABLE sample(value TEXT)")
        connection.commit()
        connection.close()
        key = load_or_create_key(self.root)
        plaintext = decrypt_payload(self.db.read_bytes(), key)
        self.assertTrue(plaintext.startswith(b"SQLite format 3"))


class WriterLockLivenessTests(unittest.TestCase):
    """A live server must keep its lock, however it was started.

    Windows `os.kill(pid, 0)` is not a liveness test: Python's os.kill opens
    the process with PROCESS_ALL_ACCESS, so a hidden, elevated or
    console-detached server raises PermissionError while it is running fine.
    The lock guard then read a live server as dead, let a second process take
    its lock and deleted it on the way out - leaving the server unprotected.
    These checks pin the OS-level answer that replaced it.
    """

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db = self.root / "your-userd_registration.db"
        self.lock_path = writer_lock_path(self.db)

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def _spawn(*args: str) -> subprocess.Popen:
        return subprocess.Popen([sys.executable, *args],
                                stdin=subprocess.DEVNULL,
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,
                                cwd=str(Path(__file__).resolve().parents[1]))

    def _wait_for(self, predicate, seconds: float = 20.0) -> bool:
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.05)
        return predicate()

    @unittest.skipUnless(os.name == "nt", "the detached-process quirk is Windows-only")
    def test_a_detached_hidden_process_is_alive(self):
        # DETACHED_PROCESS + hidden window: no console, no inherited handles -
        # the way NEXUS starts its server, and the case os.kill(pid, 0) got wrong.
        detached = self._spawn("-c", "import time; time.sleep(30)")
        try:
            self.assertTrue(_pid_alive(detached.pid),
                            "a running detached process must read as alive")
            self.assertTrue(_pid_alive(os.getpid()))
            self.assertFalse(_pid_alive(0))
        finally:
            detached.kill()
            detached.wait(timeout=20)
        self.assertTrue(self._wait_for(lambda: not _pid_alive(detached.pid)),
                        "a finished process must read as gone")

    @unittest.skipUnless(os.name == "nt", "the detached-process quirk is Windows-only")
    def test_a_detached_server_keeps_its_lock(self):
        holder = self._spawn("-c",
                             "import sys, time; sys.path.insert(0, %r); "
                             "import database_encryption as de; "
                             "de.connect_database(%r, %r); "
                             "print('HELD', flush=True); time.sleep(120)"
                             % (str(Path(__file__).resolve().parents[1]),
                                str(self.db), str(self.root)))
        try:
            self.assertTrue(self._wait_for(self.lock_path.exists), "the holder never took the lock")
            self.assertTrue(self._wait_for(
                lambda: f"pid={holder.pid}" in self.lock_path.read_text(encoding="utf-8")),
                "the lock file does not name the holder")
            # Idle long enough that the file's age is well past any age rule.
            time.sleep(2.0)
            self.assertTrue(_pid_alive(holder.pid))
            self.assertFalse(WriterLock(self.lock_path)._stale(WriterLock(self.lock_path)._read()),
                             "a live detached server's lock must not look stale")
            with self.assertRaises(DatabaseBusyError) as raised:
                connect_database(self.db, self.root)
            self.assertIn(str(holder.pid), str(raised.exception))
            self.assertIn(f"pid={holder.pid}", self.lock_path.read_text(encoding="utf-8"),
                          "a refused attempt must leave the holder's lock alone")
        finally:
            holder.kill()
            holder.wait(timeout=20)
            for connection in list(_LOCK_FILES.values()):
                try:
                    connection.release()
                except Exception:
                    pass

    def test_a_lock_left_by_a_dead_process_is_taken_over(self):
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path.write_text("pid=999999\ntoken=deadbeefdeadbeef\n"
                                  "started=2026-01-01 00:00:00\nheartbeat=0\n", encoding="utf-8")
        connection = connect_database(self.db, self.root)
        try:
            self.assertEqual(connection._writer_lock.pid, os.getpid())
            self.assertNotIn("pid=999999", self.lock_path.read_text(encoding="utf-8"))
        finally:
            connection.close()
        self.assertFalse(self.lock_path.exists(), "closing the owner removes the lock file")


if __name__ == "__main__":
    unittest.main()