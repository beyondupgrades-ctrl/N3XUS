from __future__ import annotations

import tempfile
import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from camera_service import CameraService
from onvif_client import choose_profile_token


class MemoryStore:
    def __init__(self):
        self.settings = {}

    def attendance_setting(self, key, default=""):
        return self.settings.get(key, default)

    def set_attendance_setting(self, key, value):
        self.settings[key] = value


class MemoryVault:
    def __init__(self):
        self.values = {}

    def get(self, key, default=None):
        return self.values.get(key, default)

    def set(self, key, value):
        if value is None:
            self.values.pop(key, None)
        else:
            self.values[key] = value


class CameraServiceTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = MemoryStore()
        self.vault = MemoryVault()
        self.service = CameraService(self.root, self.store, self.root / "missing-mediamtx.exe", self.vault)
        self.recordings = self.root / "selected-recordings"
        self.service.save_settings(self.recordings, 3)

    def tearDown(self):
        self.service.stop()
        self.temp.cleanup()

    def add_clip(self, name, when, content=b"footage"):
        path = self.recordings / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        stamp = datetime.fromisoformat(when).timestamp()
        import os
        os.utime(path, (stamp, stamp))
        return path

    def test_three_day_retention_is_configured_as_72_hours(self):
        self.vault.set("camera_sources", [{"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://user:secret@YOUR_LAN_IP/live"}])
        config = self.service.render_config()
        self.assertIn("recordDeleteAfter: 72h", config)
        self.assertIn("rtspAddress: 127.0.0.1:8554", config)
        self.assertIn("webrtcAddress: 127.0.0.1:8889", config)
        self.assertNotIn("source_url", str(self.service.snapshot()))
        self.assertNotIn("secret", str(self.service.snapshot()))

    def test_rename_keeps_the_saved_camera_address(self):
        with patch.object(self.service, "restart", return_value=True), patch("camera_service.onvif_stream_url", return_value=""):
            self.service.save_camera("0123456789ab", "Front door", "CH9", None, "YOUR_LAN_IP", "admin", "camera-pass", "123e4567-e89b-12d3-a456-426614174000")
            snapshot = self.service.rename_camera("0123456789ab", "Gate")
        saved = self.vault.get("camera_sources")[0]
        self.assertEqual(saved["name"], "Gate")
        self.assertIn("subtype=1", saved["source_url"])
        self.assertEqual(snapshot["cameras"][0]["name"], "Gate")
        self.assertNotIn("camera-pass", str(snapshot))

    def test_tenda_ip_and_qr_uuid_build_the_playable_stream(self):
        with patch.object(self.service, "restart", return_value=True), patch("camera_service.onvif_stream_url", return_value=""):
            snapshot = self.service.save_camera(None, "Front door", "ch9", None, "YOUR_LAN_IP", "admin", "camera-pass", "123e4567-e89b-12d3-a456-426614174000")
        saved = self.vault.get("camera_sources")[0]
        self.assertIn(":554/ch=1?subtype=1", saved["source_url"])
        self.assertEqual(saved["device_uuid"], "123e4567-e89b-12d3-a456-426614174000")
        self.assertEqual(snapshot["cameras"][0]["model"], "CH9")
        self.assertNotIn("camera-pass", str(snapshot))

    def test_extra_dot_in_the_camera_ip_is_corrected(self):
        corrected = CameraService._validate_source("rtsp://door:camera-pass@192..168.3.105:554/tenda")
        self.assertIn("YOUR_LAN_IP", corrected)
        self.assertNotIn("192..168", corrected)
        with self.assertRaises(ValueError):
            CameraService._validate_source("rtsp://door:camera-pass@not-a-camera:554/tenda")

    def test_rtsp_path_uses_the_username_and_password_the_camera_asks_for(self):
        with patch.object(self.service, "restart", return_value=True), patch("camera_service.onvif_stream_url", return_value="rtsp://YOUR_LAN_IP/ignored") as onvif:
            snapshot = self.service.save_camera(None, "Front door", "CH9", None, "YOUR_LAN_IP", "door", "camera-pass", "", "/ch=1?subtype=0")
        saved = self.vault.get("camera_sources")[0]
        self.assertEqual(saved["source_url"], "rtsp://door:camera-pass@YOUR_LAN_IP:554/ch=1?subtype=0")
        self.assertNotIn("camera-pass", str(snapshot))
        onvif.assert_not_called()

    def test_vlc_viewer_keeps_the_camera_password_out_of_the_command(self):
        vlc = self.root / "vlc.exe"
        vlc.write_bytes(b"")
        self.service.vlc_path = vlc
        self.vault.set("camera_sources", [{"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://user:secret@YOUR_LAN_IP/live"}])
        with patch("camera_service.subprocess.Popen") as popen:
            popen.return_value.poll.return_value = None
            self.service.start_viewers()
        command = popen.call_args.args[0]
        self.assertEqual(command[0], str(vlc))
        self.assertIn("--no-one-instance", command)
        self.assertIn("--avcodec-hw=none", command)
        self.assertIn("-V", command)
        self.assertNotIn("secret", " ".join(command))
        playlist = self.root / "camera-vlc" / "0123456789ab.m3u"
        self.assertIn("secret", playlist.read_text(encoding="utf-8"))
        self.assertEqual(self.service.snapshot()["player"], "vlc")
        self.service.stop()
        self.assertFalse(playlist.exists())
        self.assertEqual(self.service.snapshot()["player"], "")

    def test_a_busy_relay_port_still_opens_the_camera_viewers(self):
        relay = self.root / "mediamtx.exe"
        relay.write_bytes(b"")
        vlc = self.root / "vlc.exe"
        vlc.write_bytes(b"")
        self.service.relay_path = relay
        self.service.vlc_path = vlc
        self.vault.set("camera_sources", [{"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://user:secret@YOUR_LAN_IP/live"}])
        calls = []

        def popen(command, *args, **kwargs):
            process = MagicMock()
            process.poll.return_value = 1 if Path(command[0]).name == "mediamtx.exe" else None
            calls.append(Path(command[0]).name)
            return process

        with patch("camera_service.subprocess.run", return_value=MagicMock(returncode=0)), patch("camera_service.subprocess.Popen", side_effect=popen), patch.object(self.service, "_release_leftover_relay"):
            started = self.service.restart()
        self.assertFalse(started)
        self.assertEqual(calls.count("mediamtx.exe"), 2)
        self.assertIn("vlc.exe", calls)
        self.assertEqual(self.service.snapshot()["player"], "vlc")

    def test_a_second_camera_keeps_the_first_vlc_open(self):
        vlc = self.root / "vlc.exe"
        vlc.write_bytes(b"")
        self.service.vlc_path = vlc
        self.vault.set("camera_sources", [{"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://user:secret@YOUR_LAN_IP/live"}])
        processes = []

        def popen(*args, **kwargs):
            process = MagicMock()
            process.poll.return_value = None
            processes.append(process)
            return process

        with patch("camera_service.subprocess.Popen", side_effect=popen):
            self.service.start_viewers()
            self.vault.set("camera_sources", self.vault.get("camera_sources") + [{"id": "abcdefabcdef", "name": "Garage", "model": "CH7", "path": "camera-abcdefabcdef", "source_url": "rtsp://user:secret@YOUR_LAN_IP/tenda"}])
            self.service.start_viewers()
        self.assertEqual(len(processes), 2)
        processes[0].terminate.assert_not_called()

    def test_edit_form_recalls_the_saved_username_and_password(self):
        with patch.object(self.service, "restart", return_value=True), patch("camera_service.onvif_stream_url", return_value=""):
            self.service.save_camera(None, "Front door", "CH9", None, "YOUR_LAN_IP", "door", "camera-pass", "", "/ch=1?subtype=0")
        saved_id = self.vault.get("camera_sources")[0]["id"]
        form = self.service.camera_form(saved_id)
        self.assertEqual(form["username"], "door")
        self.assertEqual(form["password"], "camera-pass")
        self.assertEqual(form["ip"], "YOUR_LAN_IP")
        self.assertEqual(form["rtsp_path"], "/ch=1?subtype=0")
        self.assertNotIn("camera-pass", str(self.service.snapshot()))

    def test_older_camera_address_still_fills_the_edit_form(self):
        self.vault.set("camera_sources", [{"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://door:camera-pass@YOUR_LAN_IP:8554/onvif/profile1"}])
        form = self.service.camera_form("0123456789ab")
        self.assertEqual(form["username"], "door")
        self.assertEqual(form["password"], "camera-pass")
        self.assertEqual(form["rtsp_path"], "/onvif/profile1")
        with patch.object(self.service, "restart", return_value=True):
            self.service.save_camera("0123456789ab", "Front", "CH9", None, "YOUR_LAN_IP", "door", "camera-pass", "", "/onvif/profile1")
        self.assertIn(":8554/onvif/profile1", self.vault.get("camera_sources")[0]["source_url"])

    def test_status_light_follows_the_viewer_and_the_latest_picture(self):
        camera_id = "0123456789ab"
        self.vault.set("camera_sources", [{"id": camera_id, "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://user:secret@YOUR_LAN_IP/live"}])
        self.assertEqual(self.service.snapshot()["cameras"][0]["status"], "offline")
        process = MagicMock()
        process.poll.return_value = None
        self.service.viewers[camera_id] = process
        self.assertEqual(self.service.snapshot()["cameras"][0]["status"], "connecting")
        picture = self.root / "camera-vlc" / camera_id / "live.jpg"
        picture.parent.mkdir(parents=True)
        picture.write_bytes(b"\xff\xd8ok\xff\xd9")
        self.assertEqual(self.service.snapshot()["cameras"][0]["status"], "online")
        process.poll.return_value = 1
        self.assertEqual(self.service.snapshot()["cameras"][0]["status"], "offline")
        self.assertNotIn("secret", str(self.service.snapshot()))

    def test_refresh_restarts_only_the_selected_camera(self):
        self.vault.set("camera_sources", [
            {"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://user:secret@YOUR_LAN_IP/live"},
            {"id": "abcdefabcdef", "name": "Garage", "model": "CH7", "path": "camera-abcdefabcdef", "source_url": "rtsp://user:secret@YOUR_LAN_IP/tenda"},
        ])
        with patch.object(self.service, "start_viewers") as start:
            snapshot = self.service.refresh_camera("0123456789ab")
        start.assert_called_once_with(refresh_id="0123456789ab")
        self.assertEqual(snapshot["cameras"][1]["name"], "Garage")
        with self.assertRaises(KeyError):
            self.service.refresh_camera("000000000000")

    def test_onvif_profile_choice_prefers_the_smaller_h264_stream(self):
        payload = """<Profiles token="main"><Encoding>H265</Encoding><Width>2560</Width></Profiles>
        <Profiles token="sub"><Encoding>H264</Encoding><Width>640</Width></Profiles>"""
        self.assertEqual(choose_profile_token(payload), "sub")

    def test_onvif_stream_address_is_used_when_the_camera_provides_one(self):
        with patch.object(self.service, "restart", return_value=True), patch("camera_service.onvif_stream_url", return_value="rtsp://YOUR_LAN_IP:554/onvif/profile1"):
            snapshot = self.service.save_camera(None, "Front door", "CH9", None, "YOUR_LAN_IP", "admin", "camera-pass")
        saved = self.vault.get("camera_sources")[0]
        self.assertEqual(saved["source_url"], "rtsp://admin:camera-pass@YOUR_LAN_IP:554/onvif/profile1")
        self.assertNotIn("camera-pass", str(snapshot))

    def test_camera_inventory_is_not_limited_to_forty_streams(self):
        with patch.object(self.service, "restart", return_value=True):
            for index in range(41):
                camera_id=f"{index + 1:012x}"
                self.service.save_camera(camera_id,f"Feed {index + 1}","CH9",f"rtsp://YOUR_LAN_IP/{index + 1}")
        self.assertEqual(len(self.service.snapshot()["cameras"]),41)

    def test_bundled_relay_accepts_generated_local_configuration(self):
        relay = Path(__file__).resolve().parents[1] / "tools" / "mediamtx.exe"
        if not relay.is_file():
            self.skipTest("The packaged MediaMTX executable is not present.")
        self.service.relay_path = relay
        self.vault.set("camera_sources", [{"id": "0123456789ab", "name": "Front", "model": "CH9", "path": "camera-0123456789ab", "source_url": "rtsp://127.0.0.1:1/not-a-camera"}])
        # Skip instead of failing when the fixed relay ports are already held by
        # another instance of this executable (the desktop app or a stale relay):
        # a second MediaMTX on the same ports cannot start on any machine.
        if self.service._relay_ports_in_use(relay):
            self.skipTest("The camera relay ports (RTSP 8554 / WebRTC 8889 / UDP 8000) are already in use on this machine.")
        self.assertTrue(self.service.restart())
        self.assertIsNone(self.service.process.poll())

    def test_month_preview_includes_only_video_files_in_selected_folder(self):
        first = self.add_clip("camera-a/first.mp4", "2026-10-05T12:00:00", b"one")
        second = self.add_clip("camera-b/second.fmp4", "2026-10-20T08:30:00", b"two")
        ignored = self.add_clip("notes.txt", "2026-10-20T08:30:00", b"not video")
        outside = self.root / "elsewhere" / "outside.mp4"
        outside.parent.mkdir()
        outside.write_bytes(b"outside")
        preview = self.service.footage_preview(month="2026-10")
        self.assertEqual(preview["count"], 2)
        self.assertEqual(preview["bytes"], first.stat().st_size + second.stat().st_size)
        self.assertNotIn(str(ignored), preview["files"])
        self.assertNotIn(str(outside), preview["files"])

    def test_time_range_and_confirmed_delete_are_limited_to_matches(self):
        in_range = self.add_clip("camera-a/in-range.mp4", "2026-10-05T12:00:00", b"clip")
        before = self.add_clip("camera-a/before.mp4", "2026-10-05T09:00:00", b"old")
        outside = self.root / "outside.mp4"
        outside.write_bytes(b"keep")
        query = {"start": "2026-10-05T10:00:00", "end": "2026-10-05T14:00:00"}
        with self.assertRaises(ValueError):
            self.service.delete_footage(**query, confirm=False)
        result = self.service.delete_footage(**query, confirm=True)
        self.assertEqual(result["deleted"], 1)
        self.assertEqual(result["bytes"], len(b"clip"))
        self.assertFalse(in_range.exists())
        self.assertTrue(before.exists())
        self.assertTrue(outside.exists())

    def test_delete_covers_matches_your-userd_preview_limit(self):
        for index in range(105):
            self.add_clip(f"camera-a/clip-{index}.mp4", "2026-10-05T12:00:00")
        preview = self.service.footage_preview(month="2026-10")
        self.assertEqual(preview["count"], 105)
        self.assertEqual(preview["more"], 5)
        result = self.service.delete_footage(month="2026-10", confirm=True)
        self.assertEqual(result["deleted"], 105)
        self.assertEqual(self.service.footage_preview(month="2026-10")["count"], 0)


if __name__ == "__main__":
    unittest.main()