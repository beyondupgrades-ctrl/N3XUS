"""Isolated tests for the optional owner-supplied extension modules."""
import hashlib
import io
import sqlite3
import sys
import tempfile
import unittest
import zipfile
from contextlib import closing
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from your-userd_extensions import (
    initialize_database, SecurityManager, DocumentVault, SouthAfricanPayrollEngine,
    AnomalyShield, WheelchairActivityTracker, OfflineSyncManager,
    BackupRecoveryManager, InAppUpgrader,
)
from cryptography.fernet import Fernet
from system_monitor import SystemMonitor


class ExtensionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_database_and_audit(self):
        db = self.root / "test.db"
        initialize_database(db)
        entry = SecurityManager().create_audit_entry("Dean Brown", "test", {"ok": True}, db)
        with closing(sqlite3.connect(db)) as conn:
            with conn:
                row = conn.execute("SELECT user, action, hash FROM audit_ledger").fetchone()
        self.assertEqual(row, ("Dean Brown", "test", entry["hash"]))

    def test_document_quarantine_keeps_original(self):
        original = self.root / "proof.pdf"
        original.write_bytes(b"test-document")
        result = DocumentVault(self.root / "vault").process_upload(str(original), "Contract")
        self.assertEqual(result["status"], "quarantined")
        self.assertTrue(original.exists())
        self.assertEqual(result["sha256"], hashlib.sha256(b"test-document").hexdigest())
        self.assertTrue(Path(result["quarantine_path"]).is_file())

    def test_payroll_and_anomaly(self):
        engine = SouthAfricanPayrollEngine(100)
        self.assertEqual(engine.calculate_gross_pay({"weekday": 8, "saturday": 2, "sunday": 1}), 1300.0)
        with self.assertRaises(ValueError):
            engine.calculate_gross_pay({"weekday": -1})
        self.assertTrue(AnomalyShield().evaluate("unexpected_bank_details", {})["requires_override"])

    def test_wheelchair_access_and_photo(self):
        denied = WheelchairActivityTracker("Caregiver", False)
        self.assertEqual(denied.start_walk("E1", "Site") ["status"], "access_denied")
        tracker = WheelchairActivityTracker("Caregiver", True)
        self.assertEqual(tracker.start_walk("E1", "Site")["status"], "walk_started")
        photo = self.root / "end.jpg"; photo.write_bytes(b"photo")
        self.assertTrue(tracker.end_walk("E1", str(photo))["photo_verified"])

    def test_offline_sync_retains_failed_items(self):
        manager = OfflineSyncManager(self.root / "queue.json")
        manager.queue_submission({"id": 1})
        manager.queue_submission({"id": 2})
        result = manager.process_sync_queue(True, lambda item: item["id"] == 1)
        self.assertEqual(result["synced_items"], 1)
        self.assertEqual(result["pending_items"], 1)
        self.assertEqual(manager.process_sync_queue(True, lambda item: True)["pending_items"], 0)

    def test_encrypted_backup_and_restore(self):
        db = self.root / "live.db"
        with closing(sqlite3.connect(db)) as conn:
            with conn:
                conn.execute("CREATE TABLE sample(value TEXT)")
                conn.execute("INSERT INTO sample VALUES ('before')")
        manager = BackupRecoveryManager(db, self.root / "backups")
        key = Fernet.generate_key()
        result = manager.create_encrypted_backup(key)
        self.assertEqual(result["status"], "success")
        with closing(sqlite3.connect(db)) as conn:
            with conn:
                conn.execute("UPDATE sample SET value='after'")
        restored = manager.restore_encrypted_backup(result["backup_file"], key)
        self.assertEqual(restored["status"], "success")
        with closing(sqlite3.connect(db)) as conn:
            with conn:
                self.assertEqual(conn.execute("SELECT value FROM sample").fetchone()[0], "before")

    def test_upgrader_stages_valid_code_only(self):
        upgrader = InAppUpgrader(self.root / "upgrades")
        self.assertEqual(upgrader.apply_code_upgrade("intruder", "extra.py", "x=1")["status"], "unauthorized")
        self.assertEqual(upgrader.apply_code_upgrade("Dean Brown", "../evil.py", "x=1")["status"], "error")
        self.assertEqual(upgrader.apply_code_upgrade("Dean Brown", "extra.py", "x = 1")["status"], "staged")
        self.assertTrue((self.root / "upgrades" / "extra.py.pending").is_file())

    def test_upgrader_pending_files_can_be_reviewed_and_removed_without_execution(self):
        upgrader=InAppUpgrader(self.root/"role-upgrades",admin_validator=lambda username:username=="app-admin")
        self.assertEqual(upgrader.apply_code_upgrade("Dean Brown","legacy.py","value=1")["status"],"unauthorized")
        source="value = 7\n"
        self.assertEqual(upgrader.apply_code_upgrade("app-admin","review.py",source)["status"],"staged")
        listed=upgrader.list_pending()
        self.assertEqual(len(listed),1)
        pending=upgrader.read_pending("review.py.pending")
        self.assertEqual(pending["content"].splitlines(),source.splitlines())
        self.assertEqual(pending["sha256"],listed[0]["sha256"])
        upgrader.delete_pending("review.py.pending")
        self.assertEqual(upgrader.list_pending(),[])

    def test_upgrader_exports_pending_scripts_as_non_executable_review_zip(self):
        upgrader=InAppUpgrader(self.root/"zip-upgrades",admin_validator=lambda username:username=="app-admin")
        source="value = 7\n"
        self.assertEqual(upgrader.apply_code_upgrade("app-admin","review.py",source)["status"],"staged")
        bundle,summary=upgrader.export_pending_zip()
        self.assertEqual(summary["files"],1)
        with zipfile.ZipFile(io.BytesIO(bundle)) as archive:
            self.assertEqual(set(archive.namelist()),{"review.py","STAGED_SCRIPTS_MANIFEST.txt"})
            self.assertEqual(archive.read("review.py").decode("utf-8"),source)
            manifest=archive.read("STAGED_SCRIPTS_MANIFEST.txt").decode("utf-8")
            self.assertIn("did not execute or install",manifest)
            self.assertIn(hashlib.sha256(source.encode("utf-8")).hexdigest(),manifest)
        with self.assertRaises(ValueError):
            InAppUpgrader(self.root/"empty-upgrades").export_pending_zip()
        protected=InAppUpgrader(self.root/"credential-upgrades",admin_validator=lambda username:username=="app-admin")
        synthetic_value="synthetic-for-test-only"
        blocked_stage=protected.apply_code_upgrade("app-admin","example.py",f'api_key = "{synthetic_value}"\n')
        self.assertEqual(blocked_stage["status"],"error")
        self.assertNotIn(synthetic_value,blocked_stage["message"])
        (self.root/"credential-upgrades"/"tampered.py.pending").write_text(f'api_key = "{synthetic_value}"\n',encoding="utf-8")
        with self.assertRaises(ValueError) as blocked:
            protected.export_pending_zip()
        self.assertNotIn(synthetic_value,str(blocked.exception))

    def test_system_monitor_reports_health_without_exposing_paths(self):
        db=self.root/"health.db"
        conn=sqlite3.connect(db)
        try:
            conn.execute("CREATE TABLE sample(value TEXT)")
            result=SystemMonitor(conn,self.root,self.root/"backups").snapshot(camera_relay_running=True)
        finally:
            conn.close()
        self.assertEqual(result["database"],{"status":"healthy","integrity":"ok"})
        self.assertIsInstance(result["storage"]["free_bytes"],int)
        self.assertEqual(result["backups"]["count"],0)
        self.assertEqual(result["camera_relay"],"running")
        self.assertEqual(result["weather"]["status"],"not_configured")
        self.assertEqual(result["autonomy"],{"status":"paused","global_pause":True,"execution_enabled":False,"level":0})
        self.assertNotIn(str(self.root),str(result))


if __name__ == "__main__":
    unittest.main()
