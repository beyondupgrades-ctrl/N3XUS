"""End-to-end tests for the in-house business modules (finance, AP/AR, inventory,
projects, CRM, notifications, knowledge base, expenses, documents, incidents,
consent, tax and the EVOLV3 academy).

These exercise the real HTTP API surface, not the module functions directly, so
route parsing and permissions are covered too.
"""
import json, os, sqlite3, sys, tempfile, threading, unittest, urllib.request, urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import web_backend
import academy, ap_ar, consent_register, crm, document_mgmt, expense_claims
import finance, incidents, inventory, knowledge_base, notifications, projects


class FakeStore:
    def __init__(self):
        self.conn = sqlite3.connect(':memory:', check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript('''
            CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT);
            CREATE TABLE admin_permission_overrides(admin_id INTEGER PRIMARY KEY,grants_json TEXT,scope_type TEXT,scope_values_json TEXT,updated_by TEXT,updated_at TEXT);
            INSERT INTO admins VALUES(1,'Test Admin','admin','hash','',1,'Administrator');
        ''')
        self.conn.commit()
        for module in (finance, ap_ar, inventory, projects, crm, notifications,
                       knowledge_base, expense_claims, document_mgmt, incidents,
                       consent_register, academy):
            module.ensure_schema(self.conn)

    def employee(self, eid):
        return None

    def log(self, *args, **kwargs):
        pass


class NewModulesApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_store = web_backend.SERVICE.store
        cls.old_sessions = web_backend.SERVICE.sessions
        cls.old_session_expiries = web_backend.SERVICE.session_expiries
        cls.old_login_failures = web_backend.SERVICE.login_failures
        web_backend.SERVICE.store = FakeStore()
        web_backend.SERVICE.sessions = {'admin-session': 'admin'}
        web_backend.SERVICE.session_expiries = {}
        web_backend.SERVICE.login_failures = {}
        _saved = {k: os.environ.get(k) for k in ("BR_SERVER_PORT", "BR_TLS")}
        os.environ["BR_SERVER_PORT"] = "0"
        os.environ["BR_TLS"] = "off"
        try:
            cls.server, port = web_backend.make_server()
        finally:
            for k, v in _saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

        cls.url = f'http://127.0.0.1:{port}'
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close()
        web_backend.SERVICE.store = cls.old_store
        web_backend.SERVICE.sessions = cls.old_sessions
        web_backend.SERVICE.session_expiries = cls.old_session_expiries
        web_backend.SERVICE.login_failures = cls.old_login_failures

    def request(self, path, payload=None, cookie='br_session=admin-session', method=None):
        data = json.dumps(payload).encode() if payload is not None else None
        headers = {'Content-Type': 'application/json'}
        if cookie:
            headers['Cookie'] = cookie
        req = urllib.request.Request(self.url + path, data=data, headers=headers,
                                     method=method or ('POST' if data is not None else 'GET'))
        return json.loads(urllib.request.urlopen(req).read().decode())

    # ---------- academy ----------
    def test_academy_courses_are_seeded(self):
        body = self.request('/api/academy/courses')
        self.assertGreaterEqual(len(body['items']), 2)
        self.assertTrue(any(c['title'] == 'Dementia Care Basics' for c in body['items']))

    def test_academy_course_detail_contains_lessons_and_quizzes(self):
        body = self.request('/api/academy/courses/1')
        self.assertEqual(body['course']['id'], 1)
        self.assertGreaterEqual(len(body['lessons']), 3)
        self.assertTrue(body['lessons'][0]['quizzes'])

    def test_academy_progress_and_certificate(self):
        course = self.request('/api/academy/courses/1')
        for lesson in course['lessons']:
            result = self.request('/api/academy/progress', {
                'user': 'admin', 'course_id': 1,
                'lesson_id': lesson['id'], 'score': 100})
        self.assertIsNotNone(result['certificate'])
        self.assertTrue(result['certificate'].startswith('CERT-'))
        progress = self.request('/api/academy/progress?user=admin&course_id=1')
        self.assertEqual(progress['percent'], 100)

    def test_academy_admin_can_create_publish_and_extend_course(self):
        created = self.request('/api/academy/courses', {
            'title': 'Manual Handling', 'audience': 'Professional',
            'description': 'Safe patient handling.'})
        self.assertTrue(created['ok'])
        cid = created['id']

        # Draft courses are hidden from the learner list.
        listed = self.request('/api/academy/courses')
        self.assertFalse(any(c['id'] == cid for c in listed['items']))

        published = self.request(f'/api/academy/courses/{cid}/publish', {})
        self.assertEqual(published['status'], 'Published')
        listed = self.request('/api/academy/courses')
        self.assertTrue(any(c['id'] == cid for c in listed['items']))

        lesson = self.request('/api/academy/lessons', {
            'course_id': cid, 'title': 'Lifting technique',
            'body': 'Bend the knees, keep the load close.'})
        self.assertTrue(lesson['ok'])
        quiz = self.request('/api/academy/quizzes', {
            'lesson_id': lesson['id'], 'question': 'Where should the load be?',
            'option_a': 'Far away', 'option_b': 'Close to the body',
            'option_c': 'Above the head', 'option_d': 'On one shoulder',
            'correct': 'B', 'explanation': 'Keep the load close.'})
        self.assertTrue(quiz['ok'])

    # ---------- knowledge base (regression) ----------
    def test_knowledge_base_list_without_category_returns_items(self):
        self.request('/api/kb', {'title': 'Leave policy', 'body': 'Apply in advance.'})
        body = self.request('/api/kb')
        self.assertIsInstance(body['items'], list)
        self.assertGreaterEqual(len(body['items']), 1)
        found = self.request('/api/kb/search?q=leave')
        self.assertGreaterEqual(len(found['items']), 1)

    # ---------- finance / AP/AR ----------
    def test_finance_chart_of_accounts_and_trial_balance(self):
        accounts = self.request('/api/finance/accounts')
        self.assertIsInstance(accounts['items'], list)
        self.request('/api/finance/accounts', {
            'code': 'Z999', 'name': 'Test account', 'type': 'Expense'})
        accounts = self.request('/api/finance/accounts')
        self.assertTrue(any(a['code'] == 'Z999' for a in accounts['items']))
        tb = self.request('/api/finance/trial-balance')
        self.assertIsInstance(tb['items'], list)

    def test_ap_ar_invoice_and_aging(self):
        ap = self.request('/api/ap-ar/ap', {
            'supplier': 'Acme Supplies', 'amount': 1500,
            'due_date': '2026-12-01', 'invoice_no': 'AP-1'})
        ar = self.request('/api/ap-ar/ar', {
            'customer': 'Care Group', 'amount': 2200,
            'due_date': '2026-12-15', 'invoice_no': 'AR-1'})
        self.assertTrue(ap['ok'] and ar['ok'])
        self.assertTrue(any(x['invoice_no'] == 'AP-1' for x in self.request('/api/ap-ar/ap')['items']))
        self.assertTrue(any(x['invoice_no'] == 'AR-1' for x in self.request('/api/ap-ar/ar')['items']))
        aging = self.request('/api/ap-ar/aging')
        self.assertIn('ar', aging); self.assertIn('ap', aging)

    def test_tax_calculations(self):
        payroll = self.request('/api/tax/payroll', {'gross_monthly': 30000})
        self.assertGreater(payroll['paye'], 0)
        self.assertGreater(payroll['uif_employee'], 0)
        vat = self.request('/api/tax/vat', {'amount_excl': 100})
        self.assertAlmostEqual(vat['vat'], 15.0, places=2)
        self.assertAlmostEqual(vat['incl'], 115.0, places=2)

    # ---------- inventory / projects ----------
    def test_inventory_stock_movement_and_low_stock(self):
        item = self.request('/api/inventory', {
            'name': 'Gloves', 'sku': 'GLV-1', 'location': 'Store',
            'qty': 5, 'reorder': 10, 'unit': 'box', 'cost': 50})
        self.assertTrue(item['ok'])
        self.request('/api/inventory/adjust', {
            'item_id': item['id'], 'qty': -2, 'type': 'issue', 'reference': 'WARD-1'})
        items = self.request('/api/inventory')['items']
        saved = next(x for x in items if x['id'] == item['id'])
        self.assertEqual(saved['qty_on_hand'], 3)
        low = self.request('/api/inventory/low-stock')['items']
        self.assertTrue(any(x['id'] == item['id'] for x in low))

    def test_project_tasks_and_time(self):
        project = self.request('/api/projects', {
            'name': 'Home care rollout', 'status': 'Active',
            'start_date': '2026-11-01', 'budget': 50000})
        self.assertTrue(project['ok'])
        pid = project['id']
        task = self.request(f'/api/projects/{pid}/tasks', {
            'title': 'Recruit caregivers', 'status': 'Todo', 'hours': 8})
        self.assertTrue(task['ok'])
        tasks = self.request(f'/api/projects/{pid}/tasks')['items']
        self.assertTrue(any(t['id'] == task['id'] for t in tasks))
        self.request(f'/api/projects/{pid}/time', {
            'hours': 2, 'employee': 'admin', 'task_id': task['id']})
        self.assertTrue(any(p['id'] == pid for p in self.request('/api/projects')['items']))

    # ---------- CRM / notifications ----------
    def test_crm_lead_and_opportunity(self):
        lead = self.request('/api/crm/leads', {
            'name': 'Thandi Mokoena', 'company': 'Sunrise Care',
            'email': 'thandi@example.com', 'phone': '0100000000', 'source': 'Referral'})
        self.assertTrue(lead['ok'])
        opp = self.request('/api/crm/opportunities', {
            'title': 'Annual care contract', 'lead_id': lead['id'],
            'stage': 'Prospect', 'value': 120000, 'close_date': '2026-12-31'})
        self.assertTrue(opp['ok'])
        self.assertTrue(any(x['id'] == lead['id'] for x in self.request('/api/crm/leads')['items']))
        self.assertTrue(any(x['id'] == opp['id'] for x in self.request('/api/crm/opportunities')['items']))
        self.assertTrue(self.request('/api/crm/activity', {
            'activity_type': 'call', 'notes': 'Intro call', 'lead_id': lead['id']})['ok'])

    def test_notifications_push_and_read(self):
        pushed = self.request('/api/notifications', {
            'recipient': 'admin', 'title': 'Backup complete',
            'body': 'Nightly backup finished.', 'level': 'info'})
        self.assertTrue(pushed['ok'])
        listing = self.request('/api/notifications')
        self.assertTrue(any(n['id'] == pushed['id'] for n in listing['items']))
        self.assertGreaterEqual(listing['unread'], 1)
        self.assertTrue(self.request(f'/api/notifications/{pushed["id"]}/read', {})['ok'])

    # ---------- expenses / documents / incidents / consent ----------
    def test_expense_claim_submit_and_decide(self):
        claim = self.request('/api/expenses', {
            'employee': 'admin', 'amount': 450.75, 'category': 'Travel',
            'description': 'Client visit mileage'})
        self.assertTrue(claim['ok'])
        self.assertTrue(self.request(f'/api/expenses/{claim["id"]}/decide', {
            'decision': 'Approved'})['ok'])
        claims = self.request('/api/expenses')['items']
        self.assertTrue(any(c['id'] == claim['id'] for c in claims))

    def test_document_versioning(self):
        doc = self.request('/api/documents', {
            'title': 'Infection control policy', 'category': 'Clinical'})
        self.assertTrue(doc['ok'])
        version = self.request(f'/api/documents/{doc["id"]}/version', {
            'file_name': 'policy.txt', 'mime_type': 'text/plain',
            'content_b64': 'SGVhbHRoeSBwb2xpY3k='})
        self.assertTrue(version['ok'])
        versions = self.request(f'/api/documents/{doc["id"]}/versions')['items']
        self.assertGreaterEqual(len(versions), 1)

    def test_incident_report_and_resolve(self):
        incident = self.request('/api/incidents', {
            'title': 'Wet floor', 'description': 'Spill near entrance',
            'location': 'Reception', 'severity': 'High'})
        self.assertTrue(incident['ok'])
        self.assertTrue(self.request(f'/api/incidents/{incident["id"]}/resolve', {})['ok'])
        incidents_list = self.request('/api/incidents')['items']
        self.assertTrue(any(i['id'] == incident['id'] for i in incidents_list))

    def test_consent_grant_and_withdraw(self):
        granted = self.request('/api/consent', {
            'subject_type': 'employee', 'subject_id': 1,
            'consent_type': 'data_processing', 'notes': 'POPIA consent'})
        self.assertTrue(granted['ok'])
        listed = self.request('/api/consent/subject?subject_type=employee&subject_id=1')['items']
        self.assertTrue(any(c['id'] == granted['id'] for c in listed))
        self.assertTrue(self.request(f'/api/consent/{granted["id"]}/withdraw', {})['ok'])


if __name__ == '__main__':
    unittest.main()
