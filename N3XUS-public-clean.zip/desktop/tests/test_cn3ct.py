"""End-to-end tests for the CN3CT private networking control plane.

Covers organisations, address allocation, device registration using public keys
only, gateway configuration, entitlement enforcement for customer organisations,
revocation and honest diagnostics.
"""
import base64, json, os, sqlite3, sys, tempfile, threading, unittest, urllib.error, urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import web_backend
import cn3ct, master_control

PUBLIC_KEY = base64.b64encode(b'c' * 32).decode('ascii')
GATEWAY_KEY = base64.b64encode(b'g' * 32).decode('ascii')


class FakeStore:
    def __init__(self):
        self.conn = sqlite3.connect(':memory:', check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript('''
            CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT);
            CREATE TABLE admin_permission_overrides(admin_id INTEGER PRIMARY KEY,grants_json TEXT,scope_type TEXT,scope_values_json TEXT,updated_by TEXT,updated_at TEXT);
            INSERT INTO admins VALUES(1,'DEAN BROWN','admin','hash','',1,'Administrator');
        ''')
        self.conn.commit()
        master_control.ensure_schema(self.conn)
        cn3ct.ensure_schema(self.conn)

    def employee(self, eid):
        return None

    def authenticate(self, username, password):
        if str(username).casefold() == 'admin' and password == 'secret':
            return self.conn.execute("SELECT * FROM admins WHERE username='admin'").fetchone()
        return None

    def log(self, *args, **kwargs):
        pass


class Cn3ctApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix='cn3ct-test-')
        master_control.set_data_dir(cls.tmp)
        cls.old_store = web_backend.SERVICE.store
        cls.old_sessions = web_backend.SERVICE.sessions
        cls.old_session_expiries = web_backend.SERVICE.session_expiries
        cls.old_login_failures = web_backend.SERVICE.login_failures
        web_backend.SERVICE.store = FakeStore()
        web_backend.SERVICE.sessions = {'admin-session': 'admin'}
        web_backend.SERVICE.session_expiries = {}
        web_backend.SERVICE.login_failures = {}
        web_backend.SERVICE._qf3_ready = True
        _saved = {k: os.environ.get(k) for k in ("BR_SERVER_PORT", "BR_TLS")}
        os.environ["BR_SERVER_PORT"] = "0"
        os.environ["BR_TLS"] = "off"
        try:
            cls.server, port = web_backend.make_server()
        finally:
            for k, v in _saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

        cls.url = f'http://127.0.0.1:{port}'
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close()
        web_backend.SERVICE.store = cls.old_store
        web_backend.SERVICE.sessions = cls.old_sessions
        web_backend.SERVICE.session_expiries = cls.old_session_expiries
        web_backend.SERVICE.login_failures = cls.old_login_failures
        master_control.set_data_dir(None)

    def request(self, path, payload=None, method=None):
        data = json.dumps(payload).encode() if payload is not None else None
        headers = {'Content-Type': 'application/json', 'Cookie': 'br_session=admin-session'}
        req = urllib.request.Request(self.url + path, data=data, headers=headers,
                                     method=method or ('POST' if data is not None else 'GET'))
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as err:
            return err.code, json.loads(err.read().decode())

    def _internal_org(self, name='N3XUS Internal'):
        status, body = self.request('/api/cn3ct/orgs', {'name': name, 'internal': True})
        self.assertEqual(status, 201, body)
        return body['organisation']

    def _network(self, org_id, cidr='YOUR_LAN_IP/24'):
        status, body = self.request('/api/cn3ct/networks',
                                    {'org_id': org_id, 'name': 'Operations', 'cidr': cidr})
        self.assertEqual(status, 201, body)
        return body['network']

    def _device(self, org_id, network_id, **extra):
        payload = {'org_id': org_id, 'network_id': network_id, 'name': 'Field tablet',
                   'platform': 'Android', 'public_key': PUBLIC_KEY, 'auto_approve': True}
        payload.update(extra)
        return self.request('/api/cn3ct/devices', payload)

    # ---------- organisations and networks ----------
    def test_internal_org_and_network_creation(self):
        org = self._internal_org('Internal Test Org')
        self.assertTrue(org['org_no'].startswith('ORG-'))
        self.assertEqual(org['internal'], 1)
        net = self._network(org['id'])
        self.assertEqual(net['cidr'], 'YOUR_LAN_IP/24')
        self.assertEqual(net['policy']['default_action'], 'Deny')
        self.assertGreaterEqual(len(net['policy']['rules']), 1)

    def test_invalid_cidr_is_rejected(self):
        org = self._internal_org('Bad CIDR Org')
        status, body = self.request('/api/cn3ct/networks',
                                    {'org_id': org['id'], 'cidr': 'not-a-network'})
        self.assertEqual(status, 400)

    # ---------- devices and keys ----------
    def test_device_registration_allocates_unique_addresses(self):
        org = self._internal_org('Device Test Org')
        net = self._network(org['id'])
        status, first = self._device(org['id'], net['id'], name='Tablet A')
        self.assertEqual(status, 201, first)
        status, second = self._device(org['id'], net['id'], name='Tablet B')
        self.assertEqual(status, 201, second)
        self.assertEqual(first['device']['status'], 'Active')
        self.assertNotEqual(first['device']['address'], second['device']['address'])
        self.assertTrue(first['device']['address'].startswith('10.44.0.'))

    def test_private_keys_are_never_accepted(self):
        org = self._internal_org('Key Policy Org')
        net = self._network(org['id'])
        status, body = self.request('/api/cn3ct/devices', {
            'org_id': org['id'], 'network_id': net['id'], 'name': 'Bad device',
            'public_key': PUBLIC_KEY, 'private_key': 'do-not-send'})
        self.assertEqual(status, 403, body)
        self.assertIn('never accepts', body['error'])

    def test_invalid_public_key_is_rejected(self):
        org = self._internal_org('Bad Key Org')
        net = self._network(org['id'])
        status, body = self.request('/api/cn3ct/devices', {
            'org_id': org['id'], 'network_id': net['id'], 'name': 'Short key',
            'public_key': 'abc'})
        self.assertEqual(status, 400)

    def test_gateway_completes_device_configuration(self):
        org = self._internal_org('Gateway Test Org')
        net = self._network(org['id'])
        status, body = self._device(org['id'], net['id'])
        device_id = body['device']['id']

        status, body = self.request(f'/api/cn3ct/devices/{device_id}/config')
        self.assertEqual(status, 200)
        self.assertFalse(body['complete'])
        self.assertIn('PASTE_PRIVATE_KEY', body['text'])
        self.assertFalse(body['private_key_present'])

        status, body = self.request('/api/cn3ct/gateways', {
            'org_id': org['id'], 'network_id': net['id'], 'name': 'Office gateway',
            'public_key': GATEWAY_KEY, 'endpoint': 'vpn.example.invalid:51820'})
        self.assertEqual(status, 201, body)

        status, body = self.request(f'/api/cn3ct/devices/{device_id}/config')
        self.assertEqual(status, 200)
        self.assertTrue(body['complete'], body)
        self.assertIn('vpn.example.invalid:51820', body['text'])

    def test_device_revocation_then_reapproval_is_blocked(self):
        org = self._internal_org('Revocation Org')
        net = self._network(org['id'])
        status, body = self._device(org['id'], net['id'])
        device_id = body['device']['id']
        status, body = self.request(f'/api/cn3ct/devices/{device_id}/revoke', {'reason': 'Lost device'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['device']['status'], 'Revoked')
        status, body = self.request(f'/api/cn3ct/devices/{device_id}/approve', {})
        self.assertEqual(status, 400)

    # ---------- entitlements ----------
    def test_customer_org_requires_a_valid_entitlement(self):
        status, customer = self.request('/api/mc/customers', {'name': 'Network Customer Ltd'})
        self.assertEqual(status, 201, customer)
        cid = customer['customer']['id']
        status, sub = self.request('/api/mc/subscriptions',
                                   {'customer_id': cid, 'product': 'CN3CT', 'amount': 999})
        self.assertEqual(status, 201, sub)
        sid = sub['subscription']['id']

        status, org = self.request('/api/cn3ct/orgs',
                                   {'name': 'Customer Network', 'internal': False, 'mc_customer_id': cid})
        self.assertEqual(status, 201, org)
        org_id = org['organisation']['id']
        net = self._network(org_id)

        status, body = self._device(org_id, net['id'], name='Customer laptop')
        self.assertEqual(status, 403, body)
        self.assertIn('entitlement', body['error'].lower())

        status, ent = self.request('/api/mc/entitlements',
                                   {'customer_id': cid, 'subscription_id': sid, 'days': 30})
        self.assertEqual(status, 200, ent)
        status, body = self._device(org_id, net['id'], name='Customer laptop',
                                    entitlement_token=ent['token'])
        self.assertEqual(status, 201, body)
        self.assertEqual(body['device']['status'], 'Active')

    # ---------- diagnostics and audit ----------
    def test_diagnostics_are_honest(self):
        status, body = self.request('/api/cn3ct/diagnostics')
        self.assertEqual(status, 200)
        self.assertIn('wireguard_installed', body)
        self.assertIn('note', body)
        self.assertIn('never claims', body['note'])

    def test_overview_and_audit_log(self):
        self._internal_org('Overview Org')
        status, body = self.request('/api/cn3ct/overview')
        self.assertEqual(status, 200)
        self.assertGreaterEqual(body['organisations'], 1)
        self.assertGreaterEqual(body['networks'], 0)
        status, body = self.request('/api/cn3ct/audit')
        self.assertEqual(status, 200)
        self.assertTrue(any('Organisation created' in a['action'] for a in body['items']))

    def test_settings_update(self):
        status, body = self.request('/api/cn3ct/settings',
                                    {'public_endpoint': 'vpn.example.invalid:51820', 'dns': '9.9.9.9'})
        self.assertEqual(status, 200, body)
        status, body = self.request('/api/cn3ct/settings')
        self.assertEqual(body['public_endpoint'], 'vpn.example.invalid:51820')
        self.assertEqual(body['dns'], '9.9.9.9')


if __name__ == '__main__':
    unittest.main()
import cn3ct as _cn


class Cn3ctUpgradeUnitTests(unittest.TestCase):
    def test_parse_wg_dump(self):
        sample = "peerpubkey\tpreshared\t1.2.3.4:51820\t10.0.0.2/32\t1700000000\t1234\t5678\t25\n"
        peers = _cn.parse_wg_dump(sample)
        self.assertEqual(len(peers), 1)
        self.assertEqual(peers[0]["public_key"], "peerpubkey")
        self.assertEqual(peers[0]["rx_bytes"], 1234)
        self.assertEqual(peers[0]["tx_bytes"], 5678)

    def test_parse_wg_dump_empty(self):
        self.assertEqual(_cn.parse_wg_dump(""), [])
        self.assertEqual(_cn.parse_wg_dump("permission denied"), [])

    def test_wg_status_has_wireguard_interfaces_key(self):
        st = _cn.wg_status('nonexistent-iface-xyz')
        self.assertIn('wireguard_interfaces', st)

    def test_wg_status_permission_denied_honest(self):
        # monkeypatch subprocess by calling with a fake interface name that triggers not found is fine;
        # just ensure structure
        st = _cn.wg_status("nonexistent-iface-xyz")
        self.assertIn("permission_denied", st)
        self.assertIn("peers", st)
        self.assertFalse(st.get("peers") and False)

    def test_server_config_no_private_key(self):
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        _cn.ensure_schema(conn)
        out = _cn.build_server_config(conn)
        self.assertFalse(out["private_key_present"])
        self.assertIn("<PASTE_LOCAL_SERVER_PRIVATE_KEY_HERE>", out["text"])
        self.assertNotIn("PRIVATEKEY=", out["text"].upper().replace("<PASTE_LOCAL_SERVER_PRIVATE_KEY_HERE>", ""))

    def test_cross_org_policy_rule_isolation(self):
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        _cn.ensure_schema(conn)
        # two orgs
        o1 = _cn.create_org(conn, {"name": "Org1"}, "admin")
        o2 = _cn.create_org(conn, {"name": "Org2"}, "admin")
        n1 = _cn.create_network(conn, o1["id"], {"name": "n1", "cidr": "10.1.0.0/24"}, "admin")
        # get policy
        net = _cn.get_network(conn, n1["id"])
        pid = net["policy"]["id"]
        # add rule manually
        cur = conn.execute("INSERT INTO cn_policy_rules(policy_id,action,source,destination,protocol,ports,priority) VALUES(?,?,?,?,?,?,?)",
                           (pid, "Allow", "*", "*", "any", "", 5))
        conn.commit()
        rid = cur.lastrowid
        # org2 cannot edit/delete
        with self.assertRaises(PermissionError):
            _cn.edit_policy_rule(conn, rid, o2["id"], {"action": "Deny"}, "admin")
        with self.assertRaises(PermissionError):
            _cn.delete_policy_rule(conn, rid, o2["id"], "admin")
        # org1 can
        _cn.edit_policy_rule(conn, rid, o1["id"], {"action": "Deny"}, "admin")
        _cn.delete_policy_rule(conn, rid, o1["id"], "admin")
        self.assertIsNone(_cn._rule_policy(conn, rid))

class RouteContractTest(unittest.TestCase):
    def test_ui_calls_cn3ct_routes(self):
        from pathlib import Path
        ui = Path(__file__).resolve().parents[1] / "ui" / "app.js"
        text = ui.read_text(encoding="utf-8")
        for route in ["/api/cn3ct/wg-status", "/api/cn3ct/server-config",
                      "/api/cn3ct/policy-rules/"]:
            self.assertIn(route.rstrip("/"), text)
        for btn in ["cnPolicyRuleEdit", "cnPolicyRuleToggle", "cnPolicyRuleDelete"]:
            self.assertIn(btn, text)
        wb = (Path(__file__).resolve().parents[1] / "web_backend.py").read_text(encoding="utf-8")
        for route in ["/api/cn3ct/policy-rules/", "/api/cn3ct/wg-status", "/api/cn3ct/server-config"]:
            self.assertIn(route.rstrip("/"), wb)
class ServerConfigBugTests(unittest.TestCase):
    def test_server_config_excludes_self_peer(self):
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        cn3ct.ensure_schema(conn)
        # server node YOUR_SERVER_IP
        org = cn3ct.create_org(conn, {"name": "S"}, "admin")
        net = cn3ct.create_network(conn, org["id"], {"name": "n", "cidr": "YOUR_LAN_IP/24"}, "admin")
        cur = conn.execute("INSERT INTO cn_devices(org_id,device_no,name,platform,owner,public_key,address,status,created_at,approved_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                           (org["id"], "DEV-S", "server", "Gateway", "admin", "RDCfAl1ejmxfeTHRa6dmbHIxhb3S3ym4YTL7fEfVzmc=", "YOUR_SERVER_IP", "Active", "x", "x"))
        conn.commit()
        # client peer YOUR_LAN_IP
        cur2 = conn.execute("INSERT INTO cn_devices(org_id,device_no,name,platform,owner,public_key,address,status,created_at,approved_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (org["id"], "DEV-C", "client", "Windows", "admin", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=", "YOUR_LAN_IP", "Active", "x", "x"))
        conn.commit()
        out = cn3ct.build_server_config(conn)
        self.assertNotIn("YOUR_SERVER_IP/32", out["text"])
        self.assertIn("YOUR_LAN_IP/32", out["text"])

    def test_ui_uses_cnCopyServerConfig_and_pre(self):
        from pathlib import Path
        ui = Path(__file__).resolve().parents[1] / "ui" / "app.js"
        text = ui.read_text(encoding="utf-8")
        self.assertIn("cnCopyServerConfig", text)
        self.assertIn('id="cn3ct-server-config-pre"', text)
        self.assertIn("${esc(scfg.text || '')}", text)
        self.assertNotIn("<script>try{document.getElementById('cn3ct-server-config-pre')", text)
        self.assertNotIn('onclick="navigator.clipboard.writeText(', text)
        self.assertNotIn("cnPolicyRuleEdit(0)", text)
        self.assertNotIn("cnPolicyRuleToggle(0)", text)
        self.assertNotIn("cnPolicyRuleDelete(0)", text)
        self.assertIn("policy_rules", text)
