"""End-to-end tests for BEYOND MASTER CONTROL.

Covers customers, subscriptions, invoices, manual bank-transfer reconciliation,
signed entitlements, owner-only suspension/restoration and overdue alerting.
"""
import json, os, sqlite3, sys, tempfile, threading, unittest, urllib.error, urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import web_backend
import master_control


class FakeStore:
    def __init__(self):
        self.conn = sqlite3.connect(':memory:', check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript('''
            CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT);
            CREATE TABLE admin_permission_overrides(admin_id INTEGER PRIMARY KEY,grants_json TEXT,scope_type TEXT,scope_values_json TEXT,updated_by TEXT,updated_at TEXT);
            INSERT INTO admins VALUES(1,'DEAN BROWN','admin','hash','',1,'Administrator');
            INSERT INTO admins VALUES(2,'Other Administrator','other','hash','',1,'Administrator');
        ''')
        self.conn.commit()
        master_control.ensure_schema(self.conn)

    def employee(self, eid):
        return None

    def authenticate(self, username, password):
        expected = {'admin': 'secret', 'other': 'secret2'}
        if expected.get(str(username).casefold()) == password:
            return self.conn.execute("SELECT * FROM admins WHERE username=? COLLATE NOCASE",
                                     (username,)).fetchone()
        return None

    def log(self, *args, **kwargs):
        pass


class MasterControlApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix='mc-test-')
        master_control.set_data_dir(cls.tmp)
        cls.old_store = web_backend.SERVICE.store
        cls.old_sessions = web_backend.SERVICE.sessions
        cls.old_session_expiries = web_backend.SERVICE.session_expiries
        cls.old_login_failures = web_backend.SERVICE.login_failures
        web_backend.SERVICE.store = FakeStore()
        web_backend.SERVICE.sessions = {'admin-session': 'admin', 'other-session': 'other'}
        web_backend.SERVICE.session_expiries = {}
        web_backend.SERVICE.login_failures = {}
        web_backend.SERVICE._qf3_ready = True
        _saved = {k: os.environ.get(k) for k in ("BR_SERVER_PORT", "BR_TLS")}
        os.environ["BR_SERVER_PORT"] = "0"
        os.environ["BR_TLS"] = "off"
        try:
            cls.server, port = web_backend.make_server()
        finally:
            for k, v in _saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

        cls.url = f'http://127.0.0.1:{port}'
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close()
        web_backend.SERVICE.store = cls.old_store
        web_backend.SERVICE.sessions = cls.old_sessions
        web_backend.SERVICE.session_expiries = cls.old_session_expiries
        web_backend.SERVICE.login_failures = cls.old_login_failures
        master_control.set_data_dir(None)

    def request(self, path, payload=None, method=None, cookie='br_session=admin-session'):
        data = json.dumps(payload).encode() if payload is not None else None
        headers = {'Content-Type': 'application/json', 'Cookie': cookie}
        req = urllib.request.Request(self.url + path, data=data, headers=headers,
                                     method=method or ('POST' if data is not None else 'GET'))
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as err:
            try:
                return err.code, json.loads(err.read().decode())
            except Exception:
                return err.code, {}

    def _customer(self, name='Acme Care'):
        status, body = self.request('/api/mc/customers', {'name': name, 'email': 'billing@acme.invalid'})
        self.assertEqual(status, 201, body)
        return body['customer']

    def _subscription(self, customer_id, product='N3XUS', amount=499):
        status, body = self.request('/api/mc/subscriptions', {
            'customer_id': customer_id, 'product': product, 'amount': amount,
            'billing_period': 'Monthly'})
        self.assertEqual(status, 201, body)
        return body['subscription']

    def _invoice(self, customer_id, subscription_id, **extra):
        payload = {'customer_id': customer_id, 'subscription_id': subscription_id, 'tax_rate': 15}
        payload.update(extra)
        status, body = self.request('/api/mc/invoices', payload)
        self.assertEqual(status, 201, body)
        return body['invoice']

    # ---------- customers and subscriptions ----------
    def test_customer_and_subscription_lifecycle(self):
        customer = self._customer('Lifecycle Ltd')
        self.assertTrue(customer['customer_no'].startswith('CUS-'))
        sub = self._subscription(customer['id'])
        self.assertEqual(sub['product'], 'N3XUS')
        self.assertTrue(sub['modules'])
        detail = self.request(f"/api/mc/customers/{customer['id']}")[1]
        self.assertEqual(len(detail['subscriptions']), 1)

    def test_invalid_product_is_rejected(self):
        customer = self._customer('Invalid Product Ltd')
        status, body = self.request('/api/mc/subscriptions',
                                    {'customer_id': customer['id'], 'product': 'UNKNOWN'})
        self.assertEqual(status, 400)

    # ---------- invoices and payments ----------
    def test_manual_payment_reconciliation_marks_invoice_paid(self):
        customer = self._customer('Paying Ltd')
        sub = self._subscription(customer['id'])
        inv = self._invoice(customer['id'], sub['id'])
        self.assertEqual(inv['status'], 'Awaiting payment')
        self.assertAlmostEqual(inv['total'], round(499 * 1.15, 2), places=2)

        status, body = self.request(f"/api/mc/invoices/{inv['id']}/payment",
                                    {'amount': inv['total'], 'customer_reported': True,
                                     'reference': 'EFT-123'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['invoice']['status'], 'Payment reported')
        payment_id = body['invoice']['payments'][0]['id']

        status, body = self.request(f"/api/mc/payments/{payment_id}/verify", {'approve': True})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['invoice']['status'], 'Paid')
        self.assertAlmostEqual(float(body['invoice']['balance']), 0.0, places=2)

    def test_overdue_scan_raises_owner_alert_without_auto_suspending(self):
        customer = self._customer('Overdue Ltd')
        sub = self._subscription(customer['id'])
        inv = self._invoice(customer['id'], sub['id'], due_date='2020-01-01')
        status, body = self.request('/api/mc/scan', {})
        self.assertEqual(status, 200, body)
        self.assertGreaterEqual(body['alerts_created'], 1)
        detail = self.request(f"/api/mc/customers/{customer['id']}")[1]
        self.assertEqual(detail['status'], 'Active')
        status, alerts = self.request('/api/mc/alerts')
        self.assertTrue(any(a['invoice_id'] == inv['id'] for a in alerts['items']))

    # ---------- entitlements ----------
    def test_signed_entitlement_round_trip(self):
        customer = self._customer('Entitled Ltd')
        sub = self._subscription(customer['id'], product='CN3CT')
        status, body = self.request('/api/mc/entitlements',
                                    {'customer_id': customer['id'], 'subscription_id': sub['id'],
                                     'days': 30})
        self.assertEqual(status, 200, body)
        self.assertIn('.', body['token'])
        status, check = self.request('/api/mc/entitlements/validate', {'token': body['token']})
        self.assertEqual(status, 200)
        self.assertTrue(check['valid'], check)
        self.assertEqual(check['payload']['product'], 'CN3CT')

    def test_tampered_entitlement_is_rejected(self):
        status, body = self.request('/api/mc/entitlements/validate',
                                    {'token': 'not.a.valid.token'})
        self.assertEqual(status, 200)
        self.assertFalse(body['valid'])

    # ---------- owner authority ----------
    def test_only_owner_can_suspend_or_restore(self):
        customer = self._customer('Owner Gate Ltd')
        sub = self._subscription(customer['id'])

        status, body = self.request(f"/api/mc/customers/{customer['id']}/suspend",
                                    {'reason': 'Non payment', 'owner_password': 'secret2'},
                                    cookie='br_session=other-session')
        self.assertEqual(status, 403, body)
        self.assertIn('Platform Owner', body['error'])

        # The owner still needs to re-authenticate with their own password.
        status, body = self.request(f"/api/mc/customers/{customer['id']}/suspend",
                                    {'reason': 'Non payment', 'owner_password': 'wrong'})
        self.assertEqual(status, 403, body)

        status, body = self.request(f"/api/mc/customers/{customer['id']}/suspend",
                                    {'reason': 'Non payment', 'owner_password': 'secret'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['customer']['status'], 'Suspended')
        self.assertEqual(body['affected_subscriptions'], [sub['id']])

        status, body = self.request(f"/api/mc/customers/{customer['id']}/restore",
                                    {'reason': 'Payment received', 'owner_password': 'secret'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['customer']['status'], 'Active')
        self.assertTrue(body['entitlements'])
        self.assertTrue(body['entitlements'][0]['token'])

    def test_owner_profile_reports_authority(self):
        status, body = self.request('/api/mc/owner')
        self.assertEqual(status, 200)
        self.assertTrue(body['is_owner'])
        self.assertEqual(body['owner_username'], 'admin')
        self.assertEqual(body['suspension_authority'], 'Platform Owner only')

    # ---------- dashboard ----------
    def test_owner_centre_and_report(self):
        status, body = self.request('/api/mc/overview')
        self.assertEqual(status, 200)
        self.assertIn('mrr', body)
        self.assertIn('products', body)
        self.assertTrue(body['public_key'])
        status, report = self.request('/api/mc/report')
        self.assertEqual(status, 200)
        self.assertIn('invoices_by_status', report)

    def test_non_administrator_cannot_reach_master_control(self):
        # The route requires an Administrator; an unknown session is unauthenticated.
        status, body = self.request('/api/mc/overview', cookie='br_session=missing')
        self.assertIn(status, (401, 403))


if __name__ == '__main__':
    unittest.main()

class MasterControlPart1Tests(MasterControlApiTest):
    def test_currency_migration_default_zar(self):
        import sqlite3, master_control
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        # minimal mc tables
        master_control.ensure_schema(conn)
        cols = [r[1] for r in conn.execute("PRAGMA table_info(mc_customers)").fetchall()]
        self.assertIn("currency", cols)
        cust = master_control.create_customer(conn, {"name": "x"}, "admin")
        cid = cust["id"]
        row = conn.execute("SELECT currency FROM mc_customers WHERE id=?", (cid,)).fetchone()
        self.assertEqual(row["currency"], "ZAR")
        inv = master_control.create_invoice(conn, {"customer_id": cid, "subtotal": 100, "tax_rate": 15}, "admin")
        self.assertAlmostEqual(inv["tax"], 15.0)
        self.assertAlmostEqual(inv["total"], 115.0)

    def test_set_exchange_rate_owner_and_convert(self):
        import sqlite3, master_control
        import os
        os.environ["NEXUS_OWNER_USERNAME"] = "admin"
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript("CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT); INSERT INTO admins VALUES(1,'DEAN BROWN','admin','hash','',1,'Administrator');")
        conn.commit()
        master_control.ensure_schema(conn)
        r = master_control.set_exchange_rate(conn, "USD", "ZAR", 18.5, "admin")
        self.assertEqual(r["rate"], 18.5)
        # non-owner denied at route level (unit: is_owner False)
        self.assertFalse(master_control.is_owner(conn, "other"))
        # convert
        self.assertEqual(master_control.convert_amount(conn, 10, "USD", "ZAR"), 185.0)
        with self.assertRaises(ValueError):
            master_control.convert_amount(conn, 10, "XXX", "ZAR")

    def test_statement_pdf(self):
        import sqlite3, master_control
        import os
        os.environ["NEXUS_OWNER_USERNAME"] = "admin"
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript("CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT); INSERT INTO admins VALUES(1,'DEAN BROWN','admin','hash','',1,'Administrator');")
        conn.commit()
        master_control.ensure_schema(conn)
        cust = master_control.create_customer(conn, {"name": "Acme", "currency": "ZAR"}, "admin")
        cid = cust["id"]
        master_control.create_invoice(conn, {"customer_id": cid, "subtotal": 100, "tax_rate": 15, "due_date": "2020-01-01"}, "admin")
        stmt = master_control.build_customer_statement(conn, cid)
        self.assertEqual(stmt["currency"], "ZAR")
        self.assertGreaterEqual(stmt["closing_balance"], 0)
        self.assertIn("current", stmt["aging"])
        pdf = master_control.render_customer_statement_pdf(conn, cid)
        self.assertTrue(pdf.startswith(b"%PDF-"))

    def test_http_routes(self):
        # currencies list
        status, body = self.request("/api/mc/currencies")
        self.assertEqual(status, 200)
        self.assertIn("items", body)
        # rate update as non-owner (other) -> 403
        status, body = self.request("/api/mc/currencies/rate", {"base_currency":"EUR","quote_currency":"ZAR","rate":21.0}, method="POST", cookie="br_session=other-session")
        self.assertEqual(status, 403)
        # rate update as admin
        status, body = self.request("/api/mc/currencies/rate", {"base_currency":"EUR","quote_currency":"ZAR","rate":21.0}, method="POST")
        self.assertEqual(status, 200)
        # statement json
        cid = self._customer()["id"] if False else None
        # create customer
        status, body = self.request("/api/mc/customers", {"name":"StmtCo"})
        self.assertEqual(status, 201)
        cid = body["customer"]["id"]
        status, body = self.request(f"/api/mc/customers/{cid}/statement")
        self.assertEqual(status, 200)
        self.assertIn("currency", body)
        # pdf
        import urllib.request
        req = urllib.request.Request(self.url + f"/api/mc/customers/{cid}/statement.pdf", headers={"Cookie":"br_session=admin-session"})
        with urllib.request.urlopen(req) as resp:
            self.assertEqual(resp.status, 200)
            self.assertEqual(resp.headers.get("Content-Type"), "application/pdf")
            data = resp.read()
            self.assertTrue(data.startswith(b"%PDF-"))
        # non-owner pdf -> 403
        req = urllib.request.Request(self.url + f"/api/mc/customers/{cid}/statement.pdf", headers={"Cookie":"br_session=other-session"})
        try:
            urllib.request.urlopen(req)
            self.fail("expected 403")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 403)

    def test_ui_contract(self):
        from pathlib import Path
        ui = Path(__file__).resolve().parents[1] / "ui" / "app.js"
        text = ui.read_text(encoding="utf-8")
        self.assertIn("/api/mc/currencies", text)
        self.assertIn("/api/mc/customers/", text)
        self.assertIn("statement.pdf", text)
