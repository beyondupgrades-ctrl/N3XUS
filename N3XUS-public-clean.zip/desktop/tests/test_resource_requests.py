"""End-to-end tests for the N3XUS employee resource request workflow.

Covers submission, management approval, procurement, asset issue, employee
acknowledgement, self-approval protection and reporting through the real API.
"""
import json, os, sqlite3, sys, threading, unittest, urllib.error, urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import web_backend
import inventory, notifications, resource_requests


class FakeStore:
    def __init__(self):
        self.conn = sqlite3.connect(':memory:', check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript('''
            CREATE TABLE admins(id INTEGER PRIMARY KEY,full_name TEXT,username TEXT,password_hash TEXT,created_at TEXT,active INTEGER,role TEXT);
            CREATE TABLE admin_permission_overrides(admin_id INTEGER PRIMARY KEY,grants_json TEXT,scope_type TEXT,scope_values_json TEXT,updated_by TEXT,updated_at TEXT);
            CREATE TABLE employees(id INTEGER PRIMARY KEY,employee_no TEXT,first_name TEXT,last_name TEXT,job_title TEXT,department TEXT,email TEXT);
            INSERT INTO admins VALUES(1,'Test Admin','admin','hash','',1,'Administrator');
            INSERT INTO admins VALUES(2,'Thandi Mokoena','employee','hash','',1,'Staff');
            INSERT INTO employees VALUES(1,'EMP-001','Thandi','Mokoena','Store Assistant','Operations','thandi@example.invalid');
        ''')
        self.conn.commit()
        for module in (inventory, notifications, resource_requests):
            module.ensure_schema(self.conn)

    def employee(self, eid):
        return self.conn.execute("SELECT * FROM employees WHERE id=?", (int(eid),)).fetchone()

    def authenticate(self, username, password):
        if str(username).casefold() == 'admin' and password == 'secret':
            return self.conn.execute("SELECT * FROM admins WHERE username='admin'").fetchone()
        return None

    def log(self, *args, **kwargs):
        pass


class ResourceRequestsApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_store = web_backend.SERVICE.store
        cls.old_sessions = web_backend.SERVICE.sessions
        cls.old_session_expiries = web_backend.SERVICE.session_expiries
        cls.old_login_failures = web_backend.SERVICE.login_failures
        web_backend.SERVICE.store = FakeStore()
        web_backend.SERVICE.sessions = {'admin-session': 'admin', 'employee-session': 'employee'}
        web_backend.SERVICE.session_expiries = {}
        web_backend.SERVICE.login_failures = {}
        _saved = {k: os.environ.get(k) for k in ("BR_SERVER_PORT", "BR_TLS")}
        os.environ["BR_SERVER_PORT"] = "0"
        os.environ["BR_TLS"] = "off"
        try:
            cls.server, port = web_backend.make_server()
        finally:
            for k, v in _saved.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

        cls.url = f'http://127.0.0.1:{port}'
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close()
        web_backend.SERVICE.store = cls.old_store
        web_backend.SERVICE.sessions = cls.old_sessions
        web_backend.SERVICE.session_expiries = cls.old_session_expiries
        web_backend.SERVICE.login_failures = cls.old_login_failures

    def request(self, path, payload=None, method=None, cookie='br_session=admin-session'):
        data = json.dumps(payload).encode() if payload is not None else None
        headers = {'Content-Type': 'application/json', 'Cookie': cookie}
        req = urllib.request.Request(self.url + path, data=data, headers=headers,
                                     method=method or ('POST' if data is not None else 'GET'))
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as err:
            return err.code, json.loads(err.read().decode())

    def _submit(self, item='Safety boots', **extra):
        payload = {'employee_id': 1, 'item': item, 'quantity': 1,
                   'estimated_cost': 1200, 'category': 'Safety footwear',
                   'reason': 'Required for site work'}
        payload.update(extra)
        # Requests are normally submitted by the employee, never by the approver.
        status, body = self.request('/api/requests', payload, cookie='br_session=employee-session')
        self.assertEqual(status, 201, body)
        return body['request']

    # ---------- submission ----------
    def test_employee_can_submit_a_request(self):
        req = self._submit()
        self.assertEqual(req['status'], 'Submitted')
        self.assertTrue(req['ref'].startswith('RR-'))
        self.assertEqual(req['employee_name'], 'Thandi Mokoena')
        self.assertGreaterEqual(len(req['events']), 2)

    def test_request_requires_an_item(self):
        status, body = self.request('/api/requests', {'employee_id': 1, 'item': ''})
        self.assertEqual(status, 400)

    def test_list_and_filter_requests(self):
        self._submit('Blue overalls')
        status, body = self.request('/api/requests?search=Blue+overalls')
        self.assertEqual(status, 200)
        self.assertTrue(any(r['item'] == 'Blue overalls' for r in body['items']))

    # ---------- approval and procurement ----------
    def test_manager_approval_creates_procurement_then_asset(self):
        req = self._submit('Angle grinder')
        status, body = self.request(f"/api/requests/{req['id']}/decision",
                                    {'decision': 'Approved', 'approved_cost': 2500})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Awaiting procurement')
        self.assertIsNotNone(body['request']['procurement'])

        status, body = self.request(f"/api/requests/{req['id']}/order",
                                    {'supplier': 'Local Tools', 'total': 2450})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Ordered')

        status, body = self.request(f"/api/requests/{req['id']}/receive",
                                    {'supplier': 'Local Tools', 'total': 2450})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Ready for collection')

        status, body = self.request(f"/api/requests/{req['id']}/asset",
                                    {'serial_no': 'AG-9001', 'condition': 'New'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Delivered')
        self.assertEqual(body['request']['asset']['serial_no'], 'AG-9001')

        aid = body['asset_id']
        status, body = self.request(f"/api/requests/assets/{aid}/acknowledge", {})
        self.assertEqual(status, 200, body)
        self.assertTrue(body['asset']['acknowledged_at'])

    def test_approval_from_existing_stock_reserves_it(self):
        item_id = inventory.save_item(web_backend.SERVICE.store.conn,
                                      'Safety gloves', 'RR-GLOVE', 'Stores', 10, 1, 'each', 50)
        req = self._submit('Safety gloves', specifications='RR-GLOVE', quantity=2)
        status, body = self.request(f"/api/requests/{req['id']}/decision", {'decision': 'Approved'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Ready for collection')
        row = web_backend.SERVICE.store.conn.execute(
            "SELECT qty_on_hand FROM inventory_items WHERE id=?", (item_id,)).fetchone()
        self.assertEqual(float(row['qty_on_hand']), 8.0)

    def test_decline_requires_a_reason(self):
        req = self._submit('Office chair')
        status, body = self.request(f"/api/requests/{req['id']}/decision", {'decision': 'Declined'})
        self.assertEqual(status, 400)
        status, body = self.request(f"/api/requests/{req['id']}/decision",
                                    {'decision': 'Declined', 'reason': 'Not budgeted this quarter'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Declined')

    def test_self_approval_is_blocked_by_default(self):
        status, body = self.request('/api/requests', {
            'employee_id': 1, 'item': 'Monitor', 'quantity': 1, 'estimated_cost': 1500})
        self.assertEqual(status, 201, body)
        req = body['request']
        # The request was created by the signed-in administrator, so the same
        # account cannot approve it without explicit self-approval authorisation.
        status, body = self.request(f"/api/requests/{req['id']}/decision", {'decision': 'Approved'})
        self.assertEqual(status, 403, body)
        self.assertIn('your own request', body['error'])

    def test_additional_information_round_trip(self):
        req = self._submit('Laptop', **{'specifications': '16GB RAM'})
        status, body = self.request(f"/api/requests/{req['id']}/decision",
                                    {'decision': 'Additional information required',
                                     'reason': 'Which department budget?'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Additional information required')
        status, body = self.request(f"/api/requests/{req['id']}/information",
                                    {'detail': 'Operations budget'})
        self.assertEqual(status, 200, body)
        self.assertEqual(body['request']['status'], 'Awaiting approval')

    # ---------- reporting and settings ----------
    def test_report_and_settings_are_available(self):
        status, body = self.request('/api/requests/report')
        self.assertEqual(status, 200)
        self.assertIn('by_status', body)
        self.assertIn('assets_issued', body)
        status, body = self.request('/api/requests/settings')
        self.assertEqual(status, 200)
        self.assertIn('Safety footwear', body['categories'])
        status, body = self.request('/api/requests/settings', {'allow_self_approval': 'no'})
        self.assertEqual(status, 200, body)

    def test_assets_list(self):
        status, body = self.request('/api/requests/assets')
        self.assertEqual(status, 200)
        self.assertIn('items', body)


if __name__ == '__main__':
    unittest.main()
