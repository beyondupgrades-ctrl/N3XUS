import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from permission_masking import PermissionMaskingEngine


class PermissionMaskingTests(unittest.TestCase):
    def test_role_capabilities(self):
        admin = PermissionMaskingEngine("Administrator")
        manager = PermissionMaskingEngine("Manager")
        staff = PermissionMaskingEngine("Staff")
        caregiver = PermissionMaskingEngine("Caregiver")
        self.assertTrue(admin.can_view_payroll())
        self.assertTrue(manager.can_view_payroll())
        self.assertFalse(staff.can_view_payroll())
        self.assertFalse(caregiver.can_view_payroll())
        self.assertTrue(admin.can_view_audit_ledger())
        self.assertFalse(manager.can_view_audit_ledger())
        self.assertTrue(admin.can_modify_system_settings())
        self.assertFalse(manager.can_modify_system_settings())

    def test_employee_masking_is_non_destructive(self):
        source = {
            "first_name": "Test", "salary_structure": "Confidential",
            "id_number": "0000000000000", "private_admin_notes": "Private",
        }
        result = PermissionMaskingEngine("Caregiver").filter_employee_record(source)
        self.assertEqual(source["id_number"], "0000000000000")
        self.assertNotIn("id_number", result)
        self.assertNotIn("salary_structure", result)
        self.assertNotIn("private_admin_notes", result)
        self.assertIn("Restricted view", result["status_note"])
        self.assertIn("id_number", PermissionMaskingEngine("Manager").filter_employee_record(source))

    def test_explicit_grants_and_employee_scope_fail_closed(self):
        limited = PermissionMaskingEngine("Manager", {"employees": ["view"]}, "employees", ["7"])
        self.assertTrue(limited.allows("employees", "view"))
        self.assertFalse(limited.allows("employees", "edit"))
        self.assertFalse(limited.can_view_payroll())
        self.assertTrue(limited.employee_in_scope(7))
        self.assertFalse(limited.employee_in_scope(8))
        self.assertTrue(PermissionMaskingEngine("Manager").can_view_payroll())


if __name__ == "__main__":
    unittest.main()
