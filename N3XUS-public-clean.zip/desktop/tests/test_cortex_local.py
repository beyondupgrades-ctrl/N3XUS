"""CORTEX single-model selection: one local model, sized to this PC's RAM.

No network is used. The Ollama endpoints are replaced with a fixed catalog so
the choice is deterministic on any machine.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cortex_local


CATALOG = [
    {"name": "qwen2.5-coder:14b", "size": 8_900_000_000, "details": {"parameter_size": "14.8B", "quantization_level": "Q4_K_M"}},
    {"name": "qwen2.5vl:7b", "size": 5_970_000_000, "details": {"parameter_size": "8.3B", "quantization_level": "Q4_K_M"}},
    {"name": "qwen2.5vl:3b", "size": 3_200_000_000, "details": {"parameter_size": "3.8B", "quantization_level": "Q4_K_M"},
     "capabilities": ["completion", "vision"]},
    {"name": "qwen2.5:1.5b", "size": 986_000_000, "details": {"parameter_size": "1.5B", "quantization_level": "Q4_K_M"}},
    # Smallest of all, and useless for chat: must never be offered as the model.
    {"name": "nomic-embed-text:latest", "size": 274_000_000, "details": {"parameter_size": "137M", "quantization_level": "F16"},
     "capabilities": ["embedding"]},
]


def fake_ram(available, total=8.0, load=60):
    return {"total_gb": total, "available_gb": available, "load_percent": load}


class CortexLocalTest(unittest.TestCase):
    def setUp(self):
        self._real_tags = cortex_local.installed_models
        self._real_ram = cortex_local.ram_profile
        self._real_ps = cortex_local.running_models
        cortex_local.installed_models = lambda host=cortex_local.DEFAULT_HOST: [
            dict(m, size_gb=round(m["size"] / (1 << 30), 2),
                 needs_gb=round(m["size"] / (1 << 30) * cortex_local.OVERHEAD_FACTOR, 2),
                 family="", capabilities=m.get("capabilities", []))
            for m in CATALOG
        ]
        cortex_local.running_models = lambda host=cortex_local.DEFAULT_HOST: []

    def tearDown(self):
        cortex_local.installed_models = self._real_tags
        cortex_local.ram_profile = self._real_ram
        cortex_local.running_models = self._real_ps

    def test_saved_model_wins_when_it_is_installed(self):
        cortex_local.ram_profile = lambda: fake_ram(6.0)
        info = cortex_local.resolve(saved_model="qwen2.5vl:7b")
        self.assertEqual(info["model"], "qwen2.5vl:7b")
        self.assertEqual(info["reason"], "Saved in Settings.")

    def test_saved_model_that_is_not_installed_falls_back(self):
        cortex_local.ram_profile = lambda: fake_ram(6.0)
        info = cortex_local.resolve(saved_model="llama3.2:99b")
        self.assertNotEqual(info["model"], "llama3.2:99b")
        self.assertIn("not installed", info["reason"])

    def test_prefers_the_smallest_general_model_that_fits(self):
        # 2.2 GB free: 1.5B needs ~1.2 GB + the 0.35 GB floor, the 3B does not.
        cortex_local.ram_profile = lambda: fake_ram(2.2)
        info = cortex_local.resolve()
        self.assertEqual(info["model"], "qwen2.5:1.5b")
        self.assertIn("Chosen automatically", info["reason"])

    def test_coding_model_is_not_preferred_over_a_general_one(self):
        cortex_local.ram_profile = lambda: fake_ram(12.0)
        info = cortex_local.resolve()
        self.assertNotIn("-coder", info["model"])
        self.assertEqual(info["model"], "qwen2.5:1.5b")

    def test_never_selects_a_model_that_cannot_fit_and_says_why(self):
        # The 14B needs ~10.6 GB: on a machine with 1.2 GB free nothing fits.
        cortex_local.ram_profile = lambda: fake_ram(1.2)
        info = cortex_local.resolve()
        self.assertEqual(info["model"], "")
        self.assertFalse(info["available"])
        self.assertIn("fits", info["reason"])

    def test_embedding_model_is_never_offered_as_the_chat_model(self):
        cortex_local.ram_profile = lambda: fake_ram(1.0)
        info = cortex_local.resolve()
        self.assertNotIn("embed", info["model"])
        # Nothing that can chat fits in 1 GB, and the reason names a real one.
        self.assertEqual(info["model"], "")
        self.assertNotIn("nomic", info["reason"])

    def test_no_local_service_is_a_plain_answer_not_an_error(self):
        cortex_local.installed_models = lambda host=cortex_local.DEFAULT_HOST: []
        cortex_local.ram_profile = lambda: fake_ram(4.0)
        info = cortex_local.resolve()
        self.assertFalse(info["available"])
        self.assertIn("not answering", info["reason"])

    def test_unknown_ram_still_chooses_lowest_ranked_model(self):
        cortex_local.ram_profile = lambda: None
        info = cortex_local.resolve()
        self.assertTrue(info["available"])
        self.assertEqual(info["num_ctx"], cortex_local.DEFAULT_NUM_CTX)

    def test_ram_profile_reports_numbers(self):
        profile = self._real_ram()
        if profile is None:
            self.skipTest("RAM introspection unavailable on this platform")
        self.assertGreater(profile["total_gb"], 0)
        self.assertGreaterEqual(profile["available_gb"], 0)
        self.assertTrue(0 <= profile["load_percent"] <= 100)

    def test_doctor_explains_an_unusable_machine(self):
        cortex_local.ram_profile = lambda: fake_ram(0.9)
        report = cortex_local.doctor()
        self.assertFalse(report["available"])
        self.assertTrue(report["advice"])

    def test_chat_without_a_model_refuses_instead_of_guessing(self):
        with self.assertRaises(RuntimeError):
            cortex_local.chat([{"role": "user", "content": "hi"}], "")

    def test_chat_unreachable_host_reads_like_advice(self):
        with self.assertRaises(RuntimeError) as ctx:
            cortex_local.chat([{"role": "user", "content": "hi"}], "some:1b",
                              host="http://127.0.0.1:9", timeout=1)
        self.assertIn("not reachable", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
