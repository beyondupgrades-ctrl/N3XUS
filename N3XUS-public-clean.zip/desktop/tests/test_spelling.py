from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
import sys

os.environ["LOCALAPPDATA"] = tempfile.mkdtemp(prefix="your-userd-spelling-")
os.environ["HOME"] = os.environ["LOCALAPPDATA"]
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import Beyond_Registration as app


class SpellingHelpTest(unittest.TestCase):
    def test_obvious_typo_can_be_corrected_and_selected(self):
        result = app.spelling_help("teh")
        self.assertFalse(result["correct"])
        self.assertIn("the", result["suggestions"])
        self.assertEqual(result["correction"], "the")

    def test_a_real_word_is_left_alone(self):
        result = app.spelling_help("camera")
        self.assertTrue(result["correct"])
        self.assertEqual(result["suggestions"], [])
        self.assertEqual(result["correction"], "")
