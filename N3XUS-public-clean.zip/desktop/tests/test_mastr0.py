"""M4STR0 orchestration engine tests."""
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import quoteflow as qf3
import mastr0


class Mastr0Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = sqlite3.connect(str(Path(self.tmp.name) / "m.db"))
        self.conn.row_factory = sqlite3.Row
        qf3.ensure_schema(self.conn)
        mastr0.ensure_schema(self.conn)

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def _sent_quote(self, days_ago=5):
        cid = qf3.save_client(self.conn, "t", {"name": "Followup Client"})
        q = qf3.save_quote(self.conn, "t", {
            "client_id": cid, "tax_rate": 0,
            "items": [{"description": "X", "qty": 1, "unit_price": 100}]})
        qf3.transition_quote(self.conn, "t", q["id"], "send")
        # backdate updated_at so follow-up trigger fires
        from datetime import date, timedelta
        old = (date.today() - timedelta(days=days_ago)).isoformat() + "T00:00:00"
        self.conn.execute("UPDATE qf3_quotes SET updated_at=? WHERE id=?", (old, q["id"]))
        self.conn.commit()
        return q

    def _overdue_invoice(self, days_over=10):
        q = self._sent_quote(0)
        qf3.portal_decision(self.conn, qf3.get_quote(self.conn, q["id"])["portal_token"], "accept")
        inv = qf3.create_invoice_from_quote(self.conn, "t", q["id"])
        from datetime import date, timedelta
        due = (date.today() - timedelta(days=days_over)).isoformat()
        self.conn.execute("UPDATE qf3_invoices SET due_date=? WHERE id=?", (due, inv["id"]))
        self.conn.commit()
        return qf3.get_invoice(self.conn, inv["id"])

    def test_schema_and_defaults(self):
        st = mastr0.status(self.conn)
        self.assertEqual(st["mode"], "assisted")
        self.assertFalse(st["paused"])
        self.assertEqual(len(st["agents"]), 5)
        self.assertFalse(st["provider_verified"])

    def test_full_mode_blocked_without_provider(self):
        with self.assertRaises(PermissionError):
            mastr0.set_mode(self.conn, "admin", "full")
        mastr0.set_mode(self.conn, "admin", "supervised")
        self.assertEqual(mastr0.mode(self.conn), "supervised")
        mastr0.emergency_stop(self.conn, "admin")
        self.assertTrue(mastr0.paused(self.conn))
        self.assertEqual(mastr0.mode(self.conn), "assisted")

    def test_cycle_proposes_followup_and_reminder(self):
        self._sent_quote(5)
        self._overdue_invoice(10)
        res = mastr0.run_cycle(self.conn)
        self.assertFalse(res["paused"])
        props = mastr0.list_proposals(self.conn, "pending")
        kinds = {p["kind"] for p in props}
        self.assertIn("quote_followup", kinds)
        self.assertIn("invoice_escalation", kinds)  # 10 days >= 7 escalate
        # duplicate prevention: second cycle adds nothing new
        res2 = mastr0.run_cycle(self.conn)
        self.assertEqual(len(mastr0.list_proposals(self.conn, "pending")), len(props))

    def test_pause_stops_cycle(self):
        self._sent_quote(5)
        mastr0.set_paused(self.conn, "admin", True)
        res = mastr0.run_cycle(self.conn)
        self.assertTrue(res["paused"])
        self.assertEqual(mastr0.list_proposals(self.conn, "pending"), [])

    def test_proposal_decision_flow(self):
        self._sent_quote(5)
        mastr0.run_cycle(self.conn)
        p = mastr0.list_proposals(self.conn, "pending")[0]
        res = mastr0.decide_proposal(self.conn, "admin", p["id"], True)
        self.assertEqual(res["status"], "acknowledged")  # assisted mode: no auto-apply
        self.assertFalse(res["applied"])
        # already decided -> error
        with self.assertRaises(PermissionError):
            mastr0.decide_proposal(self.conn, "admin", p["id"], True)
        # reject path
        self._overdue_invoice(10)
        mastr0.run_cycle(self.conn)
        p2 = [x for x in mastr0.list_proposals(self.conn, "pending")][0]
        res = mastr0.decide_proposal(self.conn, "admin", p2["id"], False, "not needed")
        self.assertEqual(res["status"], "rejected")

    def test_supervised_applies_low_risk(self):
        self._sent_quote(5)
        mastr0.set_mode(self.conn, "admin", "supervised")
        mastr0.run_cycle(self.conn)
        p = mastr0.list_proposals(self.conn, "pending")[0]
        res = mastr0.decide_proposal(self.conn, "admin", p["id"], True)
        self.assertTrue(res["applied"])
        # audit event written
        ev = self.conn.execute("SELECT * FROM qf3_events WHERE action='mstr_action'").fetchall()
        self.assertTrue(len(ev) >= 1)

    def test_broken_promise_proposal(self):
        inv = self._overdue_invoice(3)
        qf3.record_payment(self.conn, "t", {"invoice_id": inv["id"], "amount": 50,
                                            "status": "promise", "promise_date": "2020-01-01"})
        mastr0.run_cycle(self.conn)
        kinds = {p["kind"] for p in mastr0.list_proposals(self.conn, "pending")}
        self.assertIn("broken_promise", kinds)

    def test_agent_toggle_and_runs_logged(self):
        mastr0.set_agent(self.conn, "admin", "quote_follower", False)
        self._sent_quote(5)
        mastr0.run_cycle(self.conn)
        # follower disabled -> no quote_followup proposal
        kinds = {p["kind"] for p in mastr0.list_proposals(self.conn, "pending")}
        self.assertNotIn("quote_followup", kinds)
        runs = self.conn.execute("SELECT COUNT(*) FROM mstr_runs").fetchone()[0]
        self.assertGreater(runs, 0)


if __name__ == "__main__":
    unittest.main()
