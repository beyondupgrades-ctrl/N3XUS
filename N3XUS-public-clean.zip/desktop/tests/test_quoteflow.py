"""QUOT3FLOW module tests — isolated sqlite, no server required."""
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import quoteflow as qf3


class QuoteflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = sqlite3.connect(str(Path(self.tmp.name) / "qf3.db"))
        self.conn.row_factory = sqlite3.Row
        qf3.ensure_schema(self.conn)

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def _client(self, **kw):
        data = {"name": "Test Client (Pty) Ltd", "email": "billing@test.co.za",
                "vat_registered": 1, "contact_name": "Jane"}
        data.update(kw)
        return qf3.save_client(self.conn, "tester", data)

    def _quote(self, client_id=None, **kw):
        data = {"client_id": client_id or self._client(),
                "items": [{"description": "Service A", "qty": 2, "unit_price": 100.0},
                          {"description": "Service B", "qty": 1, "unit_price": 50.0}],
                "tax_rate": 15, "currency": "ZAR"}
        data.update(kw)
        return qf3.save_quote(self.conn, "tester", data)

    # ---- schema / settings ----
    def test_schema_and_settings(self):
        tables = {r[0] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        for t in ("qf3_clients", "qf3_quotes", "qf3_quote_items", "qf3_invoices",
                  "qf3_invoice_items", "qf3_payments", "qf3_events",
                  "bank_accounts", "payment_providers"):
            self.assertIn(t, tables)
        qf3.set_setting(self.conn, "company_vat_no", "4123456789")
        self.assertEqual(qf3.setting(self.conn, "company_vat_no"), "4123456789")

    # ---- clients ----
    def test_client_crud_and_validation(self):
        cid = self._client()
        self.assertTrue(any(c["id"] == cid for c in qf3.list_clients(self.conn)))
        qf3.save_client(self.conn, "tester", {"name": "Renamed", "active": True}, cid)
        self.assertEqual(qf3.list_clients(self.conn)[0]["name"], "Renamed")
        with self.assertRaises(ValueError):
            qf3.save_client(self.conn, "tester", {"name": ""})
        with self.assertRaises(KeyError):
            qf3.save_client(self.conn, "tester", {"name": "X"}, 9999)

    # ---- quotes: numbering, totals, immutability ----
    def test_quote_lifecycle_and_totals(self):
        cid = self._client()
        q = self._quote(cid)
        self.assertEqual(q["status"], "draft")
        self.assertTrue(q["quote_no"].startswith("Q"))
        # 2*100 + 1*50 = 250 subtotal, 15% VAT = 37.50, total 287.50
        self.assertAlmostEqual(q["subtotal"], 250.0)
        self.assertAlmostEqual(q["tax"], 37.50)
        self.assertAlmostEqual(q["total"], 287.50)
        # numbering is sequential per prefix
        q2 = self._quote(cid, items=[{"description": "X", "qty": 1, "unit_price": 10}])
        self.assertNotEqual(q["quote_no"], q2["quote_no"])
        # sent quote cannot be edited
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        with self.assertRaises(PermissionError):
            qf3.save_quote(self.conn, "tester", {"client_id": cid, "items": []}, q["id"])
        # only draft can be sent
        with self.assertRaises(PermissionError):
            qf3.transition_quote(self.conn, "tester", q["id"], "send")

    # ---- portal acceptance ----
    def test_portal_accept_decline(self):
        q = self._quote()
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        sent = qf3.get_quote(self.conn, q["id"])
        token = sent["portal_token"]
        self.assertTrue(token)
        doc = qf3.portal_doc(self.conn, token)
        self.assertEqual(doc["kind"], "quote")
        res, err = qf3.portal_decision(self.conn, token, "accept")
        self.assertIsNone(err)
        self.assertEqual(res["status"], "accepted")
        self.assertEqual(qf3.get_quote(self.conn, q["id"])["status"], "accepted")
        # second decision rejected — no double transitions
        _, err = qf3.portal_decision(self.conn, token, "decline")
        self.assertIsNotNone(err)
        # bad token rejected
        _, err = qf3.portal_decision(self.conn, "bogus-token-value-1234567890", "accept")
        self.assertIsNotNone(err)

    # ---- invoices ----
    def test_invoice_from_accepted_quote_only(self):
        q = self._quote()
        with self.assertRaises(PermissionError):
            qf3.create_invoice_from_quote(self.conn, "tester", q["id"])
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        token = qf3.get_quote(self.conn, q["id"])["portal_token"]
        qf3.portal_decision(self.conn, token, "accept")
        inv = qf3.create_invoice_from_quote(self.conn, "tester", q["id"])
        self.assertEqual(inv["status"], "issued")
        self.assertTrue(inv["invoice_no"].startswith("I"))
        self.assertAlmostEqual(inv["total"], 287.50)
        self.assertTrue(inv["portal_token"])
        # duplicate active invoice prevented
        with self.assertRaises(PermissionError):
            qf3.create_invoice_from_quote(self.conn, "tester", q["id"])
        # quote marked invoiced
        self.assertEqual(qf3.get_quote(self.conn, q["id"])["status"], "invoiced")

    def test_invoice_void_rules(self):
        q = self._quote()
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        qf3.portal_decision(self.conn, qf3.get_quote(self.conn, q["id"])["portal_token"], "accept")
        inv = qf3.create_invoice_from_quote(self.conn, "tester", q["id"])
        qf3.void_invoice(self.conn, "tester", inv["id"], "test void")
        self.assertEqual(qf3.get_invoice(self.conn, inv["id"])["status"], "void")
        with self.assertRaises(PermissionError):
            qf3.void_invoice(self.conn, "tester", inv["id"])

    # ---- payments ----
    def _issued_invoice(self):
        q = self._quote()
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        qf3.portal_decision(self.conn, qf3.get_quote(self.conn, q["id"])["portal_token"], "accept")
        return qf3.create_invoice_from_quote(self.conn, "tester", q["id"])

    def test_payment_lifecycle_and_duplicate_prevention(self):
        inv = self._issued_invoice()
        # pending payment does not change status
        qf3.record_payment(self.conn, "tester",
                           {"invoice_id": inv["id"], "amount": 100, "status": "pending",
                            "provider_ref": "ref-1"})
        self.assertEqual(qf3.get_invoice(self.conn, inv["id"])["status"], "issued")
        # duplicate pending with same ref rejected
        with self.assertRaises(PermissionError):
            qf3.record_payment(self.conn, "tester",
                               {"invoice_id": inv["id"], "amount": 100, "status": "pending",
                                "provider_ref": "ref-1"})
        # confirmed payment -> part_paid, then paid
        qf3.record_payment(self.conn, "tester",
                           {"invoice_id": inv["id"], "amount": 100, "status": "confirmed",
                            "method": "eft", "provider_ref": "bank-ref-9"})
        self.assertEqual(qf3.get_invoice(self.conn, inv["id"])["status"], "part_paid")
        qf3.record_payment(self.conn, "tester",
                           {"invoice_id": inv["id"], "amount": 187.50, "status": "confirmed",
                            "method": "eft", "provider_ref": "bank-ref-10"})
        full = qf3.get_invoice(self.conn, inv["id"])
        self.assertEqual(full["status"], "paid")
        self.assertAlmostEqual(full["balance"], 0.0)
        # receipts exist for confirmed payments
        receipts = qf3.list_receipts(self.conn)
        self.assertEqual(len(receipts), 2)
        self.assertTrue(all(r["receipt_no"].startswith("R") for r in receipts))

    def test_payment_guards(self):
        inv = self._issued_invoice()
        with self.assertRaises(ValueError):
            qf3.record_payment(self.conn, "tester",
                               {"invoice_id": inv["id"], "amount": -5, "status": "confirmed"})
        with self.assertRaises(ValueError):
            qf3.record_payment(self.conn, "tester",
                               {"invoice_id": inv["id"], "amount": 10, "status": "bogus"})
        with self.assertRaises(KeyError):
            qf3.record_payment(self.conn, "tester",
                               {"invoice_id": 99999, "amount": 10, "status": "confirmed"})
        # confirmed payment cannot be downgraded
        res = qf3.record_payment(self.conn, "tester",
                                 {"invoice_id": inv["id"], "amount": 50, "status": "confirmed",
                                  "provider_ref": "x1"})
        with self.assertRaises(PermissionError):
            qf3.record_payment(self.conn, "tester",
                               {"invoice_id": inv["id"], "amount": 50, "status": "pending",
                                "provider_ref": "x1"}, payment_id=res["id"])
        # invoice with confirmed payment cannot be voided
        with self.assertRaises(PermissionError):
            qf3.void_invoice(self.conn, "tester", inv["id"])

    def test_confirmed_payment_cannot_be_falsified_by_pending(self):
        """A 'promise'/pending record never counts toward paid balance."""
        inv = self._issued_invoice()
        qf3.record_payment(self.conn, "tester",
                           {"invoice_id": inv["id"], "amount": 287.50, "status": "promise",
                            "promise_date": "2030-01-01"})
        self.assertEqual(qf3.get_invoice(self.conn, inv["id"])["status"], "issued")
        self.assertAlmostEqual(qf3.get_invoice(self.conn, inv["id"])["paid"], 0.0)

    # ---- provider payments (Phase 4 entry, idempotent) ----
    def test_provider_payment_idempotent(self):
        inv = self._issued_invoice()
        pid1 = qf3.confirm_provider_payment(self.conn, "yoco", "yoco-ref-1",
                                            inv["invoice_no"], 287.50)
        pid2 = qf3.confirm_provider_payment(self.conn, "yoco", "yoco-ref-1",
                                            inv["invoice_no"], 287.50)
        self.assertEqual(pid1, pid2)  # same provider event never double-posts
        self.assertEqual(qf3.get_invoice(self.conn, inv["id"])["status"], "paid")
        with self.assertRaises(KeyError):
            qf3.confirm_provider_payment(self.conn, "yoco", "yoco-ref-2",
                                         "I-DOES-NOT-EXIST", 10)

    # ---- banking ----
    def test_bank_accounts_masked_and_default(self):
        qf3.save_bank_account(self.conn, "admin",
                              {"label": "Main", "bank_name": "FNB", "account_number": "62123456789",
                               "is_default": 1, "verified": 1})
        qf3.save_bank_account(self.conn, "admin",
                              {"label": "Yoco", "bank_name": "Yoco", "account_number": "88001234",
                               "provider_code": "yoco"})
        rows = qf3.list_bank_accounts(self.conn)
        self.assertEqual(len(rows), 2)
        self.assertTrue(rows[0]["account_number"].endswith("6789"))
        self.assertIn("*", rows[0]["account_number"])
        # unknown provider falls back to manual
        self.assertEqual(rows[1]["provider_code"], "yoco" if rows[1]["label"] == "Yoco" else "manual")
        # only one default
        self.assertEqual(sum(1 for r in rows if r["is_default"]), 1)
        # providers registered
        codes = {p["code"] for p in qf3.list_providers(self.conn)}
        self.assertIn("manual", codes)

    # ---- PDFs ----
    def test_pdf_generation(self):
        q = self._quote()
        name, data = qf3.doc_pdf(self.conn, "quote", q["id"])
        self.assertTrue(name.endswith(".pdf"))
        self.assertTrue(data.startswith(b"%PDF"))
        inv = self._issued_invoice_for_pdf()
        name, data = qf3.doc_pdf(self.conn, "invoice", inv["id"])
        self.assertTrue(data.startswith(b"%PDF"))

    def _issued_invoice_for_pdf(self):
        q = self._quote()
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        qf3.portal_decision(self.conn, qf3.get_quote(self.conn, q["id"])["portal_token"], "accept")
        inv = qf3.create_invoice_from_quote(self.conn, "tester", q["id"])
        qf3.record_payment(self.conn, "tester",
                           {"invoice_id": inv["id"], "amount": inv["total"], "status": "confirmed",
                            "provider_ref": "pdf-ref"})
        pid = self.conn.execute(
            "SELECT id FROM qf3_payments WHERE provider_ref='pdf-ref'").fetchone()[0]
        _, rdata = qf3.doc_pdf(self.conn, "receipt", pid)
        self.assertTrue(rdata.startswith(b"%PDF"))
        return inv

    # ---- events / audit ----
    def test_events_logged(self):
        q = self._quote()
        qf3.transition_quote(self.conn, "tester", q["id"], "send")
        actions = {r["action"] for r in self.conn.execute("SELECT action FROM qf3_events")}
        self.assertIn("create", actions)
        self.assertIn("send", actions)


if __name__ == "__main__":
    unittest.main()
