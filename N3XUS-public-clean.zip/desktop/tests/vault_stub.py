"""Portable stand-in for the Windows DPAPI vault, for tests on Linux/macOS CI.

communications.SecretVault keeps secrets in memory when os.name != "nt", so
every new vault object minted a NEW database key and an encrypted test
database could never be reopened - four encryption tests failed off Windows.
On Windows nothing is patched: the real DPAPI vault is tested.
"""
from __future__ import annotations

import json
import os
from pathlib import Path


class FileVault:
    def __init__(self, path):
        self.path = Path(path)

    def read_all(self):
        return json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}

    def get(self, key, default=None):
        return self.read_all().get(key, default)

    def set(self, key, value):
        data = self.read_all()
        data[key] = value
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data), encoding="utf-8")


def install():
    if os.name == "nt":
        return
    import database_encryption
    database_encryption.SecretVault = FileVault
