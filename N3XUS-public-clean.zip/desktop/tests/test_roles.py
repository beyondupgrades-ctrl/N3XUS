"""Tests for the role system: seven roles, invites, and what each role may reach.

These run against a throwaway SQLite database, so they never touch live data.
"""

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import roles  # noqa: E402


def make_conn():
    import sqlite3
    path = Path(tempfile.mkdtemp()) / "roles.db"
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    roles.ensure_schema(conn)
    return conn


class RoleCatalogueTests(unittest.TestCase):
    def test_seven_roles_are_defined(self):
        # Owner, Admin, HR, Executive, Representative, Patient, Company phone,
        # Family/Caregiver -- the brief lists seven; Family shares the care shell.
        self.assertGreaterEqual(len(roles.ROLES), 7)

    def test_every_role_has_a_home_and_tabs(self):
        for key, spec in roles.ROLES.items():
            self.assertTrue(spec["home"], key)
            self.assertTrue(spec["tabs"], key)
            self.assertTrue(spec["label"], key)

    def test_care_roles_land_on_care(self):
        for key in (roles.PATIENT, roles.COMPANY_PHONE, roles.FAMILY):
            self.assertEqual(roles.home_for(key), "care", key)

    def test_company_roles_land_on_home(self):
        for key in (roles.OWNER, roles.ADMIN, roles.HR, roles.EXECUTIVE, roles.REPRESENTATIVE):
            self.assertEqual(roles.home_for(key), "home", key)

    def test_patient_cannot_reach_payslips_or_other_patients(self):
        tabs = roles.tabs_for(roles.PATIENT)
        self.assertNotIn("payslips", tabs)
        self.assertNotIn("patients", tabs)
        self.assertNotIn("approvals", tabs)

    def test_caregiver_cannot_reach_company_finance(self):
        tabs = roles.tabs_for(roles.FAMILY)
        self.assertNotIn("payslips", tabs)
        self.assertNotIn("contracts", tabs)

    def test_owner_and_admin_can_approve(self):
        self.assertTrue(roles.can(roles.OWNER, "approve"))
        self.assertTrue(roles.can(roles.ADMIN, "approve"))

    def test_representative_requests_but_does_not_approve(self):
        self.assertTrue(roles.can(roles.REPRESENTATIVE, "request"))
        self.assertFalse(roles.can(roles.REPRESENTATIVE, "approve"))

    def test_care_roles_can_raise_sos(self):
        for key in (roles.PATIENT, roles.COMPANY_PHONE, roles.FAMILY):
            self.assertTrue(roles.can(key, "sos"), key)

    def test_legacy_staff_and_admin_still_resolve(self):
        self.assertEqual(roles.resolve("staff"), roles.REPRESENTATIVE)
        self.assertEqual(roles.resolve("admin"), roles.ADMIN)
        self.assertEqual(roles.resolve(None), roles.REPRESENTATIVE)
        self.assertEqual(roles.resolve("nonsense"), roles.REPRESENTATIVE)

    def test_explicit_role_wins_over_profile(self):
        self.assertEqual(roles.resolve("staff", "hr"), roles.HR)


class InviteTests(unittest.TestCase):
    def setUp(self):
        self.conn = make_conn()

    def test_invite_creates_one_usable_account(self):
        inv = roles.create_invite(self.conn, role="patient", created_by="owner",
                                  display_name="Test Patient", linked_patient_id=1)
        self.assertEqual(inv["role"], roles.PATIENT)
        self.assertEqual(len(inv["code"]), 8)
        made = roles.redeem_invite(self.conn, inv["code"], "p1", "hash", "")
        self.assertEqual(made["role"], roles.PATIENT)
        self.assertEqual(made["linked_patient_id"], 1)
        # Second use must fail.
        with self.assertRaises(PermissionError):
            roles.redeem_invite(self.conn, inv["code"], "p2", "hash", "")

    def test_unknown_code_is_refused(self):
        with self.assertRaises(PermissionError):
            roles.redeem_invite(self.conn, "ZZZZZZZZ", "x", "hash", "")

    def test_duplicate_login_is_refused(self):
        a = roles.create_invite(self.conn, role="family", created_by="owner")
        b = roles.create_invite(self.conn, role="family", created_by="owner")
        roles.redeem_invite(self.conn, a["code"], "same", "hash", "")
        with self.assertRaises(ValueError):
            roles.redeem_invite(self.conn, b["code"], "same", "hash", "")

    def test_pending_invites_lists_only_unused(self):
        a = roles.create_invite(self.conn, role="patient", created_by="owner")
        roles.create_invite(self.conn, role="family", created_by="owner")
        roles.redeem_invite(self.conn, a["code"], "p9", "hash", "")
        pending = roles.pending_invites(self.conn)
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["role"], roles.FAMILY)

    def test_expired_invite_is_refused(self):
        inv = roles.create_invite(self.conn, role="patient", created_by="owner", days=-1)
        with self.assertRaises(PermissionError):
            roles.redeem_invite(self.conn, inv["code"], "late", "hash", "")

    def test_account_lookup_and_suspend(self):
        inv = roles.create_invite(self.conn, role="company_phone", created_by="owner")
        roles.redeem_invite(self.conn, inv["code"], "phone1", "hash", "Care phone")
        acct = roles.account_for(self.conn, "phone1")
        self.assertIsNotNone(acct)
        self.assertEqual(acct["role"], roles.COMPANY_PHONE)
        roles.set_status(self.conn, "phone1", "Suspended")
        self.assertEqual(roles.account_for(self.conn, "phone1")["status"], "Suspended")
        with self.assertRaises(ValueError):
            roles.set_status(self.conn, "phone1", "Banana")

    def test_accounts_are_listed_with_labels(self):
        inv = roles.create_invite(self.conn, role="hr", created_by="owner")
        roles.redeem_invite(self.conn, inv["code"], "hr1", "hash", "HR Person")
        listed = roles.accounts(self.conn)
        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0]["label"], "HR")


if __name__ == "__main__":
    unittest.main()
