"""Durable safety escalation watchdog (100% free, in-house, no external service).

Runs the NAVIQ safety monitor tick in a loop so escalation timers are advanced
even if the desktop app is closed.

IMPORTANT — do not run this while the web server is running. Each process keeps
its own in-memory copy of the encrypted SQLite database and writes the whole file
back on commit, so two writers can overwrite each other's changes. The web
server already runs the same tick every 60 seconds in a background thread. This
script is only for a headless machine where the server is intentionally stopped,
and it refuses to start when the server port is reachable.

Usage:
  python safety_watchdog.py            # run in foreground
  python safety_watchdog.py --install  # register as a Windows scheduled task
  python safety_watchdog.py --remove   # remove the scheduled task
"""
from __future__ import annotations
import os, sys, time, socket, subprocess, argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def tick_once():
    import web_backend
    svc = web_backend.SERVICE
    try:
        with svc.lock:
            svc.safety_monitor_tick()
    except Exception as exc:
        print("[watchdog] tick failed:", type(exc).__name__, exc)


def server_is_running() -> bool:
    """True when the web backend is listening; it owns the safety tick already."""
    port = int(os.environ.get("BR_SERVER_PORT", "64281") or 64281)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.4)
        return probe.connect_ex(("127.0.0.1", port)) == 0


def run_loop(interval=60):
    print("[watchdog] starting, interval", interval, "s")
    while True:
        if server_is_running():
            print("[watchdog] web server detected; it owns safety ticks now. Exiting to avoid a second writer.")
            return
        tick_once()
        time.sleep(interval)


def install_task():
    python = sys.executable
    script = str(Path(__file__).resolve())
    cmd = ["schtasks", "/Create", "/TN", "NEXUS-SafetyWatchdog", "/TR",
           f'"{python}" "{script}"', "/SC", "MINUTE", "/MO", "1", "/F"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    print(r.stdout or r.stderr)
    if r.returncode == 0:
        print("Scheduled task 'NEXUS-SafetyWatchdog' created (runs every minute).")
    else:
        print("Failed to create task. Run as Administrator.")


def remove_task():
    r = subprocess.run(["schtasks", "/Delete", "/TN", "NEXUS-SafetyWatchdog", "/F"],
                       capture_output=True, text=True)
    print(r.stdout or r.stderr)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--install", action="store_true")
    ap.add_argument("--remove", action="store_true")
    ap.add_argument("--interval", type=int, default=60)
    args = ap.parse_args()
    if args.install:
        install_task()
    elif args.remove:
        remove_task()
    else:
        if server_is_running():
            print("[watchdog] The web server is running and already advances safety timers.")
            print("[watchdog] Refusing to start a second database writer. Stop the server first if you really need this.")
            raise SystemExit(0)
        run_loop(args.interval)