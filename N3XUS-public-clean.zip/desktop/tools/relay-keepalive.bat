@echo off
REM ---------------------------------------------------------------------------
REM Keep the two N3XUS relays alive. Free, local, no account, no key.
REM
REM Runs every few minutes from Task Scheduler and does nothing at all when
REM both relays are already up. When one is missing it starts that one only, so
REM a relay that died at 3am is back before the morning without a reboot and
REM without touching the app or its database.
REM
REM   TURN relay  udp/3478                     (started by turn-up.bat)
REM   media relay tcp/8554, tcp/8189, tcp/8889  (started by media-up.bat)
REM
REM Everything it writes goes to relays.log next to this file.
REM ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"
set "LOGFILE=%~dp0relays.log"

REM --- is the TURN relay listening? ----------------------------------------
netstat -ano | findstr /c:":3478" >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] TURN relay not listening - starting it>>"%LOGFILE%"
    call "%~dp0turn-up.bat"
) else (
    echo [%DATE% %TIME%] TURN relay up>>"%LOGFILE%"
)

REM --- is the media relay listening? ---------------------------------------
netstat -ano | findstr /c:":8554" >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] media relay not listening - starting it>>"%LOGFILE%"
    call "%~dp0media-up.bat"
) else (
    echo [%DATE% %TIME%] media relay up>>"%LOGFILE%"
)

REM Keep the log from growing without limit: start a fresh one once it passes
REM about half a megabyte. The old file is kept as relays.log.old.
for %%F in ("%LOGFILE%") do if %%~zF GTR 524288 move /y "%LOGFILE%" "%~dp0relays.log.old" >nul 2>&1
exit /b 0
