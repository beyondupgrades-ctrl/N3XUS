@echo off
REM Wait until the N3XUS server is listening, then open the console in the browser.
REM Called by start-n3xus.bat so that clicking the icon shows something on screen.
setlocal
set "PORT=64281"
set /a tries=0

:wait
set /a tries+=1
netstat -ano | findstr /r /c:"TCP.*:%PORT% .*LISTENING" >nul 2>&1
if not errorlevel 1 goto ready
if %tries% GEQ 60 goto giveup
ping -n 2 127.0.0.1 >nul 2>&1
goto wait

:ready
start "" "https://127.0.0.1:64281/"
exit /b 0

:giveup
echo N3XUS did not start listening on port %PORT%.
echo Leave the other window open and read the last line it printed.
ping -n 6 127.0.0.1 >nul 2>&1
exit /b 1
