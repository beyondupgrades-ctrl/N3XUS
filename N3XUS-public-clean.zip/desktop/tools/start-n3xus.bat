@echo off
REM Start everything N3XUS needs, in the right order. Free, local, no account.
REM Safe to click more than once: it stops any copy already running first, so a second
REM click never leaves two servers fighting over the same port.

setlocal enabledelayedexpansion
set "TOOLS=%~dp0"
set "PORT=64281"
set "ENVFILE=%~dp0..\.env"

REM --- 1. stop anything already running -------------------------------------
REM Without this, every click started another server, the port was taken, and the
REM window closed instantly - which looks exactly like "the app does not open".
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /r /c:"TCP.*:%PORT% .*LISTENING"') do (
    taskkill /F /PID %%P >nul 2>&1
)
taskkill /F /IM turnserver.exe >nul 2>&1
taskkill /F /IM cloudflared.exe >nul 2>&1
taskkill /F /IM mediamtx.exe >nul 2>&1
REM ping is used instead of timeout: timeout is a cmd builtin that some
REM shells and PATH entries shadow, and it then fails with 'invalid number'.
ping -n 3 127.0.0.1 >nul 2>&1

REM --- 2. the TURN relay ----------------------------------------------------
REM turn-up.bat writes the public address it used to turn.lastip, so the server
REM below hands out exactly the address the relay is advertising.
call "%TOOLS%turn-up.bat"
set "PUBIP="
if exist "%TOOLS%turn.lastip" for /f "usebackq delims=" %%A in ("%TOOLS%turn.lastip") do set "PUBIP=%%A"
if "%PUBIP%"=="" set "PUBIP=YOUR_PUBLIC_IP"

REM --- 3. the media relay (cameras) ----------------------------------------
REM Its configuration comes from camera_service, so its ports are never written
REM down twice. Loopback only.
call "%TOOLS%media-up.bat"

REM --- 4. the tunnel, so phones on mobile data can reach this laptop --------
start "N3XUS tunnel" /min "%TOOLS%tunnel-up.bat"

REM --- 5. the app itself ----------------------------------------------------
cd /d "%TOOLS%.."
REM These are the names web_backend.py actually reads. The old script set
REM VOIC3_TURN_LOCAL to a single URL and the secret to a different name, which
REM is why the ICE config served STUN and no relay.
set VOIC3_TURN_URL=turn:%PUBIP%:3478?transport=udp,turn:%PUBIP%:3478?transport=tcp
set /p VOIC3_TURN_SECRET=<"%TOOLS%turn.secret"
set VOIC3_RELAY_IMPLEMENTED=1
set N3XUS_TURN_EXTERNAL_IP=%PUBIP%
REM Belt and braces: the same relay under the names the local-relay branch reads.
set VOIC3_TURN_LOCAL=turn:%PUBIP%:3478?transport=udp,turn:%PUBIP%:3478?transport=tcp
set VOIC3_TURN_LOCAL_SECRET=%VOIC3_TURN_SECRET%
set BR_SERVER_HOST=0.0.0.0
set BR_ALLOW_LAN=yes
set BR_SERVER_PORT=%PORT%

echo.
echo   N3XUS is starting. Leave this window open - it IS the server.
echo   Relay advertised at %PUBIP%:3478. Close this window to stop N3XUS.
echo.
start "N3XUS console" /min "%TOOLS%open-console.bat"

python web_backend.py

REM If python exits, keep the window open so the reason can be read.
echo.
echo   N3XUS stopped. Press any key to close.
pause >nul
