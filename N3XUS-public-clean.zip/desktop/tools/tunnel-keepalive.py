"""Keep the free cloudflared quick tunnel from going idle, and republish it if it does.

A free quick tunnel drops its QUIC connection when nothing crosses it for a while
("timeout: no recent network activity"). Every drop is a red light on a phone that
was working a second earlier. This pings the public hostname every 25 seconds -
one tiny request, free - which keeps the connection warm, and the moment the
hostname stops answering it restarts the tunnel and republishes the new name to
DuckDNS so the phone finds it again by itself.

Nothing here needs an account, a key or a paid plan.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
METRICS = "http://127.0.0.1:20241/quicktunnel"
INTERVAL = 25          # seconds between pings: well inside cloudflared's idle window
FAILS_BEFORE_RESTART = 2   # ~50 s of no working answer before the tunnel is replaced


def live_host() -> str:
    try:
        with urllib.request.urlopen(METRICS, timeout=5) as response:
            return (json.loads(response.read().decode("utf-8", "replace")).get("hostname") or "").strip()
    except Exception:
        return ""


def ping(host: str) -> bool:
    """True only when the tunnel really delivers to this PC.

    Any status used to count, so a 530 (tunnel up, origin unreachable) looked
    healthy while every phone got "Request failed". Only 200 means the request
    reached the desktop and came back.
    """
    if not host:
        return False
    try:
        request = urllib.request.Request("https://%s/api/system/ping" % host,
                                         headers={"User-Agent": "n3xus-keepalive"})
        with urllib.request.urlopen(request, timeout=12) as response:
            response.read(64)
            return response.status == 200
    except Exception:
        return False


def restart_tunnel() -> None:
    """Kill cloudflared, start it again with the origin certificate, republish."""
    print(time.strftime("%H:%M:%S"), "tunnel dead - restarting", flush=True)
    subprocess.run(["taskkill", "/IM", "cloudflared.exe", "/F"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)
    ca = TOOLS / "origin-ca.crt"
    args = ["cloudflared.exe", "tunnel", "--url", "https://127.0.0.1:64281", "--no-autoupdate",
            "--protocol", "http2"]   # QUIC drops every few minutes on this line; http2 holds
    if ca.is_file():
        # Without this the desktop's self-signed certificate is refused and every
        # public request is a 502 - the original 4G bug.
        args += ["--origin-ca-pool", "origin-ca.crt"]
    with open(TOOLS / "tunnel.log", "wb") as out, open(TOOLS / "tunnel.err.log", "wb") as err:
        subprocess.Popen(args, cwd=str(TOOLS), stdout=out, stderr=err,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    time.sleep(15)
    subprocess.run([sys.executable, str(TOOLS / "publish-tunnel.py")],
                   cwd=str(TOOLS), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main() -> None:
    print(time.strftime("%H:%M:%S"), "keepalive started: ping every %ds" % INTERVAL, flush=True)
    misses = 0
    while True:
        host = live_host()
        if not host:
            misses += 1
        elif ping(host):
            misses = 0
        else:
            misses += 1
            print(time.strftime("%H:%M:%S"), "no answer from %s (%d)" % (host, misses), flush=True)
        if misses >= FAILS_BEFORE_RESTART:
            restart_tunnel()
            misses = 0
        time.sleep(INTERVAL)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
