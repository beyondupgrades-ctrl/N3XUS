"""Repair double-encoded UTF-8 ("mojibake") in source files - one-off, local.

Text such as "UIF <a-circumflex><euro><quote> employee contribution" on a
payslip, or the same garbage in an SOS message, is UTF-8 that was once read
as Windows-1252 and saved again. This turns every such run back into the
character it was meant to be (em dash, middle dot, bullet, ellipsis, curly
quotes, accented letters, arrows and so on).

    python desktop\\tools\\fix-mojibake.py desktop\\web_backend.py desktop\\Beyond_Registration.py
    python desktop\\tools\\fix-mojibake.py --check desktop\\web_backend.py   (exit 1 if any found)

Line endings and every other byte are left exactly as they were.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

# A UTF-8 lead byte (as cp1252 text) followed by 1-3 continuation bytes (as
# cp1252 text). Built from code points so this file stays plain ASCII.
_CONT = "".join(chr(c) for c in range(0x80, 0xC0)) + "".join(chr(c) for c in (
    0x152, 0x153, 0x160, 0x161, 0x178, 0x17D, 0x17E, 0x192, 0x2C6, 0x2DC, 0x2013, 0x2014,
    0x2018, 0x2019, 0x201A, 0x201C, 0x201D, 0x201E, 0x2020, 0x2021, 0x2022, 0x2026, 0x2030,
    0x2039, 0x203A, 0x20AC, 0x2122))
_RUN = re.compile("[" + chr(0xC2) + "-" + chr(0xF4) + "][" + re.escape(_CONT) + "]{1,3}")


def _repair(match: re.Match) -> str:
    text = match.group(0)
    for cut in range(len(text), 1, -1):                 # longest valid prefix wins
        head, tail = text[:cut], text[cut:]
        try:
            raw = head.encode("cp1252", errors="strict")
        except UnicodeEncodeError:
            # cp1252 has no byte for U+0081/8D/8F/90/9D; Python keeps them as-is.
            try:
                raw = bytes(ord(c) if ord(c) < 256 else c.encode("cp1252")[0] for c in head)
            except Exception:
                continue
        try:
            fixed = raw.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            continue
        if len(fixed) == 1 and ord(fixed) > 0x7F:
            return fixed + tail
    return text


def repair_text(text: str) -> tuple[str, int]:
    count = 0

    def sub(m):
        nonlocal count
        out = _repair(m)
        if out != m.group(0):
            count += 1
        return out

    return _RUN.sub(sub, text), count


def main(argv) -> int:
    check = "--check" in argv
    files = [a for a in argv if a != "--check"]
    if not files:
        print(__doc__)
        return 2
    total = 0
    for name in files:
        path = Path(name)
        raw = path.read_bytes()
        text = raw.decode("utf-8")
        fixed, count = repair_text(text)
        total += count
        print(f"{path}: {count} mojibake run(s){' (not written: --check)' if check and count else ''}")
        if count and not check:
            path.write_bytes(fixed.encode("utf-8"))      # \r\n inside text is untouched
    return 1 if (check and total) else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
