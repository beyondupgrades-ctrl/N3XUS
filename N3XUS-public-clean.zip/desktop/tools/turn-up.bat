@echo off
REM ---------------------------------------------------------------------------
REM Start the N3XUS TURN relay. Free, local, no account, no key.
REM
REM turnserver.exe (Pion) refuses to start without BOTH a shared secret and the
REM public IPv4 address phones will reach it on, so both are checked here and a
REM clear reason is written to turn.log instead of the window just vanishing.
REM
REM The public address is looked up fresh on every start (the ISP hands out a new
REM one now and then), falling back to the last known value, then to desktop\.env.
REM ---------------------------------------------------------------------------
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "TURNPORT=3478"
REM The router forwards exactly two things: UDP+TCP 3478, and the single UDP port
REM 49152 ("N3XUS MEDIA"). Every relay allocation is therefore pinned to 49152 by
REM the relay's own -min-port / -max-port, so no allocation can ever land on a
REM port the router does not forward. Widen the range only together with a new
REM router rule for the extra ports.
set "RELAYMIN=49152"
set "RELAYMAX=49152"
set "LOGFILE=%~dp0turn.log"
set "ENVFILE=%~dp0..\.env"

REM --- the shared secret ----------------------------------------------------
set "TS="
for /f "usebackq delims=" %%S in ("%~dp0turn.secret") do if not defined TS set "TS=%%S"
if "%TS%"=="" (
    echo [%DATE% %TIME%] turn.secret is empty - relay not started>>"%LOGFILE%"
    exit /b 1
)

REM --- the public IPv4 address ---------------------------------------------
set "PUBIP="
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "try{(Invoke-RestMethod -TimeoutSec 6 https://api.ipify.org).Trim()}catch{''}"`) do set "PUBIP=%%A"
if "%PUBIP%"=="" (
    REM Nothing on the internet answered: reuse the address we used last time.
    if exist "%~dp0turn.lastip" for /f "usebackq delims=" %%A in ("%~dp0turn.lastip") do set "PUBIP=%%A"
)
if "%PUBIP%"=="" (
    REM Last resort: the address recorded in desktop\.env by hand.
    for /f "usebackq tokens=1,* delims==" %%A in ("%ENVFILE%") do (
        if /i "%%A"=="N3XUS_TURN_EXTERNAL_IP" set "PUBIP=%%B"
    )
)
if "%PUBIP%"=="" (
    echo [%DATE% %TIME%] no public IPv4 address known - relay not started>>"%LOGFILE%"
    exit /b 1
)
echo %PUBIP%>"%~dp0turn.lastip"

REM --- start it -------------------------------------------------------------
start "N3XUS TURN relay" /min "%~dp0turnserver.exe" -port %TURNPORT% -tcp-port %TURNPORT% -realm n3xus -secret "%TS%" -public-ip %PUBIP% -min-port %RELAYMIN% -max-port %RELAYMAX% >>"%LOGFILE%" 2>&1
echo [%DATE% %TIME%] relay started on udp+tcp/%TURNPORT% at %PUBIP%, relay ports %RELAYMIN%-%RELAYMAX%>>"%LOGFILE%"
exit /b 0
