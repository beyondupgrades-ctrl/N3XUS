#!/usr/bin/env python
"""Publish the live cloudflared tunnel host to DuckDNS, so the phones can always
find the server without a URL ever being typed in again.

Why this exists: cloudflared's free "quick" tunnel gets a NEW hostname every time
it restarts. The app therefore cannot have that hostname baked into it. Instead
the current hostname is written to a DNS TXT record that the app reads at launch
over DNS-over-HTTPS (see window.discoverServer in desktop/ui/mobile/mobile.js).

Free, no account your-userd the DuckDNS one, no router port forwarding.

Usage
  python publish-tunnel.py                 # one pass: publish and verify
  python publish-tunnel.py --watch         # stay running, republish on every restart
  python publish-tunnel.py --host X.trycloudflare.com
  python publish-tunnel.py --check         # read the record back and print it

Environment (or tools/.env, or desktop/.env):
  DUCKDNS_DOMAIN   e.g. your-app-name
  DUCKDNS_TOKEN    the DuckDNS account token
"""
import io
import json
import os
import re
import subprocess
import sys
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

DEFAULT_DOMAIN = "your-app-name"
DOH = "https://cloudflare-dns.com/dns-query?name={name}&type=TXT"
POLL_SECONDS = 20


def load_env():
    """Token and domain: real environment first, then the two .env files."""
    token = os.environ.get("DUCKDNS_TOKEN", "").strip()
    domain = os.environ.get("DUCKDNS_DOMAIN", "").strip()
    for path in (os.path.join(HERE, ".env"), os.path.join(ROOT, ".env")):
        if not os.path.isfile(path):
            continue
        try:
            for line in io.open(path, encoding="utf-8", errors="ignore"):
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key == "DUCKDNS_TOKEN" and not token:
                    token = value
                elif key == "DUCKDNS_DOMAIN" and not domain:
                    domain = value
        except OSError:
            pass
    return domain or DEFAULT_DOMAIN, token


def tunnel_host_from_cloudflared():
    """The hostname of the quick tunnel cloudflared is running right now.

    cloudflared reads the requested hostname from its stdout, which is not
    available to a separate process, so take it from the process's command line
    or its log. Both are best-effort: if neither works the caller falls back to
    what the server itself last reported (see host_from_server).
    """
    host = os.environ.get("N3XUS_TUNNEL_HOST", "").strip()
    if host:
        return host
    # cloudflared's metrics port names the live quick-tunnel host exactly. It is
    # asked first: a log keeps the name of a tunnel that has already exited, which
    # is how a dead hostname could be published while the live one worked.
    try:
        with urllib.request.urlopen("http://127.0.0.1:20241/quicktunnel", timeout=4) as resp:
            live = str(json.loads(resp.read().decode("utf-8", "replace")).get("hostname") or "").strip()
        if live.endswith(".trycloudflare.com"):
            return live
    except Exception:
        pass
    # The server itself knows which hostname it is being reached on.
    found_live = host_from_server()
    if found_live:
        return found_live
    # --url https://<host>/m
    for path in (os.path.join(HERE, "cloudflared.log"),
                 os.path.join(HERE, "tunnel.log")):
        if not os.path.isfile(path):
            continue
        try:
            text = io.open(path, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        found = re.findall(r"https://([a-z0-9-]+\.trycloudflare\.com)", text)
        if found:
            return found[-1]
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"name='cloudflared.exe'\" | "
             "ForEach-Object { $_.CommandLine }"],
            capture_output=True, text=True, timeout=30).stdout
        found = re.findall(r"https://([a-z0-9-]+\.trycloudflare\.com)", out or "")
        if found:
            return found[-1]
    except Exception:
        pass
    return ""


def host_from_server():
    """Ask the server which public hostname it is being reached on."""
    import ssl
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        req = urllib.request.Request("https://127.0.0.1:64281/api/mobile/app-version",
                                     headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
    except Exception:
        return ""
    for entry in data.get("urls") or []:
        host = re.sub(r"^https?://", "", str(entry)).strip("/")
        if host.endswith(".trycloudflare.com"):
            return host
    return ""


def publish(domain, token, host):
    query = urllib.parse.urlencode({"domains": domain, "token": token, "txt": host})
    url = "https://www.duckdns.org/update?" + query
    with urllib.request.urlopen(url, timeout=30) as resp:
        return resp.read().decode("utf-8", "replace").strip()


def read_back(domain):
    url = DOH.format(name=urllib.parse.quote(domain + ".duckdns.org"))
    req = urllib.request.Request(url, headers={"Accept": "application/dns-json"})
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = json.loads(resp.read().decode("utf-8", "replace"))
    for answer in data.get("Answer") or []:
        value = str(answer.get("data", "")).strip('"')
        if value.endswith(".trycloudflare.com"):
            return value
    return ""


def resolve_host(domain):
    host = tunnel_host_from_cloudflared()
    if host:
        return host, "cloudflared"
    host = host_from_server()
    if host:
        return host, "server"
    return "", ""


def once(domain, token, host=None, quiet=False):
    if not token:
        print("No DUCKDNS_TOKEN found. Put it in tools/.env as DUCKDNS_TOKEN=...")
        return 2
    if not host:
        host, where = resolve_host(domain)
        if not host:
            print("Could not find the live tunnel host (cloudflared down?).")
            return 3
        if not quiet:
            print("Live tunnel host (%s): %s" % (where, host))
    answer = publish(domain, token, host)
    if not quiet:
        print("DuckDNS said:", answer)
    if answer != "OK":
        return 4
    # The record has a 60 s TTL, so read it back until it matches.
    for attempt in range(6):
        current = read_back(domain)
        if current == host:
            if not quiet:
                print("Verified %s.duckdns.org TXT = %s" % (domain, current))
            return 0
        time.sleep(10)
    print("Published %s but the record still reads %r." % (host, current))
    return 5


def watch(domain, token):
    """Stay running: republish whenever the tunnel hostname changes."""
    last = None
    while True:
        try:
            host, where = resolve_host(domain)
            if host and host != last:
                code = once(domain, token, host)
                if code == 0:
                    last = host
                    print("Published %s (%s). Watching for a restart..." % (host, where))
            elif not host:
                print("No tunnel host right now; waiting.")
        except Exception as exc:
            print("Publish failed: %s" % exc)
        time.sleep(POLL_SECONDS)


def main(argv):
    domain, token = load_env()
    if "--check" in argv:
        print(read_back(domain) or "(no tunnel record)")
        return 0
    host = ""
    if "--host" in argv:
        host = argv[argv.index("--host") + 1]
    if "--watch" in argv:
        watch(domain, token)
        return 0
    return once(domain, token, host)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
