@echo off
:loop
python "C:\NEXUS\Beyond_Registration_5.1.3_NEXUS_INTERFACE_OWNER_TEST_ACADEMY_PREVIEW_20261107_015947\desktop\tools\publish-tunnel.py" > "C:\NEXUS\Beyond_Registration_5.1.3_NEXUS_INTERFACE_OWNER_TEST_ACADEMY_PREVIEW_20261107_015947\desktop\tools\publish.log" 2>&1
timeout /t 60 /nobreak >NUL
goto loop
