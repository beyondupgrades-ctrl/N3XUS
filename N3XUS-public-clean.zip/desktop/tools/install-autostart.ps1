# Starts N3XUS automatically when this user logs in. Free, local, reversible.
$ErrorActionPreference = "Stop"
$tools = Split-Path -Parent $MyInvocation.MyCommand.Path
$bat   = Join-Path $tools "start-n3xus.bat"
$startup = [Environment]::GetFolderPath('Startup')
$lnkPath = Join-Path $startup "N3XUS.lnk"

$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut($lnkPath)
$lnk.TargetPath       = $bat
$lnk.WorkingDirectory = (Split-Path -Parent $tools)
$lnk.IconLocation     = (Join-Path $tools "n3xus.ico")
$lnk.Description      = "N3XUS - starts the server and the relay at login"
$lnk.WindowStyle      = 7
$lnk.Save()
Write-Output ("autostart created: " + $lnkPath)
