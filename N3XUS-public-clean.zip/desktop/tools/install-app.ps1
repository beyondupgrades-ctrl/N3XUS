# Creates a single N3XUS launcher on the desktop and in the Start menu.
# Free, local, no install wizard. Safe to run again.
$ErrorActionPreference = "Stop"
$tools = Split-Path -Parent $MyInvocation.MyCommand.Path
$root  = Split-Path -Parent $tools
$bat   = Join-Path $tools "start-n3xus.bat"
$ico   = Join-Path $tools "n3xus.ico"

if (-not (Test-Path $bat)) { throw "missing $bat" }
if (-not (Test-Path $ico)) { throw "missing $ico" }

$shell = New-Object -ComObject WScript.Shell
$targets = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) "N3XUS.lnk"),
  (Join-Path ([Environment]::GetFolderPath('Programs')) "N3XUS.lnk")
)
foreach ($lnkPath in $targets) {
  $lnk = $shell.CreateShortcut($lnkPath)
  # A shortcut cannot point straight at a .bat and keep its icon, so it runs cmd.exe
  # with the batch file as its argument.
  $lnk.TargetPath       = "$env:SystemRoot\System32\cmd.exe"
  $lnk.Arguments        = '/c ""' + $bat + '""'
  $lnk.WorkingDirectory = $root
  $lnk.IconLocation     = "$ico,0"
  $lnk.Description      = "N3XUS - start the server, the relay and the tunnel"
  $lnk.WindowStyle      = 7
  $lnk.Save()
  Write-Output ("created: " + $lnkPath)
}
