"""Recovery kit for the encrypted N3XUS database - 100% local, no account.

The live database key is sealed with Windows DPAPI, so it only opens for this
Windows user on this PC. Run `export` ONCE on the server laptop (and again only
if you change the passphrase). It writes a passphrase-protected copy of the key
into the Data folder, which the nightly restic backup already includes.

    python desktop\\tools\\recovery-kit.py export
    python desktop\\tools\\recovery-kit.py check
    python desktop\\tools\\recovery-kit.py restore --kit <file.brrk> --db <your-userd_registration.db>

`restore` is for a NEW or rebuilt PC: it unwraps the key with the passphrase,
proves it opens the restored database, then seals it into this PC's DPAPI
vault and puts the database in place. Stop NEXUS before running it.
"""
from __future__ import annotations

import argparse
import getpass
import os
import shutil
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP_DIR))

import database_encryption as de  # noqa: E402

if os.name == "nt":
    DATA_HOME = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data"
else:
    DATA_HOME = Path.home() / ".your-userd_registration" / "Data"
DB_PATH = DATA_HOME / "your-userd_registration.db"
KIT_PATH = DATA_HOME / "recovery" / "database-recovery.brrk"


def _ask_new_passphrase() -> str:
    first = getpass.getpass("New recovery passphrase (min 12 chars): ")
    if getpass.getpass("Repeat it: ") != first:
        raise SystemExit("The two passphrases differ. Nothing was written.")
    return first


def cmd_export(_args) -> int:
    key_file = DATA_HOME / de.KEY_FILE
    if not key_file.is_file():
        raise SystemExit(f"No database key at {key_file}. Start NEXUS once first.")
    key = de.load_or_create_key_from_existing(key_file)
    blob = de.export_recovery_key(key, _ask_new_passphrase())
    KIT_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = KIT_PATH.with_suffix(".tmp")
    tmp.write_bytes(blob)
    os.replace(tmp, KIT_PATH)
    print(f"Recovery kit written: {KIT_PATH}")
    print(f"Key check value: {de.key_check_value(key)}  (write this next to the passphrase)")
    print("Keep the passphrase OFF this laptop. Without it the kit is useless - by design.")
    return 0


def cmd_check(_args) -> int:
    if not KIT_PATH.is_file():
        raise SystemExit(f"No recovery kit at {KIT_PATH}. Run: recovery-kit.py export")
    key = de.import_recovery_key(KIT_PATH.read_bytes(), getpass.getpass("Recovery passphrase: "))
    live = de.load_or_create_key_from_existing(DATA_HOME / de.KEY_FILE)
    if key != live:
        raise SystemExit("The kit does NOT match the live key. Run export again.")
    print(f"OK - the kit opens the live database key ({de.key_check_value(key)}).")
    return 0


def cmd_restore(args) -> int:
    kit, db = Path(args.kit), Path(args.db)
    if not kit.is_file() or not db.is_file():
        raise SystemExit("Both --kit and --db must point at existing files.")
    key = de.import_recovery_key(kit.read_bytes(), getpass.getpass("Recovery passphrase: "))
    de._rollback_journal_image(de.decrypt_payload(db.read_bytes(), key))   # proves the key opens it
    if DB_PATH.exists():
        raise SystemExit(f"{DB_PATH} already exists. Move the old Data folder aside first.")
    DATA_HOME.mkdir(parents=True, exist_ok=True)
    de.install_recovered_key(key, DATA_HOME)
    shutil.copy2(db, DB_PATH)
    print(f"Restored. Key {de.key_check_value(key)} sealed for this Windows user; database at {DB_PATH}.")
    print("Now copy EmployeePhotos and EmployeeDocuments from the backup, then start NEXUS.")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="N3XUS database recovery kit")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("export", help="write a passphrase-protected copy of the key into Data\\recovery")
    sub.add_parser("check", help="prove the kit still opens the live key")
    r = sub.add_parser("restore", help="restore onto a new or rebuilt PC")
    r.add_argument("--kit", required=True)
    r.add_argument("--db", required=True)
    args = parser.parse_args(argv)
    return {"export": cmd_export, "check": cmd_check, "restore": cmd_restore}[args.cmd](args)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except de.DatabaseUnlockError as exc:
        raise SystemExit(f"Refused: {exc}")
