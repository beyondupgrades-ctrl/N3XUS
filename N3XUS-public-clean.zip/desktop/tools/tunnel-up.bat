@echo off
REM Start the free quick tunnel and keep the DuckDNS TXT record pointed at it.
REM Nothing here needs a port forward, a paid account or a fixed hostname:
REM cloudflared's hostname changes on every restart, so it is republished to DNS
REM and the phone app reads it back over DNS-over-HTTPS at launch.
setlocal
cd /d "%~dp0"

REM Already running? Do not start a second tunnel.
tasklist /FI "IMAGENAME eq cloudflared.exe" 2>NUL | find /I "cloudflared.exe" >NUL
if not errorlevel 1 goto publish

echo Starting N3XUS tunnel...
start "N3XUS tunnel" /MIN cmd /c "cloudflared.exe tunnel --url https://127.0.0.1:64281 --no-autoupdate > tunnel.log 2>&1"

REM Give cloudflared time to print its hostname.
timeout /t 12 /nobreak >NUL

:publish
echo Publishing the live tunnel host to DuckDNS...
python "%~dp0publish-tunnel.py"
echo.
echo Watching for a tunnel restart. Leave this window open (or close it - the
echo record only needs updating when the tunnel gets a new hostname).
python "%~dp0publish-tunnel.py" --watch
endlocal
