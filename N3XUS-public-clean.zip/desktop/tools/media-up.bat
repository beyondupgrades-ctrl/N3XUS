@echo off
REM ---------------------------------------------------------------------------
REM Start the N3XUS media relay (MediaMTX). Free, local, no account, no key.
REM
REM The relay is the same one the camera screens use, started the same way: its
REM configuration comes from camera_service.render_standalone_config(), so the
REM ports are never written down twice and cannot drift apart.
REM
REM Everything it opens is bound to 127.0.0.1 - nothing on this relay is
REM reachable from the network unless the owner deliberately changes it.
REM
REM   RTSP  tcp/8554      HLS  tcp/8189      WebRTC  tcp/8889, udp/8190
REM ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"

set "MEDIAMTX=%~dp0mediamtx.exe"
set "CONFIG=%TEMP%\n3xus-mediamtx.yml"
set "LOGFILE=%~dp0mediamtx.log"

if not exist "%MEDIAMTX%" (
    echo [%DATE% %TIME%] mediamtx.exe is missing from %~dp0 - relay not started>>"%LOGFILE%"
    exit /b 1
)

REM --- write the configuration from the one place that knows it --------------
pushd "%~dp0.."
python -c "import pathlib,sys; sys.path.insert(0,'.'); import camera_service as c; p=pathlib.Path(r'%CONFIG%'); p.write_text(c.CameraService.__new__(c.CameraService).render_standalone_config(), encoding='utf-8')" >>"%LOGFILE%" 2>&1
if not exist "%CONFIG%" (
    echo [%DATE% %TIME%] could not write the relay configuration - relay not started>>"%LOGFILE%"
    popd
    exit /b 1
)

"%MEDIAMTX%" --validate-conf="%CONFIG%" >>"%LOGFILE%" 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] the relay rejected its configuration - relay not started>>"%LOGFILE%"
    popd
    exit /b 1
)
popd

start "N3XUS media relay" /min "%MEDIAMTX%" "%CONFIG%" >>"%LOGFILE%" 2>&1
echo [%DATE% %TIME%] media relay started: rtsp 8554, hls 8189, webrtc 8889/8190>>"%LOGFILE%"
exit /b 0
