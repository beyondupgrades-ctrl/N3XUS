@echo off
REM ---------------------------------------------------------------------------
REM N3XUS nightly encrypted backup - free, local, no account.
REM
REM Everything here is local: restic writes to a folder on this PC, and an
REM optional second copy goes to a USB drive you plug in. No cloud, no fee.
REM
REM Fixed in this version:
REM   * the log now gets a timestamped "start" line and a "finished" line on
REM     EVERY run, with the restic exit code - the old script wrote only its
REM     first line, so a run that failed looked like a run that never happened;
REM   * the run is written to backup-YYYY-MM.log as well, so last night's result
REM     is never buried under an ever-growing file;
REM   * the copy drive is read from desktop\.env, which is where it was
REM     documented to live but was never actually loaded from;
REM   * the restic password file and repository are checked before anything is
REM     touched, and every step's exit code is recorded.
REM ---------------------------------------------------------------------------
setlocal enabledelayedexpansion
set "TOOLS=%~dp0"
set "RESTIC_PASSWORD_FILE=%TOOLS%restic.pass"
set "RESTIC_REPOSITORY=C:\N3XUS_BACKUP\restic-repo"
if not exist "%LOCALAPPDATA%\N3XUS" mkdir "%LOCALAPPDATA%\N3XUS" >nul 2>&1
set "LOGDIR=%LOCALAPPDATA%\N3XUS"
set "LOGFILE=%LOGDIR%\backup.log"
set "DATA=%LOCALAPPDATA%\Beyond Registration\Data"

REM --- one timestamped line, in the log and in this month's file -------------
REM %DATE% is locale-shaped, so the month comes from PowerShell once per run and
REM a machine whose date format is unusual still gets a usable file name.
set "MONTH="
for /f "usebackq delims=" %%M in (`powershell -NoProfile -Command "Get-Date -Format yyyy-MM"`) do set "MONTH=%%M"
if "%MONTH%"=="" set "MONTH=current"

call :log "=== backup start ==="
call :log "  repository: %RESTIC_REPOSITORY%"
call :log "  data folder: %DATA%"

if not exist "%TOOLS%restic.exe" (
    call :log "FAILED: restic.exe is missing from %TOOLS% - backup skipped"
    call :log "=== backup finished, nothing was backed up ==="
    exit /b 1
)
if not exist "%RESTIC_PASSWORD_FILE%" (
    call :log "FAILED: restic.pass is missing - backup skipped"
    call :log "=== backup finished, nothing was backed up ==="
    exit /b 1
)
if not exist "%DATA%" (
    call :log "FAILED: the data folder %DATA% is not there - backup skipped"
    call :log "=== backup finished, nothing was backed up ==="
    exit /b 1
)

if not exist "%RESTIC_REPOSITORY%\config" (
    call :log "  creating the repository at %RESTIC_REPOSITORY%"
    "%TOOLS%restic.exe" -r "%RESTIC_REPOSITORY%" --password-file "%RESTIC_PASSWORD_FILE%" init >>"%LOGFILE%" 2>&1
    call :log "  repository init exit %errorlevel%"
)

call :log "  backing up..."
"%TOOLS%restic.exe" -r "%RESTIC_REPOSITORY%" --password-file "%RESTIC_PASSWORD_FILE%" backup "%DATA%" --tag nightly --quiet >>"%LOGFILE%" 2>&1
set "BACKUP_RC=%errorlevel%"
if "%BACKUP_RC%"=="0" call :log "  backup OK"
if not "%BACKUP_RC%"=="0" call :log "  backup FAILED, restic exit %BACKUP_RC%"

"%TOOLS%restic.exe" -r "%RESTIC_REPOSITORY%" --password-file "%RESTIC_PASSWORD_FILE%" forget --keep-daily 7 --keep-weekly 4 --keep-monthly 6 --prune --quiet >>"%LOGFILE%" 2>&1
set "FORGET_RC=%errorlevel%"
call :log "  retention done, restic exit %FORGET_RC%"

rem --- second copy on a removable/USB drive: still local, still free -------
rem Set NEXUS_BACKUP_COPY_REPO in desktop\.env, e.g. E:\N3XUS_BACKUP_COPY\restic-repo
rem Same password file. A drive that is not plugged in tonight is skipped.
set "COPY_REPO="
if exist "%TOOLS%..\.env" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%TOOLS%..\.env") do (
        if /i "%%A"=="NEXUS_BACKUP_COPY_REPO" set "COPY_REPO=%%B"
    )
)
if not defined COPY_REPO (
    call :log "  no copy drive configured - second copy skipped"
    goto done
)
for %%D in ("%COPY_REPO%") do set "COPY_DRIVE=%%~dD"
if not exist "%COPY_DRIVE%\" (
    call :log "  copy drive %COPY_DRIVE% is not plugged in - second copy skipped"
    goto done
)
if not exist "%COPY_REPO%\config" "%TOOLS%restic.exe" -r "%COPY_REPO%" --password-file "%RESTIC_PASSWORD_FILE%" init --from-repo "%RESTIC_REPOSITORY%" --from-password-file "%RESTIC_PASSWORD_FILE%" --copy-chunker-params >>"%LOGFILE%" 2>&1
"%TOOLS%restic.exe" -r "%COPY_REPO%" --password-file "%RESTIC_PASSWORD_FILE%" copy --from-repo "%RESTIC_REPOSITORY%" --from-password-file "%RESTIC_PASSWORD_FILE%" --quiet >>"%LOGFILE%" 2>&1
set "COPY_RC=%errorlevel%"
call :log "  second copy finished, restic exit %COPY_RC%"

:done
call :log "=== backup finished, backup exit %BACKUP_RC% ==="
exit /b %BACKUP_RC%

REM --- helpers ---------------------------------------------------------------
REM %DATE% and %TIME% are written without quotes and with the space between them
REM escaped, so the redirect can never swallow the rest of the line.
:log
echo [%DATE% %TIME%] %~1>>"%LOGFILE%"
echo [%DATE% %TIME%] %~1>>"%LOGDIR%\backup-%MONTH%.log"
goto :eof
