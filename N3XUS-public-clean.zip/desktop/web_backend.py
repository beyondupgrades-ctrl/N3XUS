"""Local HTTP/API bridge for the Beyond Registration modern desktop UI.
The bridge talks to the original Store class and therefore reuses the existing SQLite database.
It binds to 127.0.0.1 only and issues an in-memory session cookie to the desktop UI.
"""
from __future__ import annotations
import _thread, base64, hashlib, json, mimetypes, os, random, re, secrets, shutil, signal, socket, subprocess, threading, time, urllib.parse, urllib.request, urllib.error, webbrowser
from datetime import datetime, date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from io import BytesIO
from typing import Any

import Beyond_Registration as legacy
import cortex_local
from communications import CommunicationsService
from camera_service import CameraService
from permission_masking import PermissionMaskingEngine
from ai_agents import Coordinator
import security_suite
import quoteflow
import mastr0
import scheduler
import autonomy
import finance
import ap_ar
import tax_engine
import inventory
import projects
import crm
import notifications
import knowledge_base
import expense_claims
import document_mgmt
import incidents
import consent_register
import academy
import certificates
import evolv3_evolution
import voic3_push
import voic3_workflow
import voic3_sfu
import resource_requests
import master_control
import cn3ct

try:
    from your-userd_extensions.in_app_upgrader import InAppUpgrader
except Exception:  # pragma: no cover - fallback keeps the API importable
    InAppUpgrader = None

APP_ROOT = Path(__file__).resolve().parent
UI_ROOT = APP_ROOT / "ui"
APP_NAME = "Beyond Registration Full Business Profile Solution"
COMPANY_REG = legacy.COMPANY_REG

# Explicit column allow-lists keep the browser API from becoming an arbitrary SQL interface.
GENERIC = {
    "contracts": ("employee_contracts", ["employee_id","contract_type","title","start_date","end_date","probation_end","status","notes","file_path","file_name"]),
    "documents": ("employee_documents", ["employee_id","document_type","title","document_number","issue_date","expiry_date","status","notes","file_path","file_name"]),
    "reviews": ("performance_reviews", ["employee_id","review_date","review_period","reviewer","overall_rating","kpi_score","strengths","improvement_areas","goals","employee_comments","follow_up_date","status","file_path","file_name"]),
}
ATTENDANCE_KEYS = {"shift_start","shift_end","grace_minutes","lunch_minutes"}
SETTINGS_KEYS = {
    "shift_start","shift_end","grace_minutes","lunch_minutes","pay_shift_start","pay_shift_end",
    "pay_paid_lunch_minutes","pay_unpaid_lunch_minutes","pay_weekday_rate","pay_saturday_rate",
    "pay_sunday_rate","pay_public_holiday_rate","pay_public_holiday_dates"
}
EMPLOYEE_FIELDS = ["employee_no","first_name","last_name","preferred_name","id_number","phone","email","address","job_title","department","employment_status","start_date","emergency_name","emergency_relationship","emergency_phone","allergies","notes","photo_path","biometric_id","contact_number"]
HR_FIELDS = ["title","date_from","date_to","status","details","field_a","field_b","quantity","condition_issued","condition_returned","file_path"]


def iso_now() -> str:
    return datetime.now().replace(microsecond=0).isoformat(sep=" ")


def queued_stamp(value, max_age_hours: int = 24):
    """Turn a phone's ``queued_at`` (milliseconds since 1970) into iso_now() format.

    A check-in or SOS recorded while the server was unreachable is replayed
    later; the record must carry the moment it really happened. Returns None
    for a missing, malformed, too-old (> max_age_hours) or future (> 2 min
    clock skew) value, so the caller falls back to iso_now().
    """
    try:
        ms = float(value)
    except (TypeError, ValueError):
        return None
    when = datetime.fromtimestamp(ms / 1000.0)
    now = datetime.now()
    if when > now + timedelta(minutes=2) or when < now - timedelta(hours=max_age_hours):
        return None
    return when.replace(microsecond=0).isoformat(sep=" ")


def clean(value: Any) -> str:
    return "" if value is None else str(value).strip()


def as_dict(row):
    return dict(row) if row is not None else None


def parse_json(data: bytes) -> dict:
    if not data:
        return {}
    try:
        parsed = json.loads(data.decode("utf-8"))
    except Exception as exc:
        raise ValueError("Request body must be valid JSON.") from exc
    if not isinstance(parsed, dict):
        raise ValueError("JSON request body must be an object.")
    return parsed


SATELLITE_STATUS = {0: "Unknown", 1: "Medical", 2: "Mechanical", 3: "Threat", 4: "Lost", 5: "Other"}

def decode_sos12(raw: bytes):
    """Decode the 12-byte satellite SOS payload (big-endian).
    Layout: u16 employee_id | i32 lat*1e7 | i32 lon*1e7 | u8 status | u8 battery."""
    if len(raw) != 12:
        raise ValueError(f"Satellite payload must be exactly 12 bytes, got {len(raw)}.")
    eid = int.from_bytes(raw[0:2], "big")
    lat = int.from_bytes(raw[2:6], "big", signed=True) / 10_000_000.0
    lon = int.from_bytes(raw[6:10], "big", signed=True) / 10_000_000.0
    status = raw[10]
    battery = raw[11]
    return eid, lat, lon, status, battery

def encode_sos12(employee_id: int, lat: float, lon: float, status: int, battery: int) -> bytes:
    eid = int(employee_id) & 0xFFFF
    la = int(round(float(lat) * 10_000_000))
    lo = int(round(float(lon) * 10_000_000))
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise ValueError("Coordinates out of range.")
    if la < -2**31 or la > 2**31 - 1 or lo < -2**31 or lo > 2**31 - 1:
        raise ValueError("Coordinate out of Int32 range.")
    return eid.to_bytes(2, "big") + la.to_bytes(4, "big", signed=True) + lo.to_bytes(4, "big", signed=True) + bytes([int(status) & 0xFF, int(battery) & 0xFF])

def telegram_notify(text: str):
    """Optional out-of-band alert through a Telegram bot - OFF by default.

    This is the one place the server would hand data to a third-party cloud
    with a token, so it needs the token, the chat id AND an explicit
    BR_ALLOW_THIRD_PARTY_ALERTS=yes. The in-app VOIC3 message and the phone's
    own notification remain the primary, local alert path.

    It runs on a background thread: a slow or blocked internet must never
    hold the request - and the database lock - that is raising an SOS.
    """
    token = os.environ.get("BR_TELEGRAM_TOKEN", "").strip()
    chat = os.environ.get("BR_TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat or os.environ.get("BR_ALLOW_THIRD_PARTY_ALERTS", "").strip().lower() != "yes":
        return False
    body = urllib.parse.urlencode({"chat_id": chat, "text": str(text)[:4000]}).encode()

    def _send():
        try:
            req = urllib.request.Request(f"https://api.telegram.org/bot{token}/sendMessage", data=body)
            urllib.request.urlopen(req, timeout=10).read()
        except Exception as exc:
            print(f"[Telegram] notify failed: {exc}")

    threading.Thread(target=_send, name="telegram-alert", daemon=True).start()
    return True

class SlowLock(_thread.RLock):
    """The one data lock, but it says so when a hold runs long.

    Every request takes this lock, so one slow holder stalls every phone behind
    it. Without a trace, a stall is invisible until someone waits out the whole
    BR_LOCK_WAIT and gets a 503. Anything held longer than SLOW_LOCK_SECONDS is
    logged with the endpoint that held it, which is what a support question
    needs. RLock, so a nested acquire on the same thread still works, and the
    outermost hold is the one timed.
    """

    SLOW_LOCK_SECONDS = float(os.environ.get("BR_SLOW_LOCK", "2"))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._depth = 0
        self._started = 0.0

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc_info):
        self.release()
        return False

    def acquire(self, blocking=True, timeout=-1):
        started = time.monotonic()
        acquired = _thread.RLock.acquire(self, blocking, timeout)
        if acquired:
            waited = time.monotonic() - started
            if waited >= self.SLOW_LOCK_SECONDS:
                holder = getattr(SERVICE, "_lock_holder", None) or "another request"
                print(f"[BR lock] waited {waited:.1f}s for the data lock, held by {holder}", flush=True)
            self._depth += 1
            if self._depth == 1:
                self._started = time.monotonic()
        return acquired

    def release(self):
        self._depth = max(0, self._depth - 1)
        outermost = self._depth == 0
        started = self._started
        _thread.RLock.release(self)
        if outermost and started:
            held = time.monotonic() - started
            self._started = 0.0
            if held >= self.SLOW_LOCK_SECONDS:
                holder = getattr(SERVICE, "_lock_holder", None) or "an unlabelled section"
                print(f"[BR lock] held {held:.1f}s by {holder}", flush=True)


class AppService:
    def __init__(self):
        self.store = legacy.Store()
        self.comms = CommunicationsService(legacy.DATA_HOME)
        self.cameras = CameraService(legacy.DATA_HOME, self.store)
        self.sessions: dict[str, str] = {}
        self.mobile_sessions: dict[str, int] = {}
        self.mobile_profiles: dict[str, str] = {}
        self.lock = SlowLock()
        self.store.conn.executescript("""
        CREATE TABLE IF NOT EXISTS mobile_accounts (
            employee_id INTEGER PRIMARY KEY,
            password_hash TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS payslip_edit_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payroll_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            requested_by TEXT NOT NULL,
            field TEXT NOT NULL,
            proposed_value TEXT NOT NULL,
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pending',
            decision_by TEXT DEFAULT '',
            decision_at TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(payroll_id) REFERENCES payroll_records(id) ON DELETE CASCADE,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_vitals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            recorded_by TEXT NOT NULL,
            heart_rate INTEGER,
            blood_pressure TEXT DEFAULT '',
            temperature REAL,
            spo2 INTEGER,
            notes TEXT DEFAULT '',
            recorded_at TEXT NOT NULL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS mobile_pairing_codes (
            code TEXT PRIMARY KEY,
            device_class TEXT NOT NULL DEFAULT 'company',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            used_at TEXT DEFAULT '',
            used_by TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS mobile_devices (
            device_key TEXT PRIMARY KEY,
            device_class TEXT NOT NULL DEFAULT 'staff',
            label TEXT DEFAULT '',
            paired_by TEXT DEFAULT '',
            paired_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS device_checkins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_key TEXT NOT NULL,
            employee_id INTEGER NOT NULL,
            checked_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS voic3_calls (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller_employee_id INTEGER NOT NULL,
            callee_employee_id INTEGER NOT NULL,
            call_type TEXT NOT NULL DEFAULT 'audio',
            status TEXT NOT NULL DEFAULT 'ringing',
            created_at TEXT NOT NULL,
            answered_at TEXT DEFAULT '',
            ended_at TEXT DEFAULT '',
            ended_reason TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS voic3_signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            call_id INTEGER NOT NULL,
            sender_employee_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            payload TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(call_id) REFERENCES voic3_calls(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS voic3_presence (
            employee_id INTEGER PRIMARY KEY,
            status TEXT NOT NULL DEFAULT 'offline',
            custom_note TEXT DEFAULT '',
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS voic3_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            name TEXT DEFAULT '',
            department TEXT DEFAULT '',
            created_by INTEGER,
            is_announcement_only INTEGER NOT NULL DEFAULT 0,
            pinned_message_id INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS voic3_members (
            conversation_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            role TEXT NOT NULL DEFAULT 'member',
            last_read_message_id INTEGER DEFAULT 0,
            joined_at TEXT NOT NULL,
            PRIMARY KEY (conversation_id, employee_id)
        );
        CREATE TABLE IF NOT EXISTS voic3_receipts (
            message_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            delivered_at TEXT,
            read_at TEXT,
            PRIMARY KEY (message_id, employee_id)
        );
        CREATE TABLE IF NOT EXISTS voic3_reactions (
            message_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            emoji TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (message_id, employee_id, emoji)
        );
        CREATE TABLE IF NOT EXISTS voic3_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT DEFAULT '',
            body TEXT NOT NULL,
            created_by INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS voic3_auto_reply (
            target_id INTEGER PRIMARY KEY,
            enabled INTEGER NOT NULL DEFAULT 0,
            away_message TEXT DEFAULT '',
            work_hours_json TEXT DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS voic3_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            mime_type TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            storage_path TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS voic3_meetings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            host_employee_id INTEGER NOT NULL,
            conversation_id INTEGER,
            scheduled_for TEXT DEFAULT '',
            waiting_room_enabled INTEGER NOT NULL DEFAULT 1,
            is_locked INTEGER NOT NULL DEFAULT 0,
            spotlight_employee_id INTEGER,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS voic3_meeting_participants (
            meeting_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            state TEXT NOT NULL DEFAULT 'waiting',
            is_muted_by_host INTEGER NOT NULL DEFAULT 0,
            hand_raised INTEGER NOT NULL DEFAULT 0,
            joined_at TEXT,
            left_at TEXT,
            PRIMARY KEY (meeting_id, employee_id)
        );
        CREATE TABLE IF NOT EXISTS contract_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            file_name TEXT DEFAULT '',
            mime_type TEXT DEFAULT 'application/pdf',
            file_data BLOB,
            status TEXT NOT NULL DEFAULT 'Pending',
            decline_reason TEXT DEFAULT '',
            signature_data TEXT DEFAULT '',
            signed_name TEXT DEFAULT '',
            sent_by TEXT DEFAULT '',
            decided_at TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS mobile_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            location TEXT DEFAULT '',
            photo_path TEXT DEFAULT '',
            photo_name TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Submitted',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS admin_permission_overrides (
            admin_id INTEGER PRIMARY KEY,
            grants_json TEXT NOT NULL DEFAULT '{}',
            scope_type TEXT NOT NULL DEFAULT 'employees',
            scope_values_json TEXT NOT NULL DEFAULT '[]',
            updated_by TEXT DEFAULT '',
            updated_at TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_number TEXT DEFAULT '',
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            date_of_birth TEXT DEFAULT '',
            allergies TEXT DEFAULT '',
            mobility_limitations TEXT DEFAULT '',
            emergency_information TEXT DEFAULT '',
            primary_caregiver TEXT DEFAULT '',
            consent_status TEXT NOT NULL DEFAULT 'Pending',
            conditions_json TEXT NOT NULL DEFAULT '[]',
            medications_json TEXT NOT NULL DEFAULT '[]',
            procedures_json TEXT NOT NULL DEFAULT '[]',
            status TEXT NOT NULL DEFAULT 'Active',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS patient_contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            priority INTEGER NOT NULL DEFAULT 1,
            name TEXT NOT NULL,
            relationship TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            employee_id INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            document_type TEXT DEFAULT '',
            file_name TEXT DEFAULT '',
            mime_type TEXT DEFAULT '',
            content BLOB,
            uploaded_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_walks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'Active',
            notes TEXT DEFAULT '',
            started_by TEXT DEFAULT '',
            started_at TEXT NOT NULL,
            ended_at TEXT DEFAULT '',
            last_checkin_at TEXT DEFAULT '',
            last_latitude REAL,
            last_longitude REAL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_walk_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            walk_id INTEGER NOT NULL,
            note TEXT DEFAULT '',
            latitude REAL,
            longitude REAL,
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(walk_id) REFERENCES patient_walks(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_emergency_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Open',
            contact_stage INTEGER NOT NULL DEFAULT 1,
            person_1_in_app INTEGER NOT NULL DEFAULT 0,
            escalated_at TEXT DEFAULT '',
            acknowledged_at TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            event_id TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_access (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            principal_type TEXT NOT NULL,
            principal_id INTEGER NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            UNIQUE(patient_id, principal_type, principal_id),
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS hub_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT NOT NULL,
            recipient_label TEXT NOT NULL,
            employee_id INTEGER,
            department TEXT,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            payroll_id INTEGER,
            attachment_name TEXT,
            attachment_mime TEXT,
            attachment_data BLOB,
            created_at TEXT NOT NULL,
            read_at TEXT
        );
        CREATE TABLE IF NOT EXISTS geofences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            radius_m REAL NOT NULL DEFAULT 100,
            active INTEGER NOT NULL DEFAULT 1,
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS patient_location_pings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            walk_id INTEGER,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            accuracy_m REAL,
            battery_pct REAL,
            speed_mps REAL,
            source TEXT DEFAULT 'app',
            device_key TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_pings_patient ON patient_location_pings(patient_id,created_at);
        CREATE TABLE IF NOT EXISTS safety_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            alert_type TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'warning',
            status TEXT NOT NULL DEFAULT 'Open',
            details TEXT DEFAULT '',
            escalation_stage INTEGER NOT NULL DEFAULT 0,
            next_escalate_at TEXT DEFAULT '',
            acknowledged_by TEXT DEFAULT '',
            acknowledged_at TEXT DEFAULT '',
            resolved_at TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_safety_alerts_patient ON safety_alerts(patient_id,status);
        CREATE TABLE IF NOT EXISTS emergency_escalations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_id INTEGER NOT NULL,
            patient_id INTEGER NOT NULL,
            contact_priority INTEGER NOT NULL,
            contact_name TEXT DEFAULT '',
            channel TEXT DEFAULT 'inapp',
            status TEXT NOT NULL DEFAULT 'Sent',
            sent_at TEXT NOT NULL,
            ack_at TEXT DEFAULT '',
            FOREIGN KEY(alert_id) REFERENCES safety_alerts(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS satellite_incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            device_key TEXT DEFAULT '',
            employee_no TEXT DEFAULT '',
            employee_name TEXT DEFAULT '',
            latitude REAL,
            longitude REAL,
            status_code INTEGER,
            battery_pct REAL,
            source TEXT DEFAULT 'satellite',
            raw_hex TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Received',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS user_prefs (
            user_key TEXT PRIMARY KEY,
            prefs_json TEXT NOT NULL DEFAULT '{}',
            updated_at TEXT NOT NULL
        );
        """)
        try:
            self.store.conn.execute("ALTER TABLE mobile_accounts ADD COLUMN mobile_profile TEXT NOT NULL DEFAULT 'staff'")
        except Exception:
            pass
        try:
            # The two owner accounts (Heidelise Josling-Brown, Dean Brown) are administrators.
            self.store.conn.execute("UPDATE mobile_accounts SET mobile_profile='admin' WHERE employee_id IN (1,2)")
        except Exception:
            pass
        # --- Role system: seven account kinds, one per kind of person. ---
        # Additive only. Existing 'staff' and 'admin' profiles keep working exactly
        # as before; the new kinds are extra values in the same column.
        self.store.conn.execute("""
        CREATE TABLE IF NOT EXISTS mobile_role_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            login TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            display_name TEXT NOT NULL DEFAULT '',
            phone TEXT DEFAULT '',
            email TEXT DEFAULT '',
            linked_patient_id INTEGER,
            linked_employee_id INTEGER,
            created_by TEXT DEFAULT '',
            invite_code TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Active',
            created_at TEXT NOT NULL,
            last_login_at TEXT DEFAULT ''
        );
        """)
        self.store.conn.execute("""
        CREATE TABLE IF NOT EXISTS mobile_role_invites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            role TEXT NOT NULL,
            display_name TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            linked_patient_id INTEGER,
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            expires_at TEXT DEFAULT '',
            used_at TEXT DEFAULT '',
            used_login TEXT DEFAULT ''
        );
        """)
        for col,ddl in (("status","TEXT NOT NULL DEFAULT 'Active'"),("id_number","TEXT DEFAULT ''"),("medication_schedule","TEXT DEFAULT ''"),("special_care","TEXT DEFAULT ''"),("medical_history","TEXT DEFAULT ''"),("photo","BLOB")):
            try: self.store.conn.execute(f"ALTER TABLE patients ADD COLUMN {col} {ddl}")
            except Exception: pass
        for col,ddl in (("status","TEXT NOT NULL DEFAULT 'Active'"),("last_checkin_at","TEXT DEFAULT ''"),("last_latitude","REAL"),("last_longitude","REAL")):
            try: self.store.conn.execute(f"ALTER TABLE patient_walks ADD COLUMN {col} {ddl}")
            except Exception: pass
        try: self.store.conn.execute("ALTER TABLE patient_emergency_alerts ADD COLUMN event_id TEXT NOT NULL DEFAULT ''")
        except Exception: pass
        try: self.store.conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_pea_event ON patient_emergency_alerts(patient_id,event_id) WHERE event_id<>''")
        except Exception: pass
        self.store.conn.commit()
        # NAVIQ safety monitor: evaluates walks, pings, geofences and escalation timers.
        self._safety_stop = threading.Event()
        try:
            self._safety_thread = threading.Thread(target=self._safety_loop, daemon=True, name="naviq-safety")
            self._safety_thread.start()
        except Exception:
            pass
        self._av_stop = threading.Event()
        try:
            self._av_thread = threading.Thread(target=self._av_loop, daemon=True, name="clamav-scan")
            self._av_thread.start()
        except Exception:
            pass
        self.session_expiries: dict[str, float] = {}
        self.mobile_session_expiries: dict[str, float] = {}
        self.login_failures: dict[str, list[float]] = {}
        self.upgrader = (
            InAppUpgrader(legacy.DATA_HOME / "Upgrades", admin_validator=lambda username: self.role_for(username) == "Administrator")
            if InAppUpgrader is not None else None
        )
        self.config_path = legacy.DATA_HOME / "app_config.json"
        initial_url=os.environ.get("VISION_SERVER_URL", "").strip().rstrip("/")
        # Reject the AI Studio development/preview host previously returning a cookie-check
        # HTML document to the desktop JSON API client.
        if "ais-dev-" in initial_url.lower(): initial_url=""
        self.config = {"vision_server_url": initial_url}
        try:
            saved = json.loads(self.config_path.read_text(encoding="utf-8"))
            candidate = saved.get("vision_server_url")
            if isinstance(candidate, str) and candidate.startswith("https://") and "ais-dev-" not in candidate.lower():
                self.config["vision_server_url"] = candidate.rstrip("/")
        except (OSError, ValueError, TypeError):
            pass
        self.coordinator = Coordinator(
            self.store, self._llm_chat, self.permissions_for,
            log=self.store.log,
            executors={"hub_message": self._ai_hub_executor, "ddns_update": self._ddns_update_executor},
        )
        # Step 1 of autonomy plan: in-house scheduler for routine tasks.
        try:
            self.scheduler = scheduler.install(self)
        except Exception:
            self.scheduler = None
        try:
            finance.ensure_schema(self.store.conn)
        except Exception:
            pass
        for mod in (ap_ar, inventory, projects, crm, notifications, knowledge_base, expense_claims, document_mgmt, incidents, consent_register, academy,
                    resource_requests, master_control, cn3ct):
            try:
                mod.ensure_schema(self.store.conn)
            except Exception:
                pass
        try:
            cols = {r[1] for r in self.store.conn.execute("PRAGMA table_info(voic3_calls)").fetchall()}
            if "ended_reason" not in cols:
                self.store.conn.execute("ALTER TABLE voic3_calls ADD COLUMN ended_reason TEXT DEFAULT ''")
                self.store.conn.commit()
        except Exception:
            pass
        # Section 15: cache the local transcript beside its recording so a
        # re-open never re-runs the model.
        try:
            acols = {r[1] for r in self.store.conn.execute("PRAGMA table_info(voic3_attachments)").fetchall()}
            if "transcript_json" not in acols:
                self.store.conn.execute("ALTER TABLE voic3_attachments ADD COLUMN transcript_json TEXT")
                self.store.conn.commit()
        except Exception:
            pass
        # Section 14: workflow cards + append-only compliance audit chain.
        try:
            voic3_workflow.ensure_schema(self.store.conn)
        except Exception:
            pass
        # Idempotent ALTER for hub_messages companion columns (Section 6).
        try:
            cols = {r[1] for r in self.store.conn.execute("PRAGMA table_info(hub_messages)").fetchall()}
            for col, ddl in (("conversation_id","INTEGER"),("reply_to_id","INTEGER"),("message_type","TEXT DEFAULT 'text'"),("edited_at","TEXT"),("deleted_at","TEXT")):
                if col not in cols:
                    self.store.conn.execute("ALTER TABLE hub_messages ADD COLUMN %s %s" % (col, ddl))
            # Section 13: nullable idempotency key so an offline outbox retry can
            # never duplicate a message. Older clients omit it and are unaffected.
            if "idempotency_key" not in cols:
                self.store.conn.execute("ALTER TABLE hub_messages ADD COLUMN idempotency_key TEXT")
            if "metadata_json" not in cols:
                self.store.conn.execute("ALTER TABLE hub_messages ADD COLUMN metadata_json TEXT")
            try:
                self.store.conn.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_hub_messages_idem "
                    "ON hub_messages(idempotency_key) WHERE idempotency_key IS NOT NULL")
            except Exception:
                pass
            self.store.conn.commit()
        except Exception:
            pass
        # Auto-sync N3XUS departments into department conversations (Section 6).
        try:
            depts = [r[0] for r in self.store.conn.execute("SELECT DISTINCT department FROM employees WHERE department IS NOT NULL AND department<>''").fetchall()]
            for d in depts:
                exists = self.store.conn.execute("SELECT id FROM voic3_conversations WHERE kind='department' AND department=?", (d,)).fetchone()
                if not exists:
                    cur = self.store.conn.execute("INSERT INTO voic3_conversations(kind,name,department,created_by,is_announcement_only,pinned_message_id,created_at) VALUES(?,?,?,?,?,?,?)", ("department", d, d, None, 0, None, iso_now()))
                    cid = int(cur.lastrowid)
                    for (eid,) in self.store.conn.execute("SELECT id FROM employees WHERE department=?", (d,)).fetchall():
                        self.store.conn.execute("INSERT OR IGNORE INTO voic3_members(conversation_id,employee_id,role,last_read_message_id,joined_at) VALUES(?,?,?,?,?)", (cid, int(eid), "member", 0, iso_now()))
            self.store.conn.commit()
        except Exception:
            pass
        # Seed default VOIC3 templates (Section 7).
        try:
            cnt = self.store.conn.execute("SELECT COUNT(*) AS c FROM voic3_templates").fetchone()[0]
            if not cnt:
                defaults = [
                    ("Leave Request Acknowledgement", "HR", "Thank you for your leave request. It has been received and will be reviewed by your manager within 2 business days."),
                    ("Safety Incident Report", "Safety", "A safety incident has been logged. Please ensure the area is secured and report to your supervisor immediately."),
                    ("Payslip Query", "Payroll", "Your payslip query has been received. Our payroll team will respond within 3 business days."),
                    ("Shift Swap Request", "HR", "Your shift swap request has been submitted for approval."),
                ]
                for title, cat, body in defaults:
                    self.store.conn.execute("INSERT INTO voic3_templates(title,category,body,created_by,created_at) VALUES(?,?,?,?,?)", (title, cat, body, None, iso_now()))
                self.store.conn.commit()
        except Exception:
            pass
        # MASTER CONTROL signs entitlements with a key sealed in the live data home.
        try:
            master_control.set_data_dir(legacy.DATA_HOME)
        except Exception:
            pass

    def notify_owners(self, subject: str, body: str):
        try:
            owners = self.store.conn.execute("SELECT employee_id FROM mobile_accounts WHERE active=1").fetchall()
            stamp = iso_now()
            for r in owners:
                self.store.conn.execute(
                    "INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",
                    ("System", "Management / Owners", r["employee_id"], "MANAGEMENT", subject[:200], body[:20000], stamp)
                )
            self.store.conn.commit()
        except Exception:
            pass

    def _llm_chat(self, prompt: str, actor: str = "administrator", history=None):
        """Local model call for the slide-over drawer and agent replies.

        Uses the same single model as the CORTEX page, with optional prior turns
        so a follow-up has context. Raises when no local model fits, so the
        caller's deterministic data summary is used instead.
        """
        host, model, chosen = self._local_model_config()
        if not model:
            raise RuntimeError(chosen.get("reason") or "No local model fits in this PC's free memory.")
        messages = []
        if isinstance(history, list):
            for item in history[-8:]:
                if isinstance(item, dict) and item.get("role") in ("user", "assistant"):
                    content = clean(item.get("content"))[:8000]
                    if content:
                        messages.append({"role": item["role"], "content": content})
        messages.append({"role": "user", "content": prompt[:24000]})
        result = _call_without_db_lock(cortex_local.chat, messages, model, host=host, timeout=240,
                                       num_ctx=chosen.get("num_ctx"))
        if not result["reply"]:
            raise RuntimeError("Local AI returned an empty response.")
        return {"reply": result["reply"], "model": model}

    def _evolve_llm(self, prompt: str, actor: str = "system"):
        """Small, fast local call used by the EVOLV3 self-evolution loop.

        The 14B model needs more RAM than this machine has, so evolution uses a
        small model, caps the answer length and gives every item a hard
        deadline. If it fails, academy.evolve() re-uses already-reviewed cards
        instead, so the weekly run always produces usable content.
        """
        # EVOLV3 no longer runs a model of its own: it shares the single CORTEX
        # model, so only one copy is ever resident in RAM.
        _host, model, _chosen = self._local_model_config()
        if not model:
            # Same rule as the CORTEX page: without a model that fits, say so and
            # let academy.evolve() re-use reviewed cards instead of hanging.
            raise RuntimeError(_chosen.get("reason") or "No local model fits in this PC's free memory.")
        host = os.environ.get("EVOLV3_MODEL_HOST", "").strip() or _host
        try:
            timeout = int(os.environ.get("EVOLV3_LLM_TIMEOUT", "180"))
        except ValueError:
            timeout = 180
        payload = json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": prompt[:5000]}],
            "stream": False,
            "keep_alive": "5m",
            "options": {"num_predict": 260, "temperature": 0.6, "top_p": 0.9},
        }, ensure_ascii=False).encode()

        def _post():
            req = urllib.request.Request(host.rstrip("/") + "/api/chat", data=payload,
                                         headers={"Content-Type": "application/json"},
                                         method="POST")
            with urllib.request.urlopen(req, timeout=timeout) as response:
                body = json.loads(response.read().decode("utf-8", "replace"))
            reply = (body.get("message") or {}).get("content") or body.get("response") or ""
            if not reply.strip():
                raise RuntimeError("Local AI returned an empty response.")
            return {"reply": reply.strip(), "model": model}

        # A socket timeout alone is not enough: a stalled model can hold the
        # connection open forever. This hard wall-clock deadline keeps the
        # weekly job moving even when the machine is short of memory.
        import concurrent.futures as _futures
        pool = _futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="evolv3-llm")
        try:
            return pool.submit(_post).result(timeout=timeout + 10)
        except _futures.TimeoutError:
            raise TimeoutError("Local AI did not answer within %d seconds." % timeout)
        finally:
            pool.shutdown(wait=False)

    def _ai_hub_executor(self, payload: dict, actor: str):
        return self.hub_send({
            "subject": payload.get("subject") or "Message from Beyond Registration",
            "body": payload.get("body") or payload.get("summary") or "",
            "employee_id": payload.get("employee_id"),
            "department": payload.get("department"),
            "payroll_id": payload.get("payroll_id"),
        }, actor)

    def _ddns_update_executor(self, payload: dict, actor: str):
        """Run the DDNS update (reuses the in-house updater logic)."""
        import urllib.request, datetime as _dt
        # Detect WAN IP
        ip = ""
        for url in ("https://api.ipify.org", "https://ifconfig.me/ip", "https://ipv4.icanhazip.com"):
            try:
                with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "nexus-ddns/1.0"}), timeout=12) as r:
                    v = r.read().decode().strip()
                if v and v.count(".") == 3:
                    ip = v
                    break
            except Exception:
                continue
        if not ip:
            return {"ok": False, "error": "Could not detect WAN IP"}
        # Call DuckDNS
        url = f"https://www.duckdns.org/update?domains=your-userd-dean&token=YOUR_DUCKDNS_TOKEN&ip={ip}"
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "nexus-ddns/1.0"}), timeout=15) as r:
                body = r.read().decode().strip()
            if body == "OK":
                # Update last IP file
                try:
                    Path = __import__("pathlib").Path
                    Path(r"C:\NEXUS\tools\ddns_last_ip.txt").write_text(ip, encoding="utf-8")
                except Exception:
                    pass
                return {"ok": True, "ip": ip, "hostname": "your-userd-dean.duckdns.org", "result": "OK"}
            return {"ok": False, "ip": ip, "result": body}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:200]}

    # --- Session persistence -------------------------------------------------
    # Sessions are held in memory, so every restart used to sign every caregiver
    # out mid-shift. Mobile sessions (12 h tokens) are now written to disk and
    # restored on start, so a server restart no longer interrupts a patient walk.
    def _sessions_path(self):
        try:
            return Path(legacy.DATA_HOME) / "sessions.json"
        except Exception:
            return Path(".") / "sessions.json"

    def load_sessions(self) -> None:
        try:
            path = self._sessions_path()
            if not path.is_file():
                return
            payload = json.loads(path.read_text(encoding="utf-8"))
            now = time.time()
            restored = 0
            for token, item in (payload.get("mobile") or {}).items():
                expiry = float(item.get("expiry") or 0)
                if expiry > now:
                    self.mobile_sessions[token] = int(item.get("employee_id") or 0)
                    self.mobile_profiles[token] = str(item.get("profile") or "staff")
                    self.mobile_session_expiries[token] = expiry
                    restored += 1
            if restored:
                print(f"restored {restored} mobile session(s)")
        except Exception as exc:  # noqa: BLE001
            print("session restore skipped:", exc)

    def save_sessions(self) -> None:
        try:
            path = self._sessions_path()
            now = time.time()
            mobile = {}
            for token in list(self.mobile_sessions):
                expiry = float(self.mobile_session_expiries.get(token, 0))
                if expiry > now:
                    mobile[token] = {
                        "employee_id": self.mobile_sessions.get(token, 0),
                        "profile": self.mobile_profiles.get(token, "staff"),
                        "expiry": expiry,
                    }
            tmp = path.with_name(path.name + ".tmp")
            tmp.write_text(json.dumps({"mobile": mobile}), encoding="utf-8")
            os.replace(tmp, path)
        except Exception as exc:  # noqa: BLE001
            print("session save skipped:", exc)

    @staticmethod
    def _local_model_host():
        """Where the local model lives. Localhost only - no cloud endpoint, no key."""
        return (((SERVICE.config or {}).get("ollama_host") or "").strip()
                or os.environ.get("OLLAMA_HOST", "").strip()
                or cortex_local.DEFAULT_HOST).rstrip("/")

    @staticmethod
    def _local_model_saved():
        """The model name saved in Settings (may be an uninstalled leftover)."""
        return clean((SERVICE.config or {}).get("vision_model") or "") or os.environ.get("VISION_MODEL", "").strip()

    @staticmethod
    def _local_model_config():
        """The one local model every CORTEX path uses - page, drawer and EVOLV3.

        Delegates to cortex_local, which picks the smallest installed model that
        still fits free RAM. On an 8 GB laptop that is what stops every turn
        silently falling back to a data-only answer.
        """
        host = AppService._local_model_host()
        chosen = cortex_local.resolve(host, AppService._local_model_saved())
        return host, chosen["model"], chosen

    def _ollama_tags(self, host):
        """Installed model names, or [] when Ollama is not answering."""
        try:
            req = urllib.request.Request(host + "/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=3) as response:
                data = json.loads(response.read().decode("utf-8", errors="replace"))
            return sorted({str(m.get("name") or "") for m in (data.get("models") or []) if m.get("name")})
        except Exception:
            return []

    def authenticated(self, sid: str | None) -> str | None:
        if not sid:
            return None
        expiry = self.session_expiries.get(sid)
        if expiry is not None and expiry <= time.time():
            self.sessions.pop(sid, None)
            self.session_expiries.pop(sid, None)
            return None
        username = self.sessions.get(sid)
        if not username:
            return None
        # Revoke sessions for accounts that were disabled or removed.
        active = self.store.conn.execute(
            "SELECT 1 FROM admins WHERE username=? COLLATE NOCASE AND active=1", (username,)).fetchone()
        if not active:
            self.sessions.pop(sid, None)
            self.session_expiries.pop(sid, None)
            return None
        return username

    def role_for(self, username: str | None) -> str:
        if not username:
            return "Staff"
        row = self.store.conn.execute("SELECT role FROM admins WHERE username=? COLLATE NOCASE AND active=1", (username,)).fetchone()
        # Never default to Administrator for a missing/disabled account.
        return clean(row["role"]) if row and row["role"] else "Staff"

    def permissions_for(self, username: str | None) -> PermissionMaskingEngine:
        role = self.role_for(username)
        if not username:
            return PermissionMaskingEngine(role)
        row = self.store.conn.execute(
            "SELECT o.grants_json,o.scope_type,o.scope_values_json,a.role FROM admin_permission_overrides o JOIN admins a ON a.id=o.admin_id WHERE a.username=? COLLATE NOCASE",
            (username,),
        ).fetchone()
        if not row:
            return PermissionMaskingEngine(role)
        try:
            grants = json.loads(row["grants_json"] or "{}")
        except (ValueError, TypeError):
            grants = {}
        try:
            scope_values = json.loads(row["scope_values_json"] or "[]")
        except (ValueError, TypeError):
            scope_values = []
        return PermissionMaskingEngine(row["role"] or role, grants if isinstance(grants, dict) else {}, row["scope_type"] or "employees", scope_values if isinstance(scope_values, list) else [])

    def query(self, sql: str, args=()):
        return [dict(r) for r in self.store.conn.execute(sql, args).fetchall()]

    def flush(self):
        """Write any committed change that is still only in RAM to the disk."""
        try:
            legacy.flush_all()
        except Exception:
            pass

    def start_escalator(self):
        return None

    def stop_escalator(self):
        return None

    def fatigue_flags(self, threshold=8):
        rows=self.query("""SELECT d.employee_id,d.work_date,d.total_hours,e.employee_no,e.first_name,e.last_name,e.department FROM attendance_daily d JOIN employees e ON e.id=d.employee_id WHERE e.employment_status='Active' AND d.total_hours>0 ORDER BY d.employee_id,d.work_date DESC""")
        by={}
        for r in rows: by.setdefault(int(r["employee_id"]),[]).append(r)
        today=date.today(); out=[]
        for eid,rs in by.items():
            dates=sorted({date.fromisoformat(r["work_date"]) for r in rs},reverse=True)
            if not dates: continue
            streak=1
            for i in range(1,len(dates)):
                if (dates[i-1]-dates[i]).days==1: streak+=1
                else: break
            last=dates[0]
            if streak>=threshold and (today-last).days<=2:
                streak_dates={d.isoformat() for d in dates[:streak]}
                hours=round(sum(float(x["total_hours"] or 0) for x in rs if x["work_date"] in streak_dates),1)
                r0=rs[0]
                out.append({"employee_id":eid,"employee_no":r0["employee_no"],"name":(r0["first_name"]+" "+r0["last_name"]).strip(),"department":r0["department"],"consecutive_days":streak,"last_work_date":last.isoformat(),"hours_in_streak":hours})
        out.sort(key=lambda x:(-x["consecutive_days"],x["name"]))
        return out

    def dashboard(self):
        s = self.store
        counts = s.counts()
        today = date.today().isoformat()
        attendance = s.conn.execute("SELECT COUNT(*) FROM attendance_daily WHERE work_date=? AND total_hours>0", (today,)).fetchone()[0]
        leave_pending = s.conn.execute("SELECT COUNT(*) FROM leave_records WHERE status='Pending'").fetchone()[0]
        payroll_pending = s.conn.execute("SELECT COUNT(*) FROM payroll_records WHERE status IN ('Draft','Approved')").fetchone()[0]
        departments = self.query("SELECT COALESCE(NULLIF(department,''),'Unassigned') AS name, COUNT(*) AS value FROM employees WHERE employment_status='Active' GROUP BY name ORDER BY value DESC LIMIT 7")
        recent = self.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 8")
        attendance_week = self.query("SELECT work_date, COUNT(*) AS present, ROUND(COALESCE(SUM(total_hours),0),1) AS hours FROM attendance_daily WHERE work_date>=? GROUP BY work_date ORDER BY work_date", ((date.today()-timedelta(days=6)).isoformat(),))
        return {"counts":counts,"attendance_today":attendance,"leave_pending":leave_pending,"payroll_pending":payroll_pending,"departments":departments,"recent":recent,"attendance_week":attendance_week,"today":today,"fatigue_flags":len(self.fatigue_flags(8))}

    def employees(self, search="", permissions=None):
        term = f"%{clean(search)}%"
        rows = self.store.conn.execute("""SELECT * FROM employees WHERE employee_no LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR job_title LIKE ? OR department LIKE ? ORDER BY last_name,first_name""", (term,term,term,term,term)).fetchall()
        permissions = permissions or PermissionMaskingEngine("Administrator")
        scoped = [r for r in rows if permissions.employee_in_scope(int(r["id"]))]
        return [permissions.filter_employee_record(dict(r)) for r in scoped]

    def employee_detail(self, employee_id: int, permissions=None):
        emp = self.store.employee(employee_id)
        if not emp:
            raise KeyError("Employee not found.")
        permissions = permissions or PermissionMaskingEngine("Administrator")
        if not permissions.employee_in_scope(employee_id):
            raise PermissionError("This employee is outside your assigned scope.")
        result = {
            "employee":permissions.filter_employee_record(dict(emp)),
            "hr_records":self.query("SELECT * FROM hr_records WHERE employee_id=? ORDER BY id DESC",(employee_id,)),
            "leave":self.query("SELECT * FROM leave_records WHERE employee_id=? ORDER BY date_from DESC",(employee_id,)),
            "contracts":self.query("SELECT * FROM employee_contracts WHERE employee_id=? ORDER BY id DESC",(employee_id,)),
            "documents":self.query("SELECT * FROM employee_documents WHERE employee_id=? ORDER BY id DESC",(employee_id,)),
            "reviews":self.query("SELECT * FROM performance_reviews WHERE employee_id=? ORDER BY review_date DESC",(employee_id,)),
            "payroll":self.query("SELECT * FROM payroll_records WHERE employee_id=? ORDER BY pay_period DESC",(employee_id,)) if permissions.can_view_payroll() else [],
            "attendance":self.query("SELECT * FROM attendance_daily WHERE employee_id=? ORDER BY work_date DESC LIMIT 30",(employee_id,)),
        }
        return result

    def save_upload(self, payload: dict, folder: str) -> dict:
        filename = Path(clean(payload.get("filename")) or "attachment.bin").name
        raw = payload.get("data", "")
        if not isinstance(raw, str) or len(raw) > 28_000_000:
            raise ValueError("File is too large or invalid. Maximum upload size is 20 MB.")
        try:
            content = base64.b64decode(raw.split(",",1)[-1], validate=True)
        except Exception as exc:
            raise ValueError("File data could not be decoded.") from exc
        if len(content) > 20 * 1024 * 1024:
            raise ValueError("Maximum upload size is 20 MB.")
        self.scan_or_reject(content, filename)
        sub = legacy.PHOTO_DIR if folder == "photos" else legacy.DOC_DIR
        target_dir = sub / ("Uploads" if folder != "photos" else "Profiles")
        target_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", filename)[:100] or "file.bin"
        target = target_dir / f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{safe_name}"
        target.write_bytes(content)
        return {"file_path":str(target),"file_name":filename}

    def scan_or_reject(self, content: bytes, filename: str, actor: str = "system"):
        """ClamAV scan for untrusted uploads. Infected files are always blocked;
        scanner errors are logged but do not block legitimate uploads."""
        try:
            res = security_suite.scan_bytes(content, filename)
        except Exception as exc:
            res = {"engine": "clamav", "result": "error", "detail": f"{type(exc).__name__}: {exc}"}
        if res.get("result") == "infected":
            try: self.store.log(actor, "Malware upload blocked", "security", 0, f"{filename}: {res.get('signature') or 'unknown'}")
            except Exception: pass
            raise PermissionError(f"Upload blocked: malware detected ({res.get('signature') or 'unknown signature'}).")
        if res.get("result") == "error":
            try: self.store.log(actor, "AV scan error", "security", 0, f"{filename}: {res.get('detail') or 'unknown'}")
            except Exception: pass
        return res

    def record_list(self, kind: str, query: dict):
        if kind == "attendance":
            sql = "SELECT d.*,e.employee_no,e.first_name,e.last_name FROM attendance_daily d JOIN employees e ON e.id=d.employee_id WHERE 1=1"
            args=[]
            if query.get("from"): sql += " AND d.work_date>=?"; args.append(query["from"])
            if query.get("to"): sql += " AND d.work_date<=?"; args.append(query["to"])
            if query.get("employee_id"): sql += " AND d.employee_id=?"; args.append(int(query["employee_id"]))
            sql += " ORDER BY d.work_date DESC,e.last_name,e.first_name LIMIT 500"
            return self.query(sql,args)
        if kind == "leave":
            sql = "SELECT l.*,e.employee_no,e.first_name,e.last_name FROM leave_records l JOIN employees e ON e.id=l.employee_id WHERE 1=1"
            args=[]
            if query.get("status"): sql += " AND l.status=?"; args.append(query["status"])
            if query.get("employee_id"): sql += " AND l.employee_id=?"; args.append(int(query["employee_id"]))
            sql += " ORDER BY l.date_from DESC LIMIT 500"
            return self.query(sql,args)
        if kind == "payroll":
            sql = "SELECT p.*,e.employee_no,e.first_name,e.last_name FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE 1=1"
            args=[]
            if query.get("employee_id"): sql += " AND p.employee_id=?"; args.append(int(query["employee_id"]))
            if query.get("period"): sql += " AND p.pay_period=?"; args.append(query["period"])
            sql += " ORDER BY p.pay_period DESC,e.last_name,e.first_name LIMIT 500"
            return self.query(sql,args)
        if kind in GENERIC:
            table, _ = GENERIC[kind]
            return self.query(f"SELECT t.*,e.employee_no,e.first_name,e.last_name FROM {table} t JOIN employees e ON e.id=t.employee_id ORDER BY t.id DESC LIMIT 500")
        if kind == "hr":
            sql="SELECT h.*,e.employee_no,e.first_name,e.last_name FROM hr_records h JOIN employees e ON e.id=h.employee_id WHERE 1=1"; args=[]
            if query.get("employee_id"): sql+=" AND h.employee_id=?"; args.append(int(query["employee_id"]))
            if query.get("record_type"): sql+=" AND h.record_type=?"; args.append(query["record_type"])
            sql += " ORDER BY h.id DESC LIMIT 500"
            return self.query(sql,args)
        raise ValueError("Unknown record collection.")

    def create_generic(self, kind: str, data: dict, actor: str, record_id: int | None = None):
        if kind == "hr":
            employee_id = int(data.get("employee_id") or 0)
            typ = clean(data.get("record_type"))
            if not typ: raise ValueError("Choose a record category.")
            payload = {k:clean(data.get(k)) for k in HR_FIELDS}
            result = self.store.save_hr_record(employee_id, typ, payload, actor, record_id)
            return result
        table, allowed = GENERIC[kind]
        data = dict(data)
        employee_id = int(data.get("employee_id") or 0)
        if not self.store.employee(employee_id): raise ValueError("Select a valid employee.")
        values = {k:data.get(k) for k in allowed if k in data}
        values["employee_id"] = employee_id
        for k,v in list(values.items()):
            if k == "employee_id": continue
            values[k] = clean(v)
        stamp=iso_now()
        if record_id:
            sets=",".join(f"{k}=?" for k in values)
            self.store.conn.execute(f"UPDATE {table} SET {sets},updated_at=? WHERE id=?",[*values.values(),stamp,record_id])
            rid=record_id; action="Updated"
        else:
            values.update(created_by=actor,created_at=stamp,updated_at=stamp)
            cols=list(values); marks=','.join('?' for _ in cols)
            cur=self.store.conn.execute(f"INSERT INTO {table}({','.join(cols)}) VALUES({marks})",[values[k] for k in cols])
            rid=int(cur.lastrowid); action="Created"
        self.store.log(actor,f"{action} {kind} record",kind,rid, f"Employee ID {employee_id}")
        self.store.conn.commit()
        return rid

    def create_leave(self, data, actor):
        eid=int(data.get("employee_id") or 0)
        if not self.store.employee(eid): raise ValueError("Select a valid employee.")
        d1=clean(data.get("date_from")); d2=clean(data.get("date_to")); typ=clean(data.get("leave_type"))
        try:
            date.fromisoformat(d1); date.fromisoformat(d2)
            days=float(data.get("days") or 0)
        except Exception as exc: raise ValueError("Enter valid leave dates and working days.") from exc
        if d2<d1 or days<=0: raise ValueError("End date must follow start date and days must be positive.")
        stamp=iso_now()
        attachment_path=clean(data.get("attachment_path")); attachment_name=clean(data.get("attachment_name"))
        cur=self.store.conn.execute("""INSERT INTO leave_records(employee_id,leave_type,date_from,date_to,days,reason,status,attachment_path,attachment_name,notes,created_by,created_at,updated_at)
          VALUES(?,?,?,?,?,?,'Pending',?,?,?,?,?,?)""",(eid,typ,d1,d2,days,clean(data.get("reason")),attachment_path,attachment_name,clean(data.get("notes")),actor,stamp,stamp))
        rid=int(cur.lastrowid); self.store.log(actor,"Created leave application","leave",rid,f"{typ}, {d1} to {d2} ({days} days)"); self.store.conn.commit(); return rid

    def calculate_payroll(self, data):
        start=self.store.attendance_setting("pay_shift_start","09:00")
        end=self.store.attendance_setting("pay_shift_end","19:15")
        unpaid=float(self.store.attendance_setting("pay_unpaid_lunch_minutes","15") or 15)
        duration=(datetime.strptime(end,"%H:%M")-datetime.strptime(start,"%H:%M")).total_seconds()/3600
        paid=duration-unpaid/60
        if paid<=0: raise ValueError("Payroll shift settings do not produce positive paid hours.")
        cats=[("weekday_hours","pay_weekday_rate"),("saturday_hours","pay_saturday_rate"),("sunday_hours","pay_sunday_rate"),("public_holiday_hours","pay_public_holiday_rate")]
        hours={k:float(data.get(k) or 0) for k,_ in cats}
        extras={k:float(data.get(k) or 0) for k in ("overtime","allowances","bonus","other_deductions")}
        if any(v<0 for v in [*hours.values(),*extras.values()]): raise ValueError("Hours and amounts cannot be negative.")
        earned=sum(hours[key]*(float(self.store.attendance_setting(ratekey,"0").replace(',',''))/paid) for key,ratekey in cats)
        gross=earned+extras["overtime"]+extras["allowances"]+extras["bonus"]
        # Statutory deductions come from tax_engine (SARS tables, updated each
        # March): UIF stops at the R17 712 monthly ceiling and PAYE is the
        # bracket tax LESS the primary rebate. Previously PAYE was always 0 and
        # UIF had no ceiling. Rounding is half-up to the cent (Decimal).
        uif=tax_engine.uif_employee(gross)
        employer_uif=tax_engine.uif_employer(gross)
        paye=tax_engine.paye_monthly(gross)
        deductions=tax_engine.money(paye+uif+extras["other_deductions"])
        return {**hours,**extras,"basic_salary":tax_engine.money(earned),"gross_pay":tax_engine.money(gross),"paye":paye,"uif":uif,"employer_uif":employer_uif,"total_deductions":deductions,"net_pay":tax_engine.money(gross-deductions),"paid_shift_hours":round(paid,2)}

    def update_payroll(self, record_id, data, actor):
        existing=self.store.conn.execute("SELECT * FROM payroll_records WHERE id=?",(record_id,)).fetchone()
        if not existing: raise KeyError("Payroll record not found.")
        eid=int(data.get("employee_id") or 0)
        if not self.store.employee(eid): raise ValueError("Select a valid employee.")
        period=clean(data.get("pay_period")); datetime.strptime(period,"%Y-%m")
        status=clean(data.get("status") or "Drafted")
        if status not in ("Draft","Drafted","Approved","Sent","Paid"): raise ValueError("Choose Drafted, Approved, Sent or Paid as the payroll status.")
        calc=self.calculate_payroll(data)
        fields=["employee_id","pay_period","pay_date","basic_salary","weekday_hours","saturday_hours","sunday_hours","public_holiday_hours","overtime","allowances","bonus","gross_pay","paye","uif","employer_uif","other_deductions","total_deductions","net_pay","status","notes"]
        row={"employee_id":eid,"pay_period":period,"pay_date":clean(data.get("pay_date")),**calc,"status":("Drafted" if status=="Draft" else status),"employer_uif":calc.get("employer_uif",0),"notes":clean(data.get("notes"))}
        stamp=iso_now(); sets=",".join(f"{k}=?" for k in fields)
        self.store.conn.execute(f"UPDATE payroll_records SET {sets},updated_at=? WHERE id=?",[row.get(k,0) for k in fields]+[stamp,record_id])
        self.store.log(actor,"Updated payroll record","payroll",record_id,f"Employee ID {eid}; period {period}; status {status}")
        self.store.conn.commit()
        return {"id":record_id,"calculation":calc}

    def create_payroll(self, data, actor):
        eid=int(data.get("employee_id") or 0)
        if not self.store.employee(eid): raise ValueError("Select a valid employee.")
        period=clean(data.get("pay_period")); datetime.strptime(period,"%Y-%m")
        status=clean(data.get("status") or "Drafted")
        if status not in ("Draft","Drafted","Approved","Sent","Paid"): raise ValueError("Choose Drafted, Approved, Sent or Paid as the payroll status.")
        calc=self.calculate_payroll(data)
        fields=["employee_id","pay_period","pay_date","basic_salary","weekday_hours","saturday_hours","sunday_hours","public_holiday_hours","overtime","allowances","bonus","gross_pay","paye","uif","employer_uif","other_deductions","total_deductions","net_pay","status","notes"]
        row={"employee_id":eid,"pay_period":period,"pay_date":clean(data.get("pay_date")),**calc,"status":("Drafted" if clean(data.get("status") or "Draft") in ("Draft","Drafted") else clean(data.get("status"))),"employer_uif":calc.get("employer_uif",0),"notes":clean(data.get("notes"))}
        stamp=iso_now(); cols=fields+ ["created_at","updated_at"]
        vals=[row.get(k,0) for k in fields]+[stamp,stamp]
        cur=self.store.conn.execute(f"INSERT INTO payroll_records({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",vals)
        rid=int(cur.lastrowid); self.store.log(actor,"Added payroll record","payroll",rid,f"Employee ID {eid}; period {period}"); self.store.conn.commit()
        return {"id":rid,"calculation":calc}

    def compliance_snapshot(self):
        today=date.today(); alerts=[]
        contracts=self.query("SELECT c.id,c.title,c.end_date,c.status,e.id AS employee_id,e.employee_no,e.first_name,e.last_name FROM employee_contracts c JOIN employees e ON e.id=c.employee_id WHERE COALESCE(c.end_date,'')<>'' ORDER BY c.end_date")
        documents=self.query("SELECT d.id,d.title,d.expiry_date,d.status,e.id AS employee_id,e.employee_no,e.first_name,e.last_name FROM employee_documents d JOIN employees e ON e.id=d.employee_id WHERE COALESCE(d.expiry_date,'')<>'' ORDER BY d.expiry_date")
        for kind,rows,date_key in (("Contract",contracts,"end_date"),("Document",documents,"expiry_date")):
            for r in rows:
                try: due=date.fromisoformat(str(r[date_key])[:10])
                except (ValueError,TypeError): continue
                days=(due-today).days
                if days<=90:
                    severity="Critical" if days<0 else "Warning" if days<=30 else "Attention"
                    alerts.append({"type":kind,"id":r["id"],"employee_id":r["employee_id"],"employee":f"{r['first_name']} {r['last_name']}","employee_no":r["employee_no"],"title":r["title"],"date":due.isoformat(),"days":days,"severity":severity,"status":"Expired" if days<0 else "Expiring"})
        anomalies=[]
        inactive=self.query("SELECT p.id,p.pay_period,p.net_pay,e.employee_no,e.first_name,e.last_name,e.employment_status FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE lower(e.employment_status) NOT IN ('active','on leave') ORDER BY p.pay_period DESC")
        for r in inactive: anomalies.append({"severity":"Critical","issue":"Payroll record for inactive employee","employee":f"{r['first_name']} {r['last_name']}","employee_no":r['employee_no'],"period":r['pay_period'],"record_id":r['id'],"amount":float(r['net_pay'] or 0),"recommendation":"Verify employment status and payroll eligibility before approval."})
        duplicates=self.query("SELECT p.employee_id,p.pay_period,COUNT(*) AS n,MAX(e.employee_no) AS employee_no,MAX(e.first_name) AS first_name,MAX(e.last_name) AS last_name,GROUP_CONCAT(p.id) AS ids FROM payroll_records p JOIN employees e ON e.id=p.employee_id GROUP BY p.employee_id,p.pay_period HAVING COUNT(*)>1")
        for r in duplicates: anomalies.append({"severity":"Critical","issue":"Duplicate payroll records for the same employee and period","employee":f"{r['first_name']} {r['last_name']}","employee_no":r['employee_no'],"period":r['pay_period'],"record_id":r['ids'],"amount":0,"recommendation":"Review duplicate entries and retain only the authorised payroll record."})
        missing_contracts=self.query("SELECT p.id,p.pay_period,p.net_pay,e.employee_no,e.first_name,e.last_name FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE lower(e.employment_status)='active' AND NOT EXISTS (SELECT 1 FROM employee_contracts c WHERE c.employee_id=e.id AND lower(c.status)='active' AND (c.end_date='' OR c.end_date IS NULL OR date(c.end_date)>=date('now'))) ORDER BY p.pay_period DESC")
        for r in missing_contracts: anomalies.append({"severity":"Warning","issue":"Payroll record has no current active contract on file","employee":f"{r['first_name']} {r['last_name']}","employee_no":r['employee_no'],"period":r['pay_period'],"record_id":r['id'],"amount":float(r['net_pay'] or 0),"recommendation":"Check the signed contract and employment dates. This is a review alert, not an automatic wage hold."})
        return {"generated_on":today.isoformat(),"expiry_alerts":sorted(alerts,key=lambda x:x['days']),"anomalies":anomalies,"summary":{"expiry":len(alerts),"anomalies":len(anomalies),"critical":sum(1 for x in anomalies if x['severity']=='Critical')}}

    def compliance_detail(self, record_id: str, issue: str, period: str, employee_no: str) -> dict:
        """Return the source records behind an advisory reconciliation finding."""
        emp=self.store.conn.execute("SELECT * FROM employees WHERE employee_no=?",(employee_no,)).fetchone()
        if not emp:
            raise KeyError("The employee linked to this finding could not be found.")
        employee=dict(emp); eid=int(employee["id"])
        payroll=[]
        ids=[int(x) for x in re.findall(r"\d+", str(record_id or ""))]
        if ids:
            marks=",".join("?" for _ in ids)
            payroll=self.query(f"SELECT * FROM payroll_records WHERE id IN ({marks}) ORDER BY pay_period DESC",ids)
        if not payroll:
            payroll=self.query("SELECT * FROM payroll_records WHERE employee_id=? AND pay_period=? ORDER BY id",(eid,period))
        contracts=self.query("SELECT * FROM employee_contracts WHERE employee_id=? ORDER BY id DESC",(eid,))
        attendance=self.query("SELECT * FROM attendance_daily WHERE employee_id=? AND substr(work_date,1,7)=? ORDER BY work_date",(eid,period))
        leave=self.query("SELECT * FROM leave_records WHERE employee_id=? AND date_from<=? AND date_to>=? ORDER BY date_from",(eid,period+"-31",period+"-01"))
        audit_sql="SELECT * FROM audit_log WHERE (entity_type='payroll' AND entity_id IN (%s)) OR (entity_type='employee' AND entity_id=?) ORDER BY id DESC LIMIT 30" % (",".join("?" for _ in ids) if ids else "NULL")
        audit=self.query(audit_sql,[*[str(x) for x in ids],str(eid)])
        return {"employee":employee,"issue":issue,"period":period,"payroll":payroll,"contracts":contracts,"attendance":attendance,"leave":leave,"audit":audit,
                "notice":"Advisory finding only. This review does not stop or withhold legally owed wages."}

    # --- Patient care module -------------------------------------------------
    PATIENT_FIELDS = ["patient_number","first_name","last_name","date_of_birth","allergies","mobility_limitations","emergency_information","primary_caregiver","consent_status","id_number","medication_schedule","special_care","medical_history"]

    def _patient_row(self, patient_id):
        row = self.store.conn.execute("SELECT * FROM patients WHERE id=?", (int(patient_id),)).fetchone()
        if not row:
            raise KeyError("Patient record not found.")
        return row

    def _patient_dict(self, row, detail=False):
        item = dict(row)
        for key in ("conditions","medications","procedures"):
            raw = item.pop(key + "_json", "[]")
            try:
                item[key] = json.loads(raw or "[]")
            except (ValueError, TypeError):
                item[key] = []
        if detail:
            pid = int(item["id"])
            item["documents"] = self.query("SELECT id,title,document_type,file_name,mime_type,uploaded_by AS created_by,created_at FROM patient_documents WHERE patient_id=? ORDER BY id DESC", (pid,))
            item["contacts"] = self.query("SELECT * FROM patient_contacts WHERE patient_id=? ORDER BY priority,id", (pid,))
            item["emergency_alerts"] = self.query("SELECT * FROM patient_emergency_alerts WHERE patient_id=? ORDER BY id DESC LIMIT 50", (pid,))
        return item

    def patient_access_ok(self, actor, patient_id, action="view"):
        """Administrators always pass; other roles need an explicit grant or an active assignment."""
        permissions = self.permissions_for(actor)
        if permissions.user_role == "Administrator":
            return permissions
        admin_row = self.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
        assigned = False
        if admin_row:
            assigned = bool(self.store.conn.execute(
                "SELECT 1 FROM patient_access WHERE patient_id=? AND principal_type='admin' AND principal_id=? AND active=1",
                (int(patient_id), int(admin_row["id"]))).fetchone())
        if action == "view" and assigned:
            return PermissionMaskingEngine("Administrator")
        if permissions.allows("patients", action):
            return permissions
        if assigned and action == "view":
            return PermissionMaskingEngine("Administrator")
        raise PermissionError("You are not authorised to access this patient record.")

    def patients_for_actor(self, actor):
        permissions = self.permissions_for(actor)
        admin_row = self.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
        if permissions.user_role == "Administrator":
            return permissions, None
        assigned_ids = []
        if admin_row:
            assigned_ids = [int(r["patient_id"]) for r in self.query("SELECT patient_id FROM patient_access WHERE principal_type='admin' AND principal_id=? AND active=1", (int(admin_row["id"]),))]
        if permissions.allows("patients", "view"):
            return permissions, None
        if assigned_ids:
            return PermissionMaskingEngine("Administrator"), assigned_ids
        raise PermissionError("Patient care records require an explicit permission grant or caregiver assignment.")

    def save_patient(self, data, actor, patient_id=None):
        values = {k: clean(data.get(k)) for k in self.PATIENT_FIELDS}
        if not values["first_name"] or not values["last_name"]:
            raise ValueError("Patient first and last name are required.")
        if values["consent_status"] not in ("Pending","Granted","Declined","Withdrawn"):
            raise ValueError("Invalid consent status.")
        for key in ("conditions","medications","procedures"):
            raw = data.get(key)
            if isinstance(raw, str):
                items = [line.strip() for line in raw.splitlines() if line.strip()]
            elif isinstance(raw, list):
                items = [clean(x) for x in raw if clean(x)]
            else:
                items = []
            values[key + "_json"] = json.dumps(items[:100], ensure_ascii=False)
        stamp = iso_now()
        if patient_id:
            self._patient_row(patient_id)
            sets = ",".join(f"{k}=?" for k in list(values) + ["updated_at"])
            self.store.conn.execute(f"UPDATE patients SET {sets} WHERE id=?", [*values.values(), stamp, int(patient_id)])
            rid = int(patient_id); action = "Updated"
        else:
            cols = list(values) + ["created_by","created_at","updated_at"]
            cur = self.store.conn.execute(
                f"INSERT INTO patients({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",
                [*values.values(), actor, stamp, stamp])
            rid = int(cur.lastrowid); action = "Created"
        self.store.log(actor, f"{action} patient record", "patient", rid, f"{values['first_name']} {values['last_name']}")
        self.store.conn.commit()
        return rid

    def patient_walk_start(self, patient_id, data, actor):
        row = self._patient_row(patient_id)
        if clean(row["consent_status"]) != "Granted":
            raise PermissionError("Patient walks require recorded patient consent (consent status: Granted).")
        if self.store.conn.execute("SELECT 1 FROM patient_walks WHERE patient_id=? AND status='Active'", (int(patient_id),)).fetchone():
            raise ValueError("This patient already has an active walk. End it before starting another.")
        lat = data.get("latitude"); lon = data.get("longitude")
        lat = float(lat) if isinstance(lat,(int,float)) else None
        lon = float(lon) if isinstance(lon,(int,float)) else None
        stamp = iso_now()
        cur = self.store.conn.execute(
            "INSERT INTO patient_walks(patient_id,status,notes,started_by,started_from,started_at,last_checkin_at,last_latitude,last_longitude) VALUES(?, 'Active', ?,?,?,?,?,?,?)",
            (int(patient_id), clean(data.get("note")), actor, clean(data.get("started_from")) or "Windows", stamp, stamp if lat is not None else "", lat, lon))
        wid = int(cur.lastrowid)
        self.store.conn.execute("INSERT INTO patient_walk_events(walk_id,note,latitude,longitude,created_by,created_at) VALUES(?,?,?,?,?,?)",
            (wid, clean(data.get("note")), lat, lon, actor, stamp))
        self.store.log(actor, "Started patient walk", "patient_walk", wid, f"Patient {patient_id}")
        self.store.conn.commit()
        return wid

    def patient_walk_checkin(self, walk_id, patient_id, data, actor):
        walk = self.store.conn.execute("SELECT * FROM patient_walks WHERE id=? AND patient_id=? AND status='Active'", (int(walk_id), int(patient_id))).fetchone()
        if not walk:
            raise KeyError("Active patient walk not found.")
        lat = data.get("latitude"); lon = data.get("longitude")
        lat = float(lat) if isinstance(lat,(int,float)) else walk["last_latitude"]
        lon = float(lon) if isinstance(lon,(int,float)) else walk["last_longitude"]
        stamp = iso_now()
        self.store.conn.execute("UPDATE patient_walks SET last_checkin_at=?,last_latitude=?,last_longitude=?,notes=CASE WHEN ?<>'' THEN ? ELSE notes END WHERE id=?",
            (stamp, lat, lon, clean(data.get("note")), clean(data.get("note")), int(walk_id)))
        self.store.conn.execute("INSERT INTO patient_walk_events(walk_id,note,latitude,longitude,created_by,created_at) VALUES(?,?,?,?,?,?)",
            (int(walk_id), clean(data.get("note")), lat, lon, actor, stamp))
        self.store.log(actor, "Patient walk check-in", "patient_walk", int(walk_id), f"Patient {patient_id}")
        self.store.conn.commit()
        return {"ok": True}

    def patient_walk_end(self, walk_id, patient_id, actor):
        walk = self.store.conn.execute("SELECT * FROM patient_walks WHERE id=? AND patient_id=? AND status='Active'", (int(walk_id), int(patient_id))).fetchone()
        if not walk:
            raise KeyError("Active patient walk not found.")
        stamp = iso_now()
        self.store.conn.execute("UPDATE patient_walks SET status='Completed',ended_at=? WHERE id=?", (stamp, int(walk_id)))
        self.store.log(actor, "Ended patient walk", "patient_walk", int(walk_id), f"Patient {patient_id}")
        self.store.conn.commit()
        return {"ok": True}

    def patient_walk_location(self, walk_id, patient_id, data):
        lat = data.get("latitude"); lon = data.get("longitude")
        try:
            lat = float(lat); lon = float(lon)
        except (TypeError, ValueError):
            raise ValueError("Valid latitude and longitude are required.")
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError("Location coordinates are out of range.")
        walk = self.store.conn.execute("SELECT id FROM patient_walks WHERE id=? AND patient_id=? AND status='Active'", (int(walk_id), int(patient_id))).fetchone()
        if not walk:
            raise KeyError("Active patient walk not found.")
        stamp = iso_now()
        self.store.conn.execute("UPDATE patient_walks SET last_latitude=?,last_longitude=?,last_checkin_at=? WHERE id=?", (lat, lon, stamp, int(walk_id)))
        self.store.conn.execute("INSERT INTO patient_walk_events(walk_id,note,latitude,longitude,created_by,created_at) VALUES(?,?,?,?,?,?)",
            (int(walk_id), "", lat, lon, "location", stamp))
        self.store.conn.commit()
        return {"ok": True}

    def patient_alert_create(self, patient_id, data, actor):
        self._patient_row(patient_id)
        event_type = clean(data.get("event_type")) or "Emergency SOS"
        stamp = iso_now()
        contacts = self.query("SELECT * FROM patient_contacts WHERE patient_id=? ORDER BY priority,id LIMIT 3", (int(patient_id),))
        person_1_in_app = 0
        first = contacts[0] if contacts else None
        if first and first.get("employee_id"):
            account = self.store.conn.execute("SELECT active FROM mobile_accounts WHERE employee_id=?", (int(first["employee_id"]),)).fetchone()
            person_1_in_app = 1 if account and account["active"] else 0
        cur = self.store.conn.execute(
            "INSERT INTO patient_emergency_alerts(patient_id,event_type,status,contact_stage,person_1_in_app,created_by,created_at,updated_at) VALUES(?,?,'Open',1,?,?,?,?,?)",
            (int(patient_id), event_type, person_1_in_app, actor, stamp, stamp))
        aid = int(cur.lastrowid)
        self.store.log(actor, "Created patient emergency alert", "patient_alert", aid, f"Patient {patient_id}: {event_type}")
        self.store.conn.commit()
        return {"id": aid, "status": "Open", "contact_stage": 1, "person_1_in_app": bool(person_1_in_app), "person_2_in_app": False, "person_3_in_app": False,
                "message": "SOS recorded. In-app escalation is queued only for contacts with active employee app accounts; phone contacts require a caregiver to call them."}

    # ===== NAVIQ patient safety =====
    def _iso_after(self, seconds):
        return (datetime.now() + timedelta(seconds=seconds)).replace(microsecond=0).isoformat(sep=" ")

    def _haversine_m(self, lat1, lon1, lat2, lon2):
        import math
        r = 6371000.0
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
        a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
        return 2 * r * math.asin(math.sqrt(a))

    def _ping_record(self, patient_id, lat, lon, accuracy=None, battery=None, speed=None, walk_id=None, source="app", device_key="", actor="system"):
        stamp = iso_now()
        cur = self.store.conn.execute(
            "INSERT INTO patient_location_pings(patient_id,walk_id,latitude,longitude,accuracy_m,battery_pct,speed_mps,source,device_key,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (int(patient_id), walk_id, lat, lon, accuracy, battery, speed, source, device_key, actor, stamp))
        return int(cur.lastrowid), stamp

    def _geofence_check(self, patient_id, lat, lon):
        fences = self.query("SELECT * FROM geofences WHERE patient_id=? AND active=1", (int(patient_id),))
        if not fences:
            return None
        inside = any(self._haversine_m(lat, lon, float(f["latitude"]), float(f["longitude"])) <= float(f["radius_m"] or 100) for f in fences)
        return None if inside else "boundary_exit"

    def raise_safety_alert(self, patient_id, alert_type, severity="warning", details="", actor="system", escalate=False):
        self._patient_row(patient_id)
        dup = self.store.conn.execute("SELECT id FROM safety_alerts WHERE patient_id=? AND alert_type=? AND status='Open'", (int(patient_id), alert_type)).fetchone()
        if dup:
            return int(dup["id"]), False
        stamp = iso_now()
        cur = self.store.conn.execute(
            "INSERT INTO safety_alerts(patient_id,alert_type,severity,status,details,escalation_stage,next_escalate_at,created_by,created_at,updated_at) VALUES(?,?,?,?,?, ?,?,?,?,?)",
            (int(patient_id), alert_type, severity, "Open", clean(details)[:2000], 1 if escalate else 0,
             self._iso_after(60) if escalate else "", actor, stamp, stamp))
        aid = int(cur.lastrowid)
        self.store.log(actor, f"Safety alert: {alert_type}", "safety_alert", aid, f"Patient {patient_id} {severity}")
        self.store.conn.commit()
        if escalate:
            self.escalate_safety_alert(aid, 1)
        return aid, True

    def escalate_safety_alert(self, alert_id, stage):
        alert = self.store.conn.execute("SELECT * FROM safety_alerts WHERE id=?", (int(alert_id),)).fetchone()
        if not alert or clean(alert["status"]) in ("Acknowledged", "Resolved"):
            return
        stage = max(1, min(3, int(stage)))
        contacts = self.query("SELECT * FROM patient_contacts WHERE patient_id=? ORDER BY priority,id", (int(alert["patient_id"]),))
        done = {int(r["contact_priority"]) for r in self.query("SELECT contact_priority FROM emergency_escalations WHERE alert_id=?", (int(alert_id),))}
        stamp = iso_now()
        patient = self.store.conn.execute("SELECT first_name,last_name FROM patients WHERE id=?", (int(alert["patient_id"]),)).fetchone()
        pname = f"{patient['first_name']} {patient['last_name']}" if patient else f"patient {alert['patient_id']}"
        for c in contacts:
            pr = int(c["priority"])
            if pr > stage or pr in done:
                continue
            self.store.conn.execute(
                "INSERT INTO emergency_escalations(alert_id,patient_id,contact_priority,contact_name,channel,status,sent_at) VALUES(?,?,?,?,?,'Sent',?)",
                (int(alert_id), int(alert["patient_id"]), pr, clean(c["name"]), "inapp", stamp))
            if c.get("employee_id"):
                self.store.conn.execute(
                    "INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",
                    ("NAVIQ", "Employee", int(c["employee_id"]), None,
                     f"EMERGENCY — {pname}",
                     f"Emergency alert #{alert_id} ({clean(alert['alert_type'])}) for {pname}. Open the app to acknowledge. Acknowledgement does not mean resolved.", stamp))
        try:
            st = self.store.conn.execute("SELECT latitude,longitude FROM patient_location_pings WHERE patient_id=? ORDER BY id DESC LIMIT 1", (int(alert["patient_id"]),)).fetchone()
            maps = f" https://maps.google.com/?q={st['latitude']},{st['longitude']}" if st else ""
        except Exception:
            maps = ""
        telegram_notify(f"NEXUS/NAVIQ EMERGENCY\n{pname} — {clean(alert['alert_type'])} (stage {stage}){maps}")
        stamp2 = iso_now()
        self.store.conn.execute(
            "UPDATE safety_alerts SET escalation_stage=?,next_escalate_at=?,status=?,updated_at=? WHERE id=?",
            (stage, self._iso_after(60) if stage < 3 else "", "Escalated" if stage >= 2 else "Open", stamp2, int(alert_id)))
        self.store.log("system", f"Escalated safety alert to contact level {stage}", "safety_alert", alert_id, f"Patient {alert['patient_id']}")
        self.store.conn.commit()

    def safety_monitor_tick(self):
        now = iso_now()
        # 1) escalation timers for critical/emergency alerts
        due = self.query("SELECT id,escalation_stage FROM safety_alerts WHERE status IN ('Open','Escalated') AND next_escalate_at!='' AND next_escalate_at<=? AND escalation_stage<3", (now,))
        for row in due:
            with self.lock:
                self.escalate_safety_alert(int(row["id"]), int(row["escalation_stage"]) + 1)
        # 2) walk/ping checks
        walks = self.query("SELECT w.id,w.patient_id,w.started_at,w.last_checkin_at,w.last_latitude,w.last_longitude,p.first_name,p.last_name FROM patient_walks w JOIN patients p ON p.id=w.patient_id WHERE w.status='Active'")
        for w in walks:
            pid = int(w["patient_id"])
            last = clean(w.get("last_checkin_at")) or clean(w.get("started_at"))
            try:
                age_min = (datetime.now() - datetime.fromisoformat(last)).total_seconds() / 60.0
            except Exception:
                age_min = 9999
            if age_min > 15:
                with self.lock:
                    self.raise_safety_alert(pid, "inactivity", "warning", f"No check-in for {int(age_min)} minutes during active walk.", "system")
            # latest ping freshness / battery / geofence / unexpected movement
            ping = self.store.conn.execute("SELECT * FROM patient_location_pings WHERE patient_id=? ORDER BY id DESC LIMIT 1", (pid,)).fetchone()
            if ping:
                try:
                    page = (datetime.now() - datetime.fromisoformat(clean(ping["created_at"]))).total_seconds() / 60.0
                except Exception:
                    page = 9999
                if page > 10:
                    with self.lock:
                        self.raise_safety_alert(pid, "gps_loss", "warning", f"No GPS update for {int(page)} minutes.", "system")
                bat = ping["battery_pct"]
                if bat is not None and float(bat) < 20:
                    with self.lock:
                        self.raise_safety_alert(pid, "low_battery", "warning", f"Device battery at {float(bat):.0f}%.", "system")
                # unexpected movement: two pings <2min apart covering >150m
                prev = self.store.conn.execute("SELECT * FROM patient_location_pings WHERE patient_id=? AND id<? ORDER BY id DESC LIMIT 1", (pid, int(ping["id"]))).fetchone()
                if prev:
                    try:
                        dt = (datetime.fromisoformat(clean(ping["created_at"])) - datetime.fromisoformat(clean(prev["created_at"]))).total_seconds()
                        dist = self._haversine_m(float(ping["latitude"]), float(ping["longitude"]), float(prev["latitude"]), float(prev["longitude"]))
                        if 0 < dt < 120 and dist > 150:
                            with self.lock:
                                self.raise_safety_alert(pid, "unexpected_movement", "warning", f"Position jumped {int(dist)}m in {int(dt)}s.", "system")
                    except Exception:
                        pass
                g = self._geofence_check(pid, float(ping["latitude"]), float(ping["longitude"]))
                if g:
                    with self.lock:
                        self.raise_safety_alert(pid, g, "warning", f"Outside designated safe area at {ping['latitude']},{ping['longitude']}.", "system")

    def _safety_loop(self):
        # Run an immediate tick on startup so overdue escalations are not delayed
        # by up to 60s after a restart (durability across restarts).
        # The tick does not run under the global lock: it takes the lock once per
        # alert it raises (see safety_monitor_tick), so a request waits for one
        # alert at most, never for the whole sweep.
        try:
            self.safety_monitor_tick()
        except Exception as exc:
            print(f"[NAVIQ safety monitor] {exc}")
        while not self._safety_stop.wait(60):
            try:
                self.safety_monitor_tick()
            except Exception as exc:
                print(f"[NAVIQ safety monitor] {exc}")

    def _av_loop(self):
        # First sweep 5 minutes after startup, then every 6 hours.
        # freshclam refreshes definitions on each cycle (it no-ops when current).
        self._av_stop.wait(300)
        freshclam = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "ClamAV" / "freshclam.exe"
        freshclam_conf = security_suite.CLAMAV_WORK / "freshclam.conf"
        while not self._av_stop.is_set():
            try:
                if freshclam.is_file() and freshclam_conf.is_file():
                    subprocess.run([str(freshclam), f"--config-file={freshclam_conf}"],
                                   capture_output=True, timeout=300,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                if security_suite.clamav_ready():
                    security_suite.scan_data_home()
            except Exception as exc:
                print(f"[ClamAV scheduled scan] {exc}")
            self._av_stop.wait(6 * 3600)

    def patient_state(self, patient_id):
        ping = self.store.conn.execute("SELECT * FROM patient_location_pings WHERE patient_id=? ORDER BY id DESC LIMIT 1", (int(patient_id),)).fetchone()
        walk = self.store.conn.execute("SELECT * FROM patient_walks WHERE patient_id=? AND status='Active' ORDER BY id DESC LIMIT 1", (int(patient_id),)).fetchone()
        open_alerts = self.query("SELECT COUNT(*) AS c FROM safety_alerts WHERE patient_id=? AND status IN ('Open','Escalated')", (int(patient_id),))
        vit = self.store.conn.execute("SELECT * FROM patient_vitals WHERE patient_id=? ORDER BY id DESC LIMIT 1", (int(patient_id),)).fetchone()
        state = {"last_ping": dict(ping) if ping else None, "active_walk": dict(walk) if walk else None,
                 "open_alerts": int(open_alerts[0]["c"]) if open_alerts else 0,
                 "latest_vitals": dict(vit) if vit else None}
        if not ping and not walk:
            state["connection"] = "No data"
            state["connection_detail"] = "No location has ever been reported."
        else:
            ref = ping["created_at"] if ping else (walk["last_checkin_at"] or walk["started_at"] if walk else "")
            try:
                age = (datetime.now() - datetime.fromisoformat(clean(ref))).total_seconds() / 60.0
            except Exception:
                age = 9999
            state["minutes_since_update"] = round(age, 1)
            if walk and age <= 2:
                state["connection"] = "Connected"
                state["connection_detail"] = "Live location is fresh."
            elif walk and age <= 15:
                state["connection"] = "Location update delayed"
                state["connection_detail"] = f"Last update {int(age)} min ago — not confirmed current."
            elif walk:
                state["connection"] = "Device offline / stale"
                state["connection_detail"] = f"Last update {int(age)} min ago — position may be wrong."
            else:
                state["connection"] = "Idle"
                state["connection_detail"] = f"No active outing. Last known {int(age)} min ago."
        return state

    def patient_document_upload(self, patient_id, data, actor):
        self._patient_row(patient_id)
        title = clean(data.get("title")); doc_type = clean(data.get("document_type")) or "Other"
        filename = Path(clean(data.get("filename")) or "document.bin").name
        mime = clean(data.get("mime_type")) or "application/octet-stream"
        encoded = data.get("data")
        if not title or not isinstance(encoded, str):
            raise ValueError("Document title and file are required.")
        try:
            content = base64.b64decode(encoded.split(",", 1)[-1], validate=True)
        except Exception as exc:
            raise ValueError("Document data could not be decoded.") from exc
        if not content or len(content) > 20 * 1024 * 1024:
            raise ValueError("Document is empty or exceeds the 20 MB limit.")
        self.scan_or_reject(content, filename, actor)
        stamp = iso_now()
        cur = self.store.conn.execute(
            "INSERT INTO patient_documents(patient_id,title,document_type,file_name,mime_type,content,uploaded_by,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (int(patient_id), title, doc_type, filename, mime, content, actor, stamp))
        did = int(cur.lastrowid)
        self.store.log(actor, "Uploaded patient emergency document", "patient_document", did, f"Patient {patient_id}: {title}")
        self.store.conn.commit()
        return {"id": did, "status": "stored"}

    def payslip_pdf(self, payroll_id: int) -> tuple[bytes, str]:
        row=self.store.conn.execute("SELECT p.*,e.employee_no,e.first_name,e.last_name,e.job_title,e.department,e.id_number,e.whatsapp_number AS contact_number FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE p.id=?",(payroll_id,)).fetchone()
        if not row: raise KeyError("Payslip record not found.")
        if clean(row["status"]).lower() not in ("draft", "drafted", "approved", "sent", "paid"):
            raise ValueError("This payroll record is not eligible for a payslip.")
        try:
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import mm
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        except ImportError as exc:
            raise RuntimeError("PDF support is missing. Install the requirements in this package.") from exc
        number=clean(row["payslip_number"]) or f"BR-{row['pay_period'].replace('-', '')}-{int(row['id']):05d}"
        if not clean(row["payslip_number"]):
            self.store.conn.execute("UPDATE payroll_records SET payslip_number=? WHERE id=?",(number,payroll_id)); self.store.conn.commit()
        buff=BytesIO(); doc=SimpleDocTemplate(buff,pagesize=landscape(A4),rightMargin=10*mm,leftMargin=10*mm,topMargin=5*mm,bottomMargin=5*mm)
        styles=getSampleStyleSheet(); styles.add(ParagraphStyle(name="BRTitle",parent=styles["Title"],textColor=colors.HexColor("#102b4e"),fontSize=18,spaceAfter=2)); styles.add(ParagraphStyle(name="BRSub",parent=styles["Normal"],textColor=colors.HexColor("#54708e"),fontSize=9))
        story=[Paragraph("BEYOND REGISTRATION",styles["BRTitle"]),Paragraph("CONFIDENTIAL EMPLOYEE PAYSLIP",styles["BRSub"]),Spacer(1,2*mm)]
        def money(v): return f"R {float(v or 0):,.2f}"
        info=[["Payslip number",number,"Pay period",clean(row["pay_period"])],["Employee",f"{row['first_name']} {row['last_name']}","Employee number",clean(row["employee_no"])],["Job title",clean(row["job_title"]),"Department",clean(row["department"])],["Payment date",clean(row["pay_date"]),"Frequency","Monthly"],["Status",clean(row["status"]),"ID / passport",("••••••"+clean(row["id_number"])[-4:]) if clean(row["id_number"]) else "Not supplied"]]
        t=Table(info,colWidths=[42*mm,94.5*mm,42*mm,94.5*mm]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#f1f5fa")),("TEXTCOLOR",(0,0),(0,-1),colors.HexColor("#36506d")),("TEXTCOLOR",(2,0),(2,-1),colors.HexColor("#36506d")),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("FONTNAME",(2,0),(2,-1),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),.35,colors.HexColor("#d7e1ec")),("PADDING",(0,0),(-1,-1),4)])); story += [t,Spacer(1,2*mm)]
        earnings=[["EARNINGS","AMOUNT"],["Basic salary",money(row["basic_salary"])],["Overtime",money(row["overtime"])],["Approved allowances",money(row["allowances"])],["Bonus",money(row["bonus"])],["Gross earnings",money(row["gross_pay"])]]
        deduction_reason=clean(row["notes"])
        if float(row["other_deductions"] or 0) > 0:
            reason_text=(f"Other authorised deductions<br/><font size='8' color='#54708e'>Reason: {__import__('xml.sax.saxutils', fromlist=['escape']).escape(deduction_reason)}</font>" if deduction_reason else "Other authorised deductions<br/><font size='8' color='#9b3b32'>Reason: Not provided — please update the payroll notes.</font>")
        else:
            reason_text="Other authorised deductions"
        deductions=[["EMPLOYEE DEDUCTIONS","AMOUNT"],["UIF — employee contribution",money(row["uif"])],[Paragraph(reason_text,styles["Normal"]),money(row["other_deductions"])],["Total deductions",money(row["total_deductions"])],["NET SALARY PAYABLE",money(row["net_pay"])]]
        for data in (earnings,deductions):
            tb=Table(data,colWidths=[225*mm,48*mm]); tb.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#102b4e")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTNAME",(0,-1),(-1,-1),"Helvetica-Bold"),("BACKGROUND",(0,-1),(-1,-1),colors.HexColor("#eaf3fb")),("ALIGN",(1,0),(1,-1),"RIGHT"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("GRID",(0,0),(-1,-1),.35,colors.HexColor("#d7e1ec")),("FONTSIZE",(0,0),(-1,-1),9),("PADDING",(0,0),(-1,-1),4)])); story += [tb,Spacer(1,3*mm)]
        employer=float(row["employer_uif"] or 0)
        story += [Paragraph(f"Employer contributions (not deducted from employee pay): UIF paid by employer — {money(employer)}",styles["Normal"]),Spacer(1,2*mm)]
        # Cumulative totals are bounded to the employee's current active contract where one exists.
        contract=self.store.conn.execute("SELECT start_date,end_date,title FROM employee_contracts WHERE employee_id=? AND lower(status)='active' ORDER BY COALESCE(start_date,'') DESC,id DESC LIMIT 1",(int(row["employee_id"]),)).fetchone()
        contract_start=clean(contract["start_date"]) if contract else ""
        if contract_start:
            try:
                first_period=datetime.strptime(contract_start[:10],"%Y-%m-%d").strftime("%Y-%m")
            except ValueError:
                first_period=""
        else:
            first_period=""
        if first_period:
            totals=self.store.conn.execute("SELECT COALESCE(SUM(gross_pay),0) gross,COALESCE(SUM(uif),0) employee_uif,COALESCE(SUM(employer_uif),0) employer_uif,COALESCE(SUM(total_deductions),0) deductions,COALESCE(SUM(net_pay),0) net,COUNT(*) periods FROM payroll_records WHERE employee_id=? AND pay_period>=? AND pay_period<=? AND lower(status) IN ('approved','sent','paid')",(int(row["employee_id"]),first_period,clean(row["pay_period"]))).fetchone()
            period_label=f"Current contract from {contract_start[:10]}"
        else:
            totals=self.store.conn.execute("SELECT COALESCE(SUM(gross_pay),0) gross,COALESCE(SUM(uif),0) employee_uif,COALESCE(SUM(employer_uif),0) employer_uif,COALESCE(SUM(total_deductions),0) deductions,COALESCE(SUM(net_pay),0) net,COUNT(*) periods FROM payroll_records WHERE employee_id=? AND pay_period<=? AND lower(status) IN ('approved','sent','paid')",(int(row["employee_id"]),clean(row["pay_period"]))).fetchone()
            period_label="Cumulative totals from recorded approved payroll; no active contract start date is on file"
        cumulative=Table([[Paragraph("PAY TO DATE",styles["BRSub"]),""],[Paragraph(period_label,styles["BRSub"]),""] , ["Gross earnings to date",money(totals["gross"])],["Employee UIF to date",money(totals["employee_uif"])],["Employer UIF to date",money(totals["employer_uif"])],["Total deductions to date",money(totals["deductions"])],["Net salary paid to date",money(totals["net"])]],colWidths=[225*mm,48*mm])
        cumulative.setStyle(TableStyle([("SPAN",(0,0),(-1,0)),("SPAN",(0,1),(-1,1)),("BACKGROUND",(0,0),(-1,1),colors.HexColor("#edf3f8")),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("ALIGN",(1,2),(1,-1),"RIGHT"),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),.3,colors.HexColor("#d7e1ec")),("PADDING",(0,0),(-1,-1),3)]))
        story += [cumulative,Spacer(1,2*mm),Paragraph("Company registration: 2026721121",styles["BRSub"]),Paragraph("This payslip is confidential. Please contact the payroll administrator if you believe any information is incorrect.",styles["BRSub"])]
        doc.build(story); return buff.getvalue(),number

    def hub_messages(self, limit: int = 200):
        rows=self.store.conn.execute("SELECT id,sender,recipient_label,employee_id,department,subject,body,payroll_id,attachment_name,attachment_mime,CASE WHEN attachment_data IS NULL THEN 0 ELSE 1 END has_attachment,created_at,read_at FROM hub_messages ORDER BY id DESC LIMIT ?",(int(limit),)).fetchall()
        return [dict(r) for r in rows]

    def hub_recipients(self):
        rows=self.store.conn.execute("SELECT id,employee_no,first_name,last_name,job_title,department,employment_status FROM employees ORDER BY department,first_name,last_name").fetchall()
        return [dict(r) for r in rows]

    def hub_send(self, data: dict, actor: str):
        subject=clean(data.get("subject")); body=clean(data.get("body"))
        if not subject or not body: raise ValueError("Subject and message are required.")
        employee_id=data.get("employee_id"); department=clean(data.get("department")); payroll_id=data.get("payroll_id")
        attachment=None
        if payroll_id:
            pid=int(payroll_id)
            prow=self.store.conn.execute("SELECT p.id,p.employee_id FROM payroll_records p WHERE p.id=?",(pid,)).fetchone()
            if not prow: raise KeyError("Payroll record not found.")
            if employee_id and int(prow["employee_id"])!=int(employee_id): raise ValueError("The selected payslip belongs to a different employee.")
            if not employee_id: employee_id=int(prow["employee_id"])
            pdf,payslip_number=self.payslip_pdf(pid)
            attachment=(pdf,"application/pdf",f"{payslip_number}.pdf")
        if employee_id:
            emp=self.store.conn.execute("SELECT id,employee_no,first_name,last_name,department FROM employees WHERE id=?",(int(employee_id),)).fetchone()
            if not emp: raise KeyError("Employee not found.")
            if not department: department=clean(emp["department"])
            targets=[(int(emp["id"]),clean(emp["department"]) or department,f"{clean(emp['first_name'])} {clean(emp['last_name'])}".strip() or clean(emp["employee_no"]))]
        elif department and department.strip().upper() in ("ALL EMPLOYEES","COMPANY-WIDE","ALL"):
            rows=self.store.conn.execute("SELECT id,employee_no,first_name,last_name,department FROM employees WHERE employment_status='Active'").fetchall()
            if not rows: raise ValueError("There are no active employees to message.")
            targets=[(int(r["id"]),clean(r["department"]),f"{clean(r['first_name'])} {clean(r['last_name'])}".strip() or clean(r["employee_no"])) for r in rows]
        elif department:
            targets=[(None,department,f"Department: {department}")]
        else:
            raise ValueError("Choose an employee or a department recipient.")
        stamp=iso_now(); mids=[]
        for tid,tdept,tlabel in targets:
            cur=self.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,payroll_id,attachment_name,attachment_mime,attachment_data,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(actor,tlabel,tid,tdept or None,subject[:200],body[:20000],int(payroll_id) if payroll_id else None,attachment[2] if attachment else None,attachment[1] if attachment else None,attachment[0] if attachment else None,stamp))
            mids.append(int(cur.lastrowid))
        self.store.conn.commit()
        self.store.log(actor,"Sent Communication Hub message","communications",str(mids[0]),f"{targets[0][2]} (+{len(mids)-1} more): {subject[:80]}" if len(mids)>1 else f"{targets[0][2]}: {subject[:80]}")
        return {"id":mids[0],"recipient":targets[0][2],"recipients":len(mids),"attachment":attachment[2] if attachment else None,"created_at":stamp}

    def hub_attachment(self, message_id: int):
        row=self.store.conn.execute("SELECT attachment_name,attachment_mime,attachment_data FROM hub_messages WHERE id=?",(int(message_id),)).fetchone()
        if not row or row["attachment_data"] is None: raise KeyError("Attachment not found.")
        return bytes(row["attachment_data"]), clean(row["attachment_name"]) or "attachment", clean(row["attachment_mime"]) or "application/octet-stream"

    def api_vision(self, prompt: str, actor: str = "administrator", history=None, attachments=None):
        base=self.config.get("vision_server_url","").rstrip("/")
        if not base:
            if attachments:
                raise ValueError("Attachments require a configured Vision service URL; the local assistant accepts text only.")
            return self.api_vision_ollama(prompt, actor, history)
        url=base+"/api/chat"
        if not prompt.strip(): raise ValueError("Enter a question for Vision first.")
        # Reuse the original application's privacy-conscious, read-only business snapshot.
        # This includes aggregate counts and department summaries, not employee ID numbers,
        # contact details, medical notes or individual payroll amounts.
        from types import SimpleNamespace
        context=legacy.App._vision_business_context(SimpleNamespace(store=self.store,actor=actor))
        contextual_prompt=prompt+"\n\nVISION UI NAVIGATION CAPABILITY: When the user explicitly asks you to open a screen, you may append exactly one action token at the very end of your reply. Supported tokens: [[AI_ACTION:NAVIGATE_UI|dashboard]], [[AI_ACTION:NAVIGATE_UI|employees]], [[AI_ACTION:NAVIGATE_UI|staff_profile|EMPLOYEE_NUMBER_OR_ID]], [[AI_ACTION:NAVIGATE_UI|leave]], [[AI_ACTION:NAVIGATE_UI|attendance]], [[AI_ACTION:NAVIGATE_UI|contracts]], [[AI_ACTION:NAVIGATE_UI|documents]], [[AI_ACTION:NAVIGATE_UI|reviews]], [[AI_ACTION:NAVIGATE_UI|payroll]], [[AI_ACTION:NAVIGATE_UI|reports]], [[AI_ACTION:NAVIGATE_UI|audit]], [[AI_ACTION:NAVIGATE_UI|communications]], [[AI_ACTION:NAVIGATE_UI|settings]]. Do not emit action tokens unless the user asked to navigate. Do not claim a screen was opened unless the action token is included. Never use this mechanism to create, edit, delete, send, approve, or pay records.\n\n--- APPROVED BEYOND REGISTRATION BUSINESS SNAPSHOT (READ-ONLY) ---\n"+json.dumps(context,ensure_ascii=False,default=str)[:24000]+"\n--- END BUSINESS SNAPSHOT ---"
        messages=[]
        if isinstance(history,list):
            for item in history[-10:]:
                if isinstance(item,dict) and item.get("role") in ("user","assistant"):
                    content=clean(item.get("content"))[:12000]
                    if content: messages.append({"role":item["role"],"content":content})
        if not messages or messages[-1].get("role")!="user": messages.append({"role":"user","content":contextual_prompt[:30000]})
        else: messages[-1]["content"]=contextual_prompt[:30000]
        safe_attachments=[]
        allowed_text={".txt":"text/plain",".md":"text/plain",".csv":"text/csv",".json":"application/json"}
        allowed_binary={".pdf":"application/pdf",".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",".webp":"image/webp"}
        total_bytes=0
        if attachments is not None:
            if not isinstance(attachments,list): raise ValueError("Vision attachments must be a list of files.")
            if len(attachments)>4: raise ValueError("You can attach up to 4 files to a Vision message.")
            for item in attachments:
                if not isinstance(item,dict): raise ValueError("An uploaded Vision attachment is invalid.")
                name=clean(item.get("name")).replace("\\","/").split("/")[-1][:120]
                ext=Path(name).suffix.lower()
                if ext in allowed_text:
                    content=item.get("textContent")
                    if not isinstance(content,str): raise ValueError(f"{name or 'Text file'} does not contain readable text.")
                    raw_text=content[:45000]
                    size=len(raw_text.encode("utf-8"))
                    total_bytes+=size
                    safe_attachments.append({"name":name or "attachment"+ext,"mimeType":allowed_text[ext],"textContent":raw_text})
                elif ext in allowed_binary:
                    encoded=item.get("base64Data")
                    if not isinstance(encoded,str) or not encoded: raise ValueError(f"{name or 'Attachment'} could not be read.")
                    try: raw_file=base64.b64decode(encoded,validate=True)
                    except Exception as exc: raise ValueError(f"{name or 'Attachment'} is not valid base64 data.") from exc
                    if len(raw_file)>6*1024*1024: raise ValueError(f"{name} is larger than the 6 MB per-file limit.")
                    SERVICE.scan_or_reject(raw_file, name or "attachment"+ext, actor)
                    total_bytes+=len(raw_file)
                    safe_attachments.append({"name":name or "attachment"+ext,"mimeType":allowed_binary[ext],"base64Data":encoded})
                else:
                    raise ValueError(f"Unsupported Vision attachment type: {ext or 'unknown'}. Use PDF, TXT, MD, CSV, JSON, PNG, JPG or WEBP.")
                if total_bytes>8*1024*1024: raise ValueError("Vision attachments must total 8 MB or less.")
        payload=json.dumps({"prompt":contextual_prompt[:30000],"messages":messages,"attachments":safe_attachments},ensure_ascii=False).encode()
        headers={"Content-Type":"application/json","Accept":"application/json","User-Agent":"BeyondRegistration/5.0"}
        token=os.environ.get("VISION_ACCESS_TOKEN","").strip()
        if token: headers["Authorization"]="Bearer "+token
        req=urllib.request.Request(url,data=payload,headers=headers,method="POST")
        try:
            with urllib.request.urlopen(req,timeout=60) as response:
                raw=response.read().decode("utf-8",errors="replace")
                ctype=response.headers.get("Content-Type","")
                if "json" not in ctype.lower():
                    raise RuntimeError(f"Vision endpoint returned HTTP {response.status} {ctype}. The app needs a published JSON API endpoint, not an AI Studio preview page. Response: {raw[:500]}")
                data=json.loads(raw)
        except urllib.error.HTTPError as exc:
            raw=exc.read().decode("utf-8",errors="replace")[:500]
            raise RuntimeError(f"Vision returned HTTP {exc.code}: {raw}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Could not reach Vision service: {exc.reason}") from exc
        reply=""
        for key in ("reply","response","answer","message","content","text"):
            if isinstance(data,dict) and data.get(key):
                val=data[key]
                reply=val if isinstance(val,str) else json.dumps(val,ensure_ascii=False)
                break
        if not reply: reply=json.dumps(data,ensure_ascii=False)
        return {"reply":reply,"raw":data}

    def api_vision_ollama(self, prompt: str, actor: str = "administrator", history=None):
        """Local-first AI path: Ollama on 127.0.0.1:11434 (zero-cost, offline)."""
        if not prompt.strip(): raise ValueError("Enter a question for the assistant first.")
        from types import SimpleNamespace
        context=legacy.App._vision_business_context(SimpleNamespace(store=self.store,actor=actor))
        contextual_prompt=prompt+"\n\n--- APPROVED BEYOND REGISTRATION BUSINESS SNAPSHOT (READ-ONLY) ---\n"+json.dumps(context,ensure_ascii=False,default=str)[:24000]+"\n--- END BUSINESS SNAPSHOT ---"
        messages=[]
        if isinstance(history,list):
            for item in history[-10:]:
                if isinstance(item,dict) and item.get("role") in ("user","assistant"):
                    content=clean(item.get("content"))[:12000]
                    if content: messages.append({"role":item["role"],"content":content})
        messages.append({"role":"user","content":contextual_prompt[:30000]})
        host, model, chosen = self._local_model_config()
        if not model:
            # No installed model fits free RAM (or Ollama is down): say so plainly
            # rather than issuing a request that would page the laptop for minutes.
            raise RuntimeError(chosen.get("reason") or "No local model is available on this PC.")
        result = _call_without_db_lock(cortex_local.chat, messages, model, host=host, timeout=180,
                                       num_ctx=chosen.get("num_ctx"), num_predict=900)
        reply = result["reply"]
        if not reply:
            raise RuntimeError("The local model returned an empty response. Try a shorter question.")
        return {"reply": reply, "model": model, "ms": result["ms"],
                "context_used": len(contextual_prompt)}


def _read_app_version(default: str = "5.6.0-BENTO-CREAM-VOIC3-CALLS-OWNER-TEST") -> str:
    """One version for the whole system: the repository's VERSION.txt.

    The server, the APK (android-honor/app/build.gradle) and the reports all
    read this file, so support never has to guess which build a phone is on.
    """
    try:
        text = (Path(__file__).resolve().parent.parent / "VERSION.txt").read_text(encoding="utf-8").strip()
        return text or default
    except OSError:
        return default


APP_VERSION = _read_app_version()

def _role_payload(profile):
    """The role block the phone uses to choose its tabs. Never raises."""
    try:
        import roles as _roles
        r = _roles.describe(profile)
        return {"role": r["role"], "role_label": r["label"], "home_tab": r["home"],
                "tabs": r["tabs"], "can": r["can"]}
    except Exception:
        return {"role": "representative", "role_label": "Representative",
                "home_tab": "home", "tabs": ["home", "settings"], "can": []}


SIGN_IN_WAIT_SECONDS = float(os.environ.get("BR_SIGNIN_WAIT", "3"))


def _sign_in_row(load):
    """Run a sign-in read without queueing behind a long write.

    Signing in only reads one row (admins, or employees JOIN mobile_accounts).
    Those rows are already in memory, but the global lock may be held by a
    background cycle, and waiting out the full BR_LOCK_WAIT is what turns a
    busy server into a 503 on the sign-in screen. So: take the lock if it is
    free within a few seconds, and if it is not, read anyway. The worst case is
    comparing one password hash from a moment ago - the person simply tries
    again - which is far better than refusing everyone who signs in during a
    scan.
    """
    lock = getattr(SERVICE, "lock", None)
    held = False
    if lock is not None:
        try:
            held = lock.acquire(timeout=SIGN_IN_WAIT_SECONDS)
        except Exception:
            held = False
        if not held:
            print("[BR lock] sign-in answered without the data lock (held by "
                  f"{getattr(SERVICE, '_lock_holder', None) or 'a background cycle'})", flush=True)
    try:
        return load()
    finally:
        if held:
            lock.release()


LOCK_WAIT_SECONDS = float(os.environ.get("BR_LOCK_WAIT", "90"))


def _call_without_db_lock(fn, *args, **kwargs):
    """Run a slow call that never touches the database with SERVICE.lock released.

    Every API request runs inside SERVICE.lock (see Handler._handle). A local AI
    answer can take minutes on an 8 GB laptop; holding the lock that long makes
    every phone (SOS, check-ins, call signalling) wait and then get 503. The
    caller must build everything it needs from the database BEFORE calling this
    and must not touch SERVICE.store inside ``fn``.
    """
    lock = getattr(SERVICE, "lock", None)
    released = 0
    if lock is not None:
        while True:
            try:
                lock.release()
            except RuntimeError:
                break  # not (or no longer) held by this thread
            released += 1
    try:
        return fn(*args, **kwargs)
    finally:
        for _ in range(released):
            lock.acquire()


def _is_local_host(host):
    """True for this machine's own LAN, loopback or mDNS names."""
    host = (host or "").strip().lower()
    if not host:
        return True
    if host in ("localhost", "127.0.0.1", "::1") or host.endswith(".local"):
        return True
    import ipaddress
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        return False


SERVICE = AppService()

# ---- VOIC3 SSE event bus (in-memory, thread-safe, $0) ----
_VOIC3_STREAMS = {}
_VOIC3_STREAMS_LOCK = threading.Lock()

def publish_voic3_event(employee_ids, event_type, payload):
    if not employee_ids:
        return
    ids = employee_ids if isinstance(employee_ids, (list, tuple, set)) else [employee_ids]
    with _VOIC3_STREAMS_LOCK:
        for eid in ids:
            for q in list(_VOIC3_STREAMS.get(eid, [])):
                try:
                    q.put_nowait((event_type, payload))
                except Exception:
                    pass


def voic3_connected(employee_id):
    """True when the employee currently holds an open VOIC3 event stream."""
    try:
        with _VOIC3_STREAMS_LOCK:
            return bool(_VOIC3_STREAMS.get(int(employee_id)))
    except Exception:
        return False


def notify_voic3_offline(employee_ids, payload, active_ids=None):
    """Section 12: Web Push to employees with no open event stream.

    Called after ``publish_voic3_event`` so in-app clients always win and only
    backgrounded devices get a push. Never raises; a no-op without VAPID keys.
    """
    try:
        ids = employee_ids if isinstance(employee_ids, (list, tuple, set)) else [employee_ids]
        ids = [int(x) for x in ids if x]
        if not ids:
            return
        offline = [eid for eid in ids if not voic3_connected(eid)]
        if not offline:
            return
        voic3_push.notify_user(SERVICE.store.conn, offline, payload, active_ids=active_ids)
    except Exception:
        pass

SERVICE.load_sessions()

def _tunnel_hostname():
    """The hostname of the cloudflared tunnel running right now, or "".

    cloudflared exposes its own quick-tunnel hostname on 127.0.0.1:20241 while it
    runs. Reading that is exact; reading tunnel.log is not, because the log keeps
    the name of a tunnel that may already have exited.
    """
    import json as _json
    import urllib.request as _ur
    try:
        with _ur.urlopen("http://127.0.0.1:20241/quicktunnel", timeout=2) as r:
            return str(_json.loads(r.read().decode()).get("hostname") or "")
    except Exception:
        return ""


def _read_env_value(name):
    """One setting from the environment, else from desktop/tools/.env, else desktop/.env.

    The launcher exports what it needs, but a server started another way (a console,
    the IDE, a test) would otherwise serve STUN only. Reading the file keeps the
    answer the same however N3XUS was started.
    """
    value = os.environ.get(name, "").strip()
    if value:
        return value
    here = Path(__file__).resolve().parent
    for candidate in (here / "tools" / ".env", here / ".env"):
        try:
            if not candidate.is_file():
                continue
            for line in candidate.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, raw = line.partition("=")
                if key.strip() == name:
                    return raw.strip().strip('"').strip("'")
        except Exception:
            continue
    return ""


# A working relay answer is reused for ten minutes: calls start instantly, but a
# rotation of the Metered credentials is still picked up well inside its own hour.
_METERED_CACHE = {"at": 0.0, "servers": None}
_METERED_TTL = 600.0


def _metered_ice_servers():
    """Fresh TURN + STUN servers from Metered's free relay, or [] if not set up.

    Metered hands out short-lived credentials over HTTPS with the account's API key,
    so nothing static is stored on the phone and there is never a secret in the app.
    Cost is zero: the free tier covers the calls this business makes.
    """
    domain = _read_env_value("METERED_DOMAIN")
    key = _read_env_value("METERED_API_KEY")
    if not domain or not key:
        return []
    now = time.time()
    cached = _METERED_CACHE.get("servers")
    if cached and (now - float(_METERED_CACHE.get("at") or 0)) < _METERED_TTL:
        return list(cached)
    host = domain.replace("https://", "").replace("http://", "").strip("/")
    url = "https://%s/api/v1/turn/credentials?apiKey=%s" % (host, urllib.parse.quote(key, safe=""))
    try:
        with urllib.request.urlopen(url, timeout=6) as response:
            raw = json.loads(response.read().decode("utf-8", "replace"))
    except Exception:
        # Keep whatever we had; an empty list still leaves the local relay in play.
        return list(cached or [])
    servers = []
    if isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict):
                continue
            urls = item.get("urls") or item.get("url")
            if not urls:
                continue
            if isinstance(urls, str):
                urls = [urls]
            entry = {"urls": [str(u) for u in urls if u]}
            if item.get("username"):
                entry["username"] = str(item["username"])
            if item.get("credential"):
                entry["credential"] = str(item["credential"])
            if entry["urls"]:
                servers.append(entry)
    if servers:
        _METERED_CACHE["at"] = now
        _METERED_CACHE["servers"] = servers
    return servers


def _openrelay_ice_servers():
    """Metered's free public OpenRelay TURN, needing no account at all.

    Free forever, no sign-up, no key: the credentials are the public
    YOUR_RELAY_USER/YOUR_RELAY_USER pair. A relay is the only thing that makes a
    4G-to-Wi-Fi call work when the carrier blocks the inbound path, so these come
    before any STUN. Kept in code (they are public, not secrets) so the owner never
    has to edit .env or sign up for anything.
    """
    # The old "openrelay.metered.ca" name now resolves to documentation addresses
    # (192.0.2.1), so it relays nothing. The static-auth relay is the live one and
    # takes the same public Open Relay secret.
    return [
        {"urls": ["turn:staticauth.openrelay.metered.ca:80?transport=udp"],
         "username": "n3xus", "credential": "YOUR_RELAY_SHARED_SECRET"},
        {"urls": ["turn:staticauth.openrelay.metered.ca:443?transport=tcp"],
         "username": "n3xus", "credential": "YOUR_RELAY_SHARED_SECRET"},
        {"urls": ["turns:staticauth.openrelay.metered.ca:443?transport=tcp"],
         "username": "n3xus", "credential": "YOUR_RELAY_SHARED_SECRET"},
    ]


def _public_ice_servers():
    """STUN that costs nothing and needs no account, as the floor of every answer."""
    servers = [{"urls": ["stun:stun.l.google.com:19302"]},
               {"urls": ["stun:stun.cloudflare.com:3478"]}]
    metered = _metered_ice_servers()
    # A private Metered account (if one is ever pasted in) wins; otherwise the free
    # public OpenRelay relay is used, so 4G calls work out of the box.
    relay = metered or _openrelay_ice_servers()
    if relay:
        servers = relay + servers
    return servers


def _local_turn_ice_list(servers):
    """Prepend this PC's coturn relay (start-n3xus.bat exports VOIC3_TURN_*).

    The app's iceServers() takes the FIRST non-empty answer from
    /api/voic3/ice-servers, so the local relay has to be on those lists:
    when the public OpenRelay went dark, 4G/5G calls had no path at all.
    Same HMAC time-limited credentials as /api/voic3/ice-config, so no
    static password ever leaves the server. List unchanged if not configured.
    """
    turn_url = (os.environ.get("VOIC3_TURN_URL", "").strip()
                or os.environ.get("VOIC3_TURN_LOCAL", "").strip())
    turn_secret = (os.environ.get("VOIC3_TURN_SECRET", "").strip()
                   or os.environ.get("VOIC3_TURN_LOCAL_SECRET", "").strip())
    if not (turn_url and turn_secret):
        return list(servers)
    import hmac as _hmac, hashlib as _hashlib, base64 as _base64
    turn_urls = [u.strip() for u in turn_url.split(",") if u.strip()]
    ttl = 12 * 3600
    username = str(int(time.time()) + ttl)
    password = _base64.b64encode(_hmac.new(turn_secret.encode(), username.encode(), _hashlib.sha1).digest()).decode()
    entry = {"urls": turn_urls, "username": username, "credential": password}
    if entry in servers:
        return list(servers)
    return [entry] + list(servers)


def _tunnel_alive():
    """True while the free cloudflared tunnel is actually serving.

    Checked by asking the tunnel's own metrics port, which cloudflared opens on
    127.0.0.1:20241 while it runs. A subprocess call (tasklist) was tried first and
    hangs on this machine, which made the endpoint fail instead of answering.
    """
    import socket as _sock
    try:
        with _sock.create_connection(("127.0.0.1", 20241), timeout=1.5):
            return True
    except Exception:
        return False


class Handler(BaseHTTPRequestHandler):
    server_version = "BeyondRegistration/" + APP_VERSION
    def log_message(self, fmt, *args):
        # Keep routine local HTTP requests out of the console. Errors are logged by dispatch.
        pass

    def send_json(self, status: int, obj: dict, headers=None):
        payload=json.dumps(obj,ensure_ascii=False,default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(payload)))
        self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer")
        if headers:
            for k,v in headers.items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(payload)

    def get_sid(self):
        cookie=self.headers.get("Cookie","")
        m=re.search(r"(?:^|;\s*)br_session=([^;]+)",cookie)
        return m.group(1) if m else None

    def body(self):
        n=int(self.headers.get("Content-Length","0") or 0)
        if n>30*1024*1024: raise ValueError("Request body is too large.")
        # A stalled or oversized upload must never freeze the whole server.
        self.connection.settimeout(30)
        chunks=[]; remaining=n
        try:
            while remaining>0:
                chunk=self.rfile.read(min(65536,remaining))
                if not chunk: raise ValueError("Upload ended early.")
                chunks.append(chunk); remaining-=len(chunk)
        except (TimeoutError,socket.timeout):
            raise ValueError("Upload timed out. Try a shorter recording.")
        finally:
            try: self.connection.settimeout(None)
            except Exception: pass
        return parse_json(b"".join(chunks))

    def dispatch(self, method):
        parsed=urllib.parse.urlparse(self.path)
        path=urllib.parse.unquote(parsed.path)
        q=urllib.parse.parse_qs(parsed.query)
        data=self.body() if method in ("POST","PUT","PATCH","DELETE") else {k: v[0] for k, v in q.items()}
        if path == "/api/owner/reset-password" and method == "POST":
            # OWNER RESET, on this computer only. The database is held in RAM by the
            # running server, so no outside script can write it - the server must do
            # it itself. Accepted only from the loopback address, so it can never be
            # reached through the tunnel, and every reset is written to the log.
            peer = (self.client_address[0] if getattr(self, "client_address", None) else "") or ""
            if peer not in ("127.0.0.1", "::1", "localhost"):
                self.send_json(403, {"error": "Owner reset is only available on the server machine."}); return
            target = clean(data.get("password")) or "0000"
            stamp = iso_now()
            admins = [r["id"] for r in SERVICE.store.conn.execute("SELECT id FROM admins")]
            for admin_id in admins:
                SERVICE.store.conn.execute("UPDATE admins SET password_hash=? WHERE id=?",
                                           (legacy.hash_password(target), admin_id))
            mobile = [r["employee_id"] for r in SERVICE.store.conn.execute("SELECT employee_id FROM mobile_accounts")]
            for employee_id in mobile:
                SERVICE.store.conn.execute("UPDATE mobile_accounts SET password_hash=?, updated_at=? WHERE employee_id=?",
                                           (legacy.hash_password(target), stamp, employee_id))
            SERVICE.store.conn.commit()
            SERVICE.login_failures.clear()
            print(f"[OWNER RESET] {len(admins)} desktop and {len(mobile)} mobile passwords set from {peer}", flush=True)
            self.send_json(200, {"ok": True, "desktop": len(admins), "mobile": len(mobile)}); return
        if path=="/api/connect/where" and method=="GET":
            # The current public address of this server, so an installed app can find
            # it again after the free tunnel is restarted and gets a new name. Public
            # on purpose: it reveals only the address the caller could already reach.
            try:
                import re as _re
                log = (Path(__file__).resolve().parent / "tools" / "tunnel.log")
                url = ""
                # Ask the running tunnel for its own hostname first: the log can be
                # stale (an old tunnel that has since died), and a phone that follows
                # a dead address shows nothing at all.
                live = _tunnel_hostname()
                if live:
                    url = "https://" + live
                elif log.is_file():
                    found = _re.findall(r"https://[a-z0-9-]+\.trycloudflare\.com", log.read_text(errors="ignore"))
                    if found:
                        url = found[-1]
                # A tunnel name in the log means nothing once cloudflared has exited:
                # the address then answers 530 and a phone that follows it shows
                # nothing. Only advertise the tunnel while it is actually running.
                if url and not _tunnel_alive():
                    url = ""
                fwd_host = (self.headers.get("X-Forwarded-Host") or "").strip()
                fwd_proto = (self.headers.get("X-Forwarded-Proto") or "https").strip().lower()
                if fwd_host and not _is_local_host(fwd_host.split(":")[0]):
                    url = "%s://%s" % (fwd_proto, fwd_host)
                self.send_json(200, {"url": url, "mobile": (url + "/mobile/") if url else ""})
            except Exception as exc:
                self.send_json(503, {"error": "unavailable: %s" % exc})
            return
        if path=="/api/connect/qr" and method=="GET":
            # The LAN address as a scannable code. Public on purpose: it reveals
            # only this machine's own local address, and typing it is the alternative.
            try:
                import br_connect
                urls = getattr(SERVICE, "br_urls", None) or {}
                port = SERVICE.server_port if getattr(SERVICE, "server_port", None) else 64281
                # When the app is reached through a public tunnel, the code must
                # point at that public address, or a phone on mobile data would be
                # sent to a LAN address it cannot reach.
                fwd_host = (self.headers.get("X-Forwarded-Host") or self.headers.get("Host") or "").strip()
                fwd_proto = (self.headers.get("X-Forwarded-Proto") or "").strip().lower()
                target = None
                if fwd_host and not _is_local_host(fwd_host.split(":")[0]):
                    target = "%s://%s/mobile" % (fwd_proto or "https", fwd_host)
                target = target or urls.get("lan") or br_connect.lan_url(port)
                self.send_json(200, {"url": target, "svg": br_connect.qr_svg(target),
                                     "fingerprint": urls.get("fingerprint", "")})
            except Exception as exc:
                self.send_json(503, {"error": "QR unavailable: %s" % exc})
            return
        # Satellite SOS webhook: server-to-server, authenticated by shared secret only.
        if path=="/api/satellite/sos" and method=="POST":
            self.satellite_sos(data); return
        sid=self.get_sid(); actor=SERVICE.authenticated(sid)
        mobile_cookie=self.headers.get("Cookie", "")
        mm=re.search(r"(?:^|;\s*)br_mobile=([^;]+)", mobile_cookie)
        mobile_sid=mm.group(1) if mm else None
        mobile_eid=SERVICE.mobile_sessions.get(mobile_sid or "")
        if mobile_eid is not None:
            mexp = SERVICE.mobile_session_expiries.get(mobile_sid or "")
            if mexp is not None and mexp <= time.time():
                SERVICE.mobile_sessions.pop(mobile_sid, None)
                SERVICE.mobile_session_expiries.pop(mobile_sid, None)
                SERVICE.mobile_profiles.pop(mobile_sid, None)
                mobile_eid = None

        # ---- VOIC3 contacts (who you can call, meet or message) ----
        if path == "/api/voic3/contacts" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            qstr = clean(data.get("q") or "").lower()
            rows = SERVICE.query(
                "SELECT id,employee_no,first_name,last_name,job_title,department,employment_status "
                "FROM employees WHERE COALESCE(employment_status,'Active')='Active' ORDER BY first_name,last_name")
            presence = {}
            try:
                for p in SERVICE.query("SELECT employee_id,status FROM voic3_presence"):
                    presence[int(p["employee_id"])] = p["status"]
            except Exception:
                pass
            items = []
            for r in rows:
                name = (((r.get("first_name") or "") + " " + (r.get("last_name") or "")).strip()) or str(r.get("employee_no") or "")
                if qstr and qstr not in (name + " " + (r.get("department") or "") + " " + (r.get("job_title") or "") + " " + str(r.get("employee_no") or "")).lower():
                    continue
                items.append({"employee_id": int(r["id"]), "name": name,
                              "employee_no": r.get("employee_no") or "",
                              "job_title": r.get("job_title") or "",
                              "department": r.get("department") or "",
                              "is_me": int(r["id"]) == int(eid or 0),
                              "presence": presence.get(int(r["id"]), "offline")})
            self.send_json(200, {"items": items}); return

        # ---- VOIC3 calls for the desktop messenger ----
        # The phone already had a call API under /api/mobile/calls. The desktop
        # messenger uses the same tables and the same SSE events through these
        # routes, so a call started on a PC rings a phone and the other way round.
        if path == "/api/voic3/calls" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None:
                rows = SERVICE.query("SELECT id,caller_employee_id,callee_employee_id,call_type,status,created_at,answered_at,ended_at,ended_reason FROM voic3_calls ORDER BY id DESC LIMIT 60")
            else:
                rows = SERVICE.query("SELECT id,caller_employee_id,callee_employee_id,call_type,status,created_at,answered_at,ended_at,ended_reason FROM voic3_calls WHERE caller_employee_id=? OR callee_employee_id=? ORDER BY id DESC LIMIT 60", (int(eid), int(eid)))
            items = []
            for r in rows:
                r = dict(r)
                mine = int(r.get("caller_employee_id") or 0) == int(eid or 0)
                r["direction"] = "outgoing" if mine else "incoming"
                r["other_employee_id"] = int(r.get("callee_employee_id") or 0) if mine else int(r.get("caller_employee_id") or 0)
                try:
                    who = SERVICE.store.conn.execute("SELECT first_name,last_name,job_title FROM employees WHERE id=?", (r["other_employee_id"],)).fetchone()
                except Exception:
                    who = None
                r["other_name"] = (((who["first_name"] or "") + " " + (who["last_name"] or "")).strip() if who else "") or ("Employee " + str(r["other_employee_id"]))
                r["other_job"] = (who["job_title"] or "") if who else ""
                dur = None
                if r.get("answered_at") and r.get("ended_at"):
                    try:
                        import datetime as _dtmod
                        a = _dtmod.datetime.fromisoformat(str(r["answered_at"]).replace("Z", ""))
                        b = _dtmod.datetime.fromisoformat(str(r["ended_at"]).replace("Z", ""))
                        dur = max(0, int((b - a).total_seconds()))
                    except Exception:
                        dur = None
                r["duration_seconds"] = dur
                items.append(r)
            self.send_json(200, {"items": items}); return
        if path == "/api/voic3/calls" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            caller = mobile_eid
            if caller is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: caller = int(row["id"])
                except Exception: caller = None
            if caller is None: raise PermissionError("Authentication required.")
            callee = int(data.get("callee_employee_id") or 0)
            ctype = clean(data.get("call_type") or "audio")
            if ctype not in ("audio", "video"): ctype = "audio"
            if not callee: raise ValueError("callee_employee_id required")
            if callee == int(caller): raise ValueError("Cannot call yourself.")
            stamp = iso_now()
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_calls(caller_employee_id,callee_employee_id,call_type,status,created_at) VALUES(?,?,?,?,?)",
                                             (int(caller), callee, ctype, "ringing", stamp))
            call_id = int(cur.lastrowid)
            SERVICE.store.conn.commit()
            # Ring the callee only: the caller's own screen must never ring itself.
            publish_voic3_event([callee], "call.incoming", {"call_id": call_id, "caller_employee_id": int(caller), "callee_employee_id": callee, "call_type": ctype})
            publish_voic3_event([int(caller)], "call.state", {"call_id": call_id, "status": "ringing", "caller_employee_id": int(caller), "callee_employee_id": callee})
            try:
                crow = SERVICE.store.conn.execute("SELECT first_name,last_name FROM employees WHERE id=?", (int(caller),)).fetchone()
                cname = (((crow["first_name"] or "") + " " + (crow["last_name"] or "")).strip() if crow else "")
                notify_voic3_offline([callee], voic3_push.call_payload(call_id, cname, ctype))
            except Exception:
                pass
            self.send_json(201, {"id": call_id, "status": "ringing"}); return
        m = re.fullmatch(r"/api/voic3/calls/(\d+)/signal", path)
        if m and method in ("GET", "POST"):
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            call_id = int(m.group(1))
            call = SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id,status FROM voic3_calls WHERE id=?", (call_id,)).fetchone()
            if not call: raise KeyError("Call not found.")
            if int(eid) not in (int(call["caller_employee_id"]), int(call["callee_employee_id"])):
                raise PermissionError("This call is not available to your account.")
            if method == "GET":
                after = int(data.get("after") or 0)
                rows = SERVICE.query("SELECT id,sender_employee_id,kind,payload,created_at FROM voic3_signals WHERE call_id=? AND id>? AND COALESCE(sender_employee_id,0)<>? ORDER BY id", (call_id, after, int(eid)))
                self.send_json(200, {"items": rows}); return
            kind = clean(data.get("kind"))
            payload = data.get("payload")
            if not kind or payload is None: raise ValueError("kind and payload required")
            if clean(call["status"]) in ("ended", "declined", "missed", "cancelled"):
                raise ValueError("This call is already closed.")
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_signals(call_id,sender_employee_id,kind,payload,created_at) VALUES(?,?,?,?,?)",
                                             (call_id, int(eid), kind, payload if isinstance(payload, str) else json.dumps(payload), iso_now()))
            SERVICE.store.conn.commit()
            other = int(call["callee_employee_id"]) if int(eid) == int(call["caller_employee_id"]) else int(call["caller_employee_id"])
            publish_voic3_event([other], "call.signal", {"call_id": call_id, "sender_employee_id": int(eid), "kind": kind})
            self.send_json(201, {"id": int(cur.lastrowid)}); return
        m = re.fullmatch(r"/api/voic3/calls/(\d+)/(answer|decline|end)", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            call_id = int(m.group(1)); verb = m.group(2)
            call = SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id,status FROM voic3_calls WHERE id=?", (call_id,)).fetchone()
            if not call: raise KeyError("Call not found.")
            caller, callee = int(call["caller_employee_id"]), int(call["callee_employee_id"])
            if int(eid) not in (caller, callee):
                raise PermissionError("This call is not available to your account.")
            stamp = iso_now()
            if verb == "answer":
                if int(eid) != callee: raise PermissionError("Only the person being called can answer.")
                if clean(call["status"]) != "ringing": raise ValueError("This call is not ringing.")
                SERVICE.store.conn.execute("UPDATE voic3_calls SET status='active',answered_at=? WHERE id=?", (stamp, call_id))
                SERVICE.store.conn.commit()
                publish_voic3_event([caller, callee], "call.state", {"call_id": call_id, "status": "active"})
                self.send_json(200, {"ok": True, "status": "active"}); return
            if verb == "decline":
                if int(eid) != callee: raise PermissionError("Only the person being called can decline.")
                SERVICE.store.conn.execute("UPDATE voic3_calls SET status='declined',ended_at=?,ended_reason='declined' WHERE id=?", (stamp, call_id))
                SERVICE.store.conn.commit()
                publish_voic3_event([caller, callee], "call.state", {"call_id": call_id, "status": "declined"})
                self.send_json(200, {"ok": True, "status": "declined"}); return
            reason = clean(data.get("reason") or "completed")
            if reason not in ("completed", "declined", "missed", "failed", "cancelled"): reason = "completed"
            SERVICE.store.conn.execute("UPDATE voic3_calls SET status='ended',ended_at=?,ended_reason=? WHERE id=?", (stamp, reason, call_id))
            SERVICE.store.conn.commit()
            publish_voic3_event([caller, callee], "call.state", {"call_id": call_id, "status": "ended", "reason": reason})
            self.send_json(200, {"ok": True, "status": "ended"}); return
        # VOIC3 ICE server configuration (STUN always free; TURN optional via env).
        if path == "/api/voic3/ice-config" and method == "GET":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            import hmac as _hmac, hashlib as _hashlib, base64 as _base64
            # STUN from this office first: coturn (or the bundled turnserver.exe)
            # answers STUN on 3478 at the DuckDNS name with no credentials.
            ice_servers = []
            _own_stun = os.environ.get("BR_DDNS_HOST", "").strip()
            if _own_stun:
                ice_servers.append({"urls": ["stun:%s:3478" % _own_stun]})
            # Public STUN is free and keyless but third-party; keep it only as a
            # fallback, and let the owner switch it off (VOIC3_PUBLIC_STUN=off).
            # Same-Wi-Fi calls never need any STUN: host candidates connect.
            if os.environ.get("VOIC3_PUBLIC_STUN", "on").strip().lower() not in ("off", "0", "no"):
                # Metered's free relay comes first when it is configured: STUN alone
                # cannot connect a call on mobile data once the carrier blocks the
                # inbound path, which is exactly the 4G <-> Wi-Fi case.
                for _entry in _public_ice_servers():
                    if _entry not in ice_servers:
                        ice_servers.append(_entry)
            turn_url = os.environ.get("VOIC3_TURN_URL", "").strip()
            turn_secret = os.environ.get("VOIC3_TURN_SECRET", "").strip()
            # The launcher script sets VOIC3_TURN_LOCAL / _LOCAL_SECRET (that is
            # what start-n3xus.bat has always exported), so a relay configured
            # that way is honoured too instead of silently serving STUN only.
            if not (turn_url and turn_secret):
                turn_url = os.environ.get("VOIC3_TURN_LOCAL", "").strip()
                turn_secret = os.environ.get("VOIC3_TURN_LOCAL_SECRET", "").strip()
            if turn_url and turn_secret:
                # One relay can be offered over UDP and TCP at once, so ICE can
                # fall back when a router or carrier blocks inbound UDP. Give the
                # relay as a comma-separated list and both are handed out together.
                turn_urls = [u.strip() for u in turn_url.split(",") if u.strip()]
                ttl = 12 * 3600
                username = str(int(time.time()) + ttl)
                password = _base64.b64encode(_hmac.new(turn_secret.encode(), username.encode(), _hashlib.sha1).digest()).decode()
                ice_servers.append({"urls": turn_urls, "username": username, "credential": password})
            # The relay this machine runs itself. The credentials are minted here
            # from the shared secret, so there is never a static password to leak
            # and nothing has to be configured by hand on either side.
            if not (turn_url and turn_secret):
                local = os.environ.get("VOIC3_TURN_LOCAL", "").strip()
                local_secret = os.environ.get("VOIC3_TURN_LOCAL_SECRET", "").strip()
                if local and local_secret:
                    turn_urls = [u.strip() for u in local.split(",") if u.strip()]
                    ttl = 12 * 3600
                    username = str(int(time.time()) + ttl)
                    password = _base64.b64encode(_hmac.new(local_secret.encode(), username.encode(), _hashlib.sha1).digest()).decode()
                    ice_servers.append({"urls": turn_urls, "username": username, "credential": password})
            # A fixed relay with its own long-term user/password (coturn lt-cred-mech).
            turn_user = os.environ.get("VOIC3_TURN_USER", "").strip()
            turn_pass = os.environ.get("VOIC3_TURN_PASS", "").strip()
            if turn_url and turn_user and turn_pass:
                ice_servers.append({"urls": [u.strip() for u in turn_url.split(",") if u.strip()],
                                    "username": turn_user, "credential": turn_pass})
            self.send_json(200, {"iceServers": ice_servers, "ttl": 12 * 3600}); return
        # The relay list on its own, reachable before sign-in: the messenger asks
        # for it as a call starts, and a call must not fail because a session
        # cookie happened to have expired while the app sat in the background.
        if path == "/api/voic3/ice-servers" and method == "GET":
            self.send_json(200, {"iceServers": _local_turn_ice_list(_public_ice_servers()), "ttl": 600}); return

        # ------------------------------------------------------------------
        # Section 14: interactive workflow cards + immutable compliance export.
        # Additive routes; nothing existing changes shape.
        # ------------------------------------------------------------------
        if path=="/api/voic3/workflow/cards" and method=="POST":
            actor=clean(data.get("actor") or actor or "")
            if not actor and mobile_eid is None: raise PermissionError("Authentication required.")
            kind=clean(data.get("card_type") or "")
            if kind not in voic3_workflow.CARD_TYPES: raise ValueError("Unknown card type.")
            conv_id=int(data.get("conversation_id") or 0)
            if not conv_id: raise ValueError("Choose a conversation for the card.")
            conv=SERVICE.store.conn.execute("SELECT id,kind FROM voic3_conversations WHERE id=?",(conv_id,)).fetchone()
            if not conv: raise KeyError("Conversation not found.")
            payload=dict(data.get("payload") or {})
            payload.setdefault("card_type",kind)
            payload["status"]=clean(payload.get("status") or "Pending")
            if kind=="leave_card" and payload.get("leave_id"):
                row=SERVICE.store.conn.execute("SELECT * FROM leave_records WHERE id=?",(int(payload["leave_id"]),)).fetchone()
                if row:
                    payload.update({"date_from":row["date_from"],"date_to":row["date_to"],
                                    "days":row["days"],"leave_type":row["leave_type"],"status":row["status"]})
            if kind=="safety_checklist" and not payload.get("items"):
                raise ValueError("A safety checklist needs at least one item.")
            body_txt=voic3_workflow.card_fallback_text(kind,payload)
            idem=clean(data.get("idempotency_key") or "")
            if idem:
                hit=SERVICE.store.conn.execute("SELECT id FROM hub_messages WHERE idempotency_key=?",(idem[:120],)).fetchone()
                if hit: self.send_json(200,{"id":int(hit["id"]),"duplicate":True}); return
            stamp=iso_now()
            cur=SERVICE.store.conn.execute(
                "INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at,conversation_id,message_type,metadata_json,idempotency_key) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (actor,"",None,None,"",body_txt,stamp,conv_id,kind,voic3_workflow.encode_metadata(payload),idem[:120] or None))
            mid=int(cur.lastrowid); SERVICE.store.conn.commit()
            voic3_workflow.log(SERVICE.store.conn,kind,"card.created","hub_message",str(mid),actor,
                               "%s in conversation %d" % (kind,conv_id),
                               payload.get("latitude"),payload.get("longitude"))
            members=[int(r["employee_id"]) for r in SERVICE.store.conn.execute(
                "SELECT employee_id FROM voic3_members WHERE conversation_id=?",(conv_id,)).fetchall() if r["employee_id"]]
            publish_voic3_event(members,"message.new",{"conversationId":conv_id,"id":mid,
                                                       "type":kind,"text":body_txt,"payload":payload})
            self.send_json(201,{"id":mid,"card":payload,"text":body_txt}); return

        m=re.fullmatch(r"/api/voic3/workflow/cards/(\d+)",path)
        if m and method=="GET":
            actor=clean(data.get("actor") or actor or "")
            if not actor and mobile_eid is None: raise PermissionError("Authentication required.")
            row=SERVICE.store.conn.execute("SELECT * FROM hub_messages WHERE id=?",(int(m.group(1)),)).fetchone()
            if not row: raise KeyError("Card not found.")
            meta=voic3_workflow.decode_metadata(row["metadata_json"])
            self.send_json(200,{"id":int(row["id"]),"card_type":row["message_type"],
                                "conversation_id":row["conversation_id"],"sender":row["sender"],
                                "text":row["body"],"payload":meta,"created_at":row["created_at"]}); return

        m=re.fullmatch(r"/api/voic3/workflow/cards/(\d+)/action",path)
        if m and method=="POST":
            actor=clean(data.get("actor") or actor or "")
            if not actor and mobile_eid is None: raise PermissionError("Authentication required.")
            mid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT * FROM hub_messages WHERE id=?",(mid,)).fetchone()
            if not row: raise KeyError("Card not found.")
            meta=voic3_workflow.decode_metadata(row["metadata_json"])
            kind=row["message_type"] or meta.get("card_type") or ""
            action=clean(data.get("action") or "")
            if kind=="leave_card":
                if action not in ("approve","decline"): raise ValueError("Action must be approve or decline.")
                role_txt = str(SERVICE.role_for(actor) or "").lower()
                if role_txt not in ("admin","administrator","owner","manager","hr"):
                    raise PermissionError("Only a manager can decide a leave card.")
                if meta.get("leave_id"):
                    leave=SERVICE.store.conn.execute("SELECT status FROM leave_records WHERE id=?",(int(meta["leave_id"]),)).fetchone()
                    if leave and leave["status"]=="Pending":
                        stamp=iso_now()
                        decision="Approved" if action=="approve" else "Declined"
                        SERVICE.store.conn.execute("UPDATE leave_records SET status=?,decision_by=?,decision_at=?,updated_at=? WHERE id=?",
                                                   (decision,actor,stamp,stamp,int(meta["leave_id"])))
                        SERVICE.store.log(actor,"%s leave application" % decision,"leave",int(meta["leave_id"]))
                        meta["status"]=decision
                else:
                    meta["status"]="Approved" if action=="approve" else "Declined"
            elif kind=="safety_checklist":
                idx=int(data.get("index") or 0)
                items=meta.get("items") or []
                if idx<1 or idx>len(items): raise ValueError("That checklist item does not exist.")
                items[idx-1]["checked"]=bool(data.get("checked",True))
                items[idx-1]["by"]=actor
                items[idx-1]["at"]=iso_now()
                meta["items"]=items
                done=sum(1 for i in items if i.get("checked"))
                meta["status"]="Complete" if done==len(items) else "In progress"
            elif kind=="sos_pin":
                if action not in ("acknowledge","resolve"): raise ValueError("Action must be acknowledge or resolve.")
                meta["status"]="Resolved" if action=="resolve" else "Acknowledged"
                meta["handled_by"]=actor
            else:
                raise ValueError("This message is not an interactive card.")
            meta["updated_at"]=iso_now()
            text=voic3_workflow.card_fallback_text(kind,meta)
            SERVICE.store.conn.execute("UPDATE hub_messages SET metadata_json=?,body=? WHERE id=?",
                                       (voic3_workflow.encode_metadata(meta),text,mid))
            SERVICE.store.conn.commit()
            voic3_workflow.log(SERVICE.store.conn,kind,"card."+action,"hub_message",str(mid),actor,
                               "status now %s" % (meta.get("status") or ""),
                               data.get("latitude"),data.get("longitude"))
            members=[int(r["employee_id"]) for r in SERVICE.store.conn.execute(
                "SELECT employee_id FROM voic3_members WHERE conversation_id=?",(int(row["conversation_id"] or 0),)).fetchall() if r["employee_id"]]
            publish_voic3_event(members,"message.new",{"conversationId":int(row["conversation_id"] or 0),
                                                       "id":mid,"type":kind,"text":text,"payload":meta})
            self.send_json(200,{"ok":True,"card":meta,"text":text}); return

        if path=="/api/voic3/compliance/export" and method=="GET":
            actor=clean(q.get("actor",[""])[0] or actor or "")
            if not actor and mobile_eid is None: raise PermissionError("Authentication required.")
            if str(SERVICE.role_for(actor) or "").lower() not in ("admin","administrator","owner","hr"):
                raise PermissionError("Only an administrator can export compliance records.")
            kind=clean(q.get("kind",[""])[0]) or None
            since=clean(q.get("since",[""])[0]) or None
            fmt=(clean(q.get("format",["html"])[0]) or "html").lower()
            rows=voic3_workflow.export_rows(SERVICE.store.conn,kind,since)
            chain=voic3_workflow.verify_chain(SERVICE.store.conn)
            SERVICE.store.log(actor,"Exported compliance records","compliance",fmt,
                              "%d record(s), chain %s" % (len(rows),"valid" if chain.get("valid") else "BROKEN"))
            SERVICE.store.conn.commit()
            if fmt=="csv":
                body=voic3_workflow.to_csv(rows).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type","text/csv; charset=utf-8")
                self.send_header("Content-Disposition",'attachment; filename="n3xus-compliance-%s.csv"' % time.strftime("%Y%m%d-%H%M"))
                self.send_header("Content-Length",str(len(body)))
                self.end_headers(); self.wfile.write(body); return
            if fmt=="json":
                self.send_json(200,{"chain":chain,"count":len(rows),"items":rows}); return
            body=voic3_workflow.to_html(rows,chain).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Content-Length",str(len(body)))
            self.end_headers(); self.wfile.write(body); return

        # ------------------------------------------------------------------
        # Section 12: self-hosted Web Push (VAPID). Additive routes only; when
        # VAPID keys are absent every route still answers and push is skipped.
        # ------------------------------------------------------------------
        if path == "/api/voic3/push/vapid-public-key" and method == "GET":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            key = voic3_push.public_key()
            self.send_json(200, {"publicKey": key, "enabled": bool(key),
                                 "subject": (voic3_push.vapid_keys() or ("", "", ""))[2] if key else ""}); return
        if path == "/api/voic3/push/subscribe" and method == "POST":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute(
                        "SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception:
                    eid = None
            if eid is None:
                raise PermissionError("Authentication required.")
            endpoint = clean(data.get("endpoint")) or ""
            keys_obj = data.get("keys") if isinstance(data.get("keys"), dict) else {}
            p256dh = clean(data.get("p256dh") or keys_obj.get("p256dh")) or ""
            auth = clean(data.get("auth") or keys_obj.get("auth")) or ""
            if not endpoint.startswith("https://"):
                raise ValueError("A valid push endpoint is required.")
            if not p256dh or not auth:
                raise ValueError("Push keys (p256dh, auth) are required.")
            sub_id = voic3_push.save_subscription(
                SERVICE.store.conn, eid, endpoint, p256dh, auth, clean(data.get("device_label")) or "")
            try:
                SERVICE.store.log(actor or ("mobile:" + str(eid)), "VOIC3 push subscription added",
                                  "voic3_push", sub_id, endpoint[:120])
                SERVICE.store.conn.commit()
            except Exception:
                pass
            self.send_json(201, {"ok": True, "id": sub_id, "enabled": voic3_push.enabled()}); return
        if path == "/api/voic3/push/unsubscribe" and method == "DELETE":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute(
                        "SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception:
                    eid = None
            if eid is None:
                raise PermissionError("Authentication required.")
            endpoint = clean(data.get("endpoint")) or ""
            if not endpoint:
                raise ValueError("endpoint is required.")
            removed = voic3_push.delete_subscription(SERVICE.store.conn, eid, endpoint)
            self.send_json(200, {"ok": True, "removed": bool(removed)}); return

        if path == "/api/voic3/presence" and method == "GET":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            rows = SERVICE.query("SELECT employee_id,status,custom_note,updated_at FROM voic3_presence")
            self.send_json(200, {"items": rows}); return
        if path == "/api/voic3/presence" and method == "POST":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception:
                    eid = None
            if eid is None:
                raise PermissionError("Authentication required.")
            st = clean(data.get("status") or "online")
            if st not in ("online", "busy", "dnd", "offline"):
                st = "online"
            note = clean(data.get("custom_note") or "")[:120]
            stamp = iso_now()
            with SERVICE.lock:
                SERVICE.store.conn.execute("INSERT INTO voic3_presence(employee_id,status,custom_note,updated_at) VALUES(?,?,?,?) ON CONFLICT(employee_id) DO UPDATE SET status=excluded.status,custom_note=excluded.custom_note,updated_at=excluded.updated_at", (eid, st, note, stamp))
                SERVICE.store.conn.commit()
            publish_voic3_event([eid], "presence.update", {"employee_id": eid, "status": st, "custom_note": note})
            self.send_json(200, {"ok": True, "status": st}); return

        if path == "/api/voic3/calls/history" and method == "GET":
            if not actor and not mobile_eid:
                raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception:
                    eid = None
            if eid is None:
                rows = SERVICE.query("SELECT c.id,c.caller_employee_id,c.callee_employee_id,c.call_type,c.status,c.ended_reason,c.created_at,c.answered_at,c.ended_at,ce.first_name AS caller_first,ce.last_name AS caller_last,callee.first_name AS callee_first,callee.last_name AS callee_last FROM voic3_calls c LEFT JOIN employees ce ON ce.id=c.caller_employee_id LEFT JOIN employees callee ON callee.id=c.callee_employee_id ORDER BY c.id DESC LIMIT 50")
            else:
                rows = SERVICE.query("SELECT c.id,c.caller_employee_id,c.callee_employee_id,c.call_type,c.status,c.ended_reason,c.created_at,c.answered_at,c.ended_at,ce.first_name AS caller_first,ce.last_name AS caller_last,callee.first_name AS callee_first,callee.last_name AS callee_last FROM voic3_calls c LEFT JOIN employees ce ON ce.id=c.caller_employee_id LEFT JOIN employees callee ON callee.id=c.callee_employee_id WHERE c.caller_employee_id=? OR c.callee_employee_id=? ORDER BY c.id DESC LIMIT 50", (eid, eid))
            out = []
            for r in rows:
                r = dict(r)
                dur = None
                if r.get("answered_at") and r.get("ended_at"):
                    try:
                        # Import under a private name: a bare "from datetime import
                        # datetime" rebinds the module-level datetime for the whole
                        # function and broke every later call (PUT /api/vision/history).
                        import datetime as _dtmod
                        a = _dtmod.datetime.fromisoformat(str(r["answered_at"]).replace("Z",""))
                        e = _dtmod.datetime.fromisoformat(str(r["ended_at"]).replace("Z",""))
                        dur = int((e - a).total_seconds())
                    except Exception:
                        dur = None
                r["duration_seconds"] = dur
                r["caller_name"] = ((r.get("caller_first") or "") + " " + (r.get("caller_last") or "")).strip() or str(r.get("caller_employee_id"))
                r["callee_name"] = ((r.get("callee_first") or "") + " " + (r.get("callee_last") or "")).strip() or str(r.get("callee_employee_id"))
                out.append(r)
            self.send_json(200, {"items": out}); return

        # ---- VOIC3 conversations (Section 6) ----
        if path == "/api/voic3/conversations" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None:
                rows = SERVICE.query("SELECT * FROM voic3_conversations ORDER BY id DESC LIMIT 100")
            else:
                rows = SERVICE.query("SELECT c.* FROM voic3_conversations c JOIN voic3_members m ON m.conversation_id=c.id WHERE m.employee_id=? ORDER BY c.id DESC", (eid,))
            # The messenger needs a title, the participants, the last message and an
            # unread count per conversation. All of it is assembled here so the
            # browser makes one request instead of one per conversation.
            items = []
            for r in rows:
                r = dict(r)
                cid = int(r["id"])
                title = (r.get("name") or "").strip() or (r.get("department") or "").strip()
                peer_id = None
                try:
                    members = SERVICE.store.conn.execute(
                        "SELECT m.employee_id,e.first_name,e.last_name,e.job_title FROM voic3_members m "
                        "LEFT JOIN employees e ON e.id=m.employee_id WHERE m.conversation_id=? "
                        "ORDER BY m.employee_id", (cid,)).fetchall()
                except Exception:
                    members = []
                people = []
                for mrow in members:
                    keys = mrow.keys()
                    nm = (((mrow["first_name"] or "") if "first_name" in keys else "") + " " +
                          ((mrow["last_name"] or "") if "last_name" in keys else "")).strip()
                    people.append({"employee_id": int(mrow["employee_id"]),
                                   "name": nm or ("Employee " + str(mrow["employee_id"])),
                                   "job_title": (mrow["job_title"] or "") if "job_title" in keys else ""})
                if r.get("kind") == "dm" and eid is not None:
                    for p in people:
                        if p["employee_id"] != int(eid):
                            peer_id = p["employee_id"]
                            if not title: title = p["name"]
                            break
                if not title: title = "Conversation " + str(cid)
                last = None
                unread = 0
                try:
                    last_row = SERVICE.store.conn.execute(
                        "SELECT id,employee_id,sender,body,created_at FROM hub_messages WHERE conversation_id=? AND deleted_at IS NULL "
                        "ORDER BY id DESC LIMIT 1", (cid,)).fetchone()
                    last = dict(last_row) if last_row else None
                    if eid is not None:
                        mine = SERVICE.store.conn.execute(
                            "SELECT last_read_message_id FROM voic3_members WHERE conversation_id=? AND employee_id=?",
                            (cid, int(eid))).fetchone()
                        after_id = int((mine["last_read_message_id"] if mine else 0) or 0)
                        unread = int(SERVICE.store.conn.execute(
                            "SELECT COUNT(*) AS c FROM hub_messages WHERE conversation_id=? AND deleted_at IS NULL "
                            "AND id>? AND COALESCE(employee_id,0)<>?", (cid, after_id, int(eid))).fetchone()["c"] or 0)
                except Exception:
                    pass
                r["title"] = title
                r["peer_employee_id"] = peer_id
                r["members"] = people
                r["last_message"] = last
                r["unread"] = unread
                items.append(r)
            # Most recent conversation first, the way every messenger lists them.
            items.sort(key=lambda x: int((x.get("last_message") or {}).get("id") or 0) or int(x.get("id") or 0), reverse=True)
            self.send_json(200, {"items": items}); return
        if path == "/api/voic3/conversations" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            kind = clean(data.get("kind") or "group")
            if kind not in ("dm","group","channel","department","broadcast"): kind = "group"
            name = clean(data.get("name") or "")
            dept = clean(data.get("department") or "")
            ann = 1 if data.get("is_announcement_only") else 0
            creator = mobile_eid
            if creator is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: creator = int(row["id"])
                except Exception: creator = None
            # Opening the same chat twice must not create a second copy of it, so a
            # direct message returns the conversation that already exists and a group
            # with the same name and the same creator is reused as well.
            wanted = [int(m) for m in (data.get("members") or []) if str(m).strip().isdigit()]
            if kind == "dm" and creator is not None:
                peer = next((m for m in wanted if m != int(creator)), None)
                if peer is not None:
                    existing = SERVICE.store.conn.execute(
                        "SELECT c.id FROM voic3_conversations c "
                        "JOIN voic3_members a ON a.conversation_id=c.id AND a.employee_id=? "
                        "JOIN voic3_members b ON b.conversation_id=c.id AND b.employee_id=? "
                        "WHERE c.kind='dm' ORDER BY c.id LIMIT 1", (int(creator), peer)).fetchone()
                    if existing:
                        self.send_json(200, {"id": int(existing["id"]), "existing": True}); return
            if kind == "group" and name and creator is not None:
                existing = SERVICE.store.conn.execute(
                    "SELECT id FROM voic3_conversations WHERE kind='group' AND name=? AND COALESCE(created_by,0)=? ORDER BY id LIMIT 1",
                    (name, int(creator))).fetchone()
                if existing:
                    for m in wanted:
                        SERVICE.store.conn.execute("INSERT OR IGNORE INTO voic3_members(conversation_id,employee_id,role,last_read_message_id,joined_at) VALUES(?,?,?,?,?)",
                                                   (int(existing["id"]), m, "member", 0, iso_now()))
                    SERVICE.store.conn.commit()
                    self.send_json(200, {"id": int(existing["id"]), "existing": True}); return
            stamp = iso_now()
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_conversations(kind,name,department,created_by,is_announcement_only,pinned_message_id,created_at) VALUES(?,?,?,?,?,?,?)", (kind,name,dept,creator,ann,None,stamp))
            cid = int(cur.lastrowid)
            members = data.get("members") or []
            if creator is not None:
                SERVICE.store.conn.execute("INSERT OR IGNORE INTO voic3_members(conversation_id,employee_id,role,last_read_message_id,joined_at) VALUES(?,?,?,?,?)", (cid,creator,"owner",0,stamp))
            for m in members:
                try:
                    SERVICE.store.conn.execute("INSERT OR IGNORE INTO voic3_members(conversation_id,employee_id,role,last_read_message_id,joined_at) VALUES(?,?,?,?,?)", (cid,int(m),"member",0,stamp))
                except Exception: pass
            SERVICE.store.conn.commit()
            self.send_json(201, {"id": cid}); return
        m = re.fullmatch(r"/api/voic3/conversations/(\d+)/messages", path)
        if m and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            cid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            member = SERVICE.store.conn.execute("SELECT role FROM voic3_members WHERE conversation_id=? AND employee_id=?", (cid, eid)).fetchone()
            if not member and not (actor and SERVICE.role_for(actor) == "Administrator"):
                raise PermissionError("This conversation is not available to your account.")
            limit = int(data.get("limit") or 100)
            limit = max(1, min(limit, 300))
            rows = SERVICE.query("SELECT h.id,h.employee_id,h.sender,h.body,h.message_type,h.reply_to_id,h.created_at,h.edited_at,h.deleted_at, (SELECT COALESCE(e.first_name||' '||e.last_name,'') FROM employees e WHERE e.id=h.employee_id) AS sender_name, (SELECT COUNT(*) FROM voic3_receipts r WHERE r.message_id=h.id AND r.read_at IS NOT NULL) AS read_count FROM hub_messages h WHERE h.conversation_id=? AND h.deleted_at IS NULL ORDER BY h.id DESC LIMIT ?", (cid, limit))
            rows.reverse()
            for r in rows:
                r["is_me"] = int(r.get("employee_id") or 0) == eid
            try:
                last = max([int(r["id"]) for r in rows] or [0])
                if last:
                    SERVICE.store.conn.execute("UPDATE voic3_members SET last_read_message_id=? WHERE conversation_id=? AND employee_id=?", (last, cid, eid))
                    SERVICE.store.conn.commit()
            except Exception:
                pass
            self.send_json(200, {"items": rows, "conversation_id": cid}); return
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            cid = int(m.group(1))
            body_txt = clean(data.get("body"))
            if not body_txt: raise ValueError("Message body required.")
            sender = mobile_eid
            # A signed-in admin has no employee record of their own, so the message
            # is stored with employee_id NULL and their username as the sender. The
            # browser then marks it as "mine" through the employee_id it is told it has.
            if sender is None and actor:
                sender = None
            conv = SERVICE.store.conn.execute("SELECT is_announcement_only,created_by FROM voic3_conversations WHERE id=?", (cid,)).fetchone()
            if not conv: raise KeyError("Conversation not found.")
            if conv["is_announcement_only"]:
                member = SERVICE.store.conn.execute("SELECT role FROM voic3_members WHERE conversation_id=? AND employee_id=?", (cid, sender)).fetchone()
                if not (member and member["role"] in ("owner","admin") or (conv["created_by"] and conv["created_by"]==sender)):
                    raise PermissionError("Only admins can post in announcement channels.")
            reply_to = data.get("reply_to_id")
            mtype = clean(data.get("message_type") or "text")
            # Section 13: optional client idempotency key. A replayed offline
            # outbox item returns the original message instead of a duplicate.
            idem = clean(data.get("idempotency_key") or data.get("client_uuid")) or ""
            if idem:
                if len(idem) > 120:
                    idem = idem[:120]
                existing = SERVICE.store.conn.execute(
                    "SELECT id FROM hub_messages WHERE idempotency_key=?", (idem,)).fetchone()
                if existing:
                    self.send_json(200, {"id": int(existing["id"]), "duplicate": True}); return
            stamp = iso_now()
            cur = SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at,conversation_id,reply_to_id,message_type,idempotency_key) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (str(sender or actor), "", sender, None, "", body_txt[:20000], stamp, cid, int(reply_to) if reply_to else None, mtype, idem or None))
            mid = int(cur.lastrowid)
            SERVICE.store.conn.commit()
            recipients = [int(r[0]) for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_members WHERE conversation_id=?", (cid,)).fetchall()]
            publish_voic3_event(recipients, "message.new", {"conversation_id": cid, "message_id": mid})
            # Section 12: notify members whose app is closed or backgrounded.
            try:
                others = [r for r in recipients if r != int(sender or 0)]
                if others:
                    sender_row = SERVICE.store.conn.execute("SELECT first_name,last_name FROM employees WHERE id=?", (int(sender or 0),)).fetchone()
                    sender_name = ((sender_row["first_name"] or "") + " " + (sender_row["last_name"] or "")).strip() if sender_row else ""
                    notify_voic3_offline(others, voic3_push.message_payload(cid, sender_name or "New message", body_txt[:140], mid))
            except Exception:
                pass
            self.send_json(201, {"id": mid}); return
        m = re.fullmatch(r"/api/voic3/messages/(\d+)/receipt", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            kind = clean(data.get("kind") or "read")
            stamp = iso_now()
            if kind == "delivered":
                SERVICE.store.conn.execute("INSERT INTO voic3_receipts(message_id,employee_id,delivered_at,read_at) VALUES(?,?,?,NULL) ON CONFLICT(message_id,employee_id) DO UPDATE SET delivered_at=COALESCE(voic3_receipts.delivered_at,excluded.delivered_at)", (mid, eid, stamp))
            else:
                SERVICE.store.conn.execute("INSERT INTO voic3_receipts(message_id,employee_id,delivered_at,read_at) VALUES(?,?,?,?) ON CONFLICT(message_id,employee_id) DO UPDATE SET delivered_at=COALESCE(voic3_receipts.delivered_at,excluded.delivered_at), read_at=excluded.read_at", (mid, eid, stamp, stamp))
            SERVICE.store.conn.commit()
            publish_voic3_event([eid], "message.receipt", {"message_id": mid, "employee_id": eid, "kind": kind})
            self.send_json(200, {"ok": True}); return
        m = re.fullmatch(r"/api/voic3/messages/(\d+)/reaction", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            emoji = clean(data.get("emoji") or "")
            if not emoji: raise ValueError("emoji required")
            existing = SERVICE.store.conn.execute("SELECT 1 FROM voic3_reactions WHERE message_id=? AND employee_id=? AND emoji=?", (mid,eid,emoji)).fetchone()
            if existing:
                SERVICE.store.conn.execute("DELETE FROM voic3_reactions WHERE message_id=? AND employee_id=? AND emoji=?", (mid,eid,emoji))
                toggled = "removed"
            else:
                SERVICE.store.conn.execute("INSERT INTO voic3_reactions(message_id,employee_id,emoji,created_at) VALUES(?,?,?,?)", (mid,eid,emoji,iso_now()))
                toggled = "added"
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True, "action": toggled}); return
        m = re.fullmatch(r"/api/voic3/conversations/(\d+)/typing", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            cid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_members WHERE conversation_id=?", (cid,)).fetchall()], "typing", {"conversation_id": cid, "employee_id": eid})
            self.send_json(200, {"ok": True}); return
        if path == "/api/voic3/messages/search" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            qstr = clean(data.get("q") or "")
            rows = SERVICE.query("SELECT id,sender,body,created_at,conversation_id FROM hub_messages WHERE deleted_at IS NULL AND body LIKE ? ORDER BY id DESC LIMIT 50", ("%" + qstr + "%",))
            self.send_json(200, {"items": rows}); return
        # pin message
        m = re.fullmatch(r"/api/voic3/conversations/(\d+)/pin", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            cid = int(m.group(1))
            mid = data.get("message_id")
            SERVICE.store.conn.execute("UPDATE voic3_conversations SET pinned_message_id=? WHERE id=?", (int(mid) if mid else None, cid))
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True}); return
        # edit/delete own message
        m = re.fullmatch(r"/api/voic3/messages/(\d+)", path)
        if m and method == "PUT":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            row = SERVICE.store.conn.execute("SELECT employee_id FROM hub_messages WHERE id=?", (mid,)).fetchone()
            if not row or (eid is not None and int(row["employee_id"] or 0) != eid and not (actor and SERVICE.role_for(actor)=="Administrator")): raise PermissionError("Cannot edit this message.")
            body_txt = clean(data.get("body"))
            stamp = iso_now()
            SERVICE.store.conn.execute("UPDATE hub_messages SET body=?,edited_at=? WHERE id=?", (body_txt[:20000], stamp, mid))
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True}); return
        if m and method == "DELETE":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            row = SERVICE.store.conn.execute("SELECT employee_id FROM hub_messages WHERE id=?", (mid,)).fetchone()
            if not row or (eid is not None and int(row["employee_id"] or 0) != eid and not (actor and SERVICE.role_for(actor)=="Administrator")): raise PermissionError("Cannot delete this message.")
            SERVICE.store.conn.execute("UPDATE hub_messages SET deleted_at=? WHERE id=?", (iso_now(), mid))
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True}); return

        if path == "/api/voic3/templates" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            rows = SERVICE.query("SELECT * FROM voic3_templates ORDER BY id")
            self.send_json(200, {"items": rows}); return
        if path == "/api/voic3/templates" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            title = clean(data.get("title"))
            body = clean(data.get("body"))
            if not title or not body: raise ValueError("title and body required")
            cat = clean(data.get("category") or "")
            creator = mobile_eid
            if creator is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: creator = int(row["id"])
                except Exception: creator = None
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_templates(title,category,body,created_by,created_at) VALUES(?,?,?,?,?)", (title, cat, body, creator, iso_now()))
            SERVICE.store.conn.commit()
            self.send_json(201, {"id": int(cur.lastrowid)}); return
        if path == "/api/voic3/broadcast" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            subject = clean(data.get("subject") or "Broadcast")
            body = clean(data.get("body"))
            if not body: raise ValueError("body required")
            dept = clean(data.get("department") or "")
            if dept:
                rows = SERVICE.store.conn.execute("SELECT id FROM employees WHERE department=?", (dept,)).fetchall()
            else:
                rows = SERVICE.store.conn.execute("SELECT id FROM employees WHERE employment_status='Active'").fetchall()
            stamp = iso_now()
            ids = []
            for (eid,) in rows:
                cur = SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at,message_type) VALUES(?,?,?,?,?,?,?,?)", (str(actor or "admin"), "Broadcast", int(eid), dept or None, subject[:200], body[:20000], stamp, "system"))
                ids.append(int(cur.lastrowid))
            SERVICE.store.conn.commit()
            self.send_json(201, {"sent": len(ids)}); return
        if path == "/api/voic3/attachments" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            import base64 as _b64, os as _os, uuid as _uuid
            filename = clean(data.get("filename") or "file")
            mime = clean(data.get("mime_type") or "application/octet-stream")
            allowed = ("audio/", "image/", "application/pdf", "text/", "application/msword", "application/vnd.openxmlformats")
            if not any(mime.startswith(a) for a in allowed): raise ValueError("Mime type not allowed.")
            raw = data.get("data") or ""
            if "," in raw: raw = raw.split(",", 1)[1]
            try:
                blob = _b64.b64decode(raw)
            except Exception: raise ValueError("Invalid file data.")
            if len(blob) > 15 * 1024 * 1024: raise ValueError("File exceeds 15MB limit.")
            safe = _uuid.uuid4().hex + "_" + filename.replace("/", "_")
            ddir = legacy.DATA_HOME / "voic3_uploads"
            ddir.mkdir(parents=True, exist_ok=True)
            fpath = ddir / safe
            fpath.write_bytes(blob)
            stamp = iso_now()
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_attachments(employee_id,filename,mime_type,size_bytes,storage_path,created_at) VALUES(?,?,?,?,?,?)", (eid, filename, mime, len(blob), str(fpath), stamp))
            SERVICE.store.conn.commit()
            self.send_json(201, {"id": int(cur.lastrowid), "filename": filename, "mime_type": mime, "size_bytes": len(blob)}); return
        m = re.fullmatch(r"/api/voic3/attachments/(\d+)", path)
        if m and method == "GET":
            aid = int(m.group(1))
            row = SERVICE.store.conn.execute("SELECT employee_id, filename, mime_type, storage_path FROM voic3_attachments WHERE id=?", (aid,)).fetchone()
            if not row: raise KeyError("Attachment not found.")
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            raw = Path(row["storage_path"]).read_bytes()
            self.send_response(200); self.send_header("Content-Type", row["mime_type"]); self.send_header("Content-Disposition", 'attachment; filename="%s"' % row["filename"]); self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(raw); return
        if path == "/api/voic3/auto-reply" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            row = SERVICE.store.conn.execute("SELECT enabled,away_message,work_hours_json FROM voic3_auto_reply WHERE target_id=?", (eid,)).fetchone()
            self.send_json(200, {"enabled": bool(row and row["enabled"]), "away_message": (row["away_message"] if row else ""), "work_hours_json": (row["work_hours_json"] if row else "{}")}); return
        if path == "/api/voic3/auto-reply" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            enabled = 1 if data.get("enabled") else 0
            away = clean(data.get("away_message") or "")
            wh = data.get("work_hours_json") or "{}"
            SERVICE.store.conn.execute("INSERT INTO voic3_auto_reply(target_id,enabled,away_message,work_hours_json) VALUES(?,?,?,?) ON CONFLICT(target_id) DO UPDATE SET enabled=excluded.enabled,away_message=excluded.away_message,work_hours_json=excluded.work_hours_json", (eid, enabled, away, wh))
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True}); return

        # ---- VOIC3 meetings (Section 9) ----
        if path == "/api/voic3/meetings" and method == "GET":
            # Section 10: the meetings list the VOIC3 page and mobile app render.
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            rows = SERVICE.store.conn.execute(
                "SELECT m.id,m.code,m.title,m.status,m.host_employee_id,m.created_at,m.is_locked,"
                "(SELECT COUNT(*) FROM voic3_meeting_participants p WHERE p.meeting_id=m.id AND p.state='admitted') AS live_count "
                "FROM voic3_meetings m ORDER BY m.id DESC LIMIT 50").fetchall()
            items = [{"id": int(r["id"]), "code": r["code"], "title": r["title"],
                      "status": r["status"], "is_locked": bool(r["is_locked"]),
                      "live_count": int(r["live_count"] or 0),
                      "is_host": bool(eid is not None and int(r["host_employee_id"] or 0) == eid),
                      "created_at": r["created_at"]} for r in rows]
            self.send_json(200, {"items": items}); return
        if path == "/api/voic3/meetings" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            title = clean(data.get("title") or "Meeting")
            conv_id = data.get("conversation_id")
            sched = clean(data.get("scheduled_for") or "")
            wr = 0 if data.get("waiting_room_enabled") is False else 1
            code = "".join(random.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(8))
            stamp = iso_now()
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_meetings(code,title,host_employee_id,conversation_id,scheduled_for,waiting_room_enabled,is_locked,spotlight_employee_id,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (code,title,eid, int(conv_id) if conv_id else None, sched, wr, 0, None, "active", stamp))
            mid = int(cur.lastrowid)
            SERVICE.store.conn.execute("INSERT INTO voic3_meeting_participants(meeting_id,employee_id,state,is_muted_by_host,hand_raised,joined_at,left_at) VALUES(?,?,?,?,?,?,?)", (mid, eid, "admitted", 0, 0, stamp, None))
            SERVICE.store.conn.commit()
            self.send_json(201, {"id": mid, "code": code}); return
        if path == "/api/voic3/meetings/join" and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            code = clean(data.get("code"))
            row = SERVICE.store.conn.execute("SELECT id,host_employee_id,waiting_room_enabled,is_locked,status FROM voic3_meetings WHERE code=?", (code,)).fetchone()
            if not row or row["status"] != "active": raise KeyError("Meeting not found.")
            if row["is_locked"]: raise PermissionError("Meeting is locked.")
            mid = int(row["id"])
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            state = "waiting" if row["waiting_room_enabled"] else "admitted"
            stamp = iso_now()
            SERVICE.store.conn.execute("INSERT INTO voic3_meeting_participants(meeting_id,employee_id,state,is_muted_by_host,hand_raised,joined_at,left_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(meeting_id,employee_id) DO UPDATE SET state=excluded.state,joined_at=excluded.joined_at", (mid, eid, state, 0, 0, stamp, None))
            SERVICE.store.conn.commit()
            # The host must hear about a knock at once (waiting room), not on the next poll.
            host_id = int(row["host_employee_id"] or 0)
            notify = [eid] + ([host_id] if host_id and host_id != eid else [])
            publish_voic3_event(notify, "meeting.join", {"meeting_id": mid, "employee_id": eid, "state": state})
            self.send_json(200, {"meeting_id": mid, "state": state}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/join", path)
        if m and method == "POST":
            # Compatibility: joining is by code (/meetings/join). Anything that
            # still posts the id here is answered by the same code path instead
            # of a bare 404.
            mid = int(m.group(1))
            row = SERVICE.store.conn.execute(
                "SELECT code FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not row:
                raise KeyError("Meeting not found.")
            self.send_json(200, {"meeting_id": mid, "code": row["code"],
                                 "hint": "Use POST /api/voic3/meetings/join with this code."})
            return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/invite", path)
        if m and method == "POST":
            # Group meetings are started from a contact picker: the host chooses
            # people, they are added to the participant list and told to join.
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            meet = SERVICE.store.conn.execute("SELECT id,host_employee_id,title,code,status FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not meet: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            if int(eid) != int(meet["host_employee_id"] or 0) and not (actor and SERVICE.role_for(actor) == "Administrator"):
                raise PermissionError("Only the host can add people to this meeting.")
            stamp = iso_now()
            added = []
            for raw in (data.get("employee_ids") or []):
                try:
                    target = int(raw)
                except Exception:
                    continue
                if target == int(meet["host_employee_id"] or 0):
                    continue
                SERVICE.store.conn.execute(
                    "INSERT INTO voic3_meeting_participants(meeting_id,employee_id,state,is_muted_by_host,hand_raised,joined_at,left_at) "
                    "VALUES(?,?,?,?,?,?,?) ON CONFLICT(meeting_id,employee_id) DO UPDATE SET state=CASE WHEN voic3_meeting_participants.state='admitted' THEN 'admitted' ELSE excluded.state END",
                    (mid, target, "invited", 0, 0, None, None))
                added.append(target)
            SERVICE.store.conn.commit()
            if added:
                publish_voic3_event(added, "meeting.invite", {"meeting_id": mid, "code": meet["code"], "title": meet["title"], "host_employee_id": int(meet["host_employee_id"] or 0)})
                try:
                    notify_voic3_offline(added, {"type": "meeting", "title": "Meeting invitation",
                                                 "body": clean(meet["title"]) or "You are invited to a meeting",
                                                 "tag": "voic3-meeting-" + str(mid),
                                                 "url": "/?voic3_meeting=" + str(mid),
                                                 "data": {"meetingId": mid, "url": "/?voic3_meeting=" + str(mid)}})
                except Exception:
                    pass
            self.send_json(200, {"ok": True, "added": added}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/participants", path)
        if m and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            rows = SERVICE.query(
                "SELECT p.employee_id,p.state,p.is_muted_by_host,p.hand_raised,e.first_name,e.last_name,e.job_title "
                "FROM voic3_meeting_participants p LEFT JOIN employees e ON e.id=p.employee_id WHERE p.meeting_id=? ORDER BY p.employee_id", (mid,))
            items = [{"employee_id": int(r["employee_id"]), "state": r.get("state") or "",
                      "name": (((r.get("first_name") or "") + " " + (r.get("last_name") or "")).strip()) or ("Employee " + str(r["employee_id"])),
                      "job_title": r.get("job_title") or "", "hand_raised": bool(r.get("hand_raised"))} for r in rows]
            self.send_json(200, {"items": items}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/admit", path)
        if m and method == "POST":
            mid = int(m.group(1)); target = int(data.get("employee_id"))
            host = SERVICE.store.conn.execute("SELECT host_employee_id FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not host: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid != int(host["host_employee_id"]) and not (actor and SERVICE.role_for(actor)=="Administrator"): raise PermissionError("Host only.")
            SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET state='admitted',joined_at=? WHERE meeting_id=? AND employee_id=?", (iso_now(), mid, target))
            SERVICE.store.conn.commit()
            publish_voic3_event([target], "meeting.admitted", {"meeting_id": mid})
            self.send_json(200, {"ok": True}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/reject", path)
        if m and method == "POST":
            mid = int(m.group(1)); target = int(data.get("employee_id"))
            host = SERVICE.store.conn.execute("SELECT host_employee_id FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not host: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid != int(host["host_employee_id"]) and not (actor and SERVICE.role_for(actor)=="Administrator"): raise PermissionError("Host only.")
            SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET state='rejected',left_at=? WHERE meeting_id=? AND employee_id=?", (iso_now(), mid, target))
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/host-action", path)
        if m and method == "POST":
            mid = int(m.group(1))
            host = SERVICE.store.conn.execute("SELECT host_employee_id FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not host: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid != int(host["host_employee_id"]) and not (actor and SERVICE.role_for(actor)=="Administrator"): raise PermissionError("Host only.")
            action = clean(data.get("action"))
            target = data.get("employee_id")
            if action == "mute_all":
                SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET is_muted_by_host=1 WHERE meeting_id=?", (mid,))
            elif action == "mute_user" and target:
                SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET is_muted_by_host=1 WHERE meeting_id=? AND employee_id=?", (mid, int(target)))
            elif action == "kick" and target:
                SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET state='left',left_at=? WHERE meeting_id=? AND employee_id=?", (iso_now(), mid, int(target)))
            elif action == "lock":
                SERVICE.store.conn.execute("UPDATE voic3_meetings SET is_locked=1 WHERE id=?", (mid,))
            elif action == "unlock":
                SERVICE.store.conn.execute("UPDATE voic3_meetings SET is_locked=0 WHERE id=?", (mid,))
            elif action == "spotlight":
                SERVICE.store.conn.execute("UPDATE voic3_meetings SET spotlight_employee_id=? WHERE id=?", (int(target) if target else None, mid))
            elif action == "end_for_all":
                SERVICE.store.conn.execute("UPDATE voic3_meetings SET status='ended' WHERE id=?", (mid,))
                SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET state='left',left_at=? WHERE meeting_id=?", (iso_now(), mid))
            SERVICE.store.conn.commit()
            publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_meeting_participants WHERE meeting_id=?", (mid,)).fetchall()], "meeting.action", {"meeting_id": mid, "action": action, "target": target})
            self.send_json(200, {"ok": True}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/raise-hand", path)
        if m and method == "POST":
            mid = int(m.group(1))
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            SERVICE.store.conn.execute("UPDATE voic3_meeting_participants SET hand_raised=? WHERE meeting_id=? AND employee_id=?", (1 if data.get("raised") else 0, mid, eid))
            SERVICE.store.conn.commit()
            publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_meeting_participants WHERE meeting_id=?", (mid,)).fetchall()], "meeting.hand", {"meeting_id": mid, "employee_id": eid, "raised": bool(data.get("raised"))})
            self.send_json(200, {"ok": True}); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/emoji", path)
        if m and method == "POST":
            mid = int(m.group(1))
            emoji = clean(data.get("emoji") or "")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_meeting_participants WHERE meeting_id=?", (mid,)).fetchall()], "meeting.emoji", {"meeting_id": mid, "employee_id": eid, "emoji": emoji})
            self.send_json(200, {"ok": True}); return

        # Section 10: peer-to-peer signalling for the meeting mesh. The desktop
        # and mobile clients exchange offers/answers/ICE here; without it a
        # meeting can only show participant tiles, never media.
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/signal", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            if not SERVICE.store.conn.execute("SELECT id FROM voic3_meetings WHERE id=?", (mid,)).fetchone():
                raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            me = SERVICE.store.conn.execute(
                "SELECT state FROM voic3_meeting_participants WHERE meeting_id=? AND employee_id=?", (mid, eid)).fetchone()
            host = SERVICE.store.conn.execute(
                "SELECT host_employee_id FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not (me and me["state"] == "admitted") and not (host and int(host["host_employee_id"]) == eid):
                raise PermissionError("Join this meeting first.")
            kind = clean(data.get("kind"))
            if kind not in ("offer", "answer", "ice"):
                raise ValueError("Signal kind must be offer, answer or ice.")
            target = data.get("target")
            payload = data.get("payload")
            if not payload: raise ValueError("Signal payload required.")
            recipients = [int(target)] if target else [
                int(r[0]) for r in SERVICE.store.conn.execute(
                    "SELECT employee_id FROM voic3_meeting_participants WHERE meeting_id=? AND state='admitted' AND employee_id<>?",
                    (mid, eid)).fetchall()]
            for other in recipients:
                publish_voic3_event([other], "meeting.signal",
                                    {"meeting_id": mid, "from": eid, "kind": kind, "payload": payload})
            self.send_json(200, {"ok": True, "relayed": len(recipients)}); return

        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/emoji", path)
        if m and method == "POST":
            mid = int(m.group(1))
            emoji = clean(data.get("emoji") or "")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if row: eid = int(row["id"])
                except Exception: eid = None
            publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_meeting_participants WHERE meeting_id=?", (mid,)).fetchall()], "meeting.emoji", {"meeting_id": mid, "employee_id": eid, "emoji": emoji})
            self.send_json(200, {"ok": True}); return

        # ------------------------------------------------------------------
        # Section 15: optional LiveKit SFU, E2EE keys and local transcription.
        # All three degrade to the existing peer-to-peer path when unconfigured.
        # ------------------------------------------------------------------
        if path == "/api/voic3/rtc/capabilities" and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            self.send_json(200, voic3_sfu.capabilities()); return

        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/rtc-token", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            meet = SERVICE.store.conn.execute(
                "SELECT host_employee_id,status,is_locked FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not meet: raise KeyError("Meeting not found.")
            if meet["status"] != "active": raise ValueError("This meeting has ended.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            part = SERVICE.store.conn.execute(
                "SELECT state FROM voic3_meeting_participants WHERE meeting_id=? AND employee_id=?", (mid, eid)).fetchone()
            is_host = int(meet["host_employee_id"]) == eid
            is_admin = bool(actor and SERVICE.role_for(actor) in ("Administrator", "Manager"))
            # A waiting-room participant never receives a media token.
            if not (is_host or is_admin) and not (part and part["state"] == "admitted"):
                raise PermissionError("Wait for the host to admit you.")
            if meet["is_locked"] and not (is_host or is_admin):
                raise PermissionError("Meeting is locked.")
            if not voic3_sfu.livekit_enabled():
                self.send_json(200, {"enabled": False, "transport": "p2p",
                                     "e2ee": voic3_sfu.key_payload(mid) if voic3_sfu.e2ee_enabled() else None}); return
            who = SERVICE.store.conn.execute(
                "SELECT first_name,last_name FROM employees WHERE id=?", (eid,)).fetchone()
            display = ("%s %s" % (who["first_name"] or "", who["last_name"] or "")).strip() if who else ""
            token = voic3_sfu.access_token(mid, eid, display, can_publish=True,
                                           e2ee=voic3_sfu.e2ee_enabled(), admin=bool(is_host or is_admin))
            self.send_json(200, {
                "enabled": True, "transport": "sfu",
                "url": voic3_sfu.livekit_url(),
                "room": voic3_sfu.room_name(mid),
                "identity": "emp-%d" % eid,
                "token": token,
                "is_host": bool(is_host),
                "e2ee": voic3_sfu.key_payload(mid) if voic3_sfu.e2ee_enabled() else None,
            }); return

        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/e2ee-key", path)
        if m and method in ("GET", "POST"):
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            meet = SERVICE.store.conn.execute(
                "SELECT host_employee_id,status FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not meet: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            part = SERVICE.store.conn.execute(
                "SELECT state FROM voic3_meeting_participants WHERE meeting_id=? AND employee_id=?", (mid, eid)).fetchone()
            if not (int(meet["host_employee_id"]) == eid or (part and part["state"] == "admitted")):
                raise PermissionError("Wait for the host to admit you.")
            if not voic3_sfu.e2ee_enabled():
                self.send_json(200, {"enabled": False}); return
            payload = voic3_sfu.key_payload(mid)
            payload["enabled"] = True
            self.send_json(200, payload); return

        m = re.fullmatch(r"/api/voic3/attachments/(\d+)/transcribe", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            aid = int(m.group(1))
            att = SERVICE.store.conn.execute(
                "SELECT * FROM voic3_attachments WHERE id=?", (aid,)).fetchone()
            if not att: raise KeyError("Attachment not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            if not (int(att["employee_id"] or 0) == eid or (actor and SERVICE.role_for(actor) in ("Administrator", "Manager"))):
                raise PermissionError("Only the uploader or a manager can transcribe this recording.")
            if not voic3_sfu.transcription_available():
                self.send_json(503, {"error": "Local transcription is not installed on this server. "
                                              "Install faster-whisper to enable it; the recording itself is unaffected.",
                                     "engine": ""}); return
            cached = SERVICE.store.conn.execute(
                "SELECT transcript_json FROM voic3_attachments WHERE id=?", (aid,)).fetchone()
            cached_txt = (cached["transcript_json"] if cached else "") or ""
            if cached_txt and not data.get("force"):
                try:
                    self.send_json(200, json.loads(cached_txt)); return
                except Exception:
                    pass
            path_on_disk = att["storage_path"] or ""
            if not path_on_disk or not os.path.exists(path_on_disk):
                raise KeyError("The recording file is no longer on this server.")
            try:
                result = voic3_sfu.transcribe_file(path_on_disk, voic3_sfu.safe_language(data.get("language")))
            except RuntimeError as exc:
                self.send_json(503, {"error": str(exc)}); return
            result["attachment_id"] = aid
            try:
                SERVICE.store.conn.execute("UPDATE voic3_attachments SET transcript_json=? WHERE id=?",
                                           (json.dumps(result, ensure_ascii=False), aid))
                SERVICE.store.conn.commit()
            except Exception:
                pass
            SERVICE.store.log(actor or ("emp-%d" % eid), "Transcribed recording", "voic3_attachment", aid,
                              "%s · %s" % (result.get("engine"), result.get("language")))
            SERVICE.store.conn.commit()
            self.send_json(200, result); return

        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/recording", path)
        if m and method == "POST":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            row = SERVICE.store.conn.execute("SELECT host_employee_id,conversation_id FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not row: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            is_host = int(row["host_employee_id"]) == eid
            is_admin = bool(actor and SERVICE.role_for(actor) == "Administrator")
            if not (is_host or is_admin): raise PermissionError("Host only.")
            import base64 as _b64, uuid as _uuid
            raw = data.get("data") or ""
            if "," in raw: raw = raw.split(",", 1)[1]
            if not raw: raise ValueError("Recording data required.")
            # A long meeting makes a long recording. Cap one upload so it can
            # never exhaust memory or freeze the server; the phone records in parts.
            MAX_RECORDING_BYTES = 25 * 1024 * 1024
            if len(raw) > MAX_RECORDING_BYTES * 4 // 3 + 4096:
                raise ValueError("Recording is too large for one upload. Keep it under 25 MB or record in parts.")
            try:
                blob = _b64.b64decode(raw, validate=False)
            except Exception: raise ValueError("Invalid recording data.")
            if not blob: raise ValueError("Recording is empty.")
            if len(blob) > 200 * 1024 * 1024: raise ValueError("Recording too large (200MB limit).")
            # Saved beside the other VOIC3 uploads and only ever served back through
            # the authenticated /api/voic3/attachments/<id> route.
            ddir = legacy.DATA_HOME / "voic3_uploads"
            ddir.mkdir(parents=True, exist_ok=True)
            stamp = iso_now()
            label = "%s-meeting-%d-%s.webm" % (stamp.replace(":", "").replace(" ", "T"), mid, _uuid.uuid4().hex[:8])
            fpath = ddir / label
            fpath.write_bytes(blob)
            cur = SERVICE.store.conn.execute("INSERT INTO voic3_attachments(employee_id,filename,mime_type,size_bytes,storage_path,created_at) VALUES(?,?,?,?,?,?)", (eid, label, "video/webm", len(blob), str(fpath), stamp))
            aid = int(cur.lastrowid)
            size_mb = round(len(blob) / (1024.0 * 1024.0), 2)
            link = "/api/voic3/attachments/%d" % aid
            notice = "Meeting recording ready (%s MB). Sign in to VOIC3 and open: %s" % (size_mb, link)
            cid = row["conversation_id"]
            posted = None
            if cid:
                cur2 = SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at,conversation_id,message_type) VALUES(?,?,?,?,?,?,?,?,?)", (str(eid), "", None, None, "Meeting recording", notice, stamp, int(cid), "call_log"))
                posted = int(cur2.lastrowid or 0)
            SERVICE.store.conn.commit()
            try:
                publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_meeting_participants WHERE meeting_id=?", (mid,)).fetchall()], "meeting.recording", {"meeting_id": mid, "attachment_id": aid, "employee_id": eid, "conversation_id": cid})
                if cid:
                    publish_voic3_event([r[0] for r in SERVICE.store.conn.execute("SELECT employee_id FROM voic3_members WHERE conversation_id=?", (int(cid),)).fetchall()], "message.new", {"conversation_id": int(cid), "message_id": posted})
            except Exception:
                pass
            try:
                SERVICE.store.log(actor or ("employee:%s" % eid), "Saved meeting recording", "voic3_meeting", mid, "%d bytes" % len(blob))
            except Exception:
                pass
            self.send_json(201, {"id": aid, "attachment_id": aid, "filename": label, "url": link, "size_bytes": len(blob), "conversation_id": cid, "message_id": posted}); return

        m = re.fullmatch(r"/api/voic3/meetings/(\d+)", path)
        if m and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            meeting = SERVICE.store.conn.execute("SELECT * FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not meeting: raise KeyError("Meeting not found.")
            meeting = dict(meeting)
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            me = SERVICE.store.conn.execute("SELECT state,is_muted_by_host,hand_raised FROM voic3_meeting_participants WHERE meeting_id=? AND employee_id=?", (mid, eid)).fetchone()
            is_host = int(meeting["host_employee_id"]) == eid
            if not me and not is_host and not (actor and SERVICE.role_for(actor) == "Administrator"):
                raise PermissionError("Join this meeting first.")
            participants = SERVICE.query("SELECT p.employee_id,p.state,p.is_muted_by_host,p.hand_raised,p.joined_at,p.left_at,e.first_name,e.last_name,e.job_title FROM voic3_meeting_participants p LEFT JOIN employees e ON e.id=p.employee_id WHERE p.meeting_id=? ORDER BY p.joined_at", (mid,))
            for p in participants:
                p["name"] = ((p.get("first_name") or "") + " " + (p.get("last_name") or "")).strip() or str(p.get("employee_id"))
                p["is_host"] = int(p["employee_id"]) == int(meeting["host_employee_id"])
                p["is_me"] = int(p["employee_id"]) == eid
            meeting["is_host"] = is_host
            meeting["me"] = dict(me) if me else {"state": "admitted" if is_host else "waiting", "is_muted_by_host": 0, "hand_raised": 0}
            meeting["participants"] = participants
            meeting["waiting"] = [p for p in participants if p.get("state") == "waiting"]
            meeting["server_time"] = iso_now()
            self.send_json(200, meeting); return
        m = re.fullmatch(r"/api/voic3/meetings/(\d+)/poll", path)
        if m and method == "GET":
            if not actor and not mobile_eid: raise PermissionError("Authentication required.")
            mid = int(m.group(1))
            meeting = SERVICE.store.conn.execute("SELECT host_employee_id,status,is_locked,spotlight_employee_id FROM voic3_meetings WHERE id=?", (mid,)).fetchone()
            if not meeting: raise KeyError("Meeting not found.")
            eid = mobile_eid
            if eid is None and actor:
                try:
                    r = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                    if r: eid = int(r["id"])
                except Exception: eid = None
            if eid is None: raise PermissionError("Authentication required.")
            me = SERVICE.store.conn.execute("SELECT state,is_muted_by_host,hand_raised FROM voic3_meeting_participants WHERE meeting_id=? AND employee_id=?", (mid, eid)).fetchone()
            participants = SERVICE.query("SELECT p.employee_id,p.state,p.is_muted_by_host,p.hand_raised,e.first_name,e.last_name FROM voic3_meeting_participants p LEFT JOIN employees e ON e.id=p.employee_id WHERE p.meeting_id=? ORDER BY p.joined_at", (mid,))
            for p in participants:
                p["name"] = ((p.get("first_name") or "") + " " + (p.get("last_name") or "")).strip() or str(p.get("employee_id"))
                p["is_host"] = int(p["employee_id"]) == int(meeting["host_employee_id"])
                p["is_me"] = int(p["employee_id"]) == eid
            self.send_json(200, {"id": mid, "status": meeting["status"], "is_locked": int(meeting["is_locked"]), "spotlight_employee_id": meeting["spotlight_employee_id"], "is_host": int(meeting["host_employee_id"]) == eid, "me": dict(me) if me else {"state": "waiting", "is_muted_by_host": 0, "hand_raised": 0}, "participants": participants, "server_time": iso_now()}); return

        # Employee mobile authentication and self-service API. Employee accounts are
        # provisioned by an authenticated Windows administrator via /api/mobile/accounts.
        if path == "/api/mobile/people" and method == "GET":
            # The phone's sign-in screen shows a name picker instead of asking people
            # to remember an employee number. Only accounts that are switched on and
            # belong to an active employee are listed - nothing else, and no data
            # about them. A name is needed to pick a row; the password still decides.
            rows = SERVICE.query("""SELECT e.employee_no, e.first_name, e.last_name, e.job_title, e.department
                                    FROM employees e JOIN mobile_accounts a ON a.employee_id = e.id
                                    WHERE a.active = 1 AND e.employment_status = 'Active'
                                    ORDER BY e.first_name COLLATE NOCASE, e.last_name COLLATE NOCASE""")
            people = [{"employee_no": r["employee_no"],
                       "name": (str(r["first_name"] or "") + " " + str(r["last_name"] or "")).strip(),
                       "role": r["job_title"] or r["department"] or ""} for r in rows]
            self.send_json(200, {"items": people, "count": len(people)}, {"Cache-Control": "no-store"}); return
        if path == "/api/mobile/login" and method == "POST":
            employee_no=clean(data.get("employee_no")); password=str(data.get("password") or "")
            failures=[t for t in SERVICE.login_failures.get(employee_no.casefold(),[]) if time.time()-t < 900]
            SERVICE.login_failures[employee_no.casefold()]=failures
            if len(failures) >= 5:
                self.send_json(429,{"error":"Too many failed sign-in attempts. Try again in 15 minutes."},{"Retry-After":"900"}); return
            row=_sign_in_row(lambda: SERVICE.store.conn.execute("SELECT e.id,e.employee_no,e.first_name,e.last_name,a.password_hash,a.mobile_profile FROM employees e JOIN mobile_accounts a ON a.employee_id=e.id WHERE e.employee_no=? COLLATE NOCASE AND a.active=1 AND e.employment_status='Active'",(employee_no,)).fetchone())
            if not row:
                # The picker may send the person's name. Only a single exact
                # match is accepted; two people with the same name must use their
                # employee number, so the wrong account can never be opened.
                wanted = clean(data.get("employee_no"))
                matches = _sign_in_row(lambda: SERVICE.query("""SELECT e.id,e.employee_no,e.first_name,e.last_name,a.password_hash,a.mobile_profile
                                           FROM employees e JOIN mobile_accounts a ON a.employee_id=e.id
                                           WHERE a.active=1 AND e.employment_status='Active'
                                             AND TRIM(e.first_name||' '||e.last_name)=? COLLATE NOCASE""",(wanted,)))
                if len(matches) == 1: row = matches[0]
            if not row or not legacy.verify_password(password,row["password_hash"]):
                SERVICE.login_failures.setdefault(employee_no.casefold(),[]).append(time.time())
                # Authentication failure is 401, not 403 (the handler reserves 403
                # for an authenticated user who lacks permission).
                self.send_json(401,{"error":"Employee number or password is incorrect, or mobile access is disabled."}); return
            SERVICE.login_failures.pop(employee_no.casefold(),None)
            token=secrets.token_urlsafe(40); SERVICE.mobile_sessions[token]=int(row["id"]); SERVICE.mobile_profiles[token]=clean(row["mobile_profile"]) or "staff"
            SERVICE.mobile_session_expiries[token]=time.time()+43200
            SERVICE.save_sessions()
            secure="; Secure" if self.headers.get("X-Forwarded-Proto", "").lower()=="https" else ""
            # The role decides which tabs this phone shows. Additive: the old
            # "profile" field is still sent, so nothing that reads it breaks.
            try:
                import roles as _roles
                _role = _roles.describe(clean(row["mobile_profile"]) or "staff")
            except Exception:
                _role = {"role": "representative", "label": "Representative", "group": "Company",
                         "home": "home", "tabs": ["home", "settings"], "can": []}
            self.send_json(200,{"ok":True,"employee":{"id":row["id"],"employee_no":row["employee_no"],"name":(row["first_name"]+" "+row["last_name"]).strip(),"profile":clean(row["mobile_profile"]) or "staff","role":_role["role"],"role_label":_role["label"],"home_tab":_role["home"],"tabs":_role["tabs"],"can":_role["can"]}},{"Set-Cookie":f"br_mobile={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200{secure}"}); return
        if path == "/api/mobile/logout" and method == "POST":
            if mobile_sid: SERVICE.mobile_sessions.pop(mobile_sid,None); SERVICE.mobile_profiles.pop(mobile_sid,None); SERVICE.mobile_session_expiries.pop(mobile_sid,None)
            SERVICE.save_sessions()
            self.send_json(200,{"ok":True},{"Set-Cookie":"br_mobile=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict"}); return
        if path == "/api/mobile/password" and method == "POST":
            # A phone user changes their OWN password. Additive: a new route,
            # nothing existing is touched. The old password is required so a
            # borrowed unlocked phone cannot be taken over.
            if not mobile_sid or mobile_sid not in SERVICE.mobile_sessions:
                self.send_json(401,{"error":"Sign in again to change your password."}); return
            current=str(data.get("current_password") or ""); fresh=str(data.get("new_password") or "")
            eid=int(SERVICE.mobile_sessions.get(mobile_sid) or 0)
            row=SERVICE.store.conn.execute("SELECT password_hash FROM mobile_accounts WHERE employee_id=?",(eid,)).fetchone()
            if not row: self.send_json(404,{"error":"No mobile account found for this sign-in."}); return
            if not legacy.verify_password(current,row["password_hash"]):
                self.send_json(403,{"error":"Your current password is not correct."}); return
            if len(fresh)<8: self.send_json(400,{"error":"Choose a password of at least 8 characters."}); return
            if fresh==current: self.send_json(400,{"error":"Choose a password different from your current one."}); return
            SERVICE.store.conn.execute("UPDATE mobile_accounts SET password_hash=?,updated_at=? WHERE employee_id=?",
                                       (legacy.hash_password(fresh),iso_now(),eid))
            SERVICE.store.log("mobile:"+str(eid),"Changed own mobile password","mobile_account",eid,"Self-service")
            SERVICE.store.conn.commit()
            legacy.flush_all()   # a password change is written at once, not a few seconds later
            self.send_json(200,{"ok":True}); return
        if path == "/api/mobile/accounts" and method == "POST":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can manage mobile employee accounts."}); return
            eid=int(data.get("employee_id") or 0); password=str(data.get("password") or ""); mprofile=clean(data.get("profile")) or "staff"
            if mprofile not in ("admin","staff"): raise ValueError("Mobile profile must be admin or staff.")
            if not SERVICE.store.employee(eid): raise ValueError("Choose a valid employee.")
            if len(password)<8: raise ValueError("Mobile passwords must contain at least 8 characters.")
            stamp=iso_now(); digest=legacy.hash_password(password)
            SERVICE.store.conn.execute("INSERT INTO mobile_accounts(employee_id,password_hash,active,mobile_profile,created_at,updated_at) VALUES(?,?,1,?,?,?) ON CONFLICT(employee_id) DO UPDATE SET password_hash=excluded.password_hash,active=1,mobile_profile=excluded.mobile_profile,updated_at=excluded.updated_at",(eid,digest,mprofile,stamp,stamp))
            SERVICE.store.log(actor,"Provisioned employee mobile access","mobile_account",eid,"Password set/reset by administrator")
            SERVICE.store.conn.commit(); legacy.flush_all(); self.send_json(200,{"ok":True}); return
        if path == "/api/mobile/accounts" and method == "GET":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can view mobile employee accounts."}); return
            items=SERVICE.query("""SELECT e.id AS employee_id,e.employee_no,e.first_name,e.last_name,e.department,e.employment_status,COALESCE(a.active,0) AS account_active,CASE WHEN a.employee_id IS NULL THEN 0 ELSE 1 END AS account_exists,COALESCE(a.mobile_profile,'staff') AS mobile_profile FROM employees e LEFT JOIN mobile_accounts a ON a.employee_id=e.id ORDER BY e.last_name,e.first_name""")
            for item in items: item["active"]=bool(item["account_active"]) and item["account_exists"]==1
            self.send_json(200,{"items":items}); return
        m=re.fullmatch(r"/api/mobile/accounts/(\d+)/delete",path)
        if m and method == "POST":
            # A person who no longer works here keeps their employee record (for
            # history, payroll and audit) but loses the phone login completely.
            # Their live sessions are ended at once, so a phone still signed in
            # stops working on its next request.
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can manage mobile employee accounts."}); return
            eid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT e.employee_no,e.first_name,e.last_name FROM employees e WHERE e.id=?",(eid,)).fetchone()
            if not row: raise KeyError("Employee not found.")
            ended=0
            for token,value in list(SERVICE.mobile_sessions.items()):
                if int(value)==eid:
                    SERVICE.mobile_sessions.pop(token,None); SERVICE.mobile_session_expiries.pop(token,None); SERVICE.mobile_profiles.pop(token,None); ended+=1
            SERVICE.save_sessions()
            SERVICE.store.conn.execute("DELETE FROM mobile_accounts WHERE employee_id=?",(eid,))
            SERVICE.store.log(actor,"Deleted employee mobile access","mobile_account",eid,
                              f"{row['first_name']} {row['last_name']} ({row['employee_no']}) - account removed, {ended} session(s) ended")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"sessions_ended":ended}); return
        m=re.fullmatch(r"/api/mobile/accounts/(\d+)/active",path)
        if m and method == "POST":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can manage mobile employee accounts."}); return
            eid=int(m.group(1)); active=bool(data.get("active"))
            if not SERVICE.store.employee(eid): raise KeyError("Employee not found.")
            stamp=iso_now()
            SERVICE.store.conn.execute("INSERT INTO mobile_accounts(employee_id,password_hash,active,created_at,updated_at) VALUES(?,?,?, ?,?) ON CONFLICT(employee_id) DO UPDATE SET active=excluded.active,updated_at=excluded.updated_at",(eid,"",1 if active else 0,stamp,stamp))
            if not active:
                for token,value in list(SERVICE.mobile_sessions.items()):
                    if int(value)==eid:
                        SERVICE.mobile_sessions.pop(token,None); SERVICE.mobile_session_expiries.pop(token,None); SERVICE.mobile_profiles.pop(token,None)
                SERVICE.save_sessions()
            SERVICE.store.log(actor,"Changed employee mobile access","mobile_account",eid,"Enabled" if active else "Disabled")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"active":active}); return
        # Mobile app self-update: the server advertises the APK it can serve so phones
        # can detect and install newer builds without a manual file transfer.
        def mobile_apk_info():
            # The package this server actually hands out is the one it ships with:
            # tools/N3XUS.apk. It used to serve an older build from android-honor/,
            # so "Update" downloaded a different, outdated app and the bar never
            # went away. The version is read from the APK itself, so it is always
            # the truth about the file being served.
            apk = Path(os.environ.get("BR_APK_PATH", "").strip() or (APP_ROOT / "tools" / "N3XUS.apk"))
            version = ""
            vcode = 0
            try:
                import subprocess as _sp
                import re as _re
                # aapt2 ships with the Android build tools and reads the binary
                # manifest properly; scraping the bytes was unreliable.
                aapt = Path(os.environ.get("BR_AAPT2", "").strip())
                if not aapt.is_file():
                    sdk = Path(os.environ.get("LOCALAPPDATA", "")) / "Android" / "Sdk" / "build-tools"
                    found = sorted(sdk.glob("*/aapt2.exe")) if sdk.is_dir() else []
                    aapt = found[-1] if found else Path("")
                if aapt.is_file():
                    out = _sp.run([str(aapt), "dump", "badging", str(apk)],
                                  capture_output=True, text=True, timeout=20).stdout
                    vm = _re.search(r"versionName='([^']+)'", out)
                    vc = _re.search(r"versionCode='(\d+)'", out)
                    if vm:
                        version = vm.group(1)
                    if vc:
                        vcode = int(vc.group(1))
            except Exception:
                pass
            return apk, version, vcode
        def _chat_names():
            """employee_no -> "First Last", and id -> "First Last".

            Chat threads are keyed by whoever sent or received a message, and that
            key is stored as "mobile:001" or "management". Nobody wants to read
            that in a chat list, so every thread is resolved to a real name here.
            Read-only, and empty rather than raising if the lookup fails.
            """
            by_no, by_id = {}, {}
            try:
                for r in SERVICE.query("SELECT id,employee_no,first_name,last_name FROM employees"):
                    full = ((r.get("first_name") or "") + " " + (r.get("last_name") or "")).strip()
                    if not full:
                        continue
                    if r.get("employee_no"):
                        by_no[str(r["employee_no"]).strip().lower()] = full
                    by_id[int(r["id"])] = full
            except Exception:
                pass
            return by_no, by_id

        if path == "/api/mobile/ice-servers" and method == "GET":
            # The messenger's ICE list, free of sign-in on purpose: a call that
            # cannot even ask for its relay is a call that fails on mobile data.
            # Only short-lived relay credentials are handed out, never the API key.
            # The local coturn relay leads the list: the app keeps the first
            # non-empty answer, and the public fallback relay went dark.
            self.send_json(200, {"iceServers": _local_turn_ice_list(_public_ice_servers()), "ttl": 600}); return
        if path == "/api/mobile/app-version" and method == "GET":
            apk,version,vcode=mobile_apk_info()
            # The phone uses this answer for two things: to find the server, and to
            # update itself. On mobile data a LAN address is useless, so the live
            # tunnel hostname is published here too (read from cloudflared's own
            # metrics port - empty when the tunnel is down, never a stale name).
            # Every URL listed is probed by the app before it is used.
            urls=[]
            try:
                _host=_tunnel_hostname()
                if _host: urls.append("https://%s/mobile/" % _host)
            except Exception:
                pass
            try:
                _port=getattr(SERVICE,"server_port",0) or int(os.environ.get("BR_SERVER_PORT","64281") or 0)
                import br_connect as _bc
                for _ip in _bc.local_addresses():
                    urls.append("https://%s:%s/mobile/" % (_ip,_port))
            except Exception:
                pass
            self.send_json(200,{"version":version,"version_code":vcode,"apk_available":apk.is_file(),"apk_url":"/api/mobile/app-update.apk" if apk.is_file() else "","size":apk.stat().st_size if apk.is_file() else 0,"urls":urls}); return
        if path == "/api/mobile/app-update.apk" and method == "GET":
            apk,_,_=mobile_apk_info()
            if not apk.is_file(): raise KeyError("No Android package is available on this server yet.")
            raw=apk.read_bytes()
            self.send_response(200); self.send_header("Content-Type","application/vnd.android.package-archive"); self.send_header("Content-Disposition",'attachment; filename="BeyondRegistration-Mobile.apk"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
        if path.startswith("/api/mobile/"):
            if not mobile_eid:
                self.send_json(401,{"error":"Mobile session expired. Please sign in again."}); return
            emp=SERVICE.store.employee(mobile_eid)
            if not emp: raise PermissionError("Employee account is no longer available.")
            mobile_admin=SERVICE.mobile_profiles.get(mobile_sid)=="admin"
            mobile_actor="mobile:"+str(emp["employee_no"])
            device_key=clean(self.headers.get("X-Device-Key"))[:80]
            device_class="staff"
            if device_key:
                drow=SERVICE.store.conn.execute("SELECT device_class FROM mobile_devices WHERE device_key=?",(device_key,)).fetchone()
                if drow: device_class=clean(drow["device_class"]) or "staff"
            is_company_device=(device_class=="company")
            mobile_patient_ids=None
            def mobile_patient_ok(pid):
                nonlocal mobile_patient_ids
                if mobile_admin: return True
                if mobile_patient_ids is None:
                    mobile_patient_ids={int(r["patient_id"]) for r in SERVICE.query("SELECT patient_id FROM patient_access WHERE principal_type='employee' AND principal_id=? AND active=1",(mobile_eid,))}
                return int(pid) in mobile_patient_ids
            if path=="/api/mobile/me" and method=="GET":
                self.send_json(200,{"employee":{"id":emp["id"],"employee_no":emp["employee_no"],"name":(emp["first_name"]+" "+emp["last_name"]).strip(),"job_title":emp["job_title"],"department":emp["department"],"email":emp["email"],"profile":SERVICE.mobile_profiles.get(mobile_sid,"staff"),"device_class":device_class,**_role_payload(SERVICE.mobile_profiles.get(mobile_sid,"staff"))}}); return
            if path=="/api/mobile/prefs" and method=="GET":
                mkey=f"mobile:{mobile_eid}"
                row=SERVICE.store.conn.execute("SELECT prefs_json FROM user_prefs WHERE user_key=?",(mkey,)).fetchone()
                try: mprefs=json.loads(row["prefs_json"]) if row else {}
                except Exception: mprefs={}
                self.send_json(200,{"prefs":mprefs if isinstance(mprefs,dict) else {}}); return
            if path=="/api/mobile/prefs" and method=="PUT":
                mprefs=data.get("prefs")
                if not isinstance(mprefs,dict): raise ValueError("prefs must be an object.")
                blob=json.dumps(mprefs,ensure_ascii=False)
                if len(blob.encode("utf-8"))>200_000: raise ValueError("Saved preferences are too large.")
                mkey=f"mobile:{mobile_eid}"; stamp=iso_now()
                SERVICE.store.conn.execute("INSERT INTO user_prefs(user_key,prefs_json,updated_at) VALUES(?,?,?) ON CONFLICT(user_key) DO UPDATE SET prefs_json=excluded.prefs_json,updated_at=excluded.updated_at",(mkey,blob,stamp))
                SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
            if path=="/api/mobile/dashboard" and method=="GET":
                balances=SERVICE.query("SELECT b.leave_type,b.opening_days,b.accrued_days,(b.opening_days+b.accrued_days-COALESCE((SELECT SUM(l.days) FROM leave_records l WHERE l.employee_id=b.employee_id AND l.leave_type=b.leave_type AND l.status='Approved'),0)) AS available_days FROM leave_balances b WHERE b.employee_id=? ORDER BY b.leave_type",(mobile_eid,))
                leave=SERVICE.query("SELECT id,leave_type,date_from,date_to,days,status,created_at FROM leave_records WHERE employee_id=? ORDER BY id DESC LIMIT 5",(mobile_eid,))
                payslips=SERVICE.query("SELECT id,pay_period,pay_date,net_pay,status FROM payroll_records WHERE employee_id=? AND status IN ('Approved','Sent','Paid') ORDER BY pay_period DESC LIMIT 3",(mobile_eid,))
                docs=SERVICE.query("SELECT COUNT(*) AS count FROM employee_documents WHERE employee_id=?",(mobile_eid,))[0]["count"]
                self.send_json(200,{"balances":balances,"recent_leave":leave,"payslips":payslips,"document_count":docs}); return
            if path=="/api/mobile/leave" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT id,leave_type,date_from,date_to,days,reason,status,created_at FROM leave_records WHERE employee_id=? ORDER BY date_from DESC LIMIT 200",(mobile_eid,))}); return
            if path=="/api/mobile/leave" and method=="POST":
                typ=clean(data.get("leave_type")); d1=clean(data.get("date_from")); d2=clean(data.get("date_to")); reason=clean(data.get("reason"))
                try:
                    start=date.fromisoformat(d1); end=date.fromisoformat(d2)
                except ValueError as exc: raise ValueError("Choose valid leave dates.") from exc
                if end<start: raise ValueError("End date must be on or after the start date.")
                days=sum(1 for n in range((end-start).days+1) if (start+timedelta(days=n)).weekday()<5)
                if not typ or days<1: raise ValueError("Choose a leave type and at least one working day.")
                stamp=iso_now(); cur=SERVICE.store.conn.execute("INSERT INTO leave_records(employee_id,leave_type,date_from,date_to,days,reason,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,'Pending',?,?,?)",(mobile_eid,typ,d1,d2,days,reason,"Mobile employee",stamp,stamp))
                rid=int(cur.lastrowid); SERVICE.store.log("mobile:"+str(emp["employee_no"]),"Submitted mobile leave application","leave",rid,f"{typ}; {d1} to {d2}"); SERVICE.notify_owners("Leave request submitted", f"{emp['first_name']} {emp['last_name']} requested {typ} {d1} to {d2}"); SERVICE.store.conn.commit(); self.send_json(201,{"id":rid,"days":days,"status":"Pending"}); return
            if path=="/api/mobile/payslips" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT id,pay_period,pay_date,gross_pay,total_deductions,net_pay,status FROM payroll_records WHERE employee_id=? AND status IN ('Approved','Sent','Paid') ORDER BY pay_period DESC LIMIT 60",(mobile_eid,))}); return
            m=re.fullmatch(r"/api/mobile/payslips/(\d+)/pdf",path)
            if m and method=="GET":
                rid=int(m.group(1)); row=SERVICE.store.conn.execute("SELECT employee_id,status FROM payroll_records WHERE id=?",(rid,)).fetchone()
                if not row or int(row["employee_id"])!=mobile_eid or clean(row["status"]) not in ("Approved","Sent","Paid"): raise PermissionError("This payslip is not available to your account.")
                raw,number=SERVICE.payslip_pdf(rid); self.send_response(200); self.send_header("Content-Type","application/pdf"); self.send_header("Content-Disposition",f'attachment; filename="{number}.pdf"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
            if path=="/api/mobile/documents" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT id,document_type,title,document_number,issue_date,expiry_date,status,file_name,created_at FROM employee_documents WHERE employee_id=? ORDER BY id DESC LIMIT 200",(mobile_eid,))}); return
            if path=="/api/mobile/documents" and method=="POST":
                title=clean(data.get("title")); category=clean(data.get("document_type")); filename=clean(data.get("filename")); encoded=data.get("data")
                if not title or not category or not isinstance(encoded,str): raise ValueError("Document title, category and file are required.")
                upload=SERVICE.save_upload({"filename":filename,"data":encoded},"documents"); stamp=iso_now()
                cur=SERVICE.store.conn.execute("INSERT INTO employee_documents(employee_id,document_type,title,status,file_path,file_name,created_by,created_at,updated_at) VALUES(?,?,?,'Pending review',?,?,?,?,?)",(mobile_eid,category,title,upload["file_path"],upload["file_name"],"Mobile employee",stamp,stamp))
                SERVICE.store.log("mobile:"+str(emp["employee_no"]),"Uploaded mobile employee document","document",cur.lastrowid,category+" / "+title); SERVICE.notify_owners("Document uploaded", f"{emp['first_name']} {emp['last_name']} uploaded {category}: {title}"); SERVICE.store.conn.commit(); self.send_json(201,{"id":cur.lastrowid,"status":"Pending review"}); return
            m=re.fullmatch(r"/api/mobile/documents/(\d+)/file",path)
            if m and method=="GET":
                did=int(m.group(1))
                row=SERVICE.store.conn.execute("SELECT employee_id,file_path,file_name FROM employee_documents WHERE id=?",(did,)).fetchone()
                if not row or int(row["employee_id"])!=mobile_eid: raise PermissionError("This document is not available to your account.")
                fp=Path(clean(row["file_path"]))
                if not fp.is_file(): raise KeyError("File not found on server.")
                raw=fp.read_bytes()
                import mimetypes as _mt
                mime=_mt.guess_type(str(fp))[0] or "application/octet-stream"
                self.send_response(200); self.send_header("Content-Type",mime); self.send_header("Content-Disposition",f'inline; filename="{clean(row["file_name"]) or fp.name}"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
            if path=="/api/mobile/reports" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT id,title,description,location,status,photo_name,created_at,updated_at FROM mobile_reports WHERE employee_id=? ORDER BY id DESC LIMIT 100",(mobile_eid,))}); return
            if path=="/api/mobile/reports" and method=="POST":
                title=clean(data.get("title")); desc=clean(data.get("description")); location=clean(data.get("location")); photo_path=""; photo_name=""
                if not title or not desc: raise ValueError("A report title and explanation are required.")
                if data.get("photoData"):
                    up=SERVICE.save_upload({"filename":data.get("photoName") or "report.jpg","data":data["photoData"]},"documents"); photo_path=up["file_path"]; photo_name=up["file_name"]
                stamp=iso_now(); cur=SERVICE.store.conn.execute("INSERT INTO mobile_reports(employee_id,title,description,location,photo_path,photo_name,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'Submitted',?,?)",(mobile_eid,title,desc,location,photo_path,photo_name,stamp,stamp))
                SERVICE.store.log("mobile:"+str(emp["employee_no"]),"Submitted mobile image report","mobile_report",cur.lastrowid,title); SERVICE.store.conn.commit(); self.send_json(201,{"id":cur.lastrowid,"status":"Submitted"}); return
            if path=="/api/mobile/messages" and method=="GET":
                _by_no,_by_id=_chat_names()
                _rows=SERVICE.query("SELECT id,sender,recipient_label,employee_id,subject,body,attachment_name,attachment_mime,CASE WHEN attachment_data IS NULL THEN 0 ELSE 1 END has_attachment,created_at,read_at FROM hub_messages WHERE employee_id=? OR (employee_id IS NULL AND sender=?) ORDER BY id DESC LIMIT 100",(mobile_eid,mobile_actor))
                # A thread is a person or a group, and the phone shows it by name.
                # "mobile:001" is this app's own account key, never something a
                # person should see, so it is resolved here once, on the server.
                for _r in _rows:
                    _s=str(_r.get("sender") or "")
                    if _s.lower().startswith("mobile:"):
                        _no=_s.split(":",1)[1].strip().lower()
                        _r["sender_name"]=_by_no.get(_no) or _s
                    elif _s.lower() in ("management","management / owners"):
                        _r["sender_name"]="Management"
                    elif _s.isdigit() and int(_s) in _by_id:
                        # Management replies are filed under the sender's employee id.
                        _r["sender_name"]=_by_id[int(_s)]
                    else:
                        _r["sender_name"]=_s
                    if _r.get("employee_id") is not None:
                        _r["recipient_name"]=_by_id.get(int(_r["employee_id"])) or str(_r.get("recipient_label") or "")
                    else:
                        _r["recipient_name"]=str(_r.get("recipient_label") or "")
                self.send_json(200,{"items":_rows}); return
            m=re.fullmatch(r"/api/mobile/messages/(\d+)/attachment",path)
            if m and method=="GET":
                row=SERVICE.store.conn.execute("SELECT employee_id,sender FROM hub_messages WHERE id=?",(int(m.group(1)),)).fetchone()
                if not row: raise PermissionError("This attachment is not available to your account.")
                allowed = mobile_admin or (row["employee_id"] is not None and int(row["employee_id"])==mobile_eid) or (row["employee_id"] is None and row["sender"]==mobile_actor)
                if not allowed: raise PermissionError("This attachment is not available to your account.")
                raw,name,mime=SERVICE.hub_attachment(int(m.group(1)))
                self.send_response(200); self.send_header("Content-Type",mime); self.send_header("Content-Disposition",f'attachment; filename="{name}"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
            if path=="/api/mobile/messages/read" and method=="POST":
                # Opening a conversation marks it read, so the unread badge goes
                # away and stays away. A thread is one person or one alert sender,
                # so the update is limited to the caller's own inbox - never a
                # blanket "mark everything read" that would hide other people's work.
                _who = clean(data.get("thread") or data.get("sender") or "")
                _stamp = iso_now()
                if _who:
                    SERVICE.store.conn.execute(
                        "UPDATE hub_messages SET read_at=? WHERE read_at IS NULL AND "
                        "(employee_id=? OR (employee_id IS NULL AND sender=?))",
                        (_stamp, mobile_eid, _who))
                else:
                    SERVICE.store.conn.execute(
                        "UPDATE hub_messages SET read_at=? WHERE read_at IS NULL AND "
                        "(employee_id=? OR (employee_id IS NULL AND sender=?))",
                        (_stamp, mobile_eid, mobile_actor))
                SERVICE.store.conn.commit()
                self.send_json(200, {"ok": True, "read_at": _stamp}); return
            if path=="/api/mobile/messages" and method=="POST":
                body_txt=clean(data.get("body")); subject=clean(data.get("subject")) or ("Message from "+str(emp["first_name"])+" "+str(emp["last_name"])).strip()
                if not body_txt: raise ValueError("Message text is required.")
                if mobile_admin:
                    result=SERVICE.hub_send(dict(data),mobile_actor); self.send_json(201,result); return
                stamp=iso_now()
                cur=SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",(mobile_actor,"Management / Owners",None,"MANAGEMENT",subject[:200],body_txt[:20000],stamp))
                SERVICE.store.log(mobile_actor,"Sent mobile message to management","communications",str(cur.lastrowid),subject[:80]); SERVICE.store.conn.commit(); self.send_json(201,{"id":int(cur.lastrowid)}); return
            if path=="/api/mobile/notifications" and method=="GET":
                unread=SERVICE.query("SELECT COUNT(*) AS c FROM hub_messages WHERE employee_id=? AND read_at IS NULL",(mobile_eid,))[0]["c"]
                pending_contracts=SERVICE.query("SELECT COUNT(*) AS c FROM contract_documents WHERE employee_id=? AND status='Pending'",(mobile_eid,))[0]["c"]
                self.send_json(200,{"unread_messages":int(unread),"pending_contracts":int(pending_contracts)}); return
            if path=="/api/mobile/payslip-requests" and method=="POST":
                pid=int(data.get("payroll_id") or 0); field=clean(data.get("field")); proposed=clean(data.get("proposed_value")); reason=clean(data.get("reason"))
                if not pid or not field or not proposed or not reason: raise ValueError("Payroll record, field, proposed value and reason are required.")
                prow=SERVICE.store.conn.execute("SELECT id,employee_id,status,pay_period FROM payroll_records WHERE id=?",(pid,)).fetchone()
                if not prow or int(prow["employee_id"])!=mobile_eid: raise PermissionError("This payslip does not belong to your account.")
                if clean(prow["status"]) not in ("Approved","Sent","Paid"): raise ValueError("Only approved payslips can be corrected.")
                stamp=iso_now(); cur=SERVICE.store.conn.execute("INSERT INTO payslip_edit_requests(payroll_id,employee_id,requested_by,field,proposed_value,reason,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'Pending',?,?)",(pid,mobile_eid,mobile_actor,field[:80],proposed[:500],reason[:2000],stamp,stamp))
                SERVICE.store.log(mobile_actor,"Requested payslip correction","payroll",str(pid),f"{field}: {proposed[:80]}"); SERVICE.notify_owners("Payslip correction requested", f"{mobile_actor} requested {field}: {proposed[:80]}"); SERVICE.store.conn.commit(); self.send_json(201,{"id":int(cur.lastrowid),"status":"Pending"}); return
            if path=="/api/mobile/contracts" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT id,title,file_name,status,decline_reason,signed_name,decided_at,created_at FROM contract_documents WHERE employee_id=? ORDER BY id DESC LIMIT 50",(mobile_eid,))}); return
            m=re.fullmatch(r"/api/mobile/contracts/(\d+)/pdf",path)
            if m and method=="GET":
                row=SERVICE.store.conn.execute("SELECT employee_id,file_name,mime_type,file_data FROM contract_documents WHERE id=?",(int(m.group(1)),)).fetchone()
                if not row or int(row["employee_id"])!=mobile_eid or row["file_data"] is None: raise PermissionError("This contract is not available to your account.")
                raw=bytes(row["file_data"]); self.send_response(200); self.send_header("Content-Type",clean(row["mime_type"]) or "application/pdf"); self.send_header("Content-Disposition",f'inline; filename="{clean(row["file_name"]) or "contract.pdf"}"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
            m=re.fullmatch(r"/api/mobile/contracts/(\d+)/decision",path)
            if m and method=="POST":
                cid=int(m.group(1)); decision=clean(data.get("decision"))
                if decision not in ("Approved","Declined"): raise ValueError("Decision must be Approved or Declined.")
                row=SERVICE.store.conn.execute("SELECT id,employee_id,title,status FROM contract_documents WHERE id=?",(cid,)).fetchone()
                if not row or int(row["employee_id"])!=mobile_eid: raise PermissionError("This contract is not available to your account.")
                if clean(row["status"])!="Pending": raise ValueError("This contract was already decided.")
                stamp=iso_now(); signed_name=clean(data.get("signed_name"))[:120]; signature=data.get("signature_data") or ""
                if decision=="Approved" and (not signed_name or not signature): raise ValueError("A typed name and drawn signature are required to approve.")
                decline_reason=clean(data.get("reason"))[:2000] if decision=="Declined" else ""
                SERVICE.store.conn.execute("UPDATE contract_documents SET status=?,decline_reason=?,signature_data=?,signed_name=?,decided_at=?,updated_at=? WHERE id=?",(decision,decline_reason,signature if decision=="Approved" else "",signed_name if decision=="Approved" else "",stamp,stamp,cid))
                notify=("Contract signed: "+clean(row["title"])+" by "+(signed_name or mobile_actor)) if decision=="Approved" else ("Contract declined: "+clean(row["title"])+" by "+mobile_actor+(" - "+decline_reason[:120] if decline_reason else ""))
                SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",(mobile_actor,"Management / Owners",None,"MANAGEMENT","Contract "+decision.lower()+": "+clean(row["title"])[:120],notify,stamp))
                SERVICE.store.log(mobile_actor,"Contract "+decision.lower()+" on mobile","contract",str(cid),clean(row["title"])); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"status":decision}); return
            if path=="/api/mobile/directory" and method=="GET":
                # Who you can call or message: name and number only, no other detail.
                # Colleagues who are active and not the caller. Care accounts are excluded.
                rows = SERVICE.query(
                    "SELECT e.id AS employee_id, e.employee_no, e.first_name, e.last_name,"
                    " e.job_title, e.department FROM employees e"
                    " WHERE e.employment_status='Active' AND e.id<>? ORDER BY e.first_name, e.last_name",
                    (mobile_eid,))
                for row in rows:
                    row["name"] = ((row.get("first_name") or "") + " " + (row.get("last_name") or "")).strip()
                self.send_json(200, {"items": rows}); return
            if path=="/api/mobile/calls" and method=="GET":
                rows = SERVICE.query("SELECT id,caller_employee_id,callee_employee_id,call_type,status,created_at,answered_at,ended_at,ended_reason FROM voic3_calls WHERE caller_employee_id=? OR callee_employee_id=? ORDER BY id DESC LIMIT 50",(mobile_eid,mobile_eid))
                self.send_json(200,{"items":rows}); return
            if path=="/api/mobile/calls" and method=="POST":
                callee=int(data.get("callee_employee_id") or 0); ctype=clean(data.get("call_type") or "audio")
                if not callee: raise ValueError("callee_employee_id required")
                if callee==mobile_eid: raise ValueError("Cannot call yourself.")
                stamp=iso_now(); cur=SERVICE.store.conn.execute("INSERT INTO voic3_calls(caller_employee_id,callee_employee_id,call_type,status,created_at) VALUES(?,?,?,?,?)",(mobile_eid,callee,ctype,"ringing",stamp)); SERVICE.store.conn.commit()
                # Ring the callee ONLY. The caller's own phone must never receive call.incoming (it would ring itself);
                # it gets call.state=ringing instead and plays a local ringback tone until the callee answers.
                callee_only=[eid for eid in {int(callee)} if eid!=int(mobile_eid)]
                publish_voic3_event(callee_only, "call.incoming", {"call_id": int(cur.lastrowid), "caller_employee_id": mobile_eid, "callee_employee_id": int(callee), "call_type": ctype})
                publish_voic3_event([int(mobile_eid)], "call.state", {"call_id": int(cur.lastrowid), "status": "ringing", "caller_employee_id": mobile_eid, "callee_employee_id": int(callee)})
                # Section 12: ring a backgrounded phone via self-hosted Web Push.
                try:
                    caller_row = SERVICE.store.conn.execute("SELECT first_name,last_name FROM employees WHERE id=?", (mobile_eid,)).fetchone()
                    caller_name = ((caller_row["first_name"] or "") + " " + (caller_row["last_name"] or "")).strip() if caller_row else ""
                    notify_voic3_offline([callee], voic3_push.call_payload(int(cur.lastrowid), caller_name, ctype))
                except Exception:
                    pass
                self.send_json(201,{"id":int(cur.lastrowid),"status":"ringing"}); return
            m=re.fullmatch(r"/api/mobile/calls/(\d+)/signal",path)
            if m and method=="GET":
                cid=int(m.group(1)); after=int(data.get("after") or 0)
                row=SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id FROM voic3_calls WHERE id=?",(cid,)).fetchone()
                if not row or (int(row["caller_employee_id"])!=mobile_eid and int(row["callee_employee_id"])!=mobile_eid and not mobile_admin): raise PermissionError("This call is not available to your account.")
                rows=SERVICE.query("SELECT id,sender_employee_id,kind,payload,created_at FROM voic3_signals WHERE call_id=? AND id>? ORDER BY id",(cid,after))
                self.send_json(200,{"items":rows}); return
            if m and method=="POST":
                cid=int(m.group(1)); kind=clean(data.get("kind")); payload=data.get("payload")
                if not kind or payload is None: raise ValueError("kind and payload required")
                row=SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id,status FROM voic3_calls WHERE id=?",(cid,)).fetchone()
                if not row or (int(row["caller_employee_id"])!=mobile_eid and int(row["callee_employee_id"])!=mobile_eid and not mobile_admin): raise PermissionError("This call is not available to your account.")
                if clean(row["status"]) in ("ended","declined","missed","cancelled"): raise ValueError("This call is already closed.")
                stamp=iso_now(); cur=SERVICE.store.conn.execute("INSERT INTO voic3_signals(call_id,sender_employee_id,kind,payload,created_at) VALUES(?,?,?,?,?)",(cid,mobile_eid,kind,str(payload),stamp)); SERVICE.store.conn.commit()
                other = int(row["callee_employee_id"]) if mobile_eid == int(row["caller_employee_id"]) else int(row["caller_employee_id"])
                publish_voic3_event([other], "call.signal", {"call_id": cid, "sender_employee_id": mobile_eid, "kind": kind})
                self.send_json(201,{"id":int(cur.lastrowid)}); return
            m=re.fullmatch(r"/api/mobile/calls/(\d+)/answer",path)
            if m and method=="POST":
                cid=int(m.group(1)); row=SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id,status FROM voic3_calls WHERE id=?",(cid,)).fetchone()
                if not row: raise ValueError("Call not found.")
                if int(row["callee_employee_id"])!=mobile_eid and not mobile_admin: raise PermissionError("Only the callee can answer this call.")
                if clean(row["status"])!="ringing": raise ValueError("This call is not ringing.")
                SERVICE.store.conn.execute("UPDATE voic3_calls SET status='active',answered_at=? WHERE id=?",(iso_now(),cid)); SERVICE.store.conn.commit()
                publish_voic3_event([int(row["caller_employee_id"])], "call.state", {"call_id": cid, "status": "active"})
                self.send_json(200,{"ok":True}); return
            m=re.fullmatch(r"/api/mobile/calls/(\d+)/decline",path)
            if m and method=="POST":
                cid=int(m.group(1)); row=SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id,status FROM voic3_calls WHERE id=?",(cid,)).fetchone()
                if not row: raise ValueError("Call not found.")
                if int(row["callee_employee_id"])!=mobile_eid and not mobile_admin: raise PermissionError("Only the callee can decline this call.")
                if clean(row["status"]) not in ("ringing","active"): raise ValueError("This call is already closed.")
                SERVICE.store.conn.execute("UPDATE voic3_calls SET status='declined',ended_at=?,ended_reason='declined' WHERE id=?",(iso_now(),cid)); SERVICE.store.conn.commit()
                publish_voic3_event([int(row["caller_employee_id"])], "call.state", {"call_id": cid, "status": "declined"})
                self.send_json(200,{"ok":True}); return
            m=re.fullmatch(r"/api/mobile/calls/(\d+)/end",path)
            if m and method=="POST":
                cid=int(m.group(1)); row=SERVICE.store.conn.execute("SELECT caller_employee_id,callee_employee_id,status FROM voic3_calls WHERE id=?",(cid,)).fetchone()
                if not row: raise ValueError("Call not found.")
                if int(row["caller_employee_id"])!=mobile_eid and int(row["callee_employee_id"])!=mobile_eid and not mobile_admin: raise PermissionError("This call is not available to your account.")
                reason=clean(data.get("reason") or "completed")
                if reason not in ("completed","declined","missed","failed","cancelled"): reason="completed"
                SERVICE.store.conn.execute("UPDATE voic3_calls SET status='ended',ended_at=?,ended_reason=? WHERE id=?",(iso_now(),reason,cid)); SERVICE.store.conn.commit()
                publish_voic3_event([int(row["caller_employee_id"]), int(row["callee_employee_id"])], "call.state", {"call_id": cid, "status": "ended", "reason": reason})
                self.send_json(200,{"ok":True}); return
            if path=="/api/mobile/notify" and method=="POST":
                subject=clean(data.get("subject")); body=clean(data.get("body"))
                if not subject: raise ValueError("subject required")
                SERVICE.notify_owners(subject, body or "")
                self.send_json(200,{"ok":True}); return
            if path=="/api/mobile/patients" and method=="GET":
                if mobile_admin:
                    rows=SERVICE.query("SELECT * FROM patients WHERE status='Active' ORDER BY last_name,first_name")
                else:
                    ids=[int(r["patient_id"]) for r in SERVICE.query("SELECT patient_id FROM patient_access WHERE principal_type='employee' AND principal_id=? AND active=1",(mobile_eid,))]
                    rows=[]
                    if ids:
                        marks=",".join("?" for _ in ids); rows=SERVICE.query(f"SELECT * FROM patients WHERE status='Active' AND id IN ({marks}) ORDER BY last_name,first_name",[int(i) for i in ids])
                self.send_json(200,{"items":[SERVICE._patient_dict(r) for r in rows]}); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)",path)
            if m and method=="GET":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                self.send_json(200,SERVICE._patient_dict(SERVICE._patient_row(pid),detail=True)); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/walks",path)
            if m and method=="GET":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                w=SERVICE.query("SELECT * FROM patient_walks WHERE patient_id=? ORDER BY id DESC LIMIT 20",(pid,))
                active=next((x for x in w if clean(x.get("status"))=="Active"),None)
                self.send_json(200,{"active":active,"items":w}); return
            if m and method=="POST":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                action=clean(data.get("action")) or "start"
                note=clean(data.get("note") or data.get("notes"))
                def _walk_coord(key):
                    value=data.get(key)
                    try:
                        return float(value) if value not in (None,"") else None
                    except (TypeError,ValueError):
                        return None
                lat=_walk_coord("latitude"); lon=_walk_coord("longitude")
                if action=="start":
                    wid=SERVICE.patient_walk_start(pid,{"note":note,"latitude":lat,"longitude":lon,"started_from":"Mobile"},mobile_actor)
                    self.send_json(201,{"id":wid,"status":"Active"}); return
                if action=="end":
                    w=SERVICE.store.conn.execute("SELECT id FROM patient_walks WHERE patient_id=? AND status='Active' ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                    if not w: raise KeyError("No active walk found for this patient.")
                    self.send_json(200,SERVICE.patient_walk_end(int(w["id"]),pid,mobile_actor)); return
                raise ValueError("Walk action must be start or end.")
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/walks/(\d+)/(checkin|end)",path)
            if m and method=="POST":
                pid=int(m.group(1)); wid=int(m.group(2)); walk_action=m.group(3)
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                if walk_action=="end":
                    self.send_json(200,SERVICE.patient_walk_end(wid,pid,mobile_actor)); return
                payload={"note":clean(data.get("note") or data.get("notes"))}
                for key in ("latitude","longitude"):
                    value=data.get(key)
                    if value in (None,""): continue
                    try: payload[key]=float(value)
                    except (TypeError,ValueError): raise ValueError("Valid latitude and longitude are required.")
                lat=payload.get("latitude"); lon=payload.get("longitude")
                if lat is not None and not (-90<=lat<=90 and -180<=lon<=180):
                    raise ValueError("Location coordinates are out of range.")
                self.send_json(200,SERVICE.patient_walk_checkin(wid,pid,payload,mobile_actor)); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/walks/(\d+)/location",path)
            if m and method=="POST":
                pid=int(m.group(1)); wid=int(m.group(2))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                w=SERVICE.store.conn.execute("SELECT id,patient_id,status FROM patient_walks WHERE id=?",(wid,)).fetchone()
                if not w or int(w["patient_id"])!=pid: raise KeyError("Walk not found.")
                try: lat=float(data.get("latitude")); lon=float(data.get("longitude"))
                except (TypeError,ValueError): raise ValueError("Valid latitude and longitude are required.")
                if not (-90<=lat<=90 and -180<=lon<=180): raise ValueError("Location coordinates are out of range.")
                stamp=iso_now()
                SERVICE.store.conn.execute("UPDATE patient_walks SET last_checkin_at=?,last_latitude=?,last_longitude=? WHERE id=?",(stamp,lat,lon,wid))
                SERVICE.store.conn.execute("INSERT INTO patient_walk_events(walk_id,note,latitude,longitude,created_by,created_at) VALUES(?,?,?,?,?,?)",(wid,"Live location",lat,lon,mobile_actor,stamp))
                def _mf(k):
                    v=data.get(k)
                    try: return float(v) if v not in (None,"") else None
                    except (TypeError,ValueError): return None
                SERVICE._ping_record(pid,lat,lon,accuracy=_mf("accuracy"),battery=_mf("battery"),speed=_mf("speed"),walk_id=wid,source="mobile",device_key=device_key,actor=mobile_actor)
                _g=SERVICE._geofence_check(pid,lat,lon)
                if _g: SERVICE.raise_safety_alert(pid,_g,"warning",f"Outside designated safe area at {lat},{lon}.",mobile_actor)
                SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/vitals",path)
            if m and method=="GET":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                self.send_json(200,{"items":SERVICE.query("SELECT id,heart_rate,blood_pressure,temperature,spo2,notes,recorded_by,recorded_at FROM patient_vitals WHERE patient_id=? ORDER BY id DESC LIMIT 30",(pid,))}); return
            if m and method=="POST":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                try: hr=int(data.get("heart_rate")) if data.get("heart_rate") not in (None,"") else None
                except (TypeError,ValueError): raise ValueError("Heart rate must be a whole number.")
                try: temp=float(data.get("temperature")) if data.get("temperature") not in (None,"") else None
                except (TypeError,ValueError): raise ValueError("Temperature must be a number.")
                try: spo2=int(data.get("spo2")) if data.get("spo2") not in (None,"") else None
                except (TypeError,ValueError): raise ValueError("SpO2 must be a whole number.")
                if hr is not None and not (30<=hr<=220): raise ValueError("Heart rate looks out of range.")
                if spo2 is not None and not (50<=spo2<=100): raise ValueError("SpO2 looks out of range.")
                bp=clean(data.get("blood_pressure"))[:40]; notes=clean(data.get("notes"))[:2000]; stamp=iso_now()
                cur=SERVICE.store.conn.execute("INSERT INTO patient_vitals(patient_id,recorded_by,heart_rate,blood_pressure,temperature,spo2,notes,recorded_at) VALUES(?,?,?,?,?,?,?,?)",(pid,mobile_actor,hr,bp,temp,spo2,notes,stamp))
                SERVICE.store.log(mobile_actor,"Recorded patient vitals","patient",str(pid),f"HR {hr} BP {bp} Temp {temp} SpO2 {spo2}"); SERVICE.store.conn.commit(); self.send_json(201,{"id":int(cur.lastrowid)}); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/location",path)
            if m and method=="POST":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                try: lat=float(data.get("latitude")); lon=float(data.get("longitude"))
                except (TypeError,ValueError): raise ValueError("Valid latitude and longitude are required.")
                if not (-90<=lat<=90 and -180<=lon<=180): raise ValueError("Location coordinates are out of range.")
                def _optfloat(k):
                    v=data.get(k)
                    try: return float(v) if v not in (None,"") else None
                    except (TypeError,ValueError): return None
                wid=int(data.get("walk_id") or 0) or None
                ping_id,stamp=SERVICE._ping_record(pid,lat,lon,accuracy=_optfloat("accuracy"),battery=_optfloat("battery"),speed=_optfloat("speed"),walk_id=wid,source="mobile",device_key=device_key,actor=mobile_actor)
                walk=SERVICE.store.conn.execute("SELECT id FROM patient_walks WHERE patient_id=? AND status='Active' ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                if walk:
                    SERVICE.store.conn.execute("UPDATE patient_walks SET last_checkin_at=?,last_latitude=?,last_longitude=? WHERE id=?",(stamp,lat,lon,int(walk["id"])))
                    SERVICE.store.conn.execute("INSERT INTO patient_walk_events(walk_id,note,latitude,longitude,created_by,created_at) VALUES(?,?,?,?,?,?)",(int(walk["id"]),"Live location",lat,lon,mobile_actor,stamp))
                alert=SERVICE._geofence_check(pid,lat,lon)
                if alert: SERVICE.raise_safety_alert(pid,alert,"warning",f"Outside designated safe area at {lat},{lon}.",mobile_actor)
                SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"ping_id":ping_id,"geofence_alert":alert}); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/sos",path)
            if m and method=="POST":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                stamp=iso_now()
                event_id=clean(data.get("event_id"))[:80]
                fix_note=""
                try:
                    la=data.get("latitude"); lo=data.get("longitude")
                    if la is not None and lo is not None:
                        fix_note=f" Last known position {float(la):.5f},{float(lo):.5f}"
                        bat=data.get("battery")
                        if bat is not None: fix_note+=f" battery {int(float(bat))}%"
                except (TypeError,ValueError): fix_note=""
                duplicate=False; legacy_aid=0
                if event_id:
                    existing=SERVICE.store.conn.execute("SELECT id FROM patient_emergency_alerts WHERE patient_id=? AND event_id=?",(pid,event_id)).fetchone()
                    if existing:
                        duplicate=True; legacy_aid=int(existing["id"])
                if not duplicate:
                    cur=SERVICE.store.conn.execute("INSERT INTO patient_emergency_alerts(patient_id,event_type,status,contact_stage,person_1_in_app,created_by,created_at,updated_at,event_id) VALUES(?,?,'Open',1,0,?,?,?,?)",(pid,"Emergency SOS (mobile)",mobile_actor,stamp,stamp,event_id))
                    legacy_aid=int(cur.lastrowid)
                detail="Emergency button activated on mobile device."+(" (duplicate delivery suppressed)" if duplicate else "")+fix_note
                raised_at=queued_stamp(data.get("queued_at"))
                if raised_at: detail+=f" Pressed on the phone at {raised_at}; delivered after the connection returned."
                said,_=SERVICE.raise_safety_alert(pid,"emergency","critical",detail,mobile_actor,escalate=True)
                # Route SOS to admins as a VOIC3 message so they are alerted without a dashboard button.
                try:
                    prow = SERVICE.store.conn.execute("SELECT first_name,last_name,patient_number FROM patients WHERE id=?", (pid,)).fetchone()
                    pname = (clean(prow["first_name"]) + " " + clean(prow["last_name"])).strip() if prow else f"Patient {pid}"
                    pnum = clean(prow["patient_number"]) if prow else ""
                    admin_emps = SERVICE.store.conn.execute(
                        "SELECT e.id,e.first_name,e.last_name FROM employees e JOIN mobile_accounts m ON m.employee_id=e.id WHERE m.mobile_profile='admin' AND m.active=1").fetchall()
                    for ae in admin_emps:
                        SERVICE.store.conn.execute(
                            "INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",
                            (mobile_actor, f"{clean(ae['first_name'])} {clean(ae['last_name'])}".strip(),
                             int(ae["id"]), None,
                             f"SOS ALERT: {pname}",
                             f"Emergency SOS activated on a mobile device.\n\nPatient: {pname} ({pnum})\n{detail}\n\nTriggered by: {mobile_actor}\nTime: {stamp}",
                             stamp))
                    SERVICE.store.conn.commit()
                except Exception:
                    pass
                SERVICE.store.log(mobile_actor,"Mobile SOS activated"+(" (duplicate)" if duplicate else ""),"patient",pid,f"Alert {said}"); SERVICE.store.conn.commit()
                self.send_json(200 if duplicate else 201,{"ok":True,"duplicate":duplicate,"alert_id":said,"legacy_alert_id":legacy_aid}); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/safety",path)
            if m and method=="GET":
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                state=SERVICE.patient_state(pid)
                pings=SERVICE.query("SELECT id,latitude,longitude,accuracy_m,battery_pct,speed_mps,created_at FROM patient_location_pings WHERE patient_id=? ORDER BY id DESC LIMIT 30",(pid,))
                alerts=SERVICE.query("SELECT id,alert_type,severity,status,details,escalation_stage,created_at,acknowledged_at FROM safety_alerts WHERE patient_id=? ORDER BY id DESC LIMIT 30",(pid,))
                geofences=SERVICE.query("SELECT id,name,latitude,longitude,radius_m FROM geofences WHERE patient_id=? AND active=1",(pid,))
                self.send_json(200,{"state":state,"pings":pings,"alerts":alerts,"geofences":geofences}); return
            m=re.fullmatch(r"/api/mobile/patients/(\d+)/alerts",path)
            if m and method=="GET":
                # The phone asks for one patient's alerts by id; the safety route
                # already returns them, so this is a thin, permission-checked view.
                pid=int(m.group(1))
                if not mobile_patient_ok(pid): raise PermissionError("This patient is not assigned to your account.")
                rows=SERVICE.query("SELECT id,alert_type,severity,status,details,escalation_stage,created_at,acknowledged_at"
                                   " FROM safety_alerts WHERE patient_id=? ORDER BY id DESC LIMIT 100",(pid,))
                self.send_json(200,{"items":rows}); return
            if path=="/api/mobile/alerts" and method=="GET":
                if mobile_admin:
                    rows=SERVICE.query("SELECT a.id,a.patient_id,a.alert_type,a.severity,a.status,a.details,a.escalation_stage,a.created_at,p.first_name,p.last_name FROM safety_alerts a JOIN patients p ON p.id=a.patient_id WHERE a.status IN ('Open','Escalated') ORDER BY a.id DESC LIMIT 50")
                else:
                    ids=[int(r["patient_id"]) for r in SERVICE.query("SELECT patient_id FROM patient_access WHERE principal_type='employee' AND principal_id=? AND active=1",(mobile_eid,))]
                    rows=[]
                    if ids:
                        marks=",".join("?" for _ in ids); rows=SERVICE.query(f"SELECT a.id,a.patient_id,a.alert_type,a.severity,a.status,a.details,a.escalation_stage,a.created_at,p.first_name,p.last_name FROM safety_alerts a JOIN patients p ON p.id=a.patient_id WHERE a.status IN ('Open','Escalated') AND a.patient_id IN ({marks}) ORDER BY a.id DESC LIMIT 50",[int(i) for i in ids])
                self.send_json(200,{"items":rows}); return
            m=re.fullmatch(r"/api/mobile/alerts/(\d+)/acknowledge",path)
            if m and method=="POST":
                aid=int(m.group(1))
                row=SERVICE.store.conn.execute("SELECT * FROM safety_alerts WHERE id=?",(aid,)).fetchone()
                if not row: raise KeyError("Safety alert not found.")
                if not mobile_admin and not mobile_patient_ok(int(row["patient_id"])): raise PermissionError("This alert is not assigned to your account.")
                if clean(row["status"]) in ("Acknowledged","Resolved"): raise ValueError("This alert was already actioned.")
                resolution=clean(data.get("resolution"))
                stamp=iso_now(); newstatus="Resolved" if resolution else "Acknowledged"
                SERVICE.store.conn.execute("UPDATE safety_alerts SET status=?,acknowledged_by=?,acknowledged_at=?,resolved_at=?,updated_at=? WHERE id=?",(newstatus,mobile_actor,stamp,stamp if resolution else "",stamp,aid))
                if row["alert_type"]=="emergency" or row["severity"]=="critical":
                    SERVICE.store.conn.execute("UPDATE emergency_escalations SET status='Acknowledged',ack_at=? WHERE alert_id=? AND ack_at=''",(stamp,aid))
                SERVICE.store.log(mobile_actor,f"{newstatus} safety alert","safety_alert",aid,f"Patient {row['patient_id']}")
                SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"status":newstatus}); return
            if path=="/api/mobile/patient-alerts" and method=="GET":
                if mobile_admin:
                    rows=SERVICE.query("SELECT a.id AS alert_id,a.event_type,a.status,a.contact_stage,a.acknowledged_at,a.created_at,p.first_name,p.last_name FROM patient_emergency_alerts a JOIN patients p ON p.id=a.patient_id WHERE a.status IN ('Open','Escalated') ORDER BY a.id DESC LIMIT 50")
                else:
                    ids=[int(r["patient_id"]) for r in SERVICE.query("SELECT patient_id FROM patient_access WHERE principal_type='employee' AND principal_id=? AND active=1",(mobile_eid,))]
                    rows=[]
                    if ids:
                        marks=",".join("?" for _ in ids); rows=SERVICE.query(f"SELECT a.id AS alert_id,a.event_type,a.status,a.contact_stage,a.acknowledged_at,a.created_at,p.first_name,p.last_name FROM patient_emergency_alerts a JOIN patients p ON p.id=a.patient_id WHERE a.status IN ('Open','Escalated') AND a.patient_id IN ({marks}) ORDER BY a.id DESC LIMIT 50",[int(i) for i in ids])
                items=[{"alert_id":r["alert_id"],"first_name":r["first_name"],"last_name":r["last_name"],"event_type":r["event_type"],"priority":int(r["contact_stage"] or 1),"delivery_status":r["status"],"alert_created":r["created_at"]} for r in rows]
                self.send_json(200,{"items":items}); return
            m=re.fullmatch(r"/api/mobile/patient-alerts/(\d+)/ack",path)
            if m and method=="POST":
                aid=int(m.group(1))
                row=SERVICE.store.conn.execute("SELECT a.id,a.patient_id,a.status FROM patient_emergency_alerts a WHERE a.id=?",(aid,)).fetchone()
                if not row: raise KeyError("Patient alert not found.")
                if not mobile_patient_ok(int(row["patient_id"])): raise PermissionError("This alert is not available to your account.")
                if clean(row["status"]) not in ("Open","Escalated"): raise ValueError("This alert has already been acknowledged.")
                stamp=iso_now(); SERVICE.store.conn.execute("UPDATE patient_emergency_alerts SET status='Acknowledged',acknowledged_at=?,updated_at=? WHERE id=?",(stamp,stamp,aid))
                SERVICE.store.log(mobile_actor,"Acknowledged patient emergency alert","patient_alert",str(aid),f"Patient {row['patient_id']}"); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
            if path=="/api/mobile/device/claim" and method=="POST":
                code=clean(data.get("code")); device_key=clean(data.get("device_key"))[:80]; label=clean(data.get("label"))[:80]
                if not code or not device_key: raise ValueError("Pairing code and device key are required.")
                prow=SERVICE.store.conn.execute("SELECT code,device_class,used_at FROM mobile_pairing_codes WHERE code=?",(code,)).fetchone() if SERVICE.store.conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='mobile_pairing_codes'").fetchone() else None
                if not prow or prow["used_at"]: raise PermissionError("Invalid or already-used pairing code.")
                stamp=iso_now()
                SERVICE.store.conn.execute("INSERT INTO mobile_devices(device_key,device_class,label,paired_by,paired_at) VALUES(?,?,?,?,?) ON CONFLICT(device_key) DO UPDATE SET device_class=excluded.device_class,label=excluded.label,paired_by=excluded.paired_by,paired_at=excluded.paired_at",(device_key,clean(prow["device_class"]),label or "Company device",mobile_actor,stamp))
                SERVICE.store.conn.execute("UPDATE mobile_pairing_codes SET used_at=?,used_by=? WHERE code=?",(stamp,mobile_actor,code))
                SERVICE.store.log(mobile_actor,"Paired mobile device","mobile_device",device_key,f"Class {prow['device_class']}"); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"device_class":clean(prow["device_class"])}); return
            if path=="/api/mobile/checkin" and method=="POST":
                if not is_company_device: raise PermissionError("Check-ins are only required on paired company devices.")
                if not device_key: raise ValueError("Device key missing.")
                stamp=queued_stamp(data.get("queued_at")) or iso_now(); SERVICE.store.conn.execute("INSERT INTO device_checkins(device_key,employee_id,checked_at) VALUES(?,?,?)",(device_key,mobile_eid,stamp)); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"checked_at":stamp}); return
            if path=="/api/mobile/checkin/status" and method=="GET":
                if not is_company_device: raise PermissionError("Check-in status is only available on paired company devices.")
                last=SERVICE.store.conn.execute("SELECT checked_at FROM device_checkins WHERE device_key=? ORDER BY id DESC LIMIT 1",(device_key,)).fetchone()
                self.send_json(200,{"last_checkin":last["checked_at"] if last else None}); return
            if path == "/api/mobile/academy/certificates" and method == "GET":
                self.send_json(200, {"items": academy.list_certificates(SERVICE.store.conn, mobile_actor)}); return
            if path == "/api/mobile/academy/certificates/verify" and method == "POST":
                self.send_json(200, academy.verify_certificate(SERVICE.store.conn, data.get("code"))); return
            m = re.fullmatch(r"/api/mobile/academy/certificates/(\d+)/(view|pdf|qr\.png)", path)
            if m:
                cid = int(m.group(1)); kind = m.group(2)
                detail = academy.certificate_detail(SERVICE.store.conn, cid)
                if not detail: raise KeyError("That certificate does not exist.")
                if not mobile_admin and str(detail.get("user")) != mobile_actor:
                    raise PermissionError("That certificate belongs to another account.")
                base = "/api/mobile/academy/certificates/" + str(cid)
                qr = certificates.qr_png(detail.get("qr_payload") or "")
                if kind == "view":
                    raw = certificates.html_page(detail, base + "/qr.png", base + "/pdf").encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(raw)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers(); self.wfile.write(raw); return
                if kind == "pdf":
                    raw = certificates.pdf_bytes(detail, qr)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/pdf")
                    self.send_header("Content-Disposition", 'inline; filename="EVOLV3-' + str(detail.get("certificate_no")) + '.pdf"')
                    self.send_header("Content-Length", str(len(raw)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers(); self.wfile.write(raw); return
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(qr)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers(); self.wfile.write(qr); return
            # ---- EVOLV3 knowledge cards -------------------------------------
            # Cards are for staff and family. Correct quiz answers are never
            # sent to the client; they are only returned after an answer.
            if path == "/api/mobile/academy/summary" and method == "GET":
                pack = clean(data.get("pack")) or academy.PACK
                self.send_json(200, {
                    "pack": pack,
                    "cards": academy.card_progress(SERVICE.store.conn, mobile_actor, pack),
                    "quiz": academy.quiz_summary(SERVICE.store.conn, mobile_actor, pack),
                    "disclaimer": academy.DISCLAIMER,
                    "emergency_numbers": academy.EMERGENCY_NUMBERS,
                }); return
            if path == "/api/mobile/academy/cards" and method == "GET":
                pack = clean(data.get("pack")) or academy.PACK
                kind = clean(data.get("kind")) or None
                self.send_json(200, {"items": academy.list_cards(SERVICE.store.conn, pack, kind)}); return
            m = re.fullmatch(r"/api/mobile/academy/cards/(\d+)", path)
            if m and method == "GET":
                card = academy.get_card(SERVICE.store.conn, int(m.group(1)))
                if not card:
                    raise KeyError("That card is not available.")
                self.send_json(200, card); return
            m = re.fullmatch(r"/api/mobile/academy/cards/(\d+)/seen", path)
            if m and method == "POST":
                if not academy.mark_card_seen(SERVICE.store.conn, mobile_actor, int(m.group(1))):
                    raise KeyError("That card is not available.")
                pack = clean(data.get("pack")) or academy.PACK
                self.send_json(200, {"ok": True, "progress": academy.card_progress(
                    SERVICE.store.conn, mobile_actor, pack)}); return
            if path == "/api/mobile/academy/quiz" and method == "GET":
                pack = clean(data.get("pack")) or academy.PACK
                self.send_json(200, {"items": academy.list_questions(SERVICE.store.conn, pack)}); return
            if path == "/api/mobile/academy/quiz/answer" and method == "POST":
                qid = int(data.get("question_id") or 0)
                raw_choice = data.get("choice")
                choice = int(raw_choice) if raw_choice is not None else -1
                result = academy.answer_question(SERVICE.store.conn, mobile_actor, qid, choice)
                if not result:
                    raise KeyError("That question is not available.")
                self.send_json(200, result); return
            if path == "/api/mobile/academy/rate" and method == "POST":
                kind = clean(data.get("kind")) or "card"
                rid = int(data.get("id") or 0)
                rating = int(data.get("rating") or 0)
                ok = (academy.rate_card(SERVICE.store.conn, mobile_actor, rid, rating)
                      if kind == "card" else
                      academy.rate_question(SERVICE.store.conn, mobile_actor, rid, rating))
                if not ok:
                    raise KeyError("That item is not available.")
                self.send_json(200, {"ok": True}); return
            if path == "/api/mobile/academy/courses" and method == "GET":
                self.send_json(200, {"items": academy.list_courses(SERVICE.store.conn)}); return
            m = re.fullmatch(r"/api/mobile/academy/courses/(\d+)", path)
            if m and method == "GET":
                course = academy.get_course(SERVICE.store.conn, int(m.group(1)))
                if not course:
                    raise KeyError("That course is not available.")
                self.send_json(200, course); return

            if path == "/api/mobile/academy/enrol" and method == "POST":
                cid = int(data.get("course_id") or 0)
                if not academy.enrol(SERVICE.store.conn, mobile_actor, cid): raise KeyError("Course not found or not published.")
                self.send_json(200, {"ok": True, "enrolled": True}); return
            if path == "/api/mobile/academy/my-courses" and method == "GET":
                self.send_json(200, {"items": academy.my_courses(SERVICE.store.conn, mobile_actor)}); return
            if not mobile_admin:
                self.send_json(404,{"error":"Mobile resource not found."}); return
            if path=="/api/mobile/admin/overview" and method=="GET":
                self.send_json(200,{"leave_pending":SERVICE.query("SELECT COUNT(*) AS c FROM leave_records WHERE status='Pending'")[0]["c"],"ai_pending":len(SERVICE.coordinator.approvals()) if SERVICE.coordinator else 0,"payslip_pending":SERVICE.query("SELECT COUNT(*) AS c FROM payslip_edit_requests WHERE status='Pending'")[0]["c"],"contracts_pending":SERVICE.query("SELECT COUNT(*) AS c FROM contract_documents WHERE status='Pending'")[0]["c"],"active_walks":SERVICE.query("SELECT COUNT(*) AS c FROM patient_walks WHERE status='Active'")[0]["c"],"fatigue_flags":len(SERVICE.fatigue_flags(8)),"unread_messages":SERVICE.query("SELECT COUNT(*) AS c FROM hub_messages WHERE employee_id IS NULL AND read_at IS NULL")[0]["c"]}); return
            if path=="/api/mobile/admin/leave" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT l.id,l.employee_id,l.leave_type,l.date_from,l.date_to,l.days,l.reason,l.status,l.created_at,e.employee_no,e.first_name,e.last_name,e.department FROM leave_records l JOIN employees e ON e.id=l.employee_id WHERE l.status='Pending' ORDER BY l.id")}); return
            m=re.fullmatch(r"/api/mobile/admin/leave/(\d+)/decision",path)
            if m and method=="POST":
                lid=int(m.group(1)); decision=clean(data.get("decision"))
                if decision not in ("Approved","Denied"): raise ValueError("Decision must be Approved or Denied.")
                row=SERVICE.store.conn.execute("SELECT id,status FROM leave_records WHERE id=?",(lid,)).fetchone()
                if not row: raise KeyError("Leave request not found.")
                if clean(row["status"])!="Pending": raise ValueError("This leave request was already decided.")
                stamp=iso_now(); SERVICE.store.conn.execute("UPDATE leave_records SET status=?,decision_by=?,decision_at=?,updated_at=? WHERE id=?",(decision,mobile_actor,stamp,stamp,lid))
                SERVICE.store.log(mobile_actor,"Mobile leave "+decision.lower(),"leave",str(lid),f"Leave record {lid}"); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"status":decision}); return
            if path=="/api/mobile/admin/approvals" and method=="GET":
                self.send_json(200,{"items":SERVICE.coordinator.approvals() if SERVICE.coordinator else []}); return
            m=re.fullmatch(r"/api/mobile/admin/ai/(\d+)/decision",path)
            if m and method=="POST":
                self.send_json(200,SERVICE.coordinator.decide(int(m.group(1)),bool(data.get("approve")),mobile_actor)); return
            if path=="/api/mobile/admin/patients" and method=="GET":
                items=[]
                for pr in SERVICE.query("SELECT * FROM patients WHERE status='Active' ORDER BY last_name,first_name"):
                    d=SERVICE._patient_dict(pr)
                    w=SERVICE.query("SELECT * FROM patient_walks WHERE patient_id=? ORDER BY id DESC LIMIT 1",(int(pr["id"]),))
                    v=SERVICE.query("SELECT heart_rate,blood_pressure,temperature,spo2,notes,recorded_by,recorded_at FROM patient_vitals WHERE patient_id=? ORDER BY id DESC LIMIT 1",(int(pr["id"]),))
                    d["latest_walk"]=w[0] if w else None; d["latest_vitals"]=v[0] if v else None
                    items.append(d)
                self.send_json(200,{"items":items}); return
            if path=="/api/mobile/admin/messages" and method=="GET":
                rows=SERVICE.query("SELECT id,sender,recipient_label,subject,body,attachment_name,CASE WHEN attachment_data IS NULL THEN 0 ELSE 1 END has_attachment,created_at,read_at FROM hub_messages WHERE employee_id IS NULL ORDER BY id DESC LIMIT 100")
                if rows: SERVICE.store.conn.execute("UPDATE hub_messages SET read_at=? WHERE employee_id IS NULL AND read_at IS NULL",(iso_now(),)); SERVICE.store.conn.commit()
                self.send_json(200,{"items":rows}); return
            m=re.fullmatch(r"/api/mobile/admin/messages/(\d+)/attachment",path)
            if m and method=="GET":
                row=SERVICE.store.conn.execute("SELECT employee_id FROM hub_messages WHERE id=?",(int(m.group(1)),)).fetchone()
                if not row or row["employee_id"] is not None: raise PermissionError("This attachment is not addressed to management.")
                raw,name,mime=SERVICE.hub_attachment(int(m.group(1)))
                self.send_response(200); self.send_header("Content-Type",mime); self.send_header("Content-Disposition",f'attachment; filename="{name}"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
            if path=="/api/mobile/admin/payslip-requests" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT r.id,r.payroll_id,r.employee_id,r.field,r.proposed_value,r.reason,r.status,r.decision_by,r.decision_at,r.created_at,p.pay_period,p.net_pay,e.employee_no,e.first_name,e.last_name FROM payslip_edit_requests r JOIN payroll_records p ON p.id=r.payroll_id JOIN employees e ON e.id=r.employee_id ORDER BY r.id DESC LIMIT 100")}); return
            m=re.fullmatch(r"/api/mobile/admin/payslip-requests/(\d+)/decision",path)
            if m and method=="POST":
                rid=int(m.group(1)); decision=clean(data.get("decision"))
                if decision not in ("Approved","Denied"): raise ValueError("Decision must be Approved or Denied.")
                row=SERVICE.store.conn.execute("SELECT id,employee_id,payroll_id,field,status FROM payslip_edit_requests WHERE id=?",(rid,)).fetchone()
                if not row: raise KeyError("Payslip request not found.")
                if clean(row["status"])!="Pending": raise ValueError("This request was already decided.")
                stamp=iso_now(); SERVICE.store.conn.execute("UPDATE payslip_edit_requests SET status=?,decision_by=?,decision_at=?,updated_at=? WHERE id=?",(decision,mobile_actor,stamp,stamp,rid))
                SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",(mobile_actor,"Employee",int(row["employee_id"]),None,"Payslip correction "+decision.lower(),"Your payslip correction request ("+clean(row["field"])+") was "+decision.lower()+". Contact the office for the updated payslip.",stamp))
                SERVICE.store.log(mobile_actor,"Payslip request "+decision.lower(),"payslip_request",str(rid),f"Payroll {row['payroll_id']} field {row['field']}"); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"status":decision}); return
            if path=="/api/mobile/admin/contracts" and method=="GET":
                self.send_json(200,{"items":SERVICE.query("SELECT c.id,c.employee_id,c.title,c.file_name,c.status,c.decline_reason,c.signed_name,c.decided_at,c.created_at,e.employee_no,e.first_name,e.last_name FROM contract_documents c JOIN employees e ON e.id=c.employee_id ORDER BY c.id DESC LIMIT 100")}); return
            if path == "/api/mobile/requests" and method == "GET":
                self.send_json(200, {"items": resource_requests.list_requests(
                    SERVICE.store.conn, employee_id=mobile_eid)}); return
            if path == "/api/mobile/requests" and method == "POST":
                payload = dict(data); payload["employee_id"] = mobile_eid
                item = resource_requests.create_request(SERVICE.store.conn, payload, mobile_actor)
                SERVICE.store.log(mobile_actor, "Resource request submitted", "resource_request",
                                  str(item["id"]), item["ref"])
                self.send_json(201, {"ok": True, "request": item}); return
            m = re.fullmatch(r"/api/mobile/requests/(\d+)/information", path)
            if m and method == "POST":
                existing = resource_requests.get_request(SERVICE.store.conn, int(m.group(1)))
                if not existing or int(existing["employee_id"] or 0) != int(mobile_eid):
                    raise PermissionError("This request is not yours.")
                item = resource_requests.provide_information(SERVICE.store.conn, int(m.group(1)),
                                                             mobile_actor, clean(data.get("detail")))
                self.send_json(200, {"ok": True, "request": item}); return
            m = re.fullmatch(r"/api/mobile/requests/(\d+)", path)
            if m and method == "GET":
                item = resource_requests.get_request(SERVICE.store.conn, int(m.group(1)))
                if not item or int(item["employee_id"] or 0) != int(mobile_eid):
                    raise PermissionError("This request is not yours.")
                self.send_json(200, item); return
            if path == "/api/mobile/assets" and method == "GET":
                self.send_json(200, {"items": resource_requests.list_assets(SERVICE.store.conn, mobile_eid)}); return
            m = re.fullmatch(r"/api/mobile/assets/(\d+)/acknowledge", path)
            if m and method == "POST":
                item = resource_requests.acknowledge_asset(SERVICE.store.conn, int(m.group(1)),
                                                           mobile_actor, mobile_eid)
                self.send_json(200, {"ok": True, "asset": item}); return

            self.send_json(404,{"error":"Mobile resource not found."}); return

        if path == "/api/bootstrap" and method=="GET":
            user_row=SERVICE.store.conn.execute("SELECT username,full_name FROM admins WHERE username=? COLLATE NOCASE",(actor,)).fetchone() if actor else None
            self.send_json(200,{"first_run":SERVICE.store.admin_count()==0,"user":dict(user_row) if user_row else None,"app":"Beyond Registration Full Business Profile Solution","version":APP_VERSION}); return
        if path == "/api/login-options" and method=="GET":
            rows=_sign_in_row(lambda: SERVICE.store.conn.execute("SELECT username,full_name FROM admins WHERE active=1 ORDER BY full_name COLLATE NOCASE,username COLLATE NOCASE").fetchall())
            self.send_json(200,{"users":[{"username":r["username"],"full_name":r["full_name"]} for r in rows]},{"Cache-Control":"no-store"}); return
        if path == "/api/setup" and method=="POST":
            if SERVICE.store.admin_count()!=0: raise PermissionError("Initial setup has already been completed.")
            for key in ("full_name","username","password"):
                if not clean(data.get(key)): raise ValueError(f"{key.replace('_',' ').title()} is required.")
            if len(data["password"])<8: raise ValueError("Use a password with at least 8 characters.")
            SERVICE.store.create_admin(data["full_name"],data["username"],data["password"])
            row=SERVICE.store.authenticate(data["username"],data["password"])
            new_sid=secrets.token_urlsafe(32); SERVICE.sessions[new_sid]=row["username"]; SERVICE.session_expiries[new_sid]=time.time()+12*3600
            self.send_json(200,{"ok":True,"user":{"username":row["username"],"full_name":row["full_name"],"role":row["role"] if "role" in row.keys() else "Administrator"}},{"Set-Cookie":f"br_session={new_sid}; HttpOnly; SameSite=Strict; Secure; Path=/"}); return
        if path == "/api/login" and method=="POST":
            username=clean(data.get("username"))
            # Rate-limit desktop logins the same way mobile logins are limited.
            failures=[t for t in SERVICE.login_failures.get(username.casefold() or "",[]) if time.time()-t < 900]
            SERVICE.login_failures[username.casefold() or ""]=failures
            if len(failures) >= 5:
                raise PermissionError("Too many failed sign-in attempts. Please wait 15 minutes and try again.")
            row=_sign_in_row(lambda: SERVICE.store.authenticate(username,str(data.get("password") or "")))
            if not row:
                SERVICE.login_failures.setdefault(username.casefold() or "",[]).append(time.time())
                raise PermissionError("The username or password is incorrect, or this account is disabled.")
            SERVICE.login_failures.pop(username.casefold() or "",None)
            new_sid=secrets.token_urlsafe(32); SERVICE.sessions[new_sid]=row["username"]; SERVICE.session_expiries[new_sid]=time.time()+12*3600
            self.send_json(200,{"ok":True,"user":{"username":row["username"],"full_name":row["full_name"],"role":row["role"] if "role" in row.keys() else "Administrator"}},{"Set-Cookie":f"br_session={new_sid}; HttpOnly; SameSite=Strict; Secure; Path=/"}); return
        if path=="/api/logout" and method=="POST":
            if sid: SERVICE.sessions.pop(sid,None)
            self.send_json(200,{"ok":True},{"Set-Cookie":f"br_session=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict{'; Secure' if self.headers.get('X-Forwarded-Proto','').lower()=='https' else ''}"}); return

        # Per-user workspace preferences (hidden modules, dashboard order, product visibility).
        # Keyed by the authenticated account so one user's layout never overwrites another's.
        if path == "/api/prefs" and method == "GET" and actor:
            row = SERVICE.store.conn.execute("SELECT prefs_json FROM user_prefs WHERE user_key=?", (actor,)).fetchone()
            try: prefs = json.loads(row["prefs_json"]) if row else {}
            except Exception: prefs = {}
            self.send_json(200, {"prefs": prefs if isinstance(prefs, dict) else {}}); return
        if path == "/api/prefs" and method == "PUT" and actor:
            prefs = data.get("prefs")
            if not isinstance(prefs, dict): raise ValueError("prefs must be an object.")
            blob = json.dumps(prefs, ensure_ascii=False)
            if len(blob.encode("utf-8")) > 200_000: raise ValueError("Saved workspace preferences are too large.")
            stamp = iso_now()
            SERVICE.store.conn.execute("INSERT INTO user_prefs(user_key,prefs_json,updated_at) VALUES(?,?,?) ON CONFLICT(user_key) DO UPDATE SET prefs_json=excluded.prefs_json,updated_at=excluded.updated_at", (actor, blob, stamp))
            SERVICE.store.conn.commit()
            self.send_json(200, {"ok": True}); return

        # QUOT3FLOW public client portal — token-gated, no session required.
        # The token is a random per-document secret issued when a quote is sent.
        pm = re.fullmatch(r"/api/qf3portal/([A-Za-z0-9_\-]{20,100})", path)
        if pm and method == "GET":
            if not getattr(SERVICE, "_qf3_ready", False):
                quoteflow.ensure_schema(SERVICE.store.conn); SERVICE._qf3_ready = True
            doc = quoteflow.portal_doc(SERVICE.store.conn, pm.group(1))
            if not doc:
                self.send_json(404, {"error": "This link is invalid or has expired."}); return
            exp = doc.get("portal_expires") or ""
            if exp and exp < date.today().isoformat():
                self.send_json(410, {"error": "This link has expired. Please request a new one."}); return
            safe = {k: doc.get(k) for k in ("kind", "quote_no", "invoice_no", "status", "issue_date", "valid_until", "due_date", "currency", "tax_rate", "notes", "subtotal", "tax", "total", "paid", "balance", "client", "items", "portal_expires")}
            safe["client"] = {k: (doc.get("client") or {}).get(k) for k in ("name", "contact_name", "email", "phone", "address")}
            self.send_json(200, {"document": safe}); return
        pd = re.fullmatch(r"/api/qf3portal/([A-Za-z0-9_\-]{20,100})/decision", path)
        if pd and method == "POST":
            if not getattr(SERVICE, "_qf3_ready", False):
                quoteflow.ensure_schema(SERVICE.store.conn); SERVICE._qf3_ready = True
            result, err = quoteflow.portal_decision(SERVICE.store.conn, pd.group(1), data.get("decision"))
            if err:
                self.send_json(400, {"error": err}); return
            self.send_json(200, {"ok": True, "result": result}); return

        # QUOT3FLOW provider webhook — shared-secret gated, no session.
        # Only provider-verified events may confirm payments; never trusts client input alone.
        wh = re.fullmatch(r"/api/qf3/webhook/([A-Za-z0-9_\-]{2,40})", path)
        if wh and method == "POST":
            if not getattr(SERVICE, "_qf3_ready", False):
                quoteflow.ensure_schema(SERVICE.store.conn); SERVICE._qf3_ready = True
            code = wh.group(1)
            prov = SERVICE.store.conn.execute("SELECT code,active FROM payment_providers WHERE code=?", (code,)).fetchone()
            if not prov or not prov["active"]:
                self.send_json(404, {"error": "Unknown provider."}); return
            secret = quoteflow.setting(SERVICE.store.conn, f"webhook_secret_{code}")
            supplied = self.headers.get("X-Webhook-Secret", "")
            if not secret or supplied != secret:
                self.send_json(403, {"error": "Invalid webhook credentials."}); return
            try:
                pid = quoteflow.confirm_provider_payment(
                    SERVICE.store.conn, code,
                    str(data.get("provider_ref") or ""),
                    str(data.get("invoice_no") or ""),
                    float(data.get("amount") or 0), actor="provider:" + code)
                SERVICE.store.log("provider:" + code, "QUOT3FLOW provider payment confirmed", "qf3_payment", int(pid), code)
                self.send_json(200, {"ok": True, "payment_id": pid}); return
            except (KeyError, ValueError, PermissionError) as exc:
                self.send_json(400, {"error": str(exc)}); return

        if path == "/api/system/ping" and method == "GET":
            self.send_json(200, {"ok": True, "at": iso_now()}, {"Cache-Control": "no-store"}); return

        if path == "/mobile/nexus-latest.apk" and method == "GET":
            # The same package under the plain name the owner asks for. One file,
            # two addresses, so the two can never drift apart.
            apk,_,_=mobile_apk_info()
            if not apk.is_file():
                self.send_error(404); return
            raw=apk.read_bytes()
            self.send_response(200); self.send_header("Content-Type","application/vnd.android.package-archive"); self.send_header("Content-Disposition",'attachment; filename="N3XUS.apk"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
        if not actor and not mobile_eid:
            self.send_json(401,{"error":"Your session has expired. Please sign in again."}); return

        permissions = SERVICE.permissions_for(actor)
        if path.startswith("/api/qf3") or path.startswith("/api/banking"):
            self.qf3_route(method, path, data, actor, permissions, q); return
        if path.startswith("/api/mstr"):
            self.mstr_route(method, path, data, actor, permissions, q); return
        if path.startswith("/api/scheduler"):
            if not actor or SERVICE.role_for(actor) != "Administrator":
                raise PermissionError("Scheduler access requires Administrator permissions.")
            sched = getattr(SERVICE, "scheduler", None)
            if path == "/api/scheduler/status" and method == "GET":
                self.send_json(200, sched.status() if sched else {"jobs": [], "running": False}); return
            if path == "/api/scheduler/run" and method == "POST":
                if not sched: raise KeyError("Scheduler is not running.")
                self.send_json(200, sched.run_now(clean(data.get("job")))); return
            if path == "/api/scheduler/toggle" and method == "POST":
                if not sched: raise KeyError("Scheduler is not running.")
                sched.set_enabled(clean(data.get("job")), bool(data.get("enabled")))
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown scheduler endpoint.")
        if path.startswith("/api/autonomy"):
            if not actor or SERVICE.role_for(actor) != "Administrator":
                raise PermissionError("Autonomy settings require Administrator access.")
            if path == "/api/autonomy/status" and method == "GET":
                self.send_json(200, autonomy.status(SERVICE)); return
            if path == "/api/autonomy/set" and method == "POST":
                lvl = autonomy.set_level(SERVICE, int(data.get("level", 2)))
                self.send_json(200, {"ok": True, "level": lvl}); return
            raise KeyError("Unknown autonomy endpoint.")
        if path.startswith("/api/finance"):
            if not actor or SERVICE.role_for(actor) != "Administrator":
                raise PermissionError("Finance access requires Administrator permissions.")
            if path == "/api/finance/accounts" and method == "GET":
                self.send_json(200, {"items": finance.list_accounts(SERVICE.store.conn)}); return
            if path == "/api/finance/accounts" and method == "POST":
                finance.save_account(SERVICE.store.conn, clean(data.get("code")), clean(data.get("name")), clean(data.get("type")), clean(data.get("parent_code")) or None)
                self.send_json(200, {"ok": True}); return
            if path == "/api/finance/journal" and method == "GET":
                self.send_json(200, {"items": finance.list_journals(SERVICE.store.conn)}); return
            if path == "/api/finance/journal" and method == "POST":
                jid = finance.post_journal(SERVICE.store.conn, clean(data.get("entry_date")), clean(data.get("memo")), data.get("entries") or [], actor)
                self.send_json(200, {"ok": True, "id": jid}); return
            if path == "/api/finance/trial-balance" and method == "GET":
                self.send_json(200, {"items": finance.trial_balance(SERVICE.store.conn)}); return
            raise KeyError("Unknown finance endpoint.")

        if path.startswith("/api/ap-ar"):
            if not actor or SERVICE.role_for(actor) != "Administrator":
                raise PermissionError("AP/AR access requires Administrator permissions.")
            if path == "/api/ap-ar/ap" and method == "GET":
                self.send_json(200, {"items": ap_ar.list_ap(SERVICE.store.conn)}); return
            if path == "/api/ap-ar/ap" and method == "POST":
                aid = ap_ar.save_ap(SERVICE.store.conn, clean(data.get("supplier")), float(data.get("amount") or 0), clean(data.get("due_date")), clean(data.get("invoice_no")), clean(data.get("notes")))
                self.send_json(200, {"ok": True, "id": aid}); return
            if path == "/api/ap-ar/ar" and method == "GET":
                self.send_json(200, {"items": ap_ar.list_ar(SERVICE.store.conn)}); return
            if path == "/api/ap-ar/ar" and method == "POST":
                aid = ap_ar.save_ar(SERVICE.store.conn, clean(data.get("customer")), float(data.get("amount") or 0), clean(data.get("due_date")), clean(data.get("invoice_no")), clean(data.get("notes")))
                self.send_json(200, {"ok": True, "id": aid}); return
            if path == "/api/ap-ar/aging" and method == "GET":
                self.send_json(200, {"ar": ap_ar.aging_report(SERVICE.store.conn, "ar"), "ap": ap_ar.aging_report(SERVICE.store.conn, "ap")}); return
            raise KeyError("Unknown AP/AR endpoint.")

        if path.startswith("/api/tax"):
            if path == "/api/tax/payroll" and method == "POST":
                self.send_json(200, tax_engine.payroll_summary(float(data.get("gross_monthly") or 0))); return
            if path == "/api/tax/vat" and method == "POST":
                self.send_json(200, {"excl": tax_engine.vat_exclusive(float(data.get("amount_incl") or 0)), "incl": tax_engine.vat_inclusive(float(data.get("amount_excl") or 0)), "vat": tax_engine.vat_amount(float(data.get("amount_excl") or 0))}); return
            raise KeyError("Unknown tax endpoint.")

        if path.startswith("/api/inventory"):
            if path == "/api/inventory" and method == "GET":
                self.send_json(200, {"items": inventory.list_items(SERVICE.store.conn)}); return
            if path == "/api/inventory" and method == "POST":
                iid = inventory.save_item(SERVICE.store.conn, clean(data.get("name")), clean(data.get("sku")), clean(data.get("location")), float(data.get("qty") or 0), float(data.get("reorder") or 0), clean(data.get("unit")), float(data.get("cost") or 0))
                self.send_json(200, {"ok": True, "id": iid}); return
            if path == "/api/inventory/adjust" and method == "POST":
                inventory.adjust_stock(SERVICE.store.conn, int(data.get("item_id")), float(data.get("qty") or 0), clean(data.get("type")), clean(data.get("reference")))
                self.send_json(200, {"ok": True}); return
            if path == "/api/inventory/low-stock" and method == "GET":
                self.send_json(200, {"items": inventory.low_stock(SERVICE.store.conn)}); return
            raise KeyError("Unknown inventory endpoint.")

        if path.startswith("/api/projects"):
            if path == "/api/projects" and method == "GET":
                self.send_json(200, {"items": projects.list_projects(SERVICE.store.conn)}); return
            if path == "/api/projects" and method == "POST":
                pid = projects.save_project(SERVICE.store.conn, clean(data.get("name")), clean(data.get("status")), clean(data.get("start_date")), clean(data.get("end_date")), float(data.get("budget") or 0), clean(data.get("description")))
                self.send_json(200, {"ok": True, "id": pid}); return
            if path.startswith("/api/projects/") and path.endswith("/tasks") and method == "GET":
                pid = int(path.split("/")[3])
                self.send_json(200, {"items": projects.list_tasks(SERVICE.store.conn, pid)}); return
            if path.startswith("/api/projects/") and path.endswith("/tasks") and method == "POST":
                pid = int(path.split("/")[3])
                tid = projects.save_task(SERVICE.store.conn, pid, clean(data.get("title")), clean(data.get("status")), clean(data.get("assignee")), clean(data.get("due_date")), float(data.get("hours") or 0))
                self.send_json(200, {"ok": True, "id": tid}); return
            if path.startswith("/api/projects/") and path.endswith("/time") and method == "POST":
                pid = int(path.split("/")[3])
                projects.log_time(SERVICE.store.conn, pid, float(data.get("hours") or 0), clean(data.get("employee")), data.get("task_id"), clean(data.get("entry_date")), clean(data.get("notes")))
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown projects endpoint.")

        if path.startswith("/api/crm"):
            if path == "/api/crm/leads" and method == "GET":
                self.send_json(200, {"items": crm.list_leads(SERVICE.store.conn)}); return
            if path == "/api/crm/leads" and method == "POST":
                lid = crm.save_lead(SERVICE.store.conn, clean(data.get("name")), clean(data.get("company")), clean(data.get("email")), clean(data.get("phone")), clean(data.get("source")), clean(data.get("notes")))
                self.send_json(200, {"ok": True, "id": lid}); return
            if path == "/api/crm/opportunities" and method == "GET":
                self.send_json(200, {"items": crm.list_opportunities(SERVICE.store.conn)}); return
            if path == "/api/crm/opportunities" and method == "POST":
                oid = crm.save_opportunity(SERVICE.store.conn, clean(data.get("title")), data.get("lead_id"), clean(data.get("stage")), float(data.get("value") or 0), clean(data.get("close_date")), clean(data.get("notes")))
                self.send_json(200, {"ok": True, "id": oid}); return
            if path == "/api/crm/activity" and method == "POST":
                crm.log_activity(SERVICE.store.conn, clean(data.get("activity_type")), clean(data.get("notes")), data.get("lead_id"), data.get("opp_id"))
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown CRM endpoint.")

        if path.startswith("/api/notifications"):
            if path == "/api/notifications" and method == "GET":
                recipient = clean(data.get("recipient")) or (actor or "system")
                self.send_json(200, {"items": notifications.list_for(SERVICE.store.conn, recipient), "unread": notifications.unread_count(SERVICE.store.conn, recipient)}); return
            if path == "/api/notifications" and method == "POST":
                nid = notifications.push(SERVICE.store.conn, clean(data.get("recipient")) or (actor or "system"), clean(data.get("title")), clean(data.get("body")), clean(data.get("level")))
                self.send_json(200, {"ok": True, "id": nid}); return
            if path.startswith("/api/notifications/") and path.endswith("/read") and method == "POST":
                nid = int(path.split("/")[3])
                notifications.mark_read(SERVICE.store.conn, nid)
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown notifications endpoint.")

        if path.startswith("/api/kb"):
            if path == "/api/kb" and method == "GET":
                self.send_json(200, {"items": knowledge_base.list_articles(SERVICE.store.conn, clean(data.get("category")) or None)}); return
            if path == "/api/kb" and method == "POST":
                aid = knowledge_base.save_article(SERVICE.store.conn, clean(data.get("title")), clean(data.get("body")), clean(data.get("category")), clean(data.get("author")))
                self.send_json(200, {"ok": True, "id": aid}); return
            if path.startswith("/api/kb/") and path.endswith("/update") and method == "POST":
                aid = int(path.split("/")[3])
                knowledge_base.update_article(SERVICE.store.conn, aid, clean(data.get("body")), clean(data.get("author")))
                self.send_json(200, {"ok": True}); return
            if path == "/api/kb/search" and method == "GET":
                self.send_json(200, {"items": knowledge_base.search(SERVICE.store.conn, clean(data.get("q")))}) ; return
            raise KeyError("Unknown KB endpoint.")

        if path.startswith("/api/expenses"):
            if path == "/api/expenses" and method == "GET":
                self.send_json(200, {"items": expense_claims.list_claims(SERVICE.store.conn, clean(data.get("status")) or None)}); return
            if path == "/api/expenses" and method == "POST":
                cid = expense_claims.submit(SERVICE.store.conn, clean(data.get("employee")), float(data.get("amount") or 0), clean(data.get("category")), clean(data.get("description")), clean(data.get("receipt_path")))
                self.send_json(200, {"ok": True, "id": cid}); return
            if path.startswith("/api/expenses/") and path.endswith("/decide") and method == "POST":
                cid = int(path.split("/")[3])
                expense_claims.decide(SERVICE.store.conn, cid, clean(data.get("decision")), actor)
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown expenses endpoint.")

        if path.startswith("/api/documents"):
            if path == "/api/documents" and method == "GET":
                self.send_json(200, {"items": document_mgmt.list_docs(SERVICE.store.conn)}); return
            if path == "/api/documents" and method == "POST":
                did = document_mgmt.create_doc(SERVICE.store.conn, clean(data.get("title")), clean(data.get("category")), actor)
                self.send_json(200, {"ok": True, "id": did}); return
            if path.startswith("/api/documents/") and path.endswith("/version") and method == "POST":
                did = int(path.split("/")[3])
                import base64 as _b64
                content = _b64.b64decode(clean(data.get("content_b64"))) if data.get("content_b64") else b""
                ver = document_mgmt.add_version(SERVICE.store.conn, did, clean(data.get("file_name")), content, clean(data.get("mime_type")), clean(data.get("notes")), actor)
                self.send_json(200, {"ok": True, "version": ver}); return
            if path.startswith("/api/documents/") and path.endswith("/versions") and method == "GET":
                did = int(path.split("/")[3])
                self.send_json(200, {"items": document_mgmt.get_versions(SERVICE.store.conn, did)}); return
            raise KeyError("Unknown documents endpoint.")

        if path.startswith("/api/incidents"):
            if path == "/api/incidents" and method == "GET":
                self.send_json(200, {"items": incidents.list_incidents(SERVICE.store.conn, clean(data.get("status")) or None)}); return
            if path == "/api/incidents" and method == "POST":
                iid = incidents.report(SERVICE.store.conn, clean(data.get("title")), clean(data.get("description")), clean(data.get("location")), clean(data.get("severity")), actor, clean(data.get("photo_name")), clean(data.get("photo_path")))
                self.send_json(200, {"ok": True, "id": iid}); return
            if path.startswith("/api/incidents/") and path.endswith("/resolve") and method == "POST":
                iid = int(path.split("/")[3])
                incidents.resolve(SERVICE.store.conn, iid, actor)
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown incidents endpoint.")

        if path.startswith("/api/consent"):
            if path == "/api/consent" and method == "GET":
                self.send_json(200, {"items": consent_register.all_consents(SERVICE.store.conn)}); return
            if path == "/api/consent" and method == "POST":
                cid = consent_register.grant(SERVICE.store.conn, clean(data.get("subject_type")), int(data.get("subject_id") or 0), clean(data.get("consent_type")), actor, clean(data.get("notes")))
                self.send_json(200, {"ok": True, "id": cid}); return
            if path.startswith("/api/consent/") and path.endswith("/withdraw") and method == "POST":
                cid = int(path.split("/")[3])
                consent_register.withdraw(SERVICE.store.conn, cid, actor)
                self.send_json(200, {"ok": True}); return
            if path == "/api/consent/subject" and method == "GET":
                self.send_json(200, {"items": consent_register.list_for(SERVICE.store.conn, clean(data.get("subject_type")), int(data.get("subject_id") or 0))}); return
            raise KeyError("Unknown consent endpoint.")

        if path == "/api/ddns/status" and method == "GET":
            last_ip = ""
            try:
                p = r"C:\NEXUS\tools\ddns_last_ip.txt"
                if os.path.exists(p): last_ip = open(p).read().strip()
            except Exception: pass
            current_ip = ""
            try:
                with urllib.request.urlopen("https://api.ipify.org", timeout=8) as r: current_ip = r.read().decode().strip()
            except Exception: current_ip = "unavailable"
            last_log = ""
            try:
                lp = r"C:\NEXUS\tools\ddns.log"
                if os.path.exists(lp):
                    lines_log = open(lp).read().strip().splitlines()
                    last_log = lines_log[-1] if lines_log else ""
            except Exception: pass
            self.send_json(200, {"hostname": "your-userd-dean.duckdns.org", "current_ip": current_ip, "last_recorded_ip": last_ip or "(never)", "ip_changed": current_ip != last_ip if (current_ip and last_ip) else None, "last_log": last_log}); return
        if path.startswith("/api/evolv3"):
            if not actor:
                raise PermissionError("Your session has expired. Please sign in again.")
            if path == "/api/evolv3/bootstrap" and method == "GET":
                connect = SERVICE.store.conn
                state = evolv3_evolution.get_state(connect)
                self.send_json(200, {
                    "ok": True,
                    "state": state,
                    "nextRunAt": evolv3_evolution.next_run_at(state),
                    "due": evolv3_evolution.should_run_weekly_evolution(state),
                    "modules": evolv3_evolution.list_week_modules(connect),
                    "evaluations": evolv3_evolution.list_week_evaluations(connect),
                    "protocols": evolv3_evolution.list_week_protocols(connect),
                    "learner": evolv3_evolution.get_learner(connect, actor),
                    "leaderboard": evolv3_evolution.leaderboard_rows(connect),
                    "engine": {"version": evolv3_evolution.VERSION,
                               "gemini": bool(os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"))},
                }); return
            if path == "/api/evolv3/weekly-evolve" and method == "POST":
                connect = SERVICE.store.conn
                result = evolv3_evolution.weekly_evolve(
                    connect,
                    requested_week=int(data.get("weekNumber") or 0) or None,
                    existing_ids=data.get("existingCourseIds") or [],
                    actor=actor,
                    force=bool(data.get("force")),
                    source="manual" if data.get("force") else "scheduler",
                )
                SERVICE.store.log(actor, "EVOLV3 weekly curriculum evolved", "evolv3_evolution",
                                  int(result.get("weekNumber") or 0), result.get("summary", "")[:200])
                connect.commit()
                self.send_json(200, result); return
            if path == "/api/evolv3/state" and method == "POST":
                state = evolv3_evolution.set_auto_update(SERVICE.store.conn, bool(data.get("autoUpdateOnWifi")))
                self.send_json(200, {"ok": True, "state": state,
                                     "nextRunAt": evolv3_evolution.next_run_at(state)}); return
            if path == "/api/evolv3/grade" and method == "POST":
                result = evolv3_evolution.grade_answer(
                    data.get("answer"), data.get("expected") or "",
                    data.get("keywords") or [], data.get("kind") or "short")
                self.send_json(200, result); return
            if path == "/api/evolv3/learner" and method == "GET":
                self.send_json(200, {"learner": evolv3_evolution.get_learner(SERVICE.store.conn, actor)}); return
            if path == "/api/evolv3/learner" and method == "POST":
                saved = evolv3_evolution.save_learner(SERVICE.store.conn, actor, data.get("state") or {})
                self.send_json(200, {"ok": True, "learner": saved}); return
            if path == "/api/evolv3/leaderboard" and method == "GET":
                self.send_json(200, {"items": evolv3_evolution.leaderboard_rows(SERVICE.store.conn)}); return
            if path == "/api/evolv3/generate-module-image" and method == "POST":
                # Section 11: additive route. Returns a clean 800x450 clinical
                # SVG as a base64 data URI, topic-matched to the module, with a
                # deterministic fallback so it works with no network or key.
                connect = SERVICE.store.conn
                title = clean(data.get("title")) or ""
                category = clean(data.get("category")) or ""
                summary = clean(data.get("shortDescription")) or clean(data.get("description")) or ""
                hazards = data.get("hazardsCovered") or data.get("hazards") or []
                if isinstance(hazards, str):
                    hazards = [hazards]
                hazards = [clean(h) for h in hazards if clean(h)][:8]
                use_ai = data.get("useAi")
                result = evolv3_evolution.generate_module_image(
                    title, category, summary, hazards,
                    use_ai=(True if use_ai is None else bool(use_ai)))
                module_id = clean(data.get("moduleId")) or clean(data.get("id")) or ""
                saved = False
                if module_id and result.get("imageUrl"):
                    saved = evolv3_evolution.save_module_image(connect, module_id, result["imageUrl"])
                    if saved:
                        try:
                            SERVICE.store.log(actor, "EVOLV3 module artwork generated", "evolv3_evolution",
                                              0, "%s · %s" % (module_id, result.get("engine", "")))
                            connect.commit()
                        except Exception:
                            pass
                self.send_json(200, {
                    "ok": True,
                    "imageUrl": result.get("imageUrl") or "",
                    "topic": result.get("topic") or "",
                    "engine": result.get("engine") or "local-svg",
                    "saved": saved,
                    "moduleId": module_id,
                }); return
            raise KeyError("Unknown EVOLV3 endpoint.")

        if path.startswith("/api/academy"):
            if path == "/api/academy/courses" and method == "GET":
                self.send_json(200, {"items": academy.list_courses(SERVICE.store.conn, clean(data.get("audience")) or None)}); return
            if path == "/api/academy/courses" and method == "POST":
                cid = SERVICE.store.conn.execute("INSERT INTO academy_courses(title,audience,description,status,created_by,created_at) VALUES(?,?,?,?,?,?)", (clean(data.get("title")), clean(data.get("audience")) or "All", clean(data.get("description")), "Draft", actor, __import__("datetime").date.today().isoformat())).lastrowid
                SERVICE.store.conn.commit()
                self.send_json(200, {"ok": True, "id": cid}); return
            if path.startswith("/api/academy/courses/") and path.endswith("/publish") and method == "POST":
                if SERVICE.role_for(actor) != "Administrator":
                    raise PermissionError("Publishing a course requires Administrator permissions.")
                cid = int(path.split("/")[4])
                SERVICE.store.conn.execute("UPDATE academy_courses SET status='Published' WHERE id=?", (cid,))
                SERVICE.store.conn.commit()
                self.send_json(200, {"ok": True, "id": cid, "status": "Published"}); return
            if path == "/api/academy/lessons" and method == "POST":
                if SERVICE.role_for(actor) != "Administrator":
                    raise PermissionError("Adding lessons requires Administrator permissions.")
                cid = int(data.get("course_id") or 0)
                order = SERVICE.store.conn.execute("SELECT COALESCE(MAX(sort_order),0)+1 n FROM academy_lessons WHERE course_id=?", (cid,)).fetchone()["n"]
                lid = SERVICE.store.conn.execute("INSERT INTO academy_lessons(course_id,title,body,sort_order,created_at) VALUES(?,?,?,?,?)",
                                                 (cid, clean(data.get("title")), clean(data.get("body")), order, __import__("datetime").date.today().isoformat())).lastrowid
                SERVICE.store.conn.commit()
                self.send_json(200, {"ok": True, "id": lid}); return
            if path == "/api/academy/quizzes" and method == "POST":
                if SERVICE.role_for(actor) != "Administrator":
                    raise PermissionError("Adding quizzes requires Administrator permissions.")
                lid = int(data.get("lesson_id") or 0)
                correct = clean(data.get("correct")).upper()[:1] or "A"
                qid = SERVICE.store.conn.execute("INSERT INTO academy_quizzes(lesson_id,question,option_a,option_b,option_c,option_d,correct,explanation) VALUES(?,?,?,?,?,?,?,?)",
                                                 (lid, clean(data.get("question")), clean(data.get("option_a")), clean(data.get("option_b")), clean(data.get("option_c")), clean(data.get("option_d")), correct, clean(data.get("explanation")))).lastrowid
                SERVICE.store.conn.commit()
                self.send_json(200, {"ok": True, "id": qid}); return
            if path.startswith("/api/academy/courses/") and method == "GET":
                cid = int(path.split("/")[4])
                self.send_json(200, academy.get_course(SERVICE.store.conn, cid) or {}); return
            if path == "/api/academy/cards" and method == "GET":
                self.send_json(200, {
                    "items": academy.list_cards(SERVICE.store.conn,
                                                clean(data.get("pack")) or academy.PACK,
                                                clean(data.get("kind")) or None),
                    "progress": academy.card_progress(SERVICE.store.conn, actor,
                                                      clean(data.get("pack")) or academy.PACK),
                    "disclaimer": academy.DISCLAIMER,
                    "emergency_numbers": academy.EMERGENCY_NUMBERS,
                }); return
            m = re.fullmatch(r"/api/academy/cards/(\d+)", path)
            if m and method == "GET":
                self.send_json(200, academy.get_card(SERVICE.store.conn, int(m.group(1))) or {}); return
            m = re.fullmatch(r"/api/academy/cards/(\d+)/seen", path)
            if m and method == "POST":
                if not academy.mark_card_seen(SERVICE.store.conn, actor, int(m.group(1))):
                    raise KeyError("That card is not available.")
                self.send_json(200, {"ok": True, "progress": academy.card_progress(
                    SERVICE.store.conn, actor, clean(data.get("pack")) or academy.PACK)}); return
            if path == "/api/academy/quiz" and method == "GET":
                self.send_json(200, {"items": academy.list_questions(
                    SERVICE.store.conn, clean(data.get("pack")) or academy.PACK)}); return
            if path == "/api/academy/quiz/answer" and method == "POST":
                result = academy.answer_question(SERVICE.store.conn, actor,
                                                 int(data.get("question_id") or 0),
                                                 int(data.get("choice") if data.get("choice") is not None else -1))
                if not result:
                    raise KeyError("That question is not available.")
                self.send_json(200, result); return
            if path == "/api/academy/progress" and method == "POST":
                # Progress is tied to the signed-in account. Administrators may record on
                # behalf of another user; everyone else can only update their own.
                target = clean(data.get("user")) or actor
                if SERVICE.role_for(actor) != "Administrator":
                    target = actor
                academy.complete_lesson(SERVICE.store.conn, target, int(data.get("course_id")), int(data.get("lesson_id")), int(data.get("score") or 0))
                cert = academy.check_completion(SERVICE.store.conn, target, int(data.get("course_id")))
                self.send_json(200, {"ok": True, "certificate": cert}); return
            if path == "/api/academy/progress" and method == "GET":
                target = clean(data.get("user")) or actor
                if SERVICE.role_for(actor) != "Administrator":
                    target = actor
                self.send_json(200, academy.progress(SERVICE.store.conn, target, int(data.get("course_id")))); return
            if path == "/api/academy/rate" and method == "POST":
                kind = clean(data.get("kind")) or "card"
                rid = int(data.get("id") or 0)
                rating = int(data.get("rating") or 0)
                ok = (academy.rate_card(SERVICE.store.conn, actor, rid, rating)
                      if kind == "card" else
                      academy.rate_question(SERVICE.store.conn, actor, rid, rating))
                if not ok:
                    raise KeyError("That item is not available.")
                self.send_json(200, {"ok": True}); return
            if path == "/api/academy/ratings" and method == "GET":
                self.send_json(200, academy.ratings_summary(
                    SERVICE.store.conn, clean(data.get("pack")) or academy.PACK)); return
            if path == "/api/academy/evolve" and method == "POST":
                if SERVICE.role_for(actor) != "Administrator":
                    raise PermissionError("Evolving the pack requires Administrator permissions.")
                pack = clean(data.get("pack")) or academy.PACK
                n_cards = int(data.get("cards") or 2)
                n_quizzes = int(data.get("quizzes") or 1)
                import threading as _thr
                def _run_evolve():
                    try:
                        academy.evolve(SERVICE.store.conn, SERVICE._evolve_llm, pack,
                                       n_cards, n_quizzes, actor, db_lock=SERVICE.lock)
                    except Exception as exc:
                        try:
                            with SERVICE.lock:
                                SERVICE.store.log("evolv3", "Background evolution failed", "academy_evolution", 0, str(exc)[:200])
                                SERVICE.store.conn.commit()
                        except Exception:
                            pass
                _thr.Thread(target=_run_evolve, daemon=True, name="evolv3-evolve").start()
                self.send_json(200, {"ok": True, "status": "started",
                                     "message": "Evolution started in the background. It takes a few minutes; refresh to see new cards."}); return
            if path == "/api/academy/evolutions" and method == "GET":
                self.send_json(200, {"items": academy.list_evolutions(SERVICE.store.conn)}); return
            if path == "/api/academy/certificates" and method == "GET":
                self.send_json(200, {"items": academy.list_certificates(SERVICE.store.conn, actor)}); return
            if path == "/api/academy/certificates/verify" and method == "POST":
                self.send_json(200, academy.verify_certificate(SERVICE.store.conn, data.get("code"))); return
            m = re.fullmatch(r"/api/academy/certificates/(\d+)/(view|pdf|qr\.png)", path)
            if m:
                cid = int(m.group(1)); kind = m.group(2)
                detail = academy.certificate_detail(SERVICE.store.conn, cid)
                if not detail: raise KeyError("That certificate does not exist.")
                if SERVICE.role_for(actor) != "Administrator" and str(detail.get("user")) != actor:
                    raise PermissionError("That certificate belongs to another account.")
                base = "/api/academy/certificates/" + str(cid)
                qr = certificates.qr_png(detail.get("qr_payload") or "")
                if kind == "view":
                    raw = certificates.html_page(detail, base + "/qr.png", base + "/pdf").encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(raw)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers(); self.wfile.write(raw); return
                if kind == "pdf":
                    raw = certificates.pdf_bytes(detail, qr)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/pdf")
                    self.send_header("Content-Disposition", 'inline; filename="EVOLV3-' + str(detail.get("certificate_no")) + '.pdf"')
                    self.send_header("Content-Length", str(len(raw)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers(); self.wfile.write(raw); return
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(qr)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers(); self.wfile.write(qr); return
            if path == "/api/academy/enrol" and method == "POST":
                cid = int(data.get("course_id") or 0)
                if not academy.enrol(SERVICE.store.conn, actor, cid): raise KeyError("Course not found or not published.")
                self.send_json(200, {"ok": True, "enrolled": True}); return
            if path == "/api/academy/my-courses" and method == "GET":
                self.send_json(200, {"items": academy.my_courses(SERVICE.store.conn, actor)}); return
            if path == "/api/academy/unenrol" and method == "POST":
                academy.unenrol(SERVICE.store.conn, actor, int(data.get("course_id") or 0))
                self.send_json(200, {"ok": True}); return
            raise KeyError("Unknown academy endpoint.")

        if path.startswith("/api/requests"):
            rr = resource_requests
            conn = SERVICE.store.conn
            manager = permissions.user_role in ("Administrator", "Manager")
            if path == "/api/requests/settings" and method == "GET":
                rows = conn.execute("SELECT key,value FROM resource_request_settings").fetchall()
                self.send_json(200, {"settings": {r["key"]: r["value"] for r in rows},
                                     "categories": rr.CATEGORIES, "statuses": rr.STATUSES}); return
            if path == "/api/requests/settings" and method == "POST":
                if permissions.user_role != "Administrator":
                    raise PermissionError("Only Administrators can change request settings.")
                for key in ("allow_self_approval", "employee_collection_note"):
                    if key in data:
                        conn.execute("INSERT INTO resource_request_settings(key,value) VALUES(?,?) "
                                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, clean(data.get(key))))
                conn.commit(); self.send_json(200, {"ok": True}); return
            if path == "/api/requests/report" and method == "GET":
                self.send_json(200, rr.report(conn)); return
            if path == "/api/requests/assets" and method == "GET":
                self.send_json(200, {"items": rr.list_assets(conn, data.get("employee_id") or None)}); return
            m = re.fullmatch(r"/api/requests/assets/(\d+)/(acknowledge|return)", path)
            if m and method == "POST":
                aid = int(m.group(1))
                if m.group(2) == "acknowledge":
                    item = rr.acknowledge_asset(conn, aid, actor)
                else:
                    item = rr.return_asset(conn, aid, clean(data.get("condition")), actor)
                SERVICE.store.log(actor, "Asset " + m.group(2), "resource_asset", str(aid))
                self.send_json(200, {"ok": True, "asset": item}); return
            if path == "/api/requests" and method == "GET":
                self.send_json(200, {"items": rr.list_requests(
                    conn, employee_id=data.get("employee_id") or None,
                    status=clean(data.get("status")) or None,
                    department=clean(data.get("department")) or None,
                    search=clean(data.get("search")))}); return
            if path == "/api/requests" and method == "POST":
                item = rr.create_request(conn, data, actor)
                SERVICE.store.log(actor, "Resource request created", "resource_request", str(item["id"]), item["ref"])
                self.send_json(201, {"ok": True, "request": item}); return
            m = re.fullmatch(r"/api/requests/(\d+)/decision", path)
            if m and method == "POST":
                if not manager:
                    raise PermissionError("Only Managers and Administrators can decide resource requests.")
                rid = int(m.group(1))
                cost = float(data["approved_cost"]) if data.get("approved_cost") not in (None, "") else None
                item = rr.decide(conn, rid, clean(data.get("decision")), actor, permissions.user_role,
                                 reason=clean(data.get("reason")), approved_cost=cost)
                SERVICE.store.log(actor, "Resource request " + clean(data.get("decision")).lower(),
                                  "resource_request", str(rid), item["ref"] if item else "")
                self.send_json(200, {"ok": True, "request": item}); return
            m = re.fullmatch(r"/api/requests/(\d+)/(information|order|receive|asset|complete|cancel)", path)
            if m and method == "POST":
                rid = int(m.group(1)); step = m.group(2)
                if step in ("order", "receive", "asset") and not manager:
                    raise PermissionError("Only Managers and Administrators can perform procurement actions.")
                if step == "information":
                    item = rr.provide_information(conn, rid, actor, clean(data.get("detail")))
                elif step == "order":
                    item = rr.order_procurement(conn, rid, clean(data.get("supplier")), float(data.get("total") or 0),
                                                clean(data.get("expected_at")), actor, clean(data.get("notes")))
                elif step == "receive":
                    total = float(data["total"]) if data.get("total") not in (None, "") else None
                    item = rr.receive_procurement(conn, rid, clean(data.get("supplier")), total, actor, clean(data.get("notes")))
                elif step == "asset":
                    result = rr.allocate_asset(conn, rid, data, actor)
                    SERVICE.store.log(actor, "Asset allocated", "resource_request", str(rid), result["asset_no"])
                    self.send_json(200, {"ok": True, **result}); return
                elif step == "complete":
                    item = rr.complete_request(conn, rid, actor)
                else:
                    item = rr.cancel_request(conn, rid, actor, clean(data.get("reason")))
                SERVICE.store.log(actor, "Resource request " + step, "resource_request", str(rid),
                                  item["ref"] if item else "")
                self.send_json(200, {"ok": True, "request": item}); return
            m = re.fullmatch(r"/api/requests/(\d+)", path)
            if m and method == "GET":
                item = rr.get_request(conn, int(m.group(1)))
                if not item:
                    raise KeyError("Request not found.")
                self.send_json(200, item); return
            raise KeyError("Unknown resource request endpoint.")

        if path.startswith("/api/mc"):
            mc = master_control
            conn = SERVICE.store.conn
            if permissions.user_role != "Administrator":
                raise PermissionError("MASTER CONTROL is restricted to Administrators.")
            if path == "/api/mc/owner" and method == "GET":
                self.send_json(200, mc.owner_profile(conn, actor)); return
            if path == "/api/mc/overview" and method == "GET":
                self.send_json(200, mc.owner_centre(conn)); return
            if path == "/api/mc/settings" and method == "GET":
                self.send_json(200, {"owner_username": mc.setting(conn, "owner_username", ""),
                                     "owner_display_name": mc.setting(conn, "owner_display_name", "DEAN BROWN"),
                                     "products": mc.PRODUCTS, "product_modules": mc.PRODUCT_MODULES}); return
            if path == "/api/mc/settings" and method == "POST":
                if not mc.is_owner(conn, actor):
                    raise PermissionError("Only the Platform Owner can change owner settings.")
                if data.get("owner_username"):
                    mc.set_setting(conn, "owner_username", clean(data.get("owner_username")))
                if data.get("owner_display_name"):
                    mc.set_setting(conn, "owner_display_name", clean(data.get("owner_display_name")))
                self.send_json(200, {"ok": True, **mc.owner_profile(conn, actor)}); return
            if path == "/api/mc/customers" and method == "GET":
                self.send_json(200, {"items": mc.list_customers(conn, clean(data.get("status")) or None,
                                                               clean(data.get("search")))}); return
            if path == "/api/mc/customers" and method == "POST":
                item = mc.create_customer(conn, data, actor)
                SERVICE.store.log(actor, "Customer created", "mc_customer", str(item["id"]), item["customer_no"])
                self.send_json(201, {"ok": True, "customer": item}); return
            m = re.fullmatch(r"/api/mc/customers/(\d+)/(suspend|restore)", path)
            if m and method == "POST":
                cid = int(m.group(1)); step = m.group(2)
                if not mc.is_owner(conn, actor):
                    raise PermissionError("Only the Platform Owner (" + mc.resolve_owner(conn) +
                                          ") may suspend or restore service.")
                if not SERVICE.store.authenticate(actor, str(data.get("owner_password") or "")):
                    raise PermissionError("Owner re-authentication failed. Enter your own password to confirm.")
                reason = clean(data.get("reason")); scope = clean(data.get("scope")) or "all"
                sub = int(data["subscription_id"]) if data.get("subscription_id") else None
                if step == "suspend":
                    result = mc.suspend(conn, cid, sub, actor, reason, scope)
                    SERVICE.store.log(actor, "Customer suspended", "mc_customer", str(cid), reason)
                else:
                    result = mc.restore(conn, cid, sub, actor, reason, scope)
                    SERVICE.store.log(actor, "Customer restored", "mc_customer", str(cid), reason)
                self.send_json(200, {"ok": True, **result}); return
            m = re.fullmatch(r"/api/mc/customers/(\d+)", path)
            if m and method == "GET":
                item = mc.get_customer(conn, int(m.group(1)))
                if not item:
                    raise KeyError("Customer not found.")
                self.send_json(200, item); return
            if m and method in ("PUT", "POST"):
                item = mc.update_customer(conn, int(m.group(1)), data, actor)
                self.send_json(200, {"ok": True, "customer": item}); return
            if path == "/api/mc/subscriptions" and method == "GET":
                self.send_json(200, {"items": mc.list_subscriptions(conn, data.get("customer_id") or None,
                                                                    clean(data.get("status")) or None)}); return
            if path == "/api/mc/subscriptions" and method == "POST":
                item = mc.create_subscription(conn, data, actor)
                self.send_json(201, {"ok": True, "subscription": item}); return
            m = re.fullmatch(r"/api/mc/subscriptions/(\d+)/status", path)
            if m and method == "POST":
                item = mc.set_subscription_status(conn, int(m.group(1)), clean(data.get("status")),
                                                  actor, clean(data.get("reason")))
                self.send_json(200, {"ok": True, "subscription": item}); return
            if path == "/api/mc/invoices" and method == "GET":
                self.send_json(200, {"items": mc.list_invoices(conn, data.get("customer_id") or None,
                                                               clean(data.get("status")) or None)}); return
            if path == "/api/mc/invoices" and method == "POST":
                item = mc.create_invoice(conn, data, actor)
                self.send_json(201, {"ok": True, "invoice": item}); return
            m = re.fullmatch(r"/api/mc/invoices/(\d+)/payment", path)
            if m and method == "POST":
                item = mc.record_payment(conn, int(m.group(1)), float(data.get("amount") or 0),
                                         clean(data.get("method")) or "Bank transfer", clean(data.get("reference")),
                                         actor, customer_reported=bool(data.get("customer_reported")),
                                         notes=clean(data.get("notes")))
                self.send_json(200, {"ok": True, "invoice": item}); return
            m = re.fullmatch(r"/api/mc/invoices/(\d+)", path)
            if m and method == "GET":
                item = mc.get_invoice(conn, int(m.group(1)))
                if not item:
                    raise KeyError("Invoice not found.")
                self.send_json(200, item); return
            m = re.fullmatch(r"/api/mc/payments/(\d+)/verify", path)
            if m and method == "POST":
                approve = bool(data.get("approve", True))
                item = mc.verify_payment(conn, int(m.group(1)), actor, approve, clean(data.get("reason")))
                SERVICE.store.log(actor, "Payment verified" if approve else "Payment rejected",
                                  "mc_payment", m.group(1))
                self.send_json(200, {"ok": True, "invoice": item}); return
            if path == "/api/mc/alerts" and method == "GET":
                self.send_json(200, {"items": mc.list_alerts(conn, clean(data.get("status")) or "Open")}); return
            m = re.fullmatch(r"/api/mc/alerts/(\d+)/ack", path)
            if m and method == "POST":
                self.send_json(200, {"ok": True, "alert": mc.acknowledge_alert(conn, int(m.group(1)), actor)}); return
            if path == "/api/mc/scan" and method == "POST":
                self.send_json(200, {"ok": True, **mc.overdue_scan(conn)}); return
            if path == "/api/mc/entitlements" and method == "POST":
                result = mc.issue_entitlement(conn, int(data.get("customer_id") or 0),
                                              int(data.get("subscription_id") or 0), int(data.get("days") or 30))
                SERVICE.store.log(actor, "Entitlement issued", "mc_entitlement",
                                  str(data.get("subscription_id")), result["payload"]["sub_ref"])
                self.send_json(200, {"ok": True, **result}); return
            if path == "/api/mc/entitlements/validate" and method == "POST":
                self.send_json(200, mc.validate_entitlement(conn, str(data.get("token") or ""),
                                                            grace_seconds=int(data.get("grace_seconds") or 0),
                                                            online=bool(data.get("online", True)))); return
            if path == "/api/mc/report" and method == "GET":
                self.send_json(200, mc.report(conn, clean(data.get("date_from")), clean(data.get("date_to")))); return
            if path == "/api/mc/currencies" and method == "GET":
                self.send_json(200, {"items": mc.list_currencies(conn)}); return
            if path == "/api/mc/currencies/rate" and method == "POST":
                if not mc.is_owner(conn, actor):
                    raise PermissionError("Only the Platform Owner can update exchange rates.")
                r = mc.set_exchange_rate(conn, data.get("base_currency"), data.get("quote_currency"), data.get("rate"), actor)
                self.send_json(200, {"ok": True, "rate": r}); return
            m = re.fullmatch(r"/api/mc/customers/(\d+)/statement\.pdf", path)
            if m and method == "GET":
                if not mc.is_owner(conn, actor):
                    raise PermissionError("Only the Platform Owner can view customer statements.")
                pdf = mc.render_customer_statement_pdf(conn, int(m.group(1)), clean(data.get("from")), clean(data.get("to")))
                self.send_response(200); self.send_header("Content-Type","application/pdf"); self.send_header("Content-Disposition",f'attachment; filename="statement-{m.group(1)}.pdf"'); self.send_header("Content-Length",str(len(pdf))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(pdf); return
            m = re.fullmatch(r"/api/mc/customers/(\d+)/statement", path)
            if m and method == "GET":
                if not mc.is_owner(conn, actor):
                    raise PermissionError("Only the Platform Owner can view customer statements.")
                self.send_json(200, mc.build_customer_statement(conn, int(m.group(1)), clean(data.get("from")), clean(data.get("to")))); return
            if path == "/api/mc/public-key" and method == "GET":
                self.send_json(200, {"public_key": mc.public_key_b64()}); return
            raise KeyError("Unknown MASTER CONTROL endpoint.")

        if path.startswith("/api/cn3ct"):
            cn = cn3ct
            conn = SERVICE.store.conn
            if permissions.user_role != "Administrator":
                raise PermissionError("The CN3CT control plane is restricted to Administrators.")
            if path == "/api/cn3ct/overview" and method == "GET":
                self.send_json(200, cn.overview(conn)); return
            if path == "/api/cn3ct/diagnostics" and method == "GET":
                self.send_json(200, cn.diagnostics(conn, data.get("org_id") or None)); return
            if path == "/api/cn3ct/settings" and method == "GET":
                self.send_json(200, {"public_endpoint": cn.setting(conn, "public_endpoint", ""),
                                     "dns": cn.setting(conn, "dns", ""),
                                     "allow_internal_without_entitlement":
                                         cn.setting(conn, "allow_internal_without_entitlement", "yes")}); return
            if path == "/api/cn3ct/settings" and method == "POST":
                for key in ("public_endpoint", "dns", "allow_internal_without_entitlement"):
                    if key in data:
                        cn.set_setting(conn, key, clean(data.get(key)), actor)
                self.send_json(200, {"ok": True}); return
            if path == "/api/cn3ct/orgs" and method == "GET":
                self.send_json(200, {"items": cn.list_orgs(conn)}); return
            if path == "/api/cn3ct/orgs" and method == "POST":
                item = cn.create_org(conn, data, actor)
                SERVICE.store.log(actor, "CN3CT organisation created", "cn_org", str(item["id"]), item["org_no"])
                self.send_json(201, {"ok": True, "organisation": item}); return
            m = re.fullmatch(r"/api/cn3ct/orgs/(\d+)", path)
            if m and method == "GET":
                item = cn.get_org(conn, int(m.group(1)))
                if not item:
                    raise KeyError("Organisation not found.")
                self.send_json(200, item); return
            if path == "/api/cn3ct/networks" and method == "GET":
                self.send_json(200, {"items": cn.list_networks(conn, data.get("org_id") or None)}); return
            if path == "/api/cn3ct/networks" and method == "POST":
                item = cn.create_network(conn, int(data.get("org_id") or 0), data, actor)
                self.send_json(201, {"ok": True, "network": item}); return
            m = re.fullmatch(r"/api/cn3ct/networks/(\d+)", path)
            if m and method == "GET":
                item = cn.get_network(conn, int(m.group(1)))
                if not item:
                    raise KeyError("Network not found.")
                self.send_json(200, item); return
            if path == "/api/cn3ct/devices" and method == "GET":
                self.send_json(200, {"items": cn.list_devices(conn, data.get("org_id") or None)}); return
            if path == "/api/cn3ct/devices" and method == "POST":
                item = cn.register_device(conn, int(data.get("org_id") or 0), data, actor,
                                          data.get("entitlement_token"))
                SERVICE.store.log(actor, "CN3CT device registered", "cn_device", str(item["id"]), item["device_no"])
                self.send_json(201, {"ok": True, "device": item}); return
            m = re.fullmatch(r"/api/cn3ct/devices/(\d+)/(approve|revoke)", path)
            if m and method == "POST":
                did = int(m.group(1))
                if m.group(2) == "approve":
                    item = cn.approve_device(conn, did, actor, True, clean(data.get("reason")))
                else:
                    item = cn.revoke_device(conn, did, actor, clean(data.get("reason")))
                SERVICE.store.log(actor, "CN3CT device " + m.group(2), "cn_device", str(did))
                self.send_json(200, {"ok": True, "device": item}); return
            m = re.fullmatch(r"/api/cn3ct/devices/(\d+)/config", path)
            if m and method == "GET":
                cfg = cn.build_device_config(conn, int(m.group(1)))
                if not cfg:
                    raise KeyError("Device or network membership not found.")
                self.send_json(200, cfg); return
            m = re.fullmatch(r"/api/cn3ct/devices/(\d+)", path)
            if m and method == "GET":
                item = cn.get_device(conn, int(m.group(1)))
                if not item:
                    raise KeyError("Device not found.")
                self.send_json(200, item); return
            if path == "/api/cn3ct/gateways" and method == "GET":
                self.send_json(200, {"items": cn.list_gateways(conn, data.get("org_id") or None)}); return
            if path == "/api/cn3ct/gateways" and method == "POST":
                item = cn.create_gateway(conn, int(data.get("org_id") or 0), data, actor)
                self.send_json(201, {"ok": True, "gateway": item}); return
            if path == "/api/cn3ct/routes" and method == "POST":
                item = cn.create_route(conn, int(data.get("org_id") or 0), data, actor)
                self.send_json(201, {"ok": True, "route": item}); return
            if path == "/api/cn3ct/policies" and method == "POST":
                item = cn.create_policy(conn, int(data.get("org_id") or 0), data, actor)
                self.send_json(201, {"ok": True, "policy": item}); return
            m = re.fullmatch(r"/api/cn3ct/policy-rules/(\d+)", path)
            if m and method in ("PUT","PATCH"):
                item = cn.edit_policy_rule(conn, int(m.group(1)), int(data.get("org_id") or 0), data, actor)
                self.send_json(200, {"ok": True, "rule": item}); return
            if m and method == "DELETE":
                cn.delete_policy_rule(conn, int(m.group(1)), int(data.get("org_id") or 0), actor)
                self.send_json(200, {"ok": True}); return
            m = re.fullmatch(r"/api/cn3ct/policy-rules/(\d+)/toggle", path)
            if m and method == "POST":
                item = cn.toggle_policy_rule(conn, int(m.group(1)), int(data.get("org_id") or 0),
                                            bool(data.get("enabled", True)), actor)
                self.send_json(200, {"ok": True, "rule": item}); return
            if path == "/api/cn3ct/wg-status" and method == "GET":
                self.send_json(200, cn.wg_status(data.get("interface") or "cn3ct")); return
            if path == "/api/cn3ct/server-config" and method == "GET":
                self.send_json(200, cn.build_server_config(conn)); return
            if path == "/api/cn3ct/audit" and method == "GET":
                self.send_json(200, {"items": cn.audit_log(conn, data.get("org_id") or None,
                                                           int(data.get("limit") or 100))}); return
            raise KeyError("Unknown CN3CT endpoint.")

        # Enforce permissions at the API boundary; hiding a menu is not access control.
        if path.startswith("/api/audit") and permissions.user_role != "Administrator":
            raise PermissionError("The audit ledger is restricted to Administrators.")
        if path in ("/api/system/health","/api/upgrades") or path.startswith("/api/upgrades/"):
            if permissions.user_role != "Administrator":
                raise PermissionError("Only Administrators can use system health and script staging tools.")
        if path == "/api/vision/status" and not (permissions.user_role == "Administrator" or permissions.allows("ai","configure")):
            raise PermissionError("Vision service status requires AI configuration permission.")
        if path == "/api/attendance/rebuild" and not (permissions.user_role == "Administrator" or permissions.allows("attendance","approve")):
            raise PermissionError("Rebuilding attendance requires attendance approval permission.")
        if (path == "/api/employees" or re.fullmatch(r"/api/employees/\d+", path)) and self.command != "GET" and not permissions.allows("employees","edit"):
            raise PermissionError("Employee records can only be changed with employee edit permission.")
        # Module-level permission gates so explicit policies are enforced API-side.
        read_module = None
        if path == "/api/employees" or path.startswith("/api/employees/"): read_module = "employees"
        elif path.startswith("/api/hr"): read_module = "hr"
        elif path.startswith("/api/contracts"): read_module = "hr"
        elif path.startswith("/api/documents"): read_module = "documents"
        elif path.startswith("/api/reviews"): read_module = "performance"
        elif path.startswith("/api/leave"): read_module = "leave"
        elif path == "/api/attendance" or re.fullmatch(r"/api/attendance/\d+", path): read_module = "attendance"
        elif path.startswith("/api/compliance"): read_module = "reports_audit"
        if read_module and self.command == "GET" and not permissions.allows(read_module, "view"):
            raise PermissionError("These records are not visible to this account.")
        write_module = None; write_action = None
        if path.startswith("/api/hr") or path.startswith("/api/contracts"):
            write_module = "hr"
        elif path.startswith("/api/documents"):
            write_module = "documents"
        elif path.startswith("/api/reviews"):
            write_module = "performance"
        elif re.fullmatch(r"/api/leave/\d+/decision", path):
            write_module = "leave"; write_action = "approve"
        elif path == "/api/leave" and self.command == "POST":
            write_module = "leave"; write_action = "submit"
        elif path.startswith("/api/leave"):
            write_module = "leave"; write_action = "edit"
        elif path == "/api/attendance/manual" or path == "/api/attendance/import":
            write_module = "attendance"; write_action = "record"
        elif path.startswith("/api/attendance/") and self.command == "DELETE":
            write_module = "attendance"; write_action = "correct"
        if write_module and self.command != "GET":
            catalog = PermissionMaskingEngine.PERMISSION_CATALOG.get(write_module, ())
            post_action = {"hr":"add","documents":"upload","performance":"create","leave":"submit","attendance":"record"}.get(write_module,"add")
            action = write_action or (post_action if self.command == "POST" else ("delete" if "delete" in catalog else "edit"))
            if self.command == "PUT": action = "edit" if "edit" in catalog else action
            if not permissions.allows(write_module, action):
                raise PermissionError(f"{write_module} records cannot be changed with this permission.")
        if path.startswith("/api/payroll") and not permissions.can_view_payroll():
            raise PermissionError("Payroll information is restricted to Administrators and Managers.")
        if path in ("/api/payroll/settings", "/api/attendance/settings") and not permissions.can_modify_system_settings():
            raise PermissionError("Only Administrators can modify or view system settings.")
        if path.startswith(("/api/users", "/api/backup", "/api/restore")) and permissions.user_role != "Administrator":
            raise PermissionError("Only Administrators can manage users, backups or system restoration.")
        if path.startswith("/api/cameras") and permissions.user_role != "Administrator":
            raise PermissionError("Only Administrators can manage camera feeds and recordings.")
        if path.startswith("/api/payroll") and self.command != "GET" and permissions.user_role != "Administrator":
            raise PermissionError("Managers have read-only payroll access. Only Administrators can change payroll.")

        if path == "/api/cameras" and method == "GET":
            self.send_json(200, SERVICE.cameras.snapshot()); return
        if path == "/api/cameras/settings" and method == "PUT":
            result = SERVICE.cameras.save_settings(data.get("recording_folder"), data.get("retention_days", 3))
            SERVICE.store.log(actor, "Updated camera recording settings", "camera", "", f"Retention {result['retention_days']} days")
            self.send_json(200, result); return
        if path == "/api/cameras/devices" and method == "POST":
            result = SERVICE.cameras.save_camera(data.get("id"), data.get("name"), data.get("model"), data.get("source_url"))
            SERVICE.store.log(actor, "Configured local camera", "camera", result["cameras"][-1]["id"], f"{data.get('model')} camera")
            self.send_json(200, result); return
        camera_match = re.fullmatch(r"/api/cameras/devices/([a-f0-9]{12})", path)
        if camera_match and method == "GET":
            # Edit form (Administrator only - guarded above): includes the RTSP login.
            self.send_json(200, SERVICE.cameras.camera_form(camera_match.group(1))); return
        if camera_match and method == "PUT":
            result = SERVICE.cameras.rename_camera(camera_match.group(1), data.get("name"))
            SERVICE.store.log(actor, "Renamed local camera", "camera", camera_match.group(1), clean(data.get("name")))
            self.send_json(200, result); return
        if camera_match and method == "DELETE":
            SERVICE.cameras.delete_camera(camera_match.group(1))
            SERVICE.store.log(actor, "Removed local camera", "camera", camera_match.group(1))
            self.send_json(200, SERVICE.cameras.snapshot()); return
        camera_action = re.fullmatch(r"/api/cameras/devices/([a-f0-9]{12})/(live|refresh)", path)
        if camera_action and camera_action.group(2) == "refresh" and method == "POST":
            result = SERVICE.cameras.refresh_camera(camera_action.group(1))
            SERVICE.store.log(actor, "Restarted camera viewer", "camera", camera_action.group(1))
            self.send_json(200, result); return
        if camera_action and camera_action.group(2) == "live" and method == "GET":
            frame = SERVICE.cameras.latest_frame(camera_action.group(1))
            if not frame:
                # No fresh frame (viewer starting or camera offline): the tile shows "reconnecting".
                self.send_response(204); self.send_header("Cache-Control", "no-store"); self.end_headers(); return
            self.send_response(200); self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(frame))); self.send_header("Cache-Control", "no-store")
            self.end_headers(); self.wfile.write(frame); return
        if path == "/api/cameras/footage/preview" and method == "POST":
            self.send_json(200, SERVICE.cameras.footage_preview(data.get("month", ""), data.get("start", ""), data.get("end", ""))); return
        if path == "/api/cameras/footage/delete" and method == "POST":
            result = SERVICE.cameras.delete_footage(data.get("month", ""), data.get("start", ""), data.get("end", ""), data.get("confirm") is True)
            SERVICE.store.log(actor, "Deleted camera footage", "camera_footage", "", f"Deleted {result['deleted']} files; failures {result['failed']}")
            self.send_json(200, result); return

        # Safe record deletion: only explicitly supported record collections are exposed.
        dm=re.fullmatch(r"/api/(hr|contracts|documents|reviews|leave|payroll|attendance)/(\d+)",path)
        if dm and method=="DELETE":
            kind,rid=dm.group(1),int(dm.group(2))
            delete_tables={"hr":"hr_records","contracts":"employee_contracts","documents":"employee_documents","reviews":"performance_reviews","leave":"leave_records","payroll":"payroll_records","attendance":"attendance_daily"}
            table=delete_tables[kind]
            row=SERVICE.store.conn.execute(f"SELECT * FROM {table} WHERE id=?",(rid,)).fetchone()
            if not row: raise KeyError("Record not found.")
            if kind=="payroll" and clean(row["status"]).lower() not in ("draft","drafted"):
                raise PermissionError("Only Drafted payroll records can be deleted. Approved or paid payroll must be corrected through an authorised adjustment.")
            if kind=="leave" and clean(row["status"]).lower() not in ("pending","declined","cancelled"):
                raise PermissionError("Only pending, declined or cancelled leave requests can be deleted. Approved leave must remain in the audit history.")
            if kind=="attendance" and clean(row["source"]).lower() not in ("manual",""):
                raise PermissionError("Imported attendance cannot be deleted here. Correct the source/import instead to preserve attendance history.")
            SERVICE.store.conn.execute(f"DELETE FROM {table} WHERE id=?",(rid,))
            SERVICE.store.log(actor,f"Deleted {kind} record",kind,rid,"Administrator-confirmed deletion")
            SERVICE.store.conn.commit()
            self.send_json(200,{"ok":True,"deleted_id":rid}); return

        if path=="/api/compliance" and method=="GET": self.send_json(200,SERVICE.compliance_snapshot()); return
        if path=="/api/compliance/detail" and method=="GET":
            self.send_json(200,SERVICE.compliance_detail(q.get("record_id",[""])[0],q.get("issue",[""])[0],q.get("period",[""])[0],q.get("employee_no",[""])[0])); return
        if path=="/api/dashboard" and method=="GET":
            snapshot=SERVICE.dashboard()
            if not permissions.can_view_payroll(): snapshot["payroll_pending"]=None
            if not permissions.can_view_audit_ledger(): snapshot["recent"]=[]
            self.send_json(200,snapshot); return
        if path=="/api/employees" and method=="GET": self.send_json(200,{"items":SERVICE.employees(q.get("search",[""])[0],permissions)}); return
        if path=="/api/employees" and method=="POST":
            obj={k:clean(data.get(k)) for k in EMPLOYEE_FIELDS}
            if not obj["employee_no"] or not obj["first_name"] or not obj["last_name"]: raise ValueError("Employee number, first name and last name are required.")
            if data.get("photoData"):
                obj["photo_path"]=SERVICE.save_upload({"filename":data.get("photoName"),"data":data.get("photoData")},"photos")["file_path"]
            eid=SERVICE.store.save_employee(obj,None,actor); self.send_json(201,{"id":eid}); return
        m=re.fullmatch(r"/api/employees/(\d+)/photo",path)
        if m and method=="GET":
            row=SERVICE.store.employee(int(m.group(1)))
            if not row or not row["photo_path"]: raise KeyError("Employee photo not found.")
            photo=Path(row["photo_path"]).resolve()
            try: photo.relative_to(legacy.PHOTO_DIR.resolve())
            except ValueError: raise PermissionError("The requested file is outside the employee photo folder.")
            if not photo.is_file(): raise KeyError("Employee photo file is missing.")
            ctype=mimetypes.guess_type(photo.name)[0] or "application/octet-stream"
            self.send_response(200); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(photo.stat().st_size)); self.send_header("Cache-Control","no-store"); self.end_headers()
            with photo.open("rb") as fh: self.wfile.write(fh.read())
            return
        m=re.fullmatch(r"/api/employees/(\d+)",path)
        if m and method=="GET": self.send_json(200,SERVICE.employee_detail(int(m.group(1)),permissions)); return
        if m and method=="PUT":
            eid=int(m.group(1))
            if not permissions.employee_in_scope(eid): raise PermissionError("This employee is outside your assigned scope.")
            obj={k:clean(data.get(k)) for k in EMPLOYEE_FIELDS}
            if data.get("photoData"):
                obj["photo_path"]=SERVICE.save_upload({"filename":data.get("photoName"),"data":data.get("photoData")},"photos")["file_path"]
            else:
                prior=SERVICE.store.employee(eid)
                if prior: obj["photo_path"]=prior["photo_path"] or ""
            SERVICE.store.save_employee(obj,eid,actor); self.send_json(200,{"id":eid}); return

        if path == "/api/hr/fatigue" and method=="GET":
            try: days=max(5,min(int(q.get("days",["8"])[0]),30))
            except (TypeError,ValueError): days=8
            self.send_json(200,{"items":SERVICE.fatigue_flags(days),"threshold":days}); return
        if path in ("/api/hr","/api/contracts","/api/documents","/api/reviews","/api/attendance","/api/leave","/api/payroll") and method=="GET":
            kind=path.rsplit("/",1)[-1]
            if kind=="hr":
                query={"employee_id":q.get("employee_id",[None])[0],"record_type":q.get("record_type",[None])[0]}
            elif kind in ("attendance","leave","payroll"):
                query={"employee_id":q.get("employee_id",[None])[0],"from":q.get("from",[None])[0],"to":q.get("to",[None])[0],"status":q.get("status",[None])[0],"period":q.get("period",[None])[0]}
            else: query={}
            self.send_json(200,{"items":SERVICE.record_list(kind,query)}); return
        if path in ("/api/hr","/api/contracts","/api/documents","/api/reviews") and method=="POST":
            kind=path.rsplit("/",1)[-1]
            if data.get("fileData"):
                saved=SERVICE.save_upload({"filename":data.get("fileName"),"data":data.get("fileData")},"docs")
                data["file_path"]=saved["file_path"]
                if kind!="hr": data["file_name"]=saved["file_name"]
            rid=SERVICE.create_generic(kind,data,actor,int(data["id"]) if data.get("id") else None); self.send_json(201,{"id":rid}); return
        m=re.fullmatch(r"/api/(hr|contracts|documents|reviews)/(\d+)",path)
        if m and method=="GET":
            kind,rid=m.group(1),int(m.group(2)); table=GENERIC[kind][0] if kind!="hr" else "hr_records"
            row=SERVICE.store.conn.execute(f"SELECT * FROM {table} WHERE id=?",(rid,)).fetchone()
            if not row: raise KeyError("Record not found.")
            self.send_json(200,dict(row)); return
        if m and method in ("PUT","POST"):
            kind,rid=m.group(1),int(m.group(2))
            if data.get("fileData"):
                saved=SERVICE.save_upload({"filename":data.get("fileName"),"data":data.get("fileData")},"docs")
                data["file_path"]=saved["file_path"]
                if kind!="hr": data["file_name"]=saved["file_name"]
            saved_id=SERVICE.create_generic(kind,data,actor,rid)
            self.send_json(200,{"id":saved_id}); return
        if path=="/api/leave" and method=="POST": self.send_json(201,{"id":SERVICE.create_leave(data,actor)}); return
        m=re.fullmatch(r"/api/leave/(\d+)",path)
        if m and method=="GET":
            row=SERVICE.store.conn.execute("SELECT l.*,e.employee_no,e.first_name,e.last_name FROM leave_records l JOIN employees e ON e.id=l.employee_id WHERE l.id=?",(int(m.group(1)),)).fetchone()
            if not row: raise KeyError("Leave application not found.")
            self.send_json(200,dict(row)); return
        if m and method=="PUT":
            rid=int(m.group(1)); eid=int(data.get("employee_id") or 0); d1=clean(data.get("date_from")); d2=clean(data.get("date_to")); days=float(data.get("days") or 0); status=clean(data.get("status") or "Pending")
            if not SERVICE.store.employee(eid): raise ValueError("Select a valid employee.")
            date.fromisoformat(d1); date.fromisoformat(d2)
            if d2<d1 or days<=0: raise ValueError("Enter a valid leave date range and positive working days.")
            if status not in ("Pending","Approved","Declined","Cancelled"): raise ValueError("Invalid leave status.")
            old=SERVICE.store.conn.execute("SELECT id FROM leave_records WHERE id=?",(rid,)).fetchone()
            if not old: raise KeyError("Leave application not found.")
            stamp=iso_now(); SERVICE.store.conn.execute("UPDATE leave_records SET employee_id=?,leave_type=?,date_from=?,date_to=?,days=?,reason=?,status=?,notes=?,updated_at=? WHERE id=?",(eid,clean(data.get("leave_type")),d1,d2,days,clean(data.get("reason")),status,clean(data.get("notes")),stamp,rid)); SERVICE.store.log(actor,"Updated leave application","leave",rid,f"{status}; {d1} to {d2}"); SERVICE.store.conn.commit(); self.send_json(200,{"id":rid}); return
        m=re.fullmatch(r"/api/leave/(\d+)/decision",path)
        if m and method=="POST":
            decision=clean(data.get("decision"))
            if decision not in ("Approved","Declined"): raise ValueError("Decision must be Approved or Declined.")
            rid=int(m.group(1)); row=SERVICE.store.conn.execute("SELECT status FROM leave_records WHERE id=?",(rid,)).fetchone()
            if not row: raise KeyError("Leave application not found.")
            if row["status"]!="Pending": raise ValueError("This application is no longer pending.")
            stamp=iso_now(); SERVICE.store.conn.execute("UPDATE leave_records SET status=?,decision_by=?,decision_at=?,updated_at=? WHERE id=?",(decision,actor,stamp,stamp,rid)); SERVICE.store.log(actor,f"{decision} leave application","leave",rid); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
        if path=="/api/leave/balances" and method=="GET":
            self.send_json(200,{"items":SERVICE.query("SELECT b.*,e.employee_no,e.first_name,e.last_name,(b.opening_days+b.accrued_days-COALESCE((SELECT SUM(l.days) FROM leave_records l WHERE l.employee_id=b.employee_id AND l.leave_type=b.leave_type AND l.status='Approved'),0)) AS available_days FROM leave_balances b JOIN employees e ON e.id=b.employee_id ORDER BY e.last_name,e.first_name")}); return
        if path=="/api/leave/balances" and method=="POST":
            eid=int(data.get("employee_id") or 0); typ=clean(data.get("leave_type")); opening=float(data.get("opening_days") or 0); accrued=float(data.get("accrued_days") or 0)
            if not SERVICE.store.employee(eid) or not typ: raise ValueError("Choose an employee and leave type.")
            SERVICE.store.conn.execute("INSERT INTO leave_balances(employee_id,leave_type,opening_days,accrued_days,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(employee_id,leave_type) DO UPDATE SET opening_days=excluded.opening_days,accrued_days=excluded.accrued_days,updated_at=excluded.updated_at",(eid,typ,opening,accrued,iso_now())); SERVICE.store.log(actor,"Updated leave balance","leave_balance",eid,f"{typ}: opening {opening}, accrued {accrued}"); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return

        m=re.fullmatch(r"/api/attendance/(\d+)",path)
        if m and method=="GET":
            row=SERVICE.store.conn.execute("SELECT d.*,e.employee_no,e.first_name,e.last_name FROM attendance_daily d JOIN employees e ON e.id=d.employee_id WHERE d.id=?",(int(m.group(1)),)).fetchone()
            if not row: raise KeyError("Attendance record not found.")
            self.send_json(200,dict(row)); return
        if path=="/api/files/open" and method=="POST":
            target=Path(clean(data.get("path"))).resolve()
            allowed=[legacy.DOC_DIR.resolve(),legacy.PHOTO_DIR.resolve()]
            if not any(target==base or base in target.parents for base in allowed): raise PermissionError("This file is outside the employee document folders.")
            if not target.is_file(): raise KeyError("The saved attachment could not be found.")
            if os.name=="nt": os.startfile(str(target))
            else: webbrowser.open(target.as_uri())
            self.send_json(200,{"ok":True}); return

        if path=="/api/attendance/settings" and method=="GET":
            self.send_json(200,{k:SERVICE.store.attendance_setting(k,"") for k in ATTENDANCE_KEYS}); return
        if path=="/api/attendance/settings" and method=="PUT":
            values={k:clean(v) for k,v in data.items() if k in ATTENDANCE_KEYS}
            for key in ("shift_start","shift_end"):
                if key in values: datetime.strptime(values[key],"%H:%M")
            for key in ("grace_minutes","lunch_minutes"):
                if key in values and int(values[key])<0: raise ValueError("Attendance minutes cannot be negative.")
            for k,v in values.items(): SERVICE.store.set_attendance_setting(k,v)
            SERVICE.store.rebuild_attendance(actor)
            SERVICE.store.log(actor,"Updated attendance settings","attendance_settings", "", "Shift and grace settings updated")
            self.send_json(200,{"ok":True}); return
        if path=="/api/attendance/import" and method=="POST":
            uploaded=SERVICE.save_upload({"filename":data.get("filename"),"data":data.get("data")},"docs")
            source_path=Path(uploaded["file_path"]); suffix=source_path.suffix.lower()
            if suffix==".xlsx": rows=legacy.App._read_km30_xlsx(None,source_path)
            elif suffix==".csv":
                import csv
                with source_path.open("r",encoding="utf-8-sig",newline="") as f: rows=list(csv.reader(f))
            else: raise ValueError("Select a KM30 .xlsx or .csv export.")
            if not rows or len(rows)<2: raise ValueError("The selected file does not contain an attendance table.")
            header_index=0
            for i,row in enumerate(rows[:15]):
                joined=" ".join(str(x).lower() for x in row)
                if any(k in joined for k in ("user","employee","date","time","punch","attendance")):
                    header_index=i; break
            headers=rows[header_index]; data_rows=rows[header_index+1:]
            id_col,dt_col,date_col,time_col,type_col,name_col=legacy.App._km30_find_columns(None,headers)
            if id_col is None or (dt_col is None and (date_col is None or time_col is None)):
                raise ValueError("I could not identify the KM30 User ID and date/time columns.")
            employee_rows=SERVICE.store.employees()
            by_bio={str(r["biometric_id"]).strip().casefold():r for r in employee_rows if r["biometric_id"]}
            by_no={str(r["employee_no"]).strip().casefold():r for r in employee_rows}
            imported=duplicates=unmatched=invalid=0; source=source_path.name
            for row in data_rows:
                if not row or id_col>=len(row): continue
                bid=str(row[id_col]).strip()
                if not bid or bid.lower() in {"userid","employeeid","id"}: continue
                if dt_col is not None and dt_col<len(row): dt=legacy.App._parse_km30_datetime(None,row[dt_col])
                else:
                    d=str(row[date_col]).strip() if date_col is not None and date_col<len(row) else ""
                    t=str(row[time_col]).strip() if time_col is not None and time_col<len(row) else ""
                    dt=legacy.App._parse_km30_datetime(None,f"{d} {t}".strip())
                if not dt: invalid+=1; continue
                emp=by_bio.get(bid.casefold()) or by_no.get(bid.casefold()); eid=emp["id"] if emp else None
                ptype=str(row[type_col]).strip() if type_col is not None and type_col<len(row) else ""
                raw=" | ".join(str(x) for x in row)
                _,ok=SERVICE.store.save_attendance_punch(bid,dt.strftime("%Y-%m-%d %H:%M:%S"),eid,ptype,source,raw)
                if ok: imported+=1
                else: duplicates+=1
                if emp is None: unmatched+=1
            SERVICE.store.conn.commit(); SERVICE.store.rebuild_attendance(actor)
            self.send_json(200,{"imported":imported,"duplicates":duplicates,"unmatched":unmatched,"invalid":invalid}); return

        if path=="/api/attendance/manual" and method=="POST":
            eid=int(data.get("employee_id") or 0); work_date=clean(data.get("work_date")); hours=float(data.get("hours") or 0); reason=clean(data.get("reason")); first=clean(data.get("first_in")); last=clean(data.get("last_out"))
            if not SERVICE.store.employee(eid): raise ValueError("Select a valid employee.")
            date.fromisoformat(work_date)
            if hours<0 or hours>24 or not reason: raise ValueError("Hours must be 0–24 and an authorisation reason is required.")
            for value in (first,last):
                if value: datetime.strptime(value,"%H:%M")
            stamp=iso_now(); first_dt=f"{work_date} {first}:00" if first else ""; last_dt=f"{work_date} {last}:00" if last else ""
            SERVICE.store.conn.execute("""INSERT INTO attendance_daily(employee_id,work_date,first_in,last_out,total_hours,late_minutes,early_minutes,overtime_minutes,status,notes,adjusted_by,adjusted_at,source) VALUES(?,?,?,?,?,0,0,0,'Manual hours',?,?,?,'Manual') ON CONFLICT(employee_id,work_date) DO UPDATE SET first_in=excluded.first_in,last_out=excluded.last_out,total_hours=excluded.total_hours,late_minutes=0,early_minutes=0,overtime_minutes=0,status='Manual hours',notes=excluded.notes,adjusted_by=excluded.adjusted_by,adjusted_at=excluded.adjusted_at,source='Manual'""",(eid,work_date,first_dt,last_dt,round(hours,2),reason,actor,stamp)); SERVICE.store.conn.commit(); row=SERVICE.store.conn.execute("SELECT id FROM attendance_daily WHERE employee_id=? AND work_date=?",(eid,work_date)).fetchone(); SERVICE.store.log(actor,"Added manual attendance hours","attendance",row["id"],f"{hours:.2f} hours; {reason}"); self.send_json(201,{"id":row["id"]}); return
        if path=="/api/attendance/rebuild" and method=="POST": SERVICE.store.rebuild_attendance(actor); self.send_json(200,{"ok":True}); return

        m=re.fullmatch(r"/api/payroll/(\d+)",path)
        if m and method=="GET":
            row=SERVICE.store.conn.execute("SELECT * FROM payroll_records WHERE id=?",(int(m.group(1)),)).fetchone()
            if not row: raise KeyError("Payroll record not found.")
            self.send_json(200,dict(row)); return
        if m and method=="PUT": self.send_json(200,SERVICE.update_payroll(int(m.group(1)),data,actor)); return
        if path=="/api/payroll/calculate" and method=="POST": self.send_json(200,SERVICE.calculate_payroll(data)); return
        if path=="/api/payroll" and method=="POST": self.send_json(201,SERVICE.create_payroll(data,actor)); return
        m=re.fullmatch(r"/api/payroll/(\d+)/payslip",path)
        if m and method=="GET":
            raw,number=SERVICE.payslip_pdf(int(m.group(1)))
            disposition = "attachment" if q.get("download", [""])[0] == "1" else "inline"
            self.send_response(200); self.send_header("Content-Type","application/pdf"); self.send_header("Content-Disposition",f'{disposition}; filename="{number}.pdf"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
        # Payslip delivery is in-house via VOIC3 (/api/communications/messages). External messaging routes removed.
        if path=="/api/payroll/settings" and method=="GET":
            self.send_json(200,{k:SERVICE.store.attendance_setting(k,"") for k in SETTINGS_KEYS}); return
        if path=="/api/payroll/settings" and method=="PUT":
            for k,v in data.items():
                if k in SETTINGS_KEYS: SERVICE.store.set_attendance_setting(k,clean(v))
            SERVICE.store.log(actor,"Updated payroll settings","payroll_settings","","Rates and paid-shift settings updated"); self.send_json(200,{"ok":True}); return

        if path=="/api/users" and method=="GET":
            self.send_json(200,{"items":[dict(r) for r in SERVICE.store.list_admins()]}); return
        if path=="/api/users" and method=="POST":
            if len(clean(data.get("password")))<4: raise ValueError("Use a password with at least 4 characters.")
            role=clean(data.get("role") or "Administrator")
            if role not in ("Administrator","Manager","Staff","Caregiver"): raise ValueError("Choose Administrator, Manager, Staff or Caregiver.")
            SERVICE.store.create_admin(clean(data.get("full_name")),clean(data.get("username")),clean(data.get("password")),role)
            if role != "Administrator":
                admin_row=SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE",(clean(data.get("username")),)).fetchone()
                if admin_row:
                    SERVICE.store.conn.execute("INSERT INTO admin_permission_overrides(admin_id,grants_json,scope_type,scope_values_json,updated_by,updated_at) VALUES(?, '{}', 'employees', '[]', ?, ?) ON CONFLICT(admin_id) DO NOTHING",(int(admin_row["id"]),actor,iso_now()))
                    SERVICE.store.conn.commit()
            SERVICE.store.log(actor,"Created user account","admin",clean(data.get("username")),f"Role: {role}"); self.send_json(201,{"ok":True,"role":role}); return
        m=re.fullmatch(r"/api/users/(\d+)/password",path)
        if m and method=="POST":
            pw=clean(data.get("password"))
            if len(pw)<4: raise ValueError("Use a password with at least 4 characters.")
            SERVICE.store.reset_admin_password(int(m.group(1)),pw); SERVICE.store.log(actor,"Reset administrator password","admin",m.group(1)); self.send_json(200,{"ok":True}); return
        m=re.fullmatch(r"/api/users/(\d+)/active",path)
        if m and method=="POST":
            active=bool(data.get("active")); uid=int(m.group(1))
            SERVICE.store.set_admin_active(uid,active)
            # Revoke any live desktop sessions for a disabled account.
            if not active:
                row=SERVICE.store.conn.execute("SELECT username FROM admins WHERE id=?",(uid,)).fetchone()
                if row and row["username"]:
                    for token,value in list(SERVICE.sessions.items()):
                        if value == clean(row["username"]):
                            SERVICE.sessions.pop(token,None); SERVICE.session_expiries.pop(token,None)
            SERVICE.store.log(actor,"Changed administrator access","admin",m.group(1),"Active" if active else "Disabled"); self.send_json(200,{"ok":True}); return
        m=re.fullmatch(r"/api/users/(\d+)/delete",path)
        if m and method == "POST":
            # Removing an account permanently. The audit trail keeps every action
            # that account ever took, so nothing about the business is lost.
            uid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT username,full_name,role FROM admins WHERE id=?",(uid,)).fetchone()
            if not row: raise KeyError("User account not found.")
            if clean(row["username"]).lower() == clean(actor).lower():
                raise ValueError("You cannot delete the account you are signed in with.")
            if clean(row["role"] or "Administrator") == "Administrator":
                remaining=SERVICE.store.conn.execute("SELECT COUNT(*) AS n FROM admins WHERE active=1 AND COALESCE(role,'Administrator')='Administrator' AND id<>?",(uid,)).fetchone()
                if remaining and int(remaining["n"]) < 1:
                    raise ValueError("This is the last active Administrator. Create another administrator first, then delete this one.")
            for token,value in list(SERVICE.sessions.items()):
                if value == clean(row["username"]):
                    SERVICE.sessions.pop(token,None); SERVICE.session_expiries.pop(token,None)
            SERVICE.store.conn.execute("DELETE FROM admin_permission_overrides WHERE admin_id=?",(uid,))
            SERVICE.store.conn.execute("DELETE FROM admins WHERE id=?",(uid,))
            SERVICE.store.log(actor,"Deleted user account","admin",uid,f"{row['full_name']} ({row['username']}) - {row['role'] or 'Administrator'}")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
        m=re.fullmatch(r"/api/users/(\d+)/permissions",path)
        if m and method=="GET":
            uid=int(m.group(1)); admin_row=SERVICE.store.conn.execute("SELECT id,full_name,username,role,active,created_at FROM admins WHERE id=?",(uid,)).fetchone()
            if not admin_row: raise KeyError("User account not found.")
            override=SERVICE.store.conn.execute("SELECT grants_json,scope_type,scope_values_json FROM admin_permission_overrides WHERE admin_id=?",(uid,)).fetchone()
            try: grants=json.loads(override["grants_json"]) if override else {}
            except (ValueError,TypeError): grants={}
            try: scope_values=json.loads(override["scope_values_json"]) if override else []
            except (ValueError,TypeError): scope_values=[]
            self.send_json(200,{"user":dict(admin_row),"catalog":PermissionMaskingEngine.PERMISSION_CATALOG,"grants":grants if isinstance(grants,dict) else {},"scope_type":(override["scope_type"] if override else "employees") or "employees","scope_values":[str(v) for v in scope_values] if isinstance(scope_values,list) else [],"has_explicit_policy":override is not None}); return
        if m and method=="PUT":
            uid=int(m.group(1)); admin_row=SERVICE.store.conn.execute("SELECT id,role FROM admins WHERE id=?",(uid,)).fetchone()
            if not admin_row: raise KeyError("User account not found.")
            if clean(admin_row["role"])=="Administrator": raise PermissionError("Administrators retain full access; permission overrides do not apply.")
            grants=data.get("grants")
            if not isinstance(grants,dict): raise ValueError("Permissions must be an object of module to actions.")
            catalog=PermissionMaskingEngine.PERMISSION_CATALOG
            clean_grants={}
            for module,actions in grants.items():
                if module not in catalog: raise ValueError(f"Unknown permission module: {module}")
                if not isinstance(actions,list): raise ValueError(f"Actions for {module} must be a list.")
                valid=[a for a in actions if a in catalog[module]]
                if len(valid)!=len(actions): raise ValueError(f"Unknown action for {module}.")
                clean_grants[module]=valid
            scope_type=clean(data.get("scope_type")) or "employees"
            if scope_type not in ("all","departments","employees"): raise ValueError("Scope type must be all, departments or employees.")
            raw_scope=data.get("scope_values")
            if raw_scope is None: raw_scope=[]
            if not isinstance(raw_scope,list): raise ValueError("Scope values must be a list.")
            scope_values=[str(v).strip() for v in raw_scope if str(v).strip()][:200]
            stamp=iso_now()
            SERVICE.store.conn.execute("INSERT INTO admin_permission_overrides(admin_id,grants_json,scope_type,scope_values_json,updated_by,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(admin_id) DO UPDATE SET grants_json=excluded.grants_json,scope_type=excluded.scope_type,scope_values_json=excluded.scope_values_json,updated_by=excluded.updated_by,updated_at=excluded.updated_at",(uid,json.dumps(clean_grants),scope_type,json.dumps(scope_values),actor,stamp))
            SERVICE.store.log(actor,"Updated user permission policy","admin",uid,f"Scope {scope_type}: {len(scope_values)} value(s)")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"scope_type":scope_type,"scope_values":scope_values}); return

        if path=="/api/audit" and method=="GET":
            self.send_json(200,{"items":SERVICE.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 300")}); return
        if path=="/api/audit/verify" and method=="GET":
            self.send_json(200,SERVICE.store.verify_audit_chain()); return
        if path=="/api/audit/export" and method=="GET":
            verification=SERVICE.store.verify_audit_chain()
            items=SERVICE.query("SELECT * FROM audit_log ORDER BY id")
            self.send_json(200,{"verification":verification,"items":items,"exported_at":iso_now()}); return
        if path=="/api/backup" and method=="GET":
            backups = []
            if legacy.BACKUP_DIR.exists():
                for p in sorted(legacy.BACKUP_DIR.glob("*.zip"), key=lambda f: f.stat().st_mtime, reverse=True):
                    try:
                        stat = p.stat()
                        backups.append({
                            "name": p.name,
                            "size": stat.st_size,
                            "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
                        })
                    except OSError:
                        pass
            self.send_json(200, {"items": backups}); return
        if path=="/api/backup/download" and method=="GET":
            name=Path(clean(q.get("name",[""])[0])).name
            target=(legacy.BACKUP_DIR/name).resolve()
            try: target.relative_to(legacy.BACKUP_DIR.resolve())
            except ValueError: raise PermissionError("Invalid backup path.")
            if not target.is_file(): raise KeyError("Backup file not found.")
            self.send_response(200); self.send_header("Content-Type","application/zip"); self.send_header("Content-Length",str(target.stat().st_size)); self.send_header("Content-Disposition",f'attachment; filename="{name}"'); self.send_header("Cache-Control","no-store"); self.end_headers()
            with target.open("rb") as fh: self.wfile.write(fh.read())
            return
        if path=="/api/backup" and method=="POST":
            target=SERVICE.store.backup_bundle(); SERVICE.store.log(actor,"Created full backup","backup",target.name); self.send_json(200,{"path":str(target),"name":target.name}); return
        if path=="/api/restore" and method=="POST":
            file=SERVICE.save_upload({"filename":data.get("filename"),"data":data.get("data")},"docs"); safety=SERVICE.store.restore_bundle(file["file_path"]); SERVICE.store.log(actor,"Restored full backup","backup",Path(file["file_path"]).name,f"Safety copy: {safety}"); self.send_json(200,{"ok":True,"safety_backup":str(safety)}); return
        if path=="/api/communications/config" and method=="GET":
            self.send_json(200,SERVICE.comms.public_config()); return
        if path=="/api/communications/config" and method=="PUT":
            self.send_json(200,{"ok":True,"config":SERVICE.comms.save_config(data)}); return
        if path=="/api/communications/status" and method=="GET":
            self.send_json(200,SERVICE.comms.status()); return
        if path.startswith("/api/communications/email/"):
            raise PermissionError("Email functionality has been removed from Beyond Registration.")
        # External messaging endpoints removed - VOIC3 is in-house only.
        if path=="/api/communications/disconnect" and method=="POST":
            self.send_json(200,SERVICE.comms.disconnect(clean(data.get("provider")))); return
        if path=="/api/communications/messages" and method=="GET":
            self.send_json(200,{"items":SERVICE.hub_messages()}); return
        if path=="/api/communications/messages" and method=="POST":
            self.send_json(201,SERVICE.hub_send(data,actor)); return
        if path=="/api/communications/recipients" and method=="GET":
            self.send_json(200,{"items":SERVICE.hub_recipients()}); return
        m=re.fullmatch(r"/api/communications/messages/(\d+)/attachment",path)
        if m and method=="GET":
            mid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT employee_id,sender,recipient_label FROM hub_messages WHERE id=?",(mid,)).fetchone()
            if not row: raise PermissionError("This attachment is not available.")
            admin = SERVICE.role_for(actor)=="Administrator"
            allowed = admin or row["sender"]==actor or (row["employee_id"] is None)
            if not allowed: raise PermissionError("This attachment is not available to your account.")
            raw,name,mime=SERVICE.hub_attachment(mid)
            self.send_response(200); self.send_header("Content-Type",mime); self.send_header("Content-Disposition",f'attachment; filename="{name}"'); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
        if path=="/api/communications/messages/read" and method=="POST":
            SERVICE.store.conn.execute("UPDATE hub_messages SET read_at=? WHERE read_at IS NULL",(iso_now(),)); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return

        # ---- Central AI coordinator + specialist agents ----
        if path=="/api/ai/agents" and method=="GET":
            self.send_json(200,{"items":SERVICE.coordinator.agents()}); return
        if path=="/api/ai/chat" and method=="POST":
            self.send_json(200,SERVICE.coordinator.chat(actor,clean(data.get("prompt")),data.get("history"))); return
        if path in ("/api/ai/health","/api/ai/tasks","/api/ai/approvals","/api/ai/actions") and method=="GET":
            if SERVICE.role_for(actor)!="Administrator": raise PermissionError("AI administration is restricted to Administrators.")
            if path=="/api/ai/health": self.send_json(200,SERVICE.coordinator.health()); return
            if path=="/api/ai/tasks": self.send_json(200,{"items":SERVICE.coordinator.tasks()}); return
            if path=="/api/ai/approvals": self.send_json(200,{"items":SERVICE.coordinator.approvals()}); return
            self.send_json(200,{"items":SERVICE.coordinator.action_history()}); return
        m=re.fullmatch(r"/api/ai/approvals/(\d+)/decision",path)
        if m and method=="POST":
            if SERVICE.role_for(actor)!="Administrator": raise PermissionError("Only Administrators can decide AI action approvals.")
            self.send_json(200,SERVICE.coordinator.decide(int(m.group(1)),bool(data.get("approve")),actor)); return
        if path=="/api/ai/memory" and method=="GET":
            self.send_json(200,{"items":SERVICE.coordinator.memory(actor)}); return
        if path=="/api/ai/memory" and method=="POST":
            self.send_json(201,SERVICE.coordinator.remember(actor,clean(data.get("kind")),clean(data.get("content")))); return
        m=re.fullmatch(r"/api/ai/memory/(\d+)",path)
        if m and method=="DELETE":
            self.send_json(200,SERVICE.coordinator.forget(int(m.group(1)),actor)); return

        # ---- Beyond Security Suite: local defensive posture ----
        if path=="/api/security/status" and method=="GET":
            if permissions.user_role!="Administrator": raise PermissionError("Security status is restricted to Administrators.")
            self.send_json(200,security_suite.status()); return
        if path=="/api/security/scan" and method=="POST":
            if permissions.user_role!="Administrator": raise PermissionError("Security scans are restricted to Administrators.")
            self.send_json(200,security_suite.quick_scan()); return
        if path=="/api/security/malware-scan" and method=="POST":
            if permissions.user_role!="Administrator": raise PermissionError("Malware scans are restricted to Administrators.")
            if not security_suite.clamav_ready(): raise ValueError("ClamAV or its virus definitions are not installed yet.")
            threading.Thread(target=lambda: security_suite.scan_data_home(), daemon=True, name="clamav-manual").start()
            self.send_json(202,{"started":True,"note":"Data-folder scan running in background; check /api/security/status for results."}); return

        if path=="/api/config" and method=="GET": self.send_json(200,{"vision_server_url":SERVICE.config.get("vision_server_url","")}); return
        if path=="/api/config" and method=="PUT":
            url=clean(data.get("vision_server_url"))
            # An https address is a published service; a local http address is this
            # machine's own Ollama. Anything else is refused.
            if url and not (url.startswith("https://") or url.startswith("http://127.0.0.1") or url.startswith("http://localhost")):
                raise ValueError("Use an HTTPS address for a published Vision service, or a local http://127.0.0.1 address for Ollama on this PC.")
            SERVICE.config["vision_server_url"]=url.rstrip("/")
            if "vision_model" in data:
                SERVICE.config["vision_model"]=clean(data.get("vision_model"))
            if "ollama_host" in data:
                host=clean(data.get("ollama_host"))
                if host and not (host.startswith("http://127.0.0.1") or host.startswith("http://localhost")):
                    raise ValueError("The local AI host must be on this PC (http://127.0.0.1…).")
                SERVICE.config["ollama_host"]=host.rstrip("/")
            SERVICE.config_path.write_text(json.dumps(SERVICE.config,indent=2),encoding="utf-8")
            # Resolve again so the reply shows what will really be used: a saved
            # name that is not installed falls back to the best fitting model.
            state = cortex_local.resolve(SERVICE._local_model_host(), SERVICE._local_model_saved())
            self.send_json(200, {"ok": True, "model": state["model"], "host": state["host"],
                                 "requested": state["requested"], "reason": state["reason"],
                                 "available": state["available"], "fits": state["fits"]}); return
        if path=="/api/vision/history" and method=="GET":
            row=SERVICE.store.conn.execute("SELECT messages_json,updated_at FROM vision_conversations WHERE actor=? COLLATE NOCASE",(actor,)).fetchone()
            try: messages=json.loads(row["messages_json"]) if row else []
            except Exception: messages=[]
            self.send_json(200,{"messages":messages if isinstance(messages,list) else [],"updated_at":row["updated_at"] if row else ""}); return
        if path=="/api/vision/history" and method=="PUT":
            messages=data.get("messages")
            if not isinstance(messages,list): raise ValueError("Vision history must be a list of messages.")
            safe=[]
            for item in messages[-500:]:
                if not isinstance(item,dict) or item.get("role") not in ("user","assistant"): continue
                content=item.get("content")
                if not isinstance(content,str): continue
                content=content[:30000]
                if content.strip(): safe.append({"role":item["role"],"content":content})
            stamp=datetime.now().astimezone().isoformat(timespec="seconds")
            SERVICE.store.conn.execute("INSERT INTO vision_conversations(actor,messages_json,updated_at) VALUES(?,?,?) ON CONFLICT(actor) DO UPDATE SET messages_json=excluded.messages_json,updated_at=excluded.updated_at",(actor,json.dumps(safe,ensure_ascii=False),stamp))
            SERVICE.store.conn.commit()
            self.send_json(200,{"ok":True,"count":len(safe),"updated_at":stamp}); return
        if path=="/api/vision/history" and method=="DELETE":
            SERVICE.store.conn.execute("DELETE FROM vision_conversations WHERE actor=? COLLATE NOCASE",(actor,)); SERVICE.store.conn.commit()
            self.send_json(200,{"ok":True}); return
        if path=="/api/vision/chat" and method=="POST": self.send_json(200,SERVICE.api_vision(clean(data.get("prompt")),actor,data.get("messages"),data.get("attachments"))); return
        if path=="/api/vision/status" and method=="GET":
            # The CORTEX page and Settings read this: which local model is chosen,
            # which models are installed, and whether the assistant can answer.
            state = cortex_local.doctor(SERVICE._local_model_host(), SERVICE._local_model_saved())
            names = [m["name"] for m in state["models"]]
            self.send_json(200, {
                "url": SERVICE.config.get("vision_server_url", ""),
                "host": state["host"],
                # The one model every CORTEX path uses, and why it was chosen.
                "model": state["model"],
                "models": names,
                "available": state["available"],
                "selected_available": bool(state["model"] and state["model"] in names),
                # New, additive: the RAM picture behind the choice.
                "running": state["running"],
                "ram": state["ram"],
                "fits": state["fits"],
                "reason": state["reason"],
                "advice": state["advice"],
                "keep_alive": state["keep_alive"],
                "num_ctx": state["num_ctx"],
                "installed": state["models"],
            }); return

        # --- System health, staged scripts, spelling and patient care ---------
        if path in ("/api/health","/api/system/health") and method == "GET":
            try:
                # Anything already committed but still in RAM goes to disk before
                # a health check reports on it.
                legacy.flush_all()
            except Exception:
                pass
            try:
                integrity = SERVICE.store.conn.execute("PRAGMA integrity_check").fetchone()[0]
            except Exception:
                integrity = "error"
            try:
                usage = shutil.disk_usage(legacy.DATA_HOME)
                storage = {"free_bytes": usage.free, "total_bytes": usage.total}
            except OSError:
                storage = {"free_bytes": 0, "total_bytes": 0}
            self.send_json(200,{"database":{"integrity":integrity},"storage":storage,"weather":{"status":"not_configured"},"checked_at":iso_now()}); return

        if path == "/api/upgrades" and method == "GET":
            if SERVICE.upgrader is None: raise RuntimeError("Script staging is unavailable.")
            self.send_json(200,{"items":SERVICE.upgrader.list_pending(),"execution_enabled":False}); return
        if path == "/api/upgrades" and method == "POST":
            if SERVICE.upgrader is None: raise RuntimeError("Script staging is unavailable.")
            result = SERVICE.upgrader.apply_code_upgrade(actor, clean(data.get("filename")), str(data.get("content") or ""))
            if result.get("status") != "staged":
                raise ValueError(result.get("message") or "The script could not be staged.")
            self.send_json(200,{"status":"staged","file":result.get("file"),"sha256":result.get("sha256"),"execution_enabled":False,"message":result.get("message","")}); return
        m=re.fullmatch(r"/api/upgrades/([A-Za-z0-9_.-]+)",path)
        if m and method == "GET":
            if SERVICE.upgrader is None: raise RuntimeError("Script staging is unavailable.")
            reviewed=SERVICE.upgrader.read_pending(m.group(1))
            self.send_json(200,{**reviewed,"execution_enabled":False}); return
        if m and method == "DELETE":
            if SERVICE.upgrader is None: raise RuntimeError("Script staging is unavailable.")
            if data.get("confirm") is not True: raise ValueError("Set confirm=true to discard a staged script.")
            SERVICE.upgrader.delete_pending(m.group(1))
            self.send_json(200,{"ok":True,"deleted":m.group(1),"execution_enabled":False}); return

        if path == "/api/spelling" and method == "GET":
            self.send_json(200, legacy.spelling_help(q.get("word",[""])[0])); return
        if path == "/api/spelling" and method == "POST":
            self.send_json(200,{"word":legacy.add_custom_spelling(data.get("word")),"correct":True}); return

        if path == "/api/contract-documents" and method == "GET":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can view contracts."}); return
            self.send_json(200,{"items":SERVICE.query("SELECT c.id,c.employee_id,c.title,c.file_name,c.status,c.decline_reason,c.signed_name,c.decided_at,c.created_at,e.employee_no,e.first_name,e.last_name FROM contract_documents c JOIN employees e ON e.id=c.employee_id ORDER BY c.id DESC LIMIT 200")}); return
        if path == "/api/contract-documents" and method == "POST":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can send contracts."}); return
            eid=int(data.get("employee_id") or 0); title=clean(data.get("title")); encoded=data.get("data"); filename=clean(data.get("filename")) or "contract.pdf"
            if not SERVICE.store.employee(eid): raise ValueError("Choose a valid employee.")
            if not title or not isinstance(encoded,str): raise ValueError("Contract title and PDF file are required.")
            stamp=iso_now()
            import base64 as _b64
            try: blob=_b64.b64decode(encoded.split(",",1)[-1])
            except Exception: blob=b""
            if not blob: raise ValueError("Contract file could not be read.")
            SERVICE.scan_or_reject(blob, Path(filename).name, actor)
            cur=SERVICE.store.conn.execute("INSERT INTO contract_documents(employee_id,title,file_name,mime_type,file_data,status,sent_by,created_at,updated_at) VALUES(?,?,?,?,?,'Pending',?,?,?)",(eid,title,Path(filename).name,"application/pdf",blob,actor,stamp,stamp))
            SERVICE.store.log(actor,"Sent contract for signature","contract",str(cur.lastrowid),f"Employee {eid}: {title}"); SERVICE.store.conn.commit(); self.send_json(201,{"id":int(cur.lastrowid)}); return
        if path == "/api/devices/pairing-codes" and method == "POST":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can create pairing codes."}); return
            dclass=clean(data.get("device_class")) or "company"
            if dclass not in ("company","staff"): raise ValueError("Device class must be company or staff.")
            code=secrets.token_hex(4).upper(); stamp=iso_now()
            SERVICE.store.conn.execute("INSERT INTO mobile_pairing_codes(code,device_class,created_by,created_at) VALUES(?,?,?,?)",(code,dclass,actor,stamp))
            SERVICE.store.conn.commit(); self.send_json(201,{"code":code,"device_class":dclass,"expires_note":"Single use; enter once on the device."}); return
        if path == "/api/devices/status" and method == "GET":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can view device status."}); return
            devices=SERVICE.query("SELECT d.device_key,d.device_class,d.label,d.paired_by,d.paired_at, (SELECT MAX(c.checked_at) FROM device_checkins c WHERE c.device_key=d.device_key) AS last_checkin FROM mobile_devices d ORDER BY d.paired_at DESC")
            for d in devices:
                lc=d.get("last_checkin"); d["checkin_overdue"]=bool(lc is None) if d["device_class"]=="company" else False
            self.send_json(200,{"items":devices}); return
        if path == "/api/payslip-requests" and method == "GET":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can review payslip requests."}); return
            self.send_json(200,{"items":SERVICE.query("SELECT r.id,r.payroll_id,r.employee_id,r.field,r.proposed_value,r.reason,r.status,r.decision_by,r.decision_at,r.created_at,p.pay_period,p.net_pay,e.employee_no,e.first_name,e.last_name FROM payslip_edit_requests r JOIN payroll_records p ON p.id=r.payroll_id JOIN employees e ON e.id=r.employee_id ORDER BY r.id DESC LIMIT 200")}); return
        m=re.fullmatch(r"/api/payslip-requests/(\d+)/decision",path)
        if m and method == "POST":
            if not actor or SERVICE.role_for(actor) != "Administrator": self.send_json(403,{"error":"Only Administrators can review payslip requests."}); return
            rid=int(m.group(1)); decision=clean(data.get("decision"))
            if decision not in ("Approved","Denied"): raise ValueError("Decision must be Approved or Denied.")
            row=SERVICE.store.conn.execute("SELECT id,employee_id,payroll_id,field,status FROM payslip_edit_requests WHERE id=?",(rid,)).fetchone()
            if not row: raise KeyError("Payslip request not found.")
            if clean(row["status"])!="Pending": raise ValueError("This request was already decided.")
            stamp=iso_now(); SERVICE.store.conn.execute("UPDATE payslip_edit_requests SET status=?,decision_by=?,decision_at=?,updated_at=? WHERE id=?",(decision,actor,stamp,stamp,rid))
            SERVICE.store.conn.execute("INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",(actor,"Employee",int(row["employee_id"]),None,"Payslip correction "+decision.lower(),"Your payslip correction request ("+clean(row["field"])+") was "+decision.lower()+". Contact the office for the updated payslip.",stamp))
            SERVICE.store.log(actor,"Payslip request "+decision.lower(),"payslip_request",str(rid),f"Payroll {row['payroll_id']} field {row['field']}"); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"status":decision}); return
        if path == "/api/patients/monitor" and method == "GET":
            _perms, only_ids = SERVICE.patients_for_actor(actor)
            if only_ids is not None:
                marks = ",".join("?" for _ in only_ids) or "NULL"
                rows = SERVICE.query(f"SELECT * FROM patients WHERE status='Active' AND id IN ({marks}) ORDER BY last_name,first_name", [int(i) for i in only_ids])
            else:
                rows = SERVICE.query("SELECT * FROM patients WHERE status='Active' ORDER BY last_name,first_name")
            items = []
            for r in rows:
                d = SERVICE._patient_dict(r)
                d["safety"] = SERVICE.patient_state(int(r["id"]))
                items.append(d)
            alerts = SERVICE.query("SELECT a.*,p.first_name,p.last_name FROM safety_alerts a JOIN patients p ON p.id=a.patient_id WHERE a.status IN ('Open','Escalated') ORDER BY a.id DESC LIMIT 100")
            self.send_json(200, {"items": items, "alerts": alerts}); return
        m=re.fullmatch(r"/api/patients/(\d+)/safety",path)
        if m and method == "GET":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"view")
            state=SERVICE.patient_state(pid)
            pings=SERVICE.query("SELECT * FROM patient_location_pings WHERE patient_id=? ORDER BY id DESC LIMIT 100",(pid,))
            alerts=SERVICE.query("SELECT * FROM safety_alerts WHERE patient_id=? ORDER BY id DESC LIMIT 100",(pid,))
            geofences=SERVICE.query("SELECT * FROM geofences WHERE patient_id=? ORDER BY id",(pid,))
            vitals=SERVICE.query("SELECT * FROM patient_vitals WHERE patient_id=? ORDER BY id DESC LIMIT 30",(pid,))
            esc=SERVICE.query("SELECT e.*,a.alert_type,a.severity FROM emergency_escalations e JOIN safety_alerts a ON a.id=e.alert_id WHERE e.patient_id=? ORDER BY e.id DESC LIMIT 100",(pid,))
            self.send_json(200,{"state":state,"pings":pings,"alerts":alerts,"geofences":geofences,"vitals":vitals,"escalations":esc}); return
        m=re.fullmatch(r"/api/patients/(\d+)/geofences",path)
        if m and method == "POST":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"edit")
            name=clean(data.get("name")) or "Safe zone"
            try: lat=float(data.get("latitude")); lon=float(data.get("longitude")); rad=float(data.get("radius_m") or 100)
            except (TypeError,ValueError): raise ValueError("Valid centre coordinates and radius are required.")
            if not (-90<=lat<=90 and -180<=lon<=180): raise ValueError("Coordinates out of range.")
            if not (10<=rad<=5000): raise ValueError("Radius must be between 10 m and 5 km.")
            cur=SERVICE.store.conn.execute("INSERT INTO geofences(patient_id,name,latitude,longitude,radius_m,active,created_by,created_at) VALUES(?,?,?,?,?,1,?,?)",(pid,name,lat,lon,rad,actor,iso_now()))
            SERVICE.store.log(actor,"Created patient geofence","patient",pid,f"{name} r={rad}m"); SERVICE.store.conn.commit(); self.send_json(201,{"id":int(cur.lastrowid)}); return
        if path == "/api/geofences" and method == "GET":
            _perms, only_ids = SERVICE.patients_for_actor(actor)
            if only_ids is not None:
                marks = ",".join("?" for _ in only_ids) or "NULL"
                rows = SERVICE.query(f"SELECT g.*,p.first_name,p.last_name FROM geofences g JOIN patients p ON p.id=g.patient_id WHERE g.active=1 AND g.patient_id IN ({marks}) ORDER BY g.id",[int(i) for i in only_ids])
            else:
                rows = SERVICE.query("SELECT g.*,p.first_name,p.last_name FROM geofences g JOIN patients p ON p.id=g.patient_id WHERE g.active=1 ORDER BY g.id")
            self.send_json(200,{"items":rows}); return
        m=re.fullmatch(r"/api/geofences/(\d+)",path)
        if m and method == "DELETE":
            gid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT patient_id FROM geofences WHERE id=?",(gid,)).fetchone()
            if not row: raise KeyError("Geofence not found.")
            SERVICE.patient_access_ok(actor,int(row["patient_id"]),"edit")
            SERVICE.store.conn.execute("DELETE FROM geofences WHERE id=?",(gid,))
            SERVICE.store.log(actor,"Deleted patient geofence","patient",int(row["patient_id"]),str(gid)); SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
        if m and method == "POST":
            gid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT patient_id,active FROM geofences WHERE id=?",(gid,)).fetchone()
            if not row: raise KeyError("Geofence not found.")
            SERVICE.patient_access_ok(actor,int(row["patient_id"]),"edit")
            active=1 if data.get("active",True) else 0
            SERVICE.store.conn.execute("UPDATE geofences SET active=? WHERE id=?",(active,gid))
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"active":bool(active)}); return
        m=re.fullmatch(r"/api/safety-alerts/(\d+)/acknowledge",path)
        if m and method == "POST":
            aid=int(m.group(1))
            row=SERVICE.store.conn.execute("SELECT * FROM safety_alerts WHERE id=?",(aid,)).fetchone()
            if not row: raise KeyError("Safety alert not found.")
            SERVICE.patient_access_ok(actor,int(row["patient_id"]),"edit")
            if clean(row["status"]) in ("Acknowledged","Resolved"): raise ValueError("This alert was already actioned.")
            resolution=clean(data.get("resolution"))
            stamp=iso_now()
            newstatus="Resolved" if resolution else "Acknowledged"
            SERVICE.store.conn.execute("UPDATE safety_alerts SET status=?,acknowledged_by=?,acknowledged_at=?,resolved_at=?,updated_at=? WHERE id=?",(newstatus,actor,stamp,stamp if resolution else "",stamp,aid))
            if row["alert_type"]=="emergency" or row["severity"]=="critical":
                SERVICE.store.conn.execute("UPDATE emergency_escalations SET status='Acknowledged',ack_at=? WHERE alert_id=? AND ack_at=''",(stamp,aid))
            SERVICE.store.log(actor,f"{newstatus} safety alert","safety_alert",aid,f"Patient {row['patient_id']} {row['alert_type']}")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True,"status":newstatus}); return
        m=re.fullmatch(r"/api/patients/(\d+)/outing-report",path)
        if m and method == "GET":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"view")
            wid=int(q.get("walk_id",["0"])[0] or 0)
            if wid:
                walk=SERVICE.store.conn.execute("SELECT * FROM patient_walks WHERE id=? AND patient_id=?",(wid,pid)).fetchone()
            else:
                walk=SERVICE.store.conn.execute("SELECT * FROM patient_walks WHERE patient_id=? AND status='Completed' ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
            if not walk: raise KeyError("No outing found for this patient.")
            wid=int(walk["id"])
            pings=SERVICE.query("SELECT * FROM patient_location_pings WHERE walk_id=? OR (patient_id=? AND created_at>=? AND created_at<=COALESCE(?, '9999')) ORDER BY id",(wid,pid,walk["started_at"],walk["ended_at"] or ""))
            events=SERVICE.query("SELECT * FROM patient_walk_events WHERE walk_id=? ORDER BY id",(wid,))
            alerts=SERVICE.query("SELECT * FROM safety_alerts WHERE patient_id=? AND created_at>=? ORDER BY id",(pid,walk["started_at"]))
            # distance
            dist=0.0
            pts=[(float(x["latitude"]),float(x["longitude"])) for x in pings]
            for i in range(1,len(pts)): dist+=SERVICE._haversine_m(*pts[i-1],*pts[i])
            self.send_json(200,{"walk":dict(walk),"pings":pings,"events":events,"alerts":alerts,"distance_m":round(dist,1),"ping_count":len(pings)}); return
        if path == "/api/patients" and method == "GET":
            _perms, only_ids = SERVICE.patients_for_actor(actor)
            if only_ids is not None:
                marks = ",".join("?" for _ in only_ids) or "NULL"
                rows = SERVICE.query(f"SELECT * FROM patients WHERE status='Active' AND id IN ({marks}) ORDER BY last_name,first_name", [int(i) for i in only_ids])
            else:
                rows = SERVICE.query("SELECT * FROM patients WHERE status='Active' ORDER BY last_name,first_name")
            self.send_json(200,{"items":[SERVICE._patient_dict(r) for r in rows]}); return
        if path == "/api/patients" and method == "POST":
            if not SERVICE.permissions_for(actor).allows("patients","create"):
                raise PermissionError("Creating patient records requires the patients create permission.")
            rid = SERVICE.save_patient(data, actor)
            self.send_json(201,{"id":rid}); return
        m=re.fullmatch(r"/api/patients/(\d+)",path)
        if m and method == "GET":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"view")
            self.send_json(200,SERVICE._patient_dict(SERVICE._patient_row(pid),detail=True)); return
        if m and method == "PUT":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"edit")
            rid = SERVICE.save_patient(data, actor, pid)
            self.send_json(200,{"id":rid}); return

        m=re.fullmatch(r"/api/patients/(\d+)/access(?:/(employee|admin)/(\d+))?",path)
        if m and method == "GET":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"view")
            rows=SERVICE.query("""SELECT pa.principal_type,pa.principal_id,pa.active,COALESCE(e.first_name||' '||e.last_name,a.full_name,'Unknown') AS name,COALESCE(e.employee_no,a.username,'') AS reference FROM patient_access pa LEFT JOIN employees e ON pa.principal_type='employee' AND e.id=pa.principal_id LEFT JOIN admins a ON pa.principal_type='admin' AND a.id=pa.principal_id WHERE pa.patient_id=? ORDER BY pa.id""",(pid,))
            items=[{**r,"active":bool(r["active"])} for r in rows]
            self.send_json(200,{"items":items}); return
        if m and method == "POST":
            pid=int(m.group(1)); ptype=m.group(2); prid=int(m.group(3) or 0)
            SERVICE.patient_access_ok(actor,pid,"edit")
            if ptype not in ("employee","admin") or not prid: raise ValueError("Choose a valid caregiver account.")
            if ptype=="employee":
                if not SERVICE.store.employee(prid): raise ValueError("Choose a valid employee account.")
            else:
                if not SERVICE.store.conn.execute("SELECT 1 FROM admins WHERE id=?",(prid,)).fetchone(): raise ValueError("Choose a valid Windows account.")
            SERVICE.store.conn.execute("INSERT INTO patient_access(patient_id,principal_type,principal_id,active,created_by,created_at) VALUES(?,?,?,1,?,?) ON CONFLICT(patient_id,principal_type,principal_id) DO UPDATE SET active=1",(pid,ptype,prid,actor,iso_now()))
            SERVICE.store.log(actor,"Assigned caregiver to patient","patient",pid,f"{ptype}:{prid}")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
        if m and method == "DELETE":
            pid=int(m.group(1)); ptype=m.group(2); prid=int(m.group(3) or 0)
            SERVICE.patient_access_ok(actor,pid,"edit")
            SERVICE.store.conn.execute("UPDATE patient_access SET active=0 WHERE patient_id=? AND principal_type=? AND principal_id=?",(pid,ptype,prid))
            SERVICE.store.log(actor,"Removed caregiver from patient","patient",pid,f"{ptype}:{prid}")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return

        m=re.fullmatch(r"/api/patients/(\d+)/contacts",path)
        if m and method == "POST":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"edit")
            name=clean(data.get("name"))
            if not name: raise ValueError("Contact name is required.")
            priority=int(data.get("priority") or 1)
            if priority not in (1,2,3): raise ValueError("Contact priority must be 1, 2 or 3.")
            employee_id=data.get("employee_id")
            employee_id=int(employee_id) if employee_id else None
            if employee_id and not SERVICE.store.employee(employee_id): raise ValueError("Choose a valid employee account.")
            SERVICE.store.conn.execute("INSERT INTO patient_contacts(patient_id,priority,name,relationship,phone,employee_id,created_at) VALUES(?,?,?,?,?,?,?)",(pid,priority,name,clean(data.get("relationship")),clean(data.get("phone")),employee_id,iso_now()))
            SERVICE.store.log(actor,"Added patient emergency contact","patient",pid,name)
            SERVICE.store.conn.commit(); self.send_json(201,{"ok":True}); return

        m=re.fullmatch(r"/api/patients/(\d+)/documents(?:/(\d+))?",path)
        if m and method == "POST":
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"edit")
            result=SERVICE.patient_document_upload(pid,data,actor); self.send_json(201,result); return
        if m and method == "GET" and m.group(2):
            pid=int(m.group(1)); did=int(m.group(2)); SERVICE.patient_access_ok(actor,pid,"view")
            row=SERVICE.store.conn.execute("SELECT * FROM patient_documents WHERE id=? AND patient_id=?",(did,pid)).fetchone()
            if not row: raise KeyError("Patient document not found.")
            content=bytes(row["content"] or b"")
            if not content: raise KeyError("Patient document content is missing.")
            self.send_response(200); self.send_header("Content-Type",clean(row["mime_type"]) or "application/octet-stream"); self.send_header("Content-Disposition",f'attachment; filename="{Path(clean(row["file_name"]) or "document").name}"'); self.send_header("Content-Length",str(len(content))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(content); return

        m=re.fullmatch(r"/api/patients/(\d+)/walks(?:/(\d+)(?:/(checkin|end|location))?)?",path)
        if m and method == "GET" and not m.group(2):
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"view")
            items=SERVICE.query("SELECT * FROM patient_walks WHERE patient_id=? ORDER BY id DESC LIMIT 50",(pid,))
            active=next((w for w in items if w["status"]=="Active"),None)
            self.send_json(200,{"items":items,"active":active}); return
        if m and method == "POST" and not m.group(2):
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"edit")
            wid=SERVICE.patient_walk_start(pid,data,actor)
            self.send_json(201,{"id":wid,"ok":True}); return
        if m and method == "POST" and m.group(3)=="checkin":
            pid=int(m.group(1)); wid=int(m.group(2)); SERVICE.patient_access_ok(actor,pid,"edit")
            self.send_json(200,SERVICE.patient_walk_checkin(wid,pid,data,actor)); return
        if m and method == "POST" and m.group(3)=="end":
            pid=int(m.group(1)); wid=int(m.group(2)); SERVICE.patient_access_ok(actor,pid,"edit")
            self.send_json(200,SERVICE.patient_walk_end(wid,pid,actor)); return
        if m and method == "POST" and m.group(3)=="location":
            pid=int(m.group(1)); wid=int(m.group(2)); SERVICE.patient_access_ok(actor,pid,"edit")
            self.send_json(200,SERVICE.patient_walk_location(wid,pid,data)); return

        m=re.fullmatch(r"/api/patients/(\d+)/alerts(?:/(\d+)/ack)?",path)
        if m and method == "POST" and m.group(2) is None:
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"edit")
            self.send_json(201,SERVICE.patient_alert_create(pid,data,actor)); return
        if m and method == "POST" and m.group(2):
            pid=int(m.group(1)); aid=int(m.group(2)); SERVICE.patient_access_ok(actor,pid,"edit")
            row=SERVICE.store.conn.execute("SELECT status FROM patient_emergency_alerts WHERE id=? AND patient_id=?",(aid,pid)).fetchone()
            if not row: raise KeyError("Patient alert not found.")
            if row["status"] not in ("Open","Escalated"):
                raise ValueError("This alert has already been acknowledged.")
            stamp=iso_now()
            SERVICE.store.conn.execute("UPDATE patient_emergency_alerts SET status='Acknowledged',acknowledged_at=?,updated_at=? WHERE id=?",(stamp,stamp,aid))
            SERVICE.store.log(actor,"Acknowledged patient emergency alert","patient_alert",aid,f"Patient {pid}")
            SERVICE.store.conn.commit(); self.send_json(200,{"ok":True}); return
        if m and method == "GET" and m.group(2) is None:
            pid=int(m.group(1)); SERVICE.patient_access_ok(actor,pid,"view")
            self.send_json(200,{"items":SERVICE.query("SELECT * FROM patient_emergency_alerts WHERE patient_id=? ORDER BY id DESC LIMIT 100",(pid,))}); return

        self.send_json(404,{"error":"The requested resource was not found."})

    def satellite_sos(self, data):
        secret = os.environ.get("BR_SATELLITE_KEY", "").strip()
        provided = self.headers.get("X-Satellite-Key", "")
        if not secret:
            self.send_json(503, {"error": "Satellite ingress is not configured (BR_SATELLITE_KEY unset)."}); return
        if not secrets.compare_digest(provided, secret):
            self.send_json(403, {"error": "Invalid satellite key."}); return
        raw = b""
        b64 = clean(data.get("payload_b64"))
        hx = clean(data.get("payload_hex"))
        try:
            if b64:
                raw = base64.b64decode(b64)
            elif hx:
                raw = bytes.fromhex(hx)
            else:
                raise ValueError("payload_b64 or payload_hex is required.")
            eid, lat, lon, status, battery = decode_sos12(raw)
        except Exception as exc:
            self.send_json(400, {"error": f"Invalid satellite payload: {exc}"}); return
        cutoff=(datetime.now()-timedelta(minutes=15)).replace(microsecond=0).isoformat(sep=" ")
        dup=SERVICE.store.conn.execute("SELECT id FROM satellite_incidents WHERE raw_hex=? AND created_at>=?",(raw.hex(),cutoff)).fetchone()
        if dup:
            self.send_json(200,{"ok":True,"duplicate":True,"incident_id":int(dup["id"])}); return
        row = SERVICE.store.conn.execute("SELECT id,employee_no,first_name,last_name FROM employees WHERE id=?", (eid,)).fetchone()
        name = f"{row['first_name']} {row['last_name']}" if row else f"employee {eid}"
        eno = row["employee_no"] if row else ""
        stamp = iso_now()
        cur = SERVICE.store.conn.execute(
            "INSERT INTO satellite_incidents(employee_id,employee_no,employee_name,latitude,longitude,status_code,battery_pct,raw_hex,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (eid if row else None, eno, name, lat, lon, status, battery, raw.hex(), stamp))
        iid = int(cur.lastrowid)
        SERVICE.store.log("satellite", "Satellite SOS received", "satellite_incident", iid, f"{name} ({eno}) status={status} at {lat},{lon}")
        # Alert all admin mobile accounts + telegram.
        admins = SERVICE.query("SELECT employee_id FROM mobile_accounts WHERE mobile_profile='admin' AND active=1")
        for a in admins:
            SERVICE.store.conn.execute(
                "INSERT INTO hub_messages(sender,recipient_label,employee_id,department,subject,body,created_at) VALUES(?,?,?,?,?,?,?)",
                ("SATELLITE", "Employee", int(a["employee_id"]), None,
                 f"SATELLITE SOS — {name}",
                 f"Satellite emergency packet received. Status: {SATELLITE_STATUS.get(status, status)}. Position: {lat:.5f}, {lon:.5f}. Battery: {battery}%. Acknowledge and dispatch assistance.", stamp))
        SERVICE.store.conn.commit()
        telegram_notify(f"SATELLITE SOS\n{name} ({eno or 'unknown'})\nStatus: {SATELLITE_STATUS.get(status, status)}\nPosition: {lat:.5f}, {lon:.5f}\nBattery: {battery}%\nhttps://maps.google.com/?q={lat},{lon}")
        self.send_json(201, {"ok": True, "incident_id": iid, "employee": name, "admins_notified": len(admins)})

    # ------------------------------------------------ M4STR0 routes --------
    def mstr_route(self, method, path, data, actor, permissions, q=None):
        q = q or {}
        conn = SERVICE.store.conn
        if not getattr(SERVICE, "_qf3_ready", False):
            quoteflow.ensure_schema(conn); mastr0.ensure_schema(conn); SERVICE._qf3_ready = True
        is_admin = permissions.user_role == "Administrator"
        granted = permissions.has_explicit_policy and "edit" in (permissions.grants.get("quoteflow") or ())
        can_write = is_admin or granted
        can_control = is_admin or (permissions.has_explicit_policy and ("approve" in (permissions.grants.get("quoteflow") or ()) or "autopilot" in (permissions.grants.get("quoteflow") or ())))

        if path == "/api/mstr/status" and method == "GET":
            self.send_json(200, mastr0.status(conn)); return
        if path == "/api/mstr/cycle" and method == "POST":
            if not can_write: raise PermissionError("Running the M4STR0 cycle requires the quoteflow edit permission.")
            result = mastr0.run_cycle(conn)
            SERVICE.store.log(actor, "M4STR0 cycle run", "mstr", 0, str(result))
            self.send_json(200, {"ok": True, **result}); return
        if path == "/api/mstr/mode" and method == "POST":
            if not can_control: raise PermissionError("Changing M4STR0 mode requires Administrator or an autopilot approval grant.")
            new = mastr0.set_mode(conn, actor, data.get("mode"))
            SERVICE.store.log(actor, "M4STR0 mode changed", "mstr", 0, new)
            self.send_json(200, {"ok": True, "mode": new}); return
        if path == "/api/mstr/pause" and method == "POST":
            if not can_control: raise PermissionError("M4STR0 controls require Administrator or an autopilot approval grant.")
            mastr0.set_paused(conn, actor, True)
            self.send_json(200, {"ok": True, "paused": True}); return
        if path == "/api/mstr/resume" and method == "POST":
            if not can_control: raise PermissionError("M4STR0 controls require Administrator or an autopilot approval grant.")
            mastr0.set_paused(conn, actor, False)
            self.send_json(200, {"ok": True, "paused": False}); return
        if path == "/api/mstr/stop" and method == "POST":
            if not can_control: raise PermissionError("M4STR0 controls require Administrator or an autopilot approval grant.")
            mastr0.emergency_stop(conn, actor)
            SERVICE.store.log(actor, "M4STR0 EMERGENCY STOP", "mstr", 0, actor)
            self.send_json(200, {"ok": True, "paused": True, "mode": "assisted"}); return
        if path == "/api/mstr/proposals" and method == "GET":
            self.send_json(200, {"items": mastr0.list_proposals(conn, q.get("status", [None])[0])}); return
        m = re.fullmatch(r"/api/mstr/proposals/(\d+)/(approve|reject|acknowledge)", path)
        if m and method == "POST":
            if not can_control: raise PermissionError("Deciding proposals requires Administrator or an autopilot approval grant.")
            approve = m.group(2) != "reject"
            res = mastr0.decide_proposal(conn, actor, int(m.group(1)), approve, data.get("note") or "")
            SERVICE.store.log(actor, f"M4STR0 proposal {m.group(2)}", "mstr_proposal", int(m.group(1)), str(res))
            self.send_json(200, {"ok": True, **res}); return
        m = re.fullmatch(r"/api/mstr/agents/(\w+)", path)
        if m and method == "POST":
            if not can_control: raise PermissionError("Agent controls require Administrator or an autopilot approval grant.")
            mastr0.set_agent(conn, actor, m.group(1), bool(data.get("enabled", True)))
            self.send_json(200, {"ok": True}); return
        if path == "/api/mstr/settings" and method == "POST":
            if not can_control: raise PermissionError("M4STR0 settings require Administrator or an autopilot approval grant.")
            for k in ("followup_days", "overdue_days", "escalate_days", "provider_verified"):
                if k in data:
                    mastr0._set(conn, k, str(data[k]))
            conn.commit()
            self.send_json(200, {"ok": True}); return
        raise KeyError("Unknown M4STR0 endpoint.")

    # ------------------------------------------------ QUOT3FLOW routes ----
    def qf3_route(self, method, path, data, actor, permissions, q=None):
        q = q or {}
        conn = SERVICE.store.conn
        if not getattr(SERVICE, "_qf3_ready", False):
            quoteflow.ensure_schema(conn); SERVICE._qf3_ready = True
        is_admin = permissions.user_role == "Administrator"
        granted = permissions.has_explicit_policy and "edit" in (permissions.grants.get("quoteflow") or ())
        can_write = is_admin or granted
        banking_granted = permissions.has_explicit_policy and "manage" in (permissions.grants.get("banking") or ())
        can_bank = is_admin or banking_granted
        sensitive = is_admin or (permissions.has_explicit_policy and ("approve" in (permissions.grants.get("quoteflow") or ()) or "reveal" in (permissions.grants.get("banking") or ())))

        def deny_financial():
            if not sensitive:
                raise PermissionError("Financial confirmations, voids and banking changes require Administrator or an explicit approval grant.")

        # ---- banking / providers ----
        if path == "/api/banking/accounts" and method == "GET":
            reveal = sensitive and q.get("reveal", [""])[0] == "1"
            self.send_json(200, {"items": quoteflow.list_bank_accounts(conn, reveal=reveal)}); return
        if path == "/api/banking/accounts" and method == "POST":
            if not can_bank: raise PermissionError("Banking account changes require the banking permission.")
            aid = data.get("id")
            quoteflow.save_bank_account(conn, actor, data, int(aid) if aid else None)
            SERVICE.store.log(actor, "QUOT3FLOW banking account saved", "bank_account", int(aid or 0), clean(data.get("label")))
            self.send_json(200, {"ok": True}); return
        if path == "/api/banking/providers" and method == "GET":
            self.send_json(200, {"items": quoteflow.list_providers(conn)}); return

        # ---- clients ----
        if path == "/api/qf3/clients" and method == "GET":
            self.send_json(200, {"items": quoteflow.list_clients(conn)}); return
        if path == "/api/qf3/clients" and method == "POST":
            if not can_write: raise PermissionError("QUOT3FLOW changes require the quoteflow edit permission.")
            cid = quoteflow.save_client(conn, actor, data, int(data["id"]) if data.get("id") else None)
            SERVICE.store.log(actor, "QUOT3FLOW client saved", "qf3_client", cid, clean(data.get("name")))
            self.send_json(200, {"ok": True, "id": cid}); return

        # ---- quotes ----
        if path == "/api/qf3/quotes" and method == "GET":
            self.send_json(200, {"items": quoteflow.list_quotes(conn, q.get("status", [None])[0])}); return
        m = re.fullmatch(r"/api/qf3/quotes/(\d+)", path)
        if m and method == "GET":
            doc = quoteflow.get_quote(conn, int(m.group(1)))
            if not doc: raise KeyError("Quote not found.")
            self.send_json(200, {"quote": doc}); return
        if path == "/api/qf3/quotes" and method == "POST":
            if not can_write: raise PermissionError("QUOT3FLOW changes require the quoteflow edit permission.")
            q = quoteflow.save_quote(conn, actor, data, int(data["id"]) if data.get("id") else None)
            SERVICE.store.log(actor, "QUOT3FLOW quote saved", "qf3_quote", q["id"], q["quote_no"])
            self.send_json(200, {"ok": True, "quote": q}); return
        m = re.fullmatch(r"/api/qf3/quotes/(\d+)/(send|cancel)", path)
        if m and method == "POST":
            if not can_write: raise PermissionError("QUOT3FLOW changes require the quoteflow edit permission.")
            q = quoteflow.transition_quote(conn, actor, int(m.group(1)), m.group(2))
            SERVICE.store.log(actor, f"QUOT3FLOW quote {m.group(2)}", "qf3_quote", q["id"], q["quote_no"])
            self.send_json(200, {"ok": True, "quote": q}); return

        # ---- invoices ----
        if path == "/api/qf3/invoices" and method == "GET":
            self.send_json(200, {"items": quoteflow.list_invoices(conn)}); return
        if path == "/api/qf3/invoices/from-quote" and method == "POST":
            if not can_write: raise PermissionError("QUOT3FLOW changes require the quoteflow edit permission.")
            inv = quoteflow.create_invoice_from_quote(conn, actor, int(data.get("quote_id") or 0), int(data.get("due_days") or 14))
            SERVICE.store.log(actor, "QUOT3FLOW invoice created", "qf3_invoice", inv["id"], inv["invoice_no"])
            self.send_json(200, {"ok": True, "invoice": inv}); return
        m = re.fullmatch(r"/api/qf3/invoices/(\d+)", path)
        if m and method == "GET":
            inv = quoteflow.get_invoice(conn, int(m.group(1)))
            if not inv: raise KeyError("Invoice not found.")
            self.send_json(200, {"invoice": inv}); return
        m = re.fullmatch(r"/api/qf3/invoices/(\d+)/void", path)
        if m and method == "POST":
            deny_financial()
            inv = quoteflow.void_invoice(conn, actor, int(m.group(1)), data.get("reason") or "")
            SERVICE.store.log(actor, "QUOT3FLOW invoice voided", "qf3_invoice", inv["id"], inv["invoice_no"])
            self.send_json(200, {"ok": True, "invoice": inv}); return

        # ---- payments ----
        if path == "/api/qf3/payments" and method == "GET":
            iid = q.get("invoice_id", [None])[0]
            self.send_json(200, {"items": quoteflow.list_payments(conn, int(iid) if iid else None)}); return
        if path == "/api/qf3/payments" and method == "POST":
            if str(data.get("status") or "") == "confirmed" or data.get("confirm"):
                deny_financial()
            elif not can_write:
                raise PermissionError("QUOT3FLOW changes require the quoteflow edit permission.")
            res = quoteflow.record_payment(conn, actor, data)
            SERVICE.store.log(actor, "QUOT3FLOW payment recorded", "qf3_payment", res["id"], res["invoice"]["invoice_no"])
            self.send_json(200, {"ok": True, **res}); return
        m = re.fullmatch(r"/api/qf3/payments/(\d+)", path)
        if m and method == "POST":
            if str(data.get("status") or "") == "confirmed":
                deny_financial()
            elif not can_write:
                raise PermissionError("QUOT3FLOW changes require the quoteflow edit permission.")
            res = quoteflow.record_payment(conn, actor, data, int(m.group(1)))
            SERVICE.store.log(actor, "QUOT3FLOW payment updated", "qf3_payment", res["id"], res["invoice"]["invoice_no"])
            self.send_json(200, {"ok": True, **res}); return

        # ---- receipts / events / pdf ----
        if path == "/api/qf3/receipts" and method == "GET":
            self.send_json(200, {"items": quoteflow.list_receipts(conn)}); return
        if path == "/api/qf3/events" and method == "GET":
            ent, eid = q.get("entity", [""])[0], q.get("id", [""])[0]
            sql = "SELECT * FROM qf3_events"; args = []
            if ent:
                sql += " WHERE entity=?"; args.append(ent)
                if eid: sql += " AND entity_id=?"; args.append(int(eid))
            sql += " ORDER BY id DESC LIMIT 200"
            self.send_json(200, {"items": [dict(r) for r in conn.execute(sql, args).fetchall()]}); return
        m = re.fullmatch(r"/api/qf3/doc/(quote|invoice|receipt)/(\d+)/pdf", path)
        if m and method == "GET":
            name, raw = quoteflow.doc_pdf(conn, m.group(1), int(m.group(2)))
            self.send_response(200); self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Disposition", f'inline; filename="{name}"')
            self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store")
            self.end_headers(); self.wfile.write(raw); return
        if path == "/api/qf3/settings" and method == "POST":
            if not sensitive: raise PermissionError("QUOT3FLOW settings require Administrator or an approval grant.")
            allowed = {"webhook_secret_manual", "webhook_secret_yoco", "webhook_secret_fnb",
                       "webhook_secret_payfast", "webhook_secret_snapscan"}
            for k, v in data.items():
                if k in allowed:
                    quoteflow.set_setting(conn, k, str(v))
            conn.commit()
            SERVICE.store.log(actor, "QUOT3FLOW settings updated", "qf3_settings", 0, ",".join(k for k in data if k in allowed))
            self.send_json(200, {"ok": True}); return
        raise KeyError("Unknown QUOT3FLOW endpoint.")

    def _handle(self, method):
        try:
            # The original SQLite connection is shared by the local API bridge.
            # Serialise access and use check_same_thread=False in Store.
            #
            # A request must never wait for the lock forever: one slow or stuck
            # handler would freeze every other phone with no explanation. Wait a
            # bounded time, and if we do not get in, name who is holding it.
            if not SERVICE.lock.acquire(timeout=LOCK_WAIT_SECONDS):
                holder = getattr(SERVICE, "_lock_holder", None) or "an unknown request"
                print(f"[Beyond Registration API] {method} {self.path}: waited "
                      f"{LOCK_WAIT_SECONDS:.0f}s for the database lock, held by {holder}")
                self.send_json(503, {"error": "The system is busy. Please try again in a moment."})
                return
            previous_holder = getattr(SERVICE, "_lock_holder", None)
            _route_started = time.time()
            SERVICE._lock_holder = f"{method} {self.path} ({time.strftime('%H:%M:%S')})"
            try:
                self.dispatch(method)
            finally:
                # Name any route that held the whole server behind it. A route that
                # makes an outbound call while holding the lock (a push notification,
                # a remote fetch) freezes every other phone for as long as that call
                # takes, and until now the only trace was "the system is busy".
                _held = time.time() - _route_started
                if _held > 3.0:
                    print(f"[Beyond Registration API] SLOW {method} {self.path}: held the "
                          f"database lock {_held:.1f}s")
                # Restore, do not clear: a background cycle may be the outer
                # holder, and clearing would lose the name it set.
                SERVICE._lock_holder = previous_holder
                SERVICE.lock.release()
        except PermissionError as exc:
            self.send_json(403,{"error":str(exc)})
        except KeyError as exc:
            self.send_json(404,{"error":str(exc)})
        except (ValueError, TypeError) as exc:
            self.send_json(400,{"error":str(exc)})
        except Exception as exc:
            print(f"[Beyond Registration API] {method} {self.path}: {type(exc).__name__}: {exc}")
            self.send_json(500,{"error":"An unexpected application error occurred. Check the server console for details."})

    def _serve_tile(self, path):
        """GET /tiles/{z}/{x}/{y}.png - OpenStreetMap tiles cached on this PC.

        Runs OUTSIDE the database lock (no database access at all). Signed-in
        users only, checked against the in-memory session tables, so the public
        door can never be used as an open tile proxy. A tile fetched once is
        served from disk for 30 days and then kept as a stale fallback, so the
        safety map still draws on an office LAN with no internet. Follows the
        OSM tile policy: one identified User-Agent, cached, no bulk download.
        Set BR_TILES_OFFLINE=yes to never fetch (cache only).
        """
        m = re.fullmatch(r"/tiles/(\d{1,2})/(\d{1,7})/(\d{1,7})\.png", path)
        sid = self.get_sid()
        mm = re.search(r"(?:^|;\s*)br_mobile=([^;]+)", self.headers.get("Cookie", ""))
        signed_in = bool((sid and sid in SERVICE.sessions) or (mm and mm.group(1) in SERVICE.mobile_sessions))
        if not m or not signed_in:
            self.send_response(404 if not m else 401)
            self.send_header("Content-Length", "0"); self.end_headers(); return
        z, x, y = (int(g) for g in m.groups())
        if z > 19 or x >= 2 ** z or y >= 2 ** z:
            self.send_response(404); self.send_header("Content-Length", "0"); self.end_headers(); return
        cache = Path(legacy.DATA_HOME) / "tiles" / str(z) / str(x) / ("%d.png" % y)
        data = b""
        fresh = cache.is_file() and (time.time() - cache.stat().st_mtime) < 30 * 86400
        offline_only = os.environ.get("BR_TILES_OFFLINE", "").strip().lower() in ("1", "yes", "on")
        if not fresh and not offline_only:
            try:
                req = urllib.request.Request(
                    "https://tile.openstreetmap.org/%d/%d/%d.png" % (z, x, y),
                    headers={"User-Agent": "N3XUS-BeyondRegistration/5 (self-hosted business app; local tile cache)"})
                with urllib.request.urlopen(req, timeout=8) as response:
                    data = response.read(2_000_000)
                if data.startswith(b"\x89PNG"):
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    tmp = cache.with_name("%d.%s.tmp" % (y, secrets.token_hex(4)))
                    tmp.write_bytes(data)
                    os.replace(tmp, cache)
                else:
                    data = b""
            except Exception:
                data = b""
        if not data and cache.is_file():
            data = cache.read_bytes()            # stale beats blank when offline
        if not data:
            self.send_response(404); self.send_header("Content-Length", "0"); self.end_headers(); return
        self.send_response(200)
        self.send_header("Content-Type", "image/png")
        self.send_header("Cache-Control", "private, max-age=86400")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/voic3/events":
            self._voic3_sse(parsed); return
        if parsed.path.startswith("/tiles/"):
            self._serve_tile(parsed.path); return
        if self.path.startswith("/api/"):
            self._handle("GET"); return
        self.serve_static()
    def do_POST(self): self._handle("POST")
    def do_PUT(self): self._handle("PUT")
    def do_DELETE(self): self._handle("DELETE")
    def _voic3_sse(self, parsed):
        import queue as _q
        sid = self.get_sid()
        actor = SERVICE.authenticated(sid)
        mobile_cookie = self.headers.get("Cookie", "")
        mm = re.search(r"(?:^|;\s*)br_mobile=([^;]+)", mobile_cookie)
        mobile_sid = mm.group(1) if mm else None
        mobile_eid = SERVICE.mobile_sessions.get(mobile_sid or "")
        eid = mobile_eid
        if eid is None and actor:
            try:
                row = SERVICE.store.conn.execute("SELECT id FROM admins WHERE username=? COLLATE NOCASE", (actor,)).fetchone()
                if row:
                    eid = int(row["id"])
            except Exception:
                eid = None
        if eid is None:
            self.send_json(401, {"error": "Authentication required."}); return
        try:
            with SERVICE.lock:
                leave = SERVICE.store.conn.execute("SELECT COUNT(*) AS c FROM leave_records WHERE employee_id=? AND status='Approved' AND date_from<=date('now') AND date_to>=date('now')", (eid,)).fetchone()
                status = "on_leave" if (leave and int(leave["c"]) > 0) else "online"
                stamp = iso_now()
                SERVICE.store.conn.execute("INSERT INTO voic3_presence(employee_id,status,custom_note,updated_at) VALUES(?,?,?,?) ON CONFLICT(employee_id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at", (eid, status, "", stamp))
                SERVICE.store.conn.commit()
        except Exception:
            status = "online"
        publish_voic3_event([eid], "presence.update", {"employee_id": eid, "status": status})
        q = _q.Queue(maxsize=256)
        with _VOIC3_STREAMS_LOCK:
            _VOIC3_STREAMS.setdefault(eid, []).append(q)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        try:
            while True:
                try:
                    etype, payload = q.get(timeout=15)
                    data = json.dumps(payload, default=str)
                    self.wfile.write(("event: %s\ndata: %s\n\n" % (etype, data)).encode())
                    self.wfile.flush()
                except _q.Empty:
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
        except Exception:
            pass
        finally:
            with _VOIC3_STREAMS_LOCK:
                lst = _VOIC3_STREAMS.get(eid, [])
                if q in lst:
                    lst.remove(q)
                if not lst:
                    _VOIC3_STREAMS.pop(eid, None)
                    try:
                        with SERVICE.lock:
                            SERVICE.store.conn.execute("UPDATE voic3_presence SET status='offline',updated_at=? WHERE employee_id=?", (iso_now(), eid))
                            SERVICE.store.conn.commit()
                        publish_voic3_event([eid], "presence.update", {"employee_id": eid, "status": "offline"})
                    except Exception:
                        pass

    def serve_static(self):
        path=urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        if path in ("/","/index.html"): target=UI_ROOT/"index.html"
        elif path in ("/mobile","/mobile/"): target=UI_ROOT/"mobile"/"index.html"
        elif path in ("/academy","/academy/"): target=UI_ROOT/"academy"/"index.html"
        else: target=(UI_ROOT/path.lstrip("/" )).resolve()
        try: target.relative_to(UI_ROOT.resolve())
        except ValueError: self.send_error(404); return
        if not target.is_file(): self.send_error(404); return
        data=target.read_bytes()
        if target.name=="manifest.webmanifest": ctype="application/manifest+json"
        else: ctype=mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        # A service worker is only accepted if its script is served with a
        # JavaScript content type; without the header the browser refuses to
        # register it and the app cannot be installed to a home screen.
        if target.name=="sw.js" or target.suffix==".js":
            ctype="application/javascript"
        elif ctype.startswith("text/") or ctype=="application/javascript":
            ctype=ctype+"; charset=utf-8"
        self.send_response(200); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(len(data)))
        if target.name=="sw.js": self.send_header("Service-Worker-Allowed","/mobile/")
        self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(data)


def make_server():
    # Local-only by default. Enable LAN access explicitly for owner testing; production
    # phone access must be placed behind an HTTPS reverse proxy/VPN.
    host=os.environ.get("BR_SERVER_HOST", "127.0.0.1").strip() or "127.0.0.1"
    if host not in ("127.0.0.1", "localhost", "0.0.0.0"):
        raise RuntimeError("BR_SERVER_HOST must be 127.0.0.1 or 0.0.0.0")
    if host=="0.0.0.0" and os.environ.get("BR_ALLOW_LAN", "").lower()!="yes":
        raise RuntimeError("Set BR_ALLOW_LAN=yes only for a trusted-network test. Use HTTPS/VPN for production mobile access.")
    configured=os.environ.get("BR_SERVER_PORT", "64281").strip()
    if configured and configured!="0":
        port=int(configured); server=ThreadingHTTPServer((host,port),Handler)
    else:
        sock=socket.socket(); sock.bind((host,0)); port=sock.getsockname()[1]; sock.close()
        server=ThreadingHTTPServer((host,port),Handler)
    server.daemon_threads=True
    # HTTPS on the phone: a browser refuses camera and microphone on plain http,
    # so wrap the socket in a certificate this machine mints for itself, free and
    # offline. Set BR_TLS=off to keep plain http for desktop-only use.
    _tls_default = "off" if os.environ.get("BR_SERVER_PORT","").strip() == "0" else "on"
    if os.environ.get("BR_TLS", _tls_default).lower() not in ("off", "0", "no"):
        try:
            import br_connect
            from pathlib import Path as _Path
            _data_home = legacy.DATA_HOME
            cert, key = br_connect.ensure_certificate(_data_home)
            ctx = br_connect.ssl_context(_data_home)
            if ctx is not None:
                server.socket = ctx.wrap_socket(server.socket, server_side=True)
                scheme = "https"
                try:
                    lan = br_connect.lan_url(server.server_address[1])
                except Exception:
                    lan = "%s://%s:%s/mobile" % (scheme, host, server.server_address[1])
                SERVICE.br_urls = {
                    "scheme": scheme,
                    "lan": lan,
                    "loopback": "%s://127.0.0.1:%s/mobile" % (scheme, server.server_address[1]),
                    "fingerprint": br_connect.fingerprint(cert),
                }
                print("[BR] Phone URL (same Wi-Fi):", lan, flush=True)
        except Exception as exc:
            print("[BR] HTTPS unavailable, using plain http:", exc, flush=True)
    # M4STR0 background scheduler — runs orchestration cycles on an interval.
    # Respects pause / emergency stop; interval via MSTR_INTERVAL seconds (default 300).
    def _mstr_loop():
        import time as _t
        while True:
            try:
                # One agent at a time, each under its own short hold, and a single
                # commit for the whole cycle (see mastr0.run_cycle). Holding the
                # lock for the entire cycle put every request behind a scan.
                with SERVICE.lock:
                    if not getattr(SERVICE, "_qf3_ready", False):
                        quoteflow.ensure_schema(SERVICE.store.conn)
                        mastr0.ensure_schema(SERVICE.store.conn)
                        SERVICE._qf3_ready = True
                    paused = mastr0.paused(SERVICE.store.conn)
                if not paused:
                    mastr0.run_cycle(SERVICE.store.conn, lock=SERVICE.lock)
            except Exception as exc:
                # A silent failure here used to be invisible; one line is enough
                # to tell a broken cycle from an idle one.
                print(f"[M4STR0] cycle failed: {exc}", flush=True)
            _t.sleep(max(30, int(os.environ.get("MSTR_INTERVAL", "300"))))
    # Guard against duplicate scheduler threads when make_server() is called repeatedly.
    if not globals().get("_MSTR_SCHEDULER_STARTED"):
        globals()["_MSTR_SCHEDULER_STARTED"] = True
        threading.Thread(target=_mstr_loop, daemon=True, name="mstr-scheduler").start()
    return server,port


if __name__ == "__main__":
    _server, _port = make_server()
    SERVICE.httpd = _server
    SERVICE.server_port = _port
    _urls = getattr(SERVICE, "br_urls", None) or {}
    _scheme = _urls.get("scheme", "http")
    print("=" * 70)
    print("NEXUS 5.6.0: BEYOND REGISTRATION LOCAL API ONLINE")
    print(f"Listening at: {_scheme}://127.0.0.1:{_port}")
    if _urls.get("lan"):
        print(f"Phone (same Wi-Fi): {_urls['lan']}")
        print("Scan it: open the desktop app and go to Settings > Devices.")
        print("The phone will warn once that the certificate is self-signed;")
        print("choose Advanced > Proceed. It is this machine's own certificate.")
    else:
        print(f"Phone: https://<this-PC-LAN-IP>:{_port}/mobile")
    print("=" * 70)
    # Ctrl+C, a closed console and a normal exit all reach this: write whatever
    # is still only in RAM, then let go of the single-writer lock.
    def _stop_server(_signum=None, _frame=None):
        raise KeyboardInterrupt
    try:
        signal.signal(signal.SIGTERM, _stop_server)
    except (ValueError, OSError, AttributeError):
        pass
    try:
        _server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            _server.server_close()
        finally:
            try:
                legacy.shutdown_persistence()
                print("[BR db] pending changes written; database lock released.", flush=True)
            except Exception as _flush_exc:
                print("[BR db] final write failed:", _flush_exc, flush=True)

