"""Self-hosted Web Push (VAPID / RFC 8291 + RFC 8292) — Section 12.

Zero paid services and zero new dependencies: VAPID signing and the
``aes128gcm`` payload encryption are done with ``cryptography``, which the app
already ships. Everything here degrades to a no-op when VAPID keys are not
configured, so the Windows app and the P2P WebRTC/WebSocket flow are untouched.

Keys come from the environment (``VAPID_PUBLIC_KEY`` / ``VAPID_PRIVATE_KEY`` /
``VAPID_SUBJECT``) or are generated once into ``data/vapid.json`` on first use,
so a single-host install never needs a third-party push gateway.
"""
from __future__ import annotations

import base64
import json
import os
import struct
import threading
import time
import urllib.parse
import urllib.request

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VAPID_SUBJECT_DEFAULT = "mailto:admin@your-userd-registration.local"
PUSH_TTL_SECONDS = 3600
_LOCK = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS push_subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  device_label TEXT DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_push_subs_user_endpoint
  ON push_subscriptions(user_id, endpoint);
"""


# ---------------------------------------------------------------------------
# base64url helpers (no padding, as VAPID/WebPush require)
# ---------------------------------------------------------------------------
def b64u_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def b64u_decode(text: str) -> bytes:
    pad = "=" * (-len(str(text).strip()) % 4)
    return base64.urlsafe_b64decode(str(text).strip() + pad)


# ---------------------------------------------------------------------------
# Key management
# ---------------------------------------------------------------------------
def _default_data_home():
    """The app's real data folder (same rule as Beyond_Registration.DATA_HOME).

    Never the current working directory: that made the key depend on which
    folder the server was started from (two different keys existed), put a
    private key inside the app folder, and kept it out of the restic backup.
    """
    if os.name == "nt":
        return os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Beyond Registration", "Data")
    return os.path.join(os.path.expanduser("~"), ".your-userd_registration", "Data")


def _key_path(data_home=None):
    home = data_home or os.environ.get("BR_DATA_HOME") or _default_data_home()
    return os.path.join(str(home), "vapid.json")


def generate_vapid_keys():
    """Return ``(public_b64u, private_b64u)`` for a fresh P-256 key pair."""
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_raw = private_key.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    private_raw = private_key.private_numbers().private_value.to_bytes(32, "big")
    return b64u_encode(public_raw), b64u_encode(private_raw)


def _load_stored_keys(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        public = str(data.get("public") or "").strip()
        private = str(data.get("private") or "").strip()
        if public and private:
            return public, private
    except Exception:
        pass
    return None


def _store_keys(path, public, private):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump({"public": public, "private": private,
                       "created_at": time.strftime("%Y-%m-%dT%H:%M:%S")}, handle)
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass
        return True
    except Exception:
        return False


def vapid_keys():
    """Return ``(public, private, subject)`` or ``None`` when unconfigured.

    Precedence: environment variables, then a previously generated
    ``data/vapid.json``, then a freshly generated file. A missing file that
    cannot be written simply means push stays disabled.
    """
    public = (os.environ.get("VAPID_PUBLIC_KEY") or "").strip()
    private = (os.environ.get("VAPID_PRIVATE_KEY") or "").strip()
    subject = (os.environ.get("VAPID_SUBJECT") or "").strip() or VAPID_SUBJECT_DEFAULT
    if public and private:
        return public, private, subject
    with _LOCK:
        path = _key_path()
        stored = _load_stored_keys(path)
        if stored:
            return stored[0], stored[1], subject
        public, private = generate_vapid_keys()
        if _store_keys(path, public, private):
            return public, private, subject
        return None


def enabled():
    return vapid_keys() is not None


def public_key():
    keys = vapid_keys()
    return keys[0] if keys else ""


# ---------------------------------------------------------------------------
# Schema + subscriptions
# ---------------------------------------------------------------------------
def ensure_schema(conn):
    try:
        conn.executescript(SCHEMA)
        conn.commit()
        return True
    except Exception:
        return False


def save_subscription(conn, user_id, endpoint, p256dh, auth, device_label=""):
    """Insert or refresh one browser subscription. Returns the row id."""
    ensure_schema(conn)
    stamp = time.strftime("%Y-%m-%dT%H:%M:%S")
    conn.execute(
        "INSERT INTO push_subscriptions(user_id,endpoint,p256dh,auth,device_label,created_at) "
        "VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,endpoint) DO UPDATE SET "
        "p256dh=excluded.p256dh, auth=excluded.auth, device_label=excluded.device_label",
        (int(user_id), str(endpoint), str(p256dh), str(auth), str(device_label or "")[:80], stamp),
    )
    conn.commit()
    row = conn.execute(
        "SELECT id FROM push_subscriptions WHERE user_id=? AND endpoint=?",
        (int(user_id), str(endpoint))).fetchone()
    return int(row[0]) if row else 0


def delete_subscription(conn, user_id, endpoint):
    ensure_schema(conn)
    cur = conn.execute("DELETE FROM push_subscriptions WHERE user_id=? AND endpoint=?",
                       (int(user_id), str(endpoint)))
    conn.commit()
    return cur.rowcount > 0


def subscriptions_for(conn, user_ids):
    ids = [int(x) for x in (user_ids or []) if x]
    if not ids:
        return []
    try:
        marks = ",".join("?" for _ in ids)
        rows = conn.execute(
            "SELECT id,user_id,endpoint,p256dh,auth,device_label FROM push_subscriptions "
            "WHERE user_id IN (" + marks + ")", tuple(ids)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Encryption (RFC 8291 aes128gcm) + VAPID auth (RFC 8292)
# ---------------------------------------------------------------------------
def _hkdf(salt, ikm, info, length):
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=salt, info=info).derive(ikm)


def encrypt_payload(p256dh_b64, auth_b64, plaintext):
    """Return ``(body_bytes, crypto_key_header, encryption_header)``.

    ``body`` is the aes128gcm record (RFC 8188). Headers are the RFC 8291
    ``Crypto-Key`` / ``Encryption`` values older push services still expect.
    """
    ua_public = b64u_decode(p256dh_b64)
    auth_secret = b64u_decode(auth_b64)
    as_private = ec.generate_private_key(ec.SECP256R1())
    as_public = as_private.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    shared = as_private.exchange(ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(
        ec.SECP256R1(), ua_public))

    key_info = b"WebPush: info\x00" + ua_public + as_public
    ikm = _hkdf(auth_secret, shared, key_info, 32)
    salt = os.urandom(16)
    cek = _hkdf(salt, ikm, b"Content-Encoding: aes128gcm\x00", 16)
    nonce = _hkdf(salt, ikm, b"Content-Encoding: nonce\x00", 12)

    data = plaintext.encode("utf-8") if isinstance(plaintext, str) else bytes(plaintext)
    # Single record: payload || 0x02 (last-record delimiter).
    sealed = AESGCM(cek).encrypt(nonce, data + b"\x02", None)
    body = salt + struct.pack("!I", 4096) + bytes([len(as_public)]) + as_public + sealed
    return body, "dh=" + b64u_encode(as_public), "salt=" + b64u_encode(salt)


def vapid_headers(endpoint, public, private, subject, expires_in=12 * 3600):
    """Build the ``Authorization`` / ``Crypto-Key`` headers for one endpoint."""
    audience = "{0.scheme}://{0.netloc}".format(urllib.parse.urlsplit(endpoint))
    header = b64u_encode(json.dumps({"typ": "JWT", "alg": "ES256"}).encode("utf-8"))
    claims = b64u_encode(json.dumps({
        "aud": audience,
        "exp": int(time.time()) + int(expires_in),
        "sub": subject or VAPID_SUBJECT_DEFAULT,
    }).encode("utf-8"))
    signing_input = (header + "." + claims).encode("ascii")
    private_key = ec.derive_private_key(int.from_bytes(b64u_decode(private), "big"), ec.SECP256R1())
    der = private_key.sign(signing_input, ec.ECDSA(hashes.SHA256()))
    r, s = decode_dss_signature(der)
    signature = b64u_encode(r.to_bytes(32, "big") + s.to_bytes(32, "big"))
    token = (signing_input.decode("ascii") + "." + signature)
    return {
        "Authorization": "vapid t=" + token + ", k=" + public,
        "Crypto-Key": "p256ecdsa=" + public,
    }


# ---------------------------------------------------------------------------
# Sending
# ---------------------------------------------------------------------------
def _post(url, body, headers, timeout=5):
    request = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return int(getattr(response, "status", 201) or 201)


def send(subscription, payload):
    """Send one push. Returns ``(ok, status, reason)``; never raises.

    ``payload`` is a dict with at least ``title``/``body``; it is JSON-encoded
    for the service worker.
    """
    keys = vapid_keys()
    if not keys:
        return False, 0, "vapid-not-configured"
    public, private, subject = keys
    endpoint = str(subscription.get("endpoint") or "")
    if not endpoint:
        return False, 0, "no-endpoint"
    try:
        message = payload if isinstance(payload, str) else json.dumps(payload, separators=(",", ":"))
        body, crypto_key, encryption = encrypt_payload(
            subscription.get("p256dh"), subscription.get("auth"), message)
        headers = vapid_headers(endpoint, public, private, subject)
        headers.update({
            "Content-Type": "application/octet-stream",
            "Content-Encoding": "aes128gcm",
            "TTL": str(PUSH_TTL_SECONDS),
            "Urgency": "high",
            "Crypto-Key": headers.get("Crypto-Key", "") + ";" + crypto_key,
            "Encryption": encryption,
        })
        status = _post(endpoint, body, headers)
        return (200 <= status < 300), status, ""
    except Exception as exc:  # noqa: BLE001
        code = getattr(exc, "code", 0) or 0
        return False, int(code), str(exc)[:160]


def notify_user(conn, user_ids, payload, active_ids=None):
    """Push to every registered device of ``user_ids`` that is not ``active_ids``.

    ``active_ids`` are the employees that currently hold an open SSE stream;
    they already got the event in-app, so they are skipped (the "no active
    WebSocket connection" rule). Expired subscriptions (404/410) are removed.
    Returns a small summary dict, never raises.
    """
    if not enabled():
        return {"enabled": False, "sent": 0, "skipped": 0, "removed": 0}
    active = set(int(x) for x in (active_ids or []) if x)
    ids = [int(x) for x in (user_ids or []) if x and int(x) not in active]
    if not ids:
        return {"enabled": True, "sent": 0, "skipped": 0, "removed": 0}
    sent = 0
    removed = 0
    for sub in subscriptions_for(conn, ids):
        ok, status, _reason = send(sub, payload)
        if ok:
            sent += 1
        elif status in (404, 410):
            try:
                delete_subscription(conn, sub["user_id"], sub["endpoint"])
                removed += 1
            except Exception:
                pass
    return {"enabled": True, "sent": sent, "skipped": 0, "removed": removed}


# ---------------------------------------------------------------------------
# Convenience payload builders (used by call / SOS / DM hooks)
# ---------------------------------------------------------------------------
def call_payload(call_id, caller_name, call_type="audio"):
    kind = "Video" if str(call_type).lower() == "video" else "Audio"
    return {
        "type": "call",
        "title": kind + " call from " + str(caller_name or "a colleague"),
        "body": "Tap Answer to join, or Decline to send it to voicemail.",
        "tag": "voic3-call-" + str(call_id),
        "renotify": True,
        "requireInteraction": True,
        "url": "/?voic3_call=" + str(call_id),
        "actions": [
            {"action": "answer", "title": "Answer"},
            {"action": "decline", "title": "Decline"},
        ],
        "data": {"callId": int(call_id), "url": "/?voic3_call=" + str(call_id)},
    }


def sos_payload(alert_id, who, place=""):
    return {
        "type": "sos",
        "title": "SOS · " + str(who or "A colleague"),
        "body": str(place or "Emergency assistance requested."),
        "tag": "voic3-sos-" + str(alert_id),
        "renotify": True,
        "requireInteraction": True,
        "url": "/?voic3_sos=" + str(alert_id),
        "actions": [{"action": "acknowledge", "title": "Acknowledge"}],
        "data": {"sosId": int(alert_id), "url": "/?voic3_sos=" + str(alert_id)},
    }


def message_payload(conversation_id, sender_name, preview, message_id=0):
    return {
        "type": "message",
        "title": str(sender_name or "New message"),
        "body": str(preview or "")[:140],
        "tag": "voic3-conv-" + str(conversation_id),
        "url": "/?voic3_conversation=" + str(conversation_id),
        "actions": [{"action": "open", "title": "Open"}],
        "data": {"conversationId": int(conversation_id), "messageId": int(message_id or 0),
                 "url": "/?voic3_conversation=" + str(conversation_id)},
    }
