"""N3XUS desktop window - the same UI in a native Windows window (Edge WebView2).

Free and open source: pywebview (BSD-3-Clause) is already in requirements.txt
and Edge WebView2 ships with Windows 10/11. This file only OPENS A WINDOW on
the server that NEXUS_LAUNCHER.bat started; it never starts a second server.

It falls back to the default browser - exactly the old behaviour - when
pywebview is missing, or when this PC does not trust the server certificate
yet (run desktop\\tools\\make-trusted-cert.bat once to fix that for good).

Cookies and localStorage persist in Data\\desktop-window, so the sign-in and
the bento tile order survive a restart (pywebview's default is a private,
throw-away profile).
"""
from __future__ import annotations

import os
import ssl
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

URL = os.environ.get("N3XUS_DESKTOP_URL", "https://localhost:64281/")


def _data_home() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data"
    return Path.home() / ".your-userd_registration" / "Data"


def server_state(timeout: float = 2.0) -> str:
    """'trusted', 'untrusted' (answers, certificate not trusted here) or 'down'."""
    health = URL.rstrip("/") + "/api/system/health"
    try:
        _ctx = ssl.create_default_context()
        _ctx.check_hostname = False
        _ctx.verify_mode = ssl.CERT_NONE
        with urllib.request.urlopen(health, timeout=timeout, context=_ctx) as response:
            return "trusted" if response.status == 200 else "down"
    except ssl.SSLError:
        return "untrusted"
    except urllib.error.URLError as exc:
        return "untrusted" if isinstance(getattr(exc, "reason", None), ssl.SSLError) else "down"
    except Exception:
        return "down"


def main() -> int:
    state = "down"
    for _ in range(30):                      # the launcher may still be starting it
        state = server_state()
        if state != "down":
            break
        time.sleep(1)
    if state == "down":
        print(f"N3XUS is not answering on {URL}. Start it with NEXUS_LAUNCHER.bat.")
        return 1
    if state == "untrusted":
        print("This PC does not trust the N3XUS certificate yet - opening the browser instead.")
        print("Run desktop\\tools\\make-trusted-cert.bat once for the native window.")
        webbrowser.open(URL)
        return 0
    try:
        import webview  # pywebview, BSD-3-Clause
    except ImportError:
        webbrowser.open(URL)
        return 0
    try:
        webview.settings["ALLOW_DOWNLOADS"] = True       # payslip and report PDFs
    except Exception:
        pass
    storage = _data_home() / "desktop-window"
    storage.mkdir(parents=True, exist_ok=True)
    webview.create_window("N3XUS - Beyond Registration", URL, width=1440, height=900, min_size=(1024, 680))
    webview.start(private_mode=False, storage_path=str(storage))
    return 0


if __name__ == "__main__":
    sys.exit(main())
