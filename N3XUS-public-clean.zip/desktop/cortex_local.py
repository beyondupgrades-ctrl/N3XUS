"""CORTEX local engine — one in-house model, no API keys, no subscriptions.

Everything here talks to a local Ollama (or llama.cpp `llama-server`) on this
machine. Nothing is sent off the PC, there is no key, no account and no paid
service anywhere in this module.

Three things used to disagree about which model to use:

* ``api_vision_ollama``  defaulted to ``qwen2.5-coder:14b``
* ``_llm_chat`` (the slide-over drawer) also defaulted to ``qwen2.5-coder:14b``
* ``_evolve_llm``        used a separate ``qwen2.5vl:3b``

On an 8 GB laptop the 14B answer is "never": Windows has already paged the model
out, so every CORTEX turn silently fell through to a deterministic summary. This
module gives all three **one** choice, sized to the RAM that is actually free.

Rules (all deliberately conservative — a wrong answer here is a frozen laptop):

1. The model saved in Settings wins.
2. Otherwise pick the smallest installed model that fits free RAM.
3. Never pick a model larger than free RAM, even if it is the only one — the
   deterministic fallback is better than a 9 GB swap storm.
4. Prefer a general-instruct model over a coding model: CORTEX answers business
   questions, it does not write code.
5. Keep the model resident briefly (`keep_alive`) so a follow-up question is not
   another cold load, while still returning the RAM afterwards.

Public surface::

    ram_profile()                     total / available RAM on this PC
    installed_models(host)            what Ollama reports, with sizes
    resolve(host, saved_model)        -> {model, host, reason, fits, ...}
    chat(messages, ...)               -> one local completion
    doctor(host, saved_model)         -> everything the Settings page needs
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request

DEFAULT_HOST = "http://127.0.0.1:11434"
# Kept resident for a few minutes: long enough that a follow-up question does
# not pay the cold-load cost again, short enough that the RAM comes back.
KEEP_ALIVE = "5m"
# Ollama's own default context (2048) is too small for the business snapshot;
# 6144 is a deliberate ceiling so the KV cache cannot balloon past 8 GB.
DEFAULT_NUM_CTX = 6144
MAX_NUM_CTX = 8192

# Ollama/llama.cpp overhead over the file size: KV cache at num_ctx 6144,
# the compute graph and buffers. Measured against real runs, not a guess.
OVERHEAD_FACTOR = 1.25
# A model must leave this much RAM for Windows and this app before it is worth
# attempting: below ~350 MB free Windows starts paging and every token stalls.
RAM_FLOOR_GB = 0.35

# Models that answer business questions, best first. Grouped by intent so the
# default stays sane whatever happens to be installed.
GENERAL_PREFERENCE = (
    "qwen2.5:1.5b", "phi4-mini", "qwen2.5:7b", "phi3.5", "phi3",
    "mistral:7b", "qwen2.5:0.5b", "moondream",
)
CODING_HINTS = ("-coder", "codellama", "starcoder", "deepseek-coder", "qwen2.5-coder")
BIG_HINTS = (":14b", ":13b", ":32b", ":70b", ":34b", ":30b", ":27b")


# ---------------------------------------------------------------------------
# RAM on this PC
# ---------------------------------------------------------------------------
def ram_profile():
    """Total and available physical memory in GB, or None when unknown.

    Uses Win32 GlobalMemoryStatusEx through ctypes (no psutil dependency) and
    falls back to /proc/meminfo so the test suite runs anywhere.
    """
    try:
        import ctypes

        class _MemoryStatus(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        status = _MemoryStatus()
        status.dwLength = ctypes.sizeof(_MemoryStatus)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            gb = float(1 << 30)
            return {
                "total_gb": round(status.ullTotalPhys / gb, 2),
                "available_gb": round(status.ullAvailPhys / gb, 2),
                "load_percent": int(status.dwMemoryLoad),
            }
    except Exception:
        pass
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            fields = {}
            for line in handle:
                key, _, rest = line.partition(":")
                fields[key.strip()] = rest.strip()
        total = float(fields["MemTotal"].split()[0]) * 1024
        available = float(fields["MemAvailable"].split()[0]) * 1024
        gb = float(1 << 30)
        return {
            "total_gb": round(total / gb, 2),
            "available_gb": round(available / gb, 2),
            "load_percent": int(round(100 - (available / total * 100.0))) if total else 0,
        }
    except Exception:
        return None


# ---------------------------------------------------------------------------
# What is installed
# ---------------------------------------------------------------------------
def _http_json(url, payload=None, timeout=4):
    if payload is None:
        request = urllib.request.Request(url, method="GET")
    else:
        request = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8", errors="replace"))


def installed_models(host=DEFAULT_HOST):
    """`[{name, size_gb, needs_gb, parameter_size, quantization, family, capabilities}]`.

    Returns ``[]`` when the local service is not answering — that is a normal
    state, not an error: the caller falls back to a deterministic answer.
    """
    try:
        data = _http_json(str(host).rstrip("/") + "/api/tags", None, timeout=3)
    except Exception:
        return []
    out = []
    for item in data.get("models") or []:
        name = str(item.get("name") or item.get("model") or "")
        if not name:
            continue
        details = item.get("details") or {}
        size_gb = round(float(item.get("size") or 0) / (1 << 30), 2)
        out.append({
            "name": name,
            "size_gb": size_gb,
            "needs_gb": round(size_gb * OVERHEAD_FACTOR, 2) if size_gb else 0.0,
            "parameter_size": details.get("parameter_size") or "",
            "quantization": details.get("quantization_level") or "",
            "family": details.get("family") or "",
            "capabilities": list(item.get("capabilities") or []),
        })
    return out


def running_models(host=DEFAULT_HOST):
    """Models Ollama currently holds in memory."""
    try:
        data = _http_json(str(host).rstrip("/") + "/api/ps", None, timeout=3)
        return [str(m.get("name") or "") for m in (data.get("models") or []) if m.get("name")]
    except Exception:
        return []


# Task models that cannot answer a question about the business: they embed text
# or look at pictures. Offering one as "the CORTEX model" only confuses people.
NOT_A_CHAT_MODEL = ("embed", "nomic", "bge", "minilm", "clip", "llava-embed")


def is_chat_model(model):
    """True when the model can hold a conversation (not an embedding blob)."""
    name = str(model.get("name") or "").lower()
    if any(hint in name for hint in NOT_A_CHAT_MODEL):
        return False
    caps = [str(c).lower() for c in (model.get("capabilities") or [])]
    if caps and "completion" not in caps:
        return False
    return True


def _rank(model):
    """Lower is preferred. General instruct models beat coding models; small beats large."""
    name = model["name"].lower()
    for position, wanted in enumerate(GENERAL_PREFERENCE):
        if name.startswith(wanted.lower()):
            return position
    if any(hint in name for hint in CODING_HINTS):
        return 500
    if any(hint in name for hint in BIG_HINTS):
        return 900
    return 400


def resolve(host=DEFAULT_HOST, saved_model=""):
    """Choose the one model CORTEX uses, and explain the choice.

    Returns a dict the Settings page, the status endpoint and every chat path
    all read, so they can never disagree::

        {host, model, available, reason, requested, models[], ram{...},
         running[], keep_alive, num_ctx}
    """
    ram = ram_profile()
    models = installed_models(host)
    names = [m["name"] for m in models]
    saved = (saved_model or "").strip()
    model = ""
    reason = ""

    if saved and saved in names:
        model, reason = saved, "Saved in Settings."
    elif not names:
        reason = ("The local AI service is not answering on %s. Start Ollama "
                  "(or llama-server) to enable model answers; until then CORTEX "
                  "replies from the data snapshot only." % host)
    elif saved:
        reason = ("Saved model '%s' is not installed on this PC; using the best "
                  "installed model instead." % saved)

    if not model and models:
        # Only a model that can hold a conversation is a candidate: an embedding
        # blob is smaller and fits first, but it cannot answer a question.
        chat = [m for m in models if is_chat_model(m)] or models
        # A model needs its own weight in RAM and must still leave the floor
        # free, so "usable" means needs_gb + RAM_FLOOR_GB <= available.
        fits = [m for m in chat
                if ram is None or m["needs_gb"] + RAM_FLOOR_GB <= float(ram["available_gb"])]
        if fits:
            best = sorted(fits, key=lambda m: (_rank(m), m["needs_gb"]))[0]
            model = best["name"]
            if not reason:
                reason = ("Chosen automatically: %s needs about %.1f GB%s."
                          % (model, best["needs_gb"],
                             (" and %.1f GB is free right now" % float(ram["available_gb"])) if ram else ""))
        else:
            # "Fits" for a chat model means needs_gb + RAM_FLOOR. Report the
            # smallest *fitting threshold*, and say what freeing that much buys.
            smallest = sorted(chat, key=lambda m: m["needs_gb"])[0]
            threshold = round(smallest["needs_gb"] + RAM_FLOOR_GB, 1)
            free = float(ram["available_gb"]) if ram else 0.0
            reason = ("No installed model fits the %.1f GB free: %s is the smallest "
                      "and needs about %.1f GB with %.1f GB kept free. Freeing "
                      "%.1f GB more would let it answer; until then CORTEX replies "
                      "from the data snapshot."
                      % (free, smallest["name"], smallest["needs_gb"], RAM_FLOOR_GB,
                         max(0.0, threshold - free)))

    chosen = next((m for m in models if m["name"] == model), None)
    # "fits" only means something once a model is actually chosen.
    if not model:
        chosen = None
    # A model the user explicitly saved is always reported as "fits" — they may
    # know they are about to close other apps, and the UI says so either way.
    fits = bool(model)
    if chosen and ram and (not saved or saved != chosen["name"]):
        fits = chosen["needs_gb"] + RAM_FLOOR_GB <= float(ram["available_gb"])
    return {
        "host": str(host).rstrip("/"),
        "model": model,
        "requested": saved,
        "reason": reason,
        "available": bool(model),
        "fits": bool(fits),
        "needs_gb": chosen["needs_gb"] if chosen else 0.0,
        "models": models,
        "running": running_models(host),
        "ram": ram,
        "keep_alive": KEEP_ALIVE,
        "num_ctx": DEFAULT_NUM_CTX,
    }


# ---------------------------------------------------------------------------
# One completion
# ---------------------------------------------------------------------------
def chat(messages, model, host=DEFAULT_HOST, timeout=180, num_ctx=DEFAULT_NUM_CTX,
         temperature=0.2, num_predict=700):
    """Ask the local model one question. Returns ``{reply, model, ms}``.

    Raises RuntimeError with a sentence a user can act on when the local service
    is unreachable — the caller turns that into the deterministic fallback.
    """
    if not model:
        raise RuntimeError("No local model is selected.")
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "keep_alive": KEEP_ALIVE,
        "options": {
            "temperature": temperature,
            "num_predict": num_predict,
            "num_ctx": min(int(num_ctx or DEFAULT_NUM_CTX), MAX_NUM_CTX),
        },
    }
    started = time.time()
    try:
        data = _http_json(str(host).rstrip("/") + "/api/chat", payload, timeout=timeout)
    except urllib.error.HTTPError as exc:
        raise RuntimeError("The local model returned HTTP %s." % exc.code) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(
            "The local AI service is not reachable on %s. Start Ollama to get "
            "model answers." % host) from exc
    except Exception as exc:
        raise RuntimeError("The local model could not be reached (%s)." % type(exc).__name__) from exc
    reply = (data.get("message") or {}).get("content") or data.get("response") or ""
    return {
        "reply": str(reply).strip(),
        "model": model,
        "ms": int((time.time() - started) * 1000),
    }


def warm(model, host=DEFAULT_HOST):
    """Optional: pull the model into memory while the user is reading the page.

    Never raises — it is a nicety, not a requirement.
    """
    if not model:
        return False
    try:
        _http_json(str(host).rstrip("/") + "/api/chat",
                   {"model": model, "messages": [], "keep_alive": KEEP_ALIVE}, timeout=90)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Everything the Settings page and the CORTEX header need
# ---------------------------------------------------------------------------
def doctor(host=DEFAULT_HOST, saved_model=""):
    """Status for the UI: the choice, the RAM headroom, and what to do next."""
    info = resolve(host, saved_model)
    ram = info["ram"] or {}
    advice = ""
    if not info["available"]:
        advice = info["reason"]
    elif not info["fits"]:
        advice = ("%s needs about %.1f GB, more than the %.1f GB free right now. "
                  "Close other apps, or pick a smaller installed model."
                  % (info["model"], info["needs_gb"], float(ram.get("available_gb") or 0)))
    info["advice"] = advice
    info["endpoint"] = info["host"]
    return info
