"""Beyond Registration Central AI — coordinator + specialist agent framework.

Enterprise-safe design: agents never emit SQL or free-form tool calls. Each
agent declares an autonomy ceiling and a fixed set of read-only context
gatherers plus a small catalogue of typed actions. Level 3 actions are never
executed inline — they create approval rows that an administrator must
decide. Every task, action and decision is written to the audit chain.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field


def _q(conn, sql, args=()):
    try:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]
    except Exception:
        return []


def _one(conn, sql, args=()):
    row = conn.execute(sql, args).fetchone()
    return dict(row) if row else {}


# ---------------------------------------------------------------- context ---

def ctx_executive(conn, perms):
    return {
        "employees": _one(conn, "SELECT COUNT(*) total, SUM(CASE WHEN employment_status='Active' THEN 1 ELSE 0 END) active FROM employees"),
        "leave_pending": _one(conn, "SELECT COUNT(*) n FROM leave_records WHERE status='Pending'")["n"],
        "payroll_records": _one(conn, "SELECT COUNT(*) n FROM payroll_records")["n"],
        "departments": _q(conn, "SELECT department, COUNT(*) n FROM employees WHERE employment_status='Active' AND department<>'' GROUP BY department ORDER BY n DESC LIMIT 10"),
    }


def ctx_hr(conn, perms):
    out = {"leave_pending": _q(conn, "SELECT l.id,l.leave_type,l.date_from,l.date_to,l.days,l.reason,e.first_name,e.last_name,e.employee_no FROM leave_records l JOIN employees e ON e.id=l.employee_id WHERE l.status='Pending' ORDER BY l.id DESC LIMIT 15")}
    if perms.allows("hr", "view"):
        out["hr_records"] = _q(conn, "SELECT record_type,title,status,created_at FROM hr_records ORDER BY id DESC LIMIT 10")
    if perms.allows("performance", "view"):
        out["reviews_due"] = _q(conn, "SELECT COUNT(*) n FROM performance_reviews WHERE status IN ('Scheduled','In progress')")["n"]
    return out


def ctx_payroll(conn, perms):
    out = {"recent": _q(conn, "SELECT p.id,p.pay_period,p.status,p.gross_pay,p.net_pay,e.first_name,e.last_name FROM payroll_records p JOIN employees e ON e.id=p.employee_id ORDER BY p.id DESC LIMIT 12")}
    out["draft_count"] = _one(conn, "SELECT COUNT(*) n FROM payroll_records WHERE status IN ('Draft','Drafted')")["n"]
    return out


def ctx_patients(conn, perms):
    if not perms.allows("patients", "view"):
        return {"restricted": "Patient care data requires an explicit permission grant."}
    return {
        "by_status": _q(conn, "SELECT status, COUNT(*) n FROM patients GROUP BY status"),
        "active_walks": _q(conn, "SELECT w.id,w.started_at,w.last_checkin_at,p.first_name,p.last_name,p.patient_number FROM patient_walks w JOIN patients p ON p.id=w.patient_id WHERE w.status='Active'"),
        "open_alerts": _q(conn, "SELECT a.id,a.event_type,a.created_at,p.first_name,p.last_name FROM patient_emergency_alerts a JOIN patients p ON p.id=a.patient_id WHERE a.status='Open' ORDER BY a.id DESC LIMIT 10"),
    }


def ctx_documents(conn, perms):
    out = {}
    if perms.allows("documents", "view"):
        out["employee_documents"] = _q(conn, "SELECT document_type,status,COUNT(*) n FROM employee_documents GROUP BY document_type,status LIMIT 20")
    if perms.allows("patients", "view"):
        out["patient_documents"] = _one(conn, "SELECT COUNT(*) n FROM patient_documents")["n"]
    return out


def ctx_attendance(conn, perms):
    return {
        "today": _q(conn, "SELECT COUNT(*) records, SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) present FROM attendance_daily WHERE work_date=date('now')"),
        "recent_anomalies": _q(conn, "SELECT employee_id,work_date,total_hours,status FROM attendance_daily WHERE total_hours>14 OR status LIKE '%Absent%' ORDER BY work_date DESC LIMIT 10"),
    }


def ctx_financial(conn, perms):
    if not perms.can_view_payroll():
        return {"restricted": "Payroll figures require payroll view permission."}
    return {
        "periods": _q(conn, "SELECT pay_period, COUNT(*) n, SUM(gross_pay) gross, SUM(net_pay) net FROM payroll_records WHERE status IN ('Approved','Sent','Paid') GROUP BY pay_period ORDER BY pay_period DESC LIMIT 12"),
        "employer_uif_ytd": _one(conn, "SELECT COALESCE(SUM(employer_uif),0) v FROM payroll_records WHERE substr(pay_period,1,4)=strftime('%Y','now') AND status IN ('Approved','Sent','Paid')"),
    }


def ctx_security(conn, perms):
    return {
        "audit_entries": _one(conn, "SELECT COUNT(*) n FROM audit_log")["n"],
        "open_patient_alerts": _one(conn, "SELECT COUNT(*) n FROM patient_emergency_alerts WHERE status='Open'")["n"],
        "admins": _q(conn, "SELECT username,role,active,created_at FROM admins ORDER BY id"),
    }


def ctx_documents_ai(conn, perms):
    return ctx_documents(conn, perms)


def ctx_maintenance(conn, perms):
    return {"note": "Application maintenance actions are staged for administrator review; agents cannot self-modify."}


def ctx_ddns(conn, perms):
    import os
    last_ip = ""
    last_update = ""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools", "ddns_last_ip.txt")
        # Actually the file is in tools/, not desktop/
        p = r"C:\NEXUS\tools\ddns_last_ip.txt"
        if os.path.exists(p):
            last_ip = open(p).read().strip()
    except Exception:
        pass
    try:
        logp = r"C:\NEXUS\tools\ddns.log"
        if os.path.exists(logp):
            lines = open(logp).read().strip().splitlines()
            last_update = lines[-1] if lines else ""
    except Exception:
        pass
    # Current WAN IP
    current_ip = ""
    try:
        import urllib.request
        with urllib.request.urlopen("https://api.ipify.org", timeout=8) as r:
            current_ip = r.read().decode().strip()
    except Exception:
        current_ip = "unavailable"
    return {
        "hostname": "your-userd-dean.duckdns.org",
        "current_wan_ip": current_ip,
        "last_recorded_ip": last_ip or "(never updated)",
        "ip_changed": (current_ip != last_ip) if (current_ip and last_ip) else "unknown",
        "last_log_line": last_update or "(no log yet)",
    }


def ctx_evolv3(conn, perms):
    try:
        import academy
        cards = conn.execute("SELECT COUNT(*) n FROM academy_cards WHERE active=1").fetchone()["n"]
        quizzes = conn.execute("SELECT COUNT(*) n FROM academy_quiz_bank WHERE active=1").fetchone()["n"]
        ratings = conn.execute("SELECT COUNT(*) n FROM academy_card_ratings").fetchone()["n"]
        runs = conn.execute("SELECT COUNT(*) n FROM academy_evolutions").fetchone()["n"]
        last = conn.execute("SELECT status, generated_cards, generated_quizzes, started_at FROM academy_evolutions ORDER BY id DESC LIMIT 1").fetchone()
        return {"cards": cards, "quizzes": quizzes, "ratings": ratings, "evolution_runs": runs,
                "last_run": dict(last) if last else None}
    except Exception:
        return {"note": "EVOLV3 tables not available yet."}


# ----------------------------------------------------------------- agents ---

@dataclass(frozen=True)
class AgentSpec:
    key: str
    name: str
    domain: str
    description: str
    module: str
    action: str
    keywords: tuple
    gather: object
    max_level: int = 1


AGENTS = [
    AgentSpec("hr", "HR Agent", "People & Culture",
              "Leave, HR records, performance and employee relations.", "hr", "view",
              ("leave", "hr ", "human resources", "performance", "review", "grievance", "onboard"), ctx_hr),
    AgentSpec("payroll", "Payroll Agent", "Compensation",
              "Payroll records, calculations, deductions and payslip delivery.", "payroll", "view",
              ("payroll", "payslip", "salary", "wage", "uif", "deduction", "net pay", "gross"), ctx_payroll, max_level=3),
    AgentSpec("patients", "Patient Care Agent", "Clinical",
              "Patient records, walks, emergency alerts and caregiver assignments.", "patients", "view",
              ("patient", "caregiver", "walk", "emergency alert", "sos", "vitals", "wheelchair"), ctx_patients),
    AgentSpec("executive", "Executive Agent", "Strategy",
              "Cross-module summaries and workforce insights.", "reports_audit", "view",
              ("overview", "summary", "dashboard", "insight", "report", "how are we", "kpi"), ctx_executive),
    AgentSpec("medical_records", "Medical Records Agent", "Clinical",
              "Patient documents and medical record metadata.", "patients", "view",
              ("medical record", "patient document", "clinical", "diagnosis", "prescription"), ctx_documents_ai),
    AgentSpec("rostering", "Rostering Agent", "Operations",
              "Attendance patterns, shift coverage and scheduling anomalies.", "attendance", "view",
              ("roster", "shift", "schedule", "attendance", "overtime", "late", "hours"), ctx_attendance),
    AgentSpec("financial", "Financial Agent", "Finance",
              "Payroll spend, UIF liabilities and period-over-period totals.", "payroll", "view",
              ("financial", "budget", "cost", "spend", "uif liability", "accounting", "expense"), ctx_financial),
    AgentSpec("contractor", "Contractor Agent", "Procurement",
              "Contract status, document expiry and supplier-related records.", "documents", "view",
              ("contract", "contractor", "supplier", "vendor", "renewal", "expiry"), ctx_documents),
    AgentSpec("documents_ai", "Document Intelligence Agent", "Knowledge",
              "Document inventory, expiry tracking and record completeness.", "documents", "view",
              ("document", "file", "expiry", "missing record", "completeness", "archive"), ctx_documents_ai),
    AgentSpec("maintenance", "App Maintenance Agent", "Platform",
              "System health, staged upgrades and self-service limits.", "integrations", "view",
              ("upgrade", "maintenance", "system health", "backup", "version", "patch", "script"), ctx_maintenance),
    AgentSpec("security", "Security & Compliance Agent", "Governance",
              "Audit trail, access review and compliance posture.", "reports_audit", "view",
              ("security", "compliance", "audit", "access", "permission", "breach", "popia"), ctx_security),
    AgentSpec("ddns", "Network / DDNS Agent", "Infrastructure",
              "Dynamic DNS, WAN IP tracking, tunnel endpoint and DuckDNS updates.", "integrations", "view",
              ("ddns", "dns", "ip", "tunnel", "duckdns", "hostname", "endpoint", "network", "wan", "public ip", "your-userd-dean"), ctx_ddns, max_level=2),
    AgentSpec("evolv3", "EVOLV3 Skills Agent", "Learning",
              "Self-evolving skills department: fact cards, emergency cards and quizzes that grow from staff ratings.", "academy", "view",
              ("evolv3", "academy", "skills", "fact card", "emergency card", "quiz", "rating", "evolve", "self improve"), ctx_evolv3, max_level=2),
]

BY_KEY = {a.key: a for a in AGENTS}

# Typed actions agents may request. Executors are injected by the backend so
# this module never imports the HTTP layer.
ACTION_LEVELS = {"hub_message": 3, "payroll_preview": 2, "ddns_update": 2}

_INTENT_RE = re.compile(r"\b(send|deliver|message|notify|pay|delete|approve|post|submit|issue|create|schedule)\b", re.I)


class Coordinator:
    def __init__(self, store, llm, permissions_for, log=None, executors=None):
        self.store = store
        self.llm = llm
        self.permissions_for = permissions_for
        self.log = log or (lambda *a, **k: None)
        self.executors = executors or {}
        self._schema()

    # ------------------------------------------------------------- schema --
    def _schema(self):
        self.store.conn.executescript("""
        CREATE TABLE IF NOT EXISTS ai_tasks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            agent TEXT NOT NULL,
            prompt TEXT NOT NULL,
            status TEXT NOT NULL,
            reply TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ai_actions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            agent TEXT NOT NULL,
            action_type TEXT NOT NULL,
            autonomy_level INTEGER NOT NULL,
            payload_json TEXT NOT NULL DEFAULT '{}',
            status TEXT NOT NULL DEFAULT 'pending_approval',
            created_at TEXT NOT NULL,
            decided_by TEXT DEFAULT '',
            decided_at TEXT DEFAULT '',
            result_json TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS ai_memory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            kind TEXT NOT NULL DEFAULT 'note',
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        self.store.conn.commit()

    # ------------------------------------------------------------ helpers --
    def _iso(self):
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")

    @staticmethod
    def _jsonable(value, depth=0):
        if depth > 4:
            return str(value)[:200]
        if isinstance(value, dict):
            return {str(k): Coordinator._jsonable(v, depth + 1) for k, v in list(value.items())[:40]}
        if isinstance(value, (list, tuple)):
            return [Coordinator._jsonable(v, depth + 1) for v in value[:40]]
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        return str(value)[:200]

    def route(self, prompt: str) -> AgentSpec:
        text = (prompt or "").lower()
        best, score = BY_KEY["executive"], 0
        for agent in AGENTS:
            s = sum(1 for k in agent.keywords if k in text)
            if s > score:
                best, score = agent, s
        return best

    # -------------------------------------------------------------- chat ---
    def chat(self, actor: str, prompt: str, history=None):
        prompt = (prompt or "").strip()
        if not prompt:
            raise ValueError("Enter a question for the copilot first.")
        perms = self.permissions_for(actor)
        agent = self.route(prompt)
        stamp = self._iso()

        # Data isolation: agents only see modules the actor may read.
        context = {}
        if perms.allows(agent.module, agent.action):
            try:
                context = agent.gather(self.store.conn, perms)
            except Exception as exc:
                context = {"error": f"{type(exc).__name__}: context unavailable"}
        else:
            context = {"restricted": f"Your role cannot view {agent.domain} data."}

        task_id = self._record_task(actor, agent.key, prompt, "working", "", stamp)

        # Action detection → typed action request (never free-form execution).
        pending = None
        action_type = self._detect_action(prompt, agent)
        payload = self._build_payload(action_type, prompt, agent, actor) if action_type else None
        if action_type and payload is None:
            action_type = None  # unresolvable target — answer as a read-only question
        if action_type:
            level = ACTION_LEVELS[action_type]
            if level > agent.max_level:
                reply = (f"{agent.name} cannot perform '{action_type}' — it exceeds this agent's autonomy ceiling "
                         f"(level {agent.max_level}). An administrator must perform it directly.")
                self._finish_task(task_id, "refused", reply, stamp)
                self._record_action(task_id, agent.key, action_type, level, {}, "refused", actor, stamp)
                return {"reply": reply, "agent": agent.name, "agent_key": agent.key, "task_id": task_id}
            if level >= 3:
                aid = self._record_action(task_id, agent.key, action_type, level, payload, "pending_approval", actor, stamp)
                reply = (f"{agent.name} prepared a Level {level} action and is requesting approval.\n\n"
                         f"Action: {action_type}\nSummary: {payload.get('summary','')}\n\n"
                         f"Nothing has been executed. An administrator can approve or reject request #{aid}.")
                self._finish_task(task_id, "awaiting_approval", reply, stamp)
                self.log(actor, f"AI {agent.key} requested approval", "ai_action", str(aid), action_type)
                return {"reply": reply, "agent": agent.name, "agent_key": agent.key, "task_id": task_id,
                        "pending_approval": {"id": aid, "action": action_type, "summary": payload.get("summary", "")}}
            # Level 2: prepare only — return the draft, do not execute.
            draft = payload
            reply = (f"{agent.name} prepared a draft (autonomy level 2 — preparation only, nothing saved):\n\n"
                     f"{draft.get('summary','')}\n\nReview it and confirm before any record is changed.")
            self._record_action(task_id, agent.key, action_type, level, draft, "draft", actor, stamp)
            self._finish_task(task_id, "draft", reply, stamp)
            return {"reply": reply, "agent": agent.name, "agent_key": agent.key, "task_id": task_id}

        reply = self._summarize(agent, prompt, context, actor)
        self._finish_task(task_id, "complete", reply, stamp)
        return {"reply": reply, "agent": agent.name, "agent_key": agent.key, "task_id": task_id}

    # ------------------------------------------------------------ actions --
    def _detect_action(self, prompt, agent):
        text = prompt.lower()
        if not _INTENT_RE.search(text):
            return None
        if agent.key == "payroll" and re.search(r"\b(send|deliver|issue)\b.*\b(payslip|payslips|salary|payroll)\b|\b(payslip|payslips)\b.*\b(send|deliver|issue)\b", text):
            return "hub_message"
        if re.search(r"\b(send|message|notify)\b", text) and agent.key in ("hr", "executive", "payroll"):
            return "hub_message"
        if agent.key == "payroll" and re.search(r"\b(calculate|compute|preview|what if|draft)\b", text):
            return "payroll_preview"
        if agent.key == "ddns" and re.search(r"\b(update|refresh|sync|force)\b", text):
            return "ddns_update"
        return None

    def _build_payload(self, action_type, prompt, agent, actor):
        if action_type == "hub_message":
            # Resolve a concrete recipient: payroll id, employee id/number, or department.
            payload = {"kind": "message", "requested_by": actor, "subject": "", "body": ""}
            text = prompt
            ids = [int(n) for n in re.findall(r"\b\d{1,6}\b", text)]
            payroll_id = None
            for n in ids:
                if _one(self.store.conn, "SELECT id FROM payroll_records WHERE id=?", (n,)):
                    payroll_id = n
                    break
            employee_id = None
            for n in ids:
                row = _one(self.store.conn, "SELECT id FROM employees WHERE id=?", (n,))
                if not row:
                    row = _one(self.store.conn, "SELECT id FROM employees WHERE employee_no=?", (str(n),))
                if row:
                    employee_id = int(row["id"])
                    break
            department = None
            m = re.search(r"\bdepartment[:\s]+([A-Za-z &'-]{2,40})", text, re.I)
            if m:
                department = m.group(1).strip()
            if payroll_id:
                prow = _one(self.store.conn, "SELECT p.pay_period,e.id AS employee_id,e.first_name,e.last_name FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE p.id=?", (payroll_id,))
                if prow:
                    employee_id = prow["employee_id"]
                    payload["payroll_id"] = payroll_id
                    payload["subject"] = f"Payslip — {prow.get('pay_period','')}"
                    payload["body"] = (f"Good day,\n\nPlease find your payslip for {prow.get('pay_period','this period')} attached.\n\n"
                                       f"Regards,\nBeyond Registration")
                    payload["summary"] = f"Deliver payslip {payroll_id} ({prow.get('pay_period','')}) to {prow.get('first_name','')} {prow.get('last_name','')} via Communication Hub"
                    return payload
            if employee_id:
                erow = _one(self.store.conn, "SELECT first_name,last_name,department FROM employees WHERE id=?", (employee_id,))
                if erow:
                    payload["employee_id"] = employee_id
                    payload["subject"] = "Message from Beyond Registration"
                    payload["body"] = f"{prompt[:1500]}"
                    payload["summary"] = f"Send internal message to {erow.get('first_name','')} {erow.get('last_name','')} (employee {employee_id})"
                    return payload
            if department:
                payload["department"] = department
                payload["subject"] = "Message from Beyond Registration"
                payload["body"] = f"{prompt[:1500]}"
                payload["summary"] = f"Send internal message to department '{department}'"
                return payload
            return None  # no resolvable recipient — do not create an approval
        if action_type == "payroll_preview":
            return {"summary": f"Payroll calculation preview requested: \"{prompt[:160]}\"",
                    "kind": "preview", "requested_by": actor}
        if action_type == "ddns_update":
            return {"summary": "Update DuckDNS (your-userd-dean.duckdns.org) to the current WAN IP.",
                    "kind": "ddns_update", "requested_by": actor}
        return {"summary": prompt[:200], "requested_by": actor}

    # -------------------------------------------------------------- LLM ----
    def _summarize(self, agent, prompt, context, actor):
        safe_context = self._jsonable(context)
        llm_prompt = (
            f"You are {agent.name} ({agent.domain}) inside Beyond Registration, a local HR/business system. "
            f"Answer the user's question using ONLY the JSON context provided. Be concise, factual, and "
            f"mention when data is restricted or missing. Do not invent records.\n\n"
            f"USER: {prompt}\n\nCONTEXT JSON:\n{json.dumps(safe_context, ensure_ascii=False)[:12000]}"
        )
        try:
            # history lets the local model see the prior turns of the same thread,
            # so the drawer and the CORTEX page answer follow-ups consistently.
            try:
                result = self.llm(llm_prompt, actor, history)
            except TypeError:
                # A caller wired with a two-argument llm still works.
                result = self.llm(llm_prompt, actor)
            reply = (result or {}).get("reply") if isinstance(result, dict) else str(result or "")
            if reply and reply.strip():
                return reply.strip()
        except Exception:
            pass
        return self._fallback(agent, context)

    def _fallback(self, agent, context):
        lines = [f"{agent.name} here — the local AI model is offline, so here is a direct data summary:", ""]
        if isinstance(context, dict):
            if "restricted" in context:
                lines.append(context["restricted"])
            else:
                for key, value in context.items():
                    if isinstance(value, list):
                        lines.append(f"- {key.replace('_',' ')}: {len(value)} record(s)")
                    elif isinstance(value, dict):
                        lines.append(f"- {key.replace('_',' ')}: {json.dumps(value, ensure_ascii=False)[:300]}")
                    else:
                        lines.append(f"- {key}: {value}")
        return "\n".join(lines) or "No data available for this area."

    # ----------------------------------------------------------- records ---
    def _record_task(self, actor, agent, prompt, status, reply, stamp):
        cur = self.store.conn.execute(
            "INSERT INTO ai_tasks(actor,agent,prompt,status,reply,created_at) VALUES(?,?,?,?,?,?)",
            (actor, agent, prompt[:4000], status, reply, stamp))
        self.store.conn.commit()
        return int(cur.lastrowid)

    def _finish_task(self, task_id, status, reply, stamp):
        self.store.conn.execute("UPDATE ai_tasks SET status=?,reply=? WHERE id=?", (status, reply[:20000], task_id))
        self.store.conn.commit()

    def _record_action(self, task_id, agent, action_type, level, payload, status, actor, stamp):
        cur = self.store.conn.execute(
            "INSERT INTO ai_actions(task_id,agent,action_type,autonomy_level,payload_json,status,created_at) VALUES(?,?,?,?,?,?,?)",
            (task_id, agent, action_type, level, json.dumps(payload, ensure_ascii=False), status, stamp))
        self.store.conn.commit()
        return int(cur.lastrowid)

    # ---------------------------------------------------------- queries ----
    def agents(self):
        return [{"key": a.key, "name": a.name, "domain": a.domain, "description": a.description,
                 "autonomy_ceiling": a.max_level} for a in AGENTS]

    def tasks(self, limit=100):
        return _q(self.store.conn, "SELECT * FROM ai_tasks ORDER BY id DESC LIMIT ?", (int(limit),))

    def approvals(self):
        return _q(self.store.conn, "SELECT * FROM ai_actions WHERE status='pending_approval' ORDER BY id")

    def action_history(self, limit=200):
        return _q(self.store.conn, "SELECT * FROM ai_actions ORDER BY id DESC LIMIT ?", (int(limit),))

    def decide(self, action_id, approve, actor):
        row = _one(self.store.conn, "SELECT * FROM ai_actions WHERE id=?", (int(action_id),))
        if not row:
            raise KeyError("Approval request not found.")
        if row["status"] != "pending_approval":
            raise ValueError("This request has already been decided.")
        stamp = self._iso()
        if not approve:
            self.store.conn.execute("UPDATE ai_actions SET status='rejected',decided_by=?,decided_at=? WHERE id=?",
                                    (actor, stamp, int(action_id)))
            self.store.conn.commit()
            self.log(actor, "Rejected AI action", "ai_action", str(action_id), row["action_type"])
            return {"ok": True, "status": "rejected"}
        executor = self.executors.get(row["action_type"])
        if executor is None:
            self.store.conn.execute("UPDATE ai_actions SET status='failed',decided_by=?,decided_at=?,result_json=? WHERE id=?",
                                    (actor, stamp, json.dumps({"error": "No executor registered for this action."}), int(action_id)))
            self.store.conn.commit()
            raise RuntimeError("No executor is registered for this action type.")
        try:
            payload = json.loads(row["payload_json"] or "{}")
            result = executor(payload, actor)
        except Exception as exc:
            self.store.conn.execute("UPDATE ai_actions SET status='failed',decided_by=?,decided_at=?,result_json=? WHERE id=?",
                                    (actor, stamp, json.dumps({"error": str(exc)[:500]}), int(action_id)))
            self.store.conn.commit()
            self.log(actor, "AI action execution failed", "ai_action", str(action_id), f"{row['action_type']}: {exc}")
            raise
        self.store.conn.execute("UPDATE ai_actions SET status='executed',decided_by=?,decided_at=?,result_json=? WHERE id=?",
                                (actor, stamp, json.dumps(self._jsonable(result))[:8000], int(action_id)))
        self.store.conn.commit()
        self.log(actor, "Approved and executed AI action", "ai_action", str(action_id), row["action_type"])
        return {"ok": True, "status": "executed", "result": result}

    # ------------------------------------------------------------ memory ---
    def memory(self, actor, limit=200):
        return _q(self.store.conn, "SELECT * FROM ai_memory WHERE actor=? ORDER BY id DESC LIMIT ?", (actor, int(limit)))

    def remember(self, actor, kind, content):
        content = (content or "").strip()
        if not content:
            raise ValueError("Memory content is required.")
        cur = self.store.conn.execute("INSERT INTO ai_memory(actor,kind,content,created_at) VALUES(?,?,?,?)",
                                      (actor, (kind or "note")[:40], content[:4000], self._iso()))
        self.store.conn.commit()
        self.log(actor, "Stored AI memory", "ai_memory", str(int(cur.lastrowid)), kind or "note")
        return {"id": int(cur.lastrowid)}

    def forget(self, memory_id, actor):
        cur = self.store.conn.execute("DELETE FROM ai_memory WHERE id=?", (int(memory_id),))
        self.store.conn.commit()
        if cur.rowcount:
            self.log(actor, "Deleted AI memory", "ai_memory", str(memory_id), "")
        return {"ok": True}

    # ------------------------------------------------------------ health ---
    def health(self):
        out = {"agents": len(AGENTS), "pending_approvals": len(self.approvals()),
               "tasks": _one(self.store.conn, "SELECT COUNT(*) n FROM ai_tasks")["n"],
               "memory_entries": _one(self.store.conn, "SELECT COUNT(*) n FROM ai_memory")["n"],
               "database": "ok"}
        try:
            out["database"] = self.store.conn.execute("PRAGMA quick_check").fetchone()[0]
        except Exception:
            out["database"] = "error"
        out["ollama"] = self._ollama_health()
        return out

    @staticmethod
    def _ollama_health():
        import os, urllib.request
        host = os.environ.get("OLLAMA_HOST", "").strip() or "http://127.0.0.1:11434"
        try:
            with urllib.request.urlopen(host.rstrip("/") + "/api/tags", timeout=3) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
            models = [m.get("name", "") for m in data.get("models", [])]
            return {"reachable": True, "models": models[:10]}
        except Exception:
            return {"reachable": False, "models": []}
