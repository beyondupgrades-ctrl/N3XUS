﻿// icons.js - inline SVG corporate icon set (1.75px stroke, offline, no CDN)
const icons = {
 video:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-7h-4v7H4a1 1 0 0 1-1-1z"/>',
 close:'<path d="m18 6-12 12M6 6l12 12"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
 briefcase:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
 'book-open':'<path d="M12 7v14M3 7h5a4 4 0 0 1 4 4v10a4 4 0 0 0-4-4H3z"/><path d="M21 7h-5a4 4 0 0 0-4 4v10a4 4 0 0 1 4-4h5z"/>',
 folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
 target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
 wallet:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18M16 14h2M7 5V3h10v2"/>',
 sparkles:'<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
 moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
 chart:'<path d="M4 19V5M4 19h17"/><rect x="7" y="11" width="3" height="6" rx="1"/><rect x="13" y="7" width="3" height="10" rx="1"/><rect x="19" y="3" width="3" height="14" rx="1"/>',
 message:'<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5z"/><path d="M8 12h8M8 8h5"/>' , activity:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',shield:'<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"/><path d="m9 12 2 2 4-4"/>',
 settings:'<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a8 8 0 0 1-1.7 1l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.7-1l-1.7.6-1.4-2.4 1.4-1.1a7 7 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.7.6a8 8 0 0 1 1.7-1L13 7.3h2.8l.3 1.8a8 8 0 0 1 1.7 1l1.7-.6 1.4 2.4-1.4 1.1a7 7 0 0 1-.1 2z" transform="translate(-1 -1)"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
 menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',chevron:'<path d="m9 18 6-6-6-6"/>',logout:'<path d="M10 17l5-5-5-5M15 12H3M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/>',
 edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/>',eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
 trash:'<path d="M3 6h18M8 6V4h8v2m3 0-1 15H6L5 6m4 4v7m6-7v7"/>',refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.5 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.5-3"/>',
 paper:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
 paperclip:'<path d="m21.4 11.1-8.5 8.5a5.5 5.5 0 0 1-7.8-7.8l9.2-9.2a3.7 3.7 0 0 1 5.2 5.2l-9.2 9.2a1.9 1.9 0 0 1-2.6-2.6l8.5-8.5"/>',
 send:'<path d="m22 2-7 20-4-9-9-4 20-7Z"/><path d="M22 2 11 13"/>',
 mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"/>',
 phone:'<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2z"/>',
 box:'<path d="m21 8-9-5-9 5v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
 map:'<path d="m9 4-6 2v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
 heart:'<path d="M20.8 4.6a5.6 5.6 0 0 0-7.9 0L12 5.7l-.9-1.1a5.6 5.6 0 1 0-7.9 7.8l.9 1L12 21l7.9-7.6.9-1a5.6 5.6 0 0 0 0-7.8z"/>',
 alert:'<path d="M10.3 3.6 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.6a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
 book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4a2 2 0 0 0-2-2H6.5A2.5 2.5 0 0 0 4 4.5z"/><path d="M8 7h8M8 11h8"/>',
 trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 5H4v2a3 3 0 0 0 3 3M17 5h3v2a3 3 0 0 1-3 3"/>',
 pin:'<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
 check:'<path d="m20 6-11 11-5-5"/>',
 contract:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
 play:'<path d="m7 4 13 8-13 8z"/>',
 stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 1 1 5.4 2c-.9.6-2.5 1.5-2.5 3"/><path d="M12 17h.01"/>',
 lightbulb:'<path d="M9 18h6M10 22h4M12 2a6 6 0 0 0-3.5 10.9c.6.5 1 1.3 1 2.1h5c0-.8.4-1.6 1-2.1A6 6 0 0 0 12 2z"/>',
 clipboard:'<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M8 12h8M8 16h5"/>',
 hospital:'<path d="M3 21h18M5 21V7l7-4 7 4v14"/><path d="M12 9v6M9 12h6"/>',
 cash:'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 10v4M18 10v4"/>',
};
/* Legacy glyphs already used in shipped copy are mapped to the same inline SVG
   set, so no emoji or symbol font is needed to render the interface. */
const emojiIcons = {
 '⌂':'home','▣':'calendar','▤':'book','▧':'folder','◉':'eye','●':'activity','■':'stop','▶':'play','§':'contract','✦':'sparkles',
 '✓':'check','⚠':'alert','✉':'message','♥':'heart','⚙':'settings','❓':'help',
 '💡':'lightbulb','🚨':'alert','🏆':'trophy','📚':'book','📅':'calendar','💰':'cash','📁':'folder','📋':'clipboard','📦':'box',
 '🗺':'map','🏥':'hospital','💬':'message','📞':'phone',
 '🧠':'sparkles','🩹':'shield','⚡':'activity','❤':'heart','🌇':'sparkles','🫂':'users','🫁':'activity','🔥':'sparkles',
 '☠':'alert','🍬':'sparkles','🌱':'sparkles','🧩':'grid','📻':'bell','🔁':'refresh','🗣':'message','🤝':'users','☕':'clock',
 '💧':'activity','☀':'sparkles','👓':'eye','🚪':'home','🎵':'sparkles','🧼':'shield','🍽':'home','💊':'shield','🚗':'map',
 '🏦':'cash','⚖':'file','📝':'edit','🏛':'shield','🛡':'shield','🫀':'heart','🩸':'activity','🦴':'activity','🤕':'heart',
 '🚒':'alert','🛑':'alert','🔎':'search','💔':'heart','🐝':'alert','🌡':'activity','🔌':'activity','🥤':'activity'
};
const miAliases = {
 patients:'hospital',care:'heart',tracker:'map',vitals:'activity',messages:'message',voic3:'message',
 approvals:'check',contracts:'contract',ops:'activity',academy:'book',stock:'box',vault:'folder',
 payslips:'cash',leave:'calendar',settings:'settings',sos:'alert',home:'home',certificates:'trophy'
};
function iconName(v){
  if(!v)return '';
  var s=String(v);
  if(icons[s])return s;
  var first=Array.from(s)[0];
  return emojiIcons[first]||miAliases[s.toLowerCase()]||'';
}
function mi(v,cls=''){
  var n=iconName(v)||'sparkles';
  return '<svg class="mi '+cls+'" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+icons[n]+'</svg>';
}
function icon(n, cls=''){return `<svg class="ico ${cls}" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[n]||icons.file}</svg>`}

/* Hydrate static [data-icon] placeholders (nav, topbar, search) with inline SVGs. */
(function hydrateDataIcons(){
  if(typeof document==='undefined')return;
  function paint(){
    document.querySelectorAll('[data-icon]').forEach(function(el){
      if(el.querySelector('svg'))return;
      var raw=el.getAttribute('data-icon');
      var name=(typeof icons!=='undefined'&&icons[raw])?raw
        :(raw==='more'?'menu':raw==='file-check'?'file':raw==='shield-check'?'shield':(iconName(raw)||'file'));
      el.innerHTML='<svg class="ico" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+icons[name]+'</svg>';
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',paint);else paint();
})();
