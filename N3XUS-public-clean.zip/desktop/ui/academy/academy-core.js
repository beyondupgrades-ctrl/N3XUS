/* ============================================================
   EVOLV3 Academy — core state, persistence, voice and sync.
   ============================================================ */
(function () {
  'use strict';
  const D = window.ACADEMY_DATA;

  // ---------------------------------------------------------- utilities
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const nf = (n) => new Intl.NumberFormat('en-ZA').format(Math.round(Number(n) || 0));
  const todayISO = () => new Date().toISOString().slice(0, 10);
  const nowISO = () => new Date().toISOString();
  const longDate = (iso) => {
    const d = new Date(String(iso || '').length > 10 ? iso : String(iso || '') + 'T12:00:00');
    return isNaN(d) ? '—' : d.toLocaleDateString('en-ZA', { day: '2-digit', month: 'long', year: 'numeric' });
  };
  const shortDate = (iso) => {
    const d = new Date(String(iso || '').length > 10 ? iso : String(iso || '') + 'T12:00:00');
    return isNaN(d) ? '—' : d.toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' });
  };
  const timeAgo = (iso) => {
    const d = new Date(iso);
    if (isNaN(d)) return '—';
    const mins = Math.round((Date.now() - d.getTime()) / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' min ago';
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return hrs + ' h ago';
    return Math.round(hrs / 24) + ' d ago';
  };
  const hoursLabel = (mins) => {
    const m = Math.max(0, Math.round(Number(mins) || 0));
    return Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm';
  };
  const pct = (a, b) => (Number(b) ? Math.round((Number(a) / Number(b)) * 100) : 0);

  async function api(path, method, body) {
    const opt = { method: method || 'GET', headers: { Accept: 'application/json' }, credentials: 'same-origin' };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    const res = await fetch(path, opt);
    let data = {};
    try { data = await res.json(); } catch (e) { data = {}; }
    if (!res.ok) {
      const err = new Error(data.error || ('Request failed (' + res.status + ')'));
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function toast(message, kind) {
    const root = $('#toast-root');
    if (!root) return;
    const el = document.createElement('div');
    el.className = 'toast' + (kind ? ' ' + kind : '');
    el.textContent = String(message || '');
    root.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 220);
    }, kind === 'evolve' ? 6200 : 3600);
  }

  async function copyText(text) {
    const value = String(text || '');
    try {
      if (navigator.clipboard && window.isSecureContext !== false) {
        await navigator.clipboard.writeText(value);
        return true;
      }
    } catch (e) { /* fall through */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = value;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch (e) { return false; }
  }

  function download(name, text, mime) {
    const blob = new Blob([String(text || '')], { type: mime || 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  // ---------------------------------------------------------- learner state
  const LEARNER_KEY = 'evolv3:v2:learner';
  const THEME_KEY = 'evolv3:theme';

  function defaultLearner() {
    return {
      displayName: '',
      role: 'Caregiver',
      minutesStudied: 96,
      points: 1120,
      enrolled: [],
      completions: {},
      attempts: [],
      badges: [],
      studyDates: [todayISO()],
      streak: 1,
      generatedEvals: [],
      lastResult: null,
      diplomaIssuedAt: '',
      updatedAt: nowISO()
    };
  }

  function normalizeLearner(raw) {
    const base = defaultLearner();
    if (!raw || typeof raw !== 'object') return base;
    const out = Object.assign(base, raw);
    out.minutesStudied = Math.max(0, Number(out.minutesStudied) || 0);
    out.points = Math.max(0, Number(out.points) || 0);
    out.role = ['Caregiver', 'Clinical Staff', 'Family', 'Public'].includes(out.role) ? out.role : 'Caregiver';
    out.enrolled = Array.isArray(out.enrolled) ? out.enrolled.filter((x) => typeof x === 'string') : [];
    out.completions = out.completions && typeof out.completions === 'object' && !Array.isArray(out.completions) ? out.completions : {};
    out.attempts = Array.isArray(out.attempts) ? out.attempts.filter((x) => x && typeof x === 'object') : [];
    out.badges = Array.isArray(out.badges) ? out.badges : [];
    out.studyDates = Array.isArray(out.studyDates) ? out.studyDates.filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(String(x))) : [];
    out.generatedEvals = Array.isArray(out.generatedEvals) ? out.generatedEvals.slice(-60) : [];
    out.streak = Math.max(1, Number(out.streak) || 1);
    return out;
  }

  function migrateLegacy() {
    try {
      if (localStorage.getItem(LEARNER_KEY)) return null;
      const keys = ['evolv3:state', 'evolv3AcademyState', 'your-userd-academy-progress', 'evolv3_progress'];
      for (const key of keys) {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        let parsed = null;
        try { parsed = JSON.parse(raw); } catch (e) { continue; }
        if (!parsed || typeof parsed !== 'object') continue;
        const migrated = normalizeLearner({
          displayName: parsed.displayName || parsed.name || parsed.username || '',
          role: parsed.role,
          minutesStudied: parsed.minutesStudied != null ? parsed.minutesStudied : parsed.minutes,
          points: parsed.points != null ? parsed.points : parsed.xp,
          enrolled: parsed.enrolled,
          completions: parsed.completions || parsed.completed,
          attempts: parsed.attempts,
          streak: parsed.streak,
          studyDates: parsed.studyDates
        });
        localStorage.setItem(LEARNER_KEY, JSON.stringify(migrated));
        return migrated;
      }
    } catch (e) { /* storage unavailable */ }
    return null;
  }

  function mergeLearners(local, server) {
    if (!server) return normalizeLearner(local);
    if (!local) return normalizeLearner(server);
    const a = normalizeLearner(local);
    const b = normalizeLearner(server);
    const merged = Object.assign({}, a, b);
    merged.minutesStudied = Math.max(a.minutesStudied, b.minutesStudied);
    merged.points = Math.max(a.points, b.points);
    merged.enrolled = Array.from(new Set([].concat(a.enrolled, b.enrolled)));
    merged.completions = Object.assign({}, a.completions, b.completions);
    const seen = new Set();
    merged.attempts = [].concat(a.attempts, b.attempts).filter((x) => {
      const key = String(x.id || '') + '|' + String(x.date || '') + '|' + String(x.score || '');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(-400);
    merged.studyDates = Array.from(new Set([].concat(a.studyDates, b.studyDates))).sort().slice(-400);
    merged.generatedEvals = [].concat(a.generatedEvals, b.generatedEvals).slice(-60);
    merged.displayName = b.displayName || a.displayName || '';
    merged.role = b.role || a.role || 'Caregiver';
    merged.lastResult = b.lastResult || a.lastResult || null;
    merged.streak = Math.max(a.streak, b.streak);
    merged.updatedAt = nowISO();
    return merged;
  }

  function recomputeStreak(L) {
    const days = new Set(L.studyDates || []);
    days.add(todayISO());
    let streak = 0;
    const cursor = new Date();
    for (let i = 0; i < 400; i++) {
      const iso = cursor.toISOString().slice(0, 10);
      if (days.has(iso)) {
        streak++;
        cursor.setDate(cursor.getDate() - 1);
      } else if (i === 0) {
        cursor.setDate(cursor.getDate() - 1);
      } else {
        break;
      }
    }
    L.streak = Math.max(1, streak);
    L.studyDates = Array.from(days).sort().slice(-400);
    return L.streak;
  }

  // ---------------------------------------------------------- state
  const S = {
    tab: 'courses',
    courseQuery: '',
    courseCategory: 'All',
    protocolQuery: '',
    protocolCategory: '',
    protocolUrgency: '',
    evalKind: 'short',
    evalModule: '',
    evalAnswers: {},
    quizPicks: {},
    lastResult: null,
    learner: normalizeLearner(migrateLegacy() || defaultLearner()),
    bootUser: null,
    weeklyModules: [],
    weeklyEvals: [],
    weeklyProtocols: [],
    evolutionState: { version: '2.0.0', weekNumber: 1, lastEvolvedAt: nowISO(), autoUpdateOnWifi: true, changelog: [] },
    nextRunAt: '',
    leaderboard: [],
    employees: [],
    conn: 'online',
    evolving: false,
    booted: false,
    adminPeriod: 'daily',
    adminQuery: '',
    adminRole: '',
    leaderRole: '',
    auditStaff: null,
    certKind: 'diploma',
    certFace: 'front',
    speech: { active: false, id: '' },
    saveTimer: 0,
    timerId: 0,
    schedulerId: 0
  };

  // ---------------------------------------------------------- courses merge
  function allCourses() {
    const base = D.COURSES.map((c) => Object.assign({}, c, { isNewAutonomous: false }));
    const weekly = (S.weeklyModules || []).map((m) => Object.assign({}, m, {
      n: 100 + Number(m.weekAdded || 0),
      isNewAutonomous: true,
      description: m.description || '',
      highlights: Array.isArray(m.highlights) ? m.highlights : [],
      hazards: Array.isArray(m.hazards) ? m.hazards : [],
      video: Array.isArray(m.video) ? m.video : [],
      glyph: m.glyph || 'shield'
    }));
    return weekly.concat(base);
  }

  function allEvaluations() {
    return [].concat(S.weeklyEvals || [], D.BASE_EVALS, S.learner.generatedEvals || []);
  }

  function allProtocols() {
    return [].concat(S.weeklyProtocols || [], D.PROTOCOLS);
  }

  function moduleById(id) {
    return allCourses().find((c) => c.id === id) || null;
  }

  // ---------------------------------------------------------- persistence
  function persistLocal() {
    try { localStorage.setItem(LEARNER_KEY, JSON.stringify(S.learner)); } catch (e) { /* ignore */ }
  }

  function saveLearner(immediate) {
    S.learner.updatedAt = nowISO();
    persistLocal();
    clearTimeout(S.saveTimer);
    const push = () => {
      api('/api/evolv3/learner', 'POST', { state: S.learner }).catch(() => { /* offline cache remains */ });
    };
    if (immediate) push();
    else S.saveTimer = setTimeout(push, 700);
  }

  function award(points, reason) {
    const value = Math.round(Number(points) || 0);
    if (!value) return;
    S.learner.points = Math.max(0, Number(S.learner.points) + value);
    saveLearner();
    if (reason) toast('+' + value + ' pts · ' + reason, 'evolve');
  }

  function markStudyMinute() {
    S.learner.minutesStudied = Math.max(0, Number(S.learner.minutesStudied) || 0) + 1;
    recomputeStreak(S.learner);
    S.learner.updatedAt = nowISO();
    persistLocal();
    saveLearner();
    const t = $('#timer-value');
    if (t) t.textContent = nf(S.learner.minutesStudied);
    const p = $('#points-value');
    if (p) p.textContent = nf(S.learner.points);
    if (S.tab === 'progress' && window.ACADEMY.renderProgress) window.ACADEMY.renderProgress();
    if (S.tab === 'admin' && window.ACADEMY.renderAdmin) window.ACADEMY.renderAdmin();
  }

  function startTimer() {
    clearInterval(S.timerId);
    S.timerId = setInterval(() => {
      if (document.visibilityState === 'visible') markStudyMinute();
    }, 60000);
  }

  function addStudyDay() {
    recomputeStreak(S.learner);
    persistLocal();
  }

  // ---------------------------------------------------------- connection
  const CONN_LABELS = { online: 'Online', connecting: 'Connecting', offline: 'Offline / Local Cache', updating: 'Updating via Wi-Fi' };

  function setConn(kind) {
    const value = CONN_LABELS[kind] ? kind : 'online';
    S.conn = value;
    const dot = $('#conn-dot');
    if (dot) dot.className = 'conn-dot ' + value;
    const label = $('#conn-label');
    if (label) label.textContent = CONN_LABELS[value];
    document.documentElement.dataset.conn = value;
    const evoDot = $('#evo-dot');
    if (evoDot) evoDot.className = 'conn-dot ' + value;
  }

  async function wifiSync() {
    setConn('connecting');
    toast('Wi-Fi sync started · checking weekly content', 'evolve');
    await new Promise((resolve) => setTimeout(resolve, 850));
    setConn('online');
    const result = window.ACADEMY.checkDueEvolution ? await window.ACADEMY.checkDueEvolution() : null;
    if (!result) toast('Sync complete · local content is current for Week ' + (S.evolutionState.weekNumber || 1) + '.', 'evolve');
  }

  // ---------------------------------------------------------- speech
  let voicesCache = [];

  function refreshVoices() {
    try { voicesCache = window.speechSynthesis ? window.speechSynthesis.getVoices() : []; } catch (e) { voicesCache = []; }
  }

  function pickVoice() {
    if (!voicesCache.length) refreshVoices();
    const en = voicesCache.filter((v) => /^en([-_]|$)/i.test(v.lang || ''));
    if (!en.length) return null;
    const priorities = [
      /natural/i, /neural/i, /google uk english female/i, /google us english/i,
      /samantha/i, /aria/i, /jenny/i, /sonia/i, /libby/i, /serena/i, /kate/i, /female/i
    ];
    for (const rx of priorities) {
      const hit = en.find((v) => rx.test(v.name || ''));
      if (hit) return hit;
    }
    const gb = en.find((v) => /en-GB/i.test(v.lang));
    return gb || en[0];
  }

  function speak(text, id, label) {
    if (!window.speechSynthesis || typeof SpeechSynthesisUtterance === 'undefined') {
      toast('Voice guidance is not available in this browser.', 'error');
      return false;
    }
    stopVoice();
    const utter = new SpeechSynthesisUtterance(String(text || ''));
    utter.rate = 0.82;
    utter.pitch = 0.94;
    utter.volume = 1;
    utter.lang = 'en-GB';
    const voice = pickVoice();
    if (voice) utter.voice = voice;
    utter.onstart = () => {
      S.speech = { active: true, id: id || '' };
      const bar = $('#voice-bar');
      if (bar) bar.classList.add('speaking');
      const status = $('#voice-status');
      if (status) status.textContent = 'Reading: ' + (label || 'calm guidance') + ' · focus on your breathing';
      const stop = $('#stop-voice');
      if (stop) stop.disabled = false;
    };
    const finish = () => {
      S.speech = { active: false, id: '' };
      const bar = $('#voice-bar');
      if (bar) bar.classList.remove('speaking');
      const status = $('#voice-status');
      if (status) status.textContent = 'Ready · slow 0.82 rate · reassuring tone';
      const stop = $('#stop-voice');
      if (stop) stop.disabled = true;
    };
    utter.onend = finish;
    utter.onerror = finish;
    try { window.speechSynthesis.speak(utter); } catch (e) { finish(); toast('Voice guidance could not start.', 'error'); return false; }
    return true;
  }

  function stopVoice() {
    try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    S.speech = { active: false, id: '' };
    const bar = $('#voice-bar');
    if (bar) bar.classList.remove('speaking');
    const status = $('#voice-status');
    if (status) status.textContent = 'Ready · slow 0.82 rate · reassuring tone';
    const stop = $('#stop-voice');
    if (stop) stop.disabled = true;
  }

  if (window.speechSynthesis) {
    refreshVoices();
    window.speechSynthesis.onvoiceschanged = refreshVoices;
  }

  // ---------------------------------------------------------- evolution
  const SEVEN_DAYS = 7 * 24 * 60 * 60 * 1000;

  function daysSinceEvolution() {
    const last = new Date(S.evolutionState.lastEvolvedAt || 0).getTime();
    if (!last) return 7;
    return Math.max(0, (Date.now() - last) / 86400000);
  }

  function daysUntilEvolution() {
    const last = new Date(S.evolutionState.lastEvolvedAt || 0).getTime();
    if (!last) return 0;
    return Math.max(0, Math.ceil((SEVEN_DAYS - (Date.now() - last)) / 86400000));
  }

  function shouldAutoEvolve() {
    return !!S.evolutionState.autoUpdateOnWifi && (Date.now() - new Date(S.evolutionState.lastEvolvedAt || 0).getTime()) >= SEVEN_DAYS;
  }

  async function runEvolution(force) {
    if (S.evolving) { toast('A weekly evolution is already running.'); return null; }
    S.evolving = true;
    setConn('updating');
    const btn = $('#evolve-now');
    const quick = $('#conn-evolve-now');
    if (btn) { btn.disabled = true; btn.textContent = 'Evolving curriculum…'; }
    if (quick) quick.disabled = true;
    try {
      const nextWeek = Math.max(1, Number(S.evolutionState.weekNumber || 1)) + 1;
      const existing = allCourses().map((c) => c.id);
      const payload = await api('/api/evolv3/weekly-evolve', 'POST', {
        weekNumber: nextWeek,
        existingCourseIds: existing,
        force: !!force
      });
      if (payload.state) S.evolutionState = payload.state;
      let changed = false;
      if (payload.evolved) {
        if (payload.newModule && !S.weeklyModules.some((m) => m.id === payload.newModule.id)) {
          S.weeklyModules.push(payload.newModule);
          changed = true;
        }
        if (Array.isArray(payload.newEvaluations)) {
          payload.newEvaluations.forEach((item) => {
            if (!S.weeklyEvals.some((x) => x.id === item.id)) { S.weeklyEvals.push(item); changed = true; }
          });
        }
        if (payload.newProtocol && !S.weeklyProtocols.some((p) => p.id === payload.newProtocol.id)) {
          S.weeklyProtocols.push(payload.newProtocol);
          changed = true;
        }
      }
      if (changed) {
        const summary = payload.summary || ('Week ' + (payload.weekNumber || nextWeek) + ' content appended.');
        toast(summary + ' Refreshing the academy.', 'evolve');
      } else {
        toast('Weekly curriculum is already current for Week ' + (S.evolutionState.weekNumber || 1) + '.', 'evolve');
      }
      if (window.ACADEMY.refreshAll) window.ACADEMY.refreshAll();
      if (force && window.ACADEMY.setTab) window.ACADEMY.setTab('evolution');
      return payload;
    } catch (err) {
      toast(err.message || 'Weekly evolution could not complete. Local content is unchanged.', 'error');
      return null;
    } finally {
      S.evolving = false;
      setConn('online');
      if (btn) { btn.disabled = false; btn.textContent = 'Check & Evolve Weekly Content Now'; }
      if (quick) quick.disabled = false;
    }
  }

  async function checkDueEvolution(force) {
    if (force) return runEvolution(true);
    if (!shouldAutoEvolve()) return null;
    return runEvolution(false);
  }

  function startScheduler() {
    clearInterval(S.schedulerId);
    S.schedulerId = setInterval(() => {
      if (document.visibilityState === 'visible' && navigator.onLine !== false) checkDueEvolution(false);
    }, 60 * 60 * 1000);
    setTimeout(() => checkDueEvolution(false), 2500);
  }

  // ---------------------------------------------------------- bootstrap data
  async function loadSessionUser() {
    try {
      const b = await api('/api/bootstrap');
      if (b && b.user) S.bootUser = b.user;
    } catch (e) { S.bootUser = null; }
    const L = S.learner;
    if (!L.displayName) {
      L.displayName = (S.bootUser && (S.bootUser.full_name || S.bootUser.username)) || 'Academy Learner';
      const role = String((S.bootUser && S.bootUser.role) || '').toLowerCase();
      if (role === 'administrator' || role === 'manager') L.role = 'Clinical Staff';
      persistLocal();
    }
  }

  async function loadBootstrap() {
    try {
      const data = await api('/api/evolv3/bootstrap');
      if (data.state) S.evolutionState = data.state;
      S.nextRunAt = data.nextRunAt || '';
      S.weeklyModules = Array.isArray(data.modules) ? data.modules : [];
      S.weeklyEvals = Array.isArray(data.evaluations) ? data.evaluations : [];
      S.weeklyProtocols = Array.isArray(data.protocols) ? data.protocols : [];
      S.leaderboard = Array.isArray(data.leaderboard) ? data.leaderboard : [];
      if (data.learner) S.learner = mergeLearners(S.learner, data.learner);
      else saveLearner(true);
      setConn('online');
      return true;
    } catch (err) {
      setConn('offline');
      toast('Academy service unavailable — using the offline-first cache.', 'error');
      return false;
    }
  }

  async function saveRoleAndName(name, role) {
    const L = S.learner;
    L.displayName = String(name || '').trim().slice(0, 80) || L.displayName;
    L.role = ['Caregiver', 'Clinical Staff', 'Family', 'Public'].includes(role) ? role : 'Caregiver';
    L.updatedAt = nowISO();
    persistLocal();
    await api('/api/evolv3/learner', 'POST', { state: L }).catch(() => {});
    if (window.ACADEMY.refreshAll) window.ACADEMY.refreshAll();
    toast('Training profile set · ' + L.role, 'evolve');
  }

  // ---------------------------------------------------------- theme
  function applyTheme() {
    let theme = 'light';
    try { theme = localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { /* ignore */ }
    document.documentElement.dataset.theme = theme === 'dark' ? 'dark' : 'light';
  }

  function toggleTheme() {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* ignore */ }
    toast(next === 'dark' ? 'Dark mode enabled' : 'Light mode enabled');
  }

  // ---------------------------------------------------------- certificate helpers
  function credentialId(kind) {
    const L = S.learner;
    const raw = (L.displayName || 'learner') + '|' + (L.diplomaIssuedAt || '200h') + '|' + kind;
    let hash = 2166136261;
    for (let i = 0; i < raw.length; i++) {
      hash ^= raw.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    const code = (hash >>> 0).toString(36).toUpperCase().padStart(7, '0');
    return 'BR-EV3-' + code.slice(0, 7);
  }

  const ACADEMY = window.ACADEMY = {
    D, S,
    U: { $, $$, esc, clamp, nf, todayISO, nowISO, longDate, shortDate, timeAgo, hoursLabel, pct, toast, copyText, download, api },
    defaultLearner, normalizeLearner, mergeLearners, recomputeStreak,
    allCourses, allEvaluations, allProtocols, moduleById,
    persistLocal, saveLearner, award, markStudyMinute, startTimer, addStudyDay,
    setConn, wifiSync, CONN_LABELS,
    speak, stopVoice, pickVoice,
    runEvolution, checkDueEvolution, startScheduler, shouldAutoEvolve, daysSinceEvolution, daysUntilEvolution,
    loadSessionUser, loadBootstrap, saveRoleAndName,
    applyTheme, toggleTheme, credentialId,
    toast
  };
})();
