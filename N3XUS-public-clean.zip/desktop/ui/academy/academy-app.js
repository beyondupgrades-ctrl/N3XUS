/* ============================================================
   EVOLV3 Academy — interaction wiring, grading, and boot.
   Mounted inside the N3XUS Academy route via an iframe.
   ============================================================ */
(function () {
  'use strict';

  const A = window.ACADEMY;
  const D = A.D;
  const S = A.S;
  const { $, $$, esc, nf, toast, copyText, download, api, todayISO, clamp } = A.U;

  const TABS = ['courses', 'library', 'evaluations', 'leaderboard', 'progress', 'certificates', 'admin', 'evolution'];
  const ROLES = ['Caregiver', 'Clinical Staff', 'Family', 'Public'];
  const PINS_KEY = 'evolv3:pins';
  let pins = null;

  // ---------------------------------------------------------- pins
  function pinnedSet() {
    if (pins === null) {
      try {
        const raw = localStorage.getItem(PINS_KEY);
        pins = raw ? JSON.parse(raw) : D.PROTOCOLS.filter((p) => p.pinned).map((p) => p.id);
      } catch (e) {
        pins = D.PROTOCOLS.filter((p) => p.pinned).map((p) => p.id);
      }
      if (!Array.isArray(pins)) pins = [];
    }
    return pins;
  }

  function applyPins() {
    const set = new Set(pinnedSet());
    A.allProtocols().forEach((p) => { p.pinned = set.has(p.id); });
  }

  function togglePin(id) {
    const set = new Set(pinnedSet());
    if (set.has(id)) set.delete(id); else set.add(id);
    pins = Array.from(set);
    try { localStorage.setItem(PINS_KEY, JSON.stringify(pins)); } catch (e) { /* ignore */ }
    applyPins();
    A.renderLibrary();
    toast(set.has(id) ? 'Protocol pinned to the top.' : 'Protocol unpinned.');
  }

  // ---------------------------------------------------------- tab switching
  function setTab(name) {
    const tab = TABS.indexOf(name) !== -1 ? name : 'courses';
    S.tab = tab;
    $$('#academy-tabs .tab').forEach((b) => {
      const on = b.dataset.tab === tab;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    $$('.panel').forEach((p) => p.classList.toggle('is-active', p.dataset.panel === tab));
    if (tab === 'library') A.renderLibrary();
    if (tab === 'evaluations') A.renderEvaluations();
    if (tab === 'leaderboard') A.renderLeaderboard();
    if (tab === 'progress') A.renderProgress();
    if (tab === 'certificates') A.renderCertificates();
    if (tab === 'admin') A.renderAdmin();
    if (tab === 'evolution') A.renderEvolution();
    if (tab === 'courses') A.renderCourses();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  A.setTab = setTab;

  // ---------------------------------------------------------- header status
  function updateUnread() {
    const dot = $('#unread-dot');
    const count = (S.evolutionState.changelog || []).length + (S.weeklyEvals || []).length;
    if (dot) dot.classList.toggle('show', count > 0);
    const bell = $('#bell-pill');
    if (bell) bell.title = count ? count + ' academy updates and deadlines' : 'Deadlines and weekly study drops';
  }

  // ---------------------------------------------------------- enrolment
  function enrol(id) {
    const course = A.moduleById(id);
    if (!course) return;
    if (S.learner.enrolled.indexOf(id) !== -1) { toast('You are already enrolled in this module.'); return; }
    if (S.learner.completions[id]) { toast('This module is already completed.'); return; }
    S.learner.enrolled.push(id);
    const xp = course.isNewAutonomous ? 100 : 50;
    S.learner.points = Math.max(0, Number(S.learner.points) || 0) + xp;
    A.saveLearner(true);
    A.closeModal();
    A.refreshAll();
    updateUnread();
    toast('Enrolled · +' + xp + ' pts · ' + course.title, 'evolve');
  }

  async function shareCourse(id) {
    const course = A.moduleById(id);
    if (!course) return;
    const link = location.origin + '/academy#' + encodeURIComponent(id);
    const ok = await copyText(course.title + '\n' + link);
    toast(ok ? 'Share link copied to the clipboard.' : 'Share link: ' + link, ok ? '' : 'error');
  }

  // Section 11: generate (or refresh) a module's clinical illustration. The
  // backend returns a stored data URI, or the deterministic topic SVG when the
  // model is offline — either way the card, modal and clip thumbnails update.
  async function generateModuleImage(moduleId, button) {
    const course = A.moduleById(moduleId);
    if (!course) { toast('Module not found', 'error'); return; }
    const Art = window.EVOLV3_ARTWORK;
    if (!Art || typeof Art.generate !== 'function') { toast('Artwork engine unavailable', 'error'); return; }
    const label = button ? button.textContent : '';
    if (button) { button.disabled = true; button.textContent = 'Generating…'; }
    try {
      const result = await Art.generate(course, {});
      A.refreshCourses ? A.refreshCourses() : (window.ACADEMY.renderCourses && window.ACADEMY.renderCourses());
      const host = $('#modal-course-art');
      if (host) host.innerHTML = Art.ModuleArtwork(course, { className: 'course-artwork', ai: !result.fallback });
      $$('[data-thumb-course="' + moduleId + '"]').forEach((el) => {
        el.innerHTML = Art.ModuleArtwork(course, { className: 'clip-thumb' });
      });
      if (result.fallback) toast('Saved a topic illustration for "' + course.title + '" (AI offline)', 'info');
      else toast('Clinical illustration saved · ' + (result.engine || 'ai'), 'success');
    } catch (err) {
      toast(err && err.message ? err.message : 'Could not generate the illustration', 'error');
    } finally {
      if (button) { button.disabled = false; button.textContent = label || '🎨 AI Generate Image'; }
    }
  }

  function quickEval(moduleId) {
    const course = A.moduleById(moduleId);
    const evals = A.allEvaluations().filter((e) => e.moduleId === moduleId);
    A.closeModal();
    if (!evals.length) {
      toast('No evaluation is attached to this module yet. Generate one from the Evaluations tab.', 'error');
      setTab('evaluations');
      return;
    }
    S.evalModule = moduleId;
    S.evalKind = evals[0].kind;
    setTab('evaluations');
    A.renderEvaluations();
    setTimeout(() => {
      const first = $('.eval-item');
      if (first) first.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 120);
    toast('Assessment bank filtered to ' + (course ? course.title : 'this module') + '.');
  }

  // ---------------------------------------------------------- local grading
  function localGrade(item, answer) {
    const text = String(answer || '').trim();
    const lower = text.toLowerCase();
    const keywords = (item.keywords || []).map((k) => String(k).toLowerCase()).filter(Boolean);
    const hits = keywords.filter((k) => lower.indexOf(k) !== -1);
    const coverage = keywords.length ? hits.length / keywords.length : 0;
    const expected = String(item.expected || item.answer || '').toLowerCase();
    const answerWords = new Set(lower.match(/[a-z0-9]+/g) || []);
    const expectedWords = (expected.match(/[a-z0-9]+/g) || []).filter((w) => w.length > 3);
    let overlap = 0;
    if (expectedWords.length) {
      overlap = expectedWords.filter((w) => answerWords.has(w)).length / expectedWords.length;
    }
    const words = text ? text.split(/\s+/).length : 0;
    const lengthFactor = words >= 18 ? 1 : Math.max(0.35, words / 18);
    let score = Math.round(clamp(0.58 * coverage + 0.34 * overlap + 0.08 * lengthFactor, 0, 1) * 100);

    if (item.kind === 'quiz') {
      const target = String(item.answer || item.expected || '').trim().toLowerCase();
      const picked = lower.trim();
      if (target && (picked === target || picked.indexOf(target) !== -1)) score = 100;
      else score = Math.min(45, score);
    }

    const passed = score >= 60;
    const missing = keywords.filter((k) => lower.indexOf(k) === -1);
    let feedback;
    if (score >= 90) feedback = 'Excellent true match. Your response names the priority actions, the hazard and the escalation point.';
    else if (score >= 75) feedback = 'Strong clinical match. Tighten the sequence and make the escalation explicit.';
    else if (score >= 60) feedback = 'Passing match. The core idea is present, but a supervisor would want more specific actions.';
    else if (score >= 40) feedback = 'Partial match. Important safety steps or the correct clinical term are missing.';
    else feedback = 'Low match. This answer would not keep a resident safe; review the module and retake.';
    const improvements = [];
    if (missing.length) improvements.push('Include these clinical cues: ' + missing.slice(0, 4).join(', ') + '.');
    if (words < 18) improvements.push('Expand to at least two sentences with a clear action sequence.');
    improvements.push(passed
      ? 'Add one line on documentation and handover to reach distinction.'
      : 'State the first action, the risk you are preventing, and who you would escalate to.');
    const xp = (score >= 80 ? 40 : passed ? 30 : score >= 40 ? 10 : 4) + (item.kind === 'assignment' && passed ? 10 : 0);
    return {
      score, passed, xp, feedback,
      improvements: improvements.slice(0, 4),
      missing: missing.slice(0, 6),
      engine: 'offline-local'
    };
  }

  // ---------------------------------------------------------- evaluations
  function paintInlineResult(id, result) {
    const host = document.getElementById('result-' + id);
    if (!host) return;
    host.className = 'result-inline show ' + (result.passed ? 'pass' : 'fail');
    host.innerHTML = '<b>' + result.score + '% True Match · ' + (result.passed ? 'PASSED' : 'RETRY') + '</b>' +
      '<div style="margin-top:3px">' + esc(result.feedback || '') + '</div>' +
      ((result.improvements || []).length
        ? '<div style="margin-top:4px">' + result.improvements.map((x) => '→ ' + esc(x)).join('<br>') + '</div>'
        : '');
  }

  async function submitEval(id) {
    const item = A.allEvaluations().find((x) => x.id === id);
    if (!item) { toast('That evaluation is no longer in the bank.', 'error'); return; }
    const answer = item.kind === 'quiz' ? (S.quizPicks[id] || '') : String(S.evalAnswers[id] || '').trim();
    if (!answer) {
      toast(item.kind === 'quiz' ? 'Choose one option before submitting.' : 'Write a clinical answer before submitting.', 'error');
      return;
    }

    const btn = $$('[data-submit-eval]').find((b) => b.dataset.submitEval === id);
    if (btn) { btn.disabled = true; btn.textContent = 'Grading…'; }

    let result;
    try {
      result = await api('/api/evolv3/grade', 'POST', {
        answer,
        expected: item.kind === 'quiz' ? (item.answer || item.expected || '') : (item.expected || ''),
        keywords: item.keywords || [],
        kind: item.kind
      });
    } catch (err) {
      result = localGrade(item, answer);
    }

    if (item.kind === 'quiz' && item.answer) {
      const picked = String(answer).trim().toLowerCase();
      const target = String(item.answer).trim().toLowerCase();
      if (picked === target) {
        result.score = 100;
        result.passed = true;
        result.xp = Math.max(Number(result.xp) || 0, 30);
      }
    }

    const score = clamp(Math.round(Number(result.score) || 0), 0, 100);
    const passed = !!result.passed && score >= 60;
    const xp = Math.max(0, Math.round(Number(result.xp) || 0));
    const attempt = {
      id: 'att-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
      evalId: item.id,
      kind: item.kind,
      moduleId: item.moduleId || '',
      moduleTitle: item.moduleTitle || 'Academy',
      prompt: item.prompt,
      score,
      passed,
      xp,
      date: new Date().toISOString()
    };

    S.learner.attempts.push(attempt);
    S.learner.attempts = S.learner.attempts.slice(-400);
    S.learner.points = Math.max(0, Number(S.learner.points) || 0) + xp;
    S.learner.lastResult = {
      score, passed,
      feedback: result.feedback || '',
      improvements: result.improvements || [],
      engine: result.engine || 'clinical',
      title: item.moduleTitle || 'Academy',
      date: attempt.date
    };
    S.lastResult = S.learner.lastResult;

    if (passed && item.moduleId) {
      const prev = S.learner.completions[item.moduleId];
      if (!prev || score > (Number(prev.score) || 0)) {
        S.learner.completions[item.moduleId] = { score, date: todayISO() };
      }
      if (Object.keys(S.learner.completions).length >= 13 && !S.learner.diplomaIssuedAt) {
        S.learner.diplomaIssuedAt = todayISO();
      }
    }

    A.recomputeStreak(S.learner);
    A.saveLearner(true);
    paintInlineResult(item.id, { score, passed, feedback: result.feedback, improvements: result.improvements });
    A.renderHeader();
    A.renderScorePanel();
    A.renderSocialBadges();

    if (btn) { btn.disabled = false; btn.textContent = 'Submit for AI grading'; }

    if (passed) {
      delete S.evalAnswers[id];
      delete S.quizPicks[id];
      toast('Passed · ' + score + '% True Match · +' + xp + ' pts', 'evolve');
    } else {
      toast('Attempt recorded · ' + score + '% · 60% needed to pass', 'error');
    }
  }

  function retakeEval(id) {
    delete S.evalAnswers[id];
    delete S.quizPicks[id];
    const item = A.allEvaluations().find((x) => x.id === id);
    if (item) item.__shuffle = Date.now();
    A.renderEvaluations();
    toast('Cleared. Retake as often as you need.');
  }

  function generateEval() {
    const courses = A.allCourses();
    if (!courses.length) return;
    const kinds = ['short', 'quiz', 'assignment'];
    const kind = kinds[Math.floor(Math.random() * kinds.length)];
    const course = courses[Math.floor(Math.random() * courses.length)];
    const hazards = (course.hazards && course.hazards.length) ? course.hazards : ['clinical deterioration'];
    const hazard = hazards[Math.floor(Math.random() * hazards.length)];
    const makers = D.GEN_TEMPLATES[kind];
    const prompt = makers[Math.floor(Math.random() * makers.length)](course, hazard);
    const expected = 'Recognise the risk early, apply the ' + course.title + ' protocol, escalate to the clinical lead and document the observation, action and time.';

    let options = [];
    let answerText = '';
    if (kind === 'quiz') {
      const correct = 'Assess, escalate and document using the ' + course.title + ' protocol';
      const wrong = [
        'Wait until the next shift and add it to the handover',
        'Restrict fluids and observe without escalation',
        'Record the finding in the notes and take no immediate action'
      ];
      options = [correct].concat(wrong);
      for (let i = options.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const tmp = options[i]; options[i] = options[j]; options[j] = tmp;
      }
      answerText = correct;
    }

    const keywords = Array.from(new Set(
      [hazard.toLowerCase(), 'assess', 'escalate', 'document'].concat(
        String(course.title).toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 3).slice(0, 3)
      )
    ));

    const item = {
      id: 'gen-' + Date.now().toString(36) + Math.floor(Math.random() * 999).toString(36),
      kind,
      moduleId: course.id,
      moduleTitle: course.title,
      prompt,
      options,
      answer: answerText,
      expected,
      keywords,
      tips: ['Name the first action.', 'State the escalation point and the documentation.'],
      generated: true
    };

    S.learner.generatedEvals = (S.learner.generatedEvals || []).concat(item).slice(-60);
    S.evalKind = kind;
    S.evalModule = '';
    A.saveLearner();
    A.renderEvaluations();
    toast('New ' + (kind === 'quiz' ? 'quiz' : kind === 'assignment' ? 'mini assignment' : 'short question') + ' generated from the clinical bank.');
    setTimeout(() => {
      const nodes = $$('.eval-item');
      const last = nodes[nodes.length - 1];
      if (last) last.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 120);
  }

  // ---------------------------------------------------------- library
  function readCard(card) {
    if (!card) return;
    A.speak(card.voice, card.code, card.title);
  }

  function copyCard(card) {
    if (!card) return;
    const text = [
      card.title.toUpperCase() + ' (' + card.code + ')',
      '',
      'WARNING SIGNS',
      card.signs.map((s) => '• ' + s).join('\n'),
      '',
      'DO NOT',
      card.donts.map((s) => '• ' + s).join('\n'),
      '',
      'ACTION STEPS',
      card.steps.map((s, i) => (i + 1) + '. ' + s).join('\n'),
      '',
      'VISUAL CUES: ' + card.cues.join(' · '),
      '',
      'GOLDEN RULE: ' + card.golden,
      '',
      'Beyond Registration Academy · internal clinical quick-reference'
    ].join('\n');
    copyText(text).then((ok) => toast(ok ? 'Protocol steps copied.' : 'Copy is unavailable in this browser.', ok ? '' : 'error'));
  }

  async function copyProtocol(id) {
    const p = A.allProtocols().find((x) => x.id === id);
    if (!p) return;
    const text = [p.title.toUpperCase(), 'Urgency: ' + p.urgency + ' · ' + p.category, '', p.summary, '', 'STEPS']
      .concat((p.steps || []).map((s, i) => (i + 1) + '. ' + s))
      .concat(['', 'Beyond Registration Academy · internal clinical reference'])
      .join('\n');
    const ok = await copyText(text);
    toast(ok ? 'Protocol copied.' : 'Copy is unavailable in this browser.', ok ? '' : 'error');
  }

  function downloadManual() {
    const lines = [
      'BEYOND REGISTRATION ACADEMY · EVOLV3 CLINICAL MANUAL',
      'Beyond Registration (Pty) Ltd · Reg. No. 2026721121',
      'Internal, non-accredited workforce upskilling · offline edition',
      'Generated ' + new Date().toLocaleString('en-ZA'),
      '='.repeat(72),
      ''
    ];
    D.FLIP_CARDS.forEach((card) => {
      lines.push(card.title.toUpperCase() + ' (' + card.code + ')');
      lines.push('Warning signs: ' + card.signs.join('; '));
      lines.push('Do not: ' + card.donts.join(' '));
      card.steps.forEach((s, i) => lines.push('  ' + (i + 1) + '. ' + s));
      lines.push('Golden rule: ' + card.golden);
      lines.push('');
    });
    lines.push('='.repeat(72), 'CLINICAL PROTOCOLS', '');
    A.allProtocols().forEach((p) => {
      lines.push(p.title.toUpperCase() + ' · ' + p.urgency + ' · ' + p.category);
      lines.push(p.summary || '');
      (p.steps || []).forEach((s, i) => lines.push('  ' + (i + 1) + '. ' + s));
      lines.push('');
    });
    lines.push('='.repeat(72));
    lines.push('This manual is an internal, non-accredited clinical memory aid. It is not registered on the NQF (Act 67 of 2008), carries no SAQA, QCTO or CHE accreditation, and is not a formal qualification under the Higher Education Act 101 of 1997.');
    download('your-userd-academy-clinical-manual-' + todayISO() + '.txt', lines.join('\r\n'));
    toast('Offline manual downloaded.');
  }

  // ---------------------------------------------------------- profile / bell
  function roleOptions(selected) {
    return ROLES.map((r) => '<option value="' + r + '"' + (r === selected ? ' selected' : '') + '>' + r + '</option>').join('');
  }

  function openProfile() {
    const L = S.learner;
    const body = '<form id="academy-profile-form" class="auth-form" autocomplete="off">' +
      '<label class="field"><span>Username / display name</span><input id="profile-username" type="text" maxlength="80" value="' + esc(L.displayName || '') + '" autocomplete="username" required></label>' +
      '<label class="field"><span>Password</span><input id="profile-password" type="password" minlength="4" autocomplete="current-password" placeholder="At least 4 characters" required></label>' +
      '<label class="field"><span>Training role</span><select id="profile-role-select">' + roleOptions(L.role) + '</select></label>' +
      '<p class="auth-note">This training profile is separate from your N3XUS sign-in. The password is checked in this browser for role confirmation only — it is never stored, transmitted or written to the database.</p>' +
    '</form>';
    const foot = '<button class="btn btn-ghost" data-close-modal>Cancel</button>' +
      (S.bootUser ? '<button class="btn btn-secondary" id="profile-use-nexus">Use N3XUS identity</button>' : '') +
      '<button class="btn btn-primary" id="profile-save">Sign in to academy</button>';
    A.openModal('Training profile', 'Academy username & role', body, foot);

    const save = $('#profile-save');
    if (save) save.addEventListener('click', async () => {
      const name = ($('#profile-username') || {}).value || '';
      const pass = ($('#profile-password') || {}).value || '';
      const role = ($('#profile-role-select') || {}).value || 'Caregiver';
      if (!String(name).trim()) { toast('Enter a display name.', 'error'); return; }
      if (String(pass).length < 4) { toast('Use a password of at least 4 characters.', 'error'); return; }
      save.disabled = true;
      save.textContent = 'Signing in…';
      A.closeModal();
      await A.saveRoleAndName(name, role);
      toast('Password verified locally · it was not stored.', 'evolve');
    });

    const nexus = $('#profile-use-nexus');
    if (nexus) nexus.addEventListener('click', async () => {
      const user = S.bootUser || {};
      const name = user.full_name || user.username || '';
      const raw = String(user.role || '').toLowerCase();
      const role = raw === 'administrator' || raw === 'manager' ? 'Clinical Staff' : 'Caregiver';
      if (!name) { toast('No N3XUS identity is available in this session.', 'error'); return; }
      A.closeModal();
      await A.saveRoleAndName(name, role);
    });
  }

  function openBell() {
    const items = A.deadlineItems();
    const body = '<div class="deadline-list">' + items.map((d) =>
      '<div class="deadline"><div class="deadline-icon">' + esc(d.icon) + '</div>' +
      '<div><b>' + esc(d.title) + '</b><small>' + esc(d.detail) + '</small></div>' +
      '<span class="due">' + esc(d.due) + '</span></div>'
    ).join('') + '</div>' +
      '<p class="auth-note" style="margin-top:12px">Deadlines are internal study reminders generated by the academy. Weekly study drops arrive automatically every seven days.</p>';
    A.openModal('Notifications', 'Deadlines & weekly study drops', body, '<button class="btn btn-primary" data-close-modal>Done</button>');
    const dot = $('#unread-dot');
    if (dot) dot.classList.remove('show');
  }

  // ---------------------------------------------------------- export / print
  function exportProgress() {
    const L = S.learner;
    const courses = A.allCourses();
    const payload = {
      issuedBy: 'Beyond Registration (Pty) Ltd · Reg. No. 2026721121',
      system: 'EVOLV3 Academy · internal non-accredited workforce upskilling',
      exportedAt: new Date().toISOString(),
      learner: {
        displayName: L.displayName,
        role: L.role,
        points: L.points,
        minutesStudied: L.minutesStudied,
        studyHours: Math.round((Number(L.minutesStudied) || 0) / 60 * 10) / 10,
        streak: L.streak,
        badges: L.badges,
        diplomaIssuedAt: L.diplomaIssuedAt || ''
      },
      summary: {
        modulesCompleted: Object.keys(L.completions || {}).length,
        modulesAvailable: courses.length,
        attempts: (L.attempts || []).length,
        averageTrueMatch: (L.attempts || []).length
          ? Math.round(L.attempts.reduce((a, x) => a + (Number(x.score) || 0), 0) / L.attempts.length)
          : null,
        verifiedHoursTarget: 200
      },
      modules: courses.map((c) => ({
        id: c.id,
        title: c.title,
        category: c.category,
        hours: c.hours,
        enrolled: L.enrolled.indexOf(c.id) !== -1,
        completed: !!L.completions[c.id],
        bestScore: A.moduleBest(c.id),
        completedOn: (L.completions[c.id] || {}).date || ''
      })),
      attempts: L.attempts || []
    };
    download('evolv3-transcript-' + todayISO() + '.json', JSON.stringify(payload, null, 2), 'application/json');
    toast('JSON transcript exported.');
  }

  async function toggleAutoWifi(enabled) {
    const previous = !!S.evolutionState.autoUpdateOnWifi;
    S.evolutionState.autoUpdateOnWifi = !!enabled;
    try {
      const res = await api('/api/evolv3/state', 'POST', { autoUpdateOnWifi: !!enabled });
      if (res.state) S.evolutionState = res.state;
      if (res.nextRunAt) S.nextRunAt = res.nextRunAt;
      A.renderEvolution();
      toast(enabled ? 'Auto-update on Wi-Fi enabled.' : 'Auto-update on Wi-Fi paused.');
    } catch (err) {
      S.evolutionState.autoUpdateOnWifi = previous;
      const box = $('#auto-wifi');
      if (box) box.checked = previous;
      toast('Could not save that setting. Check the connection and try again.', 'error');
    }
  }

  // ---------------------------------------------------------- wiring
  function wire() {
    // Tabs
    const tabs = $('#academy-tabs');
    if (tabs) tabs.addEventListener('click', (e) => {
      const btn = e.target.closest('.tab');
      if (btn) setTab(btn.dataset.tab);
    });

    // Header pills
    const timer = $('#timer-pill');
    if (timer) timer.addEventListener('click', () => setTab('progress'));
    const points = $('#points-pill');
    if (points) points.addEventListener('click', () => setTab('leaderboard'));
    const bell = $('#bell-pill');
    if (bell) bell.addEventListener('click', openBell);
    const profile = $('#profile-pill');
    if (profile) profile.addEventListener('click', openProfile);
    const theme = $('#theme-toggle');
    if (theme) theme.addEventListener('click', () => A.toggleTheme());

    // Connection menu
    const connPill = $('#conn-pill');
    const connMenu = $('#conn-menu');
    if (connPill && connMenu) {
      connPill.addEventListener('click', (e) => {
        e.stopPropagation();
        const open = connMenu.classList.toggle('open');
        connPill.setAttribute('aria-expanded', open ? 'true' : 'false');
        connMenu.setAttribute('aria-hidden', open ? 'false' : 'true');
      });
      connMenu.addEventListener('click', async (e) => {
        const stateBtn = e.target.closest('[data-conn]');
        if (stateBtn) {
          A.setConn(stateBtn.dataset.conn);
          toast('Connection status set to ' + (A.CONN_LABELS[stateBtn.dataset.conn] || 'Online') + '.');
          connMenu.classList.remove('open');
          return;
        }
        if (e.target.closest('#wifi-sync-now')) {
          connMenu.classList.remove('open');
          await A.wifiSync();
          return;
        }
        if (e.target.closest('#conn-evolve-now')) {
          connMenu.classList.remove('open');
          await A.runEvolution(true);
        }
      });
    }

    // Course search & filters
    const courseSearch = $('#course-search');
    if (courseSearch) courseSearch.addEventListener('input', (e) => {
      S.courseQuery = e.target.value || '';
      A.renderCourses();
    });
    const filters = $('#course-filters');
    if (filters) filters.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter');
      if (!btn) return;
      S.courseCategory = btn.dataset.cat || 'All';
      $$('#course-filters .filter').forEach((b) => b.classList.toggle('is-active', b === btn));
      A.renderCourses();
    });

    // Library controls
    const copyEms = $('#copy-ems');
    if (copyEms) copyEms.addEventListener('click', async () => {
      const ok = await copyText(A.emsScript());
      toast(ok ? 'EMS / 911 handover script copied.' : 'Copy is unavailable in this browser.', ok ? '' : 'error');
    });
    const manual = $('#download-manual');
    if (manual) manual.addEventListener('click', downloadManual);
    const stopVoice = $('#stop-voice');
    if (stopVoice) stopVoice.addEventListener('click', () => {
      A.stopVoice();
      toast('Voice guidance stopped.');
    });

    const protocolSearch = $('#protocol-search');
    if (protocolSearch) protocolSearch.addEventListener('input', (e) => {
      S.protocolQuery = e.target.value || '';
      A.renderLibrary();
    });
    const protocolCat = $('#protocol-category');
    if (protocolCat) protocolCat.addEventListener('change', (e) => {
      S.protocolCategory = e.target.value || '';
      A.renderLibrary();
    });
    const protocolUrg = $('#protocol-urgency');
    if (protocolUrg) protocolUrg.addEventListener('change', (e) => {
      S.protocolUrgency = e.target.value || '';
      A.renderLibrary();
    });

    const flipGrid = $('#flip-grid');
    if (flipGrid) flipGrid.addEventListener('click', (e) => {
      const read = e.target.closest('[data-read-card]');
      if (read) {
        readCard(D.FLIP_CARDS.find((c) => c.code === read.dataset.readCard));
        return;
      }
      const copy = e.target.closest('[data-copy-card]');
      if (copy) {
        copyCard(D.FLIP_CARDS.find((c) => c.code === copy.dataset.copyCard));
        return;
      }
      const card = e.target.closest('.flip-card');
      if (card) card.classList.toggle('flipped');
    });

    // Evaluation tabs & module filter
    const evalTabs = $('#eval-tabs');
    if (evalTabs) evalTabs.addEventListener('click', (e) => {
      const btn = e.target.closest('.eval-tab');
      if (!btn) return;
      S.evalKind = btn.dataset.kind;
      A.renderEvaluations();
    });
    const evalFilter = $('#eval-module-filter');
    if (evalFilter) evalFilter.addEventListener('change', (e) => {
      S.evalModule = e.target.value || '';
      A.renderEvaluations();
    });
    const generate = $('#generate-eval');
    if (generate) generate.addEventListener('click', generateEval);

    // Leaderboard role filter
    const leaderRole = $('#leader-role');
    if (leaderRole) leaderRole.addEventListener('change', (e) => {
      S.leaderRole = e.target.value || '';
      A.renderLeaderboard();
    });

    // Progress export
    const exportBtn = $('#export-progress');
    if (exportBtn) exportBtn.addEventListener('click', exportProgress);

    // Administration
    const periodSwitch = $('#period-switch');
    if (periodSwitch) periodSwitch.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter');
      if (!btn) return;
      S.adminPeriod = btn.dataset.period || 'daily';
      A.renderAdmin();
    });
    const adminSearch = $('#admin-search');
    if (adminSearch) adminSearch.addEventListener('input', (e) => {
      S.adminQuery = e.target.value || '';
      A.renderAdmin();
    });
    const adminRole = $('#admin-role');
    if (adminRole) adminRole.addEventListener('change', (e) => {
      S.adminRole = e.target.value || '';
      A.renderAdmin();
    });
    const printAudit = $('#print-audit');
    if (printAudit) printAudit.addEventListener('click', () => A.printAudit());
    const exportCsv = $('#export-csv');
    if (exportCsv) exportCsv.addEventListener('click', () => A.exportCsv());

    // Evolution
    const autoWifi = $('#auto-wifi');
    if (autoWifi) autoWifi.addEventListener('change', (e) => toggleAutoWifi(e.target.checked));
    const evolveNow = $('#evolve-now');
    if (evolveNow) evolveNow.addEventListener('click', () => A.runEvolution(true));

    // Certificate viewer
    const certClose = $('#cert-close');
    if (certClose) certClose.addEventListener('click', () => A.closeCertificate());
    const certFlip = $('#cert-flip');
    if (certFlip) certFlip.addEventListener('click', () => {
      A.setCertFace(S.certFace === 'back' ? 'front' : 'back');
    });
    const certPrint = $('#cert-print');
    if (certPrint) certPrint.addEventListener('click', () => A.printCertificate());
    $$('[data-cert-face]').forEach((btn) => btn.addEventListener('click', () => A.setCertFace(btn.dataset.certFace)));
    window.addEventListener('resize', () => {
      if ($('#cert-viewer') && $('#cert-viewer').classList.contains('open')) A.fitCertificate();
    });

    // Global click actions
    document.addEventListener('click', (e) => {
      const openCourse = e.target.closest('[data-open-course]');
      if (openCourse) { A.openCourse(openCourse.dataset.openCourse); return; }

      const enroll = e.target.closest('[data-enroll]');
      if (enroll) { enrol(enroll.dataset.enroll); return; }

      const share = e.target.closest('[data-share]');
      if (share) { shareCourse(share.dataset.share); return; }

      const quick = e.target.closest('[data-quick-eval]');
      if (quick) { quickEval(quick.dataset.quickEval); return; }

      const genImage = e.target.closest('[data-gen-image]');
      if (genImage) { generateModuleImage(genImage.dataset.genImage, genImage); return; }

      const retake = e.target.closest('[data-retake]');
      if (retake) { quickEval(retake.dataset.retake); return; }

      const openCert = e.target.closest('[data-open-cert]');
      if (openCert) { A.openCertificate(openCert.dataset.openCert); return; }

      const viewCert = e.target.closest('[data-view-cert]');
      if (viewCert) { A.openCertificate(viewCert.dataset.viewCert); return; }

      const audit = e.target.closest('[data-audit]');
      if (audit) { A.openAudit(audit.dataset.audit); return; }

      const auditClose = e.target.closest('[data-audit-close]');
      if (auditClose) { A.closeAudit(); return; }

      const pin = e.target.closest('[data-pin]');
      if (pin) { e.preventDefault(); togglePin(pin.dataset.pin); return; }

      const copyProto = e.target.closest('[data-copy-protocol]');
      if (copyProto) { copyProtocol(copyProto.dataset.copyProtocol); return; }

      const submit = e.target.closest('[data-submit-eval]');
      if (submit) { submitEval(submit.dataset.submitEval); return; }

      const retakeEvalBtn = e.target.closest('[data-retake-eval]');
      if (retakeEvalBtn) { retakeEval(retakeEvalBtn.dataset.retakeEval); return; }

      const option = e.target.closest('[data-option]');
      if (option) {
        const id = option.dataset.option;
        S.quizPicks[id] = option.dataset.value;
        const wrap = option.closest('.eval-item');
        if (wrap) wrap.querySelectorAll('.option').forEach((o) => o.classList.toggle('selected', o === option));
        return;
      }

      if (e.target.closest('#modal-close') || e.target.closest('[data-close-modal]') || e.target === $('#modal-backdrop')) {
        A.closeModal();
        return;
      }

      // Close the connection menu on an outside click.
      if (connMenu && connMenu.classList.contains('open') && !e.target.closest('.conn-wrap')) {
        connMenu.classList.remove('open');
        if (connPill) connPill.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('input', (e) => {
      const textarea = e.target.closest('[data-answer]');
      if (textarea) S.evalAnswers[textarea.dataset.answer] = textarea.value;
    });

    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      if ($('#cert-viewer') && $('#cert-viewer').classList.contains('open')) { A.closeCertificate(); return; }
      A.closeModal();
      A.closeAudit();
      if (connMenu) connMenu.classList.remove('open');
    });
  }

  // ---------------------------------------------------------- boot
  async function boot() {
    A.applyTheme();
    A.addStudyDay();
    applyPins();
    wire();

    // Render the offline-first shell immediately.
    A.renderHeader();
    A.renderCourses();
    A.renderLibrary();
    A.renderEvaluations();
    A.renderLeaderboard();
    A.renderProgress();
    A.renderCertificates();
    A.renderAdmin();
    A.renderEvolution();
    updateUnread();
    A.startTimer();

    await A.loadSessionUser();
    const online = await A.loadBootstrap();
    applyPins();
    S.lastResult = S.learner.lastResult || null;
    A.refreshAll();
    updateUnread();
    A.startScheduler();

    if (online) {
      try {
        const roster = await api('/api/employees');
        S.employees = Array.isArray(roster.items) ? roster.items : [];
        A.renderAdmin();
      } catch (e) {
        S.employees = [];
      }
      A.saveLearner(true);
      setTimeout(() => {
        toast('Academy ready · Week ' + (S.evolutionState.weekNumber || 1) + ' curriculum loaded', 'evolve');
      }, 500);
    }
  }

  // Wrap refresh so pins and the notification dot stay in sync after every update.
  const baseRefresh = A.refreshAll;
  A.refreshAll = function refreshWithPins() {
    applyPins();
    if (baseRefresh) baseRefresh();
    updateUnread();
  };

  A.updateUnread = updateUnread;
  A.setTab = setTab;
  A.enrol = enrol;
  A.submitEval = submitEval;
  A.generateEval = generateEval;
  A.exportProgress = exportProgress;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
