/* ============================================================
   EVOLV3 Academy — ModuleArtwork (Section 11)

   Guarantees every module card and course modal shows a
   topic-specific 800x450 clinical illustration:

     1. the stored imageUrl (AI-generated or previously saved), else
     2. a locally drawn topic SVG chosen from title/category/
         hazardsCovered, else
     3. a labelled category diagram.

   A bare heart icon or empty box is never rendered.

   `ModuleArtwork` is a React component when React is present on the
   page and a plain string renderer otherwise, so the same call works
   in this vanilla build and in any React host.
   ============================================================ */
(function () {
  'use strict';

  const W = 800;
  const H = 450;
  const NS = 'http://www.w3.org/2000/svg';

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------------------------------------------------------- topic picking
  const TOPICS = {
    ecg: { label: 'VITAL SIGNS MONITORING', accent: '#0F766E' },
    dementia: { label: 'DEMENTIA CARE · FAST STAGES', accent: '#7C3AED' },
    choking: { label: 'CHOKING & DYSPHAGIA RESCUE', accent: '#B91C1C' },
    bathing: { label: 'DIGNIFIED BATHING & HYGIENE', accent: '#0284C7' },
    transfer: { label: 'SAFE PATIENT TRANSFER', accent: '#0D9488' },
    sundowning: { label: 'SUNDOWNING LIGHT PROTOCOL', accent: '#C2410C' },
    medication: { label: 'MEDICATION SAFETY · 5 RIGHTS', accent: '#1D4ED8' },
    stroke: { label: 'STROKE FAST TRIAGE', accent: '#DC2626' },
    generic: { label: 'CLINICAL CARE MODULE', accent: '#0F766E' }
  };

  const KEYWORDS = [
    ['choking', ['chok', 'dysphag', 'airway', 'iddsi', 'aspirat', 'swallow', 'heimlich']],
    ['bathing', ['bath', 'shower', 'hygiene', '38', 'water temperature', 'scald', 'skin care', 'pressure injur', 'continence']],
    ['sundowning', ['sundown', 'circadian', 'light therapy', 'dusk', 'sleep hygiene']],
    ['transfer', ['transfer', 'mobility', 'gait', 'hoist', 'pivot', 'manual handling', 'moving a patient', 'fall']],
    ['medication', ['medicat', 'polypharm', '5 rights', 'five rights', 'prescription', 'drug', 'dose', 'pill']],
    ['stroke', ['stroke', 'fast', 'cva', 'cerebrovascular', 'face droop', 'hemipleg']],
    ['dementia', ['dementia', 'alzheimer', 'memory', 'confusion', 'cognitive', 'delirium', 'behaviour', 'wandering']],
    ['ecg', ['vital', 'ecg', 'ekg', 'blood pressure', 'observation', 'news2', 'pulse', 'respiration', 'temperature chart', 'spo2']]
  ];

  function topicFor(module) {
    const m = module || {};
    const hay = [
      m.title, m.category, m.shortDescription, m.description,
      (m.hazardsCovered || m.hazards || []).join(' ')
    ].join(' ').toLowerCase();
    for (let i = 0; i < KEYWORDS.length; i += 1) {
      const words = KEYWORDS[i][1];
      for (let j = 0; j < words.length; j += 1) {
        if (hay.indexOf(words[j]) !== -1) return KEYWORDS[i][0];
      }
    }
    if (hay.indexOf('elder') !== -1 || hay.indexOf('caregiver') !== -1) return 'dementia';
    return 'generic';
  }

  // ---------------------------------------------------------- svg pieces
  function header(topic, label, accent) {
    return '<rect width="' + W + '" height="' + H + '" fill="#F8FAFC"/>' +
      '<rect x="0" y="0" width="' + W + '" height="64" fill="' + accent + '"/>' +
      '<text x="28" y="41" font-family="Inter,Segoe UI,sans-serif" font-size="21" font-weight="700" fill="#FFFFFF">' + esc(label) + '</text>' +
      '<text x="772" y="41" text-anchor="end" font-family="IBM Plex Mono,monospace" font-size="13" fill="#FFFFFF" opacity="0.75">EVOLV3 CLINICAL</text>' +
      '<rect x="1" y="65" width="798" height="384" fill="none" stroke="#E2E8F0" stroke-width="2"/>' +
      '<text x="28" y="434" font-family="IBM Plex Mono,monospace" font-size="11" fill="#0B1220" opacity="0.45">Training illustration · not a diagnostic instrument</text>';
  }

  function card(x, y, w, h, title, lines, accent, fill) {
    let out = '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="12" fill="' + (fill || '#FFFFFF') + '" stroke="' + accent + '" stroke-width="2"/>' +
      '<text x="' + (x + 14) + '" y="' + (y + 26) + '" font-family="Inter,Segoe UI,sans-serif" font-size="15" font-weight="700" fill="' + accent + '">' + esc(title) + '</text>';
    (lines || []).forEach(function (line, i) {
      out += '<text x="' + (x + 14) + '" y="' + (y + 50 + i * 20) + '" font-family="Inter,Segoe UI,sans-serif" font-size="13" fill="#334155">' + esc(line) + '</text>';
    });
    return out;
  }

  function wrap(lines, size) {
    const out = [];
    const max = size || 15;
    (lines || []).forEach(function (raw) {
      const words = String(raw).split(/\s+/);
      let line = '';
      words.forEach(function (w) {
        if ((line + ' ' + w).trim().length > max) { out.push(line.trim()); line = w; }
        else line += ' ' + w;
      });
      if (line.trim()) out.push(line.trim());
    });
    return out;
  }

  // ---------------------------------------------------------- diagrams
  const DRAW = {};

  DRAW.ecg = function (a) {
    let pts = [];
    for (let i = 0; i < 620; i += 4) {
      let y = 240;
      if (i >= 150 && i <= 190) y = 240 - (i - 150) * 1.1;
      else if (i > 190 && i <= 205) y = 240 - 44 + (i - 190) * 5.2;
      else if (i > 205 && i <= 225) y = 240 + 34 - (i - 205) * 1.7;
      pts.push((120 + i) + ' ' + y.toFixed(1));
    }
    let grid = '';
    for (let x = 140; x < 700; x += 40) grid += '<path d="M' + x + ' 96v220"/>';
    for (let y = 126; y < 316; y += 30) grid += '<path d="M100 ' + y + 'h600"/>';
    return '<rect x="100" y="96" width="600" height="220" rx="14" fill="#07131F" stroke="' + a + '" stroke-width="2"/>' +
      '<g stroke="#134E4A" stroke-width="1" opacity="0.55">' + grid + '</g>' +
      '<polyline fill="none" stroke="#34D399" stroke-width="3" stroke-linejoin="round" points="' + pts.join(' ') + '"/>' +
      card(100, 336, 190, 84, 'BLOOD PRESSURE', ['Systolic / diastolic', 'Record and escalate'], a) +
      card(305, 336, 190, 84, 'SpO2 · PULSE', ['Oxygen saturation %', 'Rate per minute'], a) +
      card(510, 336, 190, 84, 'RESP · TEMP', ['Count for 60 seconds', 'Report changes early'], a);
  };

  DRAW.dementia = function (a) {
    let nodes = '';
    for (let i = 0; i < 14; i += 1) {
      const ang = (i * (360 / 14) * Math.PI) / 180;
      const r = i % 2 === 0 ? 70 : 108;
      const x = 210 + Math.cos(ang) * r;
      const y = 230 + Math.sin(ang) * r;
      nodes += '<path d="M210 230L' + x.toFixed(0) + ' ' + y.toFixed(0) + '" stroke="' + a + '" stroke-width="2" opacity="0.35"/>';
      nodes += '<circle cx="' + x.toFixed(0) + '" cy="' + y.toFixed(0) + '" r="' + (i % 3 ? 9 : 13) + '" fill="' + a + '" opacity="' + (i % 2 === 0 ? '0.85' : '0.5') + '"/>';
    }
    const stages = [['F', 'FACE', 'Ask the resident to smile'], ['A', 'ARMS', 'Lift both arms and hold'],
      ['S', 'SPEECH', 'Repeat a simple sentence'], ['T', 'TIME', 'Call emergency immediately']];
    return '<g>' + nodes + '</g>' +
      '<circle cx="210" cy="230" r="52" fill="#FFFFFF" stroke="' + a + '" stroke-width="3"/>' +
      '<text x="210" y="226" text-anchor="middle" font-family="Inter,sans-serif" font-size="15" font-weight="700" fill="' + a + '">BRAIN</text>' +
      '<text x="210" y="248" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" fill="#334155">neural change</text>' +
      '<text x="400" y="98" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#334155">FAST SCREENING · ESCALATE ANY POSITIVE</text>' +
      stages.map(function (s, i) {
        return card(400, 108 + i * 74, 372, 64, s[0] + ' · ' + s[1], [s[2]], a);
      }).join('');
  };

  DRAW.choking = function (a) {
    const steps = [['1', 'Recognise', 'Cannot speak, cough or breathe'],
      ['2', 'Position', '90-degree upright, chin level'],
      ['3', '5 back blows', 'Between the shoulder blades'],
      ['4', '5 thrusts', 'Above navel, inward and up'],
      ['5', 'Call emergency', 'Unresponsive: start CPR']];
    let out = '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" fill="#334155">90° CHOKING RESCUE SEQUENCE</text>';
    steps.forEach(function (s, i) {
      const x = 100 + i * 122;
      out += '<rect x="' + x + '" y="118" width="108" height="150" rx="12" fill="#FFFFFF" stroke="' + a + '" stroke-width="2"/>';
      out += '<circle cx="' + (x + 54) + '" cy="150" r="18" fill="' + a + '"/>';
      out += '<text x="' + (x + 54) + '" y="156" text-anchor="middle" font-family="Inter,sans-serif" font-size="15" font-weight="700" fill="#FFFFFF">' + s[0] + '</text>';
      out += '<text x="' + (x + 54) + '" y="192" text-anchor="middle" font-family="Inter,sans-serif" font-size="12.5" font-weight="700" fill="#334155">' + esc(s[1]) + '</text>';
      wrap([s[2]], 14).forEach(function (line, j) {
        out += '<text x="' + (x + 54) + '" y="' + (212 + j * 15) + '" text-anchor="middle" font-family="Inter,sans-serif" font-size="10.5" fill="#64748B">' + esc(line) + '</text>';
      });
      if (i < steps.length - 1) out += '<path d="M' + (x + 108) + ' 193h14" stroke="' + a + '" stroke-width="2"/>';
    });
    out += '<rect x="100" y="292" width="600" height="112" rx="12" fill="#FEF3C7" stroke="#F59E0B" stroke-width="2"/>' +
      '<text x="118" y="322" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#92400E">IDDSI + DYSPHAGIA PREVENTION</text>' +
      ['Sit upright 90°, never feed lying down · small spoonfuls',
        'No mixed textures · stop if coughing or wet voice',
        'Oral care before and after meals · document every episode'].map(function (t, i) {
        return '<text x="118" y="' + (348 + i * 22) + '" font-family="Inter,sans-serif" font-size="12" fill="#78350F">' + esc(t) + '</text>';
      }).join('');
    return out;
  };

  DRAW.bathing = function (a) {
    return '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" fill="#334155">SAFE BATHING · WATER AT 38°C</text>' +
      '<rect x="100" y="118" width="240" height="180" rx="16" fill="#E0F2FE" stroke="' + a + '" stroke-width="2"/>' +
      '<path d="M124 258h192" stroke="' + a + '" stroke-width="6" stroke-linecap="round"/>' +
      '<path d="M124 232c32-16 64 16 96 0s64 16 96 0" fill="none" stroke="#0284C7" stroke-width="3"/>' +
      '<circle cx="220" cy="176" r="46" fill="#FFFFFF" stroke="' + a + '" stroke-width="3"/>' +
      '<text x="220" y="170" text-anchor="middle" font-family="Inter,sans-serif" font-size="20" font-weight="700" fill="' + a + '">38°C</text>' +
      '<text x="220" y="190" text-anchor="middle" font-family="Inter,sans-serif" font-size="10.5" fill="#334155">elbow test</text>' +
      '<rect x="112" y="118" width="8" height="140" fill="#EF4444"/>' +
      '<text x="126" y="222" font-family="Inter,sans-serif" font-size="11" fill="#B91C1C">max 40°C</text>' +
      card(364, 118, 204, 84, 'BEFORE', ['Consent + privacy', 'Grab rails, non-slip mat'], a) +
      card(584, 118, 190, 84, 'DURING', ['Never leave alone', 'Check skin each minute'], a) +
      card(364, 214, 204, 84, 'AFTER', ['Dry skin folds', 'Check for red areas'], a) +
      card(584, 214, 190, 84, 'RECORD', ['Refusals + skin', 'Any scald reported'], a) +
      '<rect x="100" y="316" width="674" height="88" rx="12" fill="#F0FDFA" stroke="' + a + '" stroke-width="2"/>' +
      '<text x="118" y="344" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#0F766E">SCALD AND SKIN-TEAR PREVENTION</text>' +
      ['Run cold water first, then hot · test with your elbow',
        'Report any redness, blister or skin tear immediately'].map(function (t, i) {
        return '<text x="118" y="' + (368 + i * 22) + '" font-family="Inter,sans-serif" font-size="12" fill="#134E4A">' + esc(t) + '</text>';
      }).join('');
  };

  DRAW.transfer = function (a) {
    return '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" fill="#334155">GAIT-BELT PIVOT TRANSFER</text>' +
      '<rect x="100" y="120" width="300" height="210" rx="14" fill="#FFFFFF" stroke="' + a + '" stroke-width="2"/>' +
      '<rect x="132" y="196" width="130" height="18" rx="9" fill="#94A3B8"/>' +
      '<rect x="150" y="214" width="10" height="70" fill="#94A3B8"/>' +
      '<rect x="238" y="214" width="10" height="70" fill="#94A3B8"/>' +
      '<circle cx="196" cy="166" r="24" fill="#CBD5E1"/>' +
      '<path d="M196 190v10" stroke="#64748B" stroke-width="6" stroke-linecap="round"/>' +
      '<rect x="160" y="196" width="74" height="10" rx="5" fill="' + a + '"/>' +
      '<text x="196" y="150" text-anchor="middle" font-family="Inter,sans-serif" font-size="10.5" fill="#334155">resident</text>' +
      '<path d="M400 224h64" stroke="' + a + '" stroke-width="3" stroke-dasharray="7 6"/>' +
      '<path d="M456 214l14 10-14 10z" fill="' + a + '"/>' +
      '<text x="432" y="206" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" fill="#334155">pivot, do not lift</text>' +
      card(484, 120, 290, 210, 'SAFE SEQUENCE', [
        '1  Explain, gain consent, check brakes',
        '2  Bed at correct height, wheels locked',
        '3  Gait belt low and snug over clothing',
        '4  Feet flat, lean forward, nose over toes',
        '5  Pivot on command, keep back straight',
        '6  Lower slowly, then release the belt',
        '7  Never twist or lift the resident'
      ], a) +
      '<rect x="100" y="344" width="674" height="60" rx="12" fill="#FEF2F2" stroke="#EF4444" stroke-width="2"/>' +
      '<text x="118" y="370" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#991B1B">STOP IF: dizziness, new pain, unsteady feet, or the belt slips</text>' +
      '<text x="118" y="392" font-family="Inter,sans-serif" font-size="12" fill="#7F1D1D">Two caregivers for heavy residents · report every fall, even without injury</text>';
  };

  DRAW.sundowning = function (a) {
    return '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" fill="#334155">SUNDOWNING · 24-HOUR LIGHT PROTOCOL</text>' +
      '<rect x="100" y="120" width="600" height="120" rx="14" fill="#0F172A"/>' +
      '<rect x="100" y="120" width="300" height="120" fill="#FDE68A" opacity="0.85" rx="14"/>' +
      '<rect x="400" y="120" width="300" height="120" fill="#1E293B" rx="14"/>' +
      '<circle cx="220" cy="180" r="34" fill="#F59E0B"/>' +
      '<text x="220" y="186" text-anchor="middle" font-family="Inter,sans-serif" font-size="12" font-weight="700" fill="#78350F">MORNING</text>' +
      '<text x="220" y="216" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" fill="#78350F">30-60 min bright light</text>' +
      '<circle cx="550" cy="180" r="30" fill="#0EA5E9" opacity="0.5"/>' +
      '<text x="550" y="186" text-anchor="middle" font-family="Inter,sans-serif" font-size="12" font-weight="700" fill="#E0F2FE">EVENING</text>' +
      '<text x="550" y="216" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" fill="#E0F2FE">dim, warm, quiet</text>' +
      '<text x="400" y="164" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" fill="#94A3B8">17:00</text>' +
      card(100, 256, 320, 148, 'DE-ESCALATION AT DUSK', [
        'Lower noise, clutter and visitors',
        'Warm lamps on before sunset',
        'Familiar snack and routine',
        'Screen for pain or infection',
        'Calm orientation, never argue'
      ], a) +
      card(440, 256, 334, 148, 'AVOID', [
        'Sedation as a first response',
        'Bright overhead light after 18:00',
        'Missed pain, urine retention, sepsis',
        'Unfamiliar carers at sundown',
        'Melatonin without prescriber review'
      ], '#EF4444', '#FEF2F2');
  };

  DRAW.medication = function (a) {
    const days = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    let out = '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" fill="#334155">5 RIGHTS · MEDICATION ORGANISER</text>';
    days.forEach(function (d, i) {
      const x = 100 + i * 96;
      out += '<rect x="' + x + '" y="118" width="84" height="150" rx="10" fill="#FFFFFF" stroke="' + a + '" stroke-width="2"/>';
      out += '<text x="' + (x + 42) + '" y="140" text-anchor="middle" font-family="IBM Plex Mono,monospace" font-size="11" font-weight="700" fill="' + a + '">' + d + '</text>';
      ['AM', 'NOON', 'PM'].forEach(function (slot, j) {
        out += '<circle cx="' + (x + 42) + '" cy="' + (170 + j * 34) + '" r="13" fill="' + a + '" opacity="0.18"/>';
        out += '<text x="' + (x + 42) + '" y="' + (174 + j * 34) + '" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" fill="#334155">' + slot + '</text>';
      });
    });
    ['PERSON', 'DRUG', 'DOSE', 'ROUTE', 'TIME'].forEach(function (v, i) {
      const x = 100 + i * 138;
      out += '<rect x="' + x + '" y="288" width="126" height="66" rx="10" fill="#F0FDFA" stroke="' + a + '" stroke-width="2"/>';
      out += '<text x="' + (x + 63) + '" y="312" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" fill="#0F766E">RIGHT</text>';
      out += '<text x="' + (x + 63) + '" y="336" text-anchor="middle" font-family="Inter,sans-serif" font-size="15" font-weight="700" fill="' + a + '">' + v + '</text>';
    });
    out += '<text x="100" y="382" font-family="Inter,sans-serif" font-size="12" fill="#334155">Document every dose given, refused or omitted · report adverse reactions immediately</text>';
    return out;
  };

  DRAW.stroke = function (a) {
    return '<text x="100" y="100" font-family="Inter,sans-serif" font-size="14" font-weight="700" fill="#334155">STROKE · FAST TRIAGE AND 3.5-HOUR WINDOW</text>' +
      '<circle cx="220" cy="240" r="96" fill="#FEF2F2" stroke="#EF4444" stroke-width="3"/>' +
      '<text x="220" y="226" text-anchor="middle" font-family="Inter,sans-serif" font-size="44" font-weight="800" fill="#DC2626">FAST</text>' +
      '<text x="220" y="252" text-anchor="middle" font-family="Inter,sans-serif" font-size="12" fill="#991B1B">FACE · ARMS · SPEECH · TIME</text>' +
      '<text x="220" y="276" text-anchor="middle" font-family="Inter,sans-serif" font-size="11" fill="#7F1D1D">last known well = the clock</text>' +
      card(348, 118, 426, 68, 'F · FACE', ['Ask the resident to smile · look for one-sided droop'], a) +
      card(348, 194, 426, 68, 'A · ARMS', ['Lift both arms for 10 seconds · one drifts down'], a) +
      card(348, 270, 426, 68, 'S · SPEECH', ['Repeat a sentence · slurred, wrong or absent words'], a) +
      '<rect x="100" y="348" width="674" height="60" rx="12" fill="#DC2626"/>' +
      '<text x="118" y="374" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#FFFFFF">T · TIME · CALL EMERGENCY NOW · NOTE THE LAST KNOWN WELL TIME</text>' +
      '<text x="118" y="396" font-family="Inter,sans-serif" font-size="12" fill="#FEE2E2">Nothing by mouth · do not give aspirin · stay with the resident</text>';
  };

  DRAW.generic = function (a, m) {
    let petals = '';
    for (let i = 0; i < 8; i += 1) {
      const ang = (i * 45 * Math.PI) / 180;
      petals += '<circle cx="' + (230 + Math.cos(ang) * 78).toFixed(0) + '" cy="' + (228 + Math.sin(ang) * 78).toFixed(0) + '" r="34" fill="' + a + '" opacity="0.22"/>';
    }
    const cat = String((m && m.category) || 'Clinical Care').toUpperCase().slice(0, 34);
    return '<g>' + petals + '</g>' +
      '<circle cx="230" cy="228" r="56" fill="#FFFFFF" stroke="' + a + '" stroke-width="3"/>' +
      '<path d="M230 200v56M202 228h56" stroke="' + a + '" stroke-width="8" stroke-linecap="round"/>' +
      '<text x="230" y="330" text-anchor="middle" font-family="Inter,sans-serif" font-size="13" font-weight="700" fill="#334155">' + esc(cat) + '</text>' +
      card(360, 108, 414, 108, 'MODULE FOCUS', [
        String((m && m.title) || 'Caregiver module').slice(0, 52),
        'Person-centred, safe, documented care',
        'Escalate any deterioration immediately'
      ], a) +
      card(360, 230, 414, 108, 'WHAT GOOD CARE LOOKS LIKE', [
        'Observe, record and report changes',
        'Work within your scope of practice',
        'Protect dignity, privacy and consent'
      ], a) +
      '<rect x="100" y="360" width="674" height="48" rx="12" fill="#F0FDFA" stroke="' + a + '" stroke-width="2"/>' +
      '<text x="118" y="390" font-family="Inter,sans-serif" font-size="12" fill="#0F766E">Follow the facility protocol, escalate early and document every action you take.</text>';
  };

  // ---------------------------------------------------------- public API
  function topicSvg(module) {
    const topic = topicFor(module);
    const meta = TOPICS[topic] || TOPICS.generic;
    const draw = DRAW[topic] || DRAW.generic;
    return '<svg xmlns="' + NS + '" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H +
      '" preserveAspectRatio="xMidYMid slice" role="img" aria-label="' + esc(meta.label) + '">' +
      header(topic, meta.label, meta.accent) + draw(meta.accent, module) + '</svg>';
  }

  function dataUri(svg) {
    const b64 = btoa(unescape(encodeURIComponent(svg)));
    return 'data:image/svg+xml;base64,' + b64;
  }

  /**
   * ModuleArtwork(module, options) -> HTML string
   *   module:  { title, category, shortDescription, description,
   *              hazardsCovered|hazards, imageUrl }
   *   options: { className, ai: true } — `ai` marks the AI illustration.
   *
   * Renders the stored image, and if it is missing or fails to load the
   * browser swaps in the topic SVG. The <noscript>-free fallback is inline,
   * so the box is never empty.
   */
  function ModuleArtwork(module, options) {
    const m = module || {};
    const opts = options || {};
    const fallback = dataUri(topicSvg(m));
    const stored = typeof m.imageUrl === 'string' ? m.imageUrl.trim() : '';
    const src = stored || fallback;
    const cls = 'module-artwork' + (opts.className ? ' ' + opts.className : '') + (opts.ai || stored ? ' is-ai' : ' is-svg');
    return '<figure class="' + cls + '" data-topic="' + topicFor(m) + '">' +
      '<img src="' + esc(src) + '" alt="' + esc(m.title || 'Module artwork') + ' clinical illustration" ' +
      'width="' + W + '" height="' + H + '" loading="lazy" decoding="async" ' +
      'onerror="window.EVOLV3_ARTWORK.fail(this)" data-fallback="' + esc(fallback) + '">' +
      '</figure>';
  }

  function fail(img) {
    if (!img || img.dataset.recovered === '1') return;
    const fb = img.dataset.fallback || '';
    if (!fb) return;
    img.dataset.recovered = '1';
    img.src = fb;
    const fig = img.closest('.module-artwork');
    if (fig) { fig.classList.remove('is-ai'); fig.classList.add('is-svg'); }
  }

  /**
   * Ask the backend for an AI illustration and store it on the module.
   * Never throws: on any failure the deterministic topic SVG is returned so
   * the caller always has something to show.
   */
  async function generate(module, options) {
    const m = module || {};
    const opts = options || {};
    const api = (window.ACADEMY && window.ACADEMY.api) || null;
    const payload = {
      moduleId: m.id || '',
      title: m.title || '',
      category: m.category || '',
      shortDescription: m.shortDescription || m.description || '',
      hazardsCovered: m.hazardsCovered || m.hazards || []
    };
    try {
      if (!api) throw new Error('offline');
      const res = await api('/api/evolv3/generate-module-image', 'POST', payload);
      if (res && res.imageUrl) {
        m.imageUrl = res.imageUrl;
        m.imageEngine = res.engine || 'local-svg';
        return { imageUrl: res.imageUrl, engine: m.imageEngine, saved: !!res.saved, fallback: false };
      }
      throw new Error('no image');
    } catch (err) {
      const local = dataUri(topicSvg(m));
      return { imageUrl: local, engine: 'local-svg', saved: false, fallback: true, error: String(err && err.message || err) };
    }
  }

  const API = {
    ModuleArtwork: ModuleArtwork,
    topicSvg: topicSvg,
    topicFor: topicFor,
    dataUri: dataUri,
    fail: fail,
    generate: generate,
    TOPICS: TOPICS
  };

  window.EVOLV3_ARTWORK = API;

  // React component when a React host is present; the same name returns the
  // identical markup so the vanilla Academy keeps working unchanged.
  if (window.React && typeof window.React.createElement === 'function') {
    window.ModuleArtwork = function (props) {
      const html = ModuleArtwork(props && (props.module || props), props || {});
      return window.React.createElement('div', {
        className: 'module-artwork-host',
        dangerouslySetInnerHTML: { __html: html }
      });
    };
  } else {
    window.ModuleArtwork = ModuleArtwork;
  }
})();
