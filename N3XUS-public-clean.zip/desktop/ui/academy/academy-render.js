/* ============================================================
   EVOLV3 Academy — renderers: courses, library, evaluations.
   ============================================================ */
(function () {
  'use strict';
  const A = window.ACADEMY;
  const D = A.D;
  const S = A.S;
  const { $, $$, esc, nf, pct, toast } = A.U;

  // ---------------------------------------------------------- course artwork
  // Section 11: real clinical illustration. Order of preference is the stored
  // AI image (imageUrl), then the topic-matched ModuleArtwork SVG. The
  // decorative teal art() below is kept only as the final layer, so a card can
  // never render a bare heart or an empty box.
  function artSvg(course) {
    const Art = window.EVOLV3_ARTWORK;
    if (Art && typeof Art.topicSvg === 'function') {
      try { return Art.topicSvg(course); } catch (e) { /* fall through */ }
    }
    return art(course);
  }

  function artwork(course) {
    const Art = window.EVOLV3_ARTWORK;
    if (Art && typeof Art.ModuleArtwork === 'function') {
      try { return Art.ModuleArtwork(course, { className: 'course-artwork' }); } catch (e) { /* fall through */ }
    }
    return '<svg viewBox="0 0 800 450" preserveAspectRatio="xMidYMid slice" role="img" aria-label="' +
      esc(course.title) + '">' + artSvg(course) + '</svg>';
  }

  function art(course) {
    const tones = D.ART_TONES[course.category] || ['#0f766e', '#115e59', '#042f2e'];
    const glyph = D.GLYPHS[course.glyph] || D.GLYPHS.shield;
    const gid = 'g' + String(course.id).replace(/[^a-z0-9]/gi, '');
    const ghost = Number(course.n) >= 100 ? 'W' + Number(course.weekAdded || 0) : String(course.n).padStart(2, '0');
    return '<svg viewBox="0 0 640 360" preserveAspectRatio="xMidYMid slice" role="img" aria-label="' + esc(course.title) + '">' +
      '<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="' + tones[0] + '"/><stop offset="0.58" stop-color="' + tones[1] + '"/><stop offset="1" stop-color="' + tones[2] + '"/>' +
      '</linearGradient><radialGradient id="' + gid + 'r" cx="0.82" cy="0.12" r="0.9">' +
      '<stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/>' +
      '</radialGradient></defs>' +
      '<rect width="640" height="360" fill="url(#' + gid + ')"/>' +
      '<rect width="640" height="360" fill="url(#' + gid + 'r)"/>' +
      '<g opacity="0.16" stroke="#ffffff" stroke-width="1">' +
      '<path d="M0 90h640M0 180h640M0 270h640M160 0v360M320 0v360M480 0v360"/></g>' +
      '<circle cx="520" cy="76" r="118" fill="#ffffff" opacity="0.07"/>' +
      '<circle cx="520" cy="76" r="76" fill="#ffffff" opacity="0.05"/>' +
      '<text x="26" y="330" font-family="IBM Plex Mono, monospace" font-size="112" font-weight="600" fill="#ffffff" opacity="0.13">' + esc(ghost) + '</text>' +
      '<g transform="translate(255 112) scale(5.2)" fill="none" stroke="#ffffff" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" opacity="0.95">' + glyph + '</g>' +
      '</svg>';
  }

  // ---------------------------------------------------------- header
  function renderHeader() {
    const L = S.learner;
    const timer = $('#timer-value');
    if (timer) timer.textContent = nf(L.minutesStudied);
    const pts = $('#points-value');
    if (pts) pts.textContent = nf(L.points);
    const name = $('#profile-name');
    if (name) name.textContent = L.displayName || 'Sign in';
    const role = $('#profile-role');
    if (role) role.textContent = L.role || 'Public';
    const av = $('#profile-avatar');
    if (av) av.textContent = (L.displayName || 'BR').trim().split(/\s+/).slice(0, 2).map((x) => x[0] || '').join('').toUpperCase() || 'BR';
    const week = $('#week-chip');
    if (week) week.textContent = 'W' + (S.evolutionState.weekNumber || 1);
    const holder = $('#cert-holder');
    if (holder) holder.textContent = 'Holder · ' + (L.displayName || 'Not signed in');
  }

  // ---------------------------------------------------------- courses
  function matchesCourse(c, q) {
    if (!q) return true;
    const hay = [c.title, c.description, c.category, (c.highlights || []).join(' '), (c.hazards || []).join(' ')].join(' ').toLowerCase();
    return q.split(/\s+/).filter(Boolean).every((part) => hay.indexOf(part) !== -1);
  }

  function statusOf(c) {
    const L = S.learner;
    if (L.completions[c.id]) return { cls: 'passed', label: 'PASSED' };
    if (L.enrolled.indexOf(c.id) !== -1) return { cls: 'enrolled', label: 'ENROLLED' };
    return { cls: 'none', label: 'NOT ENROLLED' };
  }

  function courseCard(c) {
    const st = statusOf(c);
    const isNew = !!c.isNewAutonomous;
    const hours = Number(c.hours || 0);
    const hazards = (c.hazards || []).slice(0, 3);
    const highlights = (c.highlights || []).slice(0, 3);
    return '<article class="course-card" data-course="' + esc(c.id) + '">' +
      '<div class="course-art">' + artwork(c) +
        '<div class="art-badges">' +
          (isNew ? '<span class="art-badge new">NEW · WEEK ' + esc(c.weekAdded || '') + '</span>' : '') +
          '<span class="art-badge">' + esc(c.category) + '</span>' +
          (c.imageUrl ? '<span class="art-badge ai">AI ART</span>' : '<span class="art-badge video">▶ Video Clip</span>') +
        '</div>' +
        '<span class="art-hours mono">' + hours + ' hrs</span>' +
      '</div>' +
      '<div class="course-body">' +
        '<div class="course-topline"><span class="course-cat">' + esc(c.category) + '</span><span class="status-tag ' + st.cls + '">' + st.label + '</span></div>' +
        '<h3 class="course-title">' + esc(c.title) + '</h3>' +
        '<p class="course-desc">' + esc(c.description || '') + '</p>' +
        '<ul class="course-highlights">' + highlights.map((h) => '<li>' + esc(h) + '</li>').join('') + '</ul>' +
        '<div class="hazard-row">' + hazards.map((h) => '<span class="hazard-tag">⚑ ' + esc(h) + '</span>').join('') + '</div>' +
        '<div class="course-actions">' +
          '<button class="btn btn-primary btn-small" data-open-course="' + esc(c.id) + '">Open Details</button>' +
          (st.cls === 'none'
            ? '<button class="btn btn-secondary btn-small" data-enroll="' + esc(c.id) + '">Enrol</button>'
            : '<button class="btn btn-secondary btn-small" data-quick-eval="' + esc(c.id) + '">Evaluate</button>') +
          '<button class="btn btn-ghost btn-small icon-action" data-share="' + esc(c.id) + '" title="Copy share link" aria-label="Share course">↗</button>' +
          '<button class="btn btn-ghost btn-small icon-action" data-quick-eval="' + esc(c.id) + '" title="Quick evaluate" aria-label="Quick evaluate">✦</button>' +
        '</div>' +
        '<div class="course-actions">' +
          '<button class="btn btn-secondary btn-small ai-image-btn" data-gen-image="' + esc(c.id) + '" title="Generate a clinical illustration for this module">🎨 AI Generate Image</button>' +
        '</div>' +
      '</div>' +
    '</article>';
  }

  function renderCourses() {
    const all = A.allCourses();
    const q = S.courseQuery.trim().toLowerCase();
    const list = all.filter((c) => (S.courseCategory === 'All' || c.category === S.courseCategory) && matchesCourse(c, q));
    const grid = $('#course-grid');
    if (!grid) return;
    grid.innerHTML = list.map(courseCard).join('');
    const empty = $('#course-empty');
    if (empty) empty.classList.toggle('hidden', list.length > 0);
    const baseHours = D.COURSES.reduce((a, c) => a + Number(c.hours || 0), 0);
    const weeklyHours = S.weeklyModules.reduce((a, c) => a + Number(c.hours || 0), 0);
    const meta = $('#course-meta');
    if (meta) meta.textContent = list.length + ' of ' + all.length + ' modules · ' + (baseHours + weeklyHours) + ' course hours';
  }

  function openCourse(id) {
    const c = A.moduleById(id);
    if (!c) return;
    const st = statusOf(c);
    const L = S.learner;
    const body = '<div class="modal-hero">' +
        '<div class="course-art" style="border-radius:10px;overflow:hidden" id="modal-course-art">' + artwork(c) + '</div>' +
        '<div><div class="eyebrow">' + esc(c.category) + (c.isNewAutonomous ? ' · NEW WEEK ' + esc(c.weekAdded || '') : '') + '</div>' +
        '<h3 style="font-size:19px;margin:4px 0 6px">' + esc(c.title) + '</h3>' +
        '<p class="muted" style="font-size:11.5px">' + esc(c.description || '') + '</p>' +
        '<div class="pill-row" style="margin-top:9px"><span class="tag">' + Number(c.hours || 0) + ' hours</span><span class="tag">Video simulation</span><span class="tag routed">' + st.label + '</span></div></div>' +
      '</div>' +
      '<div class="modal-section"><h4>Curriculum highlights</h4><ul class="course-highlights">' + (c.highlights || []).map((h) => '<li>' + esc(h) + '</li>').join('') + '</ul></div>' +
      '<div class="modal-section"><h4>Hazards covered</h4><div class="hazard-row">' + (c.hazards || []).map((h) => '<span class="hazard-tag">⚑ ' + esc(h) + '</span>').join('') + '</div></div>' +
      '<div class="modal-section"><h4>Video simulation · timestamps &amp; audio/visual breakdown</h4><div class="timestamp-list">' +
        (c.video || []).map((v) => '<div class="timestamp"><b>' + esc(v.t || '00:00') + '</b><div>' + esc(v.label || '') + '<small>' + esc(v.av || '') + '</small></div></div>').join('') +
      '</div></div>' +
      '<div class="modal-section"><h4>Assessment</h4><p style="font-size:11px;color:var(--muted)">Quick Evaluate opens the true-match assessment bank filtered to this module. 60% passes; retakes are unlimited.</p></div>' +
      '<div class="modal-section"><h4>Clinical illustration</h4><p style="font-size:11px;color:var(--muted)">Generate a topic-specific 800×450 clinical diagram with AI. It is saved to this module and reused for the card and the video clip thumbnails.</p><button class="btn btn-secondary btn-small ai-image-btn" data-gen-image="' + esc(c.id) + '">🎨 AI Generate Image</button></div>';
    const foot = '<button class="btn btn-ghost" data-share="' + esc(c.id) + '">Share link</button>' +
      '<button class="btn btn-secondary" data-quick-eval="' + esc(c.id) + '">Quick Evaluate</button>' +
      (st.cls === 'none'
        ? '<button class="btn btn-primary" data-enroll="' + esc(c.id) + '">Enrol · +50 pts</button>'
        : '<button class="btn btn-primary" data-quick-eval="' + esc(c.id) + '">Continue assessment</button>');
    A.openModal('Course details', c.isNewAutonomous ? 'Weekly autonomous module' : 'Bundled internal module', body, foot, 'wide');
  }

  // ---------------------------------------------------------- library
  function flipCard(card) {
    return '<div class="flip-card" data-tone="' + esc(card.tone) + '" data-card="' + esc(card.code) + '">' +
      '<div class="flip-inner">' +
        '<div class="flip-face flip-front">' +
          '<div class="flip-head"><div><div class="flip-code">' + esc(card.code) + ' · Quick-glance</div><div class="flip-title">' + esc(card.title) + '</div></div><div class="flip-diagram">' + esc(card.icon) + '</div></div>' +
          '<div class="flip-body">' +
            '<div class="flip-label">Immediate warning signs</div>' +
            '<ul class="flip-signs">' + card.signs.map((s) => '<li>' + esc(s) + '</li>').join('') + '</ul>' +
            '<div class="do-not"><b>DO NOT</b><span>' + card.donts.map(esc).join(' ' ) + '</span></div>' +
          '</div>' +
          '<div class="flip-foot"><span class="flip-hint">Tap to flip 180° ↻</span><button class="flip-read" data-read-card="' + esc(card.code) + '">🔊 Read Card</button></div>' +
        '</div>' +
        '<div class="flip-face flip-back">' +
          '<div class="flip-head"><div><div class="flip-code" style="color:#94a3b8">' + esc(card.code) + ' · Action plan</div><div class="flip-title">' + esc(card.title) + '</div></div><div class="flip-diagram" style="background:#1e293b;color:#99f6e4">↺</div></div>' +
          '<div class="flip-body">' +
            '<div class="flip-label" style="color:#94a3b8">Numbered steps</div>' +
            '<ol class="flip-steps">' + card.steps.map((s) => '<li>' + esc(s) + '</li>').join('') + '</ol>' +
            '<div class="cue-tags">' + card.cues.map((c) => '<span class="cue-tag">' + esc(c) + '</span>').join('') + '</div>' +
            '<div class="golden-rule"><b>GOLDEN RULE</b><span>' + esc(card.golden) + '</span></div>' +
          '</div>' +
          '<div class="flip-foot"><button class="flip-read" data-copy-card="' + esc(card.code) + '">Copy steps</button><button class="flip-read" data-read-card="' + esc(card.code) + '">🔊 Listen</button></div>' +
        '</div>' +
      '</div></div>';
  }

  function protocolMarkup(p) {
    return '<details class="protocol' + (p.pinned ? ' pinned' : '') + '" data-protocol="' + esc(p.id) + '">' +
      '<summary><span class="proto-dot ' + esc(p.urgency) + '"></span><div><span class="protocol-title">' + esc(p.title) + '</span><span class="protocol-sub">' + esc(p.summary || '') + '</span></div>' +
        '<div class="proto-tags"><span class="tag ' + esc(String(p.urgency).toLowerCase()) + '">' + esc(p.urgency) + '</span><span class="tag">' + esc(p.category) + '</span>' +
        '<button class="table-action" data-pin="' + esc(p.id) + '" title="Pin to top">' + (p.pinned ? 'Unpin' : 'Pin') + '</button></div>' +
      '</summary>' +
      '<div class="proto-body"><p>' + esc(p.summary || '') + '</p><ol class="proto-steps">' + (p.steps || []).map((s) => '<li>' + esc(s) + '</li>').join('') + '</ol>' +
        '<div class="proto-actions"><button class="btn btn-secondary btn-small" data-copy-protocol="' + esc(p.id) + '">Copy protocol</button>' +
        (p.weekAdded ? '<span class="tag">NEW · WEEK ' + esc(p.weekAdded) + '</span>' : '') + '</div></div>' +
    '</details>';
  }

  function renderLibrary() {
    const grid = $('#flip-grid');
    if (grid) grid.innerHTML = D.FLIP_CARDS.map(flipCard).join('');

    const all = A.allProtocols();
    const cats = Array.from(new Set(all.map((p) => p.category))).sort();
    const catSelect = $('#protocol-category');
    if (catSelect) {
      const current = S.protocolCategory;
      catSelect.innerHTML = '<option value="">All categories</option>' + cats.map((c) => '<option' + (c === current ? ' selected' : '') + '>' + esc(c) + '</option>').join('');
    }
    const q = S.protocolQuery.trim().toLowerCase();
    const list = all.filter((p) => {
      if (S.protocolCategory && p.category !== S.protocolCategory) return false;
      if (S.protocolUrgency && p.urgency !== S.protocolUrgency) return false;
      if (!q) return true;
      const hay = [p.title, p.category, p.urgency, p.summary, (p.steps || []).join(' ')].join(' ').toLowerCase();
      return q.split(/\s+/).filter(Boolean).every((part) => hay.indexOf(part) !== -1);
    }).sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned));
    const host = $('#protocol-list');
    if (host) host.innerHTML = list.length ? list.map(protocolMarkup).join('') : '<div class="empty-state">No protocols match that filter.</div>';
    const meta = $('#protocol-meta');
    if (meta) meta.textContent = list.length + ' of ' + all.length + ' protocols · offline-ready';
  }

  function emsScript() {
    return [
      'EMS / 911 HANDOVER SCRIPT — Beyond Registration Academy',
      'Caller name: ____________________   Call-back number: ____________________',
      'Service / facility: ____________________   Unit / room: ____________________',
      'Resident name and age: ____________________',
      'Exact location and access notes: ____________________',
      'What happened (one line): ____________________',
      'Time last seen well / time of onset: ____________________',
      'Conscious? Yes / No   Breathing? Yes / No   Pulse present? Yes / No',
      'Known conditions: ____________________',
      'Medicines, especially blood thinners: ____________________',
      'Allergies: ____________________',
      'Observed signs and interventions already given: ____________________',
      'Who is meeting EMS at the door: ____________________',
      'Stay on the line until the dispatcher ends the call. Document the reference number.'
    ].join('\n');
  }

  // ---------------------------------------------------------- evaluations
  function evalItem(item) {
    const isGenerated = String(item.id).indexOf('gen-') === 0;
    const isWeekly = String(item.id).indexOf('evolv3-week-') === 0;
    let controls = '';
    if (item.kind === 'quiz') {
      const picked = S.quizPicks[item.id];
      controls = '<div class="option-list">' + (item.options || []).map((opt, i) => {
        const letter = String.fromCharCode(65 + i);
        return '<button class="option' + (picked === opt ? ' selected' : '') + '" data-option="' + esc(item.id) + '" data-value="' + esc(opt) + '"><span class="option-letter">' + letter + '</span><span>' + esc(opt) + '</span></button>';
      }).join('') + '</div>';
    } else {
      controls = '<textarea class="eval-answer" data-answer="' + esc(item.id) + '" placeholder="Write a specific clinical answer. Name the first action, the risk you are preventing and who you would escalate to.">' + esc(S.evalAnswers[item.id] || '') + '</textarea>';
    }
    return '<article class="eval-item' + (isGenerated ? ' is-new' : '') + '" data-eval="' + esc(item.id) + '">' +
      '<div class="eval-meta"><span class="tag ' + (isWeekly ? 'urgent' : '') + '">' + esc(item.moduleTitle || 'Academy') + '</span>' +
        (isGenerated ? '<span class="tag emergency">AI GENERATED</span>' : '') +
        (isWeekly ? '<span class="tag">NEW · WEEK ' + esc(item.weekAdded || '') + '</span>' : '') +
        '<span class="tag">' + (item.kind === 'quiz' ? 'Quiz' : item.kind === 'assignment' ? 'Mini assignment' : 'Short question') + '</span>' +
      '</div>' +
      '<div class="eval-prompt">' + esc(item.prompt) + '</div>' +
      '<div class="eval-helper">' + (item.kind === 'quiz' ? 'Choose the single safest clinical option.' : 'Scored 0–100% True Match. 60% is the internal pass standard.') + '</div>' +
      controls +
      '<div class="eval-actions"><button class="btn btn-primary btn-small" data-submit-eval="' + esc(item.id) + '">Submit for AI grading</button>' +
        '<button class="btn btn-ghost btn-small" data-retake-eval="' + esc(item.id) + '">Clear</button>' +
        '<span class="eval-hint">Instant local clinical engine · ' + (item.kind === 'assignment' ? '+40 XP pass' : '+30 XP pass') + '</span></div>' +
      '<div class="result-inline" id="result-' + esc(item.id) + '"></div>' +
    '</article>';
  }

  function renderEvaluations() {
    const all = A.allEvaluations();
    const filter = $('#eval-module-filter');
    if (filter) {
      const modules = [];
      all.forEach((e) => {
        if (e.moduleId && !modules.some((m) => m.id === e.moduleId)) modules.push({ id: e.moduleId, title: e.moduleTitle || e.moduleId });
      });
      const current = S.evalModule;
      filter.innerHTML = '<option value="">All modules</option>' + modules.map((m) => '<option value="' + esc(m.id) + '"' + (m.id === current ? ' selected' : '') + '>' + esc(m.title) + '</option>').join('');
    }
    const items = all.filter((e) => e.kind === S.evalKind && (!S.evalModule || e.moduleId === S.evalModule));
    const host = $('#eval-list');
    if (host) host.innerHTML = items.length ? items.map(evalItem).join('') : '<div class="empty-state">No evaluations in this bank yet. Use “AI Generate New Question”.</div>';
    $$('#eval-tabs .eval-tab').forEach((b) => b.classList.toggle('is-active', b.dataset.kind === S.evalKind));
    const bank = $('#bank-chip');
    if (bank) {
      const combinations = (13 + S.weeklyModules.length) * 3 * 3 * 3 * 320;
      bank.textContent = new Intl.NumberFormat('en-US').format(combinations) + '+ question combinations';
    }
    renderScorePanel();
    renderSocialBadges();
  }

  function renderScorePanel() {
    const r = S.lastResult;
    const ring = $('#score-ring');
    const value = $('#score-value');
    const verdict = $('#score-verdict');
    const feedback = $('#score-feedback');
    const improve = $('#improve-list');
    if (r) {
      if (ring) ring.style.setProperty('--pct', r.score);
      if (value) value.textContent = r.score + '%';
      if (verdict) verdict.textContent = r.passed ? 'PASS · True Match' : 'Not yet passing';
      if (feedback) feedback.textContent = r.feedback || '';
      if (improve) improve.innerHTML = (r.improvements || []).map((x) => '<div>' + esc(x) + '</div>').join('');
    } else {
      if (ring) ring.style.setProperty('--pct', 0);
      if (value) value.textContent = '—';
      if (verdict) verdict.textContent = 'No attempt yet';
      if (feedback) feedback.textContent = 'Choose an evaluation and submit a clinical answer.';
      if (improve) improve.innerHTML = '';
    }
    const hist = $('#eval-history');
    if (hist) {
      const attempts = (S.learner.attempts || []).slice(-6).reverse();
      hist.innerHTML = attempts.length ? attempts.map((a) => '<div class="mini-row"><div><b>' + a.score + '%</b><small>' + esc(a.moduleTitle || a.kind) + ' · ' + A.U.shortDate((a.date || '').slice(0, 10)) + '</small></div><span class="tag ' + (a.score >= 60 ? 'routine' : 'emergency') + '">' + (a.score >= 60 ? 'Pass' : 'Retry') + '</span></div>').join('') : '<span class="muted" style="font-size:10px">No attempts recorded.</span>';
    }
  }

  function renderSocialBadges() {
    const L = S.learner;
    const unlocked = D.BADGES.filter((b) => {
      try { return !!b.test(L); } catch (e) { return false; }
    }).map((b) => b.id);
    L.badges = unlocked;
    const host = $('#badge-grid');
    if (host) {
      host.innerHTML = D.BADGES.map((b) => '<div class="badge' + (unlocked.indexOf(b.id) !== -1 ? ' unlocked' : '') + '" title="' + esc(b.requirement) + '"><div class="badge-icon">' + b.icon + '</div><b>' + esc(b.name) + '</b><small>' + (unlocked.indexOf(b.id) !== -1 ? 'Unlocked' : 'Locked') + '</small></div>').join('');
    }
  }

  A.art = art;
  A.renderHeader = renderHeader;
  A.renderCourses = renderCourses;
  A.openCourse = openCourse;
  A.renderLibrary = renderLibrary;
  A.renderEvaluations = renderEvaluations;
  A.renderScorePanel = renderScorePanel;
  A.renderSocialBadges = renderSocialBadges;
  A.emsScript = emsScript;
})();
