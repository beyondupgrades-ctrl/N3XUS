/* ============================================================
   EVOLV3 Academy — curriculum & clinical content.
   All content is internal workforce upskilling material.
   ============================================================ */
window.ACADEMY_DATA = (function () {
  'use strict';

  const CATEGORIES = ['All', 'Fundamentals', 'Dementia Care', 'Safety & First Aid', 'Daily Care & Mobility', 'Communication'];

  const COURSES = [
    {
      id: 'brc-01', n: 1, title: 'Knowledge for Caregivers Based on Elderly Patients', category: 'Fundamentals', hours: 12,
      glyph: 'heart',
      description: 'The professional baseline for eldercare: dignity, consent, observation, documentation and the ageing body.',
      highlights: ['Person-centred dignity, privacy and consent', 'Vital-sign, skin and hydration observation', 'Safe documentation and shift handover'],
      hazards: ['Missed deterioration', 'Unsafe restraint', 'Loss of dignity'],
      video: [
        { t: '00:00', label: 'Dignity-first morning routine', av: 'Visual: bedside sequence · Audio: calm coaching' },
        { t: '06:40', label: 'Observing without disturbing', av: 'Visual: close-up checks · Audio: clinical narration' },
        { t: '14:10', label: 'Handover that prevents harm', av: 'Visual: SBAR sheet · Audio: two-person dialogue' }
      ]
    },
    {
      id: 'brc-02', n: 2, title: 'Understanding Dementia', category: 'Dementia Care', hours: 16,
      glyph: 'brain',
      description: 'How dementia changes memory, language, perception and behaviour — and why behaviour is always communication.',
      highlights: ['Alzheimer’s, vascular, Lewy body and frontotemporal patterns', 'Stages, fluctuations and retained abilities', 'Behaviour as an unmet need'],
      hazards: ['Wandering', 'Unrecognised pain', 'Delirium superimposed on dementia'],
      video: [
        { t: '00:00', label: 'Inside the dementia experience', av: 'Visual: first-person simulation · Audio: immersive sound' },
        { t: '09:15', label: 'Four common dementia types', av: 'Visual: brain comparison · Audio: clinical narration' },
        { t: '18:30', label: 'Behaviour as communication', av: 'Visual: trigger map · Audio: case discussion' }
      ]
    },
    {
      id: 'brc-03', n: 3, title: 'Safety Precautions for Dementia Patients', category: 'Safety & First Aid', hours: 10,
      glyph: 'shield',
      description: 'Wandering, exit-seeking, poisoning, scalds and kitchen risk — practical environmental safeguards that preserve autonomy.',
      highlights: ['Door, window and stair risk assessment', 'Medication and cleaning-product lockdown', 'Wandering response without restraint'],
      hazards: ['Exit-seeking', 'Poisoning', 'Scalds and burns'],
      video: [
        { t: '00:00', label: 'Room-by-room hazard sweep', av: 'Visual: annotated home · Audio: checklist narration' },
        { t: '07:25', label: 'Responding to exit-seeking', av: 'Visual: doorway scene · Audio: de-escalation coaching' },
        { t: '15:00', label: 'Safe kitchen setup', av: 'Visual: appliance close-ups · Audio: instruction' }
      ]
    },
    {
      id: 'brc-04', n: 4, title: 'How to Deal with Patients with Dementia', category: 'Communication', hours: 14,
      glyph: 'chat',
      description: 'Validation, redirection, short sentences and visual cues for moments of confusion, refusal and repetition.',
      highlights: ['Validation before correction', 'Choice-giving instead of open questions', 'Redirecting without confrontation'],
      hazards: ['Escalation by argument', 'Overstimulation', 'Missed hearing or vision loss'],
      video: [
        { t: '00:00', label: 'Validation in practice', av: 'Visual: two-person role play · Audio: dialogue' },
        { t: '08:40', label: 'Giving choices that work', av: 'Visual: wardrobe scene · Audio: coaching' },
        { t: '16:20', label: 'When repetition will not stop', av: 'Visual: lounge scene · Audio: calm narration' }
      ]
    },
    {
      id: 'brc-05', n: 5, title: 'Patient Care & Understanding Foundations', category: 'Fundamentals', hours: 15,
      glyph: 'hand',
      description: 'Core nursing-care foundations: hydration, nutrition, pressure areas, continence, pain and comfort rounds.',
      highlights: ['Comfort-round observation set', 'Pressure area and continence care', 'Pain recognition in cognitive impairment'],
      hazards: ['Pressure injury', 'Dehydration', 'Unrecognised pain'],
      video: [
        { t: '00:00', label: 'The comfort round', av: 'Visual: full-body check · Audio: checklist' },
        { t: '10:05', label: 'Hydration and nutrition cues', av: 'Visual: meal tray · Audio: narration' },
        { t: '19:30', label: 'Pain scales for dementia', av: 'Visual: PAINAD form · Audio: clinical guidance' }
      ]
    },
    {
      id: 'brc-06', n: 6, title: 'Prevention Methods & Environmental Hazards', category: 'Safety & First Aid', hours: 14,
      glyph: 'leaf',
      description: 'A systematic environmental risk assessment: lighting, flooring, furniture, bathroom rails, clutter and temperature.',
      highlights: ['Lighting and contrast for ageing eyes', 'Trip, slip and scald prevention', 'Emergency access and signage'],
      hazards: ['Loose rugs', 'Poor lighting', 'Unsecured bathrooms'],
      video: [
        { t: '00:00', label: 'Home hazard walk-through', av: 'Visual: corridor sweep · Audio: annotated narration' },
        { t: '09:50', label: 'Lighting for ageing vision', av: 'Visual: before/after room · Audio: explanation' },
        { t: '17:15', label: 'Bathroom grab-rail check', av: 'Visual: close-up hardware · Audio: instruction' }
      ]
    },
    {
      id: 'brc-07', n: 7, title: 'First Aid & Health Check Protocols', category: 'Safety & First Aid', hours: 18,
      glyph: 'cross',
      description: 'Adult CPR, choking, recovery position, hypoglycaemia, stroke recognition and the observation set that buys time.',
      highlights: ['Adult CPR and AED use', 'Choking and recovery position', 'Stroke, sepsis and hypoglycaemia red flags'],
      hazards: ['Cardiac arrest', 'Airway obstruction', 'Hypoglycaemia'],
      video: [
        { t: '00:00', label: 'Adult CPR sequence', av: 'Visual: manikin demo · Audio: metronome coaching' },
        { t: '11:30', label: 'Choking: back blows to CPR', av: 'Visual: seated demo · Audio: step-by-step' },
        { t: '22:10', label: 'FAST stroke screen', av: 'Visual: face-arm-speech grid · Audio: urgent narration' }
      ]
    },
    {
      id: 'brc-08', n: 8, title: 'Dignified Bathing & Hygiene Care', category: 'Daily Care & Mobility', hours: 12,
      glyph: 'droplet',
      description: 'Safe, respectful bathing: privacy, water temperature, slips, skin tears, oral care and preserving independence.',
      highlights: ['Privacy, choice and trauma-informed touch', 'Water temperature and bathroom safety', 'Skin, oral and perineal care'],
      hazards: ['Scalds', 'Slips and falls', 'Skin tears'],
      video: [
        { t: '00:00', label: 'Preparing a dignified bath', av: 'Visual: bathroom setup · Audio: calm narration' },
        { t: '07:30', label: 'Water temperature and transfers', av: 'Visual: thermometer check · Audio: coaching' },
        { t: '14:45', label: 'Skin inspection and oral care', av: 'Visual: close-up technique · Audio: checklist' }
      ]
    },
    {
      id: 'brc-09', n: 9, title: 'Moving a Patient Safely & Mobility Transfers', category: 'Daily Care & Mobility', hours: 16,
      glyph: 'transfer',
      description: 'Hoist, slide-sheet and standing transfers with caregiver body mechanics, pre-transfer checks and fall-safe technique.',
      highlights: ['Pre-transfer equipment and consent check', 'Hoist sling selection and two-person technique', 'Caregiver spine protection'],
      hazards: ['Caregiver back injury', 'Patient fall during transfer', 'Hoist or sling failure'],
      video: [
        { t: '00:00', label: 'Pre-transfer safety check', av: 'Visual: hoist inspection · Audio: checklist' },
        { t: '09:20', label: 'Hoist transfer with two carers', av: 'Visual: full transfer · Audio: call-outs' },
        { t: '20:40', label: 'Standing and slide-sheet transfers', av: 'Visual: bedside demo · Audio: coaching' }
      ]
    },
    {
      id: 'brc-10', n: 10, title: 'Therapeutic Interaction with the Patient', category: 'Communication', hours: 14,
      glyph: 'person',
      description: 'Therapeutic presence, active listening, reminiscence, life-story work and supporting families through decline.',
      highlights: ['Active listening and therapeutic silence', 'Reminiscence and life-story prompts', 'Family communication and grief support'],
      hazards: ['Emotional withdrawal', 'Missed hearing loss', 'Carer burnout'],
      video: [
        { t: '00:00', label: 'Therapeutic presence', av: 'Visual: quiet bedside scene · Audio: soft narration' },
        { t: '08:10', label: 'Reminiscence prompts', av: 'Visual: memory box · Audio: dialogue' },
        { t: '16:55', label: 'A family conversation', av: 'Visual: consult room · Audio: empathetic dialogue' }
      ]
    },
    {
      id: 'brc-11', n: 11, title: 'Managing Moods of the Patient & De-escalation', category: 'Communication', hours: 15,
      glyph: 'mood',
      description: 'Recognising agitation, aggression, apathy and catastrophic reactions — and de-escalating without restraint or sedation.',
      highlights: ['Trigger mapping: pain, fear, noise, fatigue', 'Open-palm de-escalation and safety bubble', 'Restraint-free alternatives'],
      hazards: ['Physical aggression', 'Restraint injury', 'Over-sedation'],
      video: [
        { t: '00:00', label: 'Reading the escalation curve', av: 'Visual: behaviour timeline · Audio: narration' },
        { t: '09:35', label: 'Open-palm de-escalation', av: 'Visual: body-language demo · Audio: calm coaching' },
        { t: '18:05', label: 'After the incident', av: 'Visual: debrief room · Audio: reflective dialogue' }
      ]
    },
    {
      id: 'brc-12', n: 12, title: 'Home Care & Environmental Adaptation', category: 'Daily Care & Mobility', hours: 10,
      glyph: 'home',
      description: 'Adapting a family home for dementia and frailty: signage, lighting, bathroom safety, medication storage and emergency plans.',
      highlights: ['Wayfinding, contrast and signage', 'Bathroom, stair and bedroom adaptation', 'Emergency contact and medication plan'],
      hazards: ['Unlit stairs', 'Unsecured medication', 'Bathroom falls'],
      video: [
        { t: '00:00', label: 'Home adaptation audit', av: 'Visual: room-by-room sweep · Audio: checklist' },
        { t: '08:25', label: 'Wayfinding and contrast', av: 'Visual: door signage · Audio: explanation' },
        { t: '15:40', label: 'Emergency plan rehearsal', av: 'Visual: family briefing · Audio: dialogue' }
      ]
    },
    {
      id: 'brc-13', n: 13, title: 'Critical Hazards: Choking & Dysphagia Prevention', category: 'Safety & First Aid', hours: 10,
      glyph: 'airway',
      description: 'Airway emergencies and swallowing safety: IDDSI textures, silent aspiration, back blows, chest thrusts and CPR.',
      highlights: ['IDDSI texture levels and mealtime positioning', 'Choking: 5 back blows, 5 chest thrusts, CPR', 'Silent aspiration and pneumonia prevention'],
      hazards: ['Airway obstruction', 'Silent aspiration', 'Aspiration pneumonia'],
      video: [
        { t: '00:00', label: 'Recognising a choking emergency', av: 'Visual: universal sign · Audio: urgent narration' },
        { t: '07:50', label: 'Back blows and chest thrusts', av: 'Visual: seated demo · Audio: step-by-step' },
        { t: '16:30', label: 'IDDSI texture preparation', av: 'Visual: kitchen tests · Audio: clinical guidance' }
      ]
    }
  ];

  const FLIP_CARDS = [
    {
      code: 'EM-01', tone: 'choking', icon: '◍', title: 'Acute Choking & Airway Blockage',
      signs: ['Silent cough or no cough at all', 'Clutching the throat, panic, wide eyes', 'Cyanosis, wheeze or inability to speak'],
      donts: ['Do NOT slap a coughing patient on the back — encourage the cough first.', 'Do NOT give water or attempt blind finger sweeps.'],
      steps: [
        'Ask: “Are you choking?” If they can cough, encourage coughing.',
        'If they cannot breathe, call EMS and give 5 firm back blows between the shoulder blades.',
        'If not relieved, give 5 seated chest thrusts at the lower sternum.',
        'Alternate 5 back blows and 5 chest thrusts until the object clears.',
        'If they become unresponsive, lower to the floor and start CPR immediately.'
      ],
      cues: ['45° forward lean', '5 back blows', '5 seated chest thrusts', 'CPR if unresponsive'],
      golden: 'A strong cough needs encouragement, not intervention. Silence needs immediate action.',
      voice: 'Take a deep breath and stay calm. Ask the person if they are choking. If they can cough, encourage them to keep coughing. If they cannot breathe, call emergency services and give five firm back blows between the shoulder blades, leaning them forward. If that does not clear it, give five seated chest thrusts. Alternate until help arrives. If they become unresponsive, begin CPR.'
    },
    {
      code: 'EM-02', tone: 'fall', icon: '⌁', title: 'Senior Fall & Suspected Hip Fracture',
      signs: ['One leg shortened and externally rotated', 'Severe groin, hip or thigh pain', 'Inability to weight-bear after a fall'],
      donts: ['Do NOT lift or walk the resident — zero weight-bearing.', 'Do NOT give food or fluids before clinical review.'],
      steps: [
        'Do not move them. Kneel at eye level and reassure.',
        'Check response, breathing, pain and obvious deformity.',
        'Call EMS or the clinical team; state the fall and suspected hip fracture.',
        'Keep them warm with a blanket and pad pressure points.',
        'Report anticoagulants, blood thinners and the exact time of the fall.'
      ],
      cues: ['Stay flat', 'Zero weight-bearing', 'Hypothermia blanket', 'Anticoagulant alert'],
      golden: 'A shortened, rotated leg after a fall is a hip fracture until proven otherwise.',
      voice: 'Take a deep breath and stay calm. Do not lift the person or let them walk. Kneel beside them and explain that help is coming. Look for a leg that appears shortened or turned outward, which can mean a hip fracture. Call emergency services and keep them warm with a blanket. Tell the clinical team about any blood thinners and the time of the fall.'
    },
    {
      code: 'EM-03', tone: 'stroke', icon: '✚', title: 'Acute Stroke · FAST 3.5h Golden Window',
      signs: ['Face droop on one side', 'Arm weakness or drift', 'Speech slurred or confused', 'Time — record the exact onset'],
      donts: ['Do NOT give aspirin, food or fluids.', 'Do NOT lower the head flat or delay transport.'],
      steps: [
        'Test F-A-S-T: face, arms, speech and time of onset.',
        'Call emergency services immediately and say “suspected stroke”.',
        'Elevate the head approximately 30 degrees; keep them nil by mouth.',
        'Record the last-known-well time, medicines and glucose reading.',
        'Do not leave them alone; monitor breathing until EMS arrives.'
      ],
      cues: ['F-A-S-T grid', '30° head elevation', 'Nil by mouth', 'Time of onset'],
      golden: 'Time is brain. The treatment window is about 3.5 hours from the last-known-well time.',
      voice: 'Take a deep breath and stay calm. Use the F A S T check. Look at the face for drooping. Ask them to raise both arms and watch for drift. Listen for slurred speech. Then note the exact time they were last well. Call emergency services and say suspected stroke. Keep them nil by mouth, raise the head about thirty degrees, and stay with them.'
    },
    {
      code: 'EM-04', tone: 'agitation', icon: '◉', title: 'Dementia Panic & Catastrophic Agitation',
      signs: ['Sudden shouting, pacing or resistance', 'Fear, clinging or flight response', 'Refusal of care or personal care'],
      donts: ['Do NOT restrain, crowd or argue with the person.', 'Do NOT use sudden movements, raised voices or bright overhead light.'],
      steps: [
        'Create a 3-foot safety bubble; give them space.',
        'Show open palms, lower your voice and use their preferred name.',
        'Validate the feeling: “You are safe. I am staying with you.”',
        'Reduce noise and light; remove the audience.',
        'Offer a choice, a drink or a familiar activity; escalate if unsafe.'
      ],
      cues: ['3-foot bubble', 'Open palms', 'Validation therapy', 'Warm low light'],
      golden: 'Connect before you correct. A calm body settles a frightened brain.',
      voice: 'Take a deep breath and stay calm. Give the person a three foot safety bubble. Keep your hands open and visible. Lower your voice and use their preferred name. Do not argue with the story. Say, you are safe, I am staying with you. Reduce noise and bright light. Offer a simple choice or a familiar activity. Call for help if anyone is unsafe.'
    }
  ];

  const PROTOCOLS = [
    {
      id: 'lib-01', title: 'Acute Choking & Airway Blockage', category: 'Airway & Breathing', urgency: 'Emergency', pinned: true,
      summary: '5 back blows, 5 seated chest thrusts, alternate, then CPR if unresponsive. Encourage coughing when the cough is effective.',
      steps: ['Confirm choking and call EMS.', '5 firm back blows with a 45° forward lean.', '5 seated chest thrusts if unresolved.', 'Alternate and start CPR if unresponsive.', 'Document time, interventions and outcome.']
    },
    {
      id: 'lib-02', title: 'Senior Fall & Suspected Hip Fracture', category: 'Falls & Trauma', urgency: 'Emergency', pinned: true,
      summary: 'Do not lift. Zero weight-bearing. Keep warm. Alert EMS to anticoagulants and the exact fall time.',
      steps: ['Do not move the resident.', 'Assess response, breathing and deformity.', 'Call EMS and report suspected hip fracture.', 'Blanket for hypothermia; pad pressure points.', 'Report blood thinners and fall time.']
    },
    {
      id: 'lib-03', title: 'Acute Stroke · FAST 3.5h Golden Window', category: 'Neurological', urgency: 'Emergency', pinned: true,
      summary: 'Face, arms, speech, time. Nil by mouth, 30° head elevation, immediate EMS transport.',
      steps: ['Run the FAST screen.', 'Record last-known-well time.', 'Call EMS and say suspected stroke.', 'Nil by mouth; 30° head elevation.', 'Monitor airway until arrival.']
    },
    {
      id: 'lib-04', title: 'Dementia Panic & Catastrophic Agitation', category: 'Dementia & Behaviour', urgency: 'Urgent', pinned: true,
      summary: '3-foot bubble, open palms, validation, reduced stimulation. Restraint is a last resort and never without an order.',
      steps: ['Give space and reduce the audience.', 'Open palms and a low, slow voice.', 'Validate the emotion, not the fact.', 'Offer a simple choice or familiar activity.', 'Escalate if there is a risk of harm.']
    },
    {
      id: 'lib-05', title: 'Suspected Sepsis in a Frail Resident', category: 'Infection & Hygiene', urgency: 'Emergency',
      summary: 'New confusion, fever or low temperature, fast breathing and low blood pressure need same-hour escalation.',
      steps: ['Record temperature, pulse, BP, breathing and SpO2.', 'Check urine, chest and skin for a source.', 'Escalate to the clinician immediately.', 'Do not delay for a full work-up.', 'Document the observation set and time.']
    },
    {
      id: 'lib-06', title: 'Hypoglycaemia (Low Blood Sugar)', category: 'Medication & Metabolism', urgency: 'Urgent',
      summary: 'If conscious and able to swallow: fast-acting sugar, then a complex carbohydrate. If unconscious: emergency services.',
      steps: ['Check glucose if a meter is available.', 'Conscious: glucose gel or sweet drink.', 'Recheck after 15 minutes.', 'Give a snack once stable.', 'Unconscious: recovery position and call EMS.']
    },
    {
      id: 'lib-07', title: 'Burns & Scalds at the Bedside', category: 'Falls & Trauma', urgency: 'Urgent',
      summary: 'Cool running water for 20 minutes. Never ice, butter or toothpaste. Cover loosely and seek review.',
      steps: ['Stop the burning process and remove jewellery.', 'Cool with running water for 20 minutes.', 'Cover with cling film or a clean non-stick dressing.', 'Do not burst blisters.', 'Seek clinical review for large or deep burns.']
    },
    {
      id: 'lib-08', title: 'Seizure First Response', category: 'Neurological', urgency: 'Emergency',
      summary: 'Protect the head, do not restrain, do not put anything in the mouth. Time the seizure and call EMS if over 5 minutes.',
      steps: ['Clear the area and cushion the head.', 'Do not restrain or insert objects.', 'Time the seizure.', 'Recovery position once movements stop.', 'Call EMS if over 5 minutes or breathing is poor.']
    }
  ];

  const BASE_EVALS = [
    {
      id: 'ev-short-01', kind: 'short', moduleId: 'brc-13', moduleTitle: 'Critical Hazards: Choking & Dysphagia Prevention',
      prompt: 'A resident coughs and goes silent during lunch. Describe your first 60 seconds.',
      expected: 'Recognise choking, call for help and EMS, give five firm back blows with a forward lean, then five seated chest thrusts if unresolved, start CPR if unresponsive, and document the event.',
      keywords: ['choking', 'call', 'back blows', 'chest thrusts', 'cpr', 'unresponsive', 'document'],
      tips: ['State the immediate recognition step.', 'Include the exact back-blow and chest-thrust sequence.']
    },
    {
      id: 'ev-short-02', kind: 'short', moduleId: 'brc-02', moduleTitle: 'Understanding Dementia',
      prompt: 'A person with dementia insists a deceased relative is coming for dinner. How do you respond?',
      expected: 'Do not argue or correct. Validate the feeling, redirect gently, offer a comforting activity and check for pain, hunger or fear driving the story.',
      keywords: ['validate', 'do not argue', 'redirect', 'comfort', 'pain', 'fear'],
      tips: ['Use validation before redirection.', 'Screen for an unmet need.']
    },
    {
      id: 'ev-short-03', kind: 'short', moduleId: 'brc-09', moduleTitle: 'Moving a Patient Safely & Mobility Transfers',
      prompt: 'List the checks before a hoist transfer.',
      expected: 'Check consent, hoist and sling condition, weight limit, correct sling type, brakes, clear path and a second trained carer.',
      keywords: ['consent', 'hoist', 'sling', 'weight', 'brakes', 'path', 'two carers'],
      tips: ['Start with consent and equipment.', 'Name the second-carer requirement.']
    },
    {
      id: 'ev-short-04', kind: 'short', moduleId: 'brc-03', moduleTitle: 'Safety Precautions for Dementia Patients',
      prompt: 'Which environmental hazards do you remove for a resident who wanders at night?',
      expected: 'Lock away medicines and cleaning products, secure stairs and exits, remove trip hazards, add night lighting, secure windows and use door alarms without restraint.',
      keywords: ['medicines', 'cleaning', 'stairs', 'trip', 'lighting', 'windows', 'alarm'],
      tips: ['Cover poisoning and falls.', 'Offer a restraint-free door strategy.']
    },
    {
      id: 'ev-short-05', kind: 'short', moduleId: 'brc-11', moduleTitle: 'Managing Moods of the Patient & De-escalation',
      prompt: 'A resident becomes verbally aggressive during bathing. What do you do?',
      expected: 'Stop the task, give space, lower your voice, validate the fear, offer privacy and a choice, check pain and temperature, and return later with a second carer if needed.',
      keywords: ['stop', 'space', 'calm', 'validate', 'choice', 'pain', 'second carer'],
      tips: ['Stop the task first.', 'Give control back through choices.']
    },
    {
      id: 'ev-quiz-01', kind: 'quiz', moduleId: 'brc-07', moduleTitle: 'First Aid & Health Check Protocols',
      prompt: 'What is the correct adult CPR compression rate?',
      options: ['60–80 per minute', '100–120 per minute', '140–160 per minute', 'As fast as possible'],
      answer: '100–120 per minute',
      expected: 'Adult CPR compressions are delivered at 100 to 120 per minute with a depth of about 5 to 6 cm.',
      keywords: ['100', '120', 'minute', 'compressions'],
      tips: ['Rate and depth both matter.']
    },
    {
      id: 'ev-quiz-02', kind: 'quiz', moduleId: 'brc-13', moduleTitle: 'Critical Hazards: Choking & Dysphagia Prevention',
      prompt: 'A choking resident has an effective, strong cough. What is the first action?',
      options: ['Give 5 back blows immediately', 'Encourage them to keep coughing', 'Give water', 'Start CPR'],
      answer: 'Encourage them to keep coughing',
      expected: 'An effective cough means the airway is partly open; encourage coughing and stay with them while monitoring.',
      keywords: ['encourage', 'cough', 'monitor'],
      tips: ['Effective cough = encourage. Silent = intervene.']
    },
    {
      id: 'ev-quiz-03', kind: 'quiz', moduleId: 'brc-08', moduleTitle: 'Dignified Bathing & Hygiene Care',
      prompt: 'What is the safest bath water temperature for a frail older adult?',
      options: ['44–46 °C', '40–43 °C', '37–40 °C', '30–33 °C'],
      answer: '37–40 °C',
      expected: 'Keep bath water at approximately 37 to 40 degrees Celsius and always test with the elbow or a thermometer.',
      keywords: ['37', '40', 'elbow', 'thermometer'],
      tips: ['Test with the elbow, not the hand.']
    },
    {
      id: 'ev-quiz-04', kind: 'quiz', moduleId: 'brc-06', moduleTitle: 'Prevention Methods & Environmental Hazards',
      prompt: 'Which item is the highest-priority trip hazard in a dementia care home?',
      options: ['A wall clock', 'A loose rug at a doorway', 'A bedside lamp', 'A framed photograph'],
      answer: 'A loose rug at a doorway',
      expected: 'Loose rugs, trailing cables and clutter are leading trip hazards; remove or secure them.',
      keywords: ['loose rug', 'trip', 'remove'],
      tips: ['Think floor-level hazards.']
    },
    {
      id: 'ev-quiz-05', kind: 'quiz', moduleId: 'brc-04', moduleTitle: 'How to Deal with Patients with Dementia',
      prompt: 'What does validation therapy mean?',
      options: ['Correcting the person’s facts', 'Acknowledging their feelings without arguing', 'Distracting them with television', 'Explaining the diagnosis again'],
      answer: 'Acknowledging their feelings without arguing',
      expected: 'Validation acknowledges the emotion behind the words rather than correcting the content.',
      keywords: ['acknowledge', 'feelings', 'without arguing'],
      tips: ['Connect before you correct.']
    },
    {
      id: 'ev-assign-01', kind: 'assignment', moduleId: 'brc-05', moduleTitle: 'Patient Care & Understanding Foundations',
      prompt: 'Write a 100-word handover for a resident with new reduced oral intake and a sacral redness that does not blanch.',
      expected: 'Use SBAR: situation, background, assessment and recommendation. Include intake, hydration, skin description, pain, repositioning, escalation and documentation.',
      keywords: ['sbar', 'intake', 'hydration', 'sacral', 'non-blanching', 'reposition', 'escalate', 'document'],
      tips: ['Use a recognised handover structure.', 'State the escalation explicitly.']
    },
    {
      id: 'ev-assign-02', kind: 'assignment', moduleId: 'brc-12', moduleTitle: 'Home Care & Environmental Adaptation',
      prompt: 'Design a home safety walkthrough for a family caring for a parent with moderate dementia.',
      expected: 'Assess lighting, stairs, bathroom rails, trip hazards, medication storage, kitchen risk, door and window security, wayfinding and an emergency contact plan.',
      keywords: ['lighting', 'stairs', 'bathroom', 'trip', 'medication', 'kitchen', 'doors', 'wayfinding', 'emergency'],
      tips: ['Go room by room.', 'Include an emergency plan.']
    },
    {
      id: 'ev-assign-03', kind: 'assignment', moduleId: 'brc-10', moduleTitle: 'Therapeutic Interaction with the Patient',
      prompt: 'Plan a 15-minute therapeutic interaction for a withdrawn resident with hearing loss.',
      expected: 'Reduce background noise, face the resident, use clear low speech, offer a reminiscence prompt, allow silence, use touch with consent and document the response.',
      keywords: ['noise', 'face', 'clear', 'reminiscence', 'silence', 'consent', 'document'],
      tips: ['Address the hearing loss first.', 'Include consent and documentation.']
    },
    {
      id: 'ev-assign-04', kind: 'assignment', moduleId: 'brc-01', moduleTitle: 'Knowledge for Caregivers Based on Elderly Patients',
      prompt: 'Write a short self-care and boundary plan for a caregiver working three night shifts in a row.',
      expected: 'Plan sleep, hydration, meals, movement, debriefing, boundary-setting, escalation and a check-in with a supervisor.',
      keywords: ['sleep', 'hydration', 'meals', 'movement', 'debrief', 'boundaries', 'supervisor'],
      tips: ['Make it practical and time-bound.', 'Include a supervisor check-in.']
    }
  ];

  const BADGES = [
    { id: 'dementia', icon: '🧠', name: 'Dementia Mastery', requirement: 'Complete Understanding Dementia, Communication and Moods', test: (s) => ['brc-02', 'brc-04', 'brc-11'].every((id) => !!s.completions[id]) },
    { id: 'choking', icon: '◍', name: 'Choking Vigilance', requirement: 'Complete the Choking & Dysphagia module', test: (s) => !!s.completions['brc-13'] },
    { id: 'safety', icon: '🛡️', name: 'Safety Sentinel', requirement: 'Complete 3 safety & first-aid modules', test: (s) => Object.keys(s.completions).filter((id) => ['brc-03', 'brc-06', 'brc-07', 'brc-13'].includes(id)).length >= 3 },
    { id: 'diploma', icon: '🎓', name: '200-Hour Diploma', requirement: 'Reach 12,000 study minutes or complete all 13 modules', test: (s) => Number(s.minutesStudied) >= 12000 || Object.keys(s.completions).length >= 13 },
    { id: 'streak', icon: '◆', name: 'Streak Keeper', requirement: 'Study 7 days in a row', test: (s) => Number(s.streak) >= 7 },
    { id: 'match', icon: '◎', name: 'True-Match Expert', requirement: 'Average 90%+ across 3 evaluations', test: (s) => s.attempts.length >= 3 && (s.attempts.reduce((a, x) => a + Number(x.score || 0), 0) / s.attempts.length) >= 90 }
  ];

  const GEN_TEMPLATES = {
    short: [
      (m, h) => 'During the ' + m.title + ' module, a resident develops ' + h + '. Outline your first three actions and the escalation point.',
      (m, h) => 'A family reports that their relative is at risk of ' + h + '. What do you assess first, and what do you document?',
      (m, h) => 'You observe ' + h + ' during a routine comfort round. Write the clinical reasoning behind your next three steps.'
    ],
    quiz: [
      (m, h) => 'Which is the safest first response to ' + h + ' while applying ' + m.title + '?',
      (m, h) => 'In the ' + m.title + ' module, what is the priority when ' + h + ' is suspected?',
      (m, h) => 'Which action best prevents ' + h + ' in a frail resident?'
    ],
    assignment: [
      (m, h) => 'Write a 100-word care note for a resident at risk of ' + h + ' using the ' + m.title + ' protocol.',
      (m, h) => 'Create a one-page checklist that reduces ' + h + ' for a resident in your care.',
      (m, h) => 'Explain to a new caregiver how to recognise and escalate ' + h + ' in under 120 words.'
    ]
  };

  const GLYPHS = {
    heart: '<path d="M12 20.5S3.8 15.4 3.8 9.9A4.4 4.4 0 0 1 12 7.6a4.4 4.4 0 0 1 8.2 2.3c0 5.5-8.2 10.6-8.2 10.6Z"/>',
    brain: '<path d="M9.2 3.4A3.2 3.2 0 0 0 6 6.6a3.2 3.2 0 0 0-1.3 5.8A3.2 3.2 0 0 0 7.6 17a3.2 3.2 0 0 0 4.4 2.6V3.9a2.6 2.6 0 0 0-2.8-.5Z"/><path d="M14.8 3.4A3.2 3.2 0 0 1 18 6.6a3.2 3.2 0 0 1 1.3 5.8A3.2 3.2 0 0 1 16.4 17a3.2 3.2 0 0 1-4.4 2.6V3.9a2.6 2.6 0 0 1 2.8-.5Z"/>',
    shield: '<path d="M12 2.8 20 6v6.1c0 4.6-3.3 7.7-8 9.1-4.7-1.4-8-4.5-8-9.1V6l8-3.2Z"/><path d="M8.6 12.1 11 14.5l4.5-5"/>',
    chat: '<path d="M4 5.5h11.5a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H9l-4 3v-3H4a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2Z"/><path d="M17.5 9.5H19a2 2 0 0 1 2 2v5.5a2 2 0 0 1-2 2h-1V21l-3.5-2.5"/>',
    hand: '<path d="M8 11V5.5a1.5 1.5 0 0 1 3 0V11m0-6.5a1.5 1.5 0 0 1 3 0V11m0-5a1.5 1.5 0 0 1 3 0v8.5A6.5 6.5 0 0 1 10.5 21H10a6 6 0 0 1-6-6v-3a1.5 1.5 0 0 1 3 0v2"/>',
    leaf: '<path d="M20 3C11 3 4.5 7.5 4.5 14A6.5 6.5 0 0 0 11 20.5C17.5 20.5 21 14 21 5Z"/><path d="M4 21c2-5 6-9 12-12"/>',
    cross: '<path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6V3Z"/>',
    droplet: '<path d="M12 2.8s6.6 7.2 6.6 11.5a6.6 6.6 0 0 1-13.2 0C5.4 10 12 2.8 12 2.8Z"/><path d="M9 14.5a3 3 0 0 0 3 3"/>',
    transfer: '<path d="M4 8h13m-3.5-3.5L17 8l-3.5 3.5M20 16H7m3.5-3.5L7 16l3.5 3.5"/>',
    person: '<circle cx="12" cy="7" r="3.2"/><path d="M5 21a7 7 0 0 1 14 0"/>',
    mood: '<circle cx="12" cy="12" r="9"/><path d="M8 14.5s1.5 2 4 2 4-2 4-2M9 9.5h.01M15 9.5h.01"/>',
    home: '<path d="M3 10.8 12 3l9 7.8V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-9.2Z"/>',
    airway: '<path d="M12 3v7"/><path d="M8.5 10.5c-2.4 0-4 2-4 4.6S6.1 21 8.5 21s4-2.4 4-5.9"/><path d="M15.5 10.5c2.4 0 4 2 4 4.6S17.9 21 15.5 21s-4-2.4-4-5.9"/><circle cx="12" cy="4" r="1.6"/>'
  };

  const ART_TONES = {
    Fundamentals: ['#0f766e', '#115e59', '#042f2e'],
    'Dementia Care': ['#7c3aed', '#5b21b6', '#2e1065'],
    'Safety & First Aid': ['#be123c', '#9f1239', '#4c0519'],
    'Daily Care & Mobility': ['#0369a1', '#075985', '#082f49'],
    Communication: ['#b45309', '#92400e', '#451a03']
  };

  return { CATEGORIES, COURSES, FLIP_CARDS, PROTOCOLS, BASE_EVALS, BADGES, GEN_TEMPLATES, GLYPHS, ART_TONES };
})();
