/* ============================================================
   EVOLV3 Academy — renderers: gamification, progress, certificates,
   administration reporting and weekly evolution.
   ============================================================ */
(function () {
  'use strict';
  const A = window.ACADEMY;
  const D = A.D;
  const S = A.S;
  const { $, $$, esc, nf, pct, hoursLabel, longDate, shortDate, timeAgo, todayISO } = A.U;

  const LEVELS = [
    { min: 0, name: 'Foundation Learner' },
    { min: 500, name: 'Care Practitioner' },
    { min: 1200, name: 'Dementia Specialist' },
    { min: 2200, name: 'Clinical Mentor' },
    { min: 3500, name: 'Senior Care Lead' },
    { min: 5000, name: 'Master Caregiver' },
    { min: 7000, name: 'Academy Fellow' },
    { min: 10000, name: 'Beyond Legend' }
  ];

  function levelInfo(points) {
    const p = Math.max(0, Number(points) || 0);
    let idx = 0;
    for (let i = 0; i < LEVELS.length; i++) if (p >= LEVELS[i].min) idx = i;
    const current = LEVELS[idx];
    const next = LEVELS[idx + 1];
    const floor = current.min;
    const ceiling = next ? next.min : floor + 1000;
    return {
      level: idx + 1,
      name: current.name,
      floor,
      ceiling,
      xp: p - floor,
      span: ceiling - floor,
      toNext: Math.max(0, ceiling - p),
      isMax: !next
    };
  }

  // ---------------------------------------------------------- leaderboard
  function leaderboardRows() {
    const L = S.learner;
    const rows = (S.leaderboard || []).map((r) => Object.assign({}, r));
    const currentName = String(L.displayName || '').toLowerCase();
    const already = rows.some((r) => String(r.name || '').toLowerCase() === currentName);
    if (!already) {
      const scores = (L.attempts || []).map((a) => Number(a.score) || 0);
      rows.push({
        user: 'current',
        name: L.displayName || 'You',
        role: L.role,
        points: Number(L.points) || 0,
        minutes: Number(L.minutesStudied) || 0,
        completed: Object.keys(L.completions || {}).length,
        attempts: (L.attempts || []).length,
        avgScore: scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0,
        badges: (L.badges || []).length,
        streak: L.streak,
        current: true
      });
    } else {
      rows.forEach((r) => {
        r.current = String(r.name || '').toLowerCase() === currentName;
        if (r.current) {
          r.points = Math.max(Number(r.points) || 0, Number(L.points) || 0);
          r.minutes = Math.max(Number(r.minutes) || 0, Number(L.minutesStudied) || 0);
        }
      });
    }
    return rows.sort((a, b) => (Number(b.points) - Number(a.points)) || (Number(b.minutes) - Number(a.minutes)));
  }

  function renderLeaderboard() {
    const L = S.learner;
    const info = levelInfo(L.points);
    const lb = $('#level-badge'); if (lb) lb.textContent = 'L' + info.level;
    const ln = $('#level-name'); if (ln) ln.textContent = info.name;
    const lp = $('#level-points'); if (lp) lp.textContent = nf(L.points);
    const nx = $('#level-next'); if (nx) nx.textContent = info.isMax ? 'Highest level reached' : info.toNext + ' pts to next level';
    const xl = $('#xp-label'); if (xl) xl.textContent = info.xp + ' / ' + info.span;
    const xf = $('#xp-fill'); if (xf) xf.style.width = pct(info.xp, info.span) + '%';
    const sv = $('#streak-value'); if (sv) sv.textContent = L.streak || 1;

    A.renderSocialBadges();

    const rows = leaderboardRows().filter((r) => !S.leaderRole || r.role === S.leaderRole);
    const body = $('#leaderboard-body');
    if (body) {
      body.innerHTML = rows.length ? rows.map((r, i) => {
        const badgeCount = Number(r.badges) || 0;
        return '<tr' + (r.current ? ' style="background:var(--teal-soft)"' : '') + '>' +
          '<td class="num">' + (i + 1) + '</td>' +
          '<td><b>' + esc(r.name || 'Learner') + '</b>' + (r.current ? '<span class="table-sub">You</span>' : '') + '</td>' +
          '<td>' + esc(r.role || '—') + '</td>' +
          '<td class="num">' + nf(r.points) + '</td>' +
          '<td class="num">' + nf(r.minutes) + ' min</td>' +
          '<td class="num">' + nf(r.completed) + '</td>' +
          '<td class="num">' + (Number(r.avgScore) ? r.avgScore + '%' : '—') + '</td>' +
          '<td class="num">' + badgeCount + '</td>' +
        '</tr>';
      }).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--muted);padding:24px">No learners in this role yet. Invite your team to enrol.</td></tr>';
    }
    const meta = $('#leader-meta');
    if (meta) meta.textContent = rows.length + ' learner' + (rows.length === 1 ? '' : 's') + ' · live local data';
  }

  // ---------------------------------------------------------- progress
  function moduleBest(id) {
    const L = S.learner;
    if (L.completions[id]) return Number(L.completions[id].score) || 0;
    const scores = (L.attempts || []).filter((a) => a.moduleId === id).map((a) => Number(a.score) || 0);
    return scores.length ? Math.max.apply(null, scores) : null;
  }

  function renderProgress() {
    const L = S.learner;
    const courses = A.allCourses();
    const completed = Object.keys(L.completions || {}).length;
    const avg = (L.attempts || []).length ? Math.round((L.attempts || []).reduce((a, x) => a + Number(x.score || 0), 0) / L.attempts.length) : null;
    const mins = Number(L.minutesStudied) || 0;

    const sm = $('#stat-minutes'); if (sm) sm.innerHTML = nf(mins) + ' <small>min</small>';
    const sb = $('#stat-minutes-bar'); if (sb) sb.style.width = Math.min(100, pct(mins, 12000)) + '%';
    const sc = $('#stat-modules'); if (sc) sc.innerHTML = completed + ' <small>/ ' + courses.length + '</small>';
    const scs = $('#stat-modules-sub'); if (scs) scs.textContent = completed >= 13 ? 'Diploma requirements complete' : (13 - completed) + ' modules remaining for the diploma';
    const sa = $('#stat-avg'); if (sa) sa.textContent = avg === null ? '—' : avg + '%';
    const st = $('#stat-tests'); if (st) st.textContent = (L.attempts || []).length;
    const sts = $('#stat-tests-sub'); if (sts) sts.textContent = (L.attempts || []).length ? 'Best match ' + Math.max.apply(null, L.attempts.map((a) => Number(a.score) || 0)) + '%' : 'Retakes always allowed';

    const hours = mins / 60;
    const dl = $('#diploma-label'); if (dl) dl.textContent = hours.toFixed(1) + ' of 200.0 hours';
    const dp = $('#diploma-pct'); if (dp) dp.textContent = Math.min(100, pct(mins, 12000)) + '%';
    const df = $('#diploma-fill'); if (df) df.style.width = Math.min(100, pct(mins, 12000)) + '%';
    const pm = $('#progress-meta'); if (pm) pm.textContent = completed + ' of ' + courses.length + ' complete';

    const body = $('#progress-body');
    if (body) {
      body.innerHTML = courses.map((c) => {
        const done = L.completions[c.id];
        const enrolled = L.enrolled.indexOf(c.id) !== -1;
        const best = moduleBest(c.id);
        const plate = done ? '<span class="plate pass">PASSED</span>' : enrolled ? '<span class="plate progress">ENROLLED</span>' : '<span class="plate locked">NOT STARTED</span>';
        return '<tr>' +
          '<td class="num">' + (c.n < 100 ? String(c.n).padStart(2, '0') : 'W' + c.weekAdded) + '</td>' +
          '<td><b>' + esc(c.title) + '</b>' + (c.isNewAutonomous ? '<span class="table-sub">Weekly autonomous module</span>' : '') + '</td>' +
          '<td>' + esc(c.category) + '</td>' +
          '<td class="num">' + Number(c.hours || 0) + '</td>' +
          '<td>' + plate + '</td>' +
          '<td class="num">' + (best === null ? '—' : best + '%') + '</td>' +
          '<td><button class="table-action" data-retake="' + esc(c.id) + '">' + (done ? 'Retake' : 'Assess') + '</button></td>' +
        '</tr>';
      }).join('');
    }
  }

  // ---------------------------------------------------------- certificate markup
  function sealSvg() {
    // Embossed gold-foil seal, drawn entirely as SVG so it prints crisply and
    // needs no image file. The wordmark and "VERIFIED" are unchanged.
    const rays = Array.from({ length: 64 }, (_, i) => {
      const a = (i / 64) * Math.PI * 2;
      const r1 = 53, r2 = i % 2 ? 47 : 43;
      return 'M' + (60 + Math.cos(a) * r1).toFixed(2) + ' ' + (60 + Math.sin(a) * r1).toFixed(2) +
             'L' + (60 + Math.cos(a) * r2).toFixed(2) + ' ' + (60 + Math.sin(a) * r2).toFixed(2);
    }).join('');
    return '<svg viewBox="0 0 120 120" aria-hidden="true">' +
      '<defs>' +
        '<radialGradient id="cfFoil" cx="38%" cy="30%" r="78%">' +
          '<stop offset="0" stop-color="#fff6d2"/>' +
          '<stop offset=".28" stop-color="#f2d98d"/>' +
          '<stop offset=".52" stop-color="#d8ab3f"/>' +
          '<stop offset=".74" stop-color="#a87a1c"/>' +
          '<stop offset=".9" stop-color="#e8c96f"/>' +
          '<stop offset="1" stop-color="#8d6512"/>' +
        '</radialGradient>' +
        '<linearGradient id="cfFoilEdge" x1="0" y1="0" x2="1" y2="1">' +
          '<stop offset="0" stop-color="#fffbe8"/><stop offset=".45" stop-color="#d9b055"/>' +
          '<stop offset=".7" stop-color="#9a7118"/><stop offset="1" stop-color="#f0d998"/>' +
        '</linearGradient>' +
        '<radialGradient id="cfFoilInner" cx="42%" cy="34%" r="70%">' +
          '<stop offset="0" stop-color="#2b4a68"/><stop offset=".62" stop-color="#16293f"/>' +
          '<stop offset="1" stop-color="#0b1725"/>' +
        '</radialGradient>' +
      '</defs>' +
      // milled edge
      '<circle cx="60" cy="60" r="56" fill="url(#cfFoilEdge)"/>' +
      '<path d="' + rays + '" stroke="#7d5a10" stroke-width="1.1" stroke-linecap="round" opacity=".55"/>' +
      '<circle cx="60" cy="60" r="56" fill="none" stroke="#6f4f0c" stroke-width="1"/>' +
      // raised foil face
      '<circle cx="60" cy="60" r="42" fill="url(#cfFoil)"/>' +
      '<circle cx="60" cy="60" r="42" fill="none" stroke="#8a6414" stroke-width="1.1"/>' +
      '<circle cx="60" cy="60" r="38.5" fill="none" stroke="#fff3c8" stroke-width=".7" opacity=".75"/>' +
      // engraved centre
      '<circle cx="60" cy="60" r="31" fill="url(#cfFoilInner)"/>' +
      '<circle cx="60" cy="60" r="31" fill="none" stroke="#c9a44c" stroke-width="1.1"/>' +
      '<path d="M60 40l4.6 9.5 10.5 1.5-7.6 7.4 1.8 10.4L60 63.9l-9.3 4.9 1.8-10.4-7.6-7.4 10.5-1.5Z" fill="url(#cfFoilEdge)" stroke="#6f4f0c" stroke-width=".6"/>' +
      '<text x="60" y="80" text-anchor="middle" font-family="Cormorant Garamond, Georgia, serif" font-size="11.5" font-weight="700" fill="#f6e7bd">BR</text>' +
      '<text x="60" y="88" text-anchor="middle" font-family="IBM Plex Mono, monospace" font-size="4.2" letter-spacing="1" fill="#dcc485">VERIFIED</text>' +
      '</svg>';
  }

  function crestSvg() {
    // Laurel-and-star crest above the award title. Decorative only.
    return '<svg viewBox="0 0 120 26" aria-hidden="true">' +
      '<path d="M4 22c14-2 24-9 30-20" fill="none" stroke="#b8912f" stroke-width="1.1" stroke-linecap="round"/>' +
      '<path d="M116 22c-14-2-24-9-30-20" fill="none" stroke="#b8912f" stroke-width="1.1" stroke-linecap="round"/>' +
      Array.from({ length: 6 }, (_, i) => {
        const x = 8 + i * 4.4, y = 20 - i * 3.1;
        return '<ellipse cx="' + x + '" cy="' + y + '" rx="3.1" ry="1.5" fill="#c9a44c" opacity=".55" transform="rotate(' + (-32 - i * 4) + ' ' + x + ' ' + y + ')"/>' +
               '<ellipse cx="' + (120 - x) + '" cy="' + y + '" rx="3.1" ry="1.5" fill="#c9a44c" opacity=".55" transform="rotate(' + (32 + i * 4) + ' ' + (120 - x) + ' ' + y + ')"/>';
      }).join('') +
      '<path d="M60 3l2.6 5.4 5.9.9-4.3 4.1 1 5.8L60 16.5l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z" fill="#c9a44c" stroke="#8a6414" stroke-width=".5"/>' +
      '</svg>';
  }

  function certFront(kind) {
    const L = S.learner;
    const isDiploma = kind !== 'completion';
    const title = isDiploma ? 'Internal Diploma in Professional Development' : 'Certificate of Completion';
    const subtitle = isDiploma ? '200-Hour Eldercare &amp; Dementia Care Programme' : 'Module Milestone · Eldercare &amp; Dementia Care';
    const pill = isDiploma ? '13 Bundled Internal Courses · 200 Verified Study Hours' : 'Assessed Module Milestone · Internal Completion Record';
    const id = A.credentialId(kind);
    const date = longDate(L.diplomaIssuedAt || todayISO());
    // A diploma page is read top to bottom: institution, award, recipient,
    // citation, signatures. The citation is the one band that carries the
    // middle of the sheet, and it states only facts already printed elsewhere
    // on this certificate (13 modules, 200 verified hours, this award).
    return '<div class="cf-sheet">' +
      '<span class="cf-corner tl" aria-hidden="true"></span><span class="cf-corner tr" aria-hidden="true"></span>' +
      '<span class="cf-corner bl" aria-hidden="true"></span><span class="cf-corner br" aria-hidden="true"></span>' +
      '<div class="cf-inner">' +
      '<div class="cf-top">' +
        '<div class="cf-brand"><img src="/logo.jpg" alt="Beyond Registration"><div class="cf-corp"><b>Beyond Registration (Pty) Ltd</b><span>REG. NO. 2026721121 · REPUBLIC OF SOUTH AFRICA</span></div></div>' +
        '<div class="cf-kicker">Internal Workforce Recognition</div>' +
      '</div>' +
      '<div class="cf-title-block">' +
        '<div class="cf-rule-orn">' + crestSvg() + '</div>' +
        '<div class="cf-title">' + title + '</div>' +
        '<div class="cf-subtitle">' + subtitle + '</div>' +
      '</div>' +
      '<div class="cf-award">' +
        '<div class="cf-presented">This certifies that</div>' +
        '<div class="cf-recipient">' + esc(L.displayName || 'Academy Learner') + '</div>' +
        '<div class="cf-role">' + esc(L.role || 'Caregiver') + ' · Beyond Registration Academy</div>' +
      '</div>' +
      '<div class="cf-citation">' +
        '<div class="cf-citation-band"><span>Has satisfied every requirement of the</span></div>' +
        '<div class="cf-pill-wrap"><div class="cf-pill">' + pill + '</div></div>' +
        '<p class="cf-citation-text">Awarded in recognition of the successful completion of <b>all thirteen</b> bundled internal courses of this programme, with ' +
          (isDiploma ? '200.0 verified study hours' : 'the assessed module milestone') +
          ' recorded on the academic transcript overleaf and assessed to the Academy pass standard of <b>60% or higher</b>.</p>' +
      '</div>' +
      '<div class="cf-mid">' +
        '<div class="cf-signs">' +
          '<div class="cf-sign"><span class="cf-sig-ink" aria-hidden="true"></span><div class="cf-sign-line"></div><b>Dr. Evelyn Vance</b><span>MBChB, FCP(SA) · CLINICAL DIRECTOR</span></div>' +
          '<div class="cf-sign"><span class="cf-stamp">Digitally verified · EVOLV3</span><div class="cf-sign-line"></div><b>Beyond AI Assessor</b><span>EVOLV3 TRUE-MATCH ASSESSMENT ENGINE</span></div>' +
        '</div>' +
        '<div class="cf-seal">' + sealSvg() + '</div>' +
      '</div>' +
      '<div class="cf-bottom">' +
        '<div class="cf-meta">' +
          '<div><span>Credential ID</span><b>' + esc(id) + '</b></div>' +
          '<div><span>Date of Issue</span><b>' + esc(date) + '</b></div>' +
          '<div><span>Study Hours Verified</span><b>200.0 h</b></div>' +
        '</div>' +
        '<div class="cf-reverse">Official Academic Transcript Recorded on Reverse Page ↷</div>' +
      '</div>' +
    '</div></div>';
  }

  function transcriptTable(rows, start) {
    return '<table class="cf-table"><thead><tr><th>Module</th><th class="r">Hours</th><th class="r">Status</th></tr></thead><tbody>' +
      rows.map((c) => '<tr><td>' + esc(c.title) + '</td><td class="r">' + Number(c.hours || 0).toFixed(0) + '</td><td class="r"><span class="cf-pass">PASS</span></td></tr>').join('') +
      (rows.length < 7 ? '<tr><td colspan="3" style="border:0"></td></tr>' : '') +
    '</tbody></table>';
  }

  function certBack(kind) {
    const L = S.learner;
    const courses = D.COURSES;
    const left = courses.slice(0, 7);
    const right = courses.slice(7);
    return '<div class="cf-sheet">' +
      '<span class="cf-corner tl" aria-hidden="true"></span><span class="cf-corner tr" aria-hidden="true"></span>' +
      '<span class="cf-corner bl" aria-hidden="true"></span><span class="cf-corner br" aria-hidden="true"></span>' +
      '<div class="cf-inner">' +
      '<div class="cf-back-title"><div><h2>Academic Transcript · Record of Modules</h2><span>Internal Diploma in Professional Development · 200 Hours</span></div>' +
        '<div class="cf-corp" style="text-align:right"><b>Beyond Registration (Pty) Ltd</b><span>REG. NO. 2026721121</span></div></div>' +
      '<div class="cf-transcript">' + transcriptTable(left) + transcriptTable(right) + '</div>' +
      '<div class="cf-summary">' +
        '<div><span>Modules completed</span><b>13</b></div>' +
        '<div><span>Verified study hours</span><b>200.0 <em>h</em></b></div>' +
        '<div><span>Hazard clearance</span><b>100<em>%</em></b></div>' +
        '<div><span>Pass standard</span><b>≥60<em>%</em></b></div>' +
      '</div>' +
      '<div class="cf-legal"><b>South African statutory notice</b>' +
        '<p>This document is an internal, non-accredited corporate recognition of workforce upskilling. It is <b>not</b> registered on the National Qualifications Framework (NQF Act No. 67 of 2008), does <b>not</b> carry SAQA, QCTO or CHE accreditation, and is <b>not</b> a formal qualification under the Higher Education Act No. 101 of 1997. It confers no academic credit and may not be presented as a registered qualification.</p>' +
      '</div>' +
      // The lower band carries the record's own authentication, so the page is
      // balanced: what was assessed above, who stands behind it below.
      '<div class="cf-authband">' +
        '<div class="cf-auth-copy">' +
          '<div class="cf-auth-head">Authentication of this record</div>' +
          '<div class="cf-auth-grid">' +
            '<div><span>Credential ID</span><b>' + esc(A.credentialId(kind)) + '</b></div>' +
            '<div><span>Issued</span><b>' + esc(longDate(L.diplomaIssuedAt || todayISO())) + '</b></div>' +
            '<div><span>Awarded to</span><b>' + esc(L.displayName || 'Academy Learner') + '</b></div>' +
            '<div><span>Assessed by</span><b>EVOLV3 True-Match Assessment Engine</b></div>' +
          '</div>' +
          '<p class="cf-auth-note">Every module above was assessed against the Academy pass standard of 60% or higher. ' +
            'This transcript and the diploma on the reverse page carry the same credential ID; a document whose ID does not match this record has not been issued by the Academy.</p>' +
          '<div class="cf-auth-signs">' +
            '<div class="cf-sign cf-sign-sm"><span class="cf-sig-ink" aria-hidden="true"></span><div class="cf-sign-line"></div><b>Dr. Evelyn Vance</b><span>MBChB, FCP(SA) · CLINICAL DIRECTOR</span></div>' +
            '<div class="cf-sign cf-sign-sm"><span class="cf-stamp">Digitally verified · EVOLV3</span><div class="cf-sign-line"></div><b>Beyond AI Assessor</b><span>EVOLV3 TRUE-MATCH ASSESSMENT ENGINE</span></div>' +
          '</div>' +
        '</div>' +
        '<div class="cf-auth-seal">' + sealSvg() + '</div>' +
      '</div>' +
      '<div class="cf-foot-band">' +
        '<div class="cf-corp" style="text-align:left"><b>Beyond Registration (Pty) Ltd</b><span>REG. NO. 2026721121 · REPUBLIC OF SOUTH AFRICA</span></div>' +
        '<div class="cf-kicker">Internal Workforce Recognition</div>' +
      '</div>' +
      '<div class="cf-foot-note"><span>Credential ID: ' + esc(A.credentialId(kind)) + '</span>' +
        '<span>Issued: ' + esc(longDate(L.diplomaIssuedAt || todayISO())) + ' · ' + esc(L.displayName || 'Academy Learner') + ' · ' + esc(L.role || 'Caregiver') + '</span>' +
        '<span>Page 2 of 2 · Beyond Registration (Pty) Ltd</span></div>' +
    '</div></div>';
  }

  // ---------------------------------------------------------- certificates view
  function renderCertificates() {
    const L = S.learner;
    const completed = Object.keys(L.completions || {}).length;
    const cc = $('#completion-count'); if (cc) cc.textContent = completed + ' module' + (completed === 1 ? '' : 's');
    const holder = $('#cert-holder'); if (holder) holder.textContent = 'Holder · ' + (L.displayName || '—');
    const body = $('#cert-list');
    if (body) {
      const rows = Object.keys(L.completions || {}).map((id) => {
        const c = A.moduleById(id);
        if (!c) return '';
        const rec = L.completions[id] || {};
        return '<tr><td><b>' + esc(c.title) + '</b></td><td><span class="plate pass">PASSED</span></td>' +
          '<td class="num">' + esc(A.credentialId('module-' + id)) + '</td><td class="num">' + esc(shortDate((rec.date || todayISO()).slice(0, 10))) + '</td>' +
          '<td><button class="table-action" data-view-cert="completion">View certificate</button></td></tr>';
      }).join('');
      body.innerHTML = rows || '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:22px">No module milestones issued yet. Pass an evaluation to issue the first record.</td></tr>';
    }
  }

  function fitCertificate() {
    const stage = $('.cert-stage');
    if (!stage) return;
    const scale = Math.min(1, (window.innerWidth - 56) / 1122, (window.innerHeight - 132) / 794);
    stage.style.setProperty('--cert-scale', String(Math.max(0.28, scale)));
  }

  function paintCertificate() {
    const front = certFront(S.certKind);
    const back = certBack(S.certKind);
    const f = $('#cert-front'); if (f) f.innerHTML = front;
    const b = $('#cert-back'); if (b) b.innerHTML = back;
    const name = $('#cert-viewer-name');
    if (name) name.textContent = S.certKind === 'completion' ? 'Certificate of Completion' : 'Internal Diploma · 200 Hours';
    const shell = $('#cert-flip-shell');
    if (shell) shell.classList.toggle('show-back', S.certFace === 'back');
    $$('[data-cert-face]').forEach((btn) => btn.classList.toggle('is-active', btn.dataset.certFace === S.certFace));
    const pr = $('#print-root');
    if (pr) pr.innerHTML = '<div class="print-sheet">' + front + '</div><div class="print-sheet">' + back + '</div>';
    fitCertificate();
  }

  function openCertificate(kind) {
    S.certKind = kind === 'completion' ? 'completion' : 'diploma';
    S.certFace = 'front';
    paintCertificate();
    const viewer = $('#cert-viewer');
    if (viewer) { viewer.classList.add('open'); viewer.setAttribute('aria-hidden', 'false'); }
    document.documentElement.style.overflow = 'hidden';
  }

  function closeCertificate() {
    const viewer = $('#cert-viewer');
    if (viewer) { viewer.classList.remove('open'); viewer.setAttribute('aria-hidden', 'true'); }
    document.documentElement.style.overflow = '';
    const pr = $('#print-root');
    if (pr) pr.innerHTML = '';
  }

  function setCertFace(face) {
    S.certFace = face === 'back' ? 'back' : 'front';
    const shell = $('#cert-flip-shell');
    if (shell) shell.classList.toggle('show-back', S.certFace === 'back');
    $$('[data-cert-face]').forEach((btn) => btn.classList.toggle('is-active', btn.dataset.certFace === S.certFace));
  }

  function printCertificate() {
    paintCertificate();
    setTimeout(() => window.print(), 80);
  }

  // ---------------------------------------------------------- admin
  const PERIODS = {
    daily: { label: 'DAILY REPORT', factor: 1, note: 'Live tracked minutes' },
    weekly: { label: 'WEEKLY REPORT', factor: 5, note: 'Projected from tracked minutes (5 study days)' },
    monthly: { label: 'MONTHLY REPORT', factor: 21, note: 'Projected from tracked minutes (21 study days)' }
  };

  function hazardCount(completions) {
    const ids = ['brc-03', 'brc-06', 'brc-07', 'brc-13'];
    const weekly = (S.weeklyModules || []).map((m) => m.id);
    return ids.concat(weekly).filter((id) => completions && completions[id]).length;
  }

  function adminRows() {
    const L = S.learner;
    const lb = leaderboardRows();
    const rows = lb.map((r) => ({
      name: r.name,
      role: r.role,
      minutes: Number(r.minutes) || 0,
      avg: Number(r.avgScore) || null,
      completed: Number(r.completed) || 0,
      hazard: hazardCount(r.current ? L.completions : {}),
      points: Number(r.points) || 0,
      attempts: Number(r.attempts) || 0,
      badges: Number(r.badges) || 0,
      updatedAt: r.updatedAt || '',
      current: !!r.current,
      source: 'EVOLV3 learner record'
    }));
    const seen = new Set(rows.map((r) => String(r.name || '').toLowerCase()));
    (S.employees || []).forEach((e) => {
      const name = e.full_name || ((e.first_name || '') + ' ' + (e.last_name || '')).trim() || e.name || e.employee_no || 'Employee';
      if (seen.has(name.toLowerCase())) return;
      seen.add(name.toLowerCase());
      rows.push({
        name: name,
        role: e.role || e.job_title || (String(e.department || '').toLowerCase().indexOf('care') !== -1 ? 'Caregiver' : 'Clinical Staff'),
        minutes: 0,
        avg: null,
        completed: 0,
        hazard: 0,
        points: 0,
        attempts: 0,
        badges: 0,
        updatedAt: e.updated_at || '',
        current: false,
        source: 'N3XUS employee record · no academy activity yet'
      });
    });
    return rows;
  }

  function filteredAdminRows() {
    const q = S.adminQuery.trim().toLowerCase();
    return adminRows().filter((r) => {
      if (S.adminRole && r.role !== S.adminRole) return false;
      if (!q) return true;
      return (r.name + ' ' + r.role + ' ' + r.source).toLowerCase().indexOf(q) !== -1;
    });
  }

  function renderAdmin() {
    const period = PERIODS[S.adminPeriod] || PERIODS.daily;
    $$('#period-switch .filter').forEach((b) => b.classList.toggle('is-active', b.dataset.period === S.adminPeriod));
    const label = $('#admin-period-label'); if (label) label.textContent = period.label;
    const gen = $('#admin-generated'); if (gen) gen.textContent = 'Generated ' + new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
    const rows = filteredAdminRows();
    const all = adminRows();
    const totalMinutes = all.reduce((a, r) => a + r.minutes, 0) * period.factor;
    const attempts = (S.learner.attempts || []).length;
    const learnerAvg = attempts ? (S.learner.attempts.reduce((a, x) => a + Number(x.score || 0), 0) / attempts) : 0;
    const scored = all.filter((r) => r.avg !== null);
    const avg = scored.length ? Math.round(scored.reduce((a, r) => a + Number(r.avg), 0) / scored.length) : Math.round(learnerAvg);
    const hazard = all.reduce((a, r) => a + r.hazard, 0);
    const diplomas = all.filter((r) => r.completed >= 13 || r.minutes >= 12000).length;

    const kpi = $('#admin-kpis');
    if (kpi) {
      kpi.innerHTML = '<article class="kpi"><div class="kpi-top"><span>Total study volume</span><span class="live-dot" title="Synced to the live study timer"></span></div>' +
        '<div class="kpi-value">' + esc(hoursLabel(totalMinutes)) + '</div><div class="kpi-sub">' + esc(period.note) + ' · synced to the live timer</div></article>' +
        '<article class="kpi"><div class="kpi-top"><span>Avg AI true match</span><span>◎</span></div>' +
        '<div class="kpi-value">' + (avg || 0) + '<small>%</small></div><div class="kpi-sub">Weighted across learner attempts</div></article>' +
        '<article class="kpi"><div class="kpi-top"><span>Hazard verified</span><span>⚑</span></div>' +
        '<div class="kpi-value">' + hazard + '<small> modules</small></div><div class="kpi-sub">Choking, falls, first aid, environment</div></article>' +
        '<article class="kpi"><div class="kpi-top"><span>200h diplomas conferred</span><span>🎓</span></div>' +
        '<div class="kpi-value">' + diplomas + '<small> records</small></div><div class="kpi-sub">13 modules · 12,000 verified minutes</div></article>';
    }

    const body = $('#admin-body');
    if (body) {
      body.innerHTML = rows.length ? rows.map((r) => {
        const diplomaPct = Math.min(100, Math.round((r.completed / 13) * 100));
        return '<tr>' +
          '<td><b>' + esc(r.name) + '</b>' + (r.current ? '<span class="table-sub">Active study timer</span>' : '') + '</td>' +
          '<td>' + esc(r.role || '—') + '</td>' +
          '<td class="num">' + nf(r.minutes * period.factor) + ' min</td>' +
          '<td class="num">' + (r.avg === null ? '—' : r.avg + '%') + '</td>' +
          '<td class="num">' + r.hazard + ' / 4</td>' +
          '<td><div class="progress-inline"><div class="xp-track"><i style="width:' + diplomaPct + '%"></i></div><b>' + r.completed + '/13</b></div></td>' +
          '<td class="num">' + (r.updatedAt ? timeAgo(r.updatedAt) : '—') + '</td>' +
          '<td><button class="table-action" data-audit="' + esc(r.name) + '">Audit</button></td>' +
        '</tr>';
      }).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--muted);padding:24px">No staff match this filter.</td></tr>';
    }
  }

  function openAudit(name) {
    const row = adminRows().find((r) => r.name === name);
    if (!row) return;
    $$('.audit-drawer, .drawer-backdrop').forEach((n) => n.remove());
    const wrap = document.createElement('div');
    const period = PERIODS[S.adminPeriod] || PERIODS.daily;
    wrap.innerHTML = '<div class="drawer-backdrop open" data-audit-close></div>' +
      '<aside class="audit-drawer open" role="dialog" aria-modal="true" aria-label="Audit detail">' +
        '<div class="audit-head"><div><div class="eyebrow">AUDIT DETAIL</div><h3 style="font-size:17px;margin-top:2px">' + esc(row.name) + '</h3></div><button class="icon-pill" data-audit-close aria-label="Close">✕</button></div>' +
        '<div class="audit-body">' +
          '<div class="audit-row"><span>Role</span><b>' + esc(row.role || '—') + '</b></div>' +
          '<div class="audit-row"><span>Report period</span><b>' + esc(period.label) + '</b></div>' +
          '<div class="audit-row"><span>Tracked study minutes</span><b>' + nf(row.minutes) + '</b></div>' +
          '<div class="audit-row"><span>Period study volume</span><b>' + esc(hoursLabel(row.minutes * period.factor)) + '</b></div>' +
          '<div class="audit-row"><span>Average true match</span><b>' + (row.avg === null ? 'No attempts' : row.avg + '%') + '</b></div>' +
          '<div class="audit-row"><span>Modules completed</span><b>' + row.completed + ' / 13</b></div>' +
          '<div class="audit-row"><span>Hazard modules verified</span><b>' + row.hazard + ' / 4</b></div>' +
          '<div class="audit-row"><span>Evaluation attempts</span><b>' + row.attempts + '</b></div>' +
          '<div class="audit-row"><span>Badges unlocked</span><b>' + row.badges + '</b></div>' +
          '<div class="audit-row"><span>Points balance</span><b>' + nf(row.points) + '</b></div>' +
          '<div class="audit-row"><span>Last activity</span><b>' + (row.updatedAt ? esc(timeAgo(row.updatedAt)) : '—') + '</b></div>' +
          '<div class="audit-row"><span>Data source</span><b>' + esc(row.source) + '</b></div>' +
          '<p class="auth-note" style="margin-top:14px">Read-only record. Certificate names, roles and scores cannot be edited from this portal. Score percentages are omitted from issued certificates by design.</p>' +
        '</div>' +
        '<div style="padding:14px;border-top:1px solid var(--border)"><button class="btn btn-primary btn-wide" id="audit-print">Print this audit</button></div>' +
      '</aside>';
    document.body.appendChild(wrap);
    const printBtn = $('#audit-print');
    if (printBtn) printBtn.addEventListener('click', () => printAuditRow(row));
  }

  function closeAudit() {
    $$('.audit-drawer, .drawer-backdrop').forEach((n) => n.remove());
  }

  function auditPrintMarkup(rows, title, period) {
    const total = rows.reduce((a, r) => a + r.minutes, 0);
    return '<div class="print-sheet"><div style="padding:34px 40px;font-family:Plus Jakarta Sans,sans-serif;color:#0f172a">' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #115e59;padding-bottom:10px">' +
        '<div><div style="font-family:IBM Plex Mono,monospace;font-size:10px;letter-spacing:.14em;color:#0f766e">BEYOND REGISTRATION (PTY) LTD · REG. NO. 2026721121</div>' +
        '<h1 style="font-size:24px;margin:6px 0 2px">' + esc(title) + '</h1>' +
        '<div style="font-family:IBM Plex Mono,monospace;font-size:9px;color:#64748b">' + esc(period) + ' · Generated ' + esc(new Date().toLocaleString('en-ZA')) + '</div></div>' +
        '<div style="font-family:IBM Plex Mono,monospace;font-size:9px;color:#64748b;text-align:right">EVOLV3 ACADEMY<br>INTERNAL WORKFORCE UPSKILLING<br>NON-ACCREDITED</div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0">' +
        '<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px"><div style="font-size:8px;color:#64748b;letter-spacing:.08em">STUDY VOLUME</div><b style="font-family:IBM Plex Mono,monospace;font-size:16px">' + esc(hoursLabel(total)) + '</b></div>' +
        '<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px"><div style="font-size:8px;color:#64748b;letter-spacing:.08em">STAFF RECORDS</div><b style="font-family:IBM Plex Mono,monospace;font-size:16px">' + rows.length + '</b></div>' +
        '<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px"><div style="font-size:8px;color:#64748b;letter-spacing:.08em">MODULES PASSED</div><b style="font-family:IBM Plex Mono,monospace;font-size:16px">' + rows.reduce((a, r) => a + r.completed, 0) + '</b></div>' +
        '<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px"><div style="font-size:8px;color:#64748b;letter-spacing:.08em">HAZARD VERIFIED</div><b style="font-family:IBM Plex Mono,monospace;font-size:16px">' + rows.reduce((a, r) => a + r.hazard, 0) + '</b></div>' +
      '</div>' +
      '<table style="width:100%;border-collapse:collapse;font-size:10px"><thead><tr>' +
        ['Staff', 'Role', 'Study', 'Avg match', 'Hazard', 'Modules', 'Last active'].map((h) => '<th style="text-align:left;padding:6px;border-bottom:1px solid #cbd5e1;font-family:IBM Plex Mono,monospace;font-size:8px;letter-spacing:.08em;color:#64748b">' + h.toUpperCase() + '</th>').join('') +
      '</tr></thead><tbody>' + rows.map((r) => '<tr>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9"><b>' + esc(r.name) + '</b></td>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9">' + esc(r.role) + '</td>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9;font-family:IBM Plex Mono,monospace">' + nf(r.minutes) + ' min</td>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9;font-family:IBM Plex Mono,monospace">' + (r.avg === null ? '—' : r.avg + '%') + '</td>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9;font-family:IBM Plex Mono,monospace">' + r.hazard + '/4</td>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9;font-family:IBM Plex Mono,monospace">' + r.completed + '/13</td>' +
        '<td style="padding:6px;border-bottom:1px solid #f1f5f9">' + (r.updatedAt ? esc(timeAgo(r.updatedAt)) : '—') + '</td>' +
      '</tr>').join('') + '</tbody></table>' +
      '<p style="margin-top:14px;font-size:8px;color:#64748b;line-height:1.55">Internal, non-accredited corporate recognition for workforce upskilling. Not registered on the NQF (NQF Act No. 67 of 2008); no SAQA, QCTO or CHE accreditation; not a formal qualification under the Higher Education Act No. 101 of 1997.</p>' +
    '</div></div>';
  }

  function printAudit() {
    const rows = filteredAdminRows();
    const period = PERIODS[S.adminPeriod] || PERIODS.daily;
    const pr = $('#print-root');
    if (pr) pr.innerHTML = auditPrintMarkup(rows, 'Training Audit Report', period.label);
    setTimeout(() => window.print(), 80);
  }

  function printAuditRow(row) {
    const pr = $('#print-root');
    if (pr) pr.innerHTML = auditPrintMarkup([row], 'Individual Training Audit', (PERIODS[S.adminPeriod] || PERIODS.daily).label);
    setTimeout(() => window.print(), 80);
  }

  function exportCsv() {
    const rows = filteredAdminRows();
    const period = PERIODS[S.adminPeriod] || PERIODS.daily;
    const header = ['Staff', 'Role', 'Tracked minutes', 'Period study', 'Avg true match', 'Hazard verified', 'Modules completed', 'Points', 'Last active', 'Source'];
    const lines = [header.join(',')].concat(rows.map((r) => [
      r.name, r.role, r.minutes, hoursLabel(r.minutes * period.factor),
      r.avg === null ? '' : r.avg + '%', r.hazard + '/4', r.completed + '/13',
      r.points, r.updatedAt ? timeAgo(r.updatedAt) : '', r.source
    ].map((v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(',')));
    lines.push('');
    lines.push('"Beyond Registration (Pty) Ltd · Reg. No. 2026721121"');
    lines.push('"Internal, non-accredited workforce upskilling · NQF Act 67 of 2008 · no SAQA/QCTO/CHE accreditation · Higher Education Act 101 of 1997"');
    A.U.download('your-userd-registration-training-audit-' + todayISO() + '.csv', lines.join('\r\n'), 'text/csv;charset=utf-8');
    toast('CSV report exported.');
  }

  // ---------------------------------------------------------- evolution panel
  function renderEvolution() {
    const st = S.evolutionState;
    const ev = $('#evo-version'); if (ev) ev.textContent = st.version || '2.0.0';
    const ew = $('#evo-week'); if (ew) ew.textContent = 'Week ' + (st.weekNumber || 1);
    const el = $('#evo-last'); if (el) el.textContent = st.lastEvolvedAt ? longDate(st.lastEvolvedAt) : '—';
    const en = $('#evo-next'); if (en) en.textContent = S.nextRunAt ? longDate(S.nextRunAt) : 'Due now';
    const es = $('#evo-source'); if (es) es.textContent = (S.weeklyModules || []).some((m) => m.source === 'gemini') ? 'Gemini + local clinical generator' : 'Local clinical generator';
    const days = A.daysUntilEvolution();
    const dd = $('#evo-days'); if (dd) dd.textContent = days + ' day' + (days === 1 ? '' : 's');
    const df = $('#evo-days-fill'); if (df) df.style.width = Math.max(0, Math.min(100, Math.round(((7 - days) / 7) * 100))) + '%';
    const auto = $('#auto-wifi'); if (auto) auto.checked = !!st.autoUpdateOnWifi;

    const items = [];
    (S.weeklyModules || []).forEach((m) => items.push({ week: m.weekAdded, kind: 'Module', title: m.title }));
    (S.weeklyEvals || []).forEach((e) => items.push({ week: e.weekAdded, kind: e.kind === 'quiz' ? 'Quiz' : e.kind === 'assignment' ? 'Assignment' : 'Short question', title: e.prompt }));
    (S.weeklyProtocols || []).forEach((p) => items.push({ week: p.weekAdded, kind: 'Protocol', title: p.title }));
    const count = $('#evo-count'); if (count) count.textContent = items.length + ' items';
    const list = $('#evo-added-list');
    if (list) {
      list.innerHTML = items.length ? items.slice(-12).reverse().map((i) => '<div class="mini-row"><div><b>W' + esc(i.week || '') + ' · ' + esc(i.kind) + '</b><small>' + esc(String(i.title || '').slice(0, 90)) + '</small></div><span class="tag">Appended</span></div>').join('') : '<span class="muted" style="font-size:10px">No weekly additions yet. Base curriculum is Week 1; the first automatic evolution appends Week 2.</span>';
    }
    const tl = $('#evo-timeline');
    if (tl) {
      const log = (st.changelog || []).slice(0, 12);
      tl.innerHTML = log.length ? log.map((c) => '<div class="timeline-item"><b>Week ' + esc(c.week) + ' · ' + esc(c.addedModuleTitle || 'Curriculum update') + '</b><span>' + esc(longDate(c.date)) + '</span><p>' + esc(c.summary || '') + '</p></div>').join('') : '<span class="muted" style="font-size:10px">No weekly evolution recorded yet. Base curriculum is Week 1.</span>';
    }
    const wc = $('#week-chip'); if (wc) wc.textContent = 'W' + (st.weekNumber || 1);
  }

  // ---------------------------------------------------------- deadlines
  function deadlineItems() {
    const items = [];
    (S.evolutionState.changelog || []).slice(0, 2).forEach((c) => items.push({
      icon: '✦', title: 'Week ' + c.week + ' Module Live',
      detail: c.addedModuleTitle + ' · three new evaluations added',
      due: 'New'
    }));
    items.push({ icon: '⏳', title: 'Choking & Dysphagia practical assessment', detail: 'Book a supervised scenario with your clinical lead.', due: 'in 3 days' });
    items.push({ icon: '⏳', title: 'Manual handling competency sign-off', detail: 'Hoist and slide-sheet observation due this cycle.', due: 'in 6 days' });
    items.push({ icon: '◷', title: 'Dementia care case reflection', detail: 'Submit a 150-word reflection on a recent de-escalation.', due: 'in 9 days' });
    items.push({ icon: '◆', title: 'Weekly study drop', detail: 'A new clinical protocol is appended every seven days.', due: 'weekly' });
    return items;
  }

  // ---------------------------------------------------------- modal
  function openModal(eyebrow, title, body, foot, size) {
    const back = $('#modal-backdrop');
    const modal = $('#modal');
    if (!modal) return;
    $('#modal-eyebrow').textContent = eyebrow || 'EVOLV3 ACADEMY';
    $('#modal-title').textContent = title || 'Details';
    $('#modal-body').innerHTML = body || '';
    $('#modal-foot').innerHTML = foot || '';
    modal.classList.toggle('wide', size === 'wide');
    modal.classList.add('open');
    back.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    back.setAttribute('aria-hidden', 'false');
  }

  function closeModal() {
    const modal = $('#modal');
    const back = $('#modal-backdrop');
    if (modal) { modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); }
    if (back) { back.classList.remove('open'); back.setAttribute('aria-hidden', 'true'); }
  }

  // ---------------------------------------------------------- refresh all
  function refreshAll() {
    if (window.ACADEMY.renderHeader) window.ACADEMY.renderHeader();
    if (window.ACADEMY.renderCourses) window.ACADEMY.renderCourses();
    if (window.ACADEMY.renderLibrary) window.ACADEMY.renderLibrary();
    if (window.ACADEMY.renderEvaluations) window.ACADEMY.renderEvaluations();
    renderLeaderboard();
    renderProgress();
    renderCertificates();
    renderAdmin();
    renderEvolution();
  }

  A.levelInfo = levelInfo;
  A.leaderboardRows = leaderboardRows;
  A.renderLeaderboard = renderLeaderboard;
  A.renderProgress = renderProgress;
  A.moduleBest = moduleBest;
  A.renderCertificates = renderCertificates;
  A.openCertificate = openCertificate;
  A.closeCertificate = closeCertificate;
  A.setCertFace = setCertFace;
  A.printCertificate = printCertificate;
  A.certFront = certFront;
  A.certBack = certBack;
  A.fitCertificate = fitCertificate;
  A.renderAdmin = renderAdmin;
  A.adminRows = adminRows;
  A.filteredAdminRows = filteredAdminRows;
  A.openAudit = openAudit;
  A.closeAudit = closeAudit;
  A.printAudit = printAudit;
  A.exportCsv = exportCsv;
  A.renderEvolution = renderEvolution;
  A.deadlineItems = deadlineItems;
  A.PERIODS = PERIODS;
  A.openModal = openModal;
  A.closeModal = closeModal;
  A.refreshAll = refreshAll;
  A.LEVELS = LEVELS;
})();
