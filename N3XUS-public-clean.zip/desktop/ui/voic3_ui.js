/* ============================================================
   VOIC3 — messaging, calls and meetings for the N3XUS workspace.

   This file adds the WhatsApp/Telegram-style interface on top of the
   VOIC3 routes the server already had (conversations, messages,
   receipts, calls, meetings). Nothing here needs a third-party service,
   an API key or a subscription: messages travel over the app's own
   server, calls are peer-to-peer WebRTC with the server's own STUN/TURN
   settings, and meetings reuse the existing lobby/stage engine.

   Public API: window.Voic3UI.render() -> HTML for the VOIC3 page
               window.Voic3UI.mount()  -> wire the rendered page
               window.Voic3UI.openConversation(id)
               window.Voic3UI.startCall(employeeId, type)
               window.Voic3UI.startMeeting(type)
   ============================================================ */
(function () {
  'use strict';

  /* ---------------------------------------------------------------- state -- */
  const state = {
    tab: 'chats',            // chats | calls | meetings
    conversations: [],
    contacts: [],
    calls: [],
    meetings: [],
    activeId: null,
    active: null,
    messages: [],
    me: null,
    search: '',
    typing: null,
    unreadTotal: 0,
    pollTimer: 0,
    eventSource: null,
    call: null,              // { id, type, peerId, peerName, pc, stream, ... }
    signalAfter: 0,
    picked: [],              // employee ids chosen in the meeting picker
    mounted: false
  };

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function toast(msg, kind) {
    if (window.toast) { window.toast(msg, kind || 'success'); return; }
    const el = document.createElement('div');
    el.className = 'v3-toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }
  function api(path, method, body) {
    if (window.api) return window.api(path, method || 'GET', body);
    const opt = { method: method || 'GET', headers: { Accept: 'application/json' }, credentials: 'same-origin' };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    return fetch(path, opt).then((r) => r.json().then((d) => {
      if (!r.ok) throw new Error(d.error || ('Request failed (' + r.status + ')'));
      return d;
    }));
  }
  function initials(name) {
    return String(name || '?').trim().split(/\s+/).slice(0, 2).map((p) => (p[0] || '').toUpperCase()).join('') || '?';
  }
  /* Deterministic avatar colour, so a person keeps the same colour everywhere. */
  function hue(seed) {
    let h = 0;
    const s = String(seed || '');
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
    return h;
  }
  function avatar(name, size) {
    const h = hue(name);
    return '<span class="v3-av' + (size ? ' ' + size : '') + '" style="--av-h:' + h + '">' + esc(initials(name)) + '</span>';
  }
  function clock(value) {
    if (!value) return '';
    const d = new Date(String(value).replace(' ', 'T'));
    if (isNaN(d)) return '';
    const today = new Date();
    const sameDay = d.toDateString() === today.toDateString();
    if (sameDay) return d.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit', hour12: false });
    const yest = new Date(today.getTime() - 86400000);
    if (d.toDateString() === yest.toDateString()) return 'Yesterday';
    return d.toLocaleDateString('en-ZA', { day: '2-digit', month: 'short' });
  }
  function dayLabel(value) {
    const d = new Date(String(value).replace(' ', 'T'));
    if (isNaN(d)) return '';
    const today = new Date();
    if (d.toDateString() === today.toDateString()) return 'Today';
    const yest = new Date(today.getTime() - 86400000);
    if (d.toDateString() === yest.toDateString()) return 'Yesterday';
    return d.toLocaleDateString('en-ZA', { weekday: 'long', day: '2-digit', month: 'long' });
  }
  function duration(seconds) {
    const s = Number(seconds);
    if (!s && s !== 0) return '';
    const m = Math.floor(s / 60);
    const r = s % 60;
    return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r;
  }

  /* ------------------------------------------------------------ transport -- */
  async function loadAll() {
    const jobs = [
      api('/api/voic3/conversations').catch(() => ({ items: [] })),
      api('/api/voic3/contacts').catch(() => ({ items: [] })),
      api('/api/voic3/calls').catch(() => ({ items: [] })),
      api('/api/voic3/meetings').catch(() => ({ items: [] }))
    ];
    const [conv, contacts, calls, meetings] = await Promise.all(jobs);
    state.conversations = conv.items || [];
    state.contacts = contacts.items || [];
    state.calls = calls.items || [];
    state.meetings = meetings.items || [];
    const meContact = state.contacts.find((c) => c.is_me);
    const sessionEmployeeId = window.currentUser && (window.currentUser.employee_id || window.currentUser.id);
    state.me = meContact ? meContact.employee_id : (sessionEmployeeId != null ? Number(sessionEmployeeId) : null);
    state.unreadTotal = state.conversations.reduce((a, c) => a + (Number(c.unread) || 0), 0);
  }

  function contactById(id) {
    return state.contacts.find((c) => Number(c.employee_id) === Number(id)) || null;
  }
  function contactName(id) {
    const c = contactById(id);
    return c ? c.name : 'Employee ' + id;
  }

  /* Live updates: the server's own event stream. If it is unavailable the page
     still refreshes on a short timer, so nothing is ever missed silently. */
  function connectEvents() {
    if (state.eventSource || !window.EventSource) return;
    try {
      const es = new EventSource('/api/voic3/events');
      state.eventSource = es;
      es.onmessage = (ev) => {
        let payload = null;
        try { payload = JSON.parse(ev.data); } catch (e) { return; }
        handleEvent(payload);
      };
      es.onerror = () => { /* the browser retries on its own */ };
    } catch (e) { /* fall back to polling only */ }
  }
  function disconnectEvents() {
    if (state.eventSource) { try { state.eventSource.close(); } catch (e) { } state.eventSource = null; }
  }

  function handleEvent(payload) {
    const type = payload.type || payload.event || '';
    const data = payload.data || payload;
    if (type === 'message.new') {
      refreshConversations();
      if (state.activeId && Number(data.conversation_id) === Number(state.activeId)) loadMessages(state.activeId);
    } else if (type === 'message.receipt') {
      if (state.activeId) loadMessages(state.activeId, true);
    } else if (type === 'typing') {
      if (state.activeId && Number(data.conversation_id) === Number(state.activeId) && Number(data.employee_id) !== Number(state.me)) {
        state.typing = { id: Number(data.employee_id), at: Date.now() };
        paintTyping();
        clearTimeout(state.typingTimer);
        state.typingTimer = setTimeout(() => { state.typing = null; paintTyping(); }, 4000);
      }
    } else if (type === 'call.incoming') {
      // SSE is employee-scoped, but validate both IDs as a defensive UI boundary.
      if (state.me == null || data.callee_employee_id == null || Number(data.callee_employee_id) !== Number(state.me)) return;
      if (data.caller_employee_id == null || Number(data.caller_employee_id) === Number(state.me)) return;
      ringIncoming(data);
    } else if (type === 'call.state') {
      onCallState(data);
    } else if (type === 'call.signal') {
      onCallSignal(data);
    } else if (type === 'meeting.invite') {
      toast('Meeting invitation: ' + (data.title || 'a meeting'));
      refreshMeetings();
    }
  }

  async function refreshConversations() {
    try {
      const d = await api('/api/voic3/conversations');
      state.conversations = d.items || [];
      state.unreadTotal = state.conversations.reduce((a, c) => a + (Number(c.unread) || 0), 0);
      paintList();
      paintTabBadges();
    } catch (e) { /* keep the list we have */ }
  }
  async function refreshMeetings() {
    try {
      const d = await api('/api/voic3/meetings');
      state.meetings = d.items || [];
      if (state.mounted) paintMeetings();
    } catch (e) { }
  }
  async function refreshCalls() {
    try {
      const d = await api('/api/voic3/calls');
      state.calls = d.items || [];
      if (state.mounted) paintCalls();
    } catch (e) { }
  }

  /* ------------------------------------------------------------------ page -- */
  function render() {
    return '' +
      '<div class="page-head v3-head"><div><div class="eyebrow">TELECOMMUNICATIONS</div>' +
      '<h1>VOIC3</h1><p>Messages, voice calls, video calls and group meetings — inside your own workspace, with no external service or key.</p></div>' +
      '<div class="v3-head-actions">' +
      '<button class="btn btn-primary v3-new-btn" type="button" data-v3="new-chat">' + icon('plus') + ' New chat</button>' +
      '<button class="btn btn-secondary v3-new-btn" type="button" data-v3="new-meeting">' + icon('users') + ' Meeting</button>' +
      '</div></div>' +
      '<div class="v3-tabs" role="tablist">' +
      '<button type="button" class="v3-tab active" data-v3-tab="chats" role="tab">Chats<span class="v3-tab-badge" id="v3-badge-chats" hidden>0</span></button>' +
      '<button type="button" class="v3-tab" data-v3-tab="calls" role="tab">Calls</button>' +
      '<button type="button" class="v3-tab" data-v3-tab="meetings" role="tab">Meetings</button>' +
      '</div>' +
      '<div class="v3-shell">' +
      '<section class="v3-list-pane">' +
      '<div class="v3-search"><input id="v3-search" type="search" placeholder="Search people and chats" aria-label="Search chats"></div>' +
      '<div class="v3-list" id="v3-list"><div class="v3-empty">Loading conversations…</div></div>' +
      '</section>' +
      '<section class="v3-chat-pane" id="v3-chat-pane">' + emptyChat() + '</section>' +
      '</div>' +
      '<div class="v3-calls-pane" id="v3-calls-pane" hidden></div>' +
      '<div class="v3-meet-pane" id="v3-meet-pane" hidden></div>';
  }

  function emptyChat() {
    return '<div class="v3-chat-empty"><div class="v3-chat-empty-art">' + icon('message') + '</div>' +
      '<h2>Select a chat</h2><p>Pick someone from the list, or start a new conversation. Voice and video call buttons sit at the top of every chat.</p></div>';
  }

  /* ------------------------------------------------------------ list pane -- */
  function filteredConversations() {
    const q = state.search.trim().toLowerCase();
    const list = state.conversations.filter((c) => {
      if (!q) return true;
      const hay = [c.title, c.department, (c.members || []).map((m) => m.name).join(' ')].join(' ').toLowerCase();
      return hay.indexOf(q) >= 0;
    });
    return list;
  }
  function filteredContacts() {
    const q = state.search.trim().toLowerCase();
    return state.contacts.filter((c) => {
      if (c.is_me) return false;
      if (!q) return true;
      return (c.name + ' ' + (c.department || '') + ' ' + (c.job_title || '') + ' ' + (c.employee_no || '')).toLowerCase().indexOf(q) >= 0;
    });
  }

  function conversationRow(c) {
    const last = c.last_message || {};
    const preview = last.body ? String(last.body).slice(0, 60) : 'No messages yet';
    const active = Number(c.id) === Number(state.activeId) ? ' active' : '';
    const unread = Number(c.unread) || 0;
    return '<button type="button" class="v3-conv' + active + '" data-v3="open" data-id="' + c.id + '">' +
      avatar(c.title) +
      '<span class="v3-conv-main"><span class="v3-conv-top"><b>' + esc(c.title) + '</b>' +
      '<small>' + esc(clock(last.created_at || c.created_at)) + '</small></span>' +
      '<span class="v3-conv-bottom"><span class="v3-conv-last">' + esc(preview) + '</span>' +
      (unread ? '<span class="v3-unread">' + (unread > 99 ? '99+' : unread) + '</span>' : '') +
      '</span></span></button>';
  }

  function contactRow(c) {
    return '<button type="button" class="v3-conv v3-contact" data-v3="contact" data-id="' + c.employee_id + '">' +
      avatar(c.name) +
      '<span class="v3-conv-main"><span class="v3-conv-top"><b>' + esc(c.name) + '</b>' +
      '<small>' + (c.presence === 'online' ? 'online' : '') + '</small></span>' +
      '<span class="v3-conv-bottom"><span class="v3-conv-last">' + esc(c.job_title || c.department || c.employee_no || 'Employee') + '</span>' +
      '<span class="v3-row-calls">' +
      '<span class="v3-mini" data-v3="quick-call" data-id="' + c.employee_id + '" data-kind="audio" title="Voice call">' + icon('phone') + '</span>' +
      '<span class="v3-mini" data-v3="quick-call" data-id="' + c.employee_id + '" data-kind="video" title="Video call">' + icon('video') + '</span>' +
      '</span></span></span></button>';
  }

  function paintList() {
    const box = $('#v3-list');
    if (!box) return;
    if (state.tab === 'calls' || state.tab === 'meetings') return;
    const convs = filteredConversations();
    const people = filteredContacts();
    let html = '';
    if (convs.length) {
      html += '<div class="v3-list-label">Conversations</div>' + convs.map(conversationRow).join('');
    }
    if (people.length) {
      html += '<div class="v3-list-label">People</div>' + people.slice(0, 60).map(contactRow).join('');
    }
    if (!html) html = '<div class="v3-empty">No chats or people match your search.</div>';
    box.innerHTML = html;
  }

  function paintTabBadges() {
    const b = $('#v3-badge-chats');
    if (b) {
      b.textContent = state.unreadTotal > 99 ? '99+' : String(state.unreadTotal);
      b.hidden = !state.unreadTotal;
    }
  }

  /* ------------------------------------------------------------ chat pane -- */
  function chatHeader(conv) {
    const peer = conv.peer_employee_id || ((conv.members || []).find((m) => Number(m.employee_id) !== Number(state.me)) || {}).employee_id;
    const sub = conv.kind === 'group'
      ? ((conv.members || []).length + ' participants')
      : ((conv.members || []).length > 1 ? 'Direct message' : 'Direct message');
    return '<div class="v3-chat-head">' +
      '<button type="button" class="v3-icon-btn v3-back" data-v3="back" aria-label="Back to chats">' + icon('chevron') + '</button>' +
      avatar(conv.title) +
      '<div class="v3-chat-who"><b>' + esc(conv.title) + '</b><small id="v3-chat-sub">' + esc(sub) + '</small></div>' +
      '<div class="v3-chat-actions">' +
      '<button type="button" class="v3-icon-btn" data-v3="call" data-kind="audio" data-peer="' + (peer || '') + '" title="Voice call" aria-label="Voice call">' + icon('phone') + '</button>' +
      '<button type="button" class="v3-icon-btn" data-v3="call" data-kind="video" data-peer="' + (peer || '') + '" title="Video call" aria-label="Video call">' + icon('video') + '</button>' +
      '<button type="button" class="v3-icon-btn" data-v3="new-meeting" title="Start a group meeting" aria-label="Start a group meeting">' + icon('users') + '</button>' +
      '</div></div>';
  }

  async function copyMessage(messageId) {
    const message = state.messages.find((item) => Number(item.id) === Number(messageId));
    if (!message || !message.body) return;
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(String(message.body));
      else {
        const field = document.createElement('textarea'); field.value = String(message.body); field.setAttribute('readonly', '');
        field.style.position = 'fixed'; field.style.opacity = '0'; document.body.appendChild(field); field.select();
        const copied = document.execCommand('copy'); field.remove(); if (!copied) throw new Error('Copy is unavailable on this device.');
      }
      toast('Message copied');
    } catch (error) { toast(error.message || 'Could not copy message', 'error'); }
  }

  function messageRow(m) {
    const mine = m.is_me || (state.me != null && Number(m.employee_id) === Number(state.me));
    const tick = mine ? '<span class="v3-tick' + (Number(m.read_count) > 0 ? ' read' : '') + '" title="' +
      (Number(m.read_count) > 0 ? 'Read' : 'Sent') + '">' + (Number(m.read_count) > 0 ? '✓✓' : '✓') + '</span>' : '';
    return '<div class="v3-msg ' + (mine ? 'out' : 'in') + '" data-mid="' + m.id + '">' +
      (mine ? '' : '<span class="v3-msg-who">' + esc(m.sender_name || m.sender || '') + '</span>') +
      '<div class="v3-bubble"><span class="v3-text">' + esc(m.body || '').replace(/\n/g, '<br>') + '</span>' +
      '<div class="v3-meta-row"><span class="v3-meta">' + esc(clock(m.created_at)) + tick + '</span>' +
      '<button type="button" class="v3-copy-message" data-v3="copy-message" data-id="' + Number(m.id) + '" title="Copy message" aria-label="Copy message">' + icon('clipboard') + '</button></div></div></div>';
  }

  function messagesMarkup() {
    if (!state.messages.length) {
      return '<div class="v3-chat-empty small"><p>No messages yet — say hello.</p></div>';
    }
    let out = '';
    let lastDay = '';
    state.messages.forEach((m) => {
      const day = dayLabel(m.created_at);
      if (day && day !== lastDay) { out += '<div class="v3-day">' + esc(day) + '</div>'; lastDay = day; }
      out += messageRow(m);
    });
    return out;
  }

  function paintChat() {
    const pane = $('#v3-chat-pane');
    if (!pane || !state.active) return;
    const conv = state.active;
    pane.innerHTML = chatHeader(conv) +
      '<div class="v3-messages" id="v3-messages">' + messagesMarkup() + '</div>' +
      '<div class="v3-typing" id="v3-typing" hidden></div>' +
      '<form class="v3-compose" id="v3-compose" autocomplete="off">' +
      '<button type="button" class="v3-icon-btn" data-v3="attach" title="Attach a file" aria-label="Attach a file">' + icon('paperclip') + '</button>' +
      '<input type="file" id="v3-file" hidden>' +
      '<textarea id="v3-input" rows="1" placeholder="Type a message" aria-label="Message"></textarea>' +
      '<button type="submit" class="v3-send" title="Send" aria-label="Send">' + icon('send') + '</button>' +
      '</form>';
    const box = $('#v3-messages');
    if (box) box.scrollTop = box.scrollHeight;
    const input = $('#v3-input');
    if (input) {
      input.focus();
      input.addEventListener('input', () => {
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 120) + 'px';
        if (state.activeId) api('/api/voic3/conversations/' + state.activeId + '/typing', 'POST', {}).catch(() => { });
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage(input.value);
        }
      });
    }
  }

  function paintTyping() {
    const el = $('#v3-typing');
    if (!el) return;
    if (state.typing) {
      el.hidden = false;
      el.innerHTML = esc(contactName(state.typing.id)) + ' is typing…';
    } else {
      el.hidden = true;
      el.textContent = '';
    }
  }

  async function openConversation(id) {
    state.activeId = Number(id);
    state.active = state.conversations.find((c) => Number(c.id) === Number(id)) || { id: id, title: 'Conversation' };
    state.messages = [];
    document.body.classList.add('v3-chat-open');
    paintList();
    const pane = $('#v3-chat-pane');
    if (pane) pane.innerHTML = '<div class="v3-loading"><div class="loader"></div></div>';
    await loadMessages(id);
    refreshConversations();
  }

  async function loadMessages(id, quiet) {
    try {
      const d = await api('/api/voic3/conversations/' + id + '/messages');
      state.messages = d.items || [];
      if (!quiet) paintChat();
      else {
        const box = $('#v3-messages');
        if (box) { box.innerHTML = messagesMarkup(); box.scrollTop = box.scrollHeight; }
      }
      // Tell the server this person has read the conversation (the GET does it too).
      paintTabBadges();
    } catch (e) {
      const box = $('#v3-messages');
      if (box) box.innerHTML = '<div class="v3-empty">' + esc(e.message) + '</div>';
    }
  }

  async function sendMessage(text) {
    const body = String(text || '').trim();
    if (!body || !state.activeId) return;
    const input = $('#v3-input');
    if (input) { input.value = ''; input.style.height = 'auto'; }
    const box = $('#v3-messages');
    if (box) {
      box.insertAdjacentHTML('beforeend', '<div class="v3-msg out pending"><div class="v3-bubble"><span class="v3-text">' +
        esc(body).replace(/\n/g, '<br>') + '</span><span class="v3-meta">sending…</span></div></div>');
      box.scrollTop = box.scrollHeight;
    }
    try {
      await api('/api/voic3/conversations/' + state.activeId + '/messages', 'POST', {
        body: body,
        idempotency_key: 'v3-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8)
      });
      await loadMessages(state.activeId);
      refreshConversations();
    } catch (e) {
      toast(e.message || 'Message not sent', 'error');
      await loadMessages(state.activeId);
    }
  }

  async function openDirectMessage(employeeId) {
    const existing = state.conversations.find((c) => c.kind === 'dm' && Number(c.peer_employee_id) === Number(employeeId));
    if (existing) { switchTab('chats'); return openConversation(existing.id); }
    try {
      const d = await api('/api/voic3/conversations', 'POST', { kind: 'dm', members: [Number(employeeId)] });
      await refreshConversations();
      switchTab('chats');
      await openConversation(d.id);
    } catch (e) { toast(e.message || 'Could not open the chat', 'error'); }
  }

  /* ----------------------------------------------------------- calls pane -- */
  function paintCalls() {
    const box = $('#v3-calls-pane');
    if (!box) return;
    const rows = state.calls.map((c) => {
      const missed = ['declined', 'missed', 'cancelled'].indexOf(String(c.status)) >= 0 && c.direction === 'incoming';
      return '<div class="v3-call-row' + (missed ? ' missed' : '') + '">' + avatar(c.other_name) +
        '<div class="v3-call-main"><b>' + esc(c.other_name) + '</b>' +
        '<small>' + (c.direction === 'outgoing' ? 'Outgoing' : 'Incoming') + ' · ' +
        esc(clock(c.created_at)) + (c.duration_seconds != null ? ' · ' + duration(c.duration_seconds) : '') +
        (missed ? ' · missed' : '') + '</small></div>' +
        '<div class="v3-call-actions">' +
        '<button type="button" class="v3-icon-btn" data-v3="call" data-kind="audio" data-peer="' + c.other_employee_id + '" title="Voice call">' + icon('phone') + '</button>' +
        '<button type="button" class="v3-icon-btn" data-v3="call" data-kind="video" data-peer="' + c.other_employee_id + '" title="Video call">' + icon('video') + '</button>' +
        '</div></div>';
    }).join('');
    box.innerHTML = '<div class="v3-pane-head"><div><h2>Call history</h2><p>Every call you made or received on this workspace.</p></div>' +
      '<button class="btn btn-primary v3-new-btn" type="button" data-v3="pick-call">' + icon('phone') + ' New call</button></div>' +
      (rows ? '<div class="v3-call-list">' + rows + '</div>' : '<div class="v3-empty">No calls yet. Start one from here or from any chat.</div>');
  }

  /* -------------------------------------------------------- meetings pane -- */
  function paintMeetings() {
    const box = $('#v3-meet-pane');
    if (!box) return;
    const cards = state.meetings.map((m) => (
      '<div class="v3-meet-card"><div class="v3-meet-top"><b>' + esc(m.title) + '</b>' +
      '<span class="v3-pill ' + (m.status === 'live' ? 'live' : '') + '">' + esc(m.status || 'scheduled') + '</span></div>' +
      '<div class="v3-meet-code">Code ' + esc(m.code) + (m.is_host ? ' · you host' : '') +
      (m.live_count ? ' · ' + m.live_count + ' in the room' : '') + '</div>' +
      '<div class="v3-meet-actions">' +
      '<button type="button" class="btn btn-primary btn-small" data-v3="join-meeting" data-id="' + m.id + '">' +
      (m.status === 'live' ? 'Join' : 'Open') + '</button>' +
      '<button type="button" class="btn btn-secondary btn-small" data-v3="invite-meeting" data-id="' + m.id + '">Invite people</button>' +
      '</div></div>')).join('');
    box.innerHTML = '<div class="v3-pane-head"><div><h2>Meetings</h2><p>Group voice or video calls. Choose the people first, then start the meeting — no paid meeting service.</p></div>' +
      '<div class="v3-pane-actions">' +
      '<button class="btn btn-primary v3-new-btn" type="button" data-v3="new-meeting" data-kind="video">' + icon('video') + ' Video meeting</button>' +
      '<button class="btn btn-secondary v3-new-btn" type="button" data-v3="new-meeting" data-kind="audio">' + icon('phone') + ' Voice meeting</button>' +
      '</div></div>' +
      '<div class="v3-meet-grid">' + (cards || '<div class="v3-empty">No meetings yet — start one above.</div>') + '</div>';
  }

  /* ---------------------------------------------------- participant picker -- */
  /* WhatsApp-style picker: search, tap to select, chips at the top, one tap to start. */
  function pickerMarkup(mode, kind) {
    const title = mode === 'call' ? 'Who do you want to call?' : (kind === 'audio' ? 'Start a voice meeting' : 'Start a video meeting');
    return '<div class="v3-picker-backdrop" data-v3="picker-close">' +
      '<div class="v3-picker" role="dialog" aria-modal="true" aria-label="' + esc(title) + '">' +
      '<div class="v3-picker-head"><div><h3>' + esc(title) + '</h3><p>' + (mode === 'call' ? 'One person.' : 'Choose one or more people.') + '</p></div>' +
      '<button type="button" class="v3-icon-btn" data-v3="picker-close" aria-label="Close">✕</button></div>' +
      '<div class="v3-chips" id="v3-chips"></div>' +
      '<div class="v3-search"><input id="v3-picker-search" type="search" placeholder="Search people" aria-label="Search people"></div>' +
      '<div class="v3-picker-list" id="v3-picker-list"></div>' +
      '<div class="v3-picker-foot">' +
      '<button type="button" class="btn btn-secondary" data-v3="picker-close">Cancel</button>' +
      '<button type="button" class="btn btn-primary" id="v3-picker-go" data-v3="picker-go" data-mode="' + mode + '" data-kind="' + (kind || 'video') + '">' +
      (mode === 'call' ? 'Call' : 'Start meeting') + '</button>' +
      '</div></div></div>';
  }

  function paintPicker() {
    const list = $('#v3-picker-list');
    const chips = $('#v3-chips');
    if (!list) return;
    const q = ($('#v3-picker-search') && $('#v3-picker-search').value || '').trim().toLowerCase();
    const rows = state.contacts.filter((c) => !c.is_me).filter((c) => !q ||
      (c.name + ' ' + (c.department || '') + ' ' + (c.job_title || '')).toLowerCase().indexOf(q) >= 0);
    list.innerHTML = rows.length ? rows.map((c) => {
      const on = state.picked.indexOf(Number(c.employee_id)) >= 0;
      return '<button type="button" class="v3-pick' + (on ? ' on' : '') + '" data-v3="pick" data-id="' + c.employee_id + '">' +
        avatar(c.name) + '<span class="v3-pick-main"><b>' + esc(c.name) + '</b>' +
        '<small>' + esc(c.job_title || c.department || c.employee_no || 'Employee') + '</small></span>' +
        '<span class="v3-pick-tick">' + (on ? '✓' : '') + '</span></button>';
    }).join('') : '<div class="v3-empty">No people match your search.</div>';
    if (chips) {
      chips.innerHTML = state.picked.map((id) => (
        '<span class="v3-chip">' + avatar(contactName(id), 'tiny') + esc(contactName(id)) +
        '<button type="button" data-v3="unpick" data-id="' + id + '" aria-label="Remove">✕</button></span>')).join('');
      chips.hidden = !state.picked.length;
    }
    const go = $('#v3-picker-go');
    if (go) go.disabled = !state.picked.length;
  }

  function openPicker(mode, kind) {
    state.picked = [];
    const host = document.createElement('div');
    host.id = 'v3-picker-host';
    host.innerHTML = pickerMarkup(mode, kind);
    document.body.appendChild(host);
    paintPicker();
    const search = $('#v3-picker-search');
    if (search) { search.focus(); search.addEventListener('input', paintPicker); }
  }
  function closePicker() {
    const host = $('#v3-picker-host');
    if (host) host.remove();
    state.picked = [];
  }

  async function startMeeting(kind) {
    if (!state.picked.length) { toast('Choose at least one person', 'error'); return; }
    const kindLabel = kind === 'audio' ? 'Voice meeting' : 'Video meeting';
    const names = state.picked.map(contactName);
    const title = names.length === 1 ? (kindLabel + ' with ' + names[0]) : (kindLabel + ' · ' + names.length + ' people');
    try {
      const created = await api('/api/voic3/meetings', 'POST', { title: title, waiting_room_enabled: false });
      await api('/api/voic3/meetings/' + created.id + '/invite', 'POST', { employee_ids: state.picked });
      closePicker();
      toast(kindLabel + ' started — ' + names.length + ' invited');
      await refreshMeetings();
      if (window.Voic3Meetings) window.Voic3Meetings.open(created.id);
    } catch (e) { toast(e.message || 'Could not start the meeting', 'error'); }
  }

  /* ------------------------------------------------------------ in-call UI -- */
  function callOverlay() {
    let el = $('#v3-call-root');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'v3-call-root';
    el.className = 'v3-call-root';
    document.body.appendChild(el);
    return el;
  }

  function paintCall() {
    const el = callOverlay();
    const c = state.call;
    if (!c) { el.classList.remove('open'); el.innerHTML = ''; document.documentElement.classList.remove('br-call-active'); stopBeep(); return; }
    el.classList.add('open');
    const connected = c.status === 'active';
    document.documentElement.classList.add('br-call-active');
    el.innerHTML =
      '<div class="v3-call-screen">' +
      '<div class="v3-call-video">' +
      '<video id="v3-remote" autoplay playsinline></video>' +
      '<video id="v3-local" autoplay playsinline muted></video>' +
      (connected ? '' : '<div class="v3-call-ringing">' + avatar(c.peerName, 'big') + '<b>' + esc(c.peerName) + '</b>' +
        '<small>' + (c.direction === 'incoming' ? 'Incoming ' : 'Calling… ') + (c.type === 'video' ? 'video call' : 'voice call') + '</small></div>') +
      '</div>' +
      '<div class="v3-call-bar">' +
      '<div class="v3-call-meta"><b>' + esc(c.peerName) + '</b><small id="v3-call-timer">' +
      (connected ? (c.timer || '00:00') : (c.direction === 'incoming' ? 'Incoming call' : 'Ringing…')) + '</small></div>' +
      '<div class="v3-call-controls">' +
      '<button type="button" class="v3-ctl' + (c.muted ? ' off' : '') + '" data-v3-call="mute" title="Mute" aria-pressed="' + String(!!c.muted) + '">' + (c.muted ? icon('mic') : icon('mic')) + '<span>' + (c.muted ? 'Unmute' : 'Mute') + '</span></button>' +
      '<button type="button" class="v3-ctl' + (c.speaker ? ' on' : '') + '" data-v3-call="speaker" title="Speaker" aria-pressed="' + String(!!c.speaker) + '">' + icon('activity') + '<span>' + (c.speaker ? 'Speaker on' : 'Speaker off') + '</span></button>' +
      (c.type === 'video'
        ? '<button type="button" class="v3-ctl' + (c.camOn ? '' : ' off') + '" data-v3-call="camera" title="Camera">' + icon('video') + '<span>Camera</span></button>' +
          '<button type="button" class="v3-ctl" data-v3-call="switch" title="Switch camera">' + icon('play') + '<span>Flip</span></button>'
        : '') +
      (c.direction === 'incoming' && !connected
        ? '<button type="button" class="v3-ctl answer" data-v3-call="answer" title="Answer">' + icon('phone') + '<span>Answer</span></button>'
        : '') +
      '<button type="button" class="v3-ctl end" data-v3-call="end" title="End call">' + icon('phone') + '<span>End</span></button>' +
      '</div></div></div>';
    const local = $('#v3-local');
    if (local && c.stream) local.srcObject = c.stream;
  }

  function iceServers() {
    return api('/api/voic3/ice-config').then((d) => d.iceServers || []).catch(() => []);
  }

  async function startCall(peerId, type) {
    if (!peerId) { toast('Choose someone to call', 'error'); return; }
    if (state.call) { toast('A call is already in progress', 'error'); return; }
    const peer = contactById(peerId);
    state.call = { id: null, type: type === 'video' ? 'video' : 'audio', peerId: Number(peerId), peerName: peer ? peer.name : contactName(peerId), direction: 'outgoing', status: 'ringing', muted: false, speaker: true, camOn: type === 'video', stream: null, pc: null };
    paintCall();
    try {
      const res = await api('/api/voic3/calls', 'POST', { callee_employee_id: Number(peerId), call_type: state.call.type });
      state.call.id = res.id;
      state.signalAfter = 0;
      await openMedia(state.call.type === 'video');
      await createPeer(true);
      pollSignals();
    } catch (e) {
      toast(e.message || 'Could not start the call', 'error');
      endCall(true);
    }
  }

  function ringIncoming(data) {
    if (!data || !data.call_id || !data.caller_employee_id || state.me == null || data.callee_employee_id == null || Number(data.callee_employee_id) !== Number(state.me) || Number(data.caller_employee_id) === Number(state.me)) return;
    if (state.call) { api('/api/voic3/calls/' + data.call_id + '/decline', 'POST', {}).catch(() => { }); return; }
    state.call = { id: Number(data.call_id), type: data.call_type === 'video' ? 'video' : 'audio', peerId: Number(data.caller_employee_id), peerName: contactName(data.caller_employee_id), direction: 'incoming', status: 'ringing', muted: false, speaker: true, camOn: data.call_type === 'video', stream: null, pc: null };
    state.signalAfter = 0;
    paintCall();
    try { beepLoop(); } catch (e) { }
  }

  let ringTimer = null;
  function beepLoop() {
    clearInterval(ringTimer);
    const ctx = window.AudioContext || window.webkitAudioContext;
    if (!ctx) return;
    const ac = new ctx();
    const beep = () => {
      const o = ac.createOscillator(); const g = ac.createGain();
      o.connect(g); g.connect(ac.destination);
      o.frequency.value = 720; o.type = 'sine';
      g.gain.setValueAtTime(0.0001, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.08, ac.currentTime + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 0.5);
      o.start(); o.stop(ac.currentTime + 0.55);
    };
    beep();
    ringTimer = setInterval(beep, 2200);
    state.callAudio = ac;
  }
  function stopBeep() {
    clearInterval(ringTimer); ringTimer = null;
    if (state.callAudio) { try { state.callAudio.close(); } catch (e) { } state.callAudio = null; }
  }

  async function openMedia(withVideo) {
    const c = state.call;
    if (!c || !navigator.mediaDevices) throw new Error('This device has no camera or microphone available.');
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: withVideo ? { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } : false
    });
    c.stream = stream;
    paintCall();
    return stream;
  }

  async function createPeer(isCaller) {
    const c = state.call;
    if (!c) return;
    const pc = new RTCPeerConnection({ iceServers: await iceServers() });
    c.pc = pc;
    if (c.stream) c.stream.getTracks().forEach((t) => pc.addTrack(t, c.stream));
    pc.ontrack = (e) => {
      const remote = $('#v3-remote');
      if (remote) remote.srcObject = e.streams[0];
    };
    pc.onicecandidate = (e) => {
      if (!e.candidate) return;
      api('/api/voic3/calls/' + c.id + '/signal', 'POST', { kind: 'ice', payload: JSON.stringify(e.candidate) }).catch(() => { });
    };
    if (isCaller) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await api('/api/voic3/calls/' + c.id + '/signal', 'POST', { kind: 'offer', payload: JSON.stringify(offer) });
    }
  }

  function pollSignals() {
    clearInterval(state.signalTimer);
    state.signalTimer = setInterval(async () => {
      const c = state.call;
      if (!c || !c.id) return;
      try {
        const d = await api('/api/voic3/calls/' + c.id + '/signal?after=' + state.signalAfter);
        for (const sig of (d.items || [])) {
          state.signalAfter = Math.max(state.signalAfter, Number(sig.id) || 0);
          let payload = null;
          try { payload = JSON.parse(sig.payload); } catch (e) { continue; }
          if (sig.kind === 'offer' && c.pc) {
            await c.pc.setRemoteDescription(new RTCSessionDescription(payload));
            const ans = await c.pc.createAnswer();
            await c.pc.setLocalDescription(ans);
            await api('/api/voic3/calls/' + c.id + '/signal', 'POST', { kind: 'answer', payload: JSON.stringify(ans) });
          } else if (sig.kind === 'answer' && c.pc && c.pc.signalingState === 'have-local-offer') {
            await c.pc.setRemoteDescription(new RTCSessionDescription(payload));
          } else if (sig.kind === 'ice' && c.pc) {
            try { await c.pc.addIceCandidate(new RTCIceCandidate(payload)); } catch (e) { }
          }
        }
      } catch (e) { /* transient; try again next tick */ }
    }, 1500);
  }

  async function answerCall() {
    const c = state.call;
    if (!c) return;
    stopBeep();
    try {
      await api('/api/voic3/calls/' + c.id + '/answer', 'POST', {});
      c.status = 'active';
      c.direction = 'incoming';
      await openMedia(c.type === 'video');
      await createPeer(false);
      pollSignals();
      paintCall();
    } catch (e) { toast(e.message || 'Could not answer', 'error'); endCall(true); }
  }

  function onCallState(data) {
    const c = state.call;
    if (!c || Number(data.call_id) !== Number(c.id)) return;
    if (data.status === 'active') {
      stopBeep();
      c.status = 'active';
      if (!c.timerStart) c.timerStart = Date.now();
      paintCall();
      clearInterval(c.timerTimer);
      c.timerTimer = setInterval(() => {
        if (!state.call) return;
        state.call.timer = duration(Math.floor((Date.now() - state.call.timerStart) / 1000));
        const el = $('#v3-call-timer');
        if (el) el.textContent = state.call.timer;
      }, 1000);
    } else if (['ended', 'declined', 'missed', 'cancelled'].indexOf(String(data.status)) >= 0) {
      if (data.status === 'declined') toast('Call declined');
      else if (data.status === 'ended') toast('Call ended');
      endCall(true);
      refreshCalls();
    }
  }

  function onCallSignal(data) {
    /* The poll picks signals up; this is only a nudge to fetch them sooner. */
    if (state.call && Number(data.call_id) === Number(state.call.id)) {
      clearTimeout(state.nudge);
      state.nudge = setTimeout(() => { /* the interval will fetch */ }, 50);
    }
  }

  function endCall(silent) {
    const c = state.call;
    stopBeep();
    clearInterval(state.signalTimer);
    if (c) {
      clearInterval(c.timerTimer);
      if (c.id) api('/api/voic3/calls/' + c.id + '/end', 'POST', { reason: 'completed' }).catch(() => { });
      if (c.pc) { try { c.pc.close(); } catch (e) { } }
      if (c.stream) c.stream.getTracks().forEach((t) => t.stop());
    }
    state.call = null;
    state.signalAfter = 0;
    paintCall();
    if (!silent) refreshCalls();
  }

  function toggleMute() {
    const c = state.call;
    if (!c || !c.stream) return;
    c.muted = !c.muted;
    c.stream.getAudioTracks().forEach((t) => { t.enabled = !c.muted; });
    paintCall();
  }
  function toggleSpeaker() {
    const c = state.call;
    if (!c) return;
    c.speaker = !c.speaker;
    const remote = $('#v3-remote');
    if (remote) {
      try { remote.setSinkId && remote.sinkId; } catch (e) { }
      remote.volume = c.speaker ? 1 : 0.55;
    }
    paintCall();
  }
  async function toggleCamera() {
    const c = state.call;
    if (!c) return;
    if (!c.stream) { await openMedia(true); if (c.pc) c.stream.getTracks().forEach((t) => c.pc.addTrack(t, c.stream)); }
    c.camOn = !c.camOn;
    if (c.stream) c.stream.getVideoTracks().forEach((t) => { t.enabled = c.camOn; });
    paintCall();
  }
  async function switchCamera() {
    const c = state.call;
    if (!c || !c.stream) return;
    try {
      const next = c.facing === 'environment' ? 'user' : 'environment';
      const fresh = await navigator.mediaDevices.getUserMedia({ video: { facingMode: next }, audio: false });
      const track = fresh.getVideoTracks()[0];
      const sender = c.pc && c.pc.getSenders().find((s) => s.track && s.track.kind === 'video');
      if (sender) await sender.replaceTrack(track);
      c.stream.getVideoTracks().forEach((t) => { t.stop(); c.stream.removeTrack(t); });
      c.stream.addTrack(track);
      c.facing = next;
      paintCall();
    } catch (e) { toast('This device has no second camera', 'error'); }
  }

  /* --------------------------------------------------------------- wiring -- */
  function switchTab(tab) {
    state.tab = tab;
    $$('.v3-tab').forEach((b) => b.classList.toggle('active', b.dataset.v3Tab === tab));
    const listPane = $('.v3-list-pane');
    const chatPane = $('#v3-chat-pane');
    const callsPane = $('#v3-calls-pane');
    const meetPane = $('#v3-meet-pane');
    if (tab === 'chats') {
      if (listPane) listPane.hidden = false;
      if (chatPane) chatPane.hidden = false;
      if (callsPane) callsPane.hidden = true;
      if (meetPane) meetPane.hidden = true;
      paintList();
    } else if (tab === 'calls') {
      if (listPane) listPane.hidden = true;
      if (chatPane) chatPane.hidden = true;
      if (callsPane) callsPane.hidden = false;
      if (meetPane) meetPane.hidden = true;
      refreshCalls();
      paintCalls();
    } else {
      if (listPane) listPane.hidden = true;
      if (chatPane) chatPane.hidden = true;
      if (callsPane) callsPane.hidden = true;
      if (meetPane) meetPane.hidden = false;
      paintMeetings();
      refreshMeetings();
    }
  }

  function mount() {
    state.mounted = true;
    const view = $('#view');
    if (!view || !$('.v3-shell')) return;
    connectEvents();
    clearInterval(state.pollTimer);
    // A slow safety net: the event stream is the primary path, this catches a
    // dropped stream on a flaky phone connection.
    state.pollTimer = setInterval(() => {
      if (document.hidden) return;
      if (!$('.v3-shell')) { clearInterval(state.pollTimer); disconnectEvents(); state.mounted = false; return; }
      refreshConversations();
      if (state.activeId) loadMessages(state.activeId, true);
    }, 12000);
    loadAll().then(() => {
      paintList();
      paintTabBadges();
      paintCalls();
      paintMeetings();
      const search = $('#v3-search');
      if (search) search.addEventListener('input', () => { state.search = search.value; paintList(); });
      if (state.activeId && state.conversations.some((c) => Number(c.id) === Number(state.activeId))) {
        openConversation(state.activeId);
      }
    });
  }

  function unmount() {
    state.mounted = false;
    clearInterval(state.pollTimer);
    disconnectEvents();
    document.body.classList.remove('v3-chat-open');
    if (state.call) endCall(true);
    else document.documentElement.classList.remove('br-call-active');
  }

  /* One delegated listener for the whole VOIC3 surface. */
  document.addEventListener('click', (e) => {
    const tab = e.target.closest('[data-v3-tab]');
    if (tab) { e.preventDefault(); switchTab(tab.dataset.v3Tab); return; }
    const el = e.target.closest('[data-v3]');
    if (!el) return;
    const what = el.dataset.v3;
    if (what === 'picker-close') {
      if (e.target === el || el.tagName === 'BUTTON') { e.preventDefault(); closePicker(); }
      return;
    }
    if (what === 'pick') {
      e.preventDefault();
      const id = Number(el.dataset.id);
      const i = state.picked.indexOf(id);
      if (i >= 0) state.picked.splice(i, 1); else state.picked.push(id);
      paintPicker();
      return;
    }
    if (what === 'unpick') {
      e.preventDefault();
      const id = Number(el.dataset.id);
      const i = state.picked.indexOf(id);
      if (i >= 0) state.picked.splice(i, 1);
      paintPicker();
      return;
    }
    if (what === 'picker-go') {
      e.preventDefault();
      const mode = el.dataset.mode;
      if (mode === 'call') {
        const peer = state.picked[0];
        closePicker();
        startCall(peer, el.dataset.kind === 'video' ? 'video' : 'audio');
      } else {
        startMeeting(el.dataset.kind === 'audio' ? 'audio' : 'video');
      }
      return;
    }
    if (what === 'copy-message') { e.preventDefault(); e.stopPropagation(); copyMessage(el.dataset.id); return; }
    if (what === 'open') { e.preventDefault(); openConversation(Number(el.dataset.id)); return; }
    if (what === 'contact') { e.preventDefault(); openDirectMessage(Number(el.dataset.id)); return; }
    if (what === 'quick-call') {
      e.preventDefault(); e.stopPropagation();
      startCall(Number(el.dataset.id), el.dataset.kind === 'video' ? 'video' : 'audio');
      return;
    }
    if (what === 'call') {
      e.preventDefault();
      const peer = Number(el.dataset.peer);
      if (!peer) { openPicker('call', el.dataset.kind || 'audio'); return; }
      startCall(peer, el.dataset.kind === 'video' ? 'video' : 'audio');
      return;
    }
    if (what === 'back') { e.preventDefault(); document.body.classList.remove('v3-chat-open'); state.activeId = null; state.active = null; paintList(); const p = $('#v3-chat-pane'); if (p) p.innerHTML = emptyChat(); return; }
    if (what === 'new-chat' || what === 'pick-call') { e.preventDefault(); openPicker('call', what === 'pick-call' ? 'audio' : 'audio'); return; }
    if (what === 'new-meeting') { e.preventDefault(); openPicker('meeting', el.dataset.kind || 'video'); return; }
    if (what === 'join-meeting') { e.preventDefault(); if (window.Voic3Meetings) window.Voic3Meetings.open(Number(el.dataset.id)); return; }
    if (what === 'invite-meeting') {
      e.preventDefault();
      state.inviteMeetingId = Number(el.dataset.id);
      openPicker('meeting', 'video');
      return;
    }
    if (what === 'attach') { e.preventDefault(); const f = $('#v3-file'); if (f) f.click(); return; }
  });

  document.addEventListener('click', (e) => {
    const ctl = e.target.closest('[data-v3-call]');
    if (!ctl) return;
    e.preventDefault();
    const what = ctl.dataset.v3Call;
    if (what === 'mute') toggleMute();
    else if (what === 'speaker') toggleSpeaker();
    else if (what === 'camera') toggleCamera();
    else if (what === 'switch') switchCamera();
    else if (what === 'answer') answerCall();
    else if (what === 'end') endCall(false);
  });

  document.addEventListener('submit', (e) => {
    if (e.target && e.target.id === 'v3-compose') {
      e.preventDefault();
      const input = $('#v3-input');
      sendMessage(input && input.value);
    }
  });

  document.addEventListener('change', (e) => {
    if (e.target && e.target.id === 'v3-file') {
      const file = e.target.files && e.target.files[0];
      e.target.value = '';
      if (!file) return;
      toast('Attachments are sent from the phone app; the desktop chat sends text for now.');
    }
  });

  window.Voic3UI = {
    render: render,
    mount: mount,
    unmount: unmount,
    openConversation: openConversation,
    startCall: startCall,
    startMeeting: startMeeting,
    switchTab: switchTab,
    state: state
  };
})();
