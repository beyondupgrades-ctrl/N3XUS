/* ============================================================
   VOIC3 Section 13 — offline outbox (IndexedDB) + poor-4G audio
   priority for WebRTC calls and meetings.

   Two independent pieces, both opt-in and both degrading to the
   current behaviour when the browser lacks the API:

   1. Voic3Outbox — caches recent conversations/messages locally and
      queues messages, voice notes, PTT bursts and SOS alerts while
      offline, each with a client-generated UUID `idempotency_key`.
      Flushed strictly in order on reconnect, so a retry can never
      create a duplicate on the server.

   2. Voic3NetQuality — polls RTCPeerConnection.getStats() every
      2 seconds; two consecutive bad intervals (loss > 5% or RTT >
      350 ms) drop outgoing video to keep audio clear, with a manual
      override that also honours a weak link the user accepts.
   ============================================================ */
(function () {
  'use strict';

  const DB_NAME = 'voic3-offline';
  const DB_VERSION = 1;
  const STORE_QUEUE = 'outbox';
  const STORE_CACHE = 'cache';
  const MAX_CACHE_MESSAGES = 300;

  const state = {
    db: null,
    flushing: false,
    online: typeof navigator === 'undefined' ? true : navigator.onLine !== false,
    lastError: '',
    listeners: []
  };

  function uuid() {
    try {
      if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    } catch (e) { /* fall through */ }
    const rnd = () => Math.random().toString(16).slice(2, 10);
    return (rnd() + '-' + rnd() + '-4' + rnd().slice(0, 3) + '-a' + rnd().slice(0, 3) + '-' + rnd() + rnd()).slice(0, 36);
  }

  function notify() {
    state.listeners.slice().forEach((fn) => {
      try { fn(state); } catch (e) { /* listener bug must not break the queue */ }
    });
  }

  function onChange(fn) {
    if (typeof fn === 'function') state.listeners.push(fn);
    return () => {
      const i = state.listeners.indexOf(fn);
      if (i !== -1) state.listeners.splice(i, 1);
    };
  }

  // ---------------------------------------------------------- IndexedDB
  function open() {
    if (state.db) return Promise.resolve(state.db);
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error('indexeddb-unavailable')); return; }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_QUEUE)) {
          const store = db.createObjectStore(STORE_QUEUE, { keyPath: 'seq', autoIncrement: true });
          store.createIndex('idempotency_key', 'idempotency_key', { unique: true });
        }
        if (!db.objectStoreNames.contains(STORE_CACHE)) db.createObjectStore(STORE_CACHE, { keyPath: 'key' });
      };
      request.onsuccess = () => { state.db = request.result; resolve(state.db); };
      request.onerror = () => reject(request.error || new Error('indexeddb-open-failed'));
    });
  }

  function tx(storeName, mode, run) {
    return open().then((db) => new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, mode);
      const store = transaction.objectStore(storeName);
      let result;
      try { result = run(store); } catch (err) { reject(err); return; }
      transaction.oncomplete = () => resolve(result && result.result !== undefined ? result.result : result);
      transaction.onerror = () => reject(transaction.error || new Error('indexeddb-transaction-failed'));
      transaction.onabort = () => reject(transaction.error || new Error('indexeddb-aborted'));
    }));
  }

  /** Queue one item. Returns the stored item including its idempotency_key. */
  function enqueue(item) {
    const entry = {
      idempotency_key: (item && item.idempotency_key) || uuid(),
      kind: (item && item.kind) || 'message',
      method: (item && item.method) || 'POST',
      url: (item && item.url) || '',
      body: (item && item.body) || {},
      created_at: Date.now(),
      attempts: 0,
      last_error: ''
    };
    return tx(STORE_QUEUE, 'readwrite', (store) => store.add(entry)).then(() => {
      notify();
      return entry;
    });
  }

  function pending() {
    return tx(STORE_QUEUE, 'readonly', (store) => store.getAll())
      .then((rows) => rows || [])
      .catch(() => []);
  }

  function pendingCount() {
    return pending().then((rows) => rows.length);
  }

  function remove(seq) {
    return tx(STORE_QUEUE, 'readwrite', (store) => store.delete(seq)).then(notify);
  }

  function update(seq, patch) {
    return tx(STORE_QUEUE, 'readwrite', (store) => {
      const get = store.get(seq);
      get.onsuccess = () => {
        const row = get.result;
        if (!row) return;
        store.put(Object.assign(row, patch || {}));
      };
    });
  }

  // ---------------------------------------------------------- cache
  function cacheSet(key, value) {
    return tx(STORE_CACHE, 'readwrite', (store) => store.put({ key: key, value: value, saved_at: Date.now() }))
      .catch(() => null);
  }

  function cacheGet(key) {
    return tx(STORE_CACHE, 'readonly', (store) => store.get(key))
      .then((row) => (row ? row.value : null))
      .catch(() => null);
  }

  /** Cache the recent messages of one conversation (newest last). */
  function cacheMessages(conversationId, messages) {
    const trimmed = (messages || []).slice(-MAX_CACHE_MESSAGES);
    return cacheSet('conversation:' + conversationId, trimmed);
  }

  function cachedMessages(conversationId) {
    return cacheGet('conversation:' + conversationId).then((rows) => rows || []);
  }

  function cacheConversations(list) {
    return cacheSet('conversations', (list || []).slice(0, 100));
  }

  function cachedConversations() {
    return cacheGet('conversations').then((rows) => rows || []);
  }

  // ---------------------------------------------------------- flush
  /**
   * Send queued items oldest-first. Stops at the first network failure so
   * ordering is preserved; a 4xx (other than 408/429) drops the item because
   * retrying will never succeed. `api` is the app's fetch wrapper.
   */
  async function flush(api) {
    if (state.flushing) return { sent: 0, remaining: (await pending()).length, stopped: true };
    if (!api || !state.online) return { sent: 0, remaining: (await pending()).length, stopped: true };
    state.flushing = true;
    let sent = 0;
    let stopped = false;
    try {
      const rows = await pending();
      for (const row of rows) {
        try {
          const res = await api(row.url, {
            method: row.method,
            body: JSON.stringify(Object.assign({}, row.body, { idempotency_key: row.idempotency_key }))
          });
          await remove(row.seq);
          sent += 1;
          if (window.BR_OUTBOX_EVENTS && typeof window.BR_OUTBOX_EVENTS.onSent === 'function') {
            try { window.BR_OUTBOX_EVENTS.onSent(row, res); } catch (e) { /* ignore */ }
          }
        } catch (err) {
          const status = Number(err && err.status) || 0;
          const fatal = status >= 400 && status < 500 && status !== 408 && status !== 429;
          if (fatal) {
            await remove(row.seq);
            if (window.BR_OUTBOX_EVENTS && typeof window.BR_OUTBOX_EVENTS.onDropped === 'function') {
              try { window.BR_OUTBOX_EVENTS.onDropped(row, err); } catch (e) { /* ignore */ }
            }
            continue;
          }
          state.lastError = String((err && err.message) || err);
          await update(row.seq, { attempts: (row.attempts || 0) + 1, last_error: state.lastError.slice(0, 200) });
          stopped = true;
          break;
        }
      }
    } finally {
      state.flushing = false;
      notify();
    }
    return { sent: sent, remaining: (await pending()).length, stopped: stopped };
  }

  // ---------------------------------------------------------- wiring
  if (typeof window !== 'undefined') {
    window.addEventListener('online', () => { state.online = true; notify(); });
    window.addEventListener('offline', () => { state.online = false; notify(); });
  }

  window.Voic3Outbox = {
    uuid: uuid,
    enqueue: enqueue,
    pending: pending,
    pendingCount: pendingCount,
    remove: remove,
    flush: flush,
    cacheMessages: cacheMessages,
    cachedMessages: cachedMessages,
    cacheConversations: cacheConversations,
    cachedConversations: cachedConversations,
    onChange: onChange,
    state: state
  };

  /* ============================================================
     Poor-4G audio priority
     ============================================================ */
  const LOSS_THRESHOLD = 0.05;   // 5 % packet loss
  const RTT_THRESHOLD = 350;     // 350 ms round-trip
  const BAD_INTERVALS = 2;       // consecutive 2 s polls
  const POLL_MS = 2000;

  const quality = {
    pc: null,
    timer: null,
    badCount: 0,
    loss: 0,
    rtt: 0,
    audioPriority: false,
    overridden: false,      // user chose to keep video on
    listeners: []
  };

  function qualityNotify() {
    quality.listeners.slice().forEach((fn) => {
      try { fn(quality); } catch (e) { /* ignore */ }
    });
  }

  function onQuality(fn) {
    if (typeof fn === 'function') quality.listeners.push(fn);
    return () => {
      const i = quality.listeners.indexOf(fn);
      if (i !== -1) quality.listeners.splice(i, 1);
    };
  }

  /** Read loss + RTT from the selected candidate pair. */
  function readStats(report) {
    let rtt = 0;
    let lost = 0;
    let received = 0;
    let pair = null;
    const byId = {};
    report.forEach((s) => { byId[s.id] = s; });
    report.forEach((s) => {
      if (s.type === 'candidate-pair' && (s.selected || s.state === 'succeeded')) {
        if (!pair || Number(s.currentRoundTripTime) > 0) pair = s;
      }
    });
    if (pair) {
      rtt = Math.round(Number(pair.currentRoundTripTime || 0) * 1000);
      const local = byId[pair.localCandidateId];
      const remote = byId[pair.remoteCandidateId];
      [local, remote].forEach((c) => {
        if (!c) return;
        lost += Number(c.packetsLost || 0);
        received += Number(c.packetsReceived || 0);
      });
    }
    let inbound = null;
    report.forEach((s) => {
      if (s.type === 'inbound-rtp' && (s.kind === 'audio' || s.mediaType === 'audio')) inbound = s;
    });
    if (inbound) {
      lost += Number(inbound.packetsLost || 0);
      received += Number(inbound.packetsReceived || 0);
      if (!rtt && inbound.jitter) rtt = Math.round(Number(inbound.jitter) * 1000);
    }
    const total = lost + received;
    return { loss: total > 0 ? lost / total : 0, rtt: rtt };
  }

  function setVideoEnabled(enabled) {
    if (!quality.pc) return;
    try {
      quality.pc.getSenders().forEach((sender) => {
        const track = sender && sender.track;
        if (track && track.kind === 'video') track.enabled = !!enabled;
      });
    } catch (e) { /* sender list unavailable */ }
  }

  function applyAudioPriority(on, reason) {
    const next = !!on;
    if (next === quality.audioPriority) return;
    quality.audioPriority = next;
    setVideoEnabled(!next);
    qualityNotify();
    if (typeof window.onAudioPriorityChange === 'function') {
      try { window.onAudioPriorityChange(next, reason || ''); } catch (e) { /* ignore */ }
    }
  }

  /** Manual override: keep video on despite a weak link (or re-enable it). */
  function override(on) {
    quality.overridden = !!on;
    if (on) applyAudioPriority(false, 'manual-override');
    else { quality.badCount = BAD_INTERVALS; applyAudioPriority(true, 'manual-override-off'); }
    qualityNotify();
  }

  async function poll() {
    if (!quality.pc || quality.pc.connectionState === 'closed') return;
    try {
      const report = await quality.pc.getStats();
      const sample = readStats(report);
      quality.loss = sample.loss;
      quality.rtt = sample.rtt;
      const bad = sample.loss > LOSS_THRESHOLD || sample.rtt > RTT_THRESHOLD;
      quality.badCount = bad ? quality.badCount + 1 : 0;
      if (quality.badCount >= BAD_INTERVALS && !quality.overridden) applyAudioPriority(true, 'weak-4g');
      else if (quality.badCount === 0 && quality.audioPriority && !quality.overridden) applyAudioPriority(false, 'recovered');
      qualityNotify();
    } catch (e) {
      state.lastError = String((e && e.message) || e);
    }
  }

  /** Start watching one RTCPeerConnection (call or meeting). */
  function watch(pc) {
    stop();
    if (!pc || typeof pc.getStats !== 'function') return false;
    quality.pc = pc;
    quality.badCount = 0;
    quality.overridden = false;
    quality.timer = setInterval(poll, POLL_MS);
    return true;
  }

  function stop() {
    if (quality.timer) clearInterval(quality.timer);
    quality.timer = null;
    quality.pc = null;
    quality.badCount = 0;
    quality.loss = 0;
    quality.rtt = 0;
    quality.audioPriority = false;
    quality.overridden = false;
    qualityNotify();
  }

  /* ---------------------------------------------------------- banner UI
     Non-intrusive "Weak 4G — Audio Priority Mode" strip with a manual
     override. Built only when the page has a body, so the module is safe
     to load in a worker-less test harness too. */
  function ensureBanner() {
    if (typeof document === 'undefined' || !document.body) return null;
    let el = document.getElementById('br-audio-priority');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'br-audio-priority';
    el.innerHTML = '<span><b>Weak 4G</b> — Audio Priority Mode (video paused)</span>' +
      '<button type="button" id="br-audio-priority-toggle">Keep video on</button>';
    document.body.appendChild(el);
    el.querySelector('#br-audio-priority-toggle').addEventListener('click', () => {
      const keeping = !quality.overridden;
      override(keeping);
      el.querySelector('#br-audio-priority-toggle').textContent = keeping ? 'Audio priority' : 'Keep video on';
    });
    return el;
  }

  function paintBanner() {
    const el = ensureBanner();
    if (!el) return;
    const show = quality.audioPriority && !quality.overridden;
    el.classList.toggle('show', !!show);
    el.style.display = show ? 'flex' : 'none';
  }

  onQuality(paintBanner);

  window.Voic3NetQuality = {
    watch: watch,
    stop: stop,
    override: override,
    onQuality: onQuality,
    readStats: readStats,
    thresholds: { loss: LOSS_THRESHOLD, rtt: RTT_THRESHOLD, intervals: BAD_INTERVALS, pollMs: POLL_MS },
    state: quality
  };
})();
