/* ============================================================
   VOIC3 Section 14 — interactive workflow cards (client)

   Renders three message types that also exist as ordinary text:

   * leave_card       — one-tap Approve / Decline for a manager
   * safety_checklist — tap-to-sign each handover item
   * sos_pin          — location + Acknowledge / Resolve

   Every card keeps the plain `text` the server writes, so if this file is
   missing (older build, cached page) the message still reads normally.
   The card is a progressive enhancement drawn over that text.
   ============================================================ */
(function () {
  'use strict';

  const CARD_LABELS = {
    leave_card: 'Leave request',
    safety_checklist: 'Safety checklist',
    sos_pin: 'Emergency SOS'
  };

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }

  function num(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  /** Is this message one of the interactive card types? */
  function isCard(message) {
    if (!message) return false;
    const type = message.type || message.message_type || (message.payload && message.payload.card_type);
    return !!CARD_LABELS[type];
  }

  function statusChip(status) {
    const s = String(status || 'Pending');
    const cls = /approv|complete|resolved/i.test(s) ? 'ok'
      : /declin|expired/i.test(s) ? 'bad'
        : /acknowledg|progress/i.test(s) ? 'warn' : 'idle';
    return '<span class="vc-chip vc-chip-' + cls + '">' + esc(s) + '</span>';
  }

  function leaveCard(payload, opts) {
    const canDecide = !!opts.canDecide;
    const pending = /pending/i.test(String(payload.status || 'Pending'));
    const who = payload.employee_name || payload.employee || 'Employee';
    return '' +
      '<div class="vc-head"><span class="vc-kind">' + esc(CARD_LABELS.leave_card) + '</span>' + statusChip(payload.status) + '</div>' +
      '<div class="vc-title">' + esc(who) + '</div>' +
      '<div class="vc-grid">' +
      '<div><b>' + esc(payload.leave_type || 'Leave') + '</b><span>Type</span></div>' +
      '<div><b>' + esc(payload.date_from || '—') + '</b><span>From</span></div>' +
      '<div><b>' + esc(payload.date_to || '—') + '</b><span>To</span></div>' +
      '<div><b>' + num(payload.days).toFixed(1) + '</b><span>Days</span></div>' +
      '</div>' +
      (payload.reason ? '<p class="vc-note">' + esc(payload.reason) + '</p>' : '') +
      (canDecide && pending
        ? '<div class="vc-actions"><button type="button" class="vc-btn vc-ok" data-vc-action="approve">Approve</button>' +
          '<button type="button" class="vc-btn vc-bad" data-vc-action="decline">Decline</button></div>'
        : '');
  }

  function checklistCard(payload, opts) {
    const items = payload.items || [];
    const done = items.filter((i) => i.checked).length;
    const pct = items.length ? Math.round((done / items.length) * 100) : 0;
    const rows = items.map((item, i) => {
      const label = item.label || item.text || ('Item ' + (i + 1));
      return '<button type="button" class="vc-check' + (item.checked ? ' done' : '') + '" data-vc-index="' + (i + 1) + '"' +
        (opts.readOnly ? ' disabled' : '') + '>' +
        '<span class="vc-box">' + (item.checked ? '✓' : '') + '</span>' +
        '<span class="vc-check-label">' + esc(label) + '</span>' +
        (item.checked && item.by ? '<span class="vc-by">' + esc(item.by) + '</span>' : '') +
        '</button>';
    }).join('');
    return '' +
      '<div class="vc-head"><span class="vc-kind">' + esc(CARD_LABELS.safety_checklist) + '</span>' + statusChip(payload.status) + '</div>' +
      '<div class="vc-title">' + esc(payload.shift || 'Shift handover') + '</div>' +
      '<div class="vc-bar"><i style="width:' + pct + '%"></i><em>' + done + '/' + items.length + '</em></div>' +
      '<div class="vc-checks">' + rows + '</div>';
  }

  function sosCard(payload, opts) {
    const hasPin = payload.latitude != null && payload.longitude != null;
    const maps = hasPin
      ? 'https://www.openstreetmap.org/?mlat=' + num(payload.latitude) + '&mlon=' + num(payload.longitude) + '#map=17/' +
        num(payload.latitude) + '/' + num(payload.longitude)
      : '';
    const settled = /resolved|acknowledged/i.test(String(payload.status || ''));
    return '' +
      '<div class="vc-head"><span class="vc-kind vc-kind-sos">' + esc(CARD_LABELS.sos_pin) + '</span>' + statusChip(payload.status) + '</div>' +
      '<div class="vc-title">' + esc(payload.employee_name || 'Employee') +
      (payload.place ? ' · ' + esc(payload.place) : '') + '</div>' +
      (hasPin ? '<div class="vc-pin">' + num(payload.latitude).toFixed(5) + ', ' + num(payload.longitude).toFixed(5) +
        ' <a href="' + esc(maps) + '" target="_blank" rel="noopener">Open map</a></div>' : '<div class="vc-pin">No GPS fix</div>') +
      (payload.battery != null ? '<p class="vc-note">Battery ' + esc(payload.battery) + '%</p>' : '') +
      (opts.canDecide && !settled
        ? '<div class="vc-actions"><button type="button" class="vc-btn vc-warn" data-vc-action="acknowledge">Acknowledge</button>' +
          '<button type="button" class="vc-btn vc-ok" data-vc-action="resolve">Resolve</button></div>'
        : '');
  }

  /**
   * HTML for one card.
   * @param {object} payload  card payload (server metadata)
   * @param {object} opts     { canDecide:boolean, readOnly:boolean }
   */
  function render(payload, opts) {
    opts = opts || {};
    const type = (payload && (payload.card_type || payload.type)) || '';
    let inner;
    if (type === 'leave_card') inner = leaveCard(payload || {}, opts);
    else if (type === 'safety_checklist') inner = checklistCard(payload || {}, opts);
    else if (type === 'sos_pin') inner = sosCard(payload || {}, opts);
    else return '';
    return '<div class="vc-card vc-' + esc(type) + '" data-vc-type="' + esc(type) + '">' + inner + '</div>';
  }

  /**
   * Wire one rendered card. `onAction(action, extra)` performs the request;
   * buttons are disabled while it runs so a double tap cannot double-decide.
   */
  function bind(root, onAction) {
    if (!root || typeof onAction !== 'function') return;
    root.querySelectorAll('[data-vc-action]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const action = btn.getAttribute('data-vc-action');
        const group = root.querySelectorAll('[data-vc-action]');
        group.forEach((b) => { b.disabled = true; });
        root.classList.add('vc-busy');
        try {
          await onAction(action, {});
        } catch (e) {
          group.forEach((b) => { b.disabled = false; });
          if (window.toast) window.toast((e && e.message) || 'Action failed', 'error');
        } finally {
          root.classList.remove('vc-busy');
        }
      });
    });
    root.querySelectorAll('[data-vc-index]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const index = Number(btn.getAttribute('data-vc-index'));
        const willCheck = !btn.classList.contains('done');
        btn.classList.toggle('done', willCheck);
        try {
          await onAction('toggle', { index: index, checked: willCheck });
        } catch (e) {
          btn.classList.toggle('done', !willCheck);
          if (window.toast) window.toast((e && e.message) || 'Could not save', 'error');
        }
      });
    });
  }

  window.Voic3Cards = { render: render, bind: bind, isCard: isCard, labels: CARD_LABELS };
})();
