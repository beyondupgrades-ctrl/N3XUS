// VOIC3 RTC helper - free, self-hosted, vanilla JS
// Exposes window.Voic3RTC used by mobile.js
(function () {
  'use strict';
  const API = (p) => (window.api ? window.api(p) : fetch(p, { credentials: 'same-origin' }).then(r => r.json()));
  const POST = (p, body) => fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(body || {}) });

  const state = {
    activeCall: null, pc: null, localStream: null, remoteStream: null,
    callType: 'audio', ringTimer: null, candidates: {},
    sse: null, reconnectTimer: null, me: null,
  };

  function iceServers() {
    return fetch('/api/voic3/ice-config', { credentials: 'same-origin' })
      .then(r => r.json()).then(d => d.iceServers || [{ urls: ['stun:stun.l.google.com:19302'] }])
      .catch(() => [{ urls: ['stun:stun.l.google.com:19302'] }]);
  }

  function connectSSE() {
    if (state.sse) return;
    try { state.sse = new EventSource('/api/voic3/events', { withCredentials: true }); } catch (e) { state.sse = new EventSource('/api/voic3/events'); }
    state.sse.addEventListener('call.incoming', (e) => {
      try {
        const d = JSON.parse(e.data);
        // Only ring for a call addressed to this phone. An event for a call this
        // phone started (caller is me) must never raise the incoming-call screen.
        const me = state.me != null ? String(state.me) : (window.N3XUS && window.N3XUS.me != null ? String(window.N3XUS.me) : null);
        const caller = d.caller_employee_id != null ? d.caller_employee_id : (d.caller && d.caller.id);
        const callee = d.callee_employee_id != null ? d.callee_employee_id : d.callee_id;
        if (me != null && caller != null && String(caller) === me) return;
        if (me != null && callee != null && String(callee) !== me) return;
        if (window.showIncoming) window.showIncoming(d);
      } catch (err) {}
    });
    state.sse.addEventListener('call.state', (e) => {
      try { const d = JSON.parse(e.data); if (window.onCallState) window.onCallState(d); } catch (err) {}
    });
    state.sse.addEventListener('call.signal', (e) => {
      try { const d = JSON.parse(e.data); handleSignal(d); } catch (err) {}
    });
    state.sse.onerror = () => {
      state.sse = null;
      if (state.reconnectTimer) clearTimeout(state.reconnectTimer);
      state.reconnectTimer = setTimeout(connectSSE, 3000);
    };
  }

  async function setupPeer(callId, isCaller, calleeId) {
    const servers = await iceServers();
    const pc = new RTCPeerConnection({ iceServers: servers });
    state.pc = pc;
    state.candidates[callId] = [];
    const stream = await navigator.mediaDevices.getUserMedia({
      video: state.callType === 'video',
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
    });
    state.localStream = stream;
    const local = document.getElementById('local');
    if (local) local.srcObject = stream;
    stream.getTracks().forEach(t => pc.addTrack(t, stream));
    pc.ontrack = (ev) => {
      const r = document.getElementById('remote');
      if (r) r.srcObject = ev.streams[0];
    };
    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        POST('/api/mobile/calls/' + callId + '/signal', { kind: 'ice', payload: JSON.stringify(ev.candidate) }).catch(() => {});
      }
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'disconnected') { try { pc.restartIce(); } catch (e) {} }
      if (pc.connectionState === 'failed') { endCall('failed'); }
    };
    // Section 13: watch link quality so a weak 4G link drops video, not audio.
    try { if (window.Voic3NetQuality) window.Voic3NetQuality.watch(pc); } catch (e) {}
    if (isCaller) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await POST('/api/mobile/calls/' + callId + '/signal', { kind: 'offer', payload: JSON.stringify(offer) });
      // caller does NOT call /answer; waits for callee's active state via SSE
    }
    return pc;
  }

  async function handleSignal(d) {
    if (!state.pc) return;
    const pc = state.pc;
    const payload = (typeof d.payload === 'string') ? JSON.parse(d.payload) : d.payload;
    if (d.kind === 'offer') {
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      const ans = await pc.createAnswer();
      await pc.setLocalDescription(ans);
      await POST('/api/mobile/calls/' + state.activeCall + '/signal', { kind: 'answer', payload: JSON.stringify(ans) });
      await POST('/api/mobile/calls/' + state.activeCall + '/answer', {});
      flushCandidates(state.activeCall);
    } else if (d.kind === 'answer') {
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      flushCandidates(state.activeCall);
    } else if (d.kind === 'ice') {
      if (pc.remoteDescription) {
        try { await pc.addIceCandidate(new RTCIceCandidate(payload)); } catch (e) {}
      } else {
        (state.candidates[state.activeCall] = state.candidates[state.activeCall] || []).push(payload);
      }
    }
  }

  function flushCandidates(callId) {
    const pc = state.pc;
    const list = state.candidates[callId] || [];
    list.forEach(c => { try { pc.addIceCandidate(new RTCIceCandidate(c)); } catch (e) {} });
    state.candidates[callId] = [];
  }

  function endCall(reason) {
    try { if (window.Voic3NetQuality) window.Voic3NetQuality.stop(); } catch (e) {}
    if (state.ringTimer) { clearTimeout(state.ringTimer); state.ringTimer = null; }
    if (state.activeCall) {
      POST('/api/mobile/calls/' + state.activeCall + '/end', { reason: reason || 'completed' }).catch(() => {});
    }
    if (state.pc) { try { state.pc.getSenders().forEach(s => s.track && s.track.stop()); } catch (e) {} state.pc.close(); state.pc = null; }
    if (state.localStream) { state.localStream.getTracks().forEach(t => t.stop()); state.localStream = null; }
    state.activeCall = null;
    state.remoteStream = null;
    if (window.onCallEnded) window.onCallEnded(reason);
  }

  function startCall(callee, callType) {
    state.callType = callType || 'audio';
    API('/api/mobile/employees').then(d => {
      const t = (d.items || []).find(e => String(e.employee_no) === String(callee));
      if (!t) { if (window.toast) window.toast('Employee not found', 'error'); return; }
      const cid = t.employee_id || t.id;
      return POST('/api/mobile/calls', { callee_employee_id: cid, call_type: state.callType }).then(r => r.json()).then(res => {
        state.activeCall = res.id;
        if (window.showCallScreen) window.showCallScreen(t.name || t.first_name || callee);
        setupPeer(res.id, true).then(() => {
          state.ringTimer = setTimeout(() => endCall('missed'), 45000);
        });
      });
    }).catch(e => { if (window.toast) window.toast(e.message || 'Call failed', 'error'); });
  }

  function declineCall(callId) {
    POST('/api/mobile/calls/' + callId + '/decline', {}).catch(() => {});
    if (window.onCallEnded) window.onCallEnded('declined');
  }

  window.addEventListener('beforeunload', () => endCall('cancelled'));

  window.Voic3RTC = { connectSSE, startCall, endCall, declineCall, state };
  // auto-connect
  setTimeout(connectSSE, 0);
})();

// ---- MeetingRoomClient (Section 9) ----
function MeetingRoomClient(meetingId) {
  this.meetingId = meetingId;
  this.peers = {};
  this.localStream = null;
  this.audioOnly = false;
}
MeetingRoomClient.prototype.join = async function () {
  this.localStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: true });
  return this;
};
MeetingRoomClient.prototype.setAudioOnly = function (on) { this.audioOnly = !!on; };
MeetingRoomClient.prototype.watchQuality = function (pc) {
  // Section 13: the same 2 s getStats() watchdog runs during meetings.
  try { if (window.Voic3NetQuality && pc) window.Voic3NetQuality.watch(pc); } catch (e) {}
  return this;
};
MeetingRoomClient.prototype.close = function () {
  try { if (window.Voic3NetQuality) window.Voic3NetQuality.stop(); } catch (e) {}
  Object.keys(this.peers).forEach(k => { try { this.peers[k].close(); } catch (e) {} });
  this.peers = {};
  if (this.localStream) this.localStream.getTracks().forEach(t => t.stop());
  this.localStream = null;
};
window.MeetingRoomClient = MeetingRoomClient;
