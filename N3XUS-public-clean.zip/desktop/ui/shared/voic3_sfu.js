/* ============================================================
   VOIC3 Section 15 — optional LiveKit SFU transport, end-to-end
   encryption keys and local transcription helpers.

   Nothing here is required. `Voic3Sfu.available()` returns false unless the
   server reports a configured LiveKit SFU, and the meeting client keeps using
   the existing peer-to-peer path in that case. The LiveKit client library is
   loaded on demand from the app's own /vendor folder (self-hosted, no CDN).

   E2EE uses the browser's own insertable streams (RTCRtpScriptTransform), which
   is native — no extra library, no key escrow: the server only hands out a room
   key to participants it has already admitted.
   ============================================================ */
(function () {
  'use strict';

  const VENDOR_URL = '/vendor/livekit-client.umd.min.js';

  const state = {
    caps: null,
    room: null,
    loading: null,
    error: '',
    identity: '',
    e2ee: false
  };

  function api(path, opts) {
    if (window.api) return window.api(path, opts);
    return fetch(path, Object.assign({ credentials: 'same-origin' }, opts || {})).then((r) => r.json());
  }

  /** Ask the server what this deployment supports. Cached for the session. */
  function capabilities(force) {
    if (state.caps && !force) return Promise.resolve(state.caps);
    return api('/api/voic3/rtc/capabilities')
      .then((caps) => { state.caps = caps || {}; return state.caps; })
      .catch(() => {
        state.caps = { sfu: { enabled: false }, e2ee: { enabled: false }, transcription: { enabled: false } };
        return state.caps;
      });
  }

  function available() {
    return !!(state.caps && state.caps.sfu && state.caps.sfu.enabled);
  }

  /**
   * The vendored client is absent (or livekit-client is not configured). Both
   * are normal: the meeting falls back to peer-to-peer.
   */
  function vendorPresent() {
    return !state.error && !!(window.LivekitClient || state.loading);
  }

  function loadLiveKit() {
    if (window.LivekitClient) return Promise.resolve(window.LivekitClient);
    if (state.loading) return state.loading;
    state.loading = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = VENDOR_URL;
      script.async = true;
      script.onload = () => {
        if (window.LivekitClient) resolve(window.LivekitClient);
        else reject(new Error('The LiveKit client loaded but registered nothing.'));
      };
      script.onerror = () => reject(new Error('The LiveKit client is not installed at ' + VENDOR_URL + '.'));
      document.head.appendChild(script);
    }).catch((err) => {
      state.loading = null;
      state.error = err.message || String(err);
      throw err;
    });
    return state.loading;
  }

  function base64Bytes(value) {
    const normalised = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalised + '='.repeat((4 - (normalised.length % 4)) % 4);
    return Uint8Array.from(atob(padded), (c) => c.charCodeAt(0));
  }

  /**
   * SFrame key provider built from the server's per-meeting key payload.
   * LiveKit asks for a key per participant and per sender; one shared meeting
   * key is returned for every identity, which is what the server issued.
   */
  function keyProvider(payload) {
    const bytes = base64Bytes((payload && payload.key) || '');
    return {
      getKey: function () { return Promise.resolve(bytes); },
      key: bytes,
      epoch: payload && payload.epoch,
      algorithm: (payload && payload.algorithm) || 'SFrame'
    };
  }

  function supportsE2EE() {
    return typeof window !== 'undefined' && typeof window.RTCRtpScriptTransform !== 'undefined';
  }

  /**
   * Join a meeting over the SFU. Resolves to
   *   { room, url, identity, e2ee, isHost, info }
   * or null when the SFU is not configured (so the caller keeps peer-to-peer).
   * Rejects only when it should have worked and did not.
   */
  async function join(meetingId, opts) {
    opts = opts || {};
    await capabilities();
    if (!available()) return null;
    const lk = await loadLiveKit();
    const info = await api('/api/voic3/meetings/' + meetingId + '/rtc-token',
      { method: 'POST', body: JSON.stringify({}) });
    if (!info || !info.token) return null;

    const useE2EE = !!(info.e2ee && supportsE2EE());
    const room = new lk.Room({
      adaptiveStream: true,
      dynacast: true,
      videoCaptureDefaults: { resolution: lk.VideoPresets.h720.resolution },
      e2ee: useE2EE ? keyProvider(info.e2ee) : undefined
    });
    state.room = room;
    state.identity = info.identity || '';
    state.e2ee = useE2EE;

    room.on(lk.RoomEvent.TrackSubscribed, (track, publication, participant) => {
      if (opts.onTrack) opts.onTrack(track, participant, publication);
    });
    room.on(lk.RoomEvent.TrackUnsubscribed, (track, publication, participant) => {
      if (opts.onUnsubscribe) opts.onUnsubscribe(track, participant, publication);
    });
    room.on(lk.RoomEvent.ParticipantConnected, (p) => opts.onParticipant && opts.onParticipant(p));
    room.on(lk.RoomEvent.ParticipantDisconnected, (p) => opts.onParticipantLeft && opts.onParticipantLeft(p));
    room.on(lk.RoomEvent.ActiveSpeakersChanged, (speakers) => {
      if (opts.onSpeakers) opts.onSpeakers((speakers || []).map((s) => s.identity));
    });
    room.on(lk.RoomEvent.Disconnected, () => {
      const wasConnected = state.room === room;
      state.room = null;
      if (wasConnected && opts.onDisconnected) opts.onDisconnected();
    });

    try {
      await room.connect(info.url, info.token);
    } catch (err) {
      state.room = null;
      try { await room.disconnect(); } catch (e) { /* never connected */ }
      throw err;
    }

    // Publish the microphone and camera the lobby already opened, so the local
    // preview and the published tracks are the same devices.
    const stream = opts.localStream;
    const published = { audio: false, video: false };
    try {
      if (stream && stream.getAudioTracks().length) {
        await room.localParticipant.publishTrack(stream.getAudioTracks()[0], { source: lk.Track.Source.Microphone });
        published.audio = true;
      }
    } catch (e) { /* a refused microphone is not fatal */ }
    try {
      if (stream && stream.getVideoTracks().length && opts.cameraOn !== false) {
        await room.localParticipant.publishTrack(stream.getVideoTracks()[0], { source: lk.Track.Source.Camera });
        published.video = true;
      }
    } catch (e) { /* a refused camera is not fatal */ }

    return { room: room, url: info.url, identity: info.identity, e2ee: useE2EE,
      isHost: !!info.is_host, info: info, published: published };
  }

  async function leave() {
    if (!state.room) return;
    const room = state.room;
    state.room = null;
    state.identity = '';
    state.e2ee = false;
    try { await room.disconnect(); } catch (e) { /* already gone */ }
  }

  /** Publish (or stop publishing) the screen share over the SFU. */
  async function publishScreen(track) {
    if (!state.room || !window.LivekitClient) return null;
    if (!track) {
      const pub = Array.from(state.room.localParticipant.trackPublications.values())
        .find((p) => p.source === window.LivekitClient.Track.Source.ScreenShare);
      if (pub) await state.room.localParticipant.unpublishTrack(pub.track);
      return null;
    }
    return state.room.localParticipant.publishTrack(track, {
      source: window.LivekitClient.Track.Source.ScreenShare
    });
  }

  /** Mute or unmute the published microphone without ending the track. */
  async function setMicEnabled(on) {
    if (!state.room) return;
    const pub = Array.from(state.room.localParticipant.trackPublications.values())
      .find((p) => p.source === window.LivekitClient.Track.Source.Microphone);
    if (pub && pub.track) { if (on) await pub.track.unmute(); else await pub.track.mute(); }
  }

  /** Send a whiteboard stroke to everyone in the SFU room. */
  function sendData(message) {
    if (!state.room) return false;
    try {
      const payload = new TextEncoder().encode(JSON.stringify(message));
      state.room.localParticipant.publishData(payload, { reliable: true });
      return true;
    } catch (e) { return false; }
  }

  /** Read a transcript of a saved recording (cached server-side after the first run). */
  function transcribe(attachmentId, language) {
    return api('/api/voic3/attachments/' + attachmentId + '/transcribe',
      { method: 'POST', body: JSON.stringify({ language: language || '' }) });
  }

  window.Voic3Sfu = {
    capabilities: capabilities,
    available: available,
    vendorPresent: vendorPresent,
    loadLiveKit: loadLiveKit,
    supportsE2EE: supportsE2EE,
    join: join,
    leave: leave,
    publishScreen: publishScreen,
    setMicEnabled: setMicEnabled,
    sendData: sendData,
    transcribe: transcribe,
    keyProvider: keyProvider,
    state: state
  };
})();
