// i18n - in-house, 100% free, no external service
// Add language files in /i18n/<lang>.json and register here.
const I18N = {
  en: {
    dashboard: "Dashboard", employees: "Employees", payroll: "Payroll",
    leave: "Leave", attendance: "Attendance", settings: "Settings",
    save: "Save", cancel: "Cancel", delete: "Delete", edit: "Edit",
    search: "Search", loading: "Loading...", error: "Error",
    theme_dark: "Dark", theme_light: "Light",
  },
  af: {
    dashboard: "Kontroleskerm", employees: "Werknemers", payroll: "Betaalstaat",
    leave: "Verlof", attendance: "Bywoning", settings: "Instellings",
    save: "Stoor", cancel: "Kanselleer", delete: "Verwyder", edit: "Wysig",
    search: "Soek", loading: "Laai...", error: "Fout",
    theme_dark: "Donker", theme_light: "Lig",
  },
  zu: {
    dashboard: "Ideshibhodi", employees: "Abasebenzi", payroll: "Iholo",
    leave: "Iholide", attendance: "Ukuba khona", settings: "Izilungiselelo",
    save: "Gcina", cancel: "Khansela", delete: "Susa", edit: "Hlela",
    search: "Sesha", loading: "Iyalayisha...", error: "Iphutha",
    theme_dark: "Mnyama", theme_light: "Kukhanya",
  },
};
function t(key, lang) {
  lang = lang || localStorage.getItem("nexus-lang") || "en";
  return (I18N[lang] && I18N[lang][key]) || (I18N.en && I18N.en[key]) || key;
}
function setLang(lang) { try { localStorage.setItem("nexus-lang", lang); } catch (e) {} }