/* gloss.js — in-house glossy icon tiles.
   Uses the paths already in icons.js, so there is no extra asset to ship.
   No external libraries, no CDN, no paid icon pack. */
(function () {
  var tones = {
    blue: 'blue', green: 'green', emerald: 'green', amber: 'amber', orange: 'orange',
    violet: 'violet', cyan: 'cyan', red: 'red', coral: 'red', slate: 'slate'
  };

  window.glossIcon = function (name, tone, size) {
    var paths = (typeof icons !== 'undefined' && icons[name]) || icons.grid || '';
    var cls = 'gloss ' + (tones[tone] || 'blue') + (size === 'lg' ? ' lg' : '');
    return '<span class="' + cls + '" aria-hidden="true"><svg viewBox="0 0 24 24">' + paths + '</svg></span>';
  };

  /* Colour meanings, one per domain. Used by the shell and the profile homes. */
  window.glossTone = {
    patients: 'blue', care: 'blue', staff: 'green', payroll: 'amber',
    leave: 'green', comms: 'orange', learning: 'violet', safety: 'red',
    stock: 'green', documents: 'cyan', tracker: 'cyan', vitals: 'red',
    reports: 'cyan', system: 'green'
  };

  window.glossFor = function (domain, fallbackIcon) {
    return glossIcon(fallbackIcon || 'grid', glossTone[domain] || 'blue');
  };
})();
