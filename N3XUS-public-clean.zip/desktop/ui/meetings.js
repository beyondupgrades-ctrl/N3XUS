/* ============================================================
   VOIC3 meetings (Section 10) — Lobby, Waiting Room, Grid and
   Spotlight stage, host/participant toolbars, MediaRecorder and a
   slide-over Chat + Whiteboard.

   Self-hosted and free: WebRTC peer-to-peer for the mesh, the server's
   existing SSE bus (meeting.join / admitted / hand / emoji / action /
   recording) for signalling, and RTCDataChannel for whiteboard strokes.
   The optional LiveKit SFU from Section 15 is used when the server says it
   is configured; otherwise this mesh path is unchanged.

   Public API: window.Voic3Meetings.open(meetingId), .close(), .list()
   ============================================================ */
(function () {
  'use strict';

  const API = (path, opts) => {
    if (window.api) return window.api(path, opts);
    return fetch(path, Object.assign({ credentials: 'same-origin' }, opts || {})).then((r) => r.json());
  };
  const POST = (path, body) => API(path, { method: 'POST', body: JSON.stringify(body || {}) });

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }
  function toast(message, kind) {
    if (window.toast) { window.toast(message, kind); return; }
    const el = document.querySelector('#voic3-meeting-root .mtg-toast');
    if (!el) return;
    el.textContent = message;
    el.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { el.hidden = true; }, 2600);
  }
  function initials(name) {
    return String(name || '?').trim().split(/\s+/).slice(0, 2).map((p) => p[0] || '').join('').toUpperCase() || '?';
  }

  const state = {
    meetingId: null,
    meeting: null,
    me: null,
    isHost: false,
    localStream: null,
    screenStream: null,
    peers: {},              // employee_id -> { pc, channel, stream }
    sse: null,
    pollTimer: null,
    audioCtx: null,
    analysers: {},          // employee_id -> { analyser, data, level }
    speaking: null,
    view: 'grid',           // grid | spotlight
    spotlightId: null,
    micOn: true,
    camOn: true,
    screenOn: false,
    handRaised: false,
    recorder: null,
    chunks: [],
    recording: false,
    uploadTimer: null,
    whiteboard: { strokes: [], color: '#111827', size: 3, drawing: false, last: null },
    devices: { cams: [], mics: [] },
    deviceId: null,
    micId: null,
    transport: 'p2p',
    sfuIdentity: '',
    sfuStreams: {}
  };

  /* ------------------------------------------------------------ DOM ---- */
  function root() {
    let el = document.getElementById('voic3-meeting-root');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'voic3-meeting-root';
    el.innerHTML =
      '<div class="mtg-top">' +
        '<div><div class="mtg-title" id="mtg-title">Meeting</div>' +
        '<div class="mtg-sub" id="mtg-sub"></div></div>' +
        '<span class="mtg-spacer"></span>' +
        '<span class="mtg-pill" id="mtg-pill-count">0</span>' +
        '<span class="mtg-pill" id="mtg-pill-lock" hidden>LOCKED</span>' +
        '<span class="mtg-pill rec" id="mtg-pill-rec" hidden>● REC</span>' +
        '<button type="button" class="mtg-tool" data-mtg="layout" title="Switch grid / spotlight">Grid</button>' +
        '<button type="button" class="mtg-tool" data-mtg="close" title="Leave">Leave</button>' +
      '</div>' +
      '<div class="mtg-body">' +
        '<div class="mtg-stage-wrap">' +
          '<div class="mtg-stage grid" id="mtg-stage"></div>' +
          '<div class="mtg-toolbar" id="mtg-toolbar"></div>' +
          '<div class="mtg-host-tools" id="mtg-host-tools" hidden></div>' +
        '</div>' +
      '</div>' +
      '<div class="mtg-reactions" id="mtg-reactions"></div>' +
      '<div class="mtg-toast" hidden></div>';
    document.body.appendChild(el);
    el.addEventListener('click', onRootClick);
    return el;
  }

  function $(sel) { return document.querySelector(sel); }

  /* --------------------------------------------------------- devices ---- */
  async function enumerateDevices() {
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      state.devices.cams = list.filter((d) => d.kind === 'videoinput');
      state.devices.mics = list.filter((d) => d.kind === 'audioinput');
    } catch (e) { /* permission not granted yet */ }
  }

  async function openLocalMedia(videoOn, audioOn) {
    const constraints = {
      video: videoOn ? (state.deviceId ? { deviceId: { exact: state.deviceId } } : true) : false,
      audio: audioOn ? Object.assign({ echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        state.micId ? { deviceId: { exact: state.micId } } : {}) : false
    };
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    if (state.localStream) state.localStream.getTracks().forEach((t) => t.stop());
    state.localStream = stream;
    return stream;
  }

  /* ---------------------------------------------------------- lobby ---- */
  async function showLobby(meeting) {
    const el = root();
    el.classList.add('open');
    const existing = el.querySelector('.mtg-overlay');
    if (existing) existing.remove();
    await enumerateDevices();
    const camOptions = state.devices.cams.map((d, i) =>
      '<option value="' + esc(d.deviceId) + '">' + esc(d.label || ('Camera ' + (i + 1))) + '</option>').join('');
    const micOptions = state.devices.mics.map((d, i) =>
      '<option value="' + esc(d.deviceId) + '">' + esc(d.label || ('Microphone ' + (i + 1))) + '</option>').join('');
    const overlay = document.createElement('div');
    overlay.className = 'mtg-overlay';
    overlay.innerHTML =
      '<div class="mtg-panel">' +
        '<div><b>Ready to join?</b><div class="mtg-note" id="mtg-lobby-note">' +
        (meeting.waiting_room_enabled ? 'The host will admit you from the waiting room.' : 'You will join straight away.') +
        '</div></div>' +
        '<div class="mtg-lobby-grid">' +
          '<div class="mtg-preview" id="mtg-preview"><span class="mtg-preview-off">Camera off</span></div>' +
          '<div class="mtg-lobby-fields">' +
            '<label>Camera<select id="mtg-cam">' + camOptions + '</select></label>' +
            '<label>Microphone<select id="mtg-mic">' + micOptions + '</select></label>' +
            '<div class="mtg-level"><span>Mic</span><div class="mtg-meter"><i id="mtg-mic-meter"></i></div></div>' +
            '<div class="mtg-row">' +
              '<button type="button" class="mtg-tool on" id="mtg-lobby-cam">Camera on</button>' +
              '<button type="button" class="mtg-tool on" id="mtg-lobby-mic">Mic on</button>' +
            '</div>' +
            '<button type="button" class="mtg-tool on" id="mtg-join" style="justify-content:center">Join meeting</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    el.appendChild(overlay);

    let camOn = true;
    let micOn = true;
    const camBtn = overlay.querySelector('#mtg-lobby-cam');
    const micBtn = overlay.querySelector('#mtg-lobby-mic');
    const preview = overlay.querySelector('#mtg-preview');

    async function refreshPreview() {
      try {
        const stream = await openLocalMedia(camOn, micOn);
        preview.innerHTML = '';
        if (camOn) {
          const v = document.createElement('video');
          v.autoplay = true; v.muted = true; v.playsInline = true;
          v.srcObject = stream;
          preview.appendChild(v);
        } else {
          preview.innerHTML = '<span class="mtg-preview-off">Camera off</span>';
        }
        if (micOn) watchMicLevel(stream, overlay.querySelector('#mtg-mic-meter'));
      } catch (err) {
        preview.innerHTML = '<span class="mtg-preview-off">' + esc(err.message || 'Camera unavailable') + '</span>';
      }
    }

    camBtn.onclick = () => { camOn = !camOn; camBtn.classList.toggle('on', camOn); camBtn.textContent = camOn ? 'Camera on' : 'Camera off'; refreshPreview(); };
    micBtn.onclick = () => { micOn = !micOn; micBtn.classList.toggle('on', micOn); micBtn.textContent = micOn ? 'Mic on' : 'Mic off'; refreshPreview(); };
    overlay.querySelector('#mtg-cam').onchange = (e) => { state.deviceId = e.target.value; refreshPreview(); };
    overlay.querySelector('#mtg-mic').onchange = (e) => { state.micId = e.target.value; refreshPreview(); };
    overlay.querySelector('#mtg-join').onclick = () => {
      state.micOn = micOn; state.camOn = camOn;
      overlay.remove();
      joinMeeting(meeting, camOn, micOn);
    };

    refreshPreview();
  }

  function watchMicLevel(stream, meterEl) {
    if (!meterEl) return;
    try {
      state.audioCtx = state.audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const src = state.audioCtx.createMediaStreamSource(stream);
      const analyser = state.audioCtx.createAnalyser();
      analyser.fftSize = 512;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        if (!document.body.contains(meterEl)) return;
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i += 1) sum += data[i];
        const pct = Math.min(100, Math.round((sum / data.length) * 2.2));
        meterEl.style.width = pct + '%';
        requestAnimationFrame(tick);
      };
      tick();
    } catch (e) { /* audio context blocked until interaction */ }
  }

  /* ----------------------------------------------------- join + poll ---- */
  async function joinMeeting(meeting, camOn, micOn) {
    state.meeting = meeting;
    state.meetingId = meeting.id;
    state.isHost = !!meeting.is_host;
    try {
      const joined = await POST('/api/voic3/meetings/join', { code: meeting.code });
      state.me = joined;
    } catch (err) {
      toast(err.message || 'Could not join', 'error');
    }
    if (!state.localStream) await openLocalMedia(camOn, micOn).catch(() => {});
    // Section 15: use the SFU when the deployment has one configured, and fall
    // back to the peer-to-peer mesh when it does not (or refuses us).
    await connectSfu();
    connectEvents();
    startPolling();
    await refresh();
  }

  /* ------------------------------------------------------------- SFU ---- */
  async function connectSfu() {
    if (!window.Voic3Sfu) return;
    try { await Voic3Sfu.capabilities(); } catch (e) { return; }
    if (!Voic3Sfu.available()) { state.transport = 'p2p'; return; }
    try {
      const joined = await Voic3Sfu.join(state.meetingId, {
        localStream: state.localStream,
        cameraOn: state.camOn,
        onTrack: (track, participant) => {
          const id = employeeFromIdentity(participant && participant.identity);
          if (!id) return;
          if (!state.sfuStreams[id]) state.sfuStreams[id] = new MediaStream();
          try { state.sfuStreams[id].addTrack(track.mediaStreamTrack || track); } catch (e) { /* duplicate */ }
          attachStreams(((state.meeting && state.meeting.participants) || []).filter((p) => p.state === 'admitted'));
        },
        onUnsubscribe: (track, participant) => {
          const id = employeeFromIdentity(participant && participant.identity);
          if (id && state.sfuStreams[id]) {
            try { state.sfuStreams[id].removeTrack(track.mediaStreamTrack || track); } catch (e) { /* gone */ }
          }
        },
        onParticipant: () => refreshTiles(),
        onParticipantLeft: () => refreshTiles(),
        onSpeakers: (identities) => markSfuSpeaker(identities),
        onDisconnected: () => {
          if (state.transport !== 'sfu') return;
          state.transport = 'p2p';
          toast('Media server disconnected — continuing peer-to-peer');
          refresh().catch(() => {});
        }
      });
      if (!joined) { state.transport = 'p2p'; return; }
      state.transport = 'sfu';
      state.sfuIdentity = joined.identity || '';
      if (joined.e2ee) toast('End-to-end encryption is on for this meeting');
    } catch (err) {
      state.transport = 'p2p';
      // Waiting-room and locked-room refusals surface as a normal message.
      if (err && /admit|locked/i.test(err.message || '')) toast(err.message, 'error');
    }
  }

  /* LiveKit identities are "emp-<employee_id>" (see voic3_sfu.access_token). */
  function employeeFromIdentity(identity) {
    const match = /^emp-(\d+)$/.exec(String(identity || ''));
    return match ? Number(match[1]) : null;
  }

  function markSfuSpeaker(identities) {
    const ids = (identities || []).map(employeeFromIdentity).filter(Boolean);
    state.speaking = ids[0] || null;
    document.querySelectorAll('.mtg-tile').forEach((tile) => {
      tile.classList.toggle('speaking', ids.indexOf(Number(tile.dataset.employee)) !== -1);
    });
  }

  function startPolling() {
    stopPolling();
    state.pollTimer = setInterval(() => {
      if (!state.meetingId) return;
      API('/api/voic3/meetings/' + state.meetingId + '/poll')
        .then((snapshot) => { if (snapshot && snapshot.participants) renderSnapshot(snapshot); })
        .catch(() => {});
    }, 5000);
  }
  function stopPolling() {
    if (state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = null;
  }

  async function refresh() {
    if (!state.meetingId) return;
    const snapshot = await API('/api/voic3/meetings/' + state.meetingId);
    state.meeting = Object.assign({}, state.meeting, snapshot);
    state.isHost = !!snapshot.is_host;
    renderSnapshot(snapshot);
    const mine = snapshot.me || {};
    if (mine.state === 'waiting') showWaitingRoom(snapshot);
    else {
      removeOverlay();
      if (mine.state === 'rejected') { toast('The host declined your request to join.', 'error'); close(); }
    }
  }

  /* --------------------------------------------------- waiting room ---- */
  function showWaitingRoom(snapshot) {
    const el = root();
    let overlay = el.querySelector('.mtg-overlay');
    if (overlay && overlay.dataset.kind === 'waiting') {
      const list = overlay.querySelector('.mtg-waiting-list');
      if (list && state.isHost) list.innerHTML = waitingListMarkup(snapshot);
      return;
    }
    if (overlay) overlay.remove();
    overlay = document.createElement('div');
    overlay.className = 'mtg-overlay';
    overlay.dataset.kind = 'waiting';
    overlay.innerHTML = state.isHost
      ? '<div class="mtg-panel"><div><b>Waiting room</b><div class="mtg-note">' +
        snapshot.waiting.length + ' person(s) waiting to join.</div></div>' +
        '<div class="mtg-waiting-list">' + waitingListMarkup(snapshot) + '</div>' +
        '<button type="button" class="mtg-tool on" data-mtg="admit-all">Admit everyone</button></div>'
      : '<div class="mtg-panel mtg-waiting"><div class="mtg-spinner"></div>' +
        '<b>Waiting for the host</b><div class="mtg-note">You will join as soon as the host admits you.</div>' +
        '<button type="button" class="mtg-tool danger" data-mtg="close">Cancel</button></div>';
    el.appendChild(overlay);
  }

  function waitingListMarkup(snapshot) {
    const waiting = snapshot.waiting || [];
    if (!waiting.length) return '<div class="mtg-note">Nobody is waiting.</div>';
    return waiting.map((p) =>
      '<div class="mtg-waiting-item"><span class="mtg-avatar" style="width:30px;height:30px;font-size:12px">' +
      esc(initials(p.name)) + '</span><span>' + esc(p.name) + '</span><span class="mtg-spacer"></span>' +
      '<button type="button" class="mtg-tool on" data-mtg="admit" data-id="' + p.employee_id + '">Admit</button>' +
      '<button type="button" class="mtg-tool danger" data-mtg="reject" data-id="' + p.employee_id + '">Decline</button>' +
      '</div>').join('');
  }

  function removeOverlay() {
    const overlay = root().querySelector('.mtg-overlay');
    if (overlay) overlay.remove();
  }

  /* ------------------------------------------------------ rendering ---- */
  function renderSnapshot(snapshot) {
    const el = root();
    const admitted = (snapshot.participants || []).filter((p) => p.state === 'admitted');
    $('#mtg-title').textContent = snapshot.title || state.meeting && state.meeting.title || 'Meeting';
    $('#mtg-sub').textContent = (snapshot.is_host ? 'You are the host · ' : '') +
      admitted.length + ' in the room' + (state.transport === 'sfu' ? ' · media server' : '');
    $('#mtg-pill-count').textContent = admitted.length + ' live';
    $('#mtg-pill-lock').hidden = !snapshot.is_locked;
    $('#mtg-pill-rec').hidden = !state.recording;

    state.spotlightId = snapshot.spotlight_employee_id || state.spotlightId;
    renderStage(admitted, snapshot);
    renderToolbar(snapshot);
    renderHostTools(snapshot);
    if (snapshot.is_host && (snapshot.waiting || []).length) showWaitingRoom(snapshot);
    ensurePeers(admitted);
  }

  /* Open a peer connection to every other admitted participant. The first
     connection is created by whoever has the lower employee id, so both sides
     never offer at once; the other side answers when the offer arrives. */
  function ensurePeers(admitted) {
    // On the media server every participant is already reachable; a mesh on top
    // of it would duplicate audio.
    if (state.transport === 'sfu') return;
    if (!state.meetingId || !state.localStream) return;
    const meId = Number((state.meeting && state.meeting.me && state.meeting.me.employee_id) || 0);
    admitted.forEach((p) => {
      const other = Number(p.employee_id);
      if (p.is_me || !other || state.peers[other]) return;
      connectPeer(other).then((entry) => {
        if (!entry) return;
        if (meId && meId < other) {
          entry.pc.onnegotiationneeded = async () => {
            try {
              const offer = await entry.pc.createOffer();
              await entry.pc.setLocalDescription(offer);
              await POST('/api/voic3/meetings/' + state.meetingId + '/signal',
                { kind: 'offer', target: other, payload: JSON.stringify(offer) });
            } catch (e) { /* retried on the next poll */ }
          };
        }
      }).catch(() => {});
    });
  }

  async function handleSignal(data) {
    const from = Number(data.from || data.employee_id);
    if (!from) return;
    const payload = typeof data.payload === 'string' ? JSON.parse(data.payload) : data.payload;
    let entry = state.peers[from];
    if (!entry) entry = await connectPeer(from);
    if (!entry) return;
    const pc = entry.pc;
    try {
      if (data.kind === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(payload));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await POST('/api/voic3/meetings/' + state.meetingId + '/signal',
          { kind: 'answer', target: from, payload: JSON.stringify(answer) });
      } else if (data.kind === 'answer') {
        await pc.setRemoteDescription(new RTCSessionDescription(payload));
      } else if (data.kind === 'ice') {
        if (pc.remoteDescription) await pc.addIceCandidate(new RTCIceCandidate(payload));
      }
    } catch (e) { /* a failed candidate is not fatal */ }
  }

  function renderStage(participants, snapshot) {
    const stage = $('#mtg-stage');
    if (!stage) return;
    const spotlit = state.spotlightId && participants.find((p) => Number(p.employee_id) === Number(state.spotlightId));
    const useSpotlight = state.view === 'spotlight' || !!spotlit;
    stage.className = 'mtg-stage ' + (useSpotlight ? 'spotlight' : 'grid');
    const main = useSpotlight ? (spotlit || participants[0]) : null;
    const rest = useSpotlight ? participants.filter((p) => !main || Number(p.employee_id) !== Number(main.employee_id)) : participants;

    if (useSpotlight && main) {
      stage.innerHTML = tileMarkup(main, true) +
        '<div class="mtg-strip">' + rest.map((p) => tileMarkup(p, false)).join('') + '</div>';
    } else {
      stage.innerHTML = participants.length
        ? participants.map((p) => tileMarkup(p, false)).join('')
        : '<div class="mtg-tile"><span class="mtg-name">Waiting for people to join…</span></div>';
    }
    attachStreams(participants);
  }

  function tileMarkup(p, isMain) {
    const me = !!p.is_me;
    const speaking = Number(state.speaking) === Number(p.employee_id);
    const classes = ['mtg-tile'];
    if (isMain) classes.push('main');
    if (speaking) classes.push('speaking');
    if (Number(state.spotlightId) === Number(p.employee_id)) classes.push('spotlit');
    if (me) classes.push('mirror');
    const muted = p.is_muted_by_host || (me && !state.micOn);
    return '<div class="' + classes.join(' ') + '" data-employee="' + esc(p.employee_id) + '">' +
      '<video autoplay playsinline' + (me ? ' muted' : '') + ' id="mtg-v-' + esc(p.employee_id) + '"></video>' +
      (me && !state.camOn ? '<div class="mtg-avatar">' + esc(initials(p.name)) + '</div>' : '') +
      '<span class="mtg-name">' + esc(p.name) + (me ? ' (you)' : '') + (p.is_host ? ' · host' : '') + '</span>' +
      (p.hand_raised ? '<span class="mtg-hand" title="Hand raised">✋</span>' : '') +
      (muted ? '<span class="mtg-muted" title="Muted">🔇</span>' : '') +
      (me && state.screenOn ? '<span class="mtg-screenshare">Sharing your screen</span>' : '') +
      '</div>';
  }

  function attachStreams(participants) {
    participants.forEach((p) => {
      const video = document.getElementById('mtg-v-' + p.employee_id);
      if (!video) return;
      if (p.is_me && state.localStream) {
        video.srcObject = state.screenOn && state.screenStream ? state.screenStream : state.localStream;
        video.muted = true;
        return;
      }
      if (state.transport === 'sfu') {
        const stream = state.sfuStreams[p.employee_id];
        if (stream && stream.getTracks().length) { video.srcObject = stream; return; }
      }
      const peer = state.peers[p.employee_id];
      if (peer && peer.stream) {
        video.srcObject = peer.stream;
        if (!peer.audioWatched) { peer.audioWatched = true; watchSpeaking(p.employee_id, peer.stream); }
      }
    });
  }

  function refreshTiles() {
    if (state.meeting) refresh().catch(() => {});
  }

  /* ------------------------------------------------- active speaker ---- */
  function watchSpeaking(employeeId, stream) {
    if (!stream || !stream.getAudioTracks().length) return;
    try {
      state.audioCtx = state.audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const src = state.audioCtx.createMediaStreamSource(stream);
      const analyser = state.audioCtx.createAnalyser();
      analyser.fftSize = 512;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      state.analysers[employeeId] = { analyser: analyser, data: data, level: 0 };
      const tick = () => {
        if (!state.analysers[employeeId]) return;
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i += 1) sum += data[i];
        const level = sum / data.length;
        state.analysers[employeeId].level = level;
        if (level > 18) {
          if (Number(state.speaking) !== Number(employeeId)) {
            state.speaking = employeeId;
            document.querySelectorAll('.mtg-tile').forEach((t) => {
              t.classList.toggle('speaking', Number(t.dataset.employee) === Number(employeeId));
            });
          }
          state.analysers[employeeId].lastLoud = Date.now();
        } else if (Number(state.speaking) === Number(employeeId) &&
                   Date.now() - (state.analysers[employeeId].lastLoud || 0) > 1200) {
          state.speaking = null;
          document.querySelectorAll('.mtg-tile').forEach((t) => t.classList.remove('speaking'));
        }
        requestAnimationFrame(tick);
      };
      tick();
    } catch (e) { /* audio context unavailable */ }
  }

  /* -------------------------------------------------------- toolbars ---- */
  function renderToolbar(snapshot) {
    const bar = $('#mtg-toolbar');
    if (!bar) return;
    bar.innerHTML =
      '<button type="button" class="mtg-tool' + (state.micOn ? ' on' : '') + '" data-mtg="mic">' +
        (state.micOn ? 'Mute mic' : 'Unmute mic') + '</button>' +
      '<button type="button" class="mtg-tool' + (state.camOn ? ' on' : '') + '" data-mtg="cam">' +
        (state.camOn ? 'Stop camera' : 'Start camera') + '</button>' +
      '<button type="button" class="mtg-tool' + (state.screenOn ? ' on' : '') + '" data-mtg="screen">Share screen</button>' +
      '<button type="button" class="mtg-tool' + (state.handRaised ? ' on' : '') + '" data-mtg="hand">' +
        (state.handRaised ? 'Lower hand' : 'Raise hand') + '</button>' +
      '<button type="button" class="mtg-tool' + (state.recording ? ' recording' : '') + '" data-mtg="record">' +
        (state.recording ? 'Stop recording' : 'Record meeting') + '</button>' +
      '<span class="mtg-spacer"></span>' +
      '<button type="button" class="mtg-tool" data-mtg="react" data-emoji="👍">👍</button>' +
      '<button type="button" class="mtg-tool" data-mtg="react" data-emoji="👏">👏</button>' +
      '<button type="button" class="mtg-tool" data-mtg="react" data-emoji="❤️">❤️</button>' +
      '<button type="button" class="mtg-tool" data-mtg="react" data-emoji="😂">😂</button>' +
      '<button type="button" class="mtg-tool" data-mtg="side-chat">Chat</button>' +
      '<button type="button" class="mtg-tool" data-mtg="side-board">Whiteboard</button>';
  }

  function renderHostTools(snapshot) {
    const bar = $('#mtg-host-tools');
    if (!bar) return;
    if (!state.isHost) { bar.hidden = true; return; }
    bar.hidden = false;
    const waitingCount = (snapshot.waiting || []).length;
    bar.innerHTML =
      '<button type="button" class="mtg-tool" data-mtg="host" data-action="mute_all">Mute all</button>' +
      '<button type="button" class="mtg-tool' + (snapshot.is_locked ? ' on' : '') + '" data-mtg="host" data-action="' +
        (snapshot.is_locked ? 'unlock' : 'lock') + '">' + (snapshot.is_locked ? 'Unlock room' : 'Lock room') + '</button>' +
      '<button type="button" class="mtg-tool' + (waitingCount ? ' on' : '') + '" data-mtg="admit-all"' +
        (waitingCount ? '' : ' disabled') + '>Admit waiting (' + waitingCount + ')</button>' +
      '<button type="button" class="mtg-tool" data-mtg="spotlight">Spotlight</button>' +
      '<button type="button" class="mtg-tool danger" data-mtg="host" data-action="end_for_all">End meeting for all</button>';
  }

  /* -------------------------------------------------------- controls ---- */
  function toggleMic() {
    state.micOn = !state.micOn;
    if (state.localStream) state.localStream.getAudioTracks().forEach((t) => { t.enabled = state.micOn; });
    // On the SFU the published track is separate from the local stream.
    if (state.transport === 'sfu' && window.Voic3Sfu) Voic3Sfu.setMicEnabled(state.micOn).catch(() => {});
    renderToolbar(state.meeting || {});
    renderStage((state.meeting.participants || []).filter((p) => p.state === 'admitted'), state.meeting || {});
  }

  function toggleCam() {
    state.camOn = !state.camOn;
    if (state.localStream) state.localStream.getVideoTracks().forEach((t) => { t.enabled = state.camOn; });
    renderToolbar(state.meeting || {});
    refresh().catch(() => {});
  }

  async function toggleScreen() {
    if (state.screenOn) {
      if (state.transport === 'sfu' && window.Voic3Sfu) await Voic3Sfu.publishScreen(null).catch(() => {});
      if (state.screenStream) state.screenStream.getTracks().forEach((t) => t.stop());
      state.screenStream = null;
      state.screenOn = false;
      renderToolbar(state.meeting || {});
      refresh().catch(() => {});
      return;
    }
    try {
      const screen = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      state.screenStream = screen;
      state.screenOn = true;
      const track = screen.getVideoTracks()[0];
      if (track) track.onended = () => { state.screenOn = false; state.screenStream = null; renderToolbar(state.meeting || {}); refresh().catch(() => {}); };
      if (state.transport === 'sfu' && window.Voic3Sfu) {
        await Voic3Sfu.publishScreen(track).catch(() => {});
      } else {
        Object.keys(state.peers).forEach((key) => {
          const sender = state.peers[key].pc.getSenders().find((s) => s.track && s.track.kind === 'video');
          if (sender) sender.replaceTrack(track).catch(() => {});
        });
      }
      renderToolbar(state.meeting || {});
      refresh().catch(() => {});
    } catch (err) {
      if (err && err.name !== 'NotAllowedError') toast(err.message || 'Screen share failed', 'error');
    }
  }

  async function toggleHand() {
    state.handRaised = !state.handRaised;
    try { await POST('/api/voic3/meetings/' + state.meetingId + '/raise-hand', { raised: state.handRaised }); }
    catch (e) { state.handRaised = !state.handRaised; toast(e.message || 'Could not raise hand', 'error'); }
    renderToolbar(state.meeting || {});
    refresh().catch(() => {});
  }

  async function sendReaction(emoji) {
    floatReaction(emoji, true);
    try { await POST('/api/voic3/meetings/' + state.meetingId + '/emoji', { emoji: emoji }); } catch (e) { /* offline */ }
  }

  function floatReaction(emoji, mine) {
    const box = $('#mtg-reactions');
    if (!box) return;
    const span = document.createElement('span');
    span.className = 'mtg-float';
    span.textContent = emoji;
    span.style.left = (mine ? 50 : 15 + Math.random() * 70) + '%';
    box.appendChild(span);
    setTimeout(() => span.remove(), 2700);
  }

  async function hostAction(action, employeeId) {
    try {
      await POST('/api/voic3/meetings/' + state.meetingId + '/host-action',
        { action: action, employee_id: employeeId });
      if (action === 'end_for_all') { toast('Meeting ended'); close(); return; }
      await refresh();
    } catch (err) { toast(err.message || 'Action failed', 'error'); }
  }

  async function admit(employeeId) {
    try { await POST('/api/voic3/meetings/' + state.meetingId + '/admit', { employee_id: employeeId }); await refresh(); }
    catch (err) { toast(err.message || 'Could not admit', 'error'); }
  }
  async function reject(employeeId) {
    try { await POST('/api/voic3/meetings/' + state.meetingId + '/reject', { employee_id: employeeId }); await refresh(); }
    catch (err) { toast(err.message || 'Could not decline', 'error'); }
  }
  async function admitAll() {
    const waiting = ((state.meeting && state.meeting.waiting) || []).slice();
    for (const p of waiting) { await admit(p.employee_id); }
  }

  function spotlight() {
    const target = prompt('Spotlight which participant? Enter the name shown on their tile.');
    const list = (state.meeting && state.meeting.participants) || [];
    const hit = list.find((p) => String(p.name || '').toLowerCase() === String(target || '').toLowerCase());
    if (!hit) { toast('No participant with that name', 'error'); return; }
    hostAction('spotlight', hit.employee_id);
    state.spotlightId = hit.employee_id;
    state.view = 'spotlight';
    refresh().catch(() => {});
  }

  /* ------------------------------------------------------ recording ---- */
  function pickRecorderMime() {
    const options = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    return options.find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || 'video/webm';
  }

  async function toggleRecording() {
    if (state.recording) { stopRecording(); return; }
    if (!window.MediaRecorder) { toast('This browser cannot record meetings', 'error'); return; }
    if (!state.isHost) { toast('Only the host can record this meeting', 'error'); return; }
    try {
      const tracks = [];
      if (state.localStream) state.localStream.getTracks().forEach((t) => tracks.push(t));
      if (state.screenStream) state.screenStream.getVideoTracks().forEach((t) => tracks.push(t));
      Object.keys(state.peers).forEach((k) => {
        const s = state.peers[k].stream;
        if (s) s.getAudioTracks().forEach((t) => tracks.push(t));
      });
      // On the SFU everyone else's audio arrives in state.sfuStreams.
      Object.keys(state.sfuStreams).forEach((k) => {
        const s = state.sfuStreams[k];
        if (s) s.getAudioTracks().forEach((t) => tracks.push(t));
      });
      const mixed = new MediaStream(tracks);
      state.chunks = [];
      state.recorder = new MediaRecorder(mixed, { mimeType: pickRecorderMime() });
      state.recorder.ondataavailable = (ev) => { if (ev.data && ev.data.size) state.chunks.push(ev.data); };
      state.recorder.onstop = uploadRecording;
      state.recorder.start(1000);
      state.recording = true;
      renderToolbar(state.meeting || {});
      $('#mtg-pill-rec').hidden = false;
      toast('Recording started');
    } catch (err) { toast(err.message || 'Could not start recording', 'error'); }
  }

  function stopRecording() {
    if (!state.recorder) return;
    try { state.recorder.stop(); } catch (e) { /* already stopped */ }
    state.recording = false;
    renderToolbar(state.meeting || {});
    $('#mtg-pill-rec').hidden = true;
  }

  function uploadRecording() {
    const blob = new Blob(state.chunks, { type: 'video/webm' });
    state.chunks = [];
    if (!blob.size) { toast('Recording was empty', 'error'); return; }
    // Saved locally first so nothing is lost if the upload fails.
    try {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'meeting-' + state.meetingId + '-' + new Date().toISOString().replace(/[:.]/g, '-') + '.webm';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 8000);
    } catch (e) { /* download blocked */ }
    const reader = new FileReader();
    reader.onload = () => {
      POST('/api/voic3/meetings/' + state.meetingId + '/recording', { data: reader.result })
        .then(() => toast('Recording saved and posted to the meeting chat'))
        .catch((err) => toast('Recording kept on this device; upload failed: ' + (err.message || ''), 'error'));
    };
    reader.readAsDataURL(blob);
  }

  /* --------------------------------------------- chat + whiteboard ---- */
  function openSide(tab) {
    const el = root();
    let side = el.querySelector('.mtg-side');
    if (side) { side.remove(); }
    const backdrop = document.createElement('div');
    backdrop.className = 'mtg-panel-backdrop';
    backdrop.onclick = closeSide;
    el.appendChild(backdrop);
    side = document.createElement('aside');
    side.className = 'mtg-side';
    side.innerHTML =
      '<div class="mtg-side-head"><b>' + (tab === 'board' ? 'Shared whiteboard' : 'Meeting chat') + '</b>' +
      '<button type="button" class="mtg-tool" data-mtg="side-close">Close</button></div>' +
      '<div class="mtg-tabs"><button type="button" data-mtg="side-chat" class="' + (tab === 'chat' ? 'active' : '') + '">Chat</button>' +
      '<button type="button" data-mtg="side-board" class="' + (tab === 'board' ? 'active' : '') + '">Whiteboard</button></div>' +
      (tab === 'board'
        ? '<div class="mtg-board-wrap"><div class="mtg-board-tools">' +
          '<input type="color" id="mtg-board-color" value="' + state.whiteboard.color + '">' +
          '<input type="range" id="mtg-board-size" min="1" max="12" value="' + state.whiteboard.size + '">' +
          '<button type="button" class="mtg-tool" data-mtg="board-clear">Clear</button>' +
          '<span class="mtg-note">Strokes sync to everyone in the room.</span></div>' +
          '<canvas class="mtg-board" id="mtg-board"></canvas></div>'
        : '<div class="mtg-chat-list" id="mtg-chat-list"><div class="mtg-note">Loading messages…</div></div>' +
          '<form class="mtg-chat-form" id="mtg-chat-form"><input id="mtg-chat-input" placeholder="Message the meeting…" autocomplete="off">' +
          '<button type="submit" class="mtg-tool on">Send</button></form>');
    el.appendChild(side);
    if (tab === 'board') setupBoard();
    else loadChat();
  }

  function closeSide() {
    const el = root();
    const side = el.querySelector('.mtg-side');
    if (side) side.remove();
    const backdrop = el.querySelector('.mtg-panel-backdrop');
    if (backdrop) backdrop.remove();
  }

  function conversationId() {
    return state.meeting && (state.meeting.conversation_id || state.meeting.conversationId);
  }

  async function loadChat() {
    const list = $('#mtg-chat-list');
    if (!list) return;
    const cid = conversationId();
    if (!cid) { list.innerHTML = '<div class="mtg-note">This meeting has no chat conversation.</div>'; return; }
    try {
      const data = await API('/api/voic3/conversations/' + cid + '/messages');
      const items = data.items || [];
      list.innerHTML = items.length
        ? items.map((m) => '<div class="mtg-msg' + (m.is_me ? ' mine' : '') + '">' +
            '<small>' + esc(m.sender || '') + ' · ' + esc(String(m.created_at || '').slice(11, 16)) + '</small>' +
            esc(m.body || '') + '</div>').join('')
        : '<div class="mtg-note">No messages yet.</div>';
      list.scrollTop = list.scrollHeight;
    } catch (err) {
      list.innerHTML = '<div class="mtg-note">' + esc(err.message || 'Chat unavailable') + '</div>';
    }
  }

  async function sendChat(text) {
    const cid = conversationId();
    const body = String(text || '').trim();
    if (!cid || !body) return;
    const payload = { body: body, idempotency_key: (window.Voic3Outbox ? Voic3Outbox.uuid() : String(Date.now())) };
    try {
      if (window.Voic3Outbox && navigator.onLine === false) {
        await Voic3Outbox.enqueue({ kind: 'message', method: 'POST',
          url: '/api/voic3/conversations/' + cid + '/messages', body: payload });
        toast('Queued — it will send when you are back online');
      } else {
        await POST('/api/voic3/conversations/' + cid + '/messages', payload);
      }
      loadChat();
    } catch (err) { toast(err.message || 'Message not sent', 'error'); }
  }

  /* ------------------------------------------------------ whiteboard ---- */
  function setupBoard() {
    const canvas = $('#mtg-board');
    if (!canvas) return;
    const color = $('#mtg-board-color');
    const size = $('#mtg-board-size');
    color.oninput = () => { state.whiteboard.color = color.value; };
    size.oninput = () => { state.whiteboard.size = Number(size.value); };
    const fit = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
      const ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      redrawBoard();
    };
    window.addEventListener('resize', fit);
    fit();

    const pos = (ev) => {
      const rect = canvas.getBoundingClientRect();
      const point = ev.touches ? ev.touches[0] : ev;
      return { x: point.clientX - rect.left, y: point.clientY - rect.top };
    };
    const start = (ev) => {
      ev.preventDefault();
      state.whiteboard.drawing = true;
      state.whiteboard.last = pos(ev);
    };
    const move = (ev) => {
      if (!state.whiteboard.drawing) return;
      ev.preventDefault();
      const p = pos(ev);
      const stroke = { color: state.whiteboard.color, size: state.whiteboard.size,
        from: state.whiteboard.last, to: p };
      state.whiteboard.strokes.push(stroke);
      state.whiteboard.last = p;
      drawStroke(canvas.getContext('2d'), stroke);
      broadcastBoard({ type: 'stroke', stroke: stroke });
    };
    const end = () => { state.whiteboard.drawing = false; state.whiteboard.last = null; };
    canvas.addEventListener('mousedown', start);
    canvas.addEventListener('mousemove', move);
    window.addEventListener('mouseup', end);
    canvas.addEventListener('touchstart', start, { passive: false });
    canvas.addEventListener('touchmove', move, { passive: false });
    canvas.addEventListener('touchend', end);
  }

  function drawStroke(ctx, stroke) {
    if (!ctx || !stroke || !stroke.from || !stroke.to) return;
    ctx.strokeStyle = stroke.color || '#111827';
    ctx.lineWidth = stroke.size || 3;
    ctx.beginPath();
    ctx.moveTo(stroke.from.x, stroke.from.y);
    ctx.lineTo(stroke.to.x, stroke.to.y);
    ctx.stroke();
  }

  function redrawBoard() {
    const canvas = $('#mtg-board');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    state.whiteboard.strokes.forEach((s) => drawStroke(ctx, s));
  }

  function broadcastBoard(message) {
    Object.keys(state.peers).forEach((key) => {
      const ch = state.peers[key].channel;
      if (ch && ch.readyState === 'open') { try { ch.send(JSON.stringify(message)); } catch (e) { /* closed */ } }
    });
    if (window.Voic3Sfu && state.transport === 'sfu') Voic3Sfu.sendData(message);
  }

  function applyBoardMessage(message) {
    if (!message) return;
    if (message.type === 'stroke' && message.stroke) {
      state.whiteboard.strokes.push(message.stroke);
      const canvas = $('#mtg-board');
      if (canvas) drawStroke(canvas.getContext('2d'), message.stroke);
    } else if (message.type === 'clear') {
      state.whiteboard.strokes = [];
      redrawBoard();
    } else if (message.type === 'sync' && Array.isArray(message.strokes)) {
      state.whiteboard.strokes = message.strokes;
      redrawBoard();
    }
  }

  /* --------------------------------------------------- peer mesh ---- */
  async function connectPeer(employeeId) {
    if (!state.meetingId || !state.localStream) return null;
    if (state.peers[employeeId]) return state.peers[employeeId];
    const servers = await API('/api/voic3/ice-config').then((d) => d.iceServers || []).catch(() => []);
    const pc = new RTCPeerConnection({ iceServers: servers });
    const entry = { pc: pc, channel: null, stream: new MediaStream() };
    state.peers[employeeId] = entry;
    state.localStream.getTracks().forEach((t) => pc.addTrack(t, state.localStream));
    pc.ontrack = (ev) => {
      ev.streams[0].getTracks().forEach((t) => entry.stream.addTrack(t));
      refreshTiles();
    };
    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        POST('/api/voic3/meetings/' + state.meetingId + '/signal',
          { kind: 'ice', target: employeeId, payload: JSON.stringify(ev.candidate) }).catch(() => {});
      }
    };
    const channel = pc.createDataChannel('whiteboard');
    entry.channel = channel;
    channel.onmessage = (ev) => {
      try { applyBoardMessage(JSON.parse(ev.data)); } catch (e) { /* ignore */ }
    };
    channel.onopen = () => {
      try { channel.send(JSON.stringify({ type: 'sync', strokes: state.whiteboard.strokes })); } catch (e) { /* ignore */ }
    };
    try { if (window.Voic3NetQuality) Voic3NetQuality.watch(pc); } catch (e) { /* optional */ }
    return entry;
  }

  /* -------------------------------------------------------- events ---- */
  function connectEvents() {
    if (state.sse) return;
    try {
      state.sse = new EventSource('/api/voic3/events', { withCredentials: true });
    } catch (e) { return; }
    const on = (name, handler) => state.sse.addEventListener(name, (ev) => {
      let data = {};
      try { data = JSON.parse(ev.data); } catch (e) { return; }
      if (data.meeting_id && Number(data.meeting_id) !== Number(state.meetingId)) return;
      handler(data);
    });
    on('meeting.join', () => refresh().catch(() => {}));
    on('meeting.admitted', () => {
      toast('You have been admitted');
      // Media was never started in the waiting room: open it now.
      if (!state.localStream) {
        openLocalMedia(state.camOn, state.micOn).then(() => connectSfu()).catch(() => {});
      } else {
        connectSfu();
      }
      refresh().catch(() => {});
    });
    on('meeting.hand', (d) => {
      const p = ((state.meeting && state.meeting.participants) || []).find((x) => Number(x.employee_id) === Number(d.employee_id));
      if (p) { p.hand_raised = d.raised ? 1 : 0; renderStage(((state.meeting.participants) || []).filter((x) => x.state === 'admitted'), state.meeting || {}); }
    });
    on('meeting.emoji', (d) => { if (d.emoji) floatReaction(d.emoji, false); });
    on('meeting.action', (d) => {
      if (d.action === 'end_for_all') { toast('The host ended the meeting'); close(); return; }
      refresh().catch(() => {});
    });
    on('meeting.signal', (d) => { handleSignal(d).catch(() => {}); });
    on('meeting.recording', () => { toast('A recording was posted to the meeting chat'); if ($('#mtg-chat-list')) loadChat(); });
    state.sse.onerror = () => {
      try { state.sse.close(); } catch (e) { /* ignore */ }
      state.sse = null;
      setTimeout(() => { if (state.meetingId) connectEvents(); }, 3000);
    };
  }

  /* -------------------------------------------------------- clicks ---- */
  function onRootClick(event) {
    const btn = event.target.closest('[data-mtg]');
    if (!btn) return;
    const what = btn.getAttribute('data-mtg');
    event.preventDefault();
    switch (what) {
      case 'close': close(); break;
      case 'mic': toggleMic(); break;
      case 'cam': toggleCam(); break;
      case 'screen': toggleScreen(); break;
      case 'hand': toggleHand(); break;
      case 'record': toggleRecording(); break;
      case 'react': sendReaction(btn.getAttribute('data-emoji')); break;
      case 'layout':
        state.view = state.view === 'grid' ? 'spotlight' : 'grid';
        btn.textContent = state.view === 'grid' ? 'Grid' : 'Spotlight';
        refresh().catch(() => {});
        break;
      case 'host': hostAction(btn.getAttribute('data-action')); break;
      case 'admit': admit(Number(btn.getAttribute('data-id'))); break;
      case 'reject': reject(Number(btn.getAttribute('data-id'))); break;
      case 'admit-all': admitAll(); break;
      case 'spotlight': spotlight(); break;
      case 'side-chat': openSide('chat'); break;
      case 'side-board': openSide('board'); break;
      case 'side-close': closeSide(); break;
      case 'board-clear':
        state.whiteboard.strokes = [];
        redrawBoard();
        broadcastBoard({ type: 'clear' });
        break;
      default: break;
    }
  }

  document.addEventListener('submit', (event) => {
    if (event.target && event.target.id === 'mtg-chat-form') {
      event.preventDefault();
      const input = document.getElementById('mtg-chat-input');
      const text = input && input.value;
      if (input) input.value = '';
      sendChat(text);
    }
  });

  /* ----------------------------------------------------- lifecycle ---- */
  async function open(meetingId) {
    try {
      const meeting = await API('/api/voic3/meetings/' + meetingId);
      state.meetingId = meeting.id;
      state.meeting = meeting;
      state.isHost = !!meeting.is_host;
      root().classList.add('open');
      $('#mtg-title').textContent = meeting.title || 'Meeting';
      if ((meeting.me || {}).state === 'waiting' && !meeting.is_host) {
        showWaitingRoom(meeting);
        connectEvents();
        startPolling();
        return meeting;
      }
      await showLobby(meeting);
      return meeting;
    } catch (err) {
      toast(err.message || 'Could not open the meeting', 'error');
      return null;
    }
  }

  function close() {
    stopPolling();
    if (state.recording) stopRecording();
    if (state.sse) { try { state.sse.close(); } catch (e) { /* ignore */ } state.sse = null; }
    Object.keys(state.peers).forEach((k) => {
      const p = state.peers[k];
      try { p.channel && p.channel.close(); } catch (e) { /* ignore */ }
      try { p.pc.close(); } catch (e) { /* ignore */ }
    });
    state.peers = {};
    if (state.localStream) state.localStream.getTracks().forEach((t) => t.stop());
    if (state.screenStream) state.screenStream.getTracks().forEach((t) => t.stop());
    state.localStream = null;
    state.screenStream = null;
    if (window.Voic3Sfu) Voic3Sfu.leave().catch(() => {});
    if (window.Voic3NetQuality) Voic3NetQuality.stop();
    // There is no dedicated leave route; 'kick' is host-only, so a participant
    // simply closes their media and lets the poll show them as gone.
    state.meetingId = null;
    state.meeting = null;
    state.analysers = {};
    state.speaking = null;
    state.sfuStreams = {};
    state.sfuIdentity = '';
    state.transport = 'p2p';
    const el = document.getElementById('voic3-meeting-root');
    if (el) { el.classList.remove('open'); el.innerHTML = ''; }
  }

  /* ----------------------------------------------------- meeting list ---- */
  /* Rendered inside the VOIC3 page (and the mobile meetings view) so people
     can start a meeting and open an existing one without leaving the app. */
  async function list() {
    const box = document.getElementById('mtg-list');
    if (!box) return;
    try {
      const data = await API('/api/voic3/meetings');
      const items = data.items || [];
      box.innerHTML =
        '<div class="mtg-list-head"><b>Meetings</b><span class="mtg-spacer"></span>' +
        '<button type="button" class="mtg-tool on" data-mtg="new-meeting">New meeting</button></div>' +
        (items.length
          ? '<div class="mtg-grid">' + items.map((m) =>
              '<div class="mtg-card"><div><b>' + esc(m.title) + '</b>' +
              '<div class="mtg-code">' + esc(m.code) + (m.is_host ? ' · you host' : '') + '</div></div>' +
              '<div class="mtg-row"><span class="mtg-pill' + (m.status === 'live' ? ' live' : '') + '">' +
              esc(m.status || 'scheduled') + '</span><span class="mtg-spacer"></span>' +
              '<button type="button" class="mtg-tool on" data-mtg="open-meeting" data-id="' + m.id + '">' +
              (m.status === 'live' ? 'Join' : 'Open') + '</button></div></div>').join('') + '</div>'
          : '<div class="mtg-note">No meetings yet — start one above.</div>');
    } catch (err) {
      box.innerHTML = '<div class="mtg-note">' + esc(err.message || 'Meetings unavailable') + '</div>';
    }
  }

  document.addEventListener('click', async (event) => {
    const btn = event.target.closest && event.target.closest('#mtg-list [data-mtg]');
    if (!btn) return;
    event.preventDefault();
    const what = btn.getAttribute('data-mtg');
    if (what === 'open-meeting') {
      open(Number(btn.getAttribute('data-id')));
    } else if (what === 'new-meeting') {
      const title = prompt('Meeting title', 'Team meeting');
      if (!title) return;
      try {
        const created = await POST('/api/voic3/meetings', { title: title, waiting_room_enabled: true });
        await list();
        open(created.id);
      } catch (err) { toast(err.message || 'Could not create the meeting', 'error'); }
    }
  });

  window.Voic3Meetings = { open: open, close: close, list: list, state: state };
  document.addEventListener('DOMContentLoaded', () => { if (document.getElementById('mtg-list')) list(); });
})();
