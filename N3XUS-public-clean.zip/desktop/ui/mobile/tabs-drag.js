/* BR Connect — bottom tab bar.
 *
 * Makes the mobile navigation drag-and-writable: press and hold a tab, then move
 * it where you want it. The order is remembered on the device, per profile, so an
 * owner and a staff member can each have their own arrangement. Permissions are
 * untouched: this only changes the order of tabs a person can already see.
 *
 * No libraries, no network, no storage your-userd localStorage on the phone.
 */
(function () {
  'use strict';

  var HOLD_MS = 220;
  var MOVE_CANCEL_PX = 8;
  var STORE_PREFIX = 'br_tab_order:';

  function storageKey() {
    var who = 'guest';
    try {
      var e = window.employeeAccount || window.employee || null;
      if (e && e.employee_no) who = String(e.employee_no);
      else if (e && e.id) who = 'id' + e.id;
      else {
        var cached = localStorage.getItem('br_profile') || localStorage.getItem('br_role');
        if (cached) who = cached;
      }
    } catch (err) { /* storage disabled: fall back to guest */ }
    return STORE_PREFIX + who;
  }

  function readOrder() {
    try {
      var raw = localStorage.getItem(storageKey());
      var parsed = raw ? JSON.parse(raw) : null;
      return Array.isArray(parsed) ? parsed.filter(function (x) { return typeof x === 'string'; }) : [];
    } catch (err) { return []; }
  }

  function writeOrder(list) {
    try { localStorage.setItem(storageKey(), JSON.stringify(list)); } catch (err) { /* ignore */ }
  }

  function tabKey(button) {
    return button && (button.dataset.tab || button.getAttribute('data-tab')) || '';
  }

  /* Reorder the existing buttons to the saved order, keeping any new tabs
     where the app put them (at the end) so a permission change is never lost. */
  function applySavedOrder(nav) {
    if (!nav || nav.dataset.brOrdered === '1') return;
    var saved = readOrder();
    if (!saved.length) { nav.dataset.brOrdered = '1'; return; }
    var track = nav.querySelector('.nav-track');
    if (!track) return;
    var buttons = Array.prototype.slice.call(track.querySelectorAll('button[data-tab]'));
    var rank = {};
    saved.forEach(function (key, index) { rank[key] = index; });
    buttons.sort(function (a, b) {
      var ka = tabKey(a), kb = tabKey(b);
      var ra = ka in rank ? rank[ka] : 9999;
      var rb = kb in rank ? rank[kb] : 9999;
      if (ra !== rb) return ra - rb;
      return buttons.indexOf(a) - buttons.indexOf(b);
    });
    buttons.forEach(function (button) { track.appendChild(button); });
    nav.dataset.brOrdered = '1';
  }

  function saveCurrentOrder(nav) {
    var keys = Array.prototype.slice.call(nav.querySelectorAll('.nav-track button[data-tab]')).map(tabKey).filter(Boolean);
    writeOrder(keys);
  }

  function clearHoldTimer(state) {
    if (state.timer) { clearTimeout(state.timer); state.timer = null; }
  }

  function beginDrag(state, button, event) {
    state.active = true;
    state.button = button;
    button.classList.add('br-dragging');
    button.setAttribute('aria-grabbed', 'true');
    try { navigator.vibrate && navigator.vibrate(12); } catch (err) { /* not supported */ }
    var rect = button.getBoundingClientRect();
    state.offsetX = event.clientX - rect.left;
    state.offsetY = event.clientY - rect.top;
    button.style.width = rect.width + 'px';
    button.style.height = rect.height + 'px';
    button.style.position = 'fixed';
    button.style.left = rect.left + 'px';
    button.style.top = rect.top + 'px';
    button.style.zIndex = '60';
    button.style.pointerEvents = 'none';
    state.nav.classList.add('br-reordering');
  }

  function moveDrag(state, event) {
    var button = state.button;
    if (!button) return;
    button.style.left = (event.clientX - state.offsetX) + 'px';
    button.style.top = (event.clientY - state.offsetY) + 'px';

    var track = state.nav.querySelector('.nav-track') || state.nav;
    var siblings = Array.prototype.slice.call(track.querySelectorAll('button[data-tab]'))
      .filter(function (b) { return b !== button; });
    var target = null;
    for (var i = 0; i < siblings.length; i++) {
      var box = siblings[i].getBoundingClientRect();
      if (event.clientX < box.left + box.width / 2) { target = siblings[i]; break; }
    }
    if (target && target.parentNode === track) track.insertBefore(button, target);
    else if (button.parentNode !== track) track.appendChild(button);
  }

  function endDrag(state) {
    var button = state.button;
    if (button) {
      /* Put the button back in the flow where it now sits. */
      var placeholder = document.createElement('span');
      placeholder.style.display = 'none';
      button.parentNode && button.parentNode.insertBefore(placeholder, button);
      button.style.cssText = '';
      button.classList.remove('br-dragging');
      button.removeAttribute('aria-grabbed');
      placeholder.parentNode && placeholder.parentNode.removeChild(placeholder);
      saveCurrentOrder(state.nav);
    }
    state.nav.classList.remove('br-reordering');
    state.active = false;
    state.button = null;
    clearHoldTimer(state);
  }

  var state = { nav: null, timer: null, active: false, button: null, startX: 0, startY: 0, offsetX: 0, offsetY: 0 };

  /* Listen on the document once: the app re-renders the bar on every screen
     change, which would drop listeners attached to the old element. */
  function listen() {
    if (document.body && document.body.dataset.brWritableBound === '1') return;
    window.addEventListener('pointerdown', function (event) {
      var el = document.elementFromPoint(event.clientX, event.clientY) || event.target;
      var nav = el.closest && el.closest('.nav');
      if (!nav) return;
      var button = el.closest('button[data-tab]');
      if (!button) return;
      var rect = button.getBoundingClientRect();
      if (rect.width < 20 || rect.height < 20) return;   /* placeholder tab */
      state.nav = nav;
      state.startX = event.clientX;
      state.startY = event.clientY;
      state.armed = button;
      clearHoldTimer(state);
      state.timer = setTimeout(function () {
        var dx = Math.abs((event.clientX || state.startX) - state.startX);
        var dy = Math.abs((event.clientY || state.startY) - state.startY);
        if (dx < MOVE_CANCEL_PX && dy < MOVE_CANCEL_PX) beginDrag(state, button, event);
      }, HOLD_MS);
    }, { passive: true, capture: true });

    window.addEventListener('pointermove', function (event) {
      if (state.active) {
        event.preventDefault();
        moveDrag(state, event);
        return;
      }
      /* Moving before the hold completes means it is a scroll or a tap. */
      if (state.armed) {
        var dx = Math.abs(event.clientX - state.startX);
        var dy = Math.abs(event.clientY - state.startY);
        if (dx > MOVE_CANCEL_PX || dy > MOVE_CANCEL_PX) {
          clearHoldTimer(state);
          state.armed = null;
        }
      }
    }, { passive: false, capture: true });

    ['pointerup', 'pointercancel'].forEach(function (name) {
      window.addEventListener(name, function () {
        clearHoldTimer(state);
        state.armed = null;
        if (state.active) endDrag(state);
      });
    });

    /* While dragging, a normal click must not switch tabs underneath. */
    document.addEventListener('click', function (event) {
      if (state.active || (state.nav && state.nav.classList.contains('br-reordering'))) {
        event.preventDefault();
        event.stopPropagation();
      }
    }, true);

    /* Right-click / long-press context menu would interrupt a drag. */
    document.addEventListener('contextmenu', function (event) {
      if (state.active) event.preventDefault();
    });
    if (document.body) document.body.dataset.brWritableBound = '1';
  }

  /* The bar itself is fixed and transformed, which makes scrollWidth lie.
     A plain inner track scrolls correctly. */
  function ensureTrack(nav) {
    if (!nav) return null;
    var track = nav.querySelector('.nav-track');
    if (!track) {
      track = document.createElement('div');
      track.className = 'nav-track';
      while (nav.firstChild) track.appendChild(nav.firstChild);
      nav.appendChild(track);
    }
    return track;
  }

  function collapseHidden(nav) {
    var track = nav && nav.querySelector('.nav-track');
    if (!track) return;
    Array.prototype.forEach.call(track.querySelectorAll('button[data-tab]'), function (button) {
      var hidden = button.getAttribute('style') || '';
      if (hidden.indexOf('display: none') >= 0 || hidden.indexOf('display:none') >= 0) {
        button.classList.add('br-tab-hidden');
        button.style.flex = '0 0 0';
        button.style.width = '0';
        button.style.minWidth = '0';
        button.style.maxWidth = '0';
        button.style.padding = '0';
        button.style.opacity = '0';
        button.style.pointerEvents = 'none';
        button.style.overflow = 'hidden';
      } else if (button.classList.contains('br-tab-hidden')) {
        // A tab can become allowed again (a different role signed in on this
        // phone), so put back everything the hide above took away.
        button.classList.remove('br-tab-hidden');
        ['flex', 'width', 'minWidth', 'maxWidth', 'padding', 'opacity',
         'pointerEvents', 'overflow'].forEach(function (prop) {
          button.style[prop] = '';
        });
      }
    });
  }

  function attach(nav) {
    if (!nav) return;
    ensureTrack(nav);
    collapseHidden(nav);
    applySavedOrder(nav);
    flagOverflow(nav);
  }

  /* Tell the bar to show its "continues" hint, and bring the active tab in. */
  function flagOverflow(nav) {
    if (!nav) return;
    var track = nav.querySelector('.nav-track');
    nav.classList.toggle('br-overflow', !!track && track.scrollWidth > track.clientWidth + 2);
    var active = nav.querySelector('.nav-track button.active');
    if (active && active.scrollIntoView && !nav.classList.contains('br-reordering')) {
      try { active.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' }); }
      catch (err) { /* older webview */ }
    }
  }

  /* Keep the arrangement across re-renders: the app rebuilds the bar often. */
  function watch() {
    listen();
    attach(document.querySelector('.nav'));
    var observer = new MutationObserver(function () {
      var nav = document.querySelector('.nav');
      if (!nav) return;
      var fresh = !nav.querySelector('.nav-track');
      ensureTrack(nav);
      collapseHidden(nav);
      if (fresh || nav.dataset.brOrdered !== '1') applySavedOrder(nav);
      flagOverflow(nav);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function resetOrder() {
    try { localStorage.removeItem(storageKey()); } catch (err) { /* ignore */ }
    var nav = document.querySelector('.nav');
    if (nav) nav.dataset.brOrdered = '';
    if (nav) applySavedOrder(nav);
  }

  window.Voic3Tabs = {
    attach: attach,
    reset: resetOrder,
    currentOrder: function () {
      var nav = document.querySelector('.nav');
      if (!nav) return [];
      return Array.prototype.slice.call(nav.querySelectorAll('.nav-track button[data-tab]')).map(tabKey);
    },
    // Called after the role filter hides tabs, so the strip re-measures.
    collapseHidden: function () {
      var nav = document.querySelector('.nav');
      if (nav) collapseHidden(nav);
    },
    overflow: function () {
      var nav = document.querySelector('.nav');
      var track = nav && nav.querySelector('.nav-track');
      if (!track) return null;
      return { scrollable: track.scrollWidth > track.clientWidth + 2,
               scrollWidth: track.scrollWidth, clientWidth: track.clientWidth };
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', watch);
  } else {
    watch();
  }
})();
