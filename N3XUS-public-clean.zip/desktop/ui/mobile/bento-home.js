/* ============================================================================
   N3XUS · the Bento home screen
   ----------------------------------------------------------------------------
   The home tab, rebuilt as a modular Bento grid on the warm cream canvas:
   a greeting tile, coloured stat tiles, a two-column "what do you need" grid
   with a small action button in each tile, and recent activity.

   It reuses the data the app already loads (/api/mobile/dashboard) and calls
   the same screens the old home screen did, so nothing about permissions,
   accounts or data changes — only how the home screen looks.
   ========================================================================== */
(function () {
  'use strict';

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function num(v, dp) {
    var n = Number(v);
    return isNaN(n) ? '0' : n.toFixed(dp == null ? 1 : dp);
  }

  function icon(name, size) {
    if (typeof window.mi === 'function') {
      return window.mi(name).replace('width="18" height="18"', 'width="' + (size || 22) + '" height="' + (size || 22) + '"');
    }
    return '';
  }

  function pill(status) {
    var s = String(status || '');
    var cls = /approv|paid|sent/i.test(s) ? 'green' : /pend|review|await/i.test(s) ? 'orange'
      : /reject|declin/i.test(s) ? 'red' : '';
    return '<span class="pill ' + cls + '">' + esc(s) + '</span>';
  }

  function who() {
    try { return window.employee || null; } catch (e) { return null; }
  }

  function firstName() {
    var e = who();
    var n = (e && (e.name || '')) || '';
    return n.split(/\s+/)[0] || 'there';
  }

  function greeting() {
    var h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  function tile(accent, iconName, title, blurb, action, goTab) {
    return '<div class="card ' + accent + '">' +
      '<div class="v3-head" style="margin:0 0 8px">' +
      '<span style="display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:rgba(255,255,255,.72)">' +
      icon(iconName, 20) + '</span></div>' +
      '<h3>' + esc(title) + '</h3>' +
      '<p style="margin:0 0 12px">' + esc(blurb) + '</p>' +
      '<button class="btn" style="min-height:38px;padding:9px 14px;font-size:12px;background:rgba(30,36,43,.86)" ' +
      'data-go="' + esc(goTab) + '">' + esc(action) + '</button></div>';
  }

  function renderHome() {
    var host = document.getElementById('app');
    if (!host) return;
    fetch('/api/mobile/dashboard', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var e = who() || {};
        var balances = d.balances || [];
        var totalDays = balances.reduce(function (a, b) { return a + Number(b.available_days || 0); }, 0);
        var payslips = d.payslips || [];
        var latest = payslips[0];
        var leave = d.recent_leave || [];
        var pending = leave.filter(function (l) { return /pend/i.test(String(l.status)); }).length;

        var body =
          /* greeting */
          '<div class="card wide" style="background:linear-gradient(150deg,#FFFFFF 0%,#FBF6EE 100%);padding:18px">' +
          '<div class="hello" style="margin-bottom:4px">' + esc(greeting().toUpperCase()) + '</div>' +
          '<div style="font-size:23px;font-weight:780;letter-spacing:-.4px;color:var(--ink)">' +
          esc(firstName()) + '</div>' +
          '<div class="sub" style="margin-top:2px">' +
          esc([e.employee_no, e.job_title || e.department].filter(Boolean).join(' · ') || 'Employee self-service') +
          '</div></div>' +

          /* stat tiles */
          '<div class="grid" style="margin-top:var(--gap)">' +
          '<div class="card emerald"><div class="muted">Leave available</div>' +
          '<div class="metric">' + num(totalDays) + '</div>' +
          '<div class="muted">days across ' + balances.length + (balances.length === 1 ? ' type' : ' types') + '</div></div>' +

          '<div class="card sky"><div class="muted">Latest payslip</div>' +
          '<div class="metric" style="font-size:22px">' +
          (latest ? 'R ' + Number(latest.net_pay || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—') +
          '</div><div class="muted">' + esc(latest ? latest.pay_period : 'No payslip yet') + '</div></div>' +

          '<div class="card violet"><div class="muted">Leave requests</div>' +
          '<div class="metric">' + leave.length + '</div>' +
          '<div class="muted">' + pending + ' awaiting approval</div></div>' +

          '<div class="card amber"><div class="muted">Documents</div>' +
          '<div class="metric">' + Number(d.document_count || 0) + '</div>' +
          '<div class="muted">in your vault</div></div>' +
          '</div>' +

          /* what do you need */
          '<div class="section-title"><h2>What do you need?</h2></div>' +
          '<div class="grid" style="margin-top:0">' +
          tile('emerald', 'calendar', 'Take leave', 'Apply and follow every request.', 'Request leave', 'leave') +
          tile('sky', 'wallet', 'Payslips', 'View and download your pay slips.', 'Open payslips', 'payslips') +
          tile('violet', 'folder', 'Document vault', 'Upload and find your documents.', 'Open vault', 'vault') +
          tile('amber', 'eye', 'Image report', 'Report a fault with a photograph.', 'New report', 'report') +
          '</div>' +

          /* recent activity */
          '<div class="section-title"><h2>Recent leave</h2>' +
          '<button class="ghost" data-go="leave" style="min-height:36px;padding:8px 12px;font-size:12px">View all</button></div>' +
          '<div class="list">' +
          (leave.length ? leave.slice(0, 3).map(function (l) {
            return '<div class="item"><div><b>' + esc(l.leave_type) + '</b>' +
              '<small>' + esc(l.date_from) + ' → ' + esc(l.date_to) + ' · ' + num(l.days, 0) + ' days</small></div>' +
              pill(l.status) + '</div>';
          }).join('') : '<div class="empty">No leave applications yet.</div>') +
          '</div>' +

          '<div class="section-title"><h2>Recent payslips</h2>' +
          '<button class="ghost" data-go="payslips" style="min-height:36px;padding:8px 12px;font-size:12px">View all</button></div>' +
          '<div class="list">' +
          (payslips.length ? payslips.map(function (p) {
            return '<div class="item"><div><b>' + esc(p.pay_period) + '</b>' +
              '<small>Net pay · R ' + Number(p.net_pay || 0).toFixed(2) + '</small></div>' + pill(p.status) + '</div>';
          }).join('') : '<div class="empty">No approved payslips are available.</div>') +
          '</div>';

        if (typeof window.shell === 'function') window.shell(body);
        else host.innerHTML = '<main class="content">' + body + '</main>';

        // Tiles and "view all" buttons open the screens that already exist.
        Array.prototype.forEach.call(host.querySelectorAll('[data-go]'), function (b) {
          b.onclick = function () {
            var target = b.getAttribute('data-go');
            if (typeof window.setMobileTab === 'function') window.setMobileTab(target);
            else if (typeof window.render === 'function') window.render();
          };
        });
      })
      .catch(function (err) {
        if (typeof window.shell === 'function') {
          window.shell('<div class="error">' + esc(err && err.message ? err.message : 'The dashboard could not load.') + '</div>');
        }
      });
  }

  window.N3XUS_BENTO_HOME = renderHome;

  // Open the bento home whenever the home tab is chosen.
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest && e.target.closest('.nav [data-tab="home"]');
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();
    renderHome();
  }, true);
})();
