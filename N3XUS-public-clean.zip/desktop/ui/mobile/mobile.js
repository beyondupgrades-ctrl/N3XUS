/* Permanent discovery address: the tunnel host lives in a DuckDNS TXT record,
   so the server address survives reboots and never has to be typed in. */
window.N3XUS_DISCOVERY='YOUR_DUCKDNS_DOMAIN.duckdns.org';
async function discoverServer(timeoutMs){
  timeoutMs=timeoutMs||6000;
  var ctl=(typeof AbortController==='function')?new AbortController():null;
  var t=setTimeout(function(){if(ctl)ctl.abort()},timeoutMs);
  try{
    var url='https://cloudflare-dns.com/dns-query?name='+encodeURIComponent(window.N3XUS_DISCOVERY)+'&type=TXT';
    var r=await fetch(url,{headers:{Accept:'application/dns-json'},cache:'no-store',signal:ctl?ctl.signal:undefined});
    if(!r.ok)throw new Error('DoH '+r.status);
    var j=await r.json();
    var ans=(j&&j.Answer)||[];
    for(var i=0;i<ans.length;i++){
      var v=ans[i].data||'';
      v=v.replace(/^"|"$/g,'');
      if(/\.trycloudflare\.com$/.test(v))return v;
    }
    throw new Error('No tunnel host in DNS answer');
  } finally { clearTimeout(t); }
}
window.discoverServer=discoverServer;
/* The tab switcher, the back step and the live tab are published on window so
   sibling scripts (VOIC3, the bento layer) can drive the app without guessing at
   the DOM. Module level: they must exist before anything calls them. */
window.setMobileTab=setMobileTab;
window.goMobileTabBack=goMobileTabBack;
window.mobileTab=()=>tab;
const root=document.getElementById('app');let employee=null,tab='home';try{Object.defineProperty(window,'employee',{get:function(){return employee},configurable:true})}catch(e){}const tabHistory=[];let tabHistoryReady=false;function setMobileTab(next,{back=false,renderPage=true}={}){if(!next||next===tab){if(renderPage)render();return}if(!back&&tabHistoryReady){tabHistory.push(tab);try{history.pushState({n3xusTab:next},'','#'+encodeURIComponent(next))}catch{}}if(tab==='patients'&&next!=='patients')stopMobilePatientWalk();tab=next;if(renderPage)render()}function goMobileTabBack(){if(tabHistory.length){tab=tabHistory.pop();if(tab==='patients')stopMobilePatientWalk()}else tab='home';render()}window.addEventListener('popstate',()=>{if(tabHistory.length){tab=tabHistory.pop();if(tab==='patients')stopMobilePatientWalk()}else if(tab!=='home')tab='home';render()});window.addEventListener('hashchange',()=>{const next=decodeURIComponent(location.hash.slice(1)||'home');if(next!==tab)setMobileTab(next,{back:true})});let mobilePatientWalkWatch=null,mobilePatientWalkId=null,mobilePatientWalkBusy=false,mobilePatientWalkLast=0;
try{document.documentElement.dataset.theme=localStorage.getItem('br_theme')==='dark'?'dark':'light'}catch{document.documentElement.dataset.theme='light'}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path,opts={}){const r=await fetch(path,{credentials:'same-origin',cache:'no-store',...opts,headers:{'Content-Type':'application/json','X-Device-Key':localStorage.getItem('br_device_key')||'',...(opts.headers||{})}});let d={};try{d=await r.json()}catch{}if(!r.ok){const e=Error(d.error||`Request failed (${r.status})`);e.status=r.status;throw e}return d}
function toast(msg){let n=document.createElement('div');n.className='toast';n.textContent=msg;document.body.append(n);setTimeout(()=>n.remove(),2800)}
function biometricAvailable(){
  // The phone's own fingerprint or face, through the app, comes first: it is the
  // only one that works here, because the browser's unlock needs a certificate
  // this phone does not trust. The browser's own unlock is the fallback.
  try{if(window.N3XUS_BIO&&window.N3XUS_BIO.available())return true}catch(e){}
  try{return !!(window.PublicKeyCredential&&navigator.credentials&&window.isSecureContext)}catch(e){return false}
}
function biometricKind(){
  try{if(window.N3XUS_BIO&&window.N3XUS_BIO.available())return 'phone'}catch(e){}
  return biometricAvailable()?'browser':'none';
}
function encodeBioSecret(value){
  const bytes=new TextEncoder().encode(String(value));
  let binary='';
  for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return btoa(binary);
}
function decodeBioSecret(value){
  const binary=atob(value);
  const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}
async function biometricCheck(){
  // A device-bound credential: the phone asks for the fingerprint or face it
  // already knows. No service, no key, no cost.
  try{
    if(window.N3XUS_BIO&&window.N3XUS_BIO.available()){
      return !!window.N3XUS_BIO.ask();
    }
  }catch(e){}
  try{
    const challenge=new Uint8Array(32); crypto.getRandomValues(challenge);
    const id=localStorage.getItem('br_bio_id');
    if(id){
      const raw=Uint8Array.from(atob(id),c=>c.charCodeAt(0));
      const assertion=await navigator.credentials.get({publicKey:{challenge,rpId:location.hostname,allowCredentials:[{id:raw,type:'public-key'}],userVerification:'required',timeout:60000}});
      return !!assertion;
    }
    const credential=await navigator.credentials.create({publicKey:{challenge,rp:{id:location.hostname,name:'Beyond Registration'},user:{id:new Uint8Array(16),name:localStorage.getItem('br_last_employee')||'employee',displayName:'N3XUS employee'},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',userVerification:'required'},timeout:60000}});
    if(credential&&credential.rawId) localStorage.setItem('br_bio_id',btoa(String.fromCharCode(...new Uint8Array(credential.rawId))));
    return !!credential;
  }catch(e){
    if(window.N3XUS_BIO&&typeof window.N3XUS_BIO.lastError==='function'){
      try{const detail=window.N3XUS_BIO.lastError();if(detail)throw Error(String(detail))}catch(nativeError){if(nativeError&&nativeError.message)throw nativeError}
    }
    throw e;
  }
}
function auth(error=''){auth.lastMessage=error||'';root.innerHTML=`<main class="auth"><div class="logo"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" aria-hidden="true"><path d="M7 18V6l10 12V6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div class="muted" style="letter-spacing:2px">BEYOND REGISTRATION (PTY) LTD</div><div class="muted" style="font-size:9px;letter-spacing:1px">REG. NO. 2026721121 · AUTONOMOUS GLOBAL ECOSYSTEM</div><h1>Employee sign in</h1><p>Access your leave, payslips and employee documents securely.</p>${error?`<div class="error">${esc(error)}</div>`:''}<form id="login" class="form"><div class="field"><label>Who are you?</label><select name="employee_no" id="who" autocomplete="off" required><option value="">Loading the employee list…</option></select><div class="smallprint" id="who-hint" style="margin-top:6px"></div></div><div class="field"><label>Password</label><div style="display:flex;gap:8px;align-items:stretch"><input name="password" id="pw" type="password" autocomplete="current-password" required minlength="4" placeholder="Your password" style="flex:1"><button type="button" id="show-pw" class="btn secondary" style="white-space:nowrap" aria-pressed="false">Show</button></div></div><button class="btn full" id="signin">Sign in securely</button>${biometricAvailable()?`<button type="button" class="btn secondary full" id="bio" style="margin-top:10px">Use fingerprint or face</button>`:''}</form><div class="smallprint">Mobile access must first be activated by a Beyond Registration administrator.</div></main>`;
  // Show / hide what was typed - for a password typed on a small phone keyboard.
  const pw=document.getElementById('pw'), show=document.getElementById('show-pw');
  show.onclick=()=>{const hidden=pw.type==='password';pw.type=hidden?'text':'password';show.textContent=hidden?'Hide':'Show';show.setAttribute('aria-pressed',hidden?'true':'false');pw.focus()};
  // The name list: pick yourself instead of remembering an employee number.
  const who=document.getElementById('who'), hint=document.getElementById('who-hint');
  api('/api/mobile/people').then(d=>{
    const items=(d&&d.items)||[];
    if(!items.length){who.innerHTML='<option value="">No phone access has been set up yet</option>';hint.textContent='Ask a Beyond Registration administrator to switch on your mobile access.';return}
    who.innerHTML='<option value="">Select your name</option>'+items.map(p=>`<option value="${esc(p.employee_no)}">${esc(p.name)}${p.role?' · '+esc(p.role):''}</option>`).join('');
    hint.textContent=items.length+' '+ (items.length===1?'person can':'people can') +' sign in on a phone. Pick your name, then enter your password.';
  }).catch(()=>{who.innerHTML='<option value="">Could not load the list</option>';hint.textContent='Check the connection and reopen the app.'});
  // Biometric unlock: the phone checks the fingerprint or face, then the saved
  // password is used once. Nothing leaves the phone except the normal sign-in.
  const bio=document.getElementById('bio');
  if(bio)bio.onclick=async()=>{
    try{
      const saved=localStorage.getItem('br_bio_employee')||'';
      if(!saved){toast('Sign in once with your password, then set up fingerprint or face in Settings.');return}
      if(!(await biometricCheck())){toast('Fingerprint or face was cancelled, unavailable, or not recognised. Try again or sign in with your password.');return}
      const secret=localStorage.getItem('br_bio_secret')||'';
      if(!secret){toast('Sign in with your password once to renew fingerprint sign-in.');return}
      let decoded;
      try{decoded=decodeBioSecret(secret)}catch{localStorage.removeItem('br_bio_secret');toast('Saved biometric password data is invalid. Sign in with your password and set up fingerprint or face again.');return}
      await api('/api/mobile/login',{method:'POST',body:JSON.stringify({employee_no:saved,password:decoded})});
      await boot();
    }catch(e){toast(e&&e.message?e.message:'Could not complete biometric sign-in. Sign in with your password and try again.')}
  };
  document.getElementById('login').onsubmit=async e=>{
    e.preventDefault();
    // The banner belongs to THIS attempt only. Clearing it first means an old
    // failure (a 503 from a busy server, a wrong password) can never be shown
    // again as if it just happened, and a successful sign-in wipes it.
    auth.lastMessage='';
    const banner=root.querySelector('.auth .error');
    if(banner)banner.remove();
    const f=new FormData(e.target);
    const chosen=String(f.get('employee_no')||'').trim();
    if(!chosen){toast('Select your name first.');return}
    if(String(f.get('password')||'').length<4){toast('Enter a password of at least 4 characters.');return}
    try{
      await api('/api/mobile/login',{method:'POST',body:JSON.stringify({employee_no:chosen,password:f.get('password')})});
      // Remember only the employee number, never the password, unless the person
      // turns fingerprint sign-in on in Settings.
      try{localStorage.setItem('br_last_employee',chosen)}catch{}
      await boot();
    }catch(err){auth(err.message)}
  };
}
function shell(body){root.innerHTML=`<header class="top">${tabHistory.length||tab!=='home'?'<button type="button" id="mobile-tab-back" class="btn secondary" style="flex:0 0 auto;width:auto;min-height:44px;padding:8px 12px;white-space:nowrap;position:relative;z-index:2" aria-label="Back to previous tab">← Back</button>':''}<div class="brand"><div class="logo"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" aria-hidden="true"><path d="M7 18V6l10 12V6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div><strong>BEYOND REGISTRATION (PTY) LTD</strong><small>REG. NO. 2026721121 · AUTONOMOUS GLOBAL ECOSYSTEM</small></div></div><div class="conn"><i class="dot"></i> Connected</div></header>${window.__appUpdate?`<div class="app-update-bar"><span>App update available (v${esc(window.__appUpdate)})</span><button onclick="location.href='/api/mobile/app-update.apk'">Update</button></div>`:''}<main class="content">${body}</main>`;const backButton=root.querySelector('#mobile-tab-back');if(backButton)backButton.onclick=goMobileTabBack;root.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>setMobileTab(b.dataset.tab));applyRoleTabs()}
function stopMobilePatientWalk(){if(mobilePatientWalkWatch!==null&&navigator.geolocation)navigator.geolocation.clearWatch(mobilePatientWalkWatch);mobilePatientWalkWatch=null;mobilePatientWalkId=null;mobilePatientWalkBusy=false;mobilePatientWalkLast=0}
function mobilePosition(){return new Promise((resolve,reject)=>{if(!navigator.geolocation)return reject(Error('This device does not provide location access.'));navigator.geolocation.getCurrentPosition(p=>resolve({latitude:p.coords.latitude,longitude:p.coords.longitude}),e=>reject(Error(e.code===1?'Location permission was denied. Uncheck location to save without GPS.':'Could not read device location.')),{enableHighAccuracy:true,maximumAge:5000,timeout:15000})})}
function startMobilePatientWalk(patientId,walkId){if(!navigator.geolocation){toast('Live location unavailable; walk logging remains available.');return}stopMobilePatientWalk();mobilePatientWalkId=Number(walkId);mobilePatientWalkWatch=navigator.geolocation.watchPosition(async p=>{if(mobilePatientWalkBusy||Date.now()-mobilePatientWalkLast<30000)return;mobilePatientWalkBusy=true;mobilePatientWalkLast=Date.now();try{await api(`/api/mobile/patients/${patientId}/walks/${walkId}/location`,{method:'POST',body:JSON.stringify({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy??null,battery:await opsBattery(),speed:p.coords.speed??null})})}catch(e){stopMobilePatientWalk();toast(`Live location paused: ${e.message}`)}finally{mobilePatientWalkBusy=false}},e=>{stopMobilePatientWalk();toast(e.code===1?'Location permission was denied; live location stopped.':'Device location interrupted; live location stopped.')},{enableHighAccuracy:true,maximumAge:5000,timeout:20000})}
window.addEventListener('pagehide',stopMobilePatientWalk);
const status=s=>`<span class="pill ${s==='Approved'||s==='Paid'?'green':s==='Pending'?'orange':''}">${esc(s)}</span>`;
async function render(){try{if(tab==='home'){const d=await api('/api/mobile/dashboard');shell(`<div class="hello">WELCOME BACK</div><h1>${esc(employee?.name||'Employee')}</h1><div class="sub">${esc(employee?.employee_no||'')} · ${esc(employee?.job_title||'')}</div><div class="quick"><button data-go="leave"><span class="qicon mi">${mi('calendar')}</span>Request leave</button><button data-go="payslips"><span class="qicon mi">${mi('wallet')}</span>View payslip</button><button data-go="vault"><span class="qicon mi">${mi('folder')}</span>Upload document</button><button data-go="report"><span class="qicon mi">${mi('eye')}</span>Image report</button></div><div class="section-title"><h2>Leave balances</h2></div><div class="grid">${d.balances.length?d.balances.map(x=>`<div class="card"><div class="muted">${esc(x.leave_type)}</div><div class="metric">${Number(x.available_days).toFixed(1)}</div><div class="muted">days available</div></div>`).join(''):'<div class="empty wide">No leave balances have been configured yet.</div>'}</div><div class="section-title"><h2>Recent leave activity</h2><button class="ghost" data-go="leave">View all</button></div><div class="list">${d.recent_leave.length?d.recent_leave.map(x=>`<div class="item"><div><b>${esc(x.leave_type)}</b><small>${esc(x.date_from)} to ${esc(x.date_to)} · ${x.days} days</small></div>${status(x.status)}</div>`).join(''):'<div class="empty">No leave applications yet.</div>'}</div><div class="section-title"><h2>Recent payslips</h2><button class="ghost" data-go="payslips">View all</button></div><div class="list">${d.payslips.length?d.payslips.map(x=>`<div class="item"><div><b>${esc(x.pay_period)}</b><small>Net pay · R ${Number(x.net_pay).toFixed(2)}</small></div>${status(x.status)}</div>`).join(''):'<div class="empty">No approved payslips are available.</div>'}</div>`)}else if(tab==='leave'){const d=await api('/api/mobile/leave');shell(`<div class="section-title"><h2>My leave</h2><button id="newleave">+ Apply</button></div><div class="list">${d.items.length?d.items.map(x=>`<div class="item"><div><b>${esc(x.leave_type)}</b><small>${esc(x.date_from)} → ${esc(x.date_to)} · ${x.days} days</small><small>${esc(x.reason)}</small></div>${status(x.status)}</div>`).join(''):'<div class="empty">You have not submitted any leave applications.</div>'}</div>`);document.getElementById('newleave').onclick=leaveForm}else if(tab==='payslips'){const d=await api('/api/mobile/payslips');shell(`<div class="section-title"><h2>My payslips</h2></div><div class="list">${d.items.length?d.items.map(x=>`<div class="item"><div><b>${esc(x.pay_period)}</b><small>Gross R ${Number(x.gross_pay).toFixed(2)} · Deductions R ${Number(x.total_deductions).toFixed(2)}</small><small>Net pay R ${Number(x.net_pay).toFixed(2)}</small></div><button data-pdf="${x.id}" class="secondary">PDF</button></div>`).join(''):'<div class="empty">No approved payslips are available.</div>'}</div>`);root.querySelectorAll('[data-pdf]').forEach(b=>b.onclick=()=>window.open(`/api/mobile/payslips/${b.dataset.pdf}/pdf`,'_blank'))}else if(tab==='vault'){const d=await api('/api/mobile/documents');shell(`<div class="section-title"><h2>Document Vault</h2><button id="upload">+ Upload</button></div><div class="list">${d.items.length?d.items.map(x=>`<div class="item"><div><b>${esc(x.title)}</b><small>${esc(x.document_type)} · ${esc(x.file_name||'No attachment')}</small></div><div class="quick-grid" style="margin-top:6px">${x.file_name?`<button class="btn btn-secondary btn-small" onclick="window.open('/api/mobile/documents/${x.id}/file','_blank')">View / Download</button>`:''}</div>${status(x.status)}</div>`).join(''):'<div class="empty">No documents have been uploaded.</div>'}</div><div class="section-title"><h2>Printable forms</h2></div><div class="list" id="forms-list"><div class="empty">Loading forms...</div></div>`);loadForms();document.getElementById('upload').onclick=uploadForm}else if(tab==='settings'){shell(`<div class="section-title"><h2>Settings</h2></div><div class="card"><b>${esc(employee?.name)}</b><div class="muted">${esc(employee?.employee_no)} · ${esc(employee?.department||'')}</div><p class="muted">Your account details and access are managed by your employer.</p><button id="change-password" class="btn secondary full">Change my password</button></div><div class="section-title"><h2>Appearance</h2></div><div class="card"><b>Colour theme</b><p class="muted">Choose light or dark. Saved on this device.</p><button id="theme-toggle" class="btn secondary full">${document.documentElement.dataset.theme==='light'?'Switch to dark theme':'Switch to light theme'}</button></div><div class="section-title"><h2>Security</h2></div><div class="card"><b>Fingerprint or face sign-in</b><p class="muted">${biometricAvailable()?'Unlock this app with the fingerprint or face this phone already knows, instead of typing your password every time. Your password never leaves the phone.':'This phone or browser does not offer fingerprint or face unlock.'}</p>${biometricAvailable()?`${localStorage.getItem('br_bio_secret')?'<p class="muted" style="color:#4ade80">On for this phone.</p>':'<button id="bio-setup" class="btn secondary full">Turn on fingerprint or face sign-in</button>'}<button id="bio-off" class="btn secondary full" style="margin-top:8px">Turn off</button>`:''}</div><div class="card"><b>Secure session</b><p class="muted">Your connection uses your employee account. Sign out when you finish using a shared phone.</p><button id="logout" class="btn danger full">Sign out</button></div><div class="smallprint">Beyond Registration ESS Mobile · Preview</div>`);document.getElementById('logout').onclick=async()=>{await api('/api/mobile/logout',{method:'POST',body:'{}'});employee=null;auth()};const tt=document.getElementById('theme-toggle');if(tt)tt.onclick=()=>{const nl=document.documentElement.dataset.theme==='light'?'dark':'light';document.documentElement.dataset.theme=nl;try{localStorage.setItem('br_theme',nl)}catch{}render()};const cp=document.getElementById('change-password');if(cp)cp.onclick=()=>mobilePasswordChange();
    const bs=document.getElementById('bio-setup');
    if(bs)bs.onclick=()=>{
      // Collect the password in-page: Android WebView does not reliably display
      // JavaScript prompt dialogs. Verify it before displaying the OS biometric prompt.
      const wrap=document.createElement('div');
      wrap.className='modal-back';
      wrap.innerHTML='<div class="modal card"><h2>Turn on fingerprint or face sign-in</h2>'
        +'<p class="muted">Enter your current account password to confirm it is you. Then confirm with your phone’s fingerprint or face. The password is saved only on this phone.</p>'
        +'<label class="field"><span>Current password</span><input id="bio-password" type="password" autocomplete="current-password" minlength="4" required></label>'
        +'<button type="button" class="btn secondary full" id="bio-password-show">Show password</button>'
        +'<p class="form-error" id="bio-setup-error" hidden></p>'
        +'<div class="modal-actions"><button type="button" class="btn secondary" id="bio-setup-cancel">Cancel</button>'
        +'<button type="button" class="btn" id="bio-setup-continue">Continue</button></div></div>';
      document.body.appendChild(wrap);
      const password=wrap.querySelector('#bio-password');
      const error=wrap.querySelector('#bio-setup-error');
      const cancel=()=>wrap.remove();
      wrap.querySelector('#bio-setup-cancel').onclick=cancel;
      wrap.onclick=e=>{if(e.target===wrap)cancel()};
      wrap.querySelector('#bio-password-show').onclick=()=>{
        const visible=password.type==='password';
        password.type=visible?'text':'password';
        wrap.querySelector('#bio-password-show').textContent=visible?'Hide password':'Show password';
      };
      password.focus();
      wrap.querySelector('#bio-setup-continue').onclick=async()=>{
        const typed=password.value;
        error.hidden=true;
        if(!typed){error.textContent='Enter your current password.';error.hidden=false;return}
        const button=wrap.querySelector('#bio-setup-continue');
        button.disabled=true;button.textContent='Checking password…';
        try{
          const employeeNo=employee?.employee_no||localStorage.getItem('br_last_employee')||'';
          if(!employeeNo)throw Error('Could not identify your employee account. Sign out and sign in again.');
          await api('/api/mobile/login',{method:'POST',body:JSON.stringify({employee_no:employeeNo,password:typed})});
          button.textContent='Confirm fingerprint or face…';
          const ok=await biometricCheck();
          if(!ok)throw Error('Fingerprint or face confirmation was cancelled or unavailable. Your password was not saved for biometric sign-in.');
          localStorage.setItem('br_bio_employee',employeeNo);
          localStorage.setItem('br_bio_secret',encodeBioSecret(typed));
          cancel();
          toast('Fingerprint sign-in is on for this phone.');
          render();
        }catch(e){
          button.disabled=false;button.textContent='Continue';
          error.textContent=e&&e.message?e.message:'Could not enable biometric sign-in.';
          error.hidden=false;
        }
      };
    };
    const bo=document.getElementById('bio-off');
    if(bo)bo.onclick=()=>{localStorage.removeItem('br_bio_id');localStorage.removeItem('br_bio_employee');localStorage.removeItem('br_bio_secret');toast('Fingerprint sign-in is off.');render()};}root.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{setMobileTab(b.dataset.go==='report'?'report':b.dataset.go)});if(tab==='report')reportForm()}catch(e){if(e.message.includes('session')||e.message.includes('sign in'))auth(e.message);else{shell(`<div class="error">${esc(e.message)}</div><button id="retry">Try again</button>`);document.getElementById('retry').onclick=render}}}
function leaveForm(){shell(`<div class="section-title"><h2>New leave application</h2><button class="ghost" id="back">Back</button></div><form id="lf" class="form"><div class="field"><label>Leave type</label><select name="leave_type"><option>Annual leave</option><option>Sick leave</option><option>Family responsibility leave</option><option>Unpaid leave</option><option>Other</option></select></div><div class="field"><label>Start date</label><input name="date_from" type="date" required></div><div class="field"><label>End date</label><input name="date_to" type="date" required></div><div class="field"><label>Reason</label><textarea name="reason" required></textarea></div><button class="btn full">Submit application</button></form>`);document.getElementById('back').onclick=()=>{tab='leave';render()};document.getElementById('lf').onsubmit=async e=>{e.preventDefault();let f=Object.fromEntries(new FormData(e.target));try{const r=await api('/api/mobile/leave',{method:'POST',body:JSON.stringify(f)});toast(`Leave submitted · ${r.days} working days`);tab='leave';render()}catch(x){toast(x.message)}}}
function fileToData(file){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)})}
function uploadForm(){shell(`<div class="section-title"><h2>Upload document</h2><button class="ghost" id="back">Back</button></div><form id="uf" class="form"><div class="field"><label>Document category</label><select name="document_type"><option>Identity document</option><option>Medical certificate</option><option>Contract</option><option>Qualification</option><option>Proof of residence</option><option>Bank confirmation</option><option>Other</option></select></div><div class="field"><label>Document title</label><input name="title" required></div><div class="field"><label>Choose file or take photograph</label><input name="file" type="file" accept="image/*,application/pdf" capture="environment" required></div><button class="btn full">Upload for review</button></form>`);document.getElementById('back').onclick=()=>{tab='vault';render()};document.getElementById('uf').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target),file=f.get('file');try{let data=await fileToData(file);await api('/api/mobile/documents',{method:'POST',body:JSON.stringify({document_type:f.get('document_type'),title:f.get('title'),filename:file.name,data})});toast('Document uploaded for review');tab='vault';render()}catch(x){toast(x.message)}}}
function reportForm(){shell(`<div class="section-title"><h2>Image report</h2></div><p class="muted">Report damaged equipment, maintenance issues or other workplace problems. A photograph and explanation are required.</p><form id="rf" class="form"><div class="field"><label>Report title</label><input name="title" required></div><div class="field"><label>Location / affected item</label><input name="location" required></div><div class="field"><label>Explanation</label><textarea name="description" required></textarea></div><div class="field"><label>Photograph</label><input name="photo" type="file" accept="image/*" capture="environment" required></div><button class="btn full">Submit image report</button></form>`);document.getElementById('rf').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target),file=f.get('photo');try{let photoData=await fileToData(file);await api('/api/mobile/reports',{method:'POST',body:JSON.stringify({title:f.get('title'),location:f.get('location'),description:f.get('description'),photoName:file.name,photoData})});toast('Image report submitted');tab='home';render()}catch(x){toast(x.message)}}}
const BR_APP_VERSION=(new URLSearchParams(location.search).get('appv')||'2.0');
function newerVersion(a,b){const pa=String(a||'0').split('.').map(x=>parseInt(x)||0),pb=String(b||'0').split('.').map(x=>parseInt(x)||0);for(let i=0;i<3;i++){if((pa[i]||0)!==(pb[i]||0))return (pa[i]||0)>(pb[i]||0)}return false}
async function checkAppUpdate(){try{const d=await api('/api/mobile/app-version');if(d&&d.apk_available&&newerVersion(d.version,BR_APP_VERSION)&&window.__appUpdate!==d.version){
/* An explicit redraw, for when a page is left blank by a failed render. */
window.n3xRedraw=function(next){try{var t=next||tab||'home';tab=t;setMobileTab(t,{back:true});render();return root.innerHTML.length}catch(e){return 'ERR:'+e.message}};
/* Kept out of the way of the VOIC3 messenger: it drives the tab switch
   directly and does not need an observer repainting over the dashboard. */
window.__n3xLeaveVoic3=function(){try{window.setMobileTab('home')}catch(e){try{location.hash='home'}catch(e2){}}};

window.__appUpdate=d.version;try{render()}catch{}}}catch{}}
function offlineScreen(){const q=brOutbox().length;root.innerHTML=`<main class="auth"><div class="logo"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" aria-hidden="true"><path d="M7 18V6l10 12V6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div class="muted" style="letter-spacing:2px">BEYOND REGISTRATION (PTY) LTD</div><h1>Server unreachable</h1><p>The Windows server could not be contacted. Connect to the office Wi-Fi or VPN and try again.</p><div class="error" style="display:block">No live data is available while offline.${q?` ${q} queued item${q===1?'':'s'} will send automatically on reconnect.`:' Items queued on this device send automatically on reconnect.'}</div><button class="btn full" id="retry-conn">Retry connection</button><div class="smallprint">Emergency SOS and check-ins recorded while signed in are stored on this device and delivered when the server is reachable again.</div></main>`;document.getElementById('retry-conn').onclick=boot;setTimeout(()=>{if(root.querySelector('#retry-conn'))boot()},15000)}
async function boot(){try{await fetch('/api/mobile/app-version',{cache:'no-store'})}catch{offlineScreen();return}try{let d=await api('/api/mobile/me');employee=d.employee;employee.device_class=d.device_class||'staff';tabHistory.length=0;tabHistoryReady=true;try{history.replaceState({n3xusTab:'home'},'','#home')}catch{};if(!localStorage.getItem('br_device_key'))localStorage.setItem('br_device_key','dev-'+Math.random().toString(36).slice(2)+Date.now().toString(36));setMobileTab('home',{back:true});await render();if(!root.innerHTML||root.innerHTML.length<40){await render();}checkAppUpdate().catch(function(e){console.error('N3XUS update check:',e&&e.message||e)});brInitPush();brPushDeepLink();brOutboxBanner()}catch(e){console.error('N3XUS boot() failed:',e&&e.stack||e);try{auth()}catch(e2){console.error('N3XUS auth() failed:',e2&&e2.stack||e2)}}}
if('serviceWorker'in navigator)navigator.serviceWorker.register('/mobile/sw.js',{scope:'/mobile/'}).catch(()=>{});
/* Section 12: register for self-hosted Web Push so calls, SOS and DMs ring in the
   background. Best-effort: no PushManager, no VAPID key or a denied permission
   simply leaves the app behaving exactly as before. */
function brInitPush(){if(!window.BR_PUSH)return;BR_PUSH.subscribe(api,{ask:true}).then(r=>{window.__brPush=r}).catch(()=>{})}
/* Section 13: offline-first send. When the device is offline (or the fetch
   fails on a dead link) the message is queued in IndexedDB with an
   idempotency_key and flushed in order on reconnect — never duplicated. */
async function brSendOrQueue(path,payload,label){
  if(window.Voic3Outbox&&navigator.onLine!==false){
    try{return await api(path,{method:'POST',body:JSON.stringify(payload)});}
    catch(e){
      const st=Number(e&&e.status)||0;
      if(st>=400&&st<500)throw e;           // real rejection — surface it
      await Voic3Outbox.enqueue({kind:'message',method:'POST',url:path,body:payload});
      toast((label||'Message')+' queued — it will send when you are back online');return {queued:true};
    }
  }
  if(window.Voic3Outbox){
    await Voic3Outbox.enqueue({kind:'message',method:'POST',url:path,body:payload});
    toast((label||'Message')+' queued — it will send when you are back online');return {queued:true};
  }
  return api(path,{method:'POST',body:JSON.stringify(payload)});
}
function brOutboxBanner(){
  if(!window.Voic3Outbox)return;
  Voic3Outbox.onChange(async st=>{
    const n=await Voic3Outbox.pendingCount();
    let el=document.getElementById('br-outbox-banner');
    if(!el){el=document.createElement('div');el.id='br-outbox-banner';
      el.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:9998;padding:7px 14px;font-size:12.5px;font-weight:700;text-align:center;display:none;background:#1f4d2e;color:#ecfdf5';
      document.body.appendChild(el)}
    const off=navigator.onLine===false;
    if(!off&&!n){el.style.display='none';return}
    el.style.display='block';
    el.style.background=off?'#7a1f1f':'#1f4d2e';
    el.textContent=off?'OFFLINE — '+n+' item'+(n===1?'':'s')+' queued, sending automatically':'Sending '+n+' queued item'+(n===1?'':'s')+'…';
  });
  const flush=()=>Voic3Outbox.flush(api).then(r=>{if(r.sent){toast(r.sent+' queued item'+(r.sent===1?'':'s')+' sent');try{render()}catch{}}});
  window.addEventListener('online',flush);
  if(navigator.onLine!==false)setTimeout(flush,1500);
}
function brPushDeepLink(){if(!window.BR_PUSH)return null;const d=BR_PUSH.consumeDeepLink();if(!d)return null;if(d.kind==='call'){setMobileTab('calls')}else if(d.kind==='sos'){setMobileTab('sos')}else{setMobileTab('chats')}return d}
const academyBaseShell=shell;
shell=function(body){academyBaseShell(body);const nav=root.querySelector('.nav');if(!nav)return;nav.style.gridTemplateColumns='';nav.style.gridAutoColumns='';nav.style.display='flex';const button=document.createElement('button');button.dataset.tab='academy';button.className=tab==='academy'?'active':'';button.innerHTML='<span class="mi">'+mi('book')+'</span>EVOLV3';button.onclick=()=>setMobileTab('academy');nav.insertBefore(button,nav.children[1]||null)};
const academyBaseRender=render;
render=async function(){if(tab==='academy'){shell(`<div class="hello">SKILLS DEVELOPMENT · EVOLV3</div><h1>EVOLV3</h1><p class="sub">Professional learning for adults, families and care teams.</p><section class="card"><div class="muted">FIRST SPECIALIST PROGRAMME</div><h2>Dementia Care Education</h2><p>Separate learning pathways for family members and professional caregivers.</p><div class="item"><div><b>Family learning</b><small>Understanding, communication and family support</small></div><span class="pill">Coming soon</span></div><div class="item"><div><b>Professional care</b><small>Person-centred care, safety and practical support</small></div><span class="pill">Coming soon</span></div></section><p class="smallprint">Preview only. Courses, assessments, certificates and AI tutoring will be enabled after their secure services and approval workflow are built.</p>`);return}return academyBaseRender()};
let patientSelectedId=null,patientAlertTimer=0,patientAlertBusy=false;
const academyShellWithPatients=shell;
shell=function(body){academyShellWithPatients(body);const nav=root.querySelector('.nav');if(!nav)return;nav.style.gridTemplateColumns='';const button=document.createElement('button');button.dataset.tab='patients';button.className=tab==='patients'?'active':'';button.innerHTML='<span class="mi">'+mi('heart')+'</span>Patient Care';button.onclick=()=>setMobileTab('patients');nav.insertBefore(button,nav.children[1]||null);if(tab==='patients'){if(!patientAlertTimer)patientAlertTimer=setInterval(refreshPatientAlerts,12000)}else if(patientAlertTimer){clearInterval(patientAlertTimer);patientAlertTimer=0}};
const academyRenderWithPatients=render;
render=async function(){if(tab!=='patients')return academyRenderWithPatients();try{const result=await api('/api/mobile/patients');let patients=result.items||[];let selected=patients.find(p=>Number(p.id)===Number(patientSelectedId))||patients[0]||null;patientSelectedId=selected?.id||null;if(!selected){shell(`<div class="hello">PATIENT CARE SYSTEM</div><h1>Patient Care</h1><div class="empty">No patient is assigned to your account. Ask an administrator to assign patient access.</div><p class="smallprint">Patient records are confidential. Sign out when you finish on a shared device.</p>`);return}const d=await api(`/api/mobile/patients/${selected.id}`);const walks=await api(`/api/mobile/patients/${selected.id}/walks`);const activeWalk=walks.active;const lines=a=>(a||[]).map(x=>`<div class="item"><div><b>${esc(typeof x==='string'?x:Object.values(x).filter(Boolean).join(' · '))}</b></div></div>`).join('')||'<div class="empty">Not recorded</div>';shell(`<div class="hello">CONFIDENTIAL PATIENT RECORD</div><h1>${esc(d.first_name)} ${esc(d.last_name)}</h1><div class="sub">${esc(d.patient_number)} · Date of birth ${esc(d.date_of_birth||'Not recorded')}</div>${patients.length>1?`<div class="field"><label>Assigned patient</label><select id="patient-select">${patients.map(p=>`<option value="${p.id}" ${Number(p.id)===Number(d.id)?'selected':''}>${esc(p.first_name)} ${esc(p.last_name)}</option>`).join('')}</select></div>`:''}<div class="card"><b>Medical conditions</b><div class="list">${lines(d.conditions)}</div></div><div class="card"><b>Current medication</b><div class="list">${lines(d.medications)}</div></div><div class="card"><b>Previous procedures</b><div class="list">${lines(d.procedures)}</div></div><div class="card"><b>Emergency information</b><p><b>Allergies:</b> ${esc(d.allergies||'Not recorded')}</p><p><b>Mobility:</b> ${esc(d.mobility_limitations||'Not recorded')}</p><p>${esc(d.emergency_information||'No emergency summary recorded.')}</p></div><div class="card"><b>Emergency contacts</b><div class="list">${(d.contacts||[]).map(c=>`<div class="item"><div><b>Person ${c.priority}: ${esc(c.name)}</b><small>${esc(c.relationship||'')} · ${esc(c.employee_id?'In-app alert':'Call manually')} ${c.phone?`· ${esc(c.phone)}`:''}</small></div></div>`).join('')||'<div class="empty">No emergency contacts recorded.</div>'}</div></div><div class="card"><b>Emergency documents</b><div class="list">${(d.documents||[]).map(doc=>`<div class="item"><div><b>${esc(doc.title)}</b><small>${esc(doc.document_type)} · ${esc(doc.file_name)}</small></div><button class="secondary" data-patient-doc="${doc.id}" data-patient-id="${d.id}">Download</button></div>`).join('')||'<div class="empty">No emergency documents uploaded.</div>'}</div></div><div class="card"><b>Patient Walk</b><p class="muted">Staff walk log with manual check-ins and optional foreground device GPS.</p>${activeWalk?`<p>Active since ${esc(activeWalk.started_at)}</p>${activeWalk.last_latitude!=null?`<small>Last device location ${Number(activeWalk.last_latitude).toFixed(5)}, ${Number(activeWalk.last_longitude).toFixed(5)} · ${esc(activeWalk.last_checkin_at||'')}</small>`:''}<div class="form"><textarea id="walk-note" placeholder="Check-in note (optional)"></textarea><label class="check-row"><input id="walk-gps" type="checkbox"> Share device location while this screen is open</label><button id="walk-checkin" class="secondary full">Add check-in</button><button id="walk-end" class="btn danger full">End walk</button></div>`:`<div class="form"><textarea id="walk-note" placeholder="Walk notes (optional)"></textarea><label class="check-row"><input id="walk-gps" type="checkbox"> Share device location while this screen is open</label><button id="walk-start" class="btn full">Start patient walk</button></div>`}<p class="smallprint">GPS requires recorded patient consent and device permission. Location runs only while the Patient Care screen is open; this is not an emergency background tracking service.</p>${(walks.items||[]).length?`<div class="list">${walks.items.map(w=>`<div class="item"><div><b>${esc(w.status)} walk</b><small>${esc(w.started_at)}${w.ended_at?` · ended ${esc(w.ended_at)}`:''}${w.notes?` · ${esc(w.notes)}`:''}</small></div></div>`).join('')}</div>`:''}</div><button id="patient-sos" class="btn danger full">Emergency SOS</button><p class="smallprint">This sends a free in-app alert to a linked person 1. If not acknowledged in 60 seconds, linked persons 2 and 3 receive an in-app alert while their app is connected. Phone contacts without an app account must be called manually. GPS and vital readings are not connected.</p><div id="patient-alerts" class="list"></div>`);root.querySelector('#patient-select')?.addEventListener('change',e=>{stopMobilePatientWalk();patientSelectedId=Number(e.target.value);render()});const walkGps=()=>root.querySelector('#walk-gps')?.checked;const walkNote=()=>root.querySelector('#walk-note')?.value||'';root.querySelector('#walk-gps')?.addEventListener('change',e=>{if(!e.target.checked)stopMobilePatientWalk()});root.querySelector('#walk-start')?.addEventListener('click',async()=>{try{const loc=walkGps()?await mobilePosition():{};const w=await api(`/api/mobile/patients/${d.id}/walks`,{method:'POST',body:JSON.stringify({note:walkNote(),...loc})});if(walkGps())startMobilePatientWalk(d.id,w.id);toast('Patient walk started');api('/api/mobile/notify',{method:'POST',body:JSON.stringify({subject:'Patient walk started',body:`Walk started for patient ${d.first_name} ${d.last_name}`})}).catch(()=>{});render()}catch(e){toast(e.message)}});root.querySelector('#walk-checkin')?.addEventListener('click',async()=>{try{const loc=walkGps()?await mobilePosition():{};await api(`/api/mobile/patients/${d.id}/walks/${activeWalk.id}/checkin`,{method:'POST',body:JSON.stringify({note:walkNote(),...loc})});if(walkGps())startMobilePatientWalk(d.id,activeWalk.id);toast('Walk check-in saved');render()}catch(e){toast(e.message)}});root.querySelector('#walk-end')?.addEventListener('click',async()=>{try{await api(`/api/mobile/patients/${d.id}/walks/${activeWalk.id}/end`,{method:'POST',body:'{}'});stopMobilePatientWalk();toast('Patient walk ended');api('/api/mobile/notify',{method:'POST',body:JSON.stringify({subject:'Patient walk ended',body:`Walk ended for patient ${d.first_name} ${d.last_name}`})}).catch(()=>{});render()}catch(e){toast(e.message)}});root.querySelector('#patient-sos')?.addEventListener('click',async()=>{if(!confirm('Send an Emergency SOS alert now?'))return;try{const r=await api(`/api/mobile/patients/${d.id}/alerts`,{method:'POST',body:JSON.stringify({event_type:'Emergency SOS'})});toast(r.person_1_in_app?'SOS sent to person 1 in app':'SOS recorded. Call person 1 manually.');await refreshPatientAlerts()}catch(e){toast(e.message)}});root.querySelectorAll('[data-patient-doc]').forEach(button=>button.onclick=async()=>{try{const response=await fetch(`/api/mobile/patients/${button.dataset.patientId}/documents/${button.dataset.patientDoc}`,{credentials:'same-origin',cache:'no-store'});if(!response.ok)throw Error('Could not download the emergency document.');const blob=await response.blob(),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='patient-emergency-document';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}catch(e){toast(e.message)}});await refreshPatientAlerts()}catch(e){if(e.message.includes('session')||e.message.includes('sign in'))auth(e.message);else{shell(`<div class="error">${esc(e.message)}</div><button id="patient-retry">Try again</button>`);root.querySelector('#patient-retry').onclick=render}}};
async function refreshPatientAlerts(){if(tab!=='patients'||patientAlertBusy)return;patientAlertBusy=true;try{const result=await api('/api/mobile/patient-alerts');const host=root.querySelector('#patient-alerts');if(!host)return;const items=result.items||[];host.innerHTML=items.map(a=>`<div class="card emergency-card"><b>EMERGENCY · ${esc(a.first_name)} ${esc(a.last_name)}</b><p>${esc(a.event_type)} · Contact ${a.priority} · ${esc(a.delivery_status)}</p><small>${esc(a.alert_created)}</small><button class="btn danger full" data-alert-ack="${a.alert_id}">Acknowledge alert</button></div>`).join('');host.querySelectorAll('[data-alert-ack]').forEach(button=>button.onclick=async()=>{try{await api(`/api/mobile/patient-alerts/${button.dataset.alertAck}/ack`,{method:'POST',body:'{}'});toast('Emergency alert acknowledged');await refreshPatientAlerts()}catch(e){toast(e.message)}})}catch(e){console.warn('Patient alert refresh failed:',e.message)}finally{patientAlertBusy=false}}
const msgBaseShell=shell;
shell=function(body){msgBaseShell(body);const nav=root.querySelector('.nav');if(!nav)return;nav.style.gridTemplateColumns='';nav.style.gridAutoColumns='';nav.style.display='flex';const button=document.createElement('button');button.dataset.tab='messages';button.className=tab==='messages'?'active':'';button.innerHTML='<span class="mi">'+mi('message')+'</span>VOIC3';button.onclick=()=>setMobileTab('messages');nav.appendChild(button)};
const msgBaseRender=render;
render=async function(){if(tab!=='messages')return msgBaseRender();shell(`<div class="hello">TELECOMMUNICATIONS · VOIC3</div><h1>VOIC3</h1><p class="sub">Secure in-app messages, calls and payslip PDFs from Beyond Registration.</p><div style="margin:8px 0"><button class="btn btn-primary btn-small" id="voic3-call">Start a call</button></div><div id="msg-list"><div class="empty">Loading…</div></div>`);const cb=document.getElementById('voic3-call');if(cb)cb.onclick=()=>startCall();try{const d=await api('/api/mobile/messages');const items=d.items||[];const host=root.querySelector('#msg-list');host.innerHTML=items.length?items.map(m=>`<div class="card"><b>${esc(m.subject)}</b><p class="muted">${esc(m.sender)} · ${esc(m.created_at||'')}</p><p>${esc(m.body)}</p>${m.has_attachment?`<a class="btn full" href="/api/mobile/messages/${m.id}/attachment" style="display:block;text-align:center;text-decoration:none">Download ${esc(m.attachment_name||'attachment')}</a>`:''}</div>`).join(''):'<div class="empty">No messages yet. Payslips and notices sent by your office will appear here.</div>'}catch(e){const host=root.querySelector('#msg-list');if(host)host.innerHTML=`<div class="empty">${esc(e.message)}</div>`}return};

/* ===== Phase 5: profiles, contracts, admin, ops, check-in ===== */
let contractSelected=null,sigDrawing=false,checkinTimer=null,checkinBusy=false;
// Hide the tabs this role may not use. Runs after every render, so it works
// whatever order the individual tab builders added their buttons in.
function applyRoleTabs(){
  if(!employee||!Array.isArray(employee.tabs)) return;
  if(employee.role!=='admin'&&employee.profile==='admin') employee.role='admin';
  root.querySelectorAll('.nav [data-tab]').forEach(b=>{
    if(roleAllowsTab(b.dataset.tab)) b.style.display='';
    else b.style.display='none';
  });
  if(typeof window.Voic3Tabs==='object'&&window.Voic3Tabs.collapseHidden) window.Voic3Tabs.collapseHidden();
  if(typeof window.Voic3Tabs==='object'&&window.Voic3Tabs.overflow) window.Voic3Tabs.overflow();
}
function isAdmin(){return employee&&employee.profile==='admin'}
// The server tells us which role this account is. Until it does (old session,
// offline) we fall back to the old profile behaviour, so nothing changes.
function roleId(){return (employee&&employee.role)||'representative'}
function roleCan(what){
  if(employee&&Array.isArray(employee.can)) return employee.can.includes('all')||employee.can.includes(what);
  return isAdmin();
}
// A tab is shown only if the role lists it. Unknown tabs stay visible so an
// older server that sends no role keeps working exactly as before.
function roleAllowsTab(id){
  if(!employee||!Array.isArray(employee.tabs)) return true;
  return employee.tabs.includes(id);
}
function isCompany(){return employee&&employee.device_class==='company'}
function beep(){try{const C=window.AudioContext||window.webkitAudioContext;const c=new C();[0,180,360].forEach(d=>{const o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=880;o.type='sine';const t=c.currentTime+d/1000;g.gain.setValueAtTime(0.25,t);g.gain.exponentialRampToValueAtTime(0.001,t+0.15);o.start(t);o.stop(t+0.16)});setTimeout(()=>c.close(),1200)}catch(e){}}
function checkinOverlay(){beep();const ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;background:rgba(4,12,24,.94);z-index:99;display:flex;align-items:center;justify-content:center';ov.innerHTML=`<div class="card" style="max-width:340px;width:90%"><h2>Shift check-in</h2><p>Confirm you are with the patient. If this device was removed, do not check in — alert your supervisor.</p><button class="btn full" id="ci-yes">I am with the patient</button><button class="btn ghost full" id="ci-later" style="margin-top:8px">Remind me in 5 min</button></div>`;document.body.append(ov);ov.querySelector('#ci-yes').onclick=async()=>{ov.remove();await doCheckin()};ov.querySelector('#ci-later').onclick=()=>{ov.remove();setTimeout(checkinOverlay,300000)}}
async function doCheckin(){if(checkinBusy)return;checkinBusy=true;try{await api('/api/mobile/checkin',{method:'POST',body:'{}'});toast('Checked in')}catch(e){toast(e.message)}finally{checkinBusy=false}}
function startCheckinLoop(){if(!isCompany()||checkinTimer)return;checkinTimer=setInterval(()=>{checkinOverlay()},30*60*1000);setTimeout(checkinOverlay,15000)}
function contractCard(c){return `<div class="card"><b>${esc(c.title)}</b><p class="muted">${esc(c.file_name||'PDF')} · Sent ${esc((c.created_at||'').slice(0,10))} · Status: <b>${esc(c.status)}</b></p>${c.status==='Declined'?`<p class="muted">Reason: ${esc(c.decline_reason||'')}</p>`:''}${c.status==='Approved'?`<p class="muted">Signed by ${esc(c.signed_name||'')} on ${esc((c.decided_at||'').slice(0,10))}</p>`:''}${c.status==='Pending'?`<div style="display:flex;gap:8px"><a class="btn" style="flex:1;text-align:center;text-decoration:none" href="/api/mobile/contracts/${c.id}/pdf" target="_blank">Read</a><button class="btn" style="flex:1" data-cview="${c.id}">Sign</button></div>`:''}</div>`}
function contractReview(c){contractSelected=c;root.innerHTML=`<header class="top"><div class="brand"><div class="logo"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" aria-hidden="true"><path d="M7 18V6l10 12V6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div><strong>CONTRACT</strong><small>${esc(c.title)}</small></div></div></header><main class="content"><iframe src="/api/mobile/contracts/${c.id}/pdf" style="width:100%;height:52vh;border:1px solid #234;border-radius:10px;background:#fff"></iframe><div class="card"><label>Full name (signature)</label><input id="sig-name" placeholder="Type your full name"></div><div class="card"><label>Draw signature</label><canvas id="sig-pad" width="600" height="160" style="width:100%;background:#fff;border-radius:8px;touch-action:none"></canvas><div style="display:flex;gap:8px;margin-top:8px"><button class="btn ghost" id="sig-clear" style="flex:1">Clear</button><button class="btn" id="sig-ok" style="flex:1">Approve &amp; sign</button></div></div><div class="card"><input id="dec-reason" placeholder="Reason (only if declining)"><div style="display:flex;gap:8px;margin-top:8px"><button class="btn danger" id="sig-decline" style="flex:1">Decline</button><button class="btn ghost" id="sig-back" style="flex:1">Back</button></div></div></main>`;const cv=root.querySelector('#sig-pad'),ctx=cv.getContext('2d');ctx.strokeStyle='#111';ctx.lineWidth=2.5;let drawing=false;const pos=e=>{const r=cv.getBoundingClientRect();const t=e.touches?e.touches[0]:e;return{x:(t.clientX-r.left)*(cv.width/r.width),y:(t.clientY-r.top)*(cv.height/r.height)}};cv.onpointerdown=e=>{drawing=true;const q=pos(e);ctx.beginPath();ctx.moveTo(q.x,q.y);cv.setPointerCapture&&cv.setPointerCapture(e.pointerId)};cv.onpointermove=e=>{if(!drawing)return;const q=pos(e);ctx.lineTo(q.x,q.y);ctx.stroke()};cv.onpointerup=()=>drawing=false;cv.onpointercancel=()=>drawing=false;root.querySelector('#sig-clear').onclick=()=>ctx.clearRect(0,0,cv.width,cv.height);root.querySelector('#sig-back').onclick=()=>{tab='contracts';render()};root.querySelector('#sig-decline').onclick=async()=>{const reason=root.querySelector('#dec-reason').value.trim();try{await api(`/api/mobile/contracts/${c.id}/decision`,{method:'POST',body:JSON.stringify({decision:'Declined',reason})});toast('Contract declined');tab='contracts';render()}catch(e){toast(e.message)}};root.querySelector('#sig-ok').onclick=async()=>{const name=root.querySelector('#sig-name').value.trim();if(!name){toast('Type your full name first');return}const probe=document.createElement('canvas');probe.width=cv.width;probe.height=cv.height;const pctx=probe.getContext('2d');pctx.drawImage(cv,0,0);const blank=pctx.getImageData(0,0,probe.width,probe.height).data.every((v,i)=>i%4===3||v===255);if(blank){toast('Please draw your signature');return}try{await api(`/api/mobile/contracts/${c.id}/decision`,{method:'POST',body:JSON.stringify({decision:'Approved',signed_name:name,signature_data:cv.toDataURL('image/png')})});toast('Contract signed and returned');tab='contracts';render()}catch(e){toast(e.message)}}}
async function adminApprovals(){const[leave,ai,payslips,overview]=await Promise.all([api('/api/mobile/admin/leave'),api('/api/mobile/admin/approvals'),api('/api/mobile/admin/payslip-requests'),api('/api/mobile/admin/overview')]);shell(`<div class="hello">MANAGEMENT</div><h1>Approvals</h1><p class="sub">${overview.leave_pending||0} leave · ${overview.ai_pending||0} AI · ${overview.payslip_pending||0} payslip · ${overview.contracts_pending||0} contracts · ${overview.fatigue_flags||0} fatigue flags</p><div class="section-title"><h2>Leave requests</h2></div><div class="list">${(leave.items||[]).map(l=>`<div class="card"><b>${esc(l.first_name)} ${esc(l.last_name)}</b> · ${esc(l.employee_no)}<p>${esc(l.leave_type)} · ${esc(l.date_from)} → ${esc(l.date_to)} (${l.days}d)</p><p class="muted">${esc(l.reason||'')}</p><div style="display:flex;gap:8px"><button class="btn" style="flex:1" data-leave-ok="${l.id}">Approve</button><button class="btn danger" style="flex:1" data-leave-no="${l.id}">Deny</button></div></div>`).join('')||'<div class="empty">No pending leave requests.</div>'}</div><div class="section-title"><h2>Payslip corrections</h2></div><div class="list">${(payslips.items||[]).filter(r=>r.status==='Pending').map(r=>`<div class="card"><b>${esc(r.first_name)} ${esc(r.last_name)}</b> · ${esc(r.pay_period)}<p>${esc(r.field)} → ${esc(r.proposed_value)}</p><p class="muted">${esc(r.reason||'')}</p><div style="display:flex;gap:8px"><button class="btn" style="flex:1" data-pay-ok="${r.id}">Approve</button><button class="btn danger" style="flex:1" data-pay-no="${r.id}">Deny</button></div></div>`).join('')||'<div class="empty">No pending payslip requests.</div>'}</div><div class="section-title"><h2>AI action approvals</h2></div><div class="list">${(ai.items||[]).map(a=>`<div class="card"><b>${esc(a.action_type||'AI action')}</b><p class="muted">${esc((a.payload_json||'').slice(0,300))}</p><div style="display:flex;gap:8px"><button class="btn" style="flex:1" data-ai-ok="${a.id}">Approve</button><button class="btn danger" style="flex:1" data-ai-no="${a.id}">Reject</button></div></div>`).join('')||'<div class="empty">No pending AI actions.</div>'}</div>`);const bind=(sel,fn)=>root.querySelectorAll(sel).forEach(b=>b.onclick=async()=>{try{await fn(b.dataset);toast('Done');adminApprovals()}catch(e){toast(e.message)}});bind('[data-leave-ok]',d=>api(`/api/mobile/admin/leave/${d.leaveOk}/decision`,{method:'POST',body:JSON.stringify({decision:'Approved'})}));bind('[data-leave-no]',d=>api(`/api/mobile/admin/leave/${d.leaveNo}/decision`,{method:'POST',body:JSON.stringify({decision:'Denied'})}));bind('[data-pay-ok]',d=>api(`/api/mobile/admin/payslip-requests/${d.payOk}/decision`,{method:'POST',body:JSON.stringify({decision:'Approved'})}));bind('[data-pay-no]',d=>api(`/api/mobile/admin/payslip-requests/${d.payNo}/decision`,{method:'POST',body:JSON.stringify({decision:'Denied'})}));bind('[data-ai-ok]',d=>api(`/api/mobile/admin/ai/${d.aiOk}/decision`,{method:'POST',body:JSON.stringify({approve:true})}));bind('[data-ai-no]',d=>api(`/api/mobile/admin/ai/${d.aiNo}/decision`,{method:'POST',body:JSON.stringify({approve:false})}))}
let opsWatchers={};
async function opsBattery(){try{if(navigator.getBattery){const b=await navigator.getBattery();return Math.round(b.level*100)}}catch(e){}return null}
function opsPingLoop(pid){return new Promise(res=>{if(!navigator.geolocation)return res();opsWatchers[pid]=navigator.geolocation.watchPosition(async p=>{const now=Date.now();if(opsWatchers['_last_'+pid]&&now-opsWatchers['_last_'+pid]<60000)return;opsWatchers['_last_'+pid]=now;const bat=await opsBattery();try{await api(`/api/mobile/patients/${pid}/location`,{method:'POST',body:JSON.stringify({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy,battery:bat,speed:p.coords.speed==null?null:p.coords.speed})})}catch(e){}},{enableHighAccuracy:true,maximumAge:10000,timeout:20000})})}
function opsStopPing(pid){if(opsWatchers[pid]&&navigator.geolocation){navigator.geolocation.clearWatch(opsWatchers[pid]);delete opsWatchers[pid]}}
async function opsView(){
  const [d,al]=await Promise.all([api('/api/mobile/patients'),api('/api/mobile/alerts').catch(()=>({items:[]}))]);
  const items=d.items||[];const alerts=al.items||[];const enriched=[];
  for(const p of items){try{const st=await api(`/api/mobile/patients/${p.id}/safety`);enriched.push({p,st})}catch(e){enriched.push({p,st:null})}}
  const open=alerts.length;
  const connColor=c=>c==='Connected'?'#00FF66':c==='Location update delayed'?'#FF9900':c==='Device offline / stale'?'#FF3333':'#64748B';
  const eng=enriched.map(e=>e.st?e.st.state||{}:{});
  const connN=eng.filter(s=>s.connection==='Connected').length;
  const trackN=Object.keys(opsWatchers).filter(k=>!k.startsWith('_')).length;
  let freshest=null,freshPing=null;
  enriched.forEach(({st})=>{const s=st?st.state||{}:{};const m=s.minutes_since_update;if(m!=null&&(freshest===null||m<freshest)){freshest=m;freshPing=s.last_ping||null}});
  const engLabel=!items.length?'No patients':connN===items.length?'Online':connN?'Partial':'Offline';
  const engColor=engLabel==='Online'?'#00FF66':engLabel==='Partial'?'#FF9900':engLabel==='Offline'?'#FF3333':'#64748B';
  shell(`<div class="hello">LIVE OPERATIONS</div><h1>Patient Safety</h1><p class="sub">${items.length} patients · ${open} open alert${open===1?'':'s'}</p>
  ${open?`<div class="card" style="border:1px solid #FF1744"><b style="color:#FF1744">${mi('alert')} OPEN ALERTS</b>${alerts.slice(0,5).map(a=>`<p style="margin:6px 0"><b>${esc(a.alert_type)}</b> — ${esc(a.first_name)} ${esc(a.last_name)} <span class="pill orange">${esc(a.status)} · stage ${a.escalation_stage||0}</span></p>`).join('')}</div>`:''}
  <div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><b>NAVIQ TRACKING ENGINE</b><span class="pill" style="border-color:${engColor};color:${engColor}"><span class="dot"></span> ${engLabel}</span></div>
    <div class="vitals-row"><div class="vital"><b>${connN}/${items.length||0}</b><span>ONLINE</span></div><div class="vital"><b>${trackN}</b><span>TRACKING</span></div><div class="vital"><b>${freshest!=null?(freshest<60?Math.round(freshest)+'m':(freshest/60).toFixed(1)+'h'):'—'}</b><span>FRESHEST</span></div></div>
    ${freshPing?`<div class="gps-box"><b>${freshPing.latitude!=null?Number(freshPing.latitude).toFixed(5)+', '+Number(freshPing.longitude).toFixed(5):'NO POSITION'}</b>${freshPing.battery_pct!=null?' · battery '+freshPing.battery_pct+'%':''} · most recent patient update</div>`:''}
  </div>
  <div class="section-title"><h2>Live Patient Vitals</h2><span class="muted">${items.length} patients</span></div>
  <div class="list">${enriched.map(({p,st})=>{const s=st?st.state||{}:{};const ping=s.last_ping||{};const vit=s.latest_vitals||{};const mins=s.minutes_since_update;const tracking=!!opsWatchers[p.id];
    return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><div><b>${esc(p.first_name)} ${esc(p.last_name)}</b><p class="muted">${esc(p.patient_number||'')}</p></div><span class="pill" style="border-color:${connColor(s.connection)};color:${connColor(s.connection)}">${esc(s.connection||'No data')}</span></div>
    <p class="muted">${s.connection_detail||'No updates yet.'}</p>
    <div class="gps-box"><b>${ping.latitude!=null?Number(ping.latitude).toFixed(5)+', '+Number(ping.longitude).toFixed(5):'NO POSITION'}</b>${ping.accuracy_m!=null?' ±'+Math.round(ping.accuracy_m)+'m':''} · battery ${ping.battery_pct!=null?ping.battery_pct+'%':'—'} ${mins!=null?'· '+(mins<60?Math.round(mins)+' min':(mins/60).toFixed(1)+' h')+' ago':''}</div>
    <div class="vitals-row"><div class="vital"><b>${vit.heart_rate||'—'}</b><span>HR BPM</span></div><div class="vital"><b>${vit.spo2?(vit.spo2+'%'):'—'}</b><span>SpO₂</span></div><div class="vital"><b>${vit.temperature_c?(vit.temperature_c+'°C'):'—'}</b><span>TEMP</span></div></div>
    <p><b>Geofences:</b> ${(st.geofences||[]).map(f=>esc(f.name)).join(', ')||'none'}</p>
    <div style="display:flex;gap:8px"><button class="btn ghost" style="flex:1" data-ops-ping="${p.id}">${tracking?'Stop tracking':'Track location'}</button><button class="btn" style="flex:1;background:#FF1744" data-ops-sos-p="${p.id}">SOS</button></div></div>`}).join('')||'<div class="empty">No patients assigned.</div>'}</div>
  <div class="panic-card">
    <div class="panic-title">EMERGENCY PANIC BUTTON</div>
    <div class="panic-sub">NAVIQ PATIENT SAFETY</div>
    <select id="ops-sos-patient">${items.map(p=>`<option value="${p.id}">${esc(p.first_name)} ${esc(p.last_name)}</option>`).join('')}</select>
    <button id="ops-sos" class="panic-hold">HOLD 3 SECONDS FOR SOS</button>
    <div class="panic-hint">Press and hold — accidental taps do nothing.</div>
  </div>
  <div class="card" style="text-align:center"><b>MESSENGER</b><p class="muted" style="margin:6px 0 10px">Chat with authorized contacts</p><button class="btn full" id="ops-goto-msg">Open Messages</button></div>`);
  // SOS hold-3s (banner uses selected patient; per-card uses its own)
  const armSOS=(btn,pid)=>{let t=null,cancel=()=>{clearTimeout(t);t=null;btn.textContent=btn.dataset.idle||'HOLD 3 SECONDS FOR SOS';btn.style.opacity=1};btn.dataset.idle=btn.textContent;btn.addEventListener('pointerdown',()=>{t=setTimeout(async()=>{cancel();btn.textContent='SOS SENT';const target=typeof pid==='function'?pid():pid;const eid=(crypto.randomUUID?crypto.randomUUID():'e'+Date.now().toString(36)+Math.random().toString(36).slice(2,12));const fix=(typeof brLastFix==='function'?brLastFix():null)||window._lastFix||{};const body={event_id:eid};if(fix.latitude!=null){body.latitude=fix.latitude;body.longitude=fix.longitude;if(fix.battery!=null)body.battery=fix.battery}try{const r=await api(`/api/mobile/patients/${target}/sos`,{method:'POST',body:JSON.stringify(body)});toast(r&&r.queued?'SOS RECORDED ON PHONE — will send when online.':(r&&r.duplicate?'SOS already recorded — no duplicate created.':'Emergency alert raised and escalating.'));if(!(r&&r.queued)){for(let i=0;i<6;i++){beep();await new Promise(r=>setTimeout(r,400))}}}catch(e){toast(e.message);btn.textContent=btn.dataset.idle}},3000)});['pointerup','pointerleave','pointercancel'].forEach(ev=>btn.addEventListener(ev,cancel))};
  const sel=root.querySelector('#ops-sos-patient');const banner=root.querySelector('#ops-sos');
  if(banner&&sel)armSOS(banner,()=>Number(sel.value));
  // fix: armSOS expects pid; wrap banner separately
  root.querySelectorAll('[data-ops-ping]').forEach(b=>b.onclick=async()=>{const pid=Number(b.dataset.opsPing);if(opsWatchers[pid]){opsStopPing(pid);b.textContent='Track location'}else{await opsPingLoop(pid);toast('Tracking this patient — pings every ~60s.');b.textContent='Stop tracking'}});
  root.querySelectorAll('[data-ops-sos-p]').forEach(b=>{const pid=Number(b.dataset.opsSosP);armSOS(b,pid);b.dataset.idle='SOS'});
  const gm=root.querySelector('#ops-goto-msg');if(gm)gm.onclick=()=>setMobileTab('messages');
}
async function staffContracts(){const d=await api('/api/mobile/contracts');const items=d.items||[];shell(`<div class="hello">CONTRACTS</div><h1>My contracts</h1><p class="sub">Read, sign or decline contracts sent by management.</p><div class="list">${items.map(contractCard).join('')||'<div class="empty">No contracts have been sent to you.</div>'}</div>`);root.querySelectorAll('[data-cview]').forEach(b=>b.onclick=()=>{const c=items.find(x=>x.id===Number(b.dataset.cview));if(c)contractReview(c)})}
function adminContracts(){api('/api/mobile/admin/contracts').then(d=>{const items=d.items||[];shell(`<div class="hello">CONTRACTS</div><h1>Contract status</h1><p class="sub">Send new contracts from the Windows app; track signatures here.</p><div class="list">${items.map(c=>`<div class="card"><b>${esc(c.title)}</b><p class="muted">${esc(c.first_name)} ${esc(c.last_name)} · ${esc(c.employee_no)}</p><p>Status: <b>${esc(c.status)}</b>${c.signed_name?` · signed by ${esc(c.signed_name)}`:''}${c.decided_at?` · ${esc(c.decided_at.slice(0,10))}`:''}</p></div>`).join('')||'<div class="empty">No contracts sent yet.</div>'}</div>`)})}
function msgComposeCard(){const admin=isAdmin();return `<div class="card"><b>${admin?'Broadcast to all staff':'Message management'}</b>${admin?'<p class="muted smallprint">Sends to every active employee.</p>':''}<input id="msg-subject" placeholder="Subject" style="width:100%;margin:6px 0"><textarea id="msg-body" placeholder="Message" style="width:100%;min-height:70px"></textarea><button class="btn full" id="msg-send" style="margin-top:8px">Send</button></div>`}
function wireMsgSend(){const send=root.querySelector('#msg-send');if(!send)return;send.onclick=async()=>{const subject=root.querySelector('#msg-subject').value.trim(),body=root.querySelector('#msg-body').value.trim();if(!body){toast('Write a message first');return}try{if(isAdmin()){await api('/api/mobile/messages',{method:'POST',body:JSON.stringify({subject:subject||'Announcement',body,department:'ALL EMPLOYEES'})});toast('Broadcast sent')}else{await api('/api/mobile/messages',{method:'POST',body:JSON.stringify({subject,body})});toast('Sent to management')}render()}catch(e){toast(e.message)}}}
const phase5Shell=shell;
shell=function(body){phase5Shell(body);const nav=root.querySelector('.nav');if(!nav)return;const tabs=[];if(isAdmin())tabs.push(['approvals','check','Approvals'],['contracts','contract','Contracts']);else tabs.push(['contracts','contract','Contracts']);if(isAdmin()||isCompany())tabs.push(['ops','activity','Ops']);nav.style.gridTemplateColumns='';nav.style.gridAutoColumns='';nav.style.display='flex';for(const[id,ic,label]of tabs){const b=document.createElement('button');b.dataset.tab=id;b.className=tab===id?'active':'';b.innerHTML=`<span class="mi">${mi(ic)}</span>${label}`;b.onclick=()=>{tab=id;render()};nav.appendChild(b)}}
const phase5Render=render;
render=async function(){if(tab==='contracts')return isAdmin()?adminContracts():staffContracts();if(tab==='approvals'&&isAdmin())return adminApprovals();if(tab==='ops'&&(isAdmin()||isCompany()))return opsView();return phase5Render()};
/* messages: admin sees management inbox + compose; staff sees own + compose */
const phase5MsgRender=render;
render=async function(){if(tab!=='messages')return phase5MsgRender();if(isAdmin()){shell(`<div class="hello">MANAGEMENT</div><h1>Messages</h1><p class="sub">Inbox from staff + broadcast.</p><div id="msg-list"><div class="empty">Loading…</div></div>`);try{const[d1,d2]=await Promise.all([api('/api/mobile/admin/messages'),api('/api/mobile/messages')]);const mgmt=(d1.items||[]).map(m=>`<div class="card"><b>${esc(m.subject)}</b><p class="muted">${esc(m.sender)} · ${esc(m.created_at||'')}</p><p>${esc(m.body)}</p>${m.has_attachment?`<a class="btn full" href="/api/mobile/admin/messages/${m.id}/attachment" style="display:block;text-align:center;text-decoration:none">Download ${esc(m.attachment_name||'attachment')}</a>`:''}</div>`);const own=(d2.items||[]).map(m=>`<div class="card"><b>${esc(m.subject)}</b><p class="muted">${esc(m.sender)} · ${esc(m.created_at||'')}</p><p>${esc(m.body)}</p></div>`);const host=root.querySelector('#msg-list');host.innerHTML=(mgmt.length||own.length)?mgmt.concat(own).join(''):'<div class="empty">No messages.</div>'}catch(e){const host=root.querySelector('#msg-list');if(host)host.innerHTML=`<div class="empty">${esc(e.message)}</div>`}const card=document.createElement('div');card.innerHTML=msgComposeCard();const mc=root.querySelector('main.content');if(mc)mc.appendChild(card.firstElementChild);wireMsgSend();return}
await phase5MsgRender();const card2=document.createElement('div');card2.innerHTML=msgComposeCard();const mc2=root.querySelector('main.content');if(mc2)mc2.appendChild(card2.firstElementChild);wireMsgSend()};
/* pairing overlay (no window.prompt — WebView unsafe) */
function claimOverlay(){const ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;background:rgba(4,12,24,.94);z-index:98;display:flex;align-items:center;justify-content:center';ov.innerHTML=`<div class="card" style="max-width:340px;width:90%;max-height:86vh;overflow:auto"><h2>Pair this device</h2><p>Enter the pairing code created on the Windows app (Settings → Devices). Skip if this is a personal phone.</p><input id="pair-code" placeholder="Pairing code" style="width:100%;margin:8px 0;text-transform:uppercase"><button class="btn full" id="pair-go">Pair device</button><button class="btn ghost full" id="pair-skip" style="margin-top:8px">Skip for now</button></div>`;document.body.append(ov);ov.querySelector('#pair-skip').onclick=()=>{localStorage.setItem('br_device_claimed','skip');ov.remove()};ov.addEventListener('click',e=>{if(e.target===ov){localStorage.setItem('br_device_claimed','skip');ov.remove()}});const esc=e=>{if(e.key==='Escape'){localStorage.setItem('br_device_claimed','skip');ov.remove();document.removeEventListener('keydown',esc)}};document.addEventListener('keydown',esc);setTimeout(()=>{try{ov.querySelector('#pair-code').focus()}catch(_){}} ,120);ov.querySelector('#pair-go').onclick=async()=>{const code=ov.querySelector('#pair-code').value.trim();if(!code){toast('Enter the code');return}try{const r=await api('/api/mobile/device/claim',{method:'POST',body:JSON.stringify({code,device_key:localStorage.getItem('br_device_key'),label:'Mobile device'})});localStorage.setItem('br_device_claimed','1');employee.device_class=r.device_class;ov.remove();toast('Device paired: '+r.device_class);setTimeout(startCheckinLoop,500)}catch(e){toast(e.message)}}}
/* Phase 5 extras run AFTER the real boot finishes. Do not reassign `boot`:
   that shadowed the real async function and left the app unpainted. */
async function bootWithPhase5(){
  try{ await boot(); }catch(e){ console.error('N3XUS boot failed:', e&&e.stack||e); }
  setTimeout(()=>{try{if(localStorage.getItem('br_device_claimed')!=='1'&&localStorage.getItem('br_device_claimed')!=='skip')claimOverlay()}catch(e){}},1000);
  setTimeout(startCheckinLoop,1500);
}

bootWithPhase5();

/* Native bridge: OpsService foreground tick (company-device check-ins while backgrounded) */
window.brNativeTick=async function(){try{if(typeof isCompany==="function"&&isCompany()&&typeof doCheckin==="function")await doCheckin()}catch(e){}};

/* ===== Layer 1: offline mode, store-and-forward outbox, 12-byte SOS codec ===== */
window.satEncode12=function(employeeId,lat,lon,status,battery){const b=new DataView(new ArrayBuffer(12));b.setUint16(0,employeeId&0xFFFF,false);b.setInt32(2,Math.round(lat*1e7),false);b.setInt32(6,Math.round(lon*1e7),false);b.setUint8(10,status&0xFF);b.setUint8(11,Math.max(0,Math.min(100,Math.round(battery||0)))&0xFF);return Array.from(new Uint8Array(b.buffer)).map(x=>x.toString(16).padStart(2,'0')).join('')};
window.satDecode12=function(hex){if(!hex||hex.length!==24)return null;const b=new DataView(new Uint8Array(hex.match(/../g).map(x=>parseInt(x,16))).buffer);return{employee_id:b.getUint16(0,false),latitude:b.getInt32(2,false)/1e7,longitude:b.getInt32(6,false)/1e7,status:b.getUint8(10),battery:b.getUint8(11)}};
const BR_OUTBOX='br_outbox';
const BR_OUTBOX_MAX=200;
function brOutbox(){try{return JSON.parse(localStorage.getItem(BR_OUTBOX)||'[]')}catch(e){return[]}}
/* Cap the queue, but never evict an SOS: drop the oldest non-SOS items first. */
function brOutboxSave(a){const list=(a||[]).slice();while(list.length>BR_OUTBOX_MAX){const i=list.findIndex(x=>x&&x.kind!=='sos');if(i===-1)break;list.splice(i,1)}try{localStorage.setItem(BR_OUTBOX,JSON.stringify(list))}catch(e){}}
function brLastFix(){return window._lastFix||null}
function brEnqueue(kind,payload){const a=brOutbox();a.push({kind,payload,ts:Date.now()});brOutboxSave(a);brSyncOfflineBanner()}
/* Retry later when the request never reached the server (no status) or the
   server could not take it right now (408, 429, 5xx incl. 503 "busy").
   401/403 are surfaced to the person instead of being hidden in a queue. */
function brIsRetryable(err){if(!err)return false;const s=err.status;if(s===undefined||s===null||s===0)return true;return s===408||s===429||s>=500}
/* 400/404/409/422: the server will never accept this item; drop it. */
function brIsPermanent(err){const s=err&&err.status;return s===400||s===404||s===409||s===422}
let brFlushing=false;
async function brFlush(){
  if(brFlushing||navigator.onLine===false)return;
  const a=brOutbox();if(!a.length){brSyncOfflineBanner();return}
  brFlushing=true;const keep=[];
  try{
    for(let i=0;i<a.length;i++){
      const it=a[i];
      try{
        if(it.kind==='sos')await _apiBase(`/api/mobile/patients/${it.payload.pid}/sos`,{method:'POST',body:JSON.stringify({...(it.payload.body||{}),queued_at:it.ts,queued_offline:true})});
        else if(it.kind==='ping')await _apiBase(`/api/mobile/patients/${it.payload.pid}/location`,{method:'POST',body:JSON.stringify({...(it.payload.body||{}),queued_at:it.ts})});
        else if(it.kind==='checkin')await _apiBase('/api/mobile/checkin',{method:'POST',body:JSON.stringify({queued_at:it.ts})});
      }catch(e){
        if(brIsPermanent(e)){console.warn('outbox item rejected',it.kind,e.message);continue}
        it.payload._err=String((e&&e.message)||e);keep.push(...a.slice(i));break; /* keep order: stop at first failure */
      }
    }
  }finally{brFlushing=false}
  brOutboxSave(keep);brSyncOfflineBanner();
}
let brOfflineEl=null;
function brSyncOfflineBanner(){const off=!navigator.onLine;let n=brOutbox().length;if(!brOfflineEl){brOfflineEl=document.createElement('div');brOfflineEl.style.cssText='position:fixed;top:0;left:0;right:0;z-index:9999;padding:8px 14px;font-size:13px;font-weight:700;text-align:center;display:none';document.body.appendChild(brOfflineEl)}brOfflineEl.style.display=off||n?'block':'none';brOfflineEl.style.background=off?'#7a1f1f':'#1f4d2e';brOfflineEl.textContent=off?'OFFLINE — waiting for network. Queued items will send automatically.':(n?`ONLINE — sending ${n} queued item${n===1?'':'s'}…`:'')}
window.addEventListener('online',()=>{brSyncOfflineBanner();brFlush()});
window.addEventListener('offline',brSyncOfflineBanner);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')brFlush()});
setInterval(brFlush,60000);
setTimeout(brFlush,3000);
brSyncOfflineBanner();
/* Wrap api() so safety-critical POSTs are queued whenever they cannot be
   delivered now: phone offline, server laptop asleep, tunnel down, or 503. */
const _apiBase=api;
function brQueueFor(path,opts){
  if(!opts||opts.method!=='POST')return null;
  let body={};try{body=JSON.parse(opts.body||'{}')||{}}catch(_){body={}}
  const mSOS=path.match(/\/api\/mobile\/patients\/(\d+)\/sos$/);
  if(mSOS){
    const fix=brLastFix()||{};
    if(!body.event_id)body.event_id=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():('e'+Date.now().toString(36)+Math.random().toString(36).slice(2,12));
    if(body.latitude==null&&fix.latitude!=null){body.latitude=fix.latitude;body.longitude=fix.longitude;body.accuracy=fix.accuracy??null;body.battery=fix.battery??null}
    return{kind:'sos',payload:{pid:Number(mSOS[1]),body}};
  }
  const mPing=path.match(/\/api\/mobile\/patients\/(\d+)\/location$/);
  if(mPing)return{kind:'ping',payload:{pid:Number(mPing[1]),body}};
  if(path==='/api/mobile/checkin')return{kind:'checkin',payload:{}};
  return null;
}
api=async function(path,opts){
  const q=brQueueFor(path,opts);
  if(q&&navigator.onLine===false){brEnqueue(q.kind,q.payload);return{ok:true,queued:true}}
  /* The SOS goes out with the same event_id it will be replayed with, so the
     server's duplicate check can never create two alerts. */
  const sendOpts=(q&&q.kind==='sos')?{...opts,body:JSON.stringify(q.payload.body)}:opts;
  try{return await _apiBase(path,sendOpts)}
  catch(err){if(q&&brIsRetryable(err)){brEnqueue(q.kind,q.payload);return{ok:true,queued:true}}throw err}
};
/* Track last known fix for queued SOS payloads */
const _opsPingBase=opsPingLoop;
opsPingLoop=async function(pid){if(navigator.geolocation){navigator.geolocation.getCurrentPosition(p=>{window._lastFix={latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy,battery:null};opsBattery().then(b=>{if(window._lastFix)window._lastFix.battery=b})},{enableHighAccuracy:true,maximumAge:10000,timeout:15000})}return _opsPingBase(pid)};

/* ===== Synced per-employee prefs + touch reorder of home quick actions ===== */
let mobilePrefs={};
async function loadMobilePrefs(){try{const d=await api('/api/mobile/prefs');mobilePrefs=d.prefs||{}}catch{mobilePrefs={}}}
let mobilePrefsTimer=null;
function saveMobilePrefs(){clearTimeout(mobilePrefsTimer);mobilePrefsTimer=setTimeout(()=>{api('/api/mobile/prefs',{method:'PUT',body:JSON.stringify({prefs:mobilePrefs})}).catch(()=>{})},600)}
function quickOrder(){return Array.isArray(mobilePrefs.quickOrder)?mobilePrefs.quickOrder:[]}
function applyQuickOrder(){const q=root.querySelector('.quick');if(!q)return;const order=quickOrder();if(!order.length)return;const btns=[...q.querySelectorAll('button[data-go]')];const map=new Map(btns.map(b=>[b.dataset.go,b]));const sorted=[];order.forEach(k=>{if(map.has(k)){sorted.push(map.get(k));map.delete(k)}});btns.forEach(b=>{if(map.has(b.dataset.go)){sorted.push(b);map.delete(b.dataset.go)}});sorted.forEach(b=>q.appendChild(b))}
function wireQuickReorder(){const q=root.querySelector('.quick');if(!q||q.dataset.reorderWired)return;q.dataset.reorderWired='1';
 q.querySelectorAll('button[data-go]').forEach(btn=>{
  let timer=null,drag=null,sx=0,sy=0;
  const move=ev=>{if(!drag)return;btn.style.transform=`translate(${ev.clientX-drag.dx}px,${ev.clientY-drag.dy}px)`;btn.style.zIndex=50;btn.style.position='relative'};
  const finish=ev=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',finish);if(!drag)return;const b=drag.btn;b.classList.remove('qdrag');b.style.transform='';b.style.zIndex='';b.style.position='';const nr=b.getBoundingClientRect();const cx=ev&&ev.clientX!=null?ev.clientX:nr.left+nr.width/2,cy=ev&&ev.clientY!=null?ev.clientY:nr.top+nr.height/2;let target=null;q.querySelectorAll('button[data-go]').forEach(o=>{if(o===b)return;const r=o.getBoundingClientRect();if(cx>r.left&&cx<r.right&&cy>r.top&&cy<r.bottom)target=o});if(target&&target!==b){const br=b.getBoundingClientRect(),tr=target.getBoundingClientRect();q.insertBefore(b,(br.top+br.height/2)<(tr.top+tr.height/2)?target:target.nextSibling)}drag=null;mobilePrefs.quickOrder=[...q.querySelectorAll('button[data-go]')].map(x=>x.dataset.go);saveMobilePrefs()};
  btn.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;sx=e.clientX;sy=e.clientY;clearTimeout(timer);timer=setTimeout(()=>{drag={btn,dx:e.clientX-sx,dy:e.clientY-sy};btn.classList.add('qdrag');window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish);window.addEventListener('pointercancel',finish)},420)});
  btn.addEventListener('pointermove',e=>{if(!drag&&timer&&(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10)){clearTimeout(timer);timer=null}});
  btn.addEventListener('pointerup',()=>{clearTimeout(timer);timer=null});
  btn.addEventListener('pointercancel',()=>{clearTimeout(timer);timer=null});
 });
}
const prefsRender=render;
render=async function(){const r=await prefsRender();applyRoleTabs();setTimeout(applyRoleTabs,0);if(tab==='home'){applyQuickOrder();wireQuickReorder()}return r};
const prefsBoot=boot;
boot=async function(){await prefsBoot();loadMobilePrefs().then(()=>{if(tab==='home'){applyQuickOrder()}})};

/* ==========================================================================
   EVOLV3 knowledge cards - fact cards, mini emergency cards and a quiz.
   Server-served, so content and layout update without rebuilding the APK.
   ========================================================================== */
const acaBaseRender = render;
const acaState = {
  view: 'home', pack: 'dementia', kind: 'fact', index: 0, list: null, listKind: '',
  card: null, summary: null, questions: null, qindex: 0, chosen: null, result: null, flipped: false
};

function acaPct(part, total) {
  return total ? Math.round((Number(part) || 0) / Number(total) * 100) : 0;
}

async function acaLoadSummary(force) {
  if (force || !acaState.summary) {
    try { acaState.summary = await api('/api/mobile/academy/summary?pack=' + encodeURIComponent(acaState.pack)); }
    catch (e) { acaState.summary = null; }
  }
  return acaState.summary;
}

function acaNav() {
  return `<div class="aca-back"><button class="btn secondary btn-small" data-aca="home">← EVOLV3</button></div>`;
}

function acaNumbers(list) {
  if (!Array.isArray(list) || !list.length) return '';
  return `<section class="card aca-numbers"><div class="muted">EMERGENCY NUMBERS</div>
    ${list.map(n => `<a class="aca-number" href="tel:${esc(n.tel)}"><span>${esc(n.label)}</span><b>${esc(n.number)}</b></a>`).join('')}
  </section>`;
}

async function acaHome() {
  const s = await acaLoadSummary(true);
  const c = (s && s.cards) || { total: 0, seen: 0, facts: {}, emergencies: {} };
  const q = (s && s.quiz) || { total: 0, correct: 0, percent: 0 };
  const packLabel = acaState.pack === 'home_safety' ? 'Home Safety' : 'Dementia Care';
  shell(`
    <div class="hello">EVOLV3 \u00b7 ${esc(packLabel.toUpperCase())} PACK</div>
    <h1>Know the person</h1>
    <p class="sub">Short, true and practical. For staff and family.</p>

    <div class="aca-packs">
      <button class="aca-pack ${acaState.pack==='dementia'?'active':''}" data-aca-pack="dementia">Dementia</button>
      <button class="aca-pack ${acaState.pack==='home_safety'?'active':''}" data-aca-pack="home_safety">Home Safety</button>
    </div>

    <section class="card aca-progress-card">
      <div class="aca-row"><b>Cards learned</b><span class="pill green">${c.seen || 0} of ${c.total || 0}</span></div>
      <div class="aca-bar"><i style="width:${acaPct(c.seen, c.total)}%"></i></div>
      <div class="muted">${acaPct(c.seen, c.total)}% complete · quiz best ${q.correct || 0}/${q.total || 0}</div>
    </section>

    <div class="aca-tiles">
      <button class="aca-tile" data-aca="facts">
        <span class="aca-tile-icon mi">${mi('lightbulb')}</span>
        <b>Fact cards</b>
        <small>${(c.facts && c.facts.total) || 0} cards · ${(c.facts && c.facts.seen) || 0} learned</small>
      </button>
      <button class="aca-tile aca-tile-alert" data-aca="emergencies">
        <span class="aca-tile-icon mi">${mi('alert')}</span>
        <b>Emergency cards</b>
        <small>${(c.emergencies && c.emergencies.total) || 0} cards · what to do now</small>
      </button>
    </div>

    <section class="card">
      <div class="aca-row"><div><div class="muted">CHECK YOURSELF</div><h2>Quick quiz</h2></div><span class="pill">${q.total || 0} questions</span></div>
      <p class="muted">Answer a few questions and see what you remember.</p>
      <button class="btn btn-primary" data-aca="quiz" style="width:100%">Start quiz →</button>
    </section>

    <section class="card">
      <div class="aca-row"><div><div class="muted">MY CERTIFICATES</div><h2>Course completions</h2></div></div>
      <p class="muted">View the certificates you have earned.</p>
      <button class="btn btn-secondary" data-aca="certificates" style="width:100%">View my certificates →</button>
    </section>

    ${acaNumbers(s && s.emergency_numbers)}

    <p class="smallprint">${esc((s && s.disclaimer) || 'EVOLV3 teaches general awareness. It is not medical advice.')}</p>
  `);
  acaWire();
}

function acaWire() {
  root.querySelectorAll('[data-aca]').forEach(el => {
    el.onclick = () => {
      const action = el.dataset.aca;
      if (action === 'home') { acaState.view = 'home'; render(); }
      else if (action === 'facts') acaOpenDeck('fact');
      else if (action === 'emergencies') acaOpenEmergencyList();
      else if (action === 'quiz') acaOpenQuiz();
      else if (action === 'certificates') { acaState.view = 'certificates'; render(); }
    };
  });
  root.querySelectorAll('[data-aca-pack]').forEach(el => {
    el.onclick = () => {
      acaState.pack = el.dataset.acaPack;
      acaState.summary = null;
      acaState.list = null;
      acaState.listKind = '';
      acaState.view = 'home';
      render();
    };
  });
  const got = root.querySelector('[data-aca-seen]');
  if (got) got.onclick = acaMarkSeen;
  const prev = root.querySelector('[data-aca-prev]');
  if (prev) prev.onclick = () => acaStep(-1);
  const next = root.querySelector('[data-aca-next]');
  if (next) next.onclick = () => acaStep(1);
  root.querySelectorAll('[data-aca-card]').forEach(el => {
    el.onclick = () => acaOpenEmergency(Number(el.dataset.acaCard));
  });
  root.querySelectorAll('[data-aca-opt]').forEach(el => {
    el.onclick = () => acaAnswer(Number(el.dataset.acaOpt));
  });
  const qnext = root.querySelector('[data-aca-qnext]');
  if (qnext) qnext.onclick = acaNextQuestion;
  root.querySelectorAll('[data-aca-rate]').forEach(el => {
    el.onclick = () => acaRate(el.dataset.acaRateKind, Number(el.dataset.acaRateId), Number(el.dataset.acaRate));
  });
}

async function acaOpenDeck(kind) {
  try {
    acaState.kind = kind;
    acaState.view = kind === 'emergency' ? 'emergencies' : 'facts';
    acaState.index = 0;
    acaState.flipped = false;
    if (!acaState.list || acaState.listKind !== kind) {
      const r = await api('/api/mobile/academy/cards?kind=' + encodeURIComponent(kind) + '&pack=' + encodeURIComponent(acaState.pack));
      acaState.list = r.items || [];
      acaState.listKind = kind;
    }
    if (!acaState.list.length) { toast('No cards in this pack yet.'); acaState.view = 'home'; return render(); }
    await acaLoadCard();
    render();
  } catch (e) { toast(e.message, 'error'); }
}

async function acaLoadCard() {
  const item = acaState.list && acaState.list[acaState.index];
  acaState.card = item ? await api('/api/mobile/academy/cards/' + item.id) : null;
  acaState.flipped = false;
}

function acaSvgHash(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) { h = ((h << 5) - h + str.charCodeAt(i)) | 0; }
  return Math.abs(h);
}

function acaSvg(category, kind) {
  const c = (category || '').toLowerCase();
  const alert = kind === 'emergency';
  const fill = alert ? '#FF3333' : '#00C3FF';
  const bg = alert ? '#2a0a10' : '#0a1830';
  let shape = '';
  if (c.includes('airway') || c.includes('chok')) shape = '<circle cx="100" cy="70" r="28" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M100 98 L100 150 M70 120 L130 120" stroke="' + fill + '" stroke-width="6" stroke-linecap="round"/>';
  else if (c.includes('heart') || c.includes('chest')) shape = '<path d="M100 160 C60 130 40 90 40 70 C40 45 60 30 80 30 C90 30 100 40 100 50 C100 40 110 30 120 30 C140 30 160 45 160 70 C160 90 140 130 100 160 Z" fill="' + fill + '" opacity=".85"/>';
  else if (c.includes('brain') || c.includes('stroke') || c.includes('seizure')) shape = '<path d="M70 60 C70 40 90 30 100 30 C110 30 130 40 130 60 C150 60 160 80 150 100 C160 120 150 140 130 140 C130 160 110 170 100 170 C90 170 70 160 70 140 C50 140 40 120 50 100 C40 80 50 60 70 60 Z" fill="' + fill + '" opacity=".8"/>';
  else if (c.includes('fire')) shape = '<path d="M100 30 C100 30 130 70 130 100 C130 125 115 145 100 150 C85 145 70 125 70 100 C70 70 100 30 100 30 Z" fill="' + fill + '" opacity=".9"/><circle cx="100" cy="110" r="12" fill="#fff" opacity=".6"/>';
  else if (c.includes('water') || c.includes('drown')) shape = '<path d="M40 110 Q70 80 100 110 T160 110 L160 160 L40 160 Z" fill="' + fill + '" opacity=".7"/><circle cx="100" cy="60" r="18" fill="none" stroke="' + fill + '" stroke-width="5"/>';
  else if (c.includes('skin') || c.includes('bed') || c.includes('pressure')) shape = '<rect x="55" y="40" width="90" height="120" rx="20" fill="none" stroke="' + fill + '" stroke-width="6"/><circle cx="100" cy="80" r="14" fill="' + fill + '" opacity=".6"/>';
  else if (c.includes('heat') || c.includes('dehydrat')) shape = '<rect x="85" y="30" width="30" height="90" rx="15" fill="' + fill + '" opacity=".8"/><circle cx="100" cy="145" r="22" fill="' + fill + '" opacity=".8"/><path d="M100 55 L100 95" stroke="#fff" stroke-width="4" stroke-linecap="round"/>';
  else if (c.includes('poison')) shape = '<path d="M80 40 L120 40 L135 70 L135 150 L65 150 L65 70 Z" fill="none" stroke="' + fill + '" stroke-width="6"/><circle cx="100" cy="100" r="16" fill="' + fill + '" opacity=".7"/><path d="M92 92 L108 108 M108 92 L92 108" stroke="#fff" stroke-width="4" stroke-linecap="round"/>';
  else if (c.includes('fall')) shape = '<circle cx="100" cy="50" r="18" fill="' + fill + '" opacity=".8"/><path d="M100 68 L100 110 M70 85 L100 95 L130 85 M85 150 L100 110 L115 150" stroke="' + fill + '" stroke-width="6" stroke-linecap="round" fill="none"/>';
  else if (c.includes('communication')) shape = '<circle cx="80" cy="80" r="22" fill="none" stroke="' + fill + '" stroke-width="5"/><circle cx="120" cy="80" r="22" fill="none" stroke="' + fill + '" stroke-width="5"/><path d="M100 60 L100 100" stroke="' + fill + '" stroke-width="4" stroke-linecap="round"/>';
  else if (c.includes('allerg')) shape = '<path d="M100 40 L115 70 L150 75 L125 100 L130 135 L100 120 L70 135 L75 100 L50 75 L85 70 Z" fill="' + fill + '" opacity=".8"/>';
  else if (c.includes('diabet') || c.includes('sugar')) shape = '<rect x="70" y="40" width="60" height="100" rx="12" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M85 70 L115 70 M85 95 L115 95 M85 120 L105 120" stroke="' + fill + '" stroke-width="4" stroke-linecap="round"/>';
  else if (c.includes('home safety') || c.includes('security')) shape = '<path d="M100 30 L160 60 L160 120 L100 170 L40 120 L40 60 Z" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M80 100 L95 115 L125 85" stroke="' + fill + '" stroke-width="6" stroke-linecap="round" fill="none"/>';
  else if (c.includes('medication')) shape = '<rect x="60" y="50" width="80" height="100" rx="14" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M80 80 L120 80 M100 60 L100 100" stroke="' + fill + '" stroke-width="4" stroke-linecap="round"/>';
  else if (c.includes('electrical')) shape = '<path d="M90 30 L70 100 L95 100 L80 170 L130 85 L105 85 L120 30 Z" fill="' + fill + '" opacity=".9"/>';
  else if (c.includes('kitchen')) shape = '<rect x="50" y="60" width="100" height="80" rx="12" fill="none" stroke="' + fill + '" stroke-width="6"/><circle cx="80" cy="95" r="8" fill="' + fill + '"/><circle cx="120" cy="95" r="8" fill="' + fill + '"/>';
  else if (c.includes('water')) shape = '<path d="M100 30 C100 30 140 75 140 105 C140 130 122 150 100 150 C78 150 60 130 60 105 C60 75 100 30 100 30 Z" fill="' + fill + '" opacity=".75"/>';
  else if (c.includes('preparedness') || c.includes('first-aid')) shape = '<rect x="55" y="55" width="90" height="90" rx="18" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M100 75 L100 125 M75 100 L125 100" stroke="' + fill + '" stroke-width="8" stroke-linecap="round"/>';
  else if (c.includes('understanding')) shape = '<circle cx="100" cy="100" r="55" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M85 80 Q100 60 115 80 Q100 100 85 80" fill="' + fill + '" opacity=".5"/><circle cx="100" cy="115" r="6" fill="' + fill + '"/>';
  else {
    const variants = [
      '<circle cx="100" cy="100" r="50" fill="none" stroke="' + fill + '" stroke-width="6"/><path d="M100 70 L100 105 M100 125 L100 130" stroke="' + fill + '" stroke-width="8" stroke-linecap="round"/>',
      '<rect x="50" y="50" width="100" height="100" rx="20" fill="none" stroke="' + fill + '" stroke-width="6"/><circle cx="100" cy="100" r="25" fill="' + fill + '" opacity=".4"/>',
      '<polygon points="100,40 160,160 40,160" fill="none" stroke="' + fill + '" stroke-width="6"/><circle cx="100" cy="120" r="12" fill="' + fill + '" opacity=".6"/>',
      '<path d="M40 100 Q70 60 100 100 T160 100" fill="none" stroke="' + fill + '" stroke-width="6"/><circle cx="100" cy="100" r="10" fill="' + fill + '"/>',
      '<rect x="60" y="60" width="80" height="80" rx="12" fill="' + fill + '" opacity=".2" stroke="' + fill + '" stroke-width="4"/><path d="M80 100 L95 115 L125 85" stroke="' + fill + '" stroke-width="6" stroke-linecap="round" fill="none"/>',
    ];
    shape = variants[acaSvgHash((category||'') + (kind||'')) % variants.length];
  }
  return '<svg viewBox="0 0 200 200" width="100%" height="140" style="background:' + bg + ';border-radius:14px;margin-bottom:10px"><rect width="200" height="200" fill="' + bg + '"/>' + shape + '</svg>';
}

function acaFactView() {
  const c = acaState.card;
  const total = acaState.list ? acaState.list.length : 0;
  if (!c) return `<div class="empty">Card unavailable.</div>`;
  return `
    ${acaNav()}
    <div class="hello">FACT CARD ${acaState.index + 1} OF ${total}</div>
    <div class="aca-card">
      <div class="aca-card-head"><span class="aca-emoji">${mi(c.icon || 'lightbulb')}</span><span class="pill">${esc(c.category || 'Dementia')}</span></div>
      ${acaSvg(c.category, c.kind)}
      <h1 class="aca-title">${esc(c.title)}</h1>
      <p class="aca-body">${esc(c.body)}</p>
      ${c.tip ? `<div class="aca-tip"><b>Try this</b><span>${esc(c.tip)}</span></div>` : ''}
      <div class="muted">${esc(c.minutes || 1)} min read</div>
      <div class="aca-rate"><span class="muted">Rate this card</span><div class="aca-rate-btns">${[1,2,3,4,5,6,7,8,9,10].map(n=>`<button class="aca-rate-btn" data-aca-rate="${n}" data-aca-rate-kind="card" data-aca-rate-id="${c.id}">${n}</button>`).join('')}</div></div>
    </div>
    <div class="aca-deck-nav">
      <button class="btn secondary" data-aca-prev ${acaState.index === 0 ? 'disabled' : ''}>← Back</button>
      <button class="btn btn-primary" data-aca-seen>Got it ${mi('check')}</button>
      <button class="btn secondary" data-aca-next ${acaState.index >= total - 1 ? 'disabled' : ''}>Next →</button>
    </div>`;
}

async function acaEmergencyList() {
  const items = acaState.list || [];
  return `
    ${acaNav()}
    <div class="hello">EMERGENCY CARDS</div>
    <h1>What to do, right now</h1>
    <p class="sub">Tap a card for numbered steps. Call first if someone cannot breathe.</p>
    ${acaNumbers(acaState.summary && acaState.summary.emergency_numbers)}
    <div class="aca-list">
      ${items.map(c => `<button class="aca-list-item" data-aca-card="${c.id}">
        <span class="aca-emoji">${mi(c.icon || 'alert')}</span>
        <span class="aca-list-text"><b>${esc(c.title)}</b><small>${esc(c.teaser || c.category || '')}</small></span>
        <span class="aca-chev">›</span>
      </button>`).join('')}
    </div>
    <p class="smallprint">If someone is not breathing, call 112 or 10177 first, then start CPR.</p>`;
}

function acaEmergencyView() {
  const c = acaState.card;
  if (!c) return `<div class="empty">Card unavailable.</div>`;
  return `
    <div class="aca-back"><button class="btn secondary btn-small" data-aca="emergencies">← All emergencies</button></div>
    <div class="aca-card aca-card-alert">
      <div class="aca-card-head"><span class="aca-emoji">${mi(c.icon || 'alert')}</span><span class="pill orange">${esc(c.category || 'Emergency')}</span></div>
      ${acaSvg(c.category, c.kind)}
      <h1 class="aca-title">${esc(c.title)}</h1>
      <p class="aca-teaser">${esc(c.teaser || '')}</p>
      ${c.call ? `<a class="aca-call" href="tel:112">${mi('phone')} ${esc(c.call)}</a>` : ''}
      <p class="aca-body">${esc(c.body)}</p>
      <ol class="aca-steps">
        ${(c.steps || []).map(s => `<li>${esc(s)}</li>`).join('')}
      </ol>
      <div class="aca-deck-nav"><button class="btn btn-primary" data-aca-seen style="width:100%">I have read this ${mi('check')}</button></div>
    </div>`;
}

async function acaOpenEmergencyList() {
  try {
    await acaLoadSummary(false);
    await acaOpenDeck('emergency');
  } catch (e) { toast(e.message, 'error'); }
}

async function acaOpenEmergency(id) {
  try {
    acaState.card = await api('/api/mobile/academy/cards/' + id);
    acaState.flipped = false;
    acaState.view = 'emergency';
    render();
  } catch (e) { toast(e.message, 'error'); }
}

async function acaMarkSeen() {
  const c = acaState.card;
  if (!c) return;
  try {
    const r = await api('/api/mobile/academy/cards/' + c.id + '/seen', { method: 'POST', body: JSON.stringify({ pack: acaState.pack }) });
    if (acaState.summary) acaState.summary.cards = r.progress;
    toast('Nice - one more card learned.');
  } catch (e) { toast(e.message, 'error'); }
  if (acaState.view === 'facts') acaStep(1);
  else render();
}

async function acaStep(delta) {
  const total = acaState.list ? acaState.list.length : 0;
  const next = acaState.index + delta;
  if (next < 0 || next >= total) return;
  acaState.index = next;
  acaState.flipped = false;
  try { await acaLoadCard(); render(); } catch (e) { toast(e.message, 'error'); }
}

async function acaOpenQuiz() {
  try {
    const r = await api('/api/mobile/academy/quiz?pack=' + encodeURIComponent(acaState.pack));
    acaState.questions = r.items || [];
    acaState.qindex = 0; acaState.chosen = null; acaState.result = null;
    acaState.view = 'quiz';
    render();
  } catch (e) { toast(e.message, 'error'); }
}

function acaQuizView() {
  const qs = acaState.questions || [];
  const q = qs[acaState.qindex];
  if (!q) return `${acaNav()}<div class="empty">No quiz questions yet.</div>`;
  const r = acaState.result;
  return `
    ${acaNav()}
    <div class="hello">QUICK QUIZ · ${acaState.qindex + 1} OF ${qs.length}</div>
    <div class="aca-bar"><i style="width:${acaPct(acaState.qindex + 1, qs.length)}%"></i></div>
    <div class="aca-card">
      <div class="aca-card-head"><span class="aca-emoji">${mi(q.icon || 'help')}</span><span class="pill">Question ${acaState.qindex + 1}</span></div>
      <h1 class="aca-title aca-quiz-q">${esc(q.question)}</h1>
      <div class="aca-options">
        ${q.options.map((opt, i) => {
          let cls = 'aca-opt';
          if (r) {
            if (i === r.answer) cls += ' correct';
            else if (i === acaState.chosen) cls += ' wrong';
          } else if (i === acaState.chosen) cls += ' chosen';
          return `<button class="${cls}" data-aca-opt="${i}" ${r ? 'disabled' : ''}>
            <span class="aca-opt-key">${String.fromCharCode(65 + i)}</span>
            <span>${esc(opt)}</span>
          </button>`;
        }).join('')}
      </div>
      ${r ? `<div class="aca-feedback ${r.correct ? 'good' : 'bad'}">
        <b>${r.correct ? 'Correct ' + mi('check') : 'Not quite'}</b>
        <span>${esc(r.explanation || '')}</span>
        </div>
        <button class="btn btn-primary" data-aca-qnext style="width:100%">
          ${acaState.qindex + 1 >= qs.length ? 'See my score →' : 'Next question →'}
        </button>
        <button class="btn ghost btn-small" data-aca="home" style="width:100%;margin-top:8px">Exit quiz</button>` : `<p class="muted">Choose the best answer.</p>
        <button class="btn ghost btn-small" data-aca="home" style="width:100%;margin-top:8px">Exit quiz</button>`}
    </div>`;
}

async function acaAnswer(choice) {
  if (acaState.result) return;
  const q = acaState.questions[acaState.qindex];
  if (!q) return;
  acaState.chosen = choice;
  try {
    acaState.result = await api('/api/mobile/academy/quiz/answer', {
      method: 'POST', body: JSON.stringify({ question_id: q.id, choice })
    });
    render();
  } catch (e) { toast(e.message, 'error'); }
}

async function acaNextQuestion() {
  const qs = acaState.questions || [];
  if (acaState.qindex + 1 >= qs.length) {
    try { acaState.summary = await api('/api/mobile/academy/summary'); } catch (e) {}
    acaState.view = 'score';
    return render();
  }
  acaState.qindex += 1; acaState.chosen = null; acaState.result = null;
  render();
}

function acaScoreView() {
  const s = acaState.summary;
  const q = (s && s.quiz) || { total: 0, correct: 0, percent: 0 };
  return `
    ${acaNav()}
    <div class="hello">QUIZ COMPLETE</div>
    <h1>You scored ${q.correct || 0} of ${q.total || 0}</h1>
    <section class="card aca-progress-card">
      <div class="aca-bar"><i style="width:${q.percent || 0}%"></i></div>
      <div class="muted">${q.percent || 0}% correct. Retake it any time — your best answers are kept.</div>
    </section>
    <div class="aca-deck-nav">
      <button class="btn btn-primary" data-aca="quiz" style="width:100%">Try again</button>
    </div>
    <div class="aca-deck-nav">
      <button class="btn secondary" data-aca="home" style="width:100%">Back to EVOLV3</button>
    </div>`;
}

async function acaRate(kind, id, rating) {
  try {
    await api('/api/mobile/academy/rate', { method: 'POST', body: JSON.stringify({ kind, id, rating }) });
    toast('Thanks - rated ' + rating + '/10');
  } catch (e) { toast(e.message, 'error'); }
}
async function acaCertificates() {
  let items = [];
  try {
    const r = await api('/api/mobile/academy/certificates');
    items = r.items || [];
  } catch (e) { toast(e.message, 'error'); }
  shell(`
    ${acaNav()}
    <div class="hello">MY CERTIFICATES</div>
    <h1>Certificates earned</h1>
    <p class="sub">Tap a certificate to view, print or download it.</p>
    ${items.length ? '<div class="aca-list">' + items.map(c => '<button class="aca-list-item" style="width:100%" data-cert="' + c.id + '"><span class="aca-emoji">' + mi('trophy') + '</span><span class="aca-list-text"><b>' + esc(c.course_title) + '</b><small>' + esc(c.certificate_no) + ' · ' + esc(c.issued_at) + '</small></span><span class="pill">View</span></button>').join('') + '</div>' : '<div class="empty">No certificates earned yet. Complete a course with 80% or more to earn one.</div>'}
    <section class="card">
      <div class="aca-row"><div><div class="muted">VERIFY</div><h2>Check a certificate</h2></div></div>
      <p class="muted">Type the verification code printed on a certificate. This check runs entirely on this system, offline.</p>
      <div class="field"><label>Verification code</label><input id="cert-code" placeholder="CERT-XXXXXXXX-XXXXXXXXXXXX"></div>
      <button id="cert-verify" class="btn secondary">Verify certificate</button>
      <div id="cert-result" class="smallprint"></div>
    </section>
  `);
  acaWire();
  root.querySelectorAll('[data-cert]').forEach(el => {
    el.onclick = () => { location.href = '/api/mobile/academy/certificates/' + el.dataset.cert + '/view'; };
  });
  const btn = document.getElementById('cert-verify');
  if (btn) btn.onclick = async () => {
    const code = (document.getElementById('cert-code').value || '').trim();
    const out = document.getElementById('cert-result');
    if (!code) { out.textContent = 'Enter the code first.'; return; }
    try {
      const r = await api('/api/mobile/academy/certificates/verify', { method: 'POST', body: JSON.stringify({ code }) });
      if (r.valid) {
        out.innerHTML = '<b style="color:var(--green)">VALID</b> · ' + esc(r.staff_name) + ' · ' + esc(r.course_title) + ' · issued ' + esc(r.issued_at) + (r.percent != null ? ' · ' + esc(r.percent) + '%' : '');
      } else {
        out.innerHTML = '<b style="color:var(--danger)">NOT VALID</b> · ' + esc(r.reason || 'This certificate could not be verified.');
      }
    } catch (e) { out.textContent = e.message; }
  };
}

async function acaDraw() {
  if (acaState.view === 'facts') {
    shell(acaFactView()); acaWire(); return;
  }
  if (acaState.view === 'emergencies') {
    if (!acaState.list) { await acaOpenDeck('emergency'); return; }
    shell(await acaEmergencyList()); acaWire(); return;
  }
  if (acaState.view === 'emergency') {
    shell(acaEmergencyView()); acaWire(); return;
  }
  if (acaState.view === 'quiz') {
    shell(acaQuizView()); acaWire(); return;
  }
  if (acaState.view === 'certificates') {
    await acaCertificates(); return;
  }
  if (acaState.view === 'score') {
    shell(acaScoreView()); acaWire(); return;
  }
  await acaHome();
}

render = async function () {
  if (tab === 'academy') { await acaDraw(); return; }
  return acaBaseRender();
};

const profileTabs = {
  owner: ['home','leave','payslips','vault','settings','academy','patients'],
  company: ['home','patients','leave','payslips','settings','academy'],
  staff: ['home','leave','payslips','vault','settings','academy']
};

function profileType() {
  if (!employee) return 'staff';
  const no = String(employee.employee_no || '');
  if (no === '001' || no === '002') return 'owner';
  if (no === '003') return 'company';
  return 'staff';
}

function applyProfileNav() {
  const pt = profileType();
  const allowed = profileTabs[pt] || profileTabs.staff;
  const nav = root.querySelector('.nav');
  if (!nav) return;
  nav.querySelectorAll('button[data-tab], button[data-tab="academy"], button[data-tab="patients"]').forEach(b => {
    const t = b.dataset.tab;
    b.style.display = allowed.includes(t) ? '' : 'none';
  });
  // academy button uses data-tab=academy, patients uses data-tab=patients
  nav.querySelectorAll('button').forEach(b => {
    const t = b.dataset.tab;
    if (t && !allowed.includes(t)) b.style.display = 'none';
    else if (t) b.style.display = '';
  });
}

// patch boot to set profileType
const profileBaseBoot = boot;
boot = async function() {
  await profileBaseBoot();
  if (employee) employee.profileType = profileType();
  applyProfileNav();
};

// wrap render to filter nav after each render
const profileBaseRender = render;
render = async function() {
  const r = await profileBaseRender();
  applyProfileNav();
  return r;
};

// Profile-specific home banner injected after render
const profileBaseRender2 = render;
render = async function() {
  const r = await profileBaseRender2();
  applyProfileNav();
  return r;
};

// Per-profile home dashboards
const dashBaseRender = render;
render = async function() {
  if (tab !== 'home') {
    const r = await dashBaseRender();
    applyProfileNav();
    return r;
  }
  const pt = profileType();
  let html = '';
  if (pt === 'owner') html = await ownerHome();
  else if (pt === 'company') html = await companyHome();
  else html = await staffHome();
  shell(html);
  applyProfileNav();
  wireHomeActions();
  return;
};

function wireHomeActions() {
  root.querySelectorAll('[data-home]').forEach(el => {
    el.onclick = () => {
      const a = el.dataset.home;
if (a === 'academy') setMobileTab('academy');
       else if (a === 'patients') setMobileTab('patients');
       else if (a === 'leave') setMobileTab('leave');
       else if (a === 'payslips') setMobileTab('payslips');
       else if (a === 'vault') setMobileTab('vault');
       else if (a === 'voic3') setMobileTab('messages');
       else if (a === 'settings') setMobileTab('settings');
    };
  });
  const sos = root.querySelector('[data-sos]');
  if (sos) sos.onclick = triggerSOS;
}

async function ownerHome() {
  let notifs = { leave: [], payslips: [], stock: [] };
  try {
    const lr = await api('/api/mobile/admin/leave');
    notifs.leave = (lr.items || []).filter(x => x.status === 'Pending').slice(0, 5);
  } catch (e) {}
  try {
    const ar = await api('/api/mobile/admin/approvals');
    notifs.stock = (ar.items || []).slice(0, 5);
  } catch (e) {}
  return `
    <div class="hello">WELCOME BACK</div>
    <h1>${esc(employee?.name || 'Owner')}</h1>
    <div class="sub">${esc(employee?.employee_no || '')} · ${esc(employee?.role_label || 'Owner')}</div>

    <section class="card">
      <div class="aca-row"><div><div class="muted">NOTIFICATIONS</div><h2>Pending approvals</h2></div><span class="pill orange">${(notifs.leave.length + notifs.stock.length)}</span></div>
      <div class="muted">Leave requests: ${notifs.leave.length} · Stock/other: ${notifs.stock.length}</div>
      ${notifs.leave.length ? '<div class="aca-list">' + notifs.leave.map(l => '<div class="item"><div><b>' + esc(l.employee_name || 'Employee') + '</b><small>' + esc(l.leave_type) + ' · ' + esc(l.date_from) + ' to ' + esc(l.date_to) + '</small></div><span class="pill orange">Pending</span></div>').join('') + '</div>' : '<div class="empty">No pending leave requests.</div>'}
    </section>

    <div class="aca-tiles">
      <button class="aca-tile" data-home="patients"><span class="aca-tile-icon mi">${mi('hospital')}</span><b>Patient Care</b><small>Tracker + records</small></button>\n      <button class="aca-tile" data-home="vitals"><span class="aca-tile-icon mi">${mi('heart')}</span><b>Vitals</b><small>Wellness estimates</small></button>
      <button class="aca-tile" data-home="voic3"><span class="aca-tile-icon mi">${mi('message')}</span><b>VOIC3</b><small>Messages + alerts</small></button>
      <button class="aca-tile" data-home="academy"><span class="aca-tile-icon mi">${mi('book')}</span><b>EVOLV3</b><small>Skills & learning</small></button>
      <button class="aca-tile" data-home="leave"><span class="aca-tile-icon mi">${mi('calendar')}</span><b>Leave</b><small>Approve requests</small></button>
      <button class="aca-tile" data-home="payslips"><span class="aca-tile-icon mi">${mi('cash')}</span><b>Payslips</b><small>Review & approve</small></button>
      <button class="aca-tile" data-home="settings"><span class="aca-tile-icon mi">${mi('settings')}</span><b>Settings</b><small>System config</small></button>
    </div>
  `;
}

async function companyHome() {
  let patient = null, vitals = null;
  try {
    const pr = await api('/api/mobile/patients');
    patient = (pr.items || [])[0] || null;
    if (patient) {
      try { const vr = await api('/api/mobile/patients/' + patient.id + '/vitals'); vitals = (vr.items || [])[0] || null; } catch (e) {}
    }
  } catch (e) {}
  return `
    <div class="hello">WELCOME BACK</div>
    <h1>${esc(employee?.name || 'Company Phone')}</h1>
    <div class="sub">${esc(employee?.employee_no || '')} · Company phone</div>
    <div class="profile-banner company"><b>Company phone</b><span>Vitals, SOS, VOIC3, patient records, equipment and stock ordering.</span></div>

    ${patient ? `
    <section class="card">
      <div class="aca-row"><div><div class="muted">PATIENT</div><h2>${esc(patient.first_name)} ${esc(patient.last_name)}</h2></div><span class="pill green">${esc(patient.patient_number)}</span></div>
      <div class="muted">DOB: ${esc(patient.date_of_birth || 'Not recorded')}</div>
    </section>

    <section class="card">
      <div class="aca-row"><div><div class="muted">VITALS</div><h2>Latest readings</h2></div></div>
      ${vitals ? `<div class="vitals-row">
        <div class="vital"><b>${esc(vitals.heart_rate || '—')}</b><span>HR (bpm)</span></div>
        <div class="vital"><b>${esc(vitals.spo2 || '—')}</b><span>SpO2 (%)</span></div>
        <div class="vital"><b>${esc(vitals.temperature || '—')}</b><span>Temp (°C)</span></div>
      </div>
      <div class="muted">Last updated: ${esc(vitals.recorded_at || 'never')}</div>
      <div class="smallprint">Wellness estimate &mdash; not for clinical decisions.</div>` : '<div class="empty">No vitals recorded yet.</div>'}
    </section>

    <div class="aca-tiles">
      <button class="aca-tile" data-home="vitals"><span class="aca-tile-icon mi">${mi('heart')}</span><b>Vitals</b><small>Bluetooth + manual</small></button>
      <button class="aca-tile aca-tile-alert" data-sos><span class="aca-tile-icon mi">${mi('alert')}</span><b>SOS</b><small>Emergency alert</small></button>
      <button class="aca-tile" data-home="patients"><span class="aca-tile-icon mi">${mi('clipboard')}</span><b>Patient records</b><small>Medical history</small></button>
      <button class="aca-tile" data-home="voic3"><span class="aca-tile-icon mi">${mi('message')}</span><b>VOIC3</b><small>Messages + tracker</small></button>
      <button class="aca-tile" data-home="academy"><span class="aca-tile-icon mi">${mi('book')}</span><b>EVOLV3</b><small>Skills & learning</small></button>
          <button class="aca-tile" data-home="tracker"><span class="aca-tile-icon mi">${mi('map')}</span><b>Tracker</b><small>Live location</small></button>
      <button class="aca-tile" data-home="vault"><span class="aca-tile-icon mi">${mi('folder')}</span><b>Vault</b><small>Upload documents</small></button>
      <button class="aca-tile" data-home="stock"><span class="aca-tile-icon mi">${mi('box')}</span><b>Stock order</b><small>Request supplies</small></button>
</div>
    ` : '<div class="empty">No patient assigned to this device. Ask an administrator.</div>'}
  `;
}

async function staffHome() {
  let payslips = [], leave = [];
  try {
    const pr = await api('/api/mobile/payslips');
    payslips = (pr.items || []).slice(0, 3);
  } catch (e) {}
  try {
    const lr = await api('/api/mobile/leave');
    leave = (lr.items || []).slice(0, 3);
  } catch (e) {}
  return `
    <div class="hello">WELCOME BACK</div>
    <h1>${esc(employee?.name || 'Staff')}</h1>
    <div class="sub">${esc(employee?.employee_no || '')} · Staff dashboard</div>
    <div class="profile-banner staff"><b>Staff dashboard</b><span>Payslips, EVOLV3, Leave, VOIC3, Vault uploads.</span></div>

    <section class="card">
      <div class="aca-row"><div><div class="muted">PAYSLIPS</div><h2>Recent payslips</h2></div><span class="pill">${payslips.length}</span></div>
      ${payslips.length ? '<div class="list">' + payslips.map(p => '<div class="item"><div><b>' + esc(p.pay_period) + '</b><small>Net: ' + esc(p.net_pay) + '</small></div><span class="pill green">' + esc(p.status) + '</span></div>').join('') + '</div>' : '<div class="empty">No payslips yet.</div>'}
    </section>

    <section class="card">
      <div class="aca-row"><div><div class="muted">LEAVE</div><h2>Recent leave</h2></div><span class="pill">${leave.length}</span></div>
      ${leave.length ? '<div class="list">' + leave.map(l => '<div class="item"><div><b>' + esc(l.leave_type) + '</b><small>' + esc(l.date_from) + ' to ' + esc(l.date_to) + ' · ' + esc(l.days) + ' days</small></div><span class="pill ' + (l.status==='Approved'?'green':'orange') + '">' + esc(l.status) + '</span></div>').join('') + '</div>' : '<div class="empty">No leave records.</div>'}
    </section>
    <div class="aca-tiles">
      <button class="aca-tile" data-home="vitals"><span class="aca-tile-icon mi">${mi('heart')}</span><b>Vitals</b><small>Bluetooth + manual</small></button>
      <button class="aca-tile aca-tile-alert" data-sos><span class="aca-tile-icon mi">${mi('alert')}</span><b>SOS</b><small>Emergency alert</small></button>
      <button class="aca-tile" data-home="patients"><span class="aca-tile-icon mi">${mi('clipboard')}</span><b>Patient records</b><small>Medical history</small></button>
      <button class="aca-tile" data-home="voic3"><span class="aca-tile-icon mi">${mi('message')}</span><b>VOIC3</b><small>Messages + tracker</small></button>
      <button class="aca-tile" data-home="academy"><span class="aca-tile-icon mi">${mi('book')}</span><b>EVOLV3</b><small>Skills & learning</small></button>
    </div>

    <div class="aca-tiles">
      <button class="aca-tile" data-home="academy"><span class="aca-tile-icon mi">${mi('book')}</span><b>EVOLV3</b><small>Skills & learning</small></button>
      <button class="aca-tile" data-home="leave"><span class="aca-tile-icon mi">${mi('calendar')}</span><b>Leave</b><small>Apply for leave</small></button>
      <button class="aca-tile" data-home="payslips"><span class="aca-tile-icon mi">${mi('cash')}</span><b>Payslips</b><small>View & download</small></button>
      <button class="aca-tile" data-home="vault"><span class="aca-tile-icon mi">${mi('folder')}</span><b>Vault</b><small>Upload documents</small></button>
      <button class="aca-tile" data-home="voic3"><span class="aca-tile-icon mi">${mi('message')}</span><b>VOIC3</b><small>Messages</small></button>
      <button class="aca-tile" data-home="settings"><span class="aca-tile-icon mi">${mi('settings')}</span><b>Settings</b><small>Preferences</small></button>
    </div>
  `;
}

async function triggerSOS() {
  // The patient list needs the server, so the last assigned patient is
  // remembered: an SOS must still be recorded (and queued) when the laptop,
  // the tunnel or the network is down. api() adds the event_id and queues it.
  let pid = 0;
  try { pid = Number(localStorage.getItem('br_last_patient_id') || 0); } catch (_) { pid = 0; }
  try {
    const pr = await api('/api/mobile/patients');
    const patient = (pr.items || [])[0];
    if (patient) {
      pid = Number(patient.id);
      try { localStorage.setItem('br_last_patient_id', String(pid)); } catch (_) { /* private mode */ }
    }
  } catch (e) { /* unreachable: use the remembered patient below */ }
  if (!pid) { toast('No patient assigned.', 'error'); return; }
  try {
    const r = await api('/api/mobile/patients/' + pid + '/sos', { method: 'POST', body: JSON.stringify({}) });
    toast(r && r.queued ? 'SOS saved on this phone — it sends automatically when the server is reachable.' : 'SOS alert sent.');
  } catch (e) { toast(e.message, 'error'); }
}

// Stock ordering (digital message)
async function stockView() {
  return `
    <div class="aca-back"><button class="btn secondary btn-small" data-home="home">← Back</button></div>
    <div class="hello">STOCK ORDER</div>
    <h1>Request stock</h1>
    <p class="sub">Send a message to management / owners.</p>
    <section class="card">
      <div class="field"><label>What is needed (be specific)</label><input id="stock-item" type="text" placeholder="e.g. Night time nappies (size L)" required></div>
      <div class="field"><label>How many are left</label><input id="stock-left" type="number" min="0" placeholder="e.g. 10" required></div>
      <div class="field"><label>How many are needed</label><input id="stock-needed" type="number" min="1" placeholder="e.g. 20" required></div>
      <button class="btn btn-primary" id="stock-send" style="width:100%">Send stock request →</button>
      <div id="stock-status" class="muted" style="margin-top:8px"></div>
    </section>
    <p class="smallprint">The message will be sent to management/owners via VOIC3.</p>
  `;
}

async function sendStockRequest() {
  const item = (document.getElementById('stock-item')?.value || '').trim();
  const left = (document.getElementById('stock-left')?.value || '').trim();
  const needed = (document.getElementById('stock-needed')?.value || '').trim();
  const status = document.getElementById('stock-status');
  if (!item || left === '' || needed === '') {
    if (status) status.textContent = 'Please fill in all fields.';
    toast('Please fill in all fields.', 'error');
    return;
  }
  const body = `HI WE NEED: ${item} ${left} LEFT, ${needed} NEEDED`;
  try {
    await api('/api/mobile/messages', { method: 'POST', body: JSON.stringify({ subject: 'Stock Request', body: body }) });
    if (status) status.textContent = 'Sent: ' + body;
    toast('Stock request sent.'); api('/api/mobile/notify',{method:'POST',body:JSON.stringify({subject:'Stock request',body:body})}).catch(()=>{});
    document.getElementById('stock-item').value = '';
    document.getElementById('stock-left').value = '';
    document.getElementById('stock-needed').value = '';
  } catch (e) {
    if (status) status.textContent = 'Failed: ' + e.message;
    toast(e.message, 'error');
  }
}

// Hook into render: handle tab==='stock'
const stockBaseRender = render;
render = async function() {
  if (tab === 'stock') {
    shell(await stockView());
    const btn = document.getElementById('stock-send');
    if (btn) btn.onclick = sendStockRequest;
    applyProfileNav();
    return;
  }
  const r = await stockBaseRender();
  applyProfileNav();
  return r;
};

// Add stock tile to company dashboard: patch companyHome
// We'll add a stock tile by overriding companyHome
const origCompanyHome = companyHome;
companyHome = async function() {
  let html = await origCompanyHome();
  // insert stock tile into the aca-tiles div
  html = html.replace(
    '<button class="aca-tile" data-home="academy">',
    '<button class="aca-tile" data-home="stock"><span class="aca-tile-icon mi">' + mi('box') + '</span><b>Stock order</b><small>Request supplies</small></button>\n      <button class="aca-tile" data-home="academy">'
  );
  return html;
};

// wire stock in wireHomeActions
const origWire = wireHomeActions;
wireHomeActions = function() {
  origWire();
  root.querySelectorAll('[data-home="stock"]').forEach(el => {
    el.onclick = () => setMobileTab('stock');
  });
  const back = root.querySelector('[data-home="home"]');
  if (back && back.closest('.aca-back')) back.onclick = goMobileTabBack;
};

// Tracker map (OpenStreetMap, free, no API key)
async function trackerView() {
  let patient = null, pings = [], state = null;
  try {
    const pr = await api('/api/mobile/patients');
    patient = (pr.items || [])[0] || null;
    if (patient) {
      const sd = await api('/api/mobile/patients/' + patient.id + '/safety');
      pings = sd.pings || [];
      state = sd.state || null;
    }
  } catch (e) {}
  const last = pings[0] || null;
  const lat = last ? last.latitude : null;
  const lon = last ? last.longitude : null;
  const mapUrl = (lat && lon)
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${lon-0.01},${lat-0.01},${lon+0.01},${lat+0.01}&layer=mapnik&marker=${lat},${lon}`
    : '';
  return `
    <div class="aca-back"><button class="btn secondary btn-small" data-home="home">← Back</button></div>
    <div class="hello">TRACKER</div>
    <h1>Patient location</h1>
    <p class="sub">Last known position from location pings.</p>
    ${patient ? `<section class="card"><div class="aca-row"><div><div class="muted">PATIENT</div><h2>${esc(patient.first_name)} ${esc(patient.last_name)}</h2></div><span class="pill green">${esc(patient.patient_number)}</span></div></section>` : '<div class="empty">No patient assigned.</div>'}
    ${lat && lon ? `
      <section class="card" style="padding:0;overflow:hidden">
        <iframe src="${mapUrl}" width="100%" height="300" style="border:0;display:block" loading="lazy" referrerpolicy="no-referrer"></iframe>
      </section>
      <section class="card">
        <div class="aca-row"><b>Last ping</b><span class="pill">${esc(last.created_at || '')}</span></div>
        <div class="muted">Lat: ${esc(lat)} · Lon: ${esc(lon)}</div>
        ${last.accuracy_m ? '<div class="muted">Accuracy: ' + esc(last.accuracy_m) + ' m</div>' : ''}
        ${last.battery_pct ? '<div class="muted">Battery: ' + esc(last.battery_pct) + '%</div>' : ''}
      </section>
    ` : '<div class="empty">No location pings recorded yet. The patient app must send location updates.</div>'}
    ${pings.length > 1 ? `
      <section class="card">
        <div class="muted">RECENT PINGS (${pings.length})</div>
        <div class="list">
          ${pings.slice(0,10).map(pg => '<div class="item"><div><b>' + esc(pg.created_at) + '</b><small>' + esc(pg.latitude) + ', ' + esc(pg.longitude) + (pg.accuracy_m ? ' (±' + esc(pg.accuracy_m) + 'm)' : '') + '</small></div></div>').join('')}
        </div>
      </section>
    ` : ''}
  `;
}

// Hook into render
const trackerBaseRender = render;
render = async function() {
  if (tab === 'tracker') {
    shell(await trackerView());
    const back = root.querySelector('[data-home="home"]');
    if (back) back.onclick = goMobileTabBack;
    applyProfileNav();
    return;
  }
  const r = await trackerBaseRender();
  applyProfileNav();
  return r;
};

// Add tracker tile to owner and company dashboards
const origOwnerHome = ownerHome;
ownerHome = async function() {
  let html = await origOwnerHome();
  html = html.replace(
    '<button class="aca-tile" data-home="patients">',
    '<button class="aca-tile" data-home="tracker"><span class="aca-tile-icon mi">' + mi('map') + '</span><b>Tracker</b><small>Live location</small></button>\n      <button class="aca-tile" data-home="patients">'
  );
  return html;
};

const origCompanyHome2 = companyHome;
companyHome = async function() {
  let html = await origCompanyHome2();
  html = html.replace(
    '<button class="aca-tile" data-home="patients">',
    '<button class="aca-tile" data-home="tracker"><span class="aca-tile-icon mi">' + mi('map') + '</span><b>Tracker</b><small>Live location</small></button>\n      <button class="aca-tile" data-home="patients">'
  );
  return html;
};

// wire tracker in wireHomeActions
const origWire2 = wireHomeActions;
wireHomeActions = function() {
  origWire2();
  root.querySelectorAll('[data-home="tracker"]').forEach(el => {
    el.onclick = () => setMobileTab('tracker');
  });
};


/* ============================================================
   VITALS — generic Bluetooth reader
   Works with any band, watch or chest strap that exposes the
   standard Bluetooth SIG health services (Heart Rate 0x180D,
   Pulse Oximeter 0x1822, Thermometer 0x1809, Blood Pressure 0x1810).
   There is no vendor app, no cloud account and no paid SDK.

   Wellness estimate only — not a medical device and not for
   diagnosis, treatment or clinical decisions.
   ============================================================ */

const vitalsState = {
  patientId: null,
  patients: [],
  devices: {},
  connected: false,
  deviceName: '',
  reading: null,
  battery: null
};

function vitalsVal(v) {
  return (v === null || v === undefined || v === '') ? '—' : v;
}

window.NexusVitals = {
  onStatus: function (m) {
    const el = document.getElementById('vit-status');
    if (el) el.textContent = (m && m.message) || '';
  },
  onDevice: function (d) {
    if (!d || !d.address) return;
    vitalsState.devices[d.address] = d;
    const list = document.getElementById('vit-list');
    if (!list) return;
    const row = document.createElement('button');
    row.className = 'item';
    row.style.width = '100%';
    row.style.textAlign = 'left';
    row.innerHTML = '<div><b>' + esc(d.name || 'Unnamed device') + '</b><small>' + esc(d.address) +
      (d.rssi != null ? ' · signal ' + esc(d.rssi) + ' dBm' : '') +
      (d.hasHeartRate ? ' · heart rate' : '') +
      (d.hasPulseOx ? ' · pulse oximeter' : '') + '</small></div><span class="pill">Connect</span>';
    row.onclick = function () {
      if (!window.NexusBle) return;
      window.NexusVitals.onStatus({ message: 'Connecting to ' + (d.name || 'device') + '…' });
      window.NexusBle.connect(d.address);
    };
    list.appendChild(row);
    const empty = document.getElementById('vit-empty');
    if (empty) empty.style.display = 'none';
  },
  onConnection: function (c) {
    vitalsState.connected = !!(c && c.connected);
    vitalsState.deviceName = (c && c.name) || '';
    const name = document.getElementById('vit-devname');
    if (name) name.textContent = c && c.connected
      ? ('Connected: ' + (c.name || 'device') + (c.standard === false ? ' (no standard vitals service)' : ''))
      : 'No device connected';
    const btn = document.getElementById('vit-disconnect');
    if (btn) btn.style.display = c && c.connected ? '' : 'none';
  },
  onReading: function (r) {
    if (!r) return;
    vitalsState.reading = Object.assign({}, vitalsState.reading || {}, r);
    if (r.heart_rate) { const el = document.getElementById('vit-hr'); if (el) el.textContent = r.heart_rate; }
    if (r.spo2) { const el = document.getElementById('vit-spo2'); if (el) el.textContent = r.spo2 + '%'; }
    if (r.temperature) { const el = document.getElementById('vit-temp'); if (el) el.textContent = r.temperature + '°C'; }
    if (r.systolic && r.diastolic) {
      const el = document.getElementById('vit-bp');
      if (el) el.textContent = r.systolic + '/' + r.diastolic;
    }
    if (r.battery != null) { vitalsState.battery = r.battery; const el = document.getElementById('vit-bat'); if (el) el.textContent = r.battery + '%'; }
    const el = document.getElementById('vit-devname');
    if (el && r.device) el.textContent = 'Connected: ' + r.device;
  }
};

function vitalsStopScan() {
  try { if (window.NexusBle) window.NexusBle.stopScan(); } catch (e) {}
}

async function vitalsLoadLatest(pid) {
  if (!pid) return;
  try {
    const d = await api('/api/mobile/patients/' + pid + '/vitals');
    const last = (d.items || [])[0];
    const box = document.getElementById('vit-last');
    if (box) {
      box.innerHTML = last
        ? '<b>' + esc(vitalsVal(last.heart_rate)) + '</b> bpm · <b>' + esc(vitalsVal(last.spo2)) + '</b>% SpO2 · <b>' +
          esc(vitalsVal(last.temperature)) + '</b>°C · BP ' + esc(vitalsVal(last.blood_pressure || '—')) +
          '<br><span class="muted">Last saved ' + esc(last.recorded_at || '') + ' by ' + esc(last.recorded_by || '') + '</span>'
        : '<span class="muted">No reading saved for this patient yet.</span>';
    }
  } catch (e) {}
}

async function vitalsScreen() {
  let patients = [];
  try { const r = await api('/api/mobile/patients'); patients = r.items || []; } catch (e) {}
  vitalsState.patients = patients;

  if (!patients.length) {
    shell('<div class="hello">WELLNESS</div><h1>Vitals</h1>' +
      '<p class="sub">Connect a band, watch or chest strap and save a reading.</p>' +
      '<div class="card"><div class="empty">No patient is assigned to this device yet. Ask an administrator to link a patient, then come back.</div></div>');
    return;
  }

  const current = patients.find(function (p) { return p.id === vitalsState.patientId; }) || patients[0];
  vitalsState.patientId = current.id;

  shell(
    '<div class="hello">WELLNESS</div><h1>Vitals</h1>' +
    '<p class="sub">Any band, watch or chest strap that speaks standard Bluetooth health services.</p>' +

    '<div class="card">' +
      '<div class="aca-row"><div><div class="muted">PATIENT</div><h2>' + esc(current.first_name) + ' ' + esc(current.last_name) + '</h2></div>' +
      '<span class="pill green">' + esc(current.patient_number || '') + '</span></div>' +
      (patients.length > 1 ? '<div class="field"><label>Reading for</label><select id="vit-patient">' +
        patients.map(function (p) { return '<option value="' + p.id + '"' + (p.id === current.id ? ' selected' : '') + '>' + esc(p.first_name) + ' ' + esc(p.last_name) + '</option>'; }).join('') +
        '</select></div>' : '') +
      '<div class="smallprint" style="margin-top:8px"><b>Wellness estimate — not for clinical decisions.</b> This reads standard Bluetooth health services only. It is not a medical device and must not be used for diagnosis, treatment or emergency decisions.</div>' +
    '</div>' +

    '<section class="card">' +
      '<div class="aca-row"><div><div class="muted">BLUETOOTH</div><h2>Pair a device</h2></div><span class="pill" id="vit-dot">Ready</span></div>' +
      '<div class="muted" id="vit-devname">No device connected</div>' +
      '<div class="quick" style="margin-top:10px">' +
        '<button id="vit-scan">Scan for devices</button>' +
        '<button id="vit-stop" class="secondary">Stop scan</button>' +
        '<button id="vit-disconnect" class="secondary" style="display:none">Disconnect</button>' +
      '</div>' +
      '<div class="smallprint" id="vit-status"></div>' +
      '<div class="list" id="vit-list" style="margin-top:10px"></div>' +
      '<div class="empty" id="vit-empty">' +
        (window.NexusBle ? 'No devices found yet. Tap Scan and switch the band on.' : 'Bluetooth reading runs inside the N3XUS Android app. On a browser you can still enter readings by hand below.') +
      '</div>' +
    '</section>' +

    '<section class="card">' +
      '<div class="aca-row"><div><div class="muted">LIVE</div><h2>Current reading</h2></div><span class="pill" id="vit-bat">—</span></div>' +
      '<div class="vitals-row live">' +
        '<div class="vital"><b id="vit-hr">—</b><span>HR (bpm)</span></div>' +
        '<div class="vital"><b id="vit-spo2">—</b><span>SpO2 (%)</span></div>' +
        '<div class="vital"><b id="vit-temp">—</b><span>Temp (°C)</span></div>' +
        '<div class="vital"><b id="vit-bp">—</b><span>BP (mmHg)</span></div>' +
      '</div>' +
      '<div class="smallprint">Wellness estimate — not for clinical decisions.</div>' +
      '<div class="muted" id="vit-last" style="margin-top:8px"></div>' +
      '<button id="vit-save" style="margin-top:12px">Save this reading</button>' +
    '</section>' +

    '<section class="card">' +
      '<div class="aca-row"><div><div class="muted">MANUAL</div><h2>Enter by hand</h2></div></div>' +
      '<div class="smallprint">Use this when the band does not expose standard Bluetooth services, or when you need to file an existing reading.</div>' +
      '<div class="field"><label>Heart rate (bpm)</label><input id="vit-man-hr" inputmode="numeric" placeholder="e.g. 72"></div>' +
      '<div class="field"><label>SpO2 (%)</label><input id="vit-man-spo2" inputmode="numeric" placeholder="e.g. 97"></div>' +
      '<div class="field"><label>Temperature (°C)</label><input id="vit-man-temp" inputmode="decimal" placeholder="e.g. 36.6"></div>' +
      '<div class="field"><label>Blood pressure</label><input id="vit-man-bp" placeholder="e.g. 120/80"></div>' +
      '<div class="field"><label>Notes</label><input id="vit-man-notes" placeholder="Optional"></div>' +
      '<button id="vit-man-save" class="secondary">Save manual reading</button>' +
    '</section>'
  );

  vitalsLoadLatest(current.id);

  const sel = document.getElementById('vit-patient');
  if (sel) sel.onchange = function () {
    vitalsState.patientId = Number(sel.value);
    const p = vitalsState.patients.find(function (x) { return x.id === vitalsState.patientId; });
    if (p) {
      const h = root.querySelector('.card h2');
      if (h) h.textContent = p.first_name + ' ' + p.last_name;
      const pill = root.querySelector('.card .pill.green');
      if (pill) pill.textContent = p.patient_number || '';
    }
    vitalsLoadLatest(vitalsState.patientId);
  };

  const scan = document.getElementById('vit-scan');
  if (scan) scan.onclick = function () {
    const list = document.getElementById('vit-list');
    if (list) list.innerHTML = '';
    const empty = document.getElementById('vit-empty');
    if (empty) empty.style.display = 'none';
    if (!window.NexusBle) { window.NexusVitals.onStatus({ message: 'Bluetooth reading is only available inside the N3XUS Android app.' }); return; }
    window.NexusBle.startScan();
  };

  const stop = document.getElementById('vit-stop');
  if (stop) stop.onclick = vitalsStopScan;

  const disc = document.getElementById('vit-disconnect');
  if (disc) disc.onclick = function () { if (window.NexusBle) window.NexusBle.disconnect(); };

  const save = document.getElementById('vit-save');
  if (save) save.onclick = function () {
    const r = vitalsState.reading || {};
    vitalsSave({
      heart_rate: r.heart_rate,
      spo2: r.spo2,
      temperature: r.temperature,
      blood_pressure: (r.systolic && r.diastolic) ? (r.systolic + '/' + r.diastolic) : '',
      notes: 'Bluetooth reading' + (r.device ? ' from ' + r.device : '')
    });
  };

  const manSave = document.getElementById('vit-man-save');
  if (manSave) manSave.onclick = function () {
    vitalsSave({
      heart_rate: document.getElementById('vit-man-hr').value,
      spo2: document.getElementById('vit-man-spo2').value,
      temperature: document.getElementById('vit-man-temp').value,
      blood_pressure: document.getElementById('vit-man-bp').value,
      notes: document.getElementById('vit-man-notes').value
    });
  };
}

async function vitalsSave(payload) {
  const pid = vitalsState.patientId;
  if (!pid) { toast('Choose a patient first.'); return; }
  if (payload.heart_rate === '' && payload.spo2 === '' && payload.temperature === '' && !payload.blood_pressure) {
    toast('Enter at least one reading.');
    return;
  }
  try {
    await api('/api/mobile/patients/' + pid + '/vitals', { method: 'POST', body: JSON.stringify(payload) });
    toast('Reading saved.');
    vitalsLoadLatest(pid);
  } catch (e) {
    toast(e.message || 'Could not save the reading.');
  }
}

/* Nav: Vitals tab for the owner and company phone only. */
profileTabs.owner.push('vitals');
profileTabs.company.push('vitals');

const vitalsBaseShell = shell;
shell = function (body) {
  vitalsBaseShell(body);
  const pt = profileType();
  if (pt !== 'owner' && pt !== 'company') return;
  const nav = root.querySelector('.nav-track') || root.querySelector('.nav');
  if (!nav) return;
  const b = document.createElement('button');
  b.dataset.tab = 'vitals';
  b.className = tab === 'vitals' ? 'active' : '';
  b.innerHTML = '<span>&#10084;</span>Vitals';
  b.onclick = function () { setMobileTab('vitals'); };
  nav.appendChild(b);
  nav.style.gridTemplateColumns = 'none';
  nav.style.gridAutoFlow = 'column';
  nav.style.gridAutoColumns = 'minmax(76px,1fr)';
  nav.style.overflowX = 'auto';
  nav.style.scrollbarWidth = 'none';
};

const vitalsBaseRender = render;
render = async function () {
  if (tab === 'vitals') { await vitalsScreen(); return; }
  return vitalsBaseRender();
};

const vitalsBaseWire = wireHomeActions;
wireHomeActions = function () {
  vitalsBaseWire();
  root.querySelectorAll('[data-home="vitals"]').forEach(function (el) {
    el.onclick = function () { setMobileTab('vitals'); };
  });
};


/* SOS is the last item IN the tab bar, not a floating circle over it. A pinned
   circle sat on top of the right-hand tabs and hid them. */
const sosPinBaseShell = shell;
shell = function (body) {
  sosPinBaseShell(body);
  const nav = root.querySelector('.nav');
  if (!nav) return;
    const b = document.createElement('button');
  b.className = 'sos-tab';
  b.type = 'button';
  b.innerHTML = '<span class="mi">' + mi('sos') + '</span>SOS';
  b.setAttribute('aria-label', 'Trigger emergency SOS');
  b.onclick = function () { if (typeof triggerSOS === 'function') triggerSOS(); };
  nav.appendChild(b);
};


/* A phone user changes their own password. In-page form, never prompt():
   the Android WebView does not show JS dialogs. */
function mobilePasswordChange(){
  const wrap=document.createElement('div');
  wrap.className='modal-back';
  wrap.innerHTML='<div class="modal card"><h2>Change my password</h2>'
    +'<p class="muted">At least 4 characters. You stay signed in on this phone.</p>'
    +'<label class="field"><span>Current password</span><input type="password" id="pw-cur" autocomplete="current-password"></label>'
    +'<label class="field"><span>New password</span><input type="password" id="pw-new" autocomplete="new-password"></label>'
    +'<label class="field"><span>Repeat new password</span><input type="password" id="pw-rep" autocomplete="new-password"></label>'
    +'<button type="button" class="btn secondary full" id="pw-show">Show passwords</button>'
    +'<p class="form-error" id="pw-err" hidden></p>'
    +'<div class="modal-actions"><button class="btn secondary" id="pw-cancel">Cancel</button>'
    +'<button class="btn" id="pw-save">Save password</button></div></div>';
  document.body.appendChild(wrap);
  const showBtn=wrap.querySelector('#pw-show');
  if(showBtn)showBtn.onclick=()=>{const hidden=wrap.querySelector('#pw-new').type==='password';['#pw-cur','#pw-new','#pw-rep'].forEach(sel=>{wrap.querySelector(sel).type=hidden?'text':'password'});showBtn.textContent=hidden?'Hide passwords':'Show passwords'};
  const err=wrap.querySelector('#pw-err');
  const close=()=>wrap.remove();
  wrap.querySelector('#pw-cancel').onclick=close;
  wrap.onclick=(e)=>{if(e.target===wrap)close()};
  wrap.querySelector('#pw-save').onclick=async()=>{
    const cur=wrap.querySelector('#pw-cur').value;
    const nw=wrap.querySelector('#pw-new').value;
    const rep=wrap.querySelector('#pw-rep').value;
    const fail=(m)=>{err.textContent=m;err.hidden=false};
    err.hidden=true;
    if(!cur)return fail('Enter your current password.');
    if(nw.length<4)return fail('The new password needs at least 4 characters.');
    if(nw!==rep)return fail('The two new passwords do not match.');
    const btn=wrap.querySelector('#pw-save');btn.disabled=true;btn.textContent='Saving...';
    try{
      await api('/api/mobile/password',{method:'POST',body:JSON.stringify({current_password:cur,new_password:nw})});
      close();toast('Password changed');
    }catch(e){
      btn.disabled=false;btn.textContent='Save password';
      fail(e&&e.message?e.message:'Could not change the password.');
    }
  };
}

async function loadForms(){const el=document.getElementById('forms-list');if(!el)return;try{const r=await fetch('/forms/manifest.json',{cache:'no-store'});const items=await r.json();el.innerHTML=items.length?items.map(f=>`<div class="item"><div><b>${esc(f.title)}</b><small>${esc(f.file)}</small></div><div class="quick-grid" style="margin-top:6px"><button class="btn btn-secondary btn-small" onclick="window.open('/forms/${encodeURIComponent(f.file)}','_blank')">View / Print</button></div></div>`).join(''):'<div class="empty">No forms available.</div>';}catch(e){el.innerHTML='<div class="empty">Could not load forms.</div>';}}



let activeCall=null, callPc=null, callPollTimer=null, outgoingCall=null, callMediaStream=null, activeCallType='audio', activeCallPeerName='';
// ---- Call UI state -----------------------------------------------------------
// While a call is dialing, ringing, incoming or connected the bottom tab bar is
// hidden so it cannot sit on top of the call controls, and it comes back by
// itself the moment the call ends or is declined. Class only, no layout change.
function setCallUiActive(on){
  try{ document.documentElement.classList.toggle('br-call-active', !!on); }catch(e){}
  const overlay=document.getElementById('incoming-overlay');
  if(overlay) overlay.setAttribute('aria-hidden',on?'false':'true');
}
function myEmployeeId(){
  const e=window.employee||null;
  const v=(e && (e.id||e.employee_id)) ?? (typeof employee!=='undefined' && employee ? (employee.id||employee.employee_id) : null);
  return v==null?null:String(v);
}
// Local tones, generated on the phone: no audio files, no third-party service.
let _toneCtx=null, _toneTimer=null, _tonePattern=null;
function toneCtx(){
  if(_toneCtx) return _toneCtx;
  const AC=window.AudioContext||window.webkitAudioContext;
  if(!AC) return null;
  try{ _toneCtx=new AC(); }catch(e){ _toneCtx=null; }
  return _toneCtx;
}
function toneBeep(ctx,freq,startSec,durSec,vol){
  const o=ctx.createOscillator(), g=ctx.createGain();
  o.type='sine'; o.frequency.value=freq;
  const t0=ctx.currentTime+startSec;
  g.gain.setValueAtTime(0,t0);
  g.gain.linearRampToValueAtTime(vol,t0+0.02);
  g.gain.setValueAtTime(vol,t0+Math.max(0.03,durSec-0.03));
  g.gain.linearRampToValueAtTime(0,t0+durSec);
  o.connect(g); g.connect(ctx.destination);
  o.start(t0); o.stop(t0+durSec+0.02);
}
function startToneLoop(pattern){
  stopToneLoop();
  const ctx=toneCtx(); if(!ctx) return;
  try{ if(ctx.state==='suspended') ctx.resume(); }catch(e){}
  _tonePattern=pattern;
  const cycle=()=>{ const c=toneCtx(); if(!c||!c) return; for(const b of pattern.beeps) toneBeep(c,b.f,b.t,b.d,b.v); };
  cycle();
  _toneTimer=setInterval(cycle,pattern.period*1000);
}
function stopToneLoop(){
  if(_toneTimer){ clearInterval(_toneTimer); _toneTimer=null; }
  _tonePattern=null;
}
// Ringback on the CALLER's phone while the recipient's phone is still ringing.
function startRingback(){ startToneLoop({period:3.0,beeps:[{f:420,t:0,d:1.0,v:0.06},{f:480,t:0,d:1.0,v:0.06}]}); }
function stopRingback(){ if(_tonePattern&&_tonePattern.period===3.0) stopToneLoop(); }
// Ringtone on the RECIPIENT's phone while an incoming call is on screen.
function startRingtone(){ startToneLoop({period:2.4,beeps:[{f:660,t:0,d:0.35,v:0.09},{f:880,t:0.45,d:0.35,v:0.09},{f:660,t:0.9,d:0.35,v:0.09}]}); }
function stopRingtone(){ if(_tonePattern&&_tonePattern.period===2.4) stopToneLoop(); }

// ICE servers come from the server so calls work on mobile data, not only Wi-Fi.
let _iceCache=null, _iceAt=0;
// The relay can be added or restarted while a phone sits on the app, so the list is
// refreshed every few minutes instead of being fetched once per page load. A stale
// STUN-only list is why a call on mobile data fails with no relay candidate.
const ICE_TTL=5*60*1000;
async function iceServers(){
  if(_iceCache && (Date.now()-_iceAt)<ICE_TTL) return _iceCache;
  // The open list first: it needs no session, so a call still gets its relay
  // after the cookie expired while the app sat in the background. The signed-in
  // endpoint is the fallback, and a hard-coded STUN list only the last resort.
  for(const url of ['/api/voic3/ice-servers','/api/mobile/ice-servers','/api/voic3/ice-config']){
    try{
      const d=await api(url);
      const list=(d&&d.iceServers)||[];
      if(list.length){ _iceCache=list; _iceAt=Date.now(); return _iceCache; }
    }catch(e){ /* try the next one */ }
  }
  if(!_iceCache) _iceCache=[{urls:['stun:stun.l.google.com:19302']}];
  return _iceCache;
}
async function startCall(){
  // A picker inside the page, not prompt(): the installed app runs in a WebView
  // that does not implement JavaScript dialogs, so prompt() returned null and
  // tapping "Start a call" did nothing at all.
  let emps=[];
  try{ emps=(await api('/api/mobile/directory')).items||[]; }
  catch(e){ toast('Could not load the directory','error'); return; }
  if(!emps.length){ toast('No colleagues are available to call yet.','error'); return; }
  const rows=emps.map(e=>`<button class="btn full call-pick" data-eid="${e.employee_id||e.id}" data-name="${esc(e.name||e.employee_no)}" style="margin-bottom:8px;text-align:left">${esc(e.name||e.employee_no)}<br><small class="muted">${esc(e.employee_no)}${e.department?' · '+esc(e.department):''}</small></button>`).join('');
  shell(`<div class="hello">CALL</div><h1>Who do you want to call?</h1><p class="sub">Choose a colleague, then pick voice or video.</p><div id="call-picks">${rows}</div><button class="secondary full" id="call-cancel" style="margin-top:8px">Cancel</button>`);
  document.getElementById('call-cancel').onclick=()=>render();
  root.querySelectorAll('.call-pick').forEach(btn=>btn.onclick=()=>chooseCallType(btn.dataset.eid,btn.dataset.name));
}
async function chooseCallType(cid,name){
  shell(`<div class="hello">CALL</div><h1>${esc(name)}</h1><p class="sub">How would you like to call?</p><button class="btn full" id="call-video" style="margin-bottom:8px">Video call</button><button class="btn full" id="call-voice" style="margin-bottom:8px">Voice call</button><button class="secondary full" id="call-back">Back</button>`);
  document.getElementById('call-back').onclick=()=>startCall();
  const go=async type=>{
    activeCallType=type==='video'?'video':'audio';
    try{
      const res=await api('/api/mobile/calls',{method:'POST',body:JSON.stringify({callee_employee_id:Number(cid),call_type:type})});
      activeCall=res.id; outgoingCall=Number(cid); activeCallType=type; activeCallPeerName=String(name||'Colleague'); window._sigAfter=0;
      setMobileTab('messages',{renderPage:false}); showCallScreen(activeCallPeerName);
      setCallUiActive(true); startRingback();
      await setupCaller(res.id,type);
    }catch(e){ activeCall=null; stopRingback(); setCallUiActive(false); toast(e.message||'Could not start the call','error'); }
  };
  document.getElementById('call-video').onclick=()=>go('video');
  document.getElementById('call-voice').onclick=()=>go('audio');
}
function showCallScreen(name){
  const audioOnly=activeCallType!=='video';
  const initials=String(name||'Colleague').trim().split(/\\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase();
  shell(`<section class="mobile-call-screen" role="region" aria-label="Call"><div class="mobile-call-stage ${audioOnly?'audio-only':''}"><div class="mobile-call-avatar">${esc(initials)}</div><div class="mobile-call-status" id="mobile-call-status">${activeCall?'Calling…':'Connecting…'}</div><div class="mobile-call-name">${esc(name||'Colleague')}</div><video id="remote" autoplay playsinline ${audioOnly?'hidden':''}></video><video id="local" autoplay playsinline muted ${audioOnly?'hidden':''}></video></div><div class="mobile-call-controls"><button class="mobile-call-control" id="call-mute" type="button" aria-pressed="false">Mic on</button>${audioOnly?'':`<button class="mobile-call-control" id="call-camera" type="button" aria-pressed="false">Camera on</button>`}<button class="mobile-call-control hangup" id="end-call" type="button">End call</button></div></section>`);
  document.getElementById('end-call').onclick=endCall;
      document.getElementById('call-mute').onclick=()=>{const track=callMediaStream?.getAudioTracks()[0];if(!track){toast('Microphone is not available yet');return}track.enabled=!track.enabled;const button=document.getElementById('call-mute');button.textContent=track.enabled?'Mic on':'Mic off';button.setAttribute('aria-pressed',String(!track.enabled))};
      document.getElementById('call-camera')?.addEventListener('click',()=>{const track=callMediaStream?.getVideoTracks()[0];if(!track){toast('Camera is not available yet');return}track.enabled=!track.enabled;const button=document.getElementById('call-camera');button.textContent=track.enabled?'Camera on':'Camera off';button.setAttribute('aria-pressed',String(!track.enabled))});
  setCallUiActive(true);
}
async function setupCaller(callId,type=activeCallType){
  const pc=new RTCPeerConnection({iceServers:await iceServers()}); callPc=pc;
  const stream=await navigator.mediaDevices.getUserMedia({video:type==='video',audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});callMediaStream=stream;
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  const local=document.getElementById('local'); if(local&&!local.hidden) local.srcObject=stream;
  pc.ontrack=e=>{const r=document.getElementById('remote'); if(r&&!r.hidden) r.srcObject=e.streams[0];const status=document.getElementById('mobile-call-status');if(status)status.textContent='Connected'};
  pc.onconnectionstatechange=()=>{const status=document.getElementById('mobile-call-status');if(status&&pc.connectionState==='connected')status.textContent='Connected';if(pc.connectionState==='failed')endCall('failed')};
  pc.onicecandidate=e=>{ if(e.candidate) api(`/api/mobile/calls/${callId}/signal`,{method:'POST',body:JSON.stringify({kind:'ice',payload:JSON.stringify(e.candidate)})}).catch(()=>{}); };
  const offer=await pc.createOffer(); await pc.setLocalDescription(offer);
  await api(`/api/mobile/calls/${callId}/signal`,{method:'POST',body:JSON.stringify({kind:'offer',payload:JSON.stringify(offer)})});
  pollSignals(callId, true);
}
async function pollSignals(callId, isCaller){
  window._sigAfter=window._sigAfter||0;
  callPollTimer=setInterval(async()=>{
    try{
      const last=window._sigAfter||0;
      const r=await api(`/api/mobile/calls/${callId}/signal?after=${last}`);
      for(const sig of (r.items||[])){
        window._sigAfter=sig.id;
        const payload=JSON.parse(sig.payload);
        if(sig.kind==='offer' && !isCaller){
          if(!callPc){ const pc=new RTCPeerConnection({iceServers:await iceServers()}); callPc=pc;
            const stream=await navigator.mediaDevices.getUserMedia({video:activeCallType==='video',audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});callMediaStream=stream;
            stream.getTracks().forEach(t=>pc.addTrack(t,stream));
            const local=document.getElementById('local'); if(local&&!local.hidden) local.srcObject=stream;
            pc.ontrack=e=>{const rr=document.getElementById('remote'); if(rr&&!rr.hidden) rr.srcObject=e.streams[0];const status=document.getElementById('mobile-call-status');if(status)status.textContent='Connected'};
            pc.onicecandidate=e=>{ if(e.candidate) api(`/api/mobile/calls/${callId}/signal`,{method:'POST',body:JSON.stringify({kind:'ice',payload:JSON.stringify(e.candidate)})}).catch(()=>{}); };
          }
          await callPc.setRemoteDescription(new RTCSessionDescription(payload));
          const ans=await callPc.createAnswer(); await callPc.setLocalDescription(ans);
          await api(`/api/mobile/calls/${callId}/signal`,{method:'POST',body:JSON.stringify({kind:'answer',payload:JSON.stringify(ans)})});
          await api(`/api/mobile/calls/${callId}/answer`,{method:'POST',body:'{}'});
        } else if(sig.kind==='answer' && isCaller){
          await callPc.setRemoteDescription(new RTCSessionDescription(payload));
        } else if(sig.kind==='ice'){
          try{ await callPc.addIceCandidate(new RTCIceCandidate(payload)); }catch(e){}
        }
      }
    }catch(e){}
  },2000);
}
async function endCall(reason='completed'){
  if(callPollTimer){clearInterval(callPollTimer);callPollTimer=null;}
  if(activeCall){ try{ await api(`/api/mobile/calls/${activeCall}/end`,{method:'POST',body:JSON.stringify({reason:['completed','failed','cancelled'].includes(reason)?reason:'completed'})}); }catch(e){} }
  if(callPc){ callPc.getSenders().forEach(s=>s.track&&s.track.stop()); callPc.close(); callPc=null; }
  if(callMediaStream){callMediaStream.getTracks().forEach(t=>t.stop());callMediaStream=null;}
  activeCall=null; outgoingCall=null; window._sigAfter=0;
  stopRingback(); stopRingtone(); setCallUiActive(false);
  const overlay=document.getElementById('incoming-overlay'); if(overlay) overlay.remove();
  render();
}



let incomingPoll=null;
function startIncomingPoll(){
  if(incomingPoll) return;
  incomingPoll=setInterval(async()=>{
    try{
      const r=await api('/api/mobile/calls');
      const me=myEmployeeId();
      const mine=(r.items||[]).find(c=>me!=null&&String(c.callee_employee_id)===String(me)&&c.status==='ringing'&&String(c.caller_employee_id)!==String(me));
      if(mine && !activeCall){
        showIncoming(mine);
      }
    }catch(e){}
  },4000);
}
function showIncoming(call){
  // Never ring for a call this phone started: the event must target me as callee,
  // and a caller_employee_id equal to mine means it is my own outgoing call echoed back.
  if(!call) return;
  const me=myEmployeeId();
  const callee=call.callee_employee_id??call.callee_id;
  const caller=call.caller_employee_id??call.caller_id??call.caller?.id;
  if(me==null||callee==null||String(callee)!==String(me)||caller==null||String(caller)===String(me)) return;
  if(activeCall || document.getElementById('incoming-overlay')) return;
  activeCall=Number(call.id); activeCallType=call.call_type==='video'?'video':'audio';activeCallPeerName='Employee '+String(caller);
  setCallUiActive(true);
  const overlay=document.createElement('div');
  overlay.id='incoming-overlay';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;z-index:100';
  overlay.innerHTML=`<div class="card" style="max-width:320px;text-align:center"><h2>Incoming call</h2><p class="muted">From employee ${esc(caller)}</p><div style="display:flex;gap:8px;margin-top:12px"><button class="btn" id="ans-call" style="flex:1">Answer</button><button class="btn danger" id="dec-call" style="flex:1">Decline</button></div></div>`;
  document.body.appendChild(overlay);
  startRingtone();
  document.getElementById('ans-call').onclick=async()=>{ stopRingtone(); overlay.remove(); setMobileTab('messages',{renderPage:false}); setCallUiActive(true); showCallScreen(activeCallPeerName); try{await setupCallee(call.id)}catch(e){toast(e.message||'Could not answer the call');await endCall('failed')} };
  document.getElementById('dec-call').onclick=async()=>{ stopRingtone(); overlay.remove(); setCallUiActive(false); activeCall=null;try{ await api('/api/mobile/calls/'+call.id+'/decline',{method:'POST',body:'{}'}); }catch(e){} render()};
}
async function setupCallee(callId){
  await api('/api/mobile/calls/'+callId+'/answer',{method:'POST',body:'{}'});
  const pc=new RTCPeerConnection({iceServers:await iceServers()}); callPc=pc;
  const stream=await navigator.mediaDevices.getUserMedia({video:activeCallType==='video',audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});callMediaStream=stream;
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  const local=document.getElementById('local'); if(local&&!local.hidden) local.srcObject=stream;
  pc.ontrack=e=>{const r=document.getElementById('remote'); if(r&&!r.hidden) r.srcObject=e.streams[0];const status=document.getElementById('mobile-call-status');if(status)status.textContent='Connected'};
  pc.onconnectionstatechange=()=>{const status=document.getElementById('mobile-call-status');if(status&&pc.connectionState==='connected')status.textContent='Connected';if(pc.connectionState==='failed')endCall('failed')};
  pc.onicecandidate=e=>{ if(e.candidate) api('/api/mobile/calls/'+callId+'/signal',{method:'POST',body:JSON.stringify({kind:'ice',payload:JSON.stringify(e.candidate)})}).catch(()=>{}); };
  pollSignals(callId, false);
}

