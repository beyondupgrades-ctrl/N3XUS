/* ============================================================
   Section 12: Web Push client helper (self-hosted VAPID).

   Registers the service worker's push subscription against the
   N3XUS backend so a backgrounded or closed phone still rings for
   1:1 calls, SOS alerts and DMs. Everything is best-effort:
   - no PushManager / no VAPID keys  -> silent no-op
   - permission denied               -> silent no-op
   - older builds                    -> never called, unchanged
   ============================================================ */
(function () {
  'use strict';

  const STORE_KEY = 'br_push_endpoint';
  const state = { subscribed: false, endpoint: '', enabled: false, error: '' };

  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(base64);
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i);
    return out;
  }

  function bufferToBase64Url(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function deviceLabel() {
    const ua = navigator.userAgent || '';
    if (/Android/i.test(ua)) return 'Android';
    if (/iPhone|iPad|iPod/i.test(ua)) return 'iOS';
    if (/Windows/i.test(ua)) return 'Windows';
    if (/Mac/i.test(ua)) return 'macOS';
    return 'Browser';
  }

  function supported() {
    return !!(window.isSecureContext && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window);
  }

  async function registration() {
    if (!supported()) return null;
    const existing = await navigator.serviceWorker.getRegistration('/mobile/');
    if (existing) return existing;
    return navigator.serviceWorker.register('/mobile/sw.js', { scope: '/mobile/' });
  }

  /** Ask the backend for its VAPID key; returns '' when push is not configured. */
  async function vapidKey(api) {
    try {
      const res = await api('/api/voic3/push/vapid-public-key');
      state.enabled = !!res.enabled && !!res.publicKey;
      return res.publicKey || '';
    } catch (err) {
      state.enabled = false;
      return '';
    }
  }

  /** Subscribe (or refresh) this device. Safe to call on every sign-in. */
  async function subscribe(api, options) {
    const opts = options || {};
    if (!supported()) { state.error = 'unsupported'; return { ...state }; }
    try {
      const key = await vapidKey(api);
      if (!key) { state.error = 'vapid-not-configured'; return { ...state }; }
      let permission = Notification.permission;
      if (permission === 'default' && opts.ask !== false) permission = await Notification.requestPermission();
      if (permission !== 'granted') { state.error = 'permission-' + permission; return { ...state }; }
      const reg = await registration();
      if (!reg) { state.error = 'no-registration'; return { ...state }; }
      await navigator.serviceWorker.ready;
      let sub = await reg.pushManager.getSubscription();
      // A rotated server key (VAPID) silently breaks the old subscription: the
      // push service rejects every message signed with the new key. Drop it
      // and subscribe again with the key the server uses now.
      if (sub && sub.options && sub.options.applicationServerKey &&
          bufferToBase64Url(sub.options.applicationServerKey) !== String(key).replace(/=+$/, '')) {
        try { await sub.unsubscribe(); } catch (e) { /* already gone */ }
        sub = null;
      }
      if (!sub) {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(key)
        });
      }
      const json = sub.toJSON ? sub.toJSON() : {};
      const keys = json.keys || {};
      const p256dh = keys.p256dh || (sub.getKey ? bufferToBase64Url(sub.getKey('p256dh')) : '');
      const auth = keys.auth || (sub.getKey ? bufferToBase64Url(sub.getKey('auth')) : '');
      const res = await api('/api/voic3/push/subscribe', {
        method: 'POST',
        body: JSON.stringify({
          endpoint: sub.endpoint,
          keys: { p256dh: p256dh, auth: auth },
          device_label: deviceLabel()
        })
      });
      state.subscribed = true;
      state.endpoint = sub.endpoint;
      state.error = '';
      try { localStorage.setItem(STORE_KEY, sub.endpoint); } catch (e) { /* private mode */ }
      return { ...state, id: res && res.id };
    } catch (err) {
      state.error = String((err && err.message) || err);
      return { ...state };
    }
  }

  /** Remove this device's subscription (sign-out, or a user toggle). */
  async function unsubscribe(api) {
    try {
      const reg = await registration();
      const sub = reg ? await reg.pushManager.getSubscription() : null;
      const endpoint = (sub && sub.endpoint) || state.endpoint || '';
      if (sub) await sub.unsubscribe();
      if (endpoint && api) {
        try { await api('/api/voic3/push/unsubscribe', { method: 'DELETE', body: JSON.stringify({ endpoint: endpoint }) }); }
        catch (e) { /* older server */ }
      }
      state.subscribed = false;
      state.endpoint = '';
      try { localStorage.removeItem(STORE_KEY); } catch (e) { /* ignore */ }
      return { ...state };
    } catch (err) {
      state.error = String((err && err.message) || err);
      return { ...state };
    }
  }

  /** Close a ringing notification once the call was answered in-app. */
  function dismiss(tag) {
    try {
      const reg = navigator.serviceWorker && navigator.serviceWorker.controller;
      if (reg) reg.postMessage({ type: 'close-push', tag: tag });
    } catch (e) { /* ignore */ }
  }

  /**
   * Read the deep-link the notification action produced and hand it back once.
   * Returns { kind: 'call'|'sos'|'conversation', id, action } or null.
   */
  function consumeDeepLink() {
    try {
      const params = new URLSearchParams(location.search || '');
      const action = params.get('voic3_action') || '';
      let out = null;
      if (params.get('voic3_call')) out = { kind: 'call', id: Number(params.get('voic3_call')), action: action };
      else if (params.get('voic3_sos')) out = { kind: 'sos', id: Number(params.get('voic3_sos')), action: action };
      else if (params.get('voic3_conversation')) out = { kind: 'conversation', id: Number(params.get('voic3_conversation')), action: action || 'open' };
      if (!out) return null;
      ['voic3_call', 'voic3_sos', 'voic3_conversation', 'voic3_action'].forEach((k) => params.delete(k));
      const qs = params.toString();
      history.replaceState(null, '', location.pathname + (qs ? '?' + qs : '') + location.hash);
      return out;
    } catch (e) {
      return null;
    }
  }

  window.BR_PUSH = {
    supported: supported,
    subscribe: subscribe,
    unsubscribe: unsubscribe,
    dismiss: dismiss,
    consumeDeepLink: consumeDeepLink,
    state: state
  };
})();
