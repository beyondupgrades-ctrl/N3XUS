/* Bump this whenever the shell or its scripts change: install fetches the new
   set, activate deletes every older cache. A stale cached script is what makes
   a fixed app look like it is still broken. */
const CACHE='br-ess-shell-v8';
const SHELL=['/mobile/','/mobile/mobile.css','/mobile/mobile-theme.css','/mobile/vivid.css','/mobile/vivid-layout.css','/mobile/mobile.js','/mobile/sync.js','/mobile/push.js','/mobile/tabs-drag.js','/mobile/manifest.webmanifest','/mobile/assets/icon.svg','/icons.js','/shared/voic3_rtc.js','/shared/voic3_cards.js','/shared/voic3_offline.js','/shared/voic3_sfu.js'];
self.addEventListener('install',e=>e.waitUntil(
  // One bad URL must not stop the shell being cached, so each entry is added on its own.
  caches.open(CACHE).then(c=>Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting())
));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.origin!==self.location.origin)return;
  // Live data and calls must never be answered from the cache.
  if(u.pathname.startsWith('/api/'))return;
  if(u.pathname.startsWith('/tiles/'))return;
  if(e.request.method!=='GET')return;
  // Network-first for code and pages, cache-first for images and fonts, so a
  // slow link still paints the shell instead of a blank screen.
  const isAsset=/\.(png|jpe?g|svg|webp|ico|woff2?)$/i.test(u.pathname);
  if(isAsset){
    e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(r=>{
      if(r&&r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}
      return r;
    })));
    return;
  }
  e.respondWith(fetch(e.request).then(r=>{
    if(r&&r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}
    return r;
  }).catch(()=>caches.match(e.request).then(hit=>hit||(u.pathname.startsWith('/mobile')?caches.match('/mobile/'):undefined))));
});

/* ============================================================
   Section 12: self-hosted Web Push (VAPID).
   Ringing for incoming 1:1 calls, SOS alerts and DMs while the app
   is closed or backgrounded. Actions deep-link into the call / SOS
   view; every action still opens a window so an older client that
   does not understand the deep link simply shows its normal shell.
   ============================================================ */
function pushJson(event){
  try{return event.data?event.data.json():{};}catch(e){
    try{return {title:'VOIC3',body:event.data?event.data.text():''};}catch(e2){return {};}
  }
}

function pushUrl(payload){
  const d=(payload&&payload.data)||{};
  return d.url||payload.url||'/mobile/';
}

function openOrFocus(url){
  return self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{
    for(const c of list){
      try{
        if(new URL(c.url).origin===new URL(url,self.location.origin).origin){
          if('navigate' in c){return c.navigate(url).then(()=>c.focus().then(()=>c)).catch(()=>c.focus().then(()=>c));}
          return c.focus().then(()=>c);
        }
      }catch(e){}
    }
    return self.clients.openWindow(url);
  });
}

self.addEventListener('push',event=>{
  const payload=pushJson(event);
  const type=payload.type||'message';
  const tag=payload.tag||('voic3-'+type);
  const actions=Array.isArray(payload.actions)&&payload.actions.length?payload.actions:
    (type==='call'?[{action:'answer',title:'Answer'},{action:'decline',title:'Decline'}]:
     type==='sos'?[{action:'acknowledge',title:'Acknowledge'}]:[{action:'open',title:'Open'}]);
  const options={
    body:payload.body||'',
    tag:tag,
    renotify:payload.renotify!==false,
    requireInteraction:!!payload.requireInteraction,
    data:{url:pushUrl(payload),type:type,payload:payload.data||{}},
    icon:'/mobile/assets/icon.svg',
    badge:'/mobile/assets/icon.svg',
    actions:actions,
    vibrate:type==='call'?[500,250,500,250,500]:(type==='sos'?[300,120,300,120,300,120,300]:[120,60,120]),
    silent:false,
    timestamp:Date.now()
  };
  event.waitUntil(self.registration.showNotification(payload.title||'VOIC3',options));
});

self.addEventListener('notificationclick',event=>{
  const data=(event.notification&&event.notification.data)||{};
  const base=data.url||'/mobile/';
  const action=event.action||'';
  event.notification.close();
  let url=base;
  const join=base.indexOf('?')===-1?'?':'&';
  if(action==='answer')url=base+(join.indexOf('?')!==-1?'&':'&')+'voic3_action=answer';
  else if(action==='decline')url=base+'&voic3_action=decline';
  else if(action==='acknowledge')url=base+'&voic3_action=acknowledge';
  event.waitUntil(openOrFocus(url));
});

/* Let the page ask the worker to drop a notification once the call is answered. */
self.addEventListener('message',event=>{
  const msg=event.data||{};
  if(msg.type==='close-push'&&msg.tag){
    event.waitUntil(self.registration.getNotifications({tag:msg.tag}).then(list=>list.forEach(n=>n.close())));
  }
});
