// NEXUS — generic offline write queue (IndexedDB + ordered replay).
// Opt-in: a screen calls NexusSync.queueOp('/api/...', 'POST', {...}) for a
// write that must survive a dead connection. An item is deleted ONLY after
// the server answered 2xx. A network error or 401/403/408/429/5xx keeps it
// (and everything after it, to preserve order) for the next attempt;
// 400/404/409/422 drop it, because the server will never accept it.
(function () {
  'use strict';
  const DB_NAME = 'nexus_erp_offline';
  const DB_VERSION = 2;            // v1 stored {op:{table,data}} for a route that never existed
  const STORE = 'queue';
  const PERMANENT = [400, 404, 409, 422];
  let flushing = false;

  function openDB() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME, DB_VERSION);
      r.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (db.objectStoreNames.contains(STORE)) db.deleteObjectStore(STORE);
        db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
      };
      r.onsuccess = (e) => resolve(e.target.result);
      r.onerror = () => reject(r.error);
    });
  }
  function done(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }
  async function withStore(mode, fn) {
    const db = await openDB();
    try {
      const tx = db.transaction(STORE, mode);
      const out = fn(tx.objectStore(STORE));
      await done(tx);
      return out && typeof out.result !== 'undefined' ? out.result : out;
    } finally { db.close(); }
  }
  function uuid() {
    if (window.crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    return 'q-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }
  async function pendingCount() {
    try { return await withStore('readonly', (s) => s.count()); } catch (e) { return 0; }
  }
  async function queueOp(path, method, body) {
    if (typeof path !== 'string' || path.indexOf('/api/') !== 0) throw new Error('NexusSync: path must start with /api/');
    if (body != null && (typeof body !== 'object' || Array.isArray(body))) throw new Error('NexusSync: body must be a plain object');
    const item = { path, method: String(method || 'POST').toUpperCase(), body: body || null, key: uuid(), ts: Date.now(), attempts: 0 };
    await withStore('readwrite', (s) => s.add(item));
    flushQueue();                  // try at once; harmless when offline
    return item.key;
  }
  async function flushQueue() {
    if (flushing || navigator.onLine === false) return { sent: 0, pending: await pendingCount() };
    flushing = true;
    let sent = 0;
    try {
      const items = await withStore('readonly', (s) => s.getAll());
      for (const item of items) {
        let res;
        try {
          res = await fetch(item.path, {
            method: item.method, credentials: 'same-origin', cache: 'no-store',
            headers: { 'Content-Type': 'application/json', 'Idempotency-Key': item.key,
                       'X-Device-Key': localStorage.getItem('br_device_key') || '' },
            body: item.body == null ? undefined : JSON.stringify(Object.assign({}, item.body, { idempotency_key: item.key, queued_at: item.ts }))
          });
        } catch (e) { break; }   // no route to the server: keep this item and everything after it
        if (res.ok || PERMANENT.indexOf(res.status) !== -1) {
          if (!res.ok) console.warn('NexusSync: server rejected', item.method, item.path, res.status);
          await withStore('readwrite', (s) => s.delete(item.id));
          if (res.ok) sent++;
          continue;
        }
        item.attempts += 1; item.last_status = res.status;
        await withStore('readwrite', (s) => s.put(item));
        break;                   // 401/403/408/429/5xx: retry later, in order
      }
    } finally { flushing = false; }
    return { sent, pending: await pendingCount() };
  }
  window.NexusSync = { queueOp, flushQueue, pendingCount };
  window.addEventListener('online', () => { flushQueue(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') flushQueue(); });
  setTimeout(() => { flushQueue(); }, 4000);
})();
