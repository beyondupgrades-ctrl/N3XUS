/* ============================================================================
   N3XUS · VOIC3 & BENTO — the mobile experience layer
   ----------------------------------------------------------------------------
   Loaded after mobile.js. It adds the messaging-and-calling experience on top of
   the screens that already exist, without replacing any of them:

     · a WhatsApp/Telegram-grade VOIC3 messenger: chat list with avatars, online
       dots, unread counters and last-message previews; a conversation view with
       cream incoming and mint outgoing bubbles, date dividers, timestamps and
       read ticks; a composer with attachment and hold-to-record voice notes
     · Voice and Video buttons in every chat header, a full-screen call screen
       with a live duration timer and tactile controls, and a Calls tab with
       incoming/outgoing/missed indicators and one-tap callback
     · a Meetings picker with instant search and removable participant chips
     · the live connection state published to the page (data-conn) so the header
       chip and the Android notification show the same colour

   Everything is local: the same server routes the desktop messenger already
   uses (/api/voic3/...), no CDN, no third-party service, nothing paid.
   ========================================================================== */
(function () {
  'use strict';

  var state = {
    thread: null,        // conversation open in the thread view
    msgs: [],
    unread: {},
    calls: [],
    dir: [],
    convs: [],
    timer: null,
    ticker: null,
    poll: null,
    recording: null,     // MediaRecorder
    recChunks: [],
    recStarted: 0,
    recTimer: null
  };

  var LS_LAST_SEEN = 'n3xus_v3_lastseen';

  /* ---------------------------------------------------------------- helpers */
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function api(path, opts) {
    opts = opts || {};
    return fetch(path, {
      credentials: 'same-origin',
      cache: 'no-store',
      method: opts.method || 'GET',
      headers: { 'Content-Type': 'application/json', 'X-Device-Key': localStorage.getItem('br_device_key') || '' },
      body: opts.body
    }).then(function (r) {
      return r.text().then(function (t) {
        var d = {};
        try { d = JSON.parse(t); } catch (e) { d = {}; }
        if (!r.ok) {
          var err = new Error(d.error || ('Request failed (' + r.status + ')'));
          err.status = r.status;
          throw err;
        }
        return d;
      });
    });
  }

  function toast(msg) {
    var n = document.createElement('div');
    n.className = 'toast';
    n.textContent = msg;
    document.body.appendChild(n);
    setTimeout(function () { n.remove(); }, 2800);
  }

  function me() {
    try {
      if (window.employee && window.employee.id != null) return Number(window.employee.id);
    } catch (e) { /* not signed in */ }
    var m = document.querySelector('meta[name="n3xus-employee-id"]');
    return m ? Number(m.content) : null;
  }

  function initials(name) {
    var parts = String(name || '?').trim().split(/\s+/).filter(Boolean).slice(0, 2);
    return parts.map(function (p) { return p.charAt(0).toUpperCase(); }).join('') || '?';
  }

  function colourClass(seed) {
    var s = String(seed || '');
    var n = 0;
    for (var i = 0; i < s.length; i++) n = (n + s.charCodeAt(i)) % 6;
    return n === 0 ? '' : 'c' + (n + 1);
  }

  function timeOf(iso) {
    if (!iso) return '';
    var d = new Date(String(iso).replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  }

  function dayKey(iso) {
    var d = new Date(String(iso || '').replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }

  function dayLabel(iso) {
    var d = new Date(String(iso || '').replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    var today = new Date();
    var yest = new Date();
    yest.setDate(today.getDate() - 1);
    if (dayKey(iso) === dayKey(today.toISOString())) return 'Today';
    if (dayKey(iso) === dayKey(yest.toISOString())) return 'Yesterday';
    return d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
  }

  function shortTime(iso) {
    if (!iso) return '';
    var d = new Date(String(iso).replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    if (dayKey(iso) === dayKey(new Date().toISOString())) return timeOf(iso);
    return d.toLocaleDateString([], { day: 'numeric', month: 'short' });
  }

  function duration(seconds) {
    if (seconds == null) return '';
    var s = Math.max(0, Math.floor(seconds));
    var m = Math.floor(s / 60);
    var h = Math.floor(m / 60);
    if (h) return h + ':' + String(m % 60).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    return m + ':' + String(s % 60).padStart(2, '0');
  }

  function icon(name, size) {
    var s = size || 20;
    if (typeof window.mi === 'function') {
      // mi() returns an <svg> at 18px; re-size it through a wrapper class
      return window.mi(name).replace('width="18" height="18"', 'width="' + s + '" height="' + s + '"');
    }
    return '';
  }

  /* ------------------------------------------------------- live status chip */
  function publishConn(stateName) {
    var root = document.documentElement;
    root.setAttribute('data-conn', stateName);
    var chip = document.querySelector('.conn');
    if (!chip) return;
    var label = stateName === 'offline' ? 'Offline' : stateName === 'reconnecting' ? 'Connecting' : 'Connected';
    chip.innerHTML = '<i class="dot"></i>' + label;
    if (window.N3XUS && typeof window.N3XUS.setStatus === 'function') {
      try { window.N3XUS.setStatus(stateName); } catch (e) { /* native bridge optional */ }
    }
  }

  function watchConnection() {
    function evaluate() {
      if (!navigator.onLine) return publishConn('offline');
      api('/api/system/ping').then(function () { publishConn('connected'); })
        .catch(function (e) {
          // 401/404 still means the server answered: the network is fine.
          publishConn(e && e.status && e.status < 500 ? 'connected' : 'reconnecting');
        });
    }
    window.addEventListener('online', evaluate);
    window.addEventListener('offline', function () { publishConn('offline'); });
    evaluate();
    setInterval(evaluate, 30000);
  }

  /* ---------------------------------------------------------- chat list data */
  function loadConvs() {
    return api('/api/voic3/conversations').then(function (d) {
      state.convs = d.items || [];
      return state.convs;
    }).catch(function () { state.convs = []; return []; });
  }

  function loadDirectory() {
    if (state.dir.length) return Promise.resolve(state.dir);
    return api('/api/mobile/directory').then(function (d) {
      state.dir = (d.items || []).map(function (e) {
        return {
          id: Number(e.employee_id || e.id),
          name: e.name || ((e.first_name || '') + ' ' + (e.last_name || '')).trim() || e.employee_no,
          job: e.job_title || '',
          dept: e.department || '',
          presence: e.presence || 'offline'
        };
      });
      return state.dir;
    }).catch(function () { state.dir = []; return []; });
  }

  function presenceOf(peerId) {
    var p = state.dir.filter(function (d) { return d.id === Number(peerId); })[0];
    return (p && p.presence) || 'offline';
  }

  function convTitle(c) {
    if (c.title) return c.title;
    if (c.name) return c.name;
    var peer = (c.members || []).filter(function (m) { return m.employee_id !== me(); })[0];
    return peer ? peer.name : 'Conversation';
  }

  function convAvatar(c) {
    var peer = (c.members || []).filter(function (m) { return m.employee_id !== me(); })[0];
    var seed = peer ? peer.employee_id : c.id;
    var p = peer ? presenceOf(peer.employee_id) : 'offline';
    return '<span class="v3-av ' + colourClass(seed) + '">' + esc(initials(convTitle(c))) +
      '<i class="dot ' + (p === 'online' ? 'online' : p === 'busy' ? 'busy' : p === 'dnd' ? 'dnd' : '') + '"></i></span>';
  }

  /* ------------------------------------------------------------- VOIC3 home */
  function renderVoic3() {
    var host = document.getElementById('app');
    if (!host) return;
    var body =
      '<div class="v3-head"><div><div class="hello">VOIC3</div><h1>Messages</h1></div>' +
      '<button class="v3-icon-btn accent" id="v3-new" aria-label="Start a new chat">' + icon('plus', 20) + '</button></div>' +
      '<div class="v3-seg" role="tablist">' +
      '<button role="tab" class="on" data-v3seg="chats">Chats</button>' +
      '<button role="tab" data-v3seg="calls">Calls</button>' +
      '<button role="tab" data-v3seg="meet">Meetings</button>' +
      '</div>' +
      '<div class="v3-search">' + icon('search', 18) +
      '<input id="v3-q" type="search" placeholder="Search people, chats or calls" autocomplete="off"></div>' +
      '<div id="v3-body"><div class="empty">Loading…</div></div>';

    if (typeof window.shell === 'function') window.shell(body);
    else host.innerHTML = '<main class="content">' + body + '</main>';

    var seg = host.querySelectorAll('[data-v3seg]');
    Array.prototype.forEach.call(seg, function (b) {
      b.onclick = function () {
        Array.prototype.forEach.call(seg, function (x) { x.classList.toggle('on', x === b); });
        paintSegment(b.getAttribute('data-v3seg'));
      };
    });
    var q = host.querySelector('#v3-q');
    if (q) q.oninput = function () { paintSegment(currentSegment(), q.value.trim().toLowerCase()); };
    var nw = host.querySelector('#v3-new');
    if (nw) nw.onclick = newChatPicker;

    paintSegment('chats');
    watchConnection();
  }

  function currentSegment() {
    var on = document.querySelector('[data-v3seg].on');
    return on ? on.getAttribute('data-v3seg') : 'chats';
  }

  function paintSegment(which, q) {
    var host = document.querySelector('#v3-body');
    if (!host) return;
    if (which === 'calls') return paintCalls(host, q);
    if (which === 'meet') return paintMeetings(host, q);
    return paintChats(host, q);
  }

  /* ------------------------------------------------------------ chats list */
  function paintChats(host, q) {
    host.innerHTML = '<div class="empty">Loading…</div>';
    loadConvs().then(function (items) {
      if (q) {
        items = items.filter(function (c) {
          var hay = (convTitle(c) + ' ' + ((c.last_message && c.last_message.body) || '')).toLowerCase();
          return hay.indexOf(q) >= 0;
        });
      }
      if (!items.length) {
        host.innerHTML = '<div class="empty">No chats yet. Tap <b>+</b> to message a colleague — ' +
          'everyone you can reach is in your office directory.</div>';
        return;
      }
      host.innerHTML = '<div class="list">' + items.map(function (c) {
        var last = c.last_message || {};
        var preview = String(last.body || '').replace(/\s+/g, ' ').slice(0, 68);
        var unread = Number(c.unread || 0);
        return '<button class="v3-row ' + (unread ? 'unread' : '') + '" data-v3conv="' + c.id + '">' +
          convAvatar(c) +
          '<span class="v3-main"><b>' + esc(convTitle(c)) + '</b>' +
          '<small>' + (last.body ? esc(preview) : 'No messages yet') + '</small></span>' +
          '<span class="v3-side"><time>' + esc(shortTime(last.created_at)) + '</time>' +
          (unread ? '<span class="v3-badge">' + (unread > 99 ? '99+' : unread) + '</span>' : '') +
          '</span></button>';
      }).join('') + '</div>';

      Array.prototype.forEach.call(host.querySelectorAll('[data-v3conv]'), function (b) {
        b.onclick = function () { openThread(Number(b.getAttribute('data-v3conv'))); };
      });
    });
  }

  /* ------------------------------------------------------------ new chat */
  function newChatPicker() {
    var host = document.getElementById('app');
    if (!host) return;
    var body = '<div class="v3-head"><div><div class="hello">NEW CHAT</div><h1>Who do you want to message?</h1></div>' +
      '<button class="v3-icon-btn" id="v3-back" aria-label="Back">' + icon('close', 20) + '</button></div>' +
      '<div class="v3-search">' + icon('search', 18) +
      '<input id="v3-dq" type="search" placeholder="Search a colleague" autocomplete="off"></div>' +
      '<div id="v3-dir"><div class="empty">Loading the directory…</div></div>';
    if (typeof window.shell === 'function') window.shell(body); else host.innerHTML = '<main class="content">' + body + '</main>';
    var back = document.getElementById('v3-back');
    if (back) back.onclick = function () { renderVoic3(); };

    function paint(filter) {
      var out = document.getElementById('v3-dir');
      if (!out) return;
      var list = state.dir.filter(function (d) {
        if (!filter) return true;
        return (d.name + ' ' + d.job + ' ' + d.dept).toLowerCase().indexOf(filter) >= 0;
      });
      if (!list.length) { out.innerHTML = '<div class="empty">Nobody matches that search.</div>'; return; }
      out.innerHTML = '<div class="list">' + list.map(function (d) {
        return '<button class="v3-row" data-v3dm="' + d.id + '" data-v3name="' + esc(d.name) + '">' +
          '<span class="v3-av ' + colourClass(d.id) + '">' + esc(initials(d.name)) +
          '<i class="dot ' + (d.presence === 'online' ? 'online' : d.presence === 'busy' ? 'busy' : '') + '"></i></span>' +
          '<span class="v3-main"><b>' + esc(d.name) + '</b><small>' +
          esc([d.job, d.dept].filter(Boolean).join(' · ') || 'Colleague') + '</small></span>' +
          '</button>';
      }).join('') + '</div>';
      Array.prototype.forEach.call(out.querySelectorAll('[data-v3dm]'), function (b) {
        b.onclick = function () { startDm(Number(b.getAttribute('data-v3dm')), b.getAttribute('data-v3name')); };
      });
    }

    loadDirectory().then(function () { paint(''); });
    var q = document.getElementById('v3-dq');
    if (q) q.oninput = function () { paint(q.value.trim().toLowerCase()); };
  }

  function startDm(peerId, name) {
    api('/api/voic3/conversations', {
      method: 'POST',
      body: JSON.stringify({ kind: 'dm', members: [peerId], name: '' })
    }).then(function (r) {
      var cid = Number(r.id || (r.conversation && r.conversation.id) || 0);
      if (!cid) throw new Error('Could not open that chat.');
      openThread(cid, name);
    }).catch(function (e) { toast(e.message || 'Could not open that chat.'); });
  }

  /* -------------------------------------------------------- conversation */
  function openThread(cid, fallbackName) {
    state.thread = cid;
    state.msgs = [];
    var conv = state.convs.filter(function (c) { return Number(c.id) === Number(cid); })[0];
    var title = (conv && convTitle(conv)) || fallbackName || 'Chat';
    var peer = conv ? (conv.peer_employee_id || ((conv.members || []).filter(function (m) { return m.employee_id !== me(); })[0] || {}).employee_id) : null;

    var host = document.createElement('section');
    host.className = 'v3-thread';
    host.id = 'v3-thread';
    host.innerHTML =
      '<header class="v3-thread-head">' +
      '<button class="v3-icon-btn" id="v3-tback" aria-label="Back to chats">' + icon('close', 20) + '</button>' +
      '<span class="v3-av ' + colourClass(peer || cid) + '">' + esc(initials(title)) + '</span>' +
      '<span class="v3-main"><b>' + esc(title) + '</b><small id="v3-tpresence">' +
      (peer ? esc(presenceOf(peer) === 'online' ? 'online' : 'tap for info') : 'group chat') + '</small></span>' +
      '<button class="v3-icon-btn accent" id="v3-voice" aria-label="Voice call">' + icon('phone', 20) + '</button>' +
      '<button class="v3-icon-btn accent sky" id="v3-video" aria-label="Video call">' + icon('video', 20) + '</button>' +
      '</header>' +
      '<div class="v3-scroll" id="v3-scroll"></div>' +
      '<div class="v3-composer">' +
      '<button class="v3-icon-btn" id="v3-attach" aria-label="Attach a file">' + icon('paperclip', 20) + '</button>' +
      '<textarea id="v3-input" rows="1" placeholder="Message" aria-label="Message"></textarea>' +
      '<button class="v3-icon-btn rec" id="v3-rec" aria-label="Hold to record a voice note">' + icon('mic', 20) + '</button>' +
      '<button class="v3-icon-btn accent" id="v3-send" aria-label="Send">' + icon('send', 20) + '</button>' +
      '</div>' +
      '<input type="file" id="v3-file" hidden>';

    document.body.appendChild(host);
    document.documentElement.classList.add('br-thread-open');

    document.getElementById('v3-tback').onclick = closeThread;
    if (peer) {
      document.getElementById('v3-voice').onclick = function () { placeCall(peer, title, 'audio'); };
      document.getElementById('v3-video').onclick = function () { placeCall(peer, title, 'video'); };
    } else {
      document.getElementById('v3-voice').onclick = function () { toast('Pick one person from the chat to call.'); };
      document.getElementById('v3-video').onclick = function () { toast('Pick one person from the chat to call.'); };
    }
    wireComposer(cid);
    loadThread(cid);
    state.poll = setInterval(function () { loadThread(cid, true); }, 5000);
  }

  function closeThread() {
    var host = document.getElementById('v3-thread');
    if (host) host.remove();
    document.documentElement.classList.remove('br-thread-open');
    if (state.poll) { clearInterval(state.poll); state.poll = null; }
    stopRecording(true);
    state.thread = null;
    renderVoic3();
  }

  function loadThread(cid, quiet) {
    return api('/api/voic3/conversations/' + cid + '/messages').then(function (d) {
      state.msgs = d.items || [];
      paintThread();
      if (!quiet) {
        try {
          localStorage.setItem(LS_LAST_SEEN + ':' + cid, String(Date.now()));
        } catch (e) { /* storage full or blocked */ }
      }
    }).catch(function (e) {
      if (!quiet) {
        var s = document.getElementById('v3-scroll');
        if (s) s.innerHTML = '<div class="empty">' + esc(e.message || 'Could not load this chat.') + '</div>';
      }
    });
  }

  function paintThread() {
    var box = document.getElementById('v3-scroll');
    if (!box) return;
    var atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 90;
    var lastDay = '';
    var html = state.msgs.map(function (m) {
      var k = dayKey(m.created_at);
      var divider = k !== lastDay ? '<div class="v3-date">' + esc(dayLabel(m.created_at)) + '</div>' : '';
      lastDay = k;
      var mine = m.is_me;
      var reads = Number(m.read_count || 0);
      var ticks = mine
        ? '<span class="ticks ' + (reads ? 'read' : '') + '">' + (reads ? '✓✓' : '✓') + '</span>'
        : '';
      var body = esc(m.body);
      if (m.message_type && m.message_type !== 'text' && /^\[?voice/i.test(String(m.body))) {
        body = '<span class="mi" style="display:inline-block;vertical-align:-4px;margin-right:6px">' + icon('mic', 16) + '</span>' + body;
      }
      return divider + '<div class="v3-msg ' + (mine ? 'out' : 'in') + '">' + body +
        '<span class="meta">' + esc(timeOf(m.created_at)) + ticks + '</span></div>';
    }).join('');
    box.innerHTML = html || '<div class="empty">No messages yet. Say hello.</div>';
    if (atBottom) box.scrollTop = box.scrollHeight;
  }

  function wireComposer(cid) {
    var input = document.getElementById('v3-input');
    var send = document.getElementById('v3-send');
    var rec = document.getElementById('v3-rec');
    var attach = document.getElementById('v3-attach');
    var file = document.getElementById('v3-file');

    function doSend() {
      var text = (input.value || '').trim();
      if (!text) return;
      input.value = '';
      input.style.height = 'auto';
      sendMessage(cid, text, 'text');
    }

    if (send) send.onclick = doSend;
    if (input) {
      input.onkeydown = function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); }
      };
      input.oninput = function () {
        input.style.height = 'auto';
        input.style.height = Math.min(120, input.scrollHeight) + 'px';
      };
    }

    if (attach && file) {
      attach.onclick = function () { file.click(); };
      file.onchange = function () {
        var f = file.files && file.files[0];
        if (!f) return;
        if (f.size > 8 * 1024 * 1024) { toast('That file is larger than 8 MB.'); return; }
        var reader = new FileReader();
        reader.onload = function () {
          api('/api/voic3/attachments', {
            method: 'POST',
            body: JSON.stringify({
              filename: f.name,
              mime_type: f.type || 'application/octet-stream',
              data: reader.result
            })
          }).then(function (r) {
            return sendMessage(cid, 'Attachment · ' + f.name + ' (/api/voic3/attachments/' + r.id + ')', 'file');
          }).then(function () {
            toast('Attached: ' + f.name);
          }).catch(function (e) { toast(e.message || 'Could not attach that file.'); });
        };
        reader.readAsDataURL(f);
      };
    }

    if (rec) {
      var start = function (ev) {
        ev.preventDefault();
        beginRecording(cid, rec);
      };
      var stop = function (ev) {
        ev.preventDefault();
        stopRecording(false);
      };
      rec.addEventListener('pointerdown', start);
      rec.addEventListener('pointerup', stop);
      rec.addEventListener('pointercancel', stop);
      rec.addEventListener('pointerleave', stop);
    }
  }

  function sendMessage(cid, text, type) {
    var key = 'n3xus-' + cid + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
    return api('/api/voic3/conversations/' + cid + '/messages', {
      method: 'POST',
      body: JSON.stringify({ body: text, message_type: type || 'text', idempotency_key: key })
    }).then(function () {
      return loadThread(cid, true);
    }).catch(function (e) {
      toast(e.message || 'Message not sent.');
    });
  }

  /* ------------------------------------------------------- voice notes */
  function beginRecording(cid, btn) {
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      toast('Voice notes need microphone access on this phone.');
      return;
    }
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      state.recChunks = [];
      state.recStarted = Date.now();
      var mr = new MediaRecorder(stream);
      state.recording = mr;
      mr.ondataavailable = function (e) { if (e.data && e.data.size) state.recChunks.push(e.data); };
      mr.onstop = function () {
        stream.getTracks().forEach(function (t) { t.stop(); });
        var secs = Math.max(1, Math.round((Date.now() - state.recStarted) / 1000));
        var blob = new Blob(state.recChunks, { type: mr.mimeType || 'audio/webm' });
        state.recording = null;
        if (btn) btn.classList.remove('live');
        if (secs < 1 || !blob.size) return;
        var reader = new FileReader();
        reader.onload = function () {
          api('/api/voic3/attachments', {
            method: 'POST',
            body: JSON.stringify({
              filename: 'voice-note-' + secs + 's.webm',
              mime_type: blob.type || 'audio/webm',
              data: reader.result
            })
          }).then(function () {
            return sendMessage(cid, 'Voice note · ' + duration(secs), 'voice');
          }).catch(function (e) { toast(e.message || 'Voice note not sent.'); });
        };
        reader.readAsDataURL(blob);
      };
      mr.start();
      if (btn) btn.classList.add('live');
      state.recTimer = setInterval(function () {
        if (btn) btn.setAttribute('aria-label', 'Recording ' + duration((Date.now() - state.recStarted) / 1000));
      }, 500);
    }).catch(function () {
      toast('Microphone permission was refused, so no voice note was recorded.');
    });
  }

  function stopRecording(silent) {
    if (state.recTimer) { clearInterval(state.recTimer); state.recTimer = null; }
    var mr = state.recording;
    if (!mr) return;
    if (silent && mr.state !== 'inactive') {
      state.recChunks = [];
      try { mr.stop(); } catch (e) { /* already stopped */ }
      return;
    }
    try { mr.stop(); } catch (e) { /* already stopped */ }
  }

  /* ------------------------------------------------------------- calls log */
  function paintCalls(host, q) {
    host.innerHTML = '<div class="empty">Loading calls…</div>';
    api('/api/voic3/calls').then(function (d) {
      var items = d.items || [];
      if (q) {
        items = items.filter(function (c) {
          return String(c.other_name || '').toLowerCase().indexOf(q) >= 0;
        });
      }
      if (!items.length) {
        host.innerHTML = '<div class="empty">No calls yet. Open a chat and tap the phone or camera button to call.</div>';
        return;
      }
      host.innerHTML = '<div class="list">' + items.map(function (c) {
        var missed = String(c.status) === 'missed' || (!c.answered_at && String(c.status) === 'ended');
        var kind = missed ? 'missed' : (c.direction === 'outgoing' ? 'out' : 'in');
        var kindLabel = missed ? 'Missed' : (c.direction === 'outgoing' ? 'Outgoing' : 'Incoming');
        var extra = c.duration_seconds != null ? ' · ' + duration(c.duration_seconds)
          : (c.call_type === 'video' ? ' · video' : ' · voice');
        return '<div class="v3-callrow">' +
          '<span class="v3-av ' + colourClass(c.other_employee_id) + '">' + esc(initials(c.other_name)) + '</span>' +
          '<span class="v3-main"><b>' + esc(c.other_name || 'Colleague') + '</b>' +
          '<small><span class="kind ' + kind + '">' + kindLabel + '</span>' + esc(extra) +
          ' · ' + esc(shortTime(c.created_at)) + '</small></span>' +
          '<span class="v3-side">' +
          '<button class="v3-icon-btn accent" data-v3call="' + c.other_employee_id + '" data-v3cname="' + esc(c.other_name || '') +
          '" data-v3ctype="audio" aria-label="Call back">' + icon('phone', 18) + '</button>' +
          '<button class="v3-icon-btn accent sky" data-v3call="' + c.other_employee_id + '" data-v3cname="' + esc(c.other_name || '') +
          '" data-v3ctype="video" aria-label="Video call back">' + icon('video', 18) + '</button>' +
          '</span></div>';
      }).join('') + '</div>';

      Array.prototype.forEach.call(host.querySelectorAll('[data-v3call]'), function (b) {
        b.onclick = function () {
          placeCall(Number(b.getAttribute('data-v3call')), b.getAttribute('data-v3cname'), b.getAttribute('data-v3ctype'));
        };
      });
    }).catch(function (e) {
      host.innerHTML = '<div class="empty">' + esc(e.message || 'Could not load the call log.') + '</div>';
    });
  }

  /* ------------------------------------------------------------- meetings */
  function paintMeetings(host, q) {
    var selected = [];
    host.innerHTML =
      '<div class="card emerald" style="margin-bottom:12px"><h3>Start a meeting</h3>' +
      '<p class="muted">Pick the people to invite. Everyone gets a call from the meeting, not from you.</p></div>' +
      '<div class="v3-search">' + icon('search', 18) +
      '<input id="v3-mq" type="search" placeholder="Search colleagues to invite" autocomplete="off"></div>' +
      '<div id="v3-chips" class="list" style="flex-direction:row;flex-wrap:wrap;gap:8px"></div>' +
      '<div id="v3-mlist" class="list" style="margin-top:10px"><div class="empty">Loading…</div></div>' +
      '<button class="btn full" id="v3-mgo" style="margin-top:14px">Start meeting</button>';

    var chips = document.getElementById('v3-chips');
    var list = document.getElementById('v3-mlist');
    var go = document.getElementById('v3-mgo');

    function paintChips() {
      chips.innerHTML = selected.map(function (p) {
        return '<span class="v3-chip">' + esc(p.name) +
          '<button data-v3rm="' + p.id + '" aria-label="Remove ' + esc(p.name) + '">×</button></span>';
      }).join('');
      Array.prototype.forEach.call(chips.querySelectorAll('[data-v3rm]'), function (b) {
        b.onclick = function () {
          var id = Number(b.getAttribute('data-v3rm'));
          selected = selected.filter(function (p) { return p.id !== id; });
          paintChips();
          paintList(lastFilter);
        };
      });
    }

    var lastFilter = q || '';
    function paintList(filter) {
      lastFilter = filter || '';
      var f = lastFilter.toLowerCase();
      var rows = state.dir.filter(function (d) {
        return !f || (d.name + ' ' + d.job + ' ' + d.dept).toLowerCase().indexOf(f) >= 0;
      });
      if (!rows.length) { list.innerHTML = '<div class="empty">Nobody matches that search.</div>'; return; }
      list.innerHTML = rows.map(function (d) {
        var on = selected.some(function (p) { return p.id === d.id; });
        return '<button class="v3-row" data-v3pick="' + d.id + '">' +
          '<span class="v3-av ' + colourClass(d.id) + '">' + esc(initials(d.name)) + '</span>' +
          '<span class="v3-main"><b>' + esc(d.name) + '</b><small>' +
          esc([d.job, d.dept].filter(Boolean).join(' · ') || 'Colleague') + '</small></span>' +
          '<span class="pill ' + (on ? 'green' : '') + '">' + (on ? 'Invited' : 'Invite') + '</span></button>';
      }).join('');
      Array.prototype.forEach.call(list.querySelectorAll('[data-v3pick]'), function (b) {
        b.onclick = function () {
          var id = Number(b.getAttribute('data-v3pick'));
          var person = state.dir.filter(function (d) { return d.id === id; })[0];
          if (!person) return;
          if (selected.some(function (p) { return p.id === id; })) {
            selected = selected.filter(function (p) { return p.id !== id; });
          } else {
            selected.push({ id: id, name: person.name });
          }
          paintChips();
          paintList(lastFilter);
        };
      });
    }

    loadDirectory().then(function () { paintList(q || ''); paintChips(); });
    var mq = document.getElementById('v3-mq');
    if (mq) mq.oninput = function () { paintList(mq.value); };

    if (go) {
      go.onclick = function () {
        if (!selected.length) { toast('Pick at least one person to invite.'); return; }
        go.disabled = true;
        // The server makes the meeting, then a second call adds the invitees:
        // each of them gets a meeting.invite event and a push notification.
        api('/api/voic3/meetings', {
          method: 'POST',
          body: JSON.stringify({ title: 'N3XUS meeting' })
        }).then(function (r) {
          var mid = Number(r.id || 0);
          if (!mid) throw new Error('The meeting could not be created.');
          return api('/api/voic3/meetings/' + mid + '/invite', {
            method: 'POST',
            body: JSON.stringify({ employee_ids: selected.map(function (p) { return p.id; }) })
          }).then(function (inv) {
            var code = r.code || '';
            var n = (inv && inv.added) ? inv.added.length : selected.length;
            toast('Meeting started with ' + n + (n === 1 ? ' person' : ' people') +
              (code ? ' · code ' + code : ''));
            if (window.Meetings && typeof window.Meetings.open === 'function') {
              try { window.Meetings.open(mid); } catch (e) { /* desktop-only view */ }
            }
          });
        }).catch(function (e) {
          toast(e.message || 'Could not start the meeting.');
        }).then(function () { go.disabled = false; });
      };
    }
  }

  /* ------------------------------------------------------- placing a call */
  function placeCall(calleeId, name, type) {
    if (!calleeId) { toast('That person cannot be called right now.'); return; }
    if (typeof window.startCall !== 'function') { toast('Calling is not available in this build.'); return; }
    // The existing call engine does the ringing, WebRTC and cleanup. We only
    // make sure the right person is dialled and the navigation is hidden while
    // the call is up (html.br-call-active, styled in bento.css).
    var peer = Number(calleeId);
    try {
      var mine = me();
      if (mine != null && peer === mine) { toast('You cannot call yourself.'); return; }
    } catch (e) { /* no session yet */ }

    api('/api/mobile/calls', {
      method: 'POST',
      body: JSON.stringify({ callee_employee_id: peer, call_type: type === 'video' ? 'video' : 'audio' })
    }).then(function (res) {
      document.documentElement.classList.add('br-call-active');
      startCallTicker();
      // The call engine that already ships with the app owns the WebRTC session,
      // the ringback tone and the cleanup. If it exposes its caller entry point
      // we hand the call straight to it; otherwise the ringing call is shown
      // with the standard screen and ended through the same route.
      if (typeof window.startOutgoingCall === 'function') {
        try { window.startOutgoingCall(res.id, peer, name || 'Colleague', type); return; } catch (e) { /* fall through */ }
      }
      if (typeof window.showCallScreen === 'function') {
        window.showCallScreen(name || 'Colleague');
      }
      if (typeof window.startRingback === 'function') { try { window.startRingback(); } catch (e) { /* no audio context */ } }
    }).catch(function (e) {
      document.documentElement.classList.remove('br-call-active');
      stopCallTicker();
      toast(e.message || 'Could not place the call.');
    });
  }

  function startCallTicker() {
    stopCallTicker();
    var t0 = Date.now();
    state.ticker = setInterval(function () {
      var el = document.getElementById('mobile-call-status');
      if (!el) { stopCallTicker(); return; }
      var label = el.getAttribute('data-state');
      if (label === 'connected') el.textContent = duration((Date.now() - t0) / 1000);
    }, 1000);
  }

  function stopCallTicker() {
    if (state.ticker) { clearInterval(state.ticker); state.ticker = null; }
  }

  /* ------------------------------------------------------------- wire-up */
  function boot() {
    // The VOIC3 tab in the existing navigation now opens the messenger.
    document.addEventListener('click', function (e) {
      var b = e.target && e.target.closest && e.target.closest('[data-tab="messages"]');
      if (!b) return;
      e.preventDefault();
      e.stopPropagation();
      renderVoic3();
    }, true);

    // Calls end (or are declined) → the navigation comes back.
    var obs = new MutationObserver(function () {
      if (!document.querySelector('.mobile-call-screen') && !document.getElementById('incoming-overlay')) {
        document.documentElement.classList.remove('br-call-active');
        stopCallTicker();
      }
    });
    obs.observe(document.body, { childList: true, subtree: true });

    publishConn(navigator.onLine ? 'connected' : 'offline');
    watchConnection();
  }

  /**
   * The caller entry point the call engine did not expose: the VOIC3 buttons call
   * it with a call the server has already created. It sets up the outgoing
   * WebRTC session, shows the call screen and starts the ringback tone, and it
   * never rings this device — the server only rings the callee.
   */
  window.startOutgoingCall = function (callId, peerId, name, type) {
    if (typeof window.showCallScreen === 'function') window.showCallScreen(name || 'Colleague');
    if (typeof window.startRingback === 'function') { try { window.startRingback(); } catch (e) { /* no audio context */ } }
    if (typeof window.setupCaller === 'function') {
      Promise.resolve(window.setupCaller(callId, type === 'video' ? 'video' : 'audio'))
        .catch(function (e) { toast(e.message || 'The call could not start.'); });
    }
  };

  window.N3XUS_VOIC3 = {
    render: renderVoic3,
    openThread: openThread,
    closeThread: closeThread,
    call: placeCall,
    status: publishConn
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
