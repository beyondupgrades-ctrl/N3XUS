/*
 * N3XUS — the last word on layout.
 *
 * nexus-cream-bento.css brings the warm cream canvas, the Bento cards, the
 * navigation pills and the VOIC3 bubbles. This file only makes sure the pieces
 * built by bento.js / bento-home.js actually wear those classes and sit on the
 * right rows, without touching any data, any endpoint or any call signalling:
 * it adds class names to elements that already exist.
 *
 * No fetch, no storage, no external file. It only looks at what is on the page.
 */
(function () {
  'use strict';

  /* ---- 1. The app's own bottom bar wears the cream pills --------------- */
  function styleNav() {
    var nav = document.querySelector('.nav, .bottom-nav, .nav-bar, .mobile-nav, #bottom-nav');
    if (!nav) return;
    nav.classList.add('nexus-bottom-nav');

    var buttons = nav.querySelectorAll('button, .nav-item, [data-tab]');
    Array.prototype.forEach.call(buttons, function (btn) {
      if (btn.dataset && btn.dataset.creamPill === '1') return;
      btn.dataset.creamPill = '1';

      var tab = (btn.dataset && btn.dataset.tab) || btn.getAttribute('data-tab') || '';
      if (!tab) {
        var label = (btn.textContent || '').trim().toLowerCase();
        if (label.indexOf('home') === 0) tab = 'home';
        else if (label.indexOf('patient') === 0) tab = 'patients';
        else if (label.indexOf('voic3') === 0) tab = 'messages';
        else if (label.indexOf('more') === 0) tab = 'more';
      }
      if (tab) btn.setAttribute('data-tab', tab);
      btn.classList.add('nav-pill');
    });
  }

  /* ---- 2. A live call hides the bar (both markers, belt and braces) ---- */
  function watchCall() {
    var body = document.body;
    var apply = function () {
      var live = body.classList.contains('br-call-active')
        || body.classList.contains('in-call')
        || !!document.querySelector('.voic3-call-overlay, .mobile-call-screen.show');
      body.classList.toggle('in-call', live);
      var nav = document.querySelector('.nexus-bottom-nav');
      if (nav) nav.classList.toggle('hidden-in-call', live);
    };
    apply();
    if (window.__n3xusCreamObserver) return;
    var obs = new MutationObserver(apply);
    obs.observe(body, { attributes: true, attributeFilter: ['class'] });
    window.__n3xusCreamObserver = obs;
  }

  /* ---- 3. Give the Bento screens their grid and their tints ------------ */
  function styleBento() {
    // The home screen's stat tiles and action tiles become Bento cards.
    var selectors = [
      '.home-tiles > *',
      '.stat-tiles > *',
      '.quick-actions > *',
      '.action-grid > *',
      '.home-grid > *'
    ];
    selectors.forEach(function (sel) {
      Array.prototype.forEach.call(document.querySelectorAll(sel), function (el) {
        if (el.dataset.creamCard === '1') return;
        el.dataset.creamCard = '1';
        el.classList.add('bento-card');
        var text = (el.textContent || '').toLowerCase();
        if (/leave|payslip/.test(text)) el.classList.add('tint-emerald');
        else if (/document|vault/.test(text)) el.classList.add('tint-sky');
        else if (/request|report/.test(text)) el.classList.add('tint-amber');
        else if (/alert|fault|issue/.test(text)) el.classList.add('tint-coral');
      });
    });
  }

  /* ---- 4. The live connection light, in the header --------------------- */
  function paintConnection() {
    var chip = document.querySelector('.nexus-conn-light');
    if (!chip) return;
    var state = 'offline';
    if (navigator.onLine === false) state = 'offline';
    else if (chip.dataset.conn === 'connected') state = 'connected';
    else if (chip.dataset.conn === 'reconnecting' || chip.dataset.conn === 'connecting') state = 'connecting';
    else if (chip.dataset.conn) state = 'connected';
    chip.setAttribute('data-state', state);
    chip.setAttribute('data-conn', state === 'connected' ? 'connected'
      : state === 'connecting' ? 'reconnecting' : 'offline');
  }

  function run() {
    styleNav();
    watchCall();
    styleBento();
    paintConnection();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
  // The screens are redrawn as data arrives; re-apply, cheaply and idempotently.
  window.addEventListener('load', run);
  setInterval(run, 2500);
})();
