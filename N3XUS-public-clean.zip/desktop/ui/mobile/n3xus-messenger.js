/*
 * N3XUS 5.7.0 — VOIC3 as a WhatsApp-style messenger.
 *
 * Two screens:
 *   1. Chats  — search, filter chips (All / Unread / Groups / Alerts), contact rows
 *   2. Thread — WhatsApp-style header with voice + video call, bubble canvas, composer
 *
 * It is a view layer only. It reads the endpoints the app already had:
 *   GET  /api/mobile/messages      the person's inbox (hub_messages)
 *   POST /api/mobile/messages      staff -> management, admin -> chosen person
 *   GET  /api/mobile/directory     colleagues, for "new chat"
 *   GET  /api/mobile/calls         call history, so a thread can show its calls
 *   POST /api/mobile/calls         start a voice or video call
 * Nothing is invented: a row is a real conversation, a bubble is a real message.
 */
(function () {
  'use strict';

  var ICON = {
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2z"/>',
    paperclip: '<path d="m21.4 11.1-8.5 8.5a5.5 5.5 0 0 1-7.8-7.8l9.2-9.2a3.7 3.7 0 0 1 5.2 5.2l-9.2 9.2a1.9 1.9 0 0 1-2.6-2.6l8.5-8.5"/>',
    send: '<path d="m22 2-7 20-4-9-9-4 20-7Z"/><path d="M22 2 11 13"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"/>',
    alert: '<path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 2.4 17.4A1.9 1.9 0 0 0 4 20.3h16a1.9 1.9 0 0 0 1.6-2.9L13.7 3.9a1.9 1.9 0 0 0-3.4 0z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/>',
    message: '<path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 9.9 9.9 0 0 1-4.2-.9L3 21l1.9-4.5A8.4 8.4 0 0 1 12 3a8.4 8.4 0 0 1 9 8.5z"/>'
  };

  function svg(name, cls) {
    return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" width="20" height="20" fill="none" ' +
      'stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" ' +
      'aria-hidden="true">' + (ICON[name] || ICON.message) + '</svg>';
  }

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function api(path, opts) {
    // The app's own helper when it is there (it carries the device key).
    if (typeof window.api === 'function') return window.api(path, opts);
    return fetch(path, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, opts || {}))
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (d) {
          if (!r.ok) { var e = new Error(d.error || ('Request failed (' + r.status + ')')); e.status = r.status; throw e; }
          return d;
        });
      });
  }

  /* ------------------------------------------------------------- helpers */
  function initials(name) {
    var parts = String(name || '?').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '?';
    return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
  }

  function whenLabel(iso) {
    if (!iso) return '';
    var d = new Date(String(iso).replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    var now = new Date();
    var sameDay = d.toDateString() === now.toDateString();
    if (sameDay) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    var yesterday = new Date(now.getTime() - 86400000);
    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return d.toLocaleDateString([], { day: 'numeric', month: 'short' });
  }

  function dayLabel(iso) {
    var d = new Date(String(iso).replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    var now = new Date();
    if (d.toDateString() === now.toDateString()) return 'Today';
    return d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
  }

  var ALERT_RE = /sos|emergency|alert|leave|stock|order|request|fault|incident|payslip/i;

  function isAlert(m) {
    var subject = String(m.subject || '');
    var sender = String(m.sender || '');
    return ALERT_RE.test(subject) || /^(sos|system|ops|management|alerts?)$/i.test(sender);
  }

  function isGroup(m) {
    var label = String(m.recipient_label || '');
    var dept = String(m.department || '');
    return /all employees|company-wide|department|broadcast|everyone/i.test(label + ' ' + dept) ||
      /^(management|owners|management \/ owners)$/i.test(String(m.sender || ''));
  }

  /* A thread is a person or a group. The server resolves account keys such as
     "mobile:001" to real names (sender_name / recipient_name); this picks the
     right one and falls back to the raw key only if that lookup was empty. */
  function meNo() {
    var me = state.me || {};
    return String(me.employee_no || me.employeeNo || '');
  }

  function personName(m) {
    var name = String(m.sender_name || m.sender || 'Management');
    var mine = meNo();
    if (/^mobile:/i.test(name) && mine && name.toLowerCase() === 'mobile:' + mine.toLowerCase()) {
      return String((state.me && (state.me.name || state.me.full_name)) || 'You');
    }
    return name;
  }

  function otherName(m) {
    var mine = meNo();
    if (mine && String(m.sender || '').toLowerCase() === 'mobile:' + mine.toLowerCase()) {
      return String(m.recipient_name || m.recipient_label || 'Management');
    }
    return personName(m);
  }

  function withNo(name, m) {
    /* Directory match so the avatar and the call buttons know the account. */
    var clean = String(name || '').trim().toLowerCase();
    var hit = (state.directory || []).filter(function (e) {
      return String(e.name || '').trim().toLowerCase() === clean;
    })[0];
    if (hit) return hit;
    var raw = String((m && m.sender) || '').toLowerCase();
    if (raw.indexOf('mobile:') === 0) {
      var key = raw.slice(7);
      return (state.directory || []).filter(function (e) {
        return String(e.employee_no || '').toLowerCase() === key;
      })[0] || null;
    }
    return null;
  }

  /* ------------------------------------------------------------- state */
  var state = {
    filter: 'all',
    query: '',
    inbox: [],
    directory: [],
    me: null,
    calls: [],
    open: null,      // { key, name, sub, alert, group }
    loaded: false
  };

  function root() { return document.getElementById('app') || document.body; }

  /* ------------------------------------------------------- data loading */
  function load() {
    return Promise.all([
      api('/api/mobile/messages').catch(function () { return { items: [] }; }),
      api('/api/mobile/directory').catch(function () { return { items: [] }; }),
      api('/api/mobile/me').catch(function () { return {}; }),
      api('/api/mobile/calls').catch(function () { return { items: [] }; })
    ]).then(function (out) {
      state.inbox = (out[0] && out[0].items) || [];
      state.directory = (out[1] && out[1].items) || [];
      state.me = (out[2] && (out[2].employee || out[2].me || out[2])) || null;
      state.calls = (out[2] && out[2].items) || [];
      state.loaded = true;
    });
  }

  /* --------------------------------------------------- conversations */
  function conversations() {
    var map = Object.create(null);
    var list = [];

    function push(key, conv) {
      if (map[key]) {
        var existing = map[key];
        existing.messages.push.apply(existing.messages, conv.messages);
        existing.unread += conv.unread;
        if (conv.lastAt > existing.lastAt) existing.lastAt = conv.lastAt;
        return;
      }
      map[key] = conv;
      list.push(conv);
    }

    state.inbox.forEach(function (m) {
      var sender = personName(m);
      var group = isGroup(m);
      var alert = isAlert(m);
      var person = otherName(m);
      var key = group ? 'group:' + sender : alert ? 'alert:' + sender : 'person:' + person;
      var who = withNo(person, m);
      push(key, {
        key: key,
        name: group ? (sender === 'Management / Owners' ? 'Management' : sender) : person,
        employeeId: who ? who.employee_id : null,
        employeeNo: who ? who.employee_no : '',
        sub: group ? 'Group · office updates' : (alert ? 'Alerts and requests' : 'Beyond Registration'),
        group: group,
        alert: alert,
        unread: m.read_at ? 0 : 1,
        lastAt: m.created_at || '',
        messages: [m]
      });
    });

    // Calls belong in the thread of the other person.
    state.calls.forEach(function (c) {
      var other = c.caller_employee_id && c.callee_employee_id ? 'Colleague' : 'Colleague';
      var key = 'person:' + other;
      if (!map[key]) {
        push(key, { key: key, name: other, sub: 'Voice and video calls', group: false, alert: false, unread: 0, lastAt: c.created_at || '', messages: [], calls: [] });
      }
      map[key].calls = map[key].calls || [];
      map[key].calls.push(c);
    });

    list.forEach(function (conv) {
      conv.messages.sort(function (a, b) { return String(a.created_at).localeCompare(String(b.created_at)); });
      var last = conv.messages[conv.messages.length - 1];
      conv.preview = last ? String(last.body || '').replace(/\s+/g, ' ').slice(0, 120) : 'No messages yet';
      conv.time = whenLabel(conv.lastAt);
      conv.outgoing = last ? !!(last.recipient_label) : false;
    });

    list.sort(function (a, b) { return String(b.lastAt).localeCompare(String(a.lastAt)); });
    return list;
  }

  function visible(list) {
    var q = state.query.trim().toLowerCase();
    return list.filter(function (c) {
      if (state.filter === 'unread' && !c.unread) return false;
      if (state.filter === 'groups' && !c.group) return false;
      if (state.filter === 'alerts' && !c.alert) return false;
      if (q && (c.name + ' ' + c.preview + ' ' + c.sub).toLowerCase().indexOf(q) < 0) return false;
      return true;
    });
  }

  /* ============================================== SCREEN 1: CHATS LIST == */
  function chatsMarkup() {
    var list = visible(conversations());
    var chips = [['all', 'All'], ['unread', 'Unread'], ['groups', 'Groups'], ['alerts', 'Alerts']];
    var rows = list.map(function (c) {
      var av = c.group ? 'group' : c.alert ? 'alert' : '';
      var avIcon = c.group ? svg('users') : c.alert ? svg('alert') : esc(initials(c.name));
      var ticks = c.outgoing ? '<span class="n3x-ticks read">\u2713\u2713</span>' : '';
      var badge = c.unread ? '<span class="n3x-badge">' + (c.unread > 9 ? '9+' : c.unread) + '</span>' : '';
      return '<button class="n3x-row" type="button" data-n3x-open="' + esc(c.key) + '">' +
        '<span class="n3x-av ' + av + '">' + avIcon + '</span>' +
        '<span class="n3x-row-main">' +
        '<span class="n3x-row-top"><span class="n3x-row-name">' + esc(c.name) + '</span>' +
        '<span class="n3x-row-time">' + esc(c.time) + '</span></span>' +
        '<span class="n3x-row-sub"><span class="n3x-row-preview">' + esc(c.preview) + '</span>' + ticks + badge + '</span>' +
        '</span></button>';
    }).join('');

    return '<section class="n3x-chats">' +
      '<div class="n3x-chats-head">' +
      // A real link to #home: the app already listens for hashchange, so this
      // works even if every script-level route is unavailable.
      '<a class="n3x-dash" id="n3x-dash" href="#home" role="button" aria-label="Back to the staff dashboard">' +
      '<span aria-hidden="true">\u2190</span> Dashboard</a>' +
      '<h1>Chats</h1>' +
      '<button class="n3x-newchat" type="button" id="n3x-newchat" aria-label="Start a new chat">' + svg('plus') + '</button></div>' +
      '<label class="n3x-search">' + svg('search') +
      '<input id="n3x-search" type="search" placeholder="Search or start a new chat" value="' + esc(state.query) + '" autocomplete="off"></label>' +
      '<div class="n3x-filters" role="tablist">' +
      chips.map(function (c) {
        return '<button class="n3x-chip" type="button" role="tab" data-n3x-filter="' + c[0] + '" ' +
          'aria-selected="' + (state.filter === c[0] ? 'true' : 'false') + '">' + c[1] + '</button>';
      }).join('') +
      '</div>' +
      '<div class="n3x-rows">' +
      (rows || '<div class="n3x-empty">No conversations yet. Tap + to start a chat, or send a message from the dashboard.</div>') +
      '</div></section>';
  }

  function bindChats() {
    var app = root();
    app.querySelectorAll('[data-n3x-filter]').forEach(function (b) {
      b.onclick = function () { state.filter = b.dataset.n3xFilter; paintChats(); };
    });
    var search = app.querySelector('#n3x-search');
    if (search) {
      search.oninput = function () {
        state.query = search.value;
        var rows = app.querySelector('.n3x-rows');
        var list = visible(conversations());
        if (rows) {
          rows.innerHTML = list.length ? list.map(rowMarkup).join('') :
            '<div class="n3x-empty">No conversation matches that search.</div>';
          bindRows();
        }
      };
    }
    var add = app.querySelector('#n3x-newchat');
    if (add) add.onclick = newChatPicker;
    var dash = app.querySelector('#n3x-dash');
    if (dash) {
      dash.addEventListener('click', function (ev) {
        ev.preventDefault();
        goDashboard();
      }, true);
    }
    wireBackButton();
    bindRows();
  }

  function rowMarkup(c) {
    var av = c.group ? 'group' : c.alert ? 'alert' : '';
    var avIcon = c.group ? svg('users') : c.alert ? svg('alert') : esc(initials(c.name));
    var ticks = c.outgoing ? '<span class="n3x-ticks read">\u2713\u2713</span>' : '';
    var badge = c.unread ? '<span class="n3x-badge">' + (c.unread > 9 ? '9+' : c.unread) + '</span>' : '';
    return '<button class="n3x-row" type="button" data-n3x-open="' + esc(c.key) + '">' +
      '<span class="n3x-av ' + av + '">' + avIcon + '</span>' +
      '<span class="n3x-row-main"><span class="n3x-row-top">' +
      '<span class="n3x-row-name">' + esc(c.name) + '</span><span class="n3x-row-time">' + esc(c.time) + '</span></span>' +
      '<span class="n3x-row-sub"><span class="n3x-row-preview">' + esc(c.preview) + '</span>' + ticks + badge + '</span></span></button>';
  }

  function bindRows() {
    root().querySelectorAll('[data-n3x-open]').forEach(function (b) {
      b.onclick = function () {
        var key = b.dataset.n3xOpen;
        var conv = conversations().filter(function (c) { return c.key === key; })[0];
        if (conv) openThread(conv);
      };
    });
  }

  /* --------------------------------------------------- new chat picker */
  function newChatPicker() {
    var rows = state.directory.map(function (e) {
      var name = e.name || ((e.first_name || '') + ' ' + (e.last_name || '')).trim() || e.employee_no;
      return '<button class="n3x-row" type="button" data-n3x-pick="' + esc(e.employee_id || e.id) + '" ' +
        'data-n3x-name="' + esc(name) + '"><span class="n3x-av">' + esc(initials(name)) + '</span>' +
        '<span class="n3x-row-main"><span class="n3x-row-top"><span class="n3x-row-name">' + esc(name) + '</span></span>' +
        '<span class="n3x-row-sub"><span class="n3x-row-preview">' + esc(e.department || e.employee_no || 'Colleague') + '</span></span>' +
        '</span></button>';
    }).join('');
    var app = root();
    app.innerHTML = '<section class="n3x-chats">' +
      '<div class="n3x-chats-head"><button class="n3x-back" type="button" id="n3x-pick-back" aria-label="Back">\u2190</button>' +
      '<h1 style="font-size:21px">New chat</h1></div>' +
      '<div class="n3x-rows">' + (rows || '<div class="n3x-empty">No colleagues are available to chat with yet.</div>') + '</div></section>';
    app.querySelector('#n3x-pick-back').onclick = paintChats;
    app.querySelectorAll('[data-n3x-pick]').forEach(function (b) {
      b.onclick = function () {
        openThread({
          key: 'person:' + b.dataset.n3xName,
          name: b.dataset.n3xName,
          sub: 'Colleague',
          group: false, alert: false, unread: 0, lastAt: '',
          messages: [], calls: [],
          employeeId: Number(b.dataset.n3xPick)
        });
      };
    });
  }

  /* =========================================== SCREEN 2: CONVERSATION == */
  function openThread(conv) {
    state.open = conv;
    markRead(conv);
    var bubbles = conv.messages.map(function (m, i) {
      var outgoing = !!(m.recipient_label);
      var prev = conv.messages[i - 1];
      var day = (!prev || dayLabel(prev.created_at) !== dayLabel(m.created_at))
        ? '<div class="n3x-day">' + esc(dayLabel(m.created_at)) + '</div>' : '';
      var attachment = m.has_attachment
        ? '<div class="n3x-bubble-meta" style="justify-content:flex-start">\uD83D\uDCCE ' + esc(m.attachment_name || 'Attachment') + '</div>'
        : '';
      return day + '<div class="n3x-bubble ' + (outgoing ? 'out' : 'in') + '">' +
        (outgoing ? '' : '<div style="font-size:11px;font-weight:700;color:#1E9E6A;margin-bottom:2px">' + esc(personName(m)) + '</div>') +
        esc(m.body) + attachment +
        '<div class="n3x-bubble-meta"><span>' + esc(whenLabel(m.created_at)) + '</span>' +
        (outgoing ? '<span class="n3x-ticks read">\u2713\u2713</span>' : '') + '</div></div>';
    }).join('');

    if (!bubbles) {
      bubbles = '<div class="n3x-day">No messages yet</div>' +
        '<div class="n3x-bubble in">Say hello \u2014 your message goes to ' + esc(conv.name) + ' through VOIC3.</div>';
    }

    var app = root();
    app.innerHTML = '<section class="n3x-chat">' +
      '<header class="n3x-chat-head">' +
      '<button class="n3x-back" type="button" id="n3x-back" aria-label="Back to chats">\u2190</button>' +
      '<span class="n3x-av ' + (conv.group ? 'group' : conv.alert ? 'alert' : '') + '">' +
      (conv.group ? svg('users') : conv.alert ? svg('alert') : esc(initials(conv.name))) + '</span>' +
      '<span class="n3x-chat-who"><span class="n3x-chat-name">' + esc(conv.name) + '</span>' +
      '<span class="n3x-chat-status">' + esc(conv.sub || 'Beyond Registration') + ' \u00B7 online</span></span>' +
      '<button class="n3x-callbtn" type="button" id="n3x-call-video" aria-label="Video call">' + svg('video') + '</button>' +
      '<button class="n3x-callbtn" type="button" id="n3x-call-voice" aria-label="Voice call">' + svg('phone') + '</button>' +
      '</header>' +
      '<div class="n3x-canvas" id="n3x-canvas">' + bubbles + '</div>' +
      '<div class="n3x-composer">' +
      '<div class="n3x-composer-pill">' +
      '<textarea id="n3x-input" rows="1" placeholder="Type a message"></textarea>' +
      '<button class="n3x-attach" type="button" id="n3x-attach" aria-label="Attach a file">' + svg('paperclip') + '</button>' +
      '</div>' +
      '<button class="n3x-send" type="button" id="n3x-send" aria-label="Send message">' + svg('send') + '</button>' +
      '</div></section>';

    var canvas = app.querySelector('#n3x-canvas');
    if (canvas) canvas.scrollTop = canvas.scrollHeight;

    app.querySelector('#n3x-back').onclick = function () { closeThread(); };

    app.querySelector('#n3x-call-voice').onclick = function () { startCall('audio'); };
    app.querySelector('#n3x-call-video').onclick = function () { startCall('video'); };

    var input = app.querySelector('#n3x-input');
    input.oninput = function () {
      input.style.height = 'auto';
      input.style.height = Math.min(96, input.scrollHeight) + 'px';
    };
    input.onkeydown = function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
    };
    var sendBtn = app.querySelector('#n3x-send');
    if (sendBtn) sendBtn.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      var box = app.querySelector('#n3x-input');
      send(box ? box.value : '');
    }, true);
    app.querySelector('#n3x-attach').onclick = function () {
      // The vault upload is the app's own file path; point there rather than
      // inventing an upload that does not exist.
      if (typeof window.toast === 'function') window.toast('Attach through Vault upload, then send the message here.');
      else alert('Attach through Vault upload, then send the message here.');
    };

    function send(typed) {
      // The text is read at the moment of the tap. Reading it later, or from a
      // stale element, is how a message can look typed but never leave.
      var box = app.querySelector('#n3x-input') || input;
      var text = String(typeof typed === 'string' ? typed : (box && box.value) || '').trim();
      if (!text) return;
      try { box.value = ''; box.style.height = '38px'; } catch (e) { /* the view may already be gone */ }
      var body = { subject: 'Message from VOIC3', body: text };
      if (conv.group) body.department = 'ALL EMPLOYEES';
      if (conv.employeeId) body.employee_id = conv.employeeId;
      api('/api/mobile/messages', { method: 'POST', body: JSON.stringify(body) })
        .then(function () {
          return load();
        })
        .then(function () {
          var fresh = conversations().filter(function (c) { return c.key === conv.key; })[0] || conv;
          openThread(fresh);
        })
        .catch(function (e) {
          if (typeof window.toast === 'function') window.toast(e.message || 'Could not send');
          else alert(e.message || 'Could not send');
        });
    }

    function startCall(type) {
      if (conv.employeeId && typeof window.api === 'function') {
        api('/api/mobile/calls', { method: 'POST', body: JSON.stringify({ callee_employee_id: conv.employeeId, call_type: type }) })
          .then(function () { if (typeof window.toast === 'function') window.toast('Calling ' + conv.name + '\u2026'); })
          .catch(function (e) { if (typeof window.toast === 'function') window.toast(e.message || 'Call failed'); });
        return;
      }
      // No employee id on this row: use the app's own call picker, which asks who.
      if (typeof window.startCall === 'function') window.startCall();
      else if (typeof window.toast === 'function') window.toast('Choose who to call from the dashboard.');
    }
  }

  /* --------------------------------------------------------------- paint */
  function paintChats() {
    load().then(function () {
      var app = root();
      app.innerHTML = '<section class="n3x-chats">' + chatsMarkup().replace(/^<section class="n3x-chats">|<\/section>$/g, '') + '</section>';
      bindChats();
    });
  }

  /* Attach to the app's VOIC3 tab without rewriting its router: the tab sets
     #app's innerHTML itself, so we take over the messages tab right after it. */
  var observer = null;
  function watchTab() {
    if (state.watching) return;
    state.watching = true;
    // Two things, and only two: paint when the app changes tab, and paint once
    // after the messages tab has rendered. No MutationObserver - it repainted the
    // chats over the dashboard and made "\u2190 Dashboard" look dead.
    window.addEventListener('hashchange', function () {
      setTimeout(mountIfMessagesTab, 40);
    });
    setInterval(mountIfMessagesTab, 1500);
    setTimeout(mountIfMessagesTab, 600);
  }

  /** Paint the chats only while the app is showing its messages tab. */
  function mountIfMessagesTab() {
    if (state.leaving) return;
    var app = root();
    if (!app) return;
    var tabNow = (typeof window.mobileTab === 'function') ? window.mobileTab() : '';
    // No answer from the app means we do not know where the user is: do nothing.
    // Guessing here is what painted chats over the dashboard and left a blank screen.
    if (!tabNow) return;
    if (tabNow !== 'messages') {
      // Left VOIC3: drop our own view, but never the app's.
      var mine = app.querySelector('.n3x-chats, .n3x-chat');
      if (mine) mine.remove();
      state.open = null;
      return;
    }
    if (app.querySelector('.n3x-chats') || app.querySelector('.n3x-chat')) return;
    if (app.querySelector('.mobile-call-screen, .voic3-call-overlay')) return;
    paintChats();
  }

  /** Which tab the app is on, read from what it drew, when it publishes nothing. */
  function tabFromDom() {
    var active = document.querySelector('.nav button.active[data-tab]');
    if (active && active.dataset) return active.dataset.tab;
    var app = root();
    var html = (app && app.innerHTML) || '';
    if (/TELECOMMUNICATIONS \u00B7 VOIC3|>VOIC3</.test(html)) return 'messages';
    // A dashboard render always starts with the home cards, never with chats.
    if (app && app.querySelector('.bento, .home-grid, [data-home="home"]')) return 'home';
    return '';
  }

  /* --------------------------------------------- leaving and going back */
  function goDashboard() {
    // Leave VOIC3 for the app's own dashboard.
    //
    // The app publishes its tab switcher on window (mobile.js), so this is a direct
    // call into the app's own navigation - no hash routing and no observer that
    // could paint the chats back over it.
    state.open = null;
    state.leaving = true;
    var app = root();
    if (app) {
      var mine = app.querySelector('.n3x-chats, .n3x-chat');
      if (mine) mine.remove();
    }
    var switched = false;
    try {
      if (typeof window.setMobileTab === 'function') { window.setMobileTab('home'); switched = true; }
    } catch (e) { /* fall through */ }
    if (!switched) { try { location.hash = '#home'; } catch (e2) { /* ignore */ } }
    setTimeout(function () {
      // If the app did not draw anything, put its render back in charge by asking
      // it again; only as a last resort take our own view away entirely.
      var appNow = root();
      var drew = appNow && appNow.innerHTML && appNow.innerHTML.length > 40 &&
        !appNow.querySelector('.n3x-chat');
      if (!drew) {
        try { if (typeof window.setMobileTab === 'function') window.setMobileTab('home'); } catch (e3) { }
      }
      state.leaving = false;
    }, 350);
  }

  function closeThread() {
    state.open = null;
    paintChats();
  }

  /* Android's Back button and the browser's own back gesture arrive as
     popstate. One press leaves the conversation, the next leaves VOIC3 - the
     same path as the on-screen buttons, so a user never gets stuck. */
  function wireBackButton() {
    if (state.backWired) return;
    state.backWired = true;
    // Registered first and in the capture phase, so this sees the press before
    // the app's own tab handler can move the user somewhere unexpected.
    window.addEventListener('popstate', function (ev) {
      var app = root();
      if (!app || !app.querySelector('.n3x-chats, .n3x-chat')) return;
      if (!state.open) return;   // already on the list: let the app leave VOIC3
      if (ev) { try { ev.stopImmediatePropagation(); } catch (e) { /* older browsers */ } }
      // Stay in VOIC3 but step back one level, and put the history entry back so
      // the following press is the one that leaves for the dashboard.
      try { history.pushState({ n3xMessenger: 'chats' }, '', location.href); } catch (e2) { /* ignore */ }
      closeThread();
    }, true);
  }

  /* Opening a conversation clears its badge at once, then tells the server, so
     the green number does not come back on the next refresh. */
  function markRead(conv) {
    if (!conv) return;
    conv.unread = 0;
    conv.messages.forEach(function (m) { if (!m.read_at) m.read_at = new Date().toISOString(); });
    var thread = conv.employeeNo ? 'mobile:' + conv.employeeNo : String((conv.messages[0] && conv.messages[0].sender) || '');
    if (!thread && conv.alert) thread = String((conv.messages[0] && conv.messages[0].sender) || '');
    if (!thread) return;
    api('/api/mobile/messages/read', { method: 'POST', body: JSON.stringify({ thread: thread }) })
      .catch(function () { /* the badge is already gone locally; retried on next open */ });
  }

  window.N3XUS_MESSENGER = { chats: paintChats, open: openThread, conversations: conversations };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watchTab);
  else watchTab();
})();
