﻿"""EVOLV3 Academy - Learning Management System (100% free, in-house).

Courses, lessons, quizzes (caregiver/family level), progress tracking, certificates.
Also hosts the EVOLV3 knowledge cards: short fact cards and mini emergency cards
for staff and family. No external service or paid API.
"""
from __future__ import annotations
import json
from datetime import date

# Content packs. Each module exposes PACK, CARDS, QUIZZES, DISCLAIMER, EMERGENCY_NUMBERS.
# Add a new module here to teach a new sector - the rest of the system is pack-aware.
_PACK_MODULES = []
for _name in ("academy_content", "academy_content_home_safety"):
    try:
        _PACK_MODULES.append(__import__(_name))
    except ImportError:
        try:
            _PACK_MODULES.append(__import__("." + _name, package=__package__))
        except ImportError:
            pass

# Backwards-compatible aliases for the default (dementia) pack.
_default = _PACK_MODULES[0] if _PACK_MODULES else None
CARDS = getattr(_default, "CARDS", [])
QUIZZES = getattr(_default, "QUIZZES", [])
PACK = getattr(_default, "PACK", "dementia")
DISCLAIMER = getattr(_default, "DISCLAIMER", "")
EMERGENCY_NUMBERS = getattr(_default, "EMERGENCY_NUMBERS", [])

def all_packs():
    return [(m.PACK, m) for m in _PACK_MODULES]

def pack_meta(pack):
    for m in _PACK_MODULES:
        if m.PACK == pack:
            return {"pack": m.PACK, "disclaimer": m.DISCLAIMER,
                    "emergency_numbers": m.EMERGENCY_NUMBERS,
                    "cards": len(m.CARDS), "quizzes": len(m.QUIZZES)}
    return None

SCHEMA = """
CREATE TABLE IF NOT EXISTS academy_courses(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, audience TEXT DEFAULT 'All',
  description TEXT DEFAULT '', status TEXT DEFAULT 'Draft', created_by TEXT DEFAULT '',
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS academy_lessons(
  id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL, title TEXT NOT NULL,
  body TEXT DEFAULT '', sort_order INTEGER DEFAULT 0, created_at TEXT NOT NULL,
  FOREIGN KEY(course_id) REFERENCES academy_courses(id));
CREATE TABLE IF NOT EXISTS academy_quizzes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, lesson_id INTEGER NOT NULL, question TEXT NOT NULL,
  option_a TEXT NOT NULL, option_b TEXT NOT NULL, option_c TEXT DEFAULT '', option_d TEXT DEFAULT '',
  correct TEXT NOT NULL, explanation TEXT DEFAULT '',
  FOREIGN KEY(lesson_id) REFERENCES academy_lessons(id));
CREATE TABLE IF NOT EXISTS academy_progress(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, course_id INTEGER NOT NULL,
  lesson_id INTEGER NOT NULL, completed INTEGER DEFAULT 0, score INTEGER DEFAULT 0,
  completed_at TEXT DEFAULT '', UNIQUE(user, lesson_id));
CREATE TABLE IF NOT EXISTS academy_certificates(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, course_id INTEGER NOT NULL,
  issued_at TEXT NOT NULL, certificate_no TEXT NOT NULL, score INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS academy_settings(
  key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS academy_enrolments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, course_id INTEGER NOT NULL,
  enrolled_at TEXT NOT NULL, UNIQUE(user, course_id),
  FOREIGN KEY(course_id) REFERENCES academy_courses(id));
CREATE TABLE IF NOT EXISTS academy_cards(
  id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE,
  pack TEXT NOT NULL DEFAULT 'dementia', kind TEXT NOT NULL DEFAULT 'fact',
  category TEXT DEFAULT '', title TEXT NOT NULL, teaser TEXT DEFAULT '', body TEXT DEFAULT '',
  tip TEXT DEFAULT '', steps_json TEXT DEFAULT '[]', call_text TEXT DEFAULT '',
  icon TEXT DEFAULT '', minutes INTEGER DEFAULT 1, sort_order INTEGER DEFAULT 0,
  source TEXT DEFAULT 'seed', image_path TEXT DEFAULT '', active INTEGER DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS academy_card_progress(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, card_id INTEGER NOT NULL,
  seen INTEGER DEFAULT 0, seen_at TEXT DEFAULT '', UNIQUE(user, card_id));
CREATE TABLE IF NOT EXISTS academy_card_ratings(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, card_id INTEGER NOT NULL,
  rating INTEGER NOT NULL, rated_at TEXT NOT NULL, UNIQUE(user, card_id));
CREATE TABLE IF NOT EXISTS academy_quiz_ratings(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, question_id INTEGER NOT NULL,
  rating INTEGER NOT NULL, rated_at TEXT NOT NULL, UNIQUE(user, question_id));
CREATE TABLE IF NOT EXISTS academy_quiz_bank(
  id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE,
  pack TEXT NOT NULL DEFAULT 'dementia', question TEXT NOT NULL, options_json TEXT NOT NULL,
  correct INTEGER NOT NULL, explanation TEXT DEFAULT '', icon TEXT DEFAULT '',
  source TEXT DEFAULT 'seed', active INTEGER DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS academy_quiz_attempts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL, question_id INTEGER NOT NULL,
  choice INTEGER NOT NULL, correct INTEGER NOT NULL DEFAULT 0, answered_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_academy_quiz_attempts ON academy_quiz_attempts(user, question_id);
CREATE TABLE IF NOT EXISTS academy_evolutions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, pack TEXT NOT NULL, started_at TEXT NOT NULL,
  finished_at TEXT DEFAULT '', status TEXT NOT NULL, generated_cards INTEGER DEFAULT 0,
  generated_quizzes INTEGER DEFAULT 0, summary TEXT DEFAULT '', error TEXT DEFAULT '');
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    # Backfill columns added after the first release (SQLite has no IF NOT EXISTS for columns).
    for table, col, ddl in (
        ("academy_cards", "source", "TEXT DEFAULT 'seed'"),
        ("academy_cards", "image_path", "TEXT DEFAULT ''"),
        ("academy_quiz_bank", "source", "TEXT DEFAULT 'seed'"),
        ("academy_certificates", "score", "INTEGER DEFAULT 0"),
    ):
        try:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(" + table + ")")]
        except Exception:
            cols = []
        if cols and col not in cols:
            conn.execute("ALTER TABLE " + table + " ADD COLUMN " + col + " " + ddl)
    seed_cards(conn)
    # A restart kills the background evolution thread, so never leave a run
    # stuck on "running" forever.
    try:
        import datetime as _dts
        conn.execute(
            "UPDATE academy_evolutions SET status='failed',finished_at=?,"
            "error=COALESCE(NULLIF(error,''),'interrupted by restart') WHERE status='running'",
            (_dts.datetime.now().isoformat(timespec="seconds"),))
    except Exception:
        pass
    conn.commit()
    # Seed starter courses if empty (guarded so re-runs do not duplicate).
    if conn.execute("SELECT COUNT(*) c FROM academy_courses").fetchone()["c"] == 0:
        cur = conn.execute("INSERT INTO academy_courses(title,audience,description,status,created_by,created_at) VALUES(?,?,?,?,?,?)",
                           ("Dementia Care Basics", "Family", "Understanding dementia and daily care for family members.", "Published", "system", date.today().isoformat()))
        cid = cur.lastrowid
        l1 = conn.execute("INSERT INTO academy_lessons(course_id,title,body,sort_order,created_at) VALUES(?,?,?,?,?)",
                          (cid, "What is Dementia?", "Dementia is a syndrome that affects memory, thinking, and social abilities. It is not a single disease but a group of conditions. Alzheimer's is the most common type. Early signs include forgetfulness, confusion, and difficulty with daily tasks. Understanding this helps families respond with patience.", 1, date.today().isoformat())).lastrowid
        conn.execute("INSERT INTO academy_quizzes(lesson_id,question,option_a,option_b,option_c,option_d,correct,explanation) VALUES(?,?,?,?,?,?,?,?)",
                     (l1, "What is dementia?", "A single disease", "A syndrome affecting memory and thinking", "A normal part of aging", "An infection", "B", "Dementia is a syndrome, not a single disease."))
        l2 = conn.execute("INSERT INTO academy_lessons(course_id,title,body,sort_order,created_at) VALUES(?,?,?,?,?)",
                          (cid, "Daily Care Tips", "Routine is key for dementia care. Keep a consistent schedule. Use simple, clear language. Reduce noise and clutter. Encourage independence where possible. Be patient and never argue - redirect instead. Safety first: remove trip hazards, lock away dangerous items.", 2, date.today().isoformat())).lastrowid
        conn.execute("INSERT INTO academy_quizzes(lesson_id,question,option_a,option_b,option_c,option_d,correct,explanation) VALUES(?,?,?,?,?,?,?,?)",
                     (l2, "What is the best approach when a person with dementia becomes agitated?", "Argue to correct them", "Redirect and stay calm", "Leave them alone", "Raise your voice", "B", "Redirecting and staying calm is the recommended approach."))
        l3 = conn.execute("INSERT INTO academy_lessons(course_id,title,body,sort_order,created_at) VALUES(?,?,?,?,?)",
                          (cid, "Communication Strategies", "Speak slowly and clearly. Use short sentences. Make eye contact. Use gestures and visual cues. Avoid open-ended questions; offer choices instead. Validate their feelings even if facts are wrong. Never say 'I already told you'.", 3, date.today().isoformat())).lastrowid
        conn.execute("INSERT INTO academy_quizzes(lesson_id,question,option_a,option_b,option_c,option_d,correct,explanation) VALUES(?,?,?,?,?,?,?,?)",
                     (l3, "Which communication tip is most effective?", "Speak quickly to save time", "Use long complex sentences", "Offer choices instead of open questions", "Correct every mistake", "C", "Offering choices reduces frustration and supports independence."))
        cur2 = conn.execute("INSERT INTO academy_courses(title,audience,description,status,created_by,created_at) VALUES(?,?,?,?,?,?)",
                            ("Dementia Care for Professionals", "Professional", "Clinical and care-practice guidance for caregivers and nurses.", "Published", "system", date.today().isoformat()))
        cid2 = cur2.lastrowid
        conn.execute("INSERT INTO academy_lessons(course_id,title,body,sort_order,created_at) VALUES(?,?,?,?,?)",
                     (cid2, "Assessment & Care Planning", "Conduct baseline cognitive assessments using validated tools. Document functional abilities. Develop individualized care plans with measurable goals. Review and update quarterly. Involve family in planning.", 1, date.today().isoformat()))
        conn.execute("INSERT INTO academy_lessons(course_id,title,body,sort_order,created_at) VALUES(?,?,?,?,?)",
                     (cid2, "Managing Challenging Behaviours", "Identify triggers (pain, hunger, overstimulation). Use de-escalation techniques. Document incidents. Adjust environment. Consider non-pharmacological interventions first. Refer to specialist when needed.", 2, date.today().isoformat()))
    conn.commit()


def list_courses(conn, audience=None):
    sql = "SELECT * FROM academy_courses WHERE status='Published'"
    args = []
    if audience:
        sql += " AND (audience=? OR audience='All')"; args.append(audience)
    sql += " ORDER BY id"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def get_course(conn, cid):
    c = conn.execute("SELECT * FROM academy_courses WHERE id=?", (cid,)).fetchone()
    if not c: return None
    lessons = [dict(r) for r in conn.execute("SELECT * FROM academy_lessons WHERE course_id=? ORDER BY sort_order", (cid,)).fetchall()]
    for l in lessons:
        l["quizzes"] = [dict(r) for r in conn.execute("SELECT * FROM academy_quizzes WHERE lesson_id=?", (l["id"],)).fetchall()]
    return {"course": dict(c), "lessons": lessons}


def complete_lesson(conn, user, course_id, lesson_id, score=0):
    conn.execute("INSERT INTO academy_progress(user,course_id,lesson_id,completed,score,completed_at) VALUES(?,?,?,?,?,?) "
                 "ON CONFLICT(user,lesson_id) DO UPDATE SET completed=1,score=excluded.score,completed_at=excluded.completed_at",
                 (user, course_id, lesson_id, 1, score, date.today().isoformat()))
    conn.commit()


def progress(conn, user, course_id):
    lessons = conn.execute("SELECT id FROM academy_lessons WHERE course_id=?", (course_id,)).fetchall()
    total = len(lessons)
    done = conn.execute("SELECT COUNT(*) c FROM academy_progress WHERE user=? AND course_id=? AND completed=1", (user, course_id)).fetchone()["c"]
    return {"total": total, "completed": done, "percent": round(done / total * 100) if total else 0}


CERTIFICATE_PASS_MARK = 80


def course_score(conn, user, course_id):
    """Average of the learner's current quiz scores, over lessons that have a quiz.

    Returns None when the course has no assessments at all, so a completion-only
    course is never given a fabricated percentage.
    """
    row = conn.execute(
        "SELECT AVG(p.score) AS avg_score, COUNT(*) AS n FROM academy_progress p "
        "WHERE p.user=? AND p.course_id=? AND p.completed=1 AND EXISTS("
        "SELECT 1 FROM academy_quizzes q WHERE q.lesson_id=p.lesson_id)",
        (user, course_id)).fetchone()
    if not row:
        return None
    n = _value(row, "n", 1) or 0
    if not n:
        return None
    avg = _value(row, "avg_score", 0)
    if avg is None:
        return None
    return max(0, min(100, int(round(float(avg)))))


def issue_certificate(conn, user, course_id):
    import secrets
    no = "CERT-" + secrets.token_hex(4).upper()
    score = course_score(conn, user, course_id) or 0
    conn.execute("INSERT INTO academy_certificates(user,course_id,issued_at,certificate_no,score) VALUES(?,?,?,?,?)",
                 (user, course_id, date.today().isoformat(), no, score))
    conn.commit()
    return no


def check_completion(conn, user, course_id):
    p = progress(conn, user, course_id)
    if p["percent"] == 100:
        existing = conn.execute("SELECT certificate_no FROM academy_certificates WHERE user=? AND course_id=?", (user, course_id)).fetchone()
        if existing:
            return existing["certificate_no"]
        score = course_score(conn, user, course_id)
        if score is not None and score < CERTIFICATE_PASS_MARK:
            return None
        return issue_certificate(conn, user, course_id)
    return None


def _staff_display_name(conn, user):
    """Resolve the certificate holder from the account string used in progress rows."""
    import re as _re
    raw = str(user or "").strip()
    key = raw.split(":", 1)[1] if _re.match(r"^[A-Za-z]+:", raw) else raw
    try:
        row = conn.execute("SELECT first_name,last_name FROM employees WHERE employee_no=?", (key,)).fetchone()
        if row:
            first = _value(row, "first_name", 0) or ""
            last = _value(row, "last_name", 1) or ""
            name = (first + " " + last).strip()
            if name:
                return name
    except Exception:
        pass
    try:
        row = conn.execute("SELECT full_name FROM admins WHERE username=?", (key,)).fetchone()
        if row and _value(row, "full_name", 0):
            return _value(row, "full_name", 0)
    except Exception:
        pass
    return key or "Employee"


def _cert_secret(conn):
    import secrets
    row = conn.execute("SELECT value FROM academy_settings WHERE key='certificate_secret'").fetchone()
    if row:
        return _value(row, "value", 0)
    value = secrets.token_hex(32)
    conn.execute("INSERT OR IGNORE INTO academy_settings(key,value) VALUES('certificate_secret',?)", (value,))
    conn.commit()
    return value


def _cert_signature(conn, no, user, course_id, issued_at, score):
    import hashlib
    import hmac
    message = ("|".join([str(no), str(user), str(course_id), str(issued_at), str(score or 0)])).encode("utf-8")
    return hmac.new(_cert_secret(conn).encode("utf-8"), message, hashlib.sha256).hexdigest()[:12].upper()


def certificate_detail(conn, cert_id):
    row = conn.execute(
        "SELECT c.id, c.user, c.course_id, c.certificate_no, c.issued_at, c.score, "
        "co.title AS course_title, co.audience AS audience "
        "FROM academy_certificates c JOIN academy_courses co ON co.id=c.course_id "
        "WHERE c.id=?", (int(cert_id),)).fetchone()
    if not row:
        return None
    user = _value(row, "user", 1)
    course_id = _value(row, "course_id", 2)
    no = _value(row, "certificate_no", 3)
    issued = _value(row, "issued_at", 4)
    score = _value(row, "score", 5) or 0
    percent = int(score) if int(score) > 0 else None
    sig = _cert_signature(conn, no, user, course_id, issued, score)
    code = no + "-" + sig
    name = _staff_display_name(conn, user)
    course = _value(row, "course_title", 6) or "EVOLV3 Course"
    qr_payload = "\n".join([
        "N3XUS EVOLV3 CERTIFICATE",
        "No: " + str(no),
        "Name: " + name,
        "Course: " + course,
        "Issued: " + str(issued),
        "Verify: " + code,
    ])
    return {
        "id": _value(row, "id", 0),
        "user": user,
        "course_id": course_id,
        "certificate_no": no,
        "issued_at": issued,
        "score": percent,
        "percent": percent,
        "passed": percent is None or percent >= CERTIFICATE_PASS_MARK,
        "staff_name": name,
        "course_title": course,
        "audience": _value(row, "audience", 7) or "",
        "verification_code": code,
        "verify_code": code,
        "qr_payload": qr_payload,
    }


def verify_certificate(conn, code):
    """Validate a printed verification code entirely offline.

    Accepts the code on its own, or a pasted QR payload (any line containing it).
    """
    import re as _re
    text = str(code or "").strip().upper()
    match = _re.search(r"(CERT-[0-9A-F]{8})-([0-9A-F]{12})", text)
    if not match:
        return {"valid": False, "reason": "That is not an EVOLV3 certificate code."}
    no, sig = match.group(1), match.group(2)
    row = conn.execute("SELECT id FROM academy_certificates WHERE certificate_no=?", (no,)).fetchone()
    if not row:
        return {"valid": False, "reason": "No certificate with that number exists on this system."}
    detail = certificate_detail(conn, _value(row, "id", 0))
    if not detail:
        return {"valid": False, "reason": "No certificate with that number exists on this system."}
    import hmac
    if not hmac.compare_digest(detail["verification_code"].split("-")[-1], sig):
        return {"valid": False, "reason": "The verification code does not match this certificate."}
    return {
        "valid": True,
        "certificate_no": detail["certificate_no"],
        "staff_name": detail["staff_name"],
        "course_title": detail["course_title"],
        "issued_at": detail["issued_at"],
        "percent": detail["percent"],
        "passed": detail["passed"],
    }


# ---------------------------------------------------------------------------
# EVOLV3 knowledge cards
# ---------------------------------------------------------------------------

def _value(row, key, index):
    """Read a column from a Row or a plain tuple (tests use a tuple-ish store)."""
    try:
        return row[key]
    except (KeyError, IndexError, TypeError):
        return row[index]


def seed_cards(conn):
    """Insert or refresh every built-in content pack. Safe to run repeatedly."""
    stamp = date.today().isoformat()
    for mod in _PACK_MODULES:
        pack = mod.PACK
        for order, card in enumerate(mod.CARDS):
            conn.execute(
                "INSERT INTO academy_cards(slug,pack,kind,category,title,teaser,body,tip,"
                "steps_json,call_text,icon,minutes,sort_order,source,active,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'seed',1,?,?) "
                "ON CONFLICT(slug) DO UPDATE SET pack=excluded.pack,kind=excluded.kind,"
                "category=excluded.category,title=excluded.title,teaser=excluded.teaser,"
                "body=excluded.body,tip=excluded.tip,steps_json=excluded.steps_json,"
                "call_text=excluded.call_text,icon=excluded.icon,minutes=excluded.minutes,"
                "sort_order=excluded.sort_order,active=1,updated_at=excluded.updated_at",
                (card["slug"], pack, card["kind"], card.get("category", ""), card["title"],
                 card.get("teaser", ""), card.get("body", ""), card.get("tip", ""),
                 json.dumps(card.get("steps", []), ensure_ascii=False),
                 card.get("call", ""), card.get("icon", ""), int(card.get("minutes", 1)),
                 order, stamp, stamp))
        for order, quiz in enumerate(mod.QUIZZES):
            conn.execute(
                "INSERT INTO academy_quiz_bank(slug,pack,question,options_json,correct,"
                "explanation,icon,source,active,created_at) VALUES(?,?,?,?,?,?,?,'seed',1,?) "
                "ON CONFLICT(slug) DO UPDATE SET pack=excluded.pack,question=excluded.question,"
                "options_json=excluded.options_json,correct=excluded.correct,"
                "explanation=excluded.explanation,icon=excluded.icon,active=1",
                (quiz["slug"], pack, quiz["question"],
                 json.dumps(quiz["options"], ensure_ascii=False), int(quiz["correct"]),
                 quiz.get("explanation", ""), quiz.get("icon", ""), stamp))


def _card_row(row):
    return {
        "id": _value(row, "id", 0),
        "slug": _value(row, "slug", 1),
        "pack": _value(row, "pack", 2),
        "kind": _value(row, "kind", 3),
        "category": _value(row, "category", 4),
        "title": _value(row, "title", 5),
        "teaser": _value(row, "teaser", 6),
        "icon": _value(row, "icon", 11),
        "minutes": _value(row, "minutes", 12),
        "image_path": _value(row, "image_path", 14),
    }


def list_cards(conn, pack=PACK, kind=None, category=None):
    sql = "SELECT id,slug,pack,kind,category,title,teaser,body,tip,steps_json,call_text,icon,minutes,sort_order,image_path FROM academy_cards WHERE active=1 AND pack=?"
    args = [pack]
    if kind:
        sql += " AND kind=?"; args.append(kind)
    if category:
        sql += " AND category=?"; args.append(category)
    sql += " ORDER BY kind, sort_order, id"
    return [_card_row(r) for r in conn.execute(sql, args).fetchall()]


def get_card(conn, card_id):
    row = conn.execute(
        "SELECT id,slug,pack,kind,category,title,teaser,body,tip,steps_json,call_text,icon,minutes,"
        "sort_order,active,image_path FROM academy_cards WHERE id=? AND active=1", (card_id,)).fetchone()
    if not row:
        return None
    try:
        steps = json.loads(_value(row, "steps_json", 9) or "[]")
    except (TypeError, ValueError):
        steps = []
    return {
        "id": _value(row, "id", 0), "slug": _value(row, "slug", 1),
        "pack": _value(row, "pack", 2), "kind": _value(row, "kind", 3),
        "category": _value(row, "category", 4), "title": _value(row, "title", 5),
        "teaser": _value(row, "teaser", 6), "body": _value(row, "body", 7),
        "tip": _value(row, "tip", 8), "steps": steps,
        "call": _value(row, "call_text", 10), "icon": _value(row, "icon", 11),
        "minutes": _value(row, "minutes", 12),
        "image_path": _value(row, "image_path", 15),
    }


def mark_card_seen(conn, user, card_id):
    row = conn.execute("SELECT id FROM academy_cards WHERE id=? AND active=1", (card_id,)).fetchone()
    if not row:
        return False
    conn.execute(
        "INSERT INTO academy_card_progress(user,card_id,seen,seen_at) VALUES(?,?,1,?) "
        "ON CONFLICT(user,card_id) DO UPDATE SET seen=1,seen_at=excluded.seen_at",
        (user, card_id, date.today().isoformat()))
    conn.commit()
    return True


def card_progress(conn, user, pack=PACK):
    rows = conn.execute(
        "SELECT c.kind AS kind, COUNT(*) AS total, "
        "COALESCE(SUM(CASE WHEN p.seen=1 THEN 1 ELSE 0 END),0) AS seen "
        "FROM academy_cards c LEFT JOIN academy_card_progress p "
        "ON p.card_id=c.id AND p.user=? "
        "WHERE c.active=1 AND c.pack=? GROUP BY c.kind", (user, pack)).fetchall()
    totals = {"fact": 0, "emergency": 0}
    seen = {"fact": 0, "emergency": 0}
    for r in rows:
        kind = _value(r, "kind", 0)
        if kind in totals:
            totals[kind] = int(_value(r, "total", 1))
            seen[kind] = int(_value(r, "seen", 2))
    total = sum(totals.values())
    done = sum(seen.values())
    return {
        "total": total, "seen": done,
        "percent": round(done / total * 100) if total else 0,
        "facts": {"total": totals["fact"], "seen": seen["fact"]},
        "emergencies": {"total": totals["emergency"], "seen": seen["emergency"]},
    }


def list_questions(conn, pack=PACK):
    """Questions safe to send to the client: the correct answer is never included."""
    rows = conn.execute(
        "SELECT id,slug,question,options_json,icon FROM academy_quiz_bank "
        "WHERE active=1 AND pack=? ORDER BY id", (pack,)).fetchall()
    items = []
    for r in rows:
        try:
            options = json.loads(_value(r, "options_json", 3) or "[]")
        except (TypeError, ValueError):
            options = []
        items.append({"id": _value(r, "id", 0), "slug": _value(r, "slug", 1),
                      "question": _value(r, "question", 2), "options": options,
                      "icon": _value(r, "icon", 4)})
    return items


def answer_question(conn, user, question_id, choice):
    row = conn.execute(
        "SELECT id,correct,explanation FROM academy_quiz_bank WHERE id=? AND active=1",
        (question_id,)).fetchone()
    if not row:
        return None
    correct_index = int(_value(row, "correct", 1))
    ok = int(choice) == correct_index
    conn.execute(
        "INSERT INTO academy_quiz_attempts(user,question_id,choice,correct,answered_at) "
        "VALUES(?,?,?,?,?)",
        (user, question_id, int(choice), 1 if ok else 0, date.today().isoformat()))
    conn.commit()
    return {"correct": ok, "answer": correct_index,
            "explanation": _value(row, "explanation", 2)}


def quiz_summary(conn, user, pack=PACK):
    total = conn.execute(
        "SELECT COUNT(*) FROM academy_quiz_bank WHERE active=1 AND pack=?", (pack,)).fetchone()[0]
    # Best result per question, so a retry can improve the score.
    rows = conn.execute(
        "SELECT q.id AS qid, MAX(a.correct) AS best FROM academy_quiz_bank q "
        "LEFT JOIN academy_quiz_attempts a ON a.question_id=q.id AND a.user=? "
        "WHERE q.active=1 AND q.pack=? GROUP BY q.id", (user, pack)).fetchall()
    answered = sum(1 for r in rows if _value(r, "best", 1) is not None)
    correct = sum(1 for r in rows if int(_value(r, "best", 1) or 0) == 1)
    return {"total": int(total), "answered": answered, "correct": correct,
            "percent": round(correct / total * 100) if total else 0}


# ---------------------------------------------------------------------------
# Ratings (staff rate content 1-10)
# ---------------------------------------------------------------------------

def rate_card(conn, user, card_id, rating):
    rating = max(1, min(10, int(rating)))
    row = conn.execute("SELECT id FROM academy_cards WHERE id=? AND active=1", (card_id,)).fetchone()
    if not row:
        return False
    conn.execute(
        "INSERT INTO academy_card_ratings(user,card_id,rating,rated_at) VALUES(?,?,?,?) "
        "ON CONFLICT(user,card_id) DO UPDATE SET rating=excluded.rating,rated_at=excluded.rated_at",
        (user, card_id, rating, date.today().isoformat()))
    conn.commit()
    return True


def rate_question(conn, user, question_id, rating):
    rating = max(1, min(10, int(rating)))
    row = conn.execute("SELECT id FROM academy_quiz_bank WHERE id=? AND active=1", (question_id,)).fetchone()
    if not row:
        return False
    conn.execute(
        "INSERT INTO academy_quiz_ratings(user,question_id,rating,rated_at) VALUES(?,?,?,?) "
        "ON CONFLICT(user,question_id) DO UPDATE SET rating=excluded.rating,rated_at=excluded.rated_at",
        (user, question_id, rating, date.today().isoformat()))
    conn.commit()
    return True


def ratings_summary(conn, pack=PACK):
    card_rows = conn.execute(
        "SELECT c.id AS id, c.title AS title, c.kind AS kind, c.source AS source, "
        "COUNT(r.id) AS n, COALESCE(AVG(r.rating),0) AS avg "
        "FROM academy_cards c LEFT JOIN academy_card_ratings r ON r.card_id=c.id "
        "WHERE c.active=1 AND c.pack=? GROUP BY c.id ORDER BY avg DESC, n DESC", (pack,)).fetchall()
    quiz_rows = conn.execute(
        "SELECT q.id AS id, q.question AS question, q.source AS source, "
        "COUNT(r.id) AS n, COALESCE(AVG(r.rating),0) AS avg "
        "FROM academy_quiz_bank q LEFT JOIN academy_quiz_ratings r ON r.question_id=q.id "
        "WHERE q.active=1 AND q.pack=? GROUP BY q.id ORDER BY avg DESC, n DESC", (pack,)).fetchall()
    def _map(r, keys):
        return {k: (_value(r, k, i) if False else _value(r, k, 0)) for i, k in enumerate(keys)}
    return {
        "cards": [{"id": _value(r, "id", 0), "title": _value(r, "title", 1),
                   "kind": _value(r, "kind", 2), "source": _value(r, "source", 3),
                   "ratings": int(_value(r, "n", 4)), "avg": round(float(_value(r, "avg", 5) or 0), 2)}
                  for r in card_rows],
        "quizzes": [{"id": _value(r, "id", 0), "question": _value(r, "question", 1),
                     "source": _value(r, "source", 2), "ratings": int(_value(r, "n", 3)),
                     "avg": round(float(_value(r, "avg", 4) or 0), 2)}
                    for r in quiz_rows],
    }


# ---------------------------------------------------------------------------
# Self-evolution: the AI bot generates new cards and quizzes from top-rated content
# ---------------------------------------------------------------------------

def _slugify(text):
    import re
    base = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return base[:60] or "item"


def _existing_titles(conn, pack):
    rows = conn.execute("SELECT title FROM academy_cards WHERE pack=?", (pack,)).fetchall()
    return [str(_value(r, "title", 0)) for r in rows]


def _json_object(text):
    """Return the first balanced JSON object in *text*, or "" if none."""
    import re
    if not text:
        return ""
    body = str(text)
    # Strip markdown fences if the model wrapped its answer.
    fence = re.search(r"```(?:json)?\s*(.*?)```", body, re.S)
    if fence:
        body = fence.group(1)
    start = body.find("{")
    while start >= 0:
        depth = 0
        in_str = False
        escape = False
        for i in range(start, len(body)):
            ch = body[i]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return body[start:i + 1]
        start = body.find("{", start + 1)
    return ""


def _call_llm(llm_callable, prompt, actor):
    """Call the local model, tolerating one-argument or two-argument callables."""
    if llm_callable is None:
        raise RuntimeError("No local AI is configured.")
    import inspect
    try:
        params = inspect.signature(llm_callable).parameters
        two = len(params) >= 2
    except (TypeError, ValueError):
        two = True
    return llm_callable(prompt, actor) if two else llm_callable(prompt)


_CARD_PROMPT = (
    "You are the learning writer for a dementia-care pack used by care staff and families.\n"
    "Never copy the example below. It only shows the shape of the answer.\n"
    "Write about this topic: {topic}\n"
    "Return ONE JSON object and nothing else, with exactly these keys:\n"
    "kind (fact or emergency), category, title, teaser, body, tip, steps (list, empty for facts), "
    "call (text, empty unless emergency), icon (one emoji), minutes (1).\n"
    "Example shape only: {example}\n"
    "Rules:\n"
    "- body MUST be 4 sentences and at least 300 characters long, and MUST explain why it matters.\n"
    "- Plain English, short sentences, warm and practical. No college jargon, no medical advice.\n"
    "- This pack teaches practical care, not medicine. Never write about medicines, doses,\n"
    "  diagnoses, allergies, infections, tests or treatments.\n"
    "- kind should be fact for daily care. Only use emergency when the topic is a real crisis,\n"
    "  and then steps and call must both be filled in.\n"
    "- category must be a real 1-3 word topic, never a placeholder.\n"
    "- title at most 60 characters, and must be clearly different from every existing title.\n"
    "- Do not repeat any sentence from the example or from the existing cards.\n"
    "Existing titles: {titles}\n"
    "These cards are rated highest by staff, so match their depth and tone:\n{examples}\n"
    "Output the JSON object only."
)

_QUIZ_PROMPT = (
    "You write one multiple-choice question for dementia-care staff training.\n"
    "Base it only on this vetted card:\n"
    "TITLE: {title}\nBODY: {body}\nTIP: {tip}\n\n"
    "Return ONE JSON object and nothing else, with these keys:\n"
    '{"question":"...","options":["...","...","...","..."],"correct":0,'
    '"explanation":"one short sentence","icon":"\\u2753"}\n'
    "Rules:\n"
    "- Exactly 4 options. Exactly one is right. The other 3 must be clearly wrong.\n"
    "- Test a different detail from these questions that already exist: {asked}\n"
    "- Plain English, short sentences. No medicine names or doses.\n"
    "- Keep the question under 120 characters and each option under 80 characters.\n"
    "Output the JSON object only."
)

_PLACEHOLDERS = {
    "short label", "short title", "one short line", "one practical tip", "1 emoji",
    "4 short plain sentences", "2-4 plain sentences", "...", "label", "category",
}


def _clean_field(value, fallback=""):
    text = str(value or "").strip().strip('"').strip()
    if text.lower() in _PLACEHOLDERS or len(text) < 2:
        return fallback
    return text


_STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "be", "to", "of", "for", "in", "on", "at",
    "and", "or", "do", "does", "did", "you", "your", "they", "their", "it", "its",
    "this", "that", "these", "those", "should", "would", "can", "could", "what",
    "which", "when", "how", "why", "who", "with", "about", "from", "as", "by",
    "correct", "one", "good", "best", "next", "step", "belong", "belongs", "there",
}


def _words(text):
    import re
    words = set()
    for w in re.findall(r"[a-z0-9']+", str(text or "").lower()):
        w = w.strip("'")
        if w and w not in _STOPWORDS:
            words.add(w)
    return words


def _too_similar(a, b, threshold=0.8):
    """Cheap duplicate check so the AI cannot add near-identical titles/questions.

    Uses word containment (ignoring filler words) instead of a strict overlap,
    because short questions often differ by one extra word only.
    """
    wa, wb = _words(a), _words(b)
    if not wa or not wb:
        return False
    shared = len(wa & wb)
    jaccard = shared / float(len(wa | wb))
    containment = shared / float(min(len(wa), len(wb)))
    return max(jaccard, containment) >= threshold


_UNSAFE_TERMS = (
    "allerg", "antibiotic", "antidepress", "blood pressure", "cancer", "chemotherapy",
    "dementia stage", "diabet", "diagnos", "dose", "dosage", "drug", "fever", "infection",
    "injection", "insulin", "medicine", "medication", "mg", "milligram", "paracetamol",
    "prescrib", "sedative", "side effect", "symptom of", "tablet", "treatment", "vaccine",
    "wound", "x-ray",
)


def _clinical_claim(text):
    """True when a draft makes a clinical claim that needs a clinician to review."""
    low = str(text or "").lower()
    return any(term in low for term in _UNSAFE_TERMS)


def _insert_card(conn, pack, data, titles, existing_slugs, bodies=None):
    """Validate one generated card and insert it. Returns True when inserted."""
    import datetime as _dt
    if not isinstance(data, dict):
        return False
    kind = str(data.get("kind") or "fact").lower()
    if kind not in ("fact", "emergency"):
        kind = "fact"
    title = _clean_field(data.get("title"), "")[:60]
    body = _clean_field(data.get("body"), "")
    if not title or len(body) < 200 or title in titles:
        return False
    if any(_too_similar(title, existing) for existing in titles):
        return False
    # Reject recycled sentences: the model sometimes repeats a card it has seen.
    if any(_too_similar(body, existing, 0.6) for existing in (bodies or [])):
        return False
    if body.count(".") + body.count("!") + body.count("?") < 4:
        return False
    # Practical care only: anything clinical must be written by a clinician.
    if _clinical_claim(title + " " + body):
        return False
    slug = _slugify(title)
    if slug in existing_slugs:
        return False
    steps = data.get("steps") or []
    if not isinstance(steps, list):
        steps = []
    steps = [_clean_field(s, "") for s in steps]
    steps = [s for s in steps if s][:6]
    call_text = _clean_field(data.get("call"), "")[:200]
    if kind == "emergency" and (not steps or not call_text):
        return False
    today = _dt.date.today().isoformat()
    category = _clean_field(data.get("category"), "")[:40]
    if not category:
        category = "Emergency care" if kind == "emergency" else "Everyday care"
    conn.execute(
        "INSERT INTO academy_cards(slug,pack,kind,category,title,teaser,body,tip,"
        "steps_json,call_text,icon,minutes,sort_order,source,active,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'ai',1,?,?)",
        (slug, pack, kind, category,
         title, _clean_field(data.get("teaser"), "")[:200], body,
         _clean_field(data.get("tip"), "")[:300],
         json.dumps(steps, ensure_ascii=False),
         call_text,
         (_clean_field(data.get("icon"), "\u2728") or "\u2728")[:4],
         int(data.get("minutes") or 1), 999, today, today))
    existing_slugs.add(slug)
    titles.append(title)
    return True


def _insert_quiz(conn, pack, data, existing_slugs, slug=None, source="ai",
                 existing_questions=None):
    """Validate one generated quiz and insert it. Returns True when inserted."""
    import datetime as _dt
    if not isinstance(data, dict):
        return False
    question = _clean_field(data.get("question"), "")
    options = data.get("options") or []
    if not question or not isinstance(options, list) or len(options) != 4:
        return False
    options = [_clean_field(o, "")[:120] for o in options]
    if any(not o for o in options) or len(set(options)) != 4:
        return False
    for other in (existing_questions or []):
        if _too_similar(question, other, 0.75):
            return False
    try:
        correct = int(data.get("correct"))
    except (TypeError, ValueError):
        return False
    if correct < 0 or correct > 3:
        return False
    slug = slug or _slugify(question)
    if slug in existing_slugs:
        return False
    conn.execute(
        "INSERT INTO academy_quiz_bank(slug,pack,question,options_json,correct,"
        "explanation,icon,source,active,created_at) VALUES(?,?,?,?,?,?,?,?,1,?)",
        (slug, pack, question, json.dumps(options, ensure_ascii=False), correct,
         str(data.get("explanation") or "").strip()[:400],
         (str(data.get("icon") or "\u2753").strip() or "\u2753")[:4], source,
         _dt.date.today().isoformat()))
    existing_slugs.add(slug)
    return True


def derive_quizzes(conn, pack=PACK, limit=5):
    """Build new quiz questions from cards we already reviewed.

    This is the guaranteed weekly engine: it never invents medical claims,
    because every option is a sentence that already passed review. Each card
    can yield two question styles, so the bank keeps growing for months
    without any manual writing.
    """
    import datetime as _dt
    rows = conn.execute(
        "SELECT id,title,category,kind,body,coalesce(tip,'') FROM academy_cards "
        "WHERE active=1 AND pack=? AND length(trim(coalesce(tip,''))) BETWEEN 18 AND 110 "
        "ORDER BY id", (pack,)).fetchall()
    if len(rows) < 5:
        return 0
    cards = [{"id": _value(r, "id", 0), "title": str(_value(r, "title", 1)),
              "category": str(_value(r, "category", 2)), "kind": str(_value(r, "kind", 3)),
              "body": str(_value(r, "body", 4)), "tip": str(_value(r, "tip", 5)).strip()}
             for r in rows]
    existing = {str(r[0]) for r in conn.execute(
        "SELECT slug FROM academy_quiz_bank WHERE pack=?", (pack,)).fetchall()}
    added = 0
    for card in cards:
        if added >= limit:
            break
        tips = []
        for c in cards:
            if c["tip"] and c["tip"] != card["tip"] and c["category"] != card["category"]:
                tips.append(c["tip"])
        if len(tips) < 3:
            tips = []
            for c in cards:
                if c["tip"] and c["tip"] != card["tip"]:
                    tips.append(c["tip"])
        tips = list(dict.fromkeys(tips))
        if len(tips) < 3:
            continue
        # Style 1: "what is the best next step for this topic?"
        slug1 = "auto-action-%d" % int(card["id"])
        if slug1 not in existing:
            options = [card["tip"]] + tips[:3]
            correct = int(card["id"]) % 4
            options.insert(correct, options.pop(0))
            topic = (card["category"] or card["title"])[:60]
            question = "What is one good next step for: %s?" % topic
            if len(question) <= 120 and _insert_quiz(
                    conn, pack,
                    {"question": question, "options": options, "correct": correct,
                     "explanation": "This comes from the card '%s'." % card["title"],
                     "icon": "\U0001f4a1"},
                    existing, slug1, "auto"):
                added += 1
                if added >= limit:
                    break
        # Style 2: "which topic does this action belong to?"
        slug2 = "auto-topic-%d" % int(card["id"])
        if slug2 not in existing:
            others = [c["title"] for c in cards if c["title"] != card["title"]]
            if len(others) >= 3:
                options = [card["title"]] + others[:3]
                correct = int(card["id"]) % 4
                options.insert(correct, options.pop(0))
                snippet = card["tip"]
                if len(snippet) > 68:
                    snippet = snippet[:68].rsplit(" ", 1)[0] + "\u2026"
                question = 'Which topic does this belong to: "%s"?' % snippet
                if len(question) <= 130 and _insert_quiz(
                        conn, pack,
                        {"question": question, "options": options, "correct": correct,
                         "explanation": "That action is the tip from the '%s' card." % card["title"],
                         "icon": "\U0001f9e0"},
                        existing, slug2, "auto"):
                    added += 1
    if added:
        conn.commit()
    return added


def evolve(conn, llm_callable, pack=PACK, n_cards=2, n_quizzes=1, actor="system",
           llm_error_budget=2, db_lock=None):
    """Grow the pack. The local AI writes new items; reviewed content is reused
    to top up quizzes when the AI is unavailable or slow.

    ``db_lock`` is optional. It is taken only for the short database steps, never
    while waiting on the AI, so a slow model can never freeze the web server.
    Every item is committed on its own, so an interrupted run still leaves
    usable content behind. Returns a summary dict.
    """
    import datetime as _dt

    def _db(fn):
        if db_lock is None:
            return fn()
        with db_lock:
            return fn()

    started = _dt.datetime.now().isoformat(timespec="seconds")

    def _open_run():
        # Close out runs that were interrupted by a restart, so the table stays honest.
        conn.execute(
            "UPDATE academy_evolutions SET status='failed',finished_at=?,"
            "error=COALESCE(NULLIF(error,''),'interrupted before completion') "
            "WHERE status='running' AND started_at < ?",
            (started, (_dt.datetime.now() - _dt.timedelta(minutes=45)).isoformat(timespec="seconds")))
        conn.commit()
        rid = conn.execute(
            "INSERT INTO academy_evolutions(pack,started_at,status) VALUES(?,?,?)",
            (pack, started, "running")).lastrowid
        conn.commit()
        return rid

    run_id = _db(_open_run)
    generated_cards = 0
    generated_quizzes = 0
    derived_quizzes = 0
    notes = []
    errors = []
    try:
        def _context():
            return (_existing_titles(conn, pack),
                    {str(r[0]) for r in conn.execute(
                        "SELECT slug FROM academy_cards WHERE pack=?", (pack,)).fetchall()},
                    {str(r[0]) for r in conn.execute(
                        "SELECT slug FROM academy_quiz_bank WHERE pack=?", (pack,)).fetchall()},
                    conn.execute(
                        "SELECT c.title, c.body, c.tip, c.category FROM academy_cards c "
                        "LEFT JOIN academy_card_ratings r ON r.card_id=c.id "
                        "WHERE c.active=1 AND c.pack=? "
                        "GROUP BY c.id ORDER BY COALESCE(AVG(r.rating),0) DESC, "
                        "COUNT(r.id) DESC LIMIT 2", (pack,)).fetchall(),
                    [str(r[0]) for r in conn.execute(
                        "SELECT question FROM academy_quiz_bank WHERE pack=? ORDER BY id DESC LIMIT 12",
                        (pack,)).fetchall()],
                    [str(r[0]) for r in conn.execute(
                        "SELECT body FROM academy_cards WHERE pack=? AND active=1",
                        (pack,)).fetchall()],
                    [(str(r[0]), int(r[1])) for r in conn.execute(
                        "SELECT coalesce(nullif(trim(category),''),'Everyday care') AS cat, COUNT(*) AS n "
                        "FROM academy_cards WHERE pack=? AND active=1 "
                        "GROUP BY cat ORDER BY n ASC, cat", (pack,)).fetchall()])

        titles, existing_slugs, existing_q_slugs, top, asked, bodies, cats = _db(_context)
        examples = "\n".join(
            "- " + str(_value(r, "title", 0)) + ": " + str(_value(r, "body", 1))[:160]
            for r in top) or "- (no rated content yet)"
        # A real card shows the model the exact shape without handing it a template to copy.
        example = "-"
        if top:
            r0 = top[0]
            example = json.dumps({
                "kind": "fact",
                "category": str(_value(r0, "category", 3) or "Everyday care"),
                "title": str(_value(r0, "title", 0)),
                "teaser": "",
                "body": str(_value(r0, "body", 1)),
                "tip": str(_value(r0, "tip", 2) or ""),
                "steps": [], "call": "", "icon": "\u2728", "minutes": 1,
            }, ensure_ascii=False)
        # Fill the thinnest topic first, so the pack grows where it is weakest.
        topic = "everyday dementia care"
        if cats:
            topic = "%s (a new angle that is not covered yet)" % cats[0][0]

        # --- New cards from the local AI, one short call per card -----------
        for _ in range(int(n_cards or 0)):
            if len(errors) >= int(llm_error_budget):
                notes.append("stopped asking the AI after %d errors" % len(errors))
                break
            prompt = _CARD_PROMPT.replace("{topic}", topic).replace(
                "{example}", example[:700]).replace(
                "{titles}", ", ".join(titles[:12])).replace("{examples}", examples)
            try:
                result = _call_llm(llm_callable, prompt, actor)
                reply = result.get("reply") if isinstance(result, dict) else str(result or "")
                data = json.loads(_json_object(reply) or "{}")

                def _store_card():
                    ok = _insert_card(conn, pack, data, titles, existing_slugs, bodies)
                    if ok:
                        conn.commit()
                        bodies.append(str(data.get("body") or ""))
                    return ok
                if _db(_store_card):
                    generated_cards += 1
                else:
                    notes.append("a generated card was rejected by the quality checks")
            except Exception as exc:
                errors.append(type(exc).__name__ + ": " + str(exc)[:160])

        # --- New quizzes: AI first, then safe re-use of reviewed sentences --
        def _quiz_pool():
            return conn.execute(
                "SELECT c.title, c.body, coalesce(c.tip,'') FROM academy_cards c "
                "LEFT JOIN academy_card_ratings r ON r.card_id=c.id "
                "WHERE c.active=1 AND c.pack=? GROUP BY c.id "
                "ORDER BY COALESCE(AVG(r.rating),0) DESC, COUNT(r.id) DESC, c.id LIMIT 3",
                (pack,)).fetchall()

        pool = _db(_quiz_pool)
        for row in pool[:int(n_quizzes or 0)]:
            if len(errors) >= int(llm_error_budget):
                break
            prompt = _QUIZ_PROMPT.replace("{title}", str(_value(row, "title", 0))).replace(
                "{body}", str(_value(row, "body", 1))[:900]).replace(
                "{tip}", str(_value(row, "tip", 2))[:200]).replace(
                "{asked}", " | ".join(asked[:6]) or "(none yet)")
            try:
                result = _call_llm(llm_callable, prompt, actor)
                reply = result.get("reply") if isinstance(result, dict) else str(result or "")
                data = json.loads(_json_object(reply) or "{}")

                def _store_quiz(data=data):
                    ok = _insert_quiz(conn, pack, data, existing_q_slugs,
                                      existing_questions=asked)
                    if ok:
                        conn.commit()
                        asked.insert(0, str(data.get("question") or ""))
                    return ok
                if _db(_store_quiz):
                    generated_quizzes += 1
                else:
                    notes.append("a generated quiz was rejected by the quality checks")
            except Exception as exc:
                errors.append(type(exc).__name__ + ": " + str(exc)[:160])

        deficit = max(0, int(n_quizzes or 0) - generated_quizzes)
        if deficit:
            derived_quizzes = _db(lambda: derive_quizzes(conn, pack, limit=deficit))
            notes.append("%d quiz item(s) built from already-reviewed cards" % derived_quizzes)
    except Exception as exc:
        errors.append(type(exc).__name__ + ": " + str(exc)[:300])

    total_added = generated_cards + generated_quizzes + derived_quizzes
    error = "; ".join(errors)[:500] if errors else ""
    status = "complete" if total_added else "failed"
    summary = ("Added %d card(s), %d AI quiz item(s) and %d derived quiz item(s) to pack '%s'."
               % (generated_cards, generated_quizzes, derived_quizzes, pack))
    if notes:
        summary += " " + "; ".join(notes[:4]) + "."

    finished = _dt.datetime.now().isoformat(timespec="seconds")

    def _close_run():
        conn.execute(
            "UPDATE academy_evolutions SET finished_at=?,status=?,generated_cards=?,"
            "generated_quizzes=?,summary=?,error=? WHERE id=?",
            (finished, status, generated_cards, generated_quizzes + derived_quizzes,
             summary, error, run_id))
        conn.commit()

    _db(_close_run)
    return {"run_id": int(run_id), "status": status, "generated_cards": generated_cards,
            "generated_quizzes": generated_quizzes + derived_quizzes,
            "summary": summary, "error": error}


def list_evolutions(conn, limit=20):
    rows = conn.execute(
        "SELECT * FROM academy_evolutions ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    return [dict(r) for r in rows]

def set_card_image(conn, card_id, image_path):
    conn.execute("UPDATE academy_cards SET image_path=?, updated_at=? WHERE id=?",
                 (image_path, date.today().isoformat(), card_id))
    conn.commit()
    return True

def list_certificates(conn, user):
    rows = conn.execute(
        "SELECT c.id, c.course_id, c.certificate_no, c.issued_at, "
        "co.title AS course_title, co.audience AS audience, c.score "
        "FROM academy_certificates c JOIN academy_courses co ON co.id=c.course_id "
        "WHERE c.user=? ORDER BY c.id DESC", (user,)).fetchall()
    return [{"id": _value(r, "id", 0), "course_id": _value(r, "course_id", 1),
            "certificate_no": _value(r, "certificate_no", 2),
            "issued_at": _value(r, "issued_at", 3),
            "course_title": _value(r, "course_title", 4),
            "audience": _value(r, "audience", 5),
            "score": _value(r, "score", 6) or 0} for r in rows]

def enrol(conn, user, course_id):
    row = conn.execute("SELECT id FROM academy_courses WHERE id=? AND status='Published'", (course_id,)).fetchone()
    if not row:
        return False
    conn.execute(
        "INSERT INTO academy_enrolments(user, course_id, enrolled_at) VALUES(?,?,?) "
        "ON CONFLICT(user, course_id) DO NOTHING",
        (user, course_id, date.today().isoformat()))
    conn.commit()
    return True


def unenrol(conn, user, course_id):
    conn.execute("DELETE FROM academy_enrolments WHERE user=? AND course_id=?", (user, course_id))
    conn.commit()
    return True


def is_enrolled(conn, user, course_id):
    row = conn.execute("SELECT id FROM academy_enrolments WHERE user=? AND course_id=?", (user, course_id)).fetchone()
    return row is not None


def my_courses(conn, user):
    rows = conn.execute(
        "SELECT c.* FROM academy_courses c JOIN academy_enrolments e ON e.course_id=c.id "
        "WHERE e.user=? AND c.status='Published' ORDER BY e.enrolled_at DESC", (user,)).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        lessons = conn.execute("SELECT id FROM academy_lessons WHERE course_id=?", (d["id"],)).fetchall()
        done = conn.execute("SELECT COUNT(*) c FROM academy_progress WHERE user=? AND course_id=? AND completed=1", (user, d["id"])).fetchone()["c"]
        d["lesson_count"] = len(lessons)
        d["completed"] = done
        d["percent"] = round(done / len(lessons) * 100) if lessons else 0
        result.append(d)
    return result


def all_courses_with_enrolment(conn, user, audience=None):
    courses = list_courses(conn, audience)
    enrolled = {r["course_id"] for r in conn.execute("SELECT course_id FROM academy_enrolments WHERE user=?", (user,)).fetchall()}
    for c in courses:
        c["enrolled"] = c["id"] in enrolled
    return courses
