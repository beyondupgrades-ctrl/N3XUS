﻿"""Beyond Registration Full Business Profile Solution
Version 5.0.21 modern desktop application with retained local business data layer.
Local Windows desktop business/employee management application. Includes employee
profiles, HR records, manual attendance, leave, contracts, documents, performance
reviews, payroll records, payslip generation, audit trail, backup and restore.
KM30 biometric integration is intentionally deferred in this release.
"""
from __future__ import annotations

import hashlib
import base64
import difflib
import re
import zlib
import hmac
import os
import secrets
import shutil
import sqlite3
import subprocess
import sys
import zipfile
import webbrowser
import urllib.parse
import html
import json
import threading
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import tkinter as tk
from datetime import datetime, timedelta
from pathlib import Path

from database_encryption import (
    KEY_FILE, MAGIC, DatabaseBusyError, connect_database, decrypt_payload, flush_all,
    key_from_vault_bytes, load_or_create_key, shutdown_persistence, write_encrypted,
)
from tkinter import filedialog, messagebox, ttk, colorchooser

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = ImageTk = None

APP_NAME = "Beyond Registration Full Business Profile Solution"
APP_VERSION = "5.6.0-BENTO-CREAM-VOIC3-CALLS-OWNER-TEST"
COMPANY_REG = "2026721121"

# Keep user data separate from the application folder.
if os.name == "nt":
    DATA_HOME = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Beyond Registration" / "Data"
else:
    DATA_HOME = Path.home() / ".your-userd_registration" / "Data"
DB_PATH = DATA_HOME / "your-userd_registration.db"
PHOTO_DIR = DATA_HOME / "EmployeePhotos"
DOC_DIR = DATA_HOME / "EmployeeDocuments"
BACKUP_DIR = DATA_HOME / "Backups"
CUSTOM_DICT_PATH = DATA_HOME / "custom_dictionary.txt"

BG = "#050b1e"
NAVY = "#171b31"
BLUE = "#6d5dfc"
TEAL = "#14b8a6"
TEXT = "#e8f4ff"
MUTED = "#9bb6cc"
WHITE = "#ffffff"
# Modern glass-inspired palette. Tkinter uses crisp opaque surfaces rather than true backdrop blur.
ORIGINAL_APPEARANCE = {
    "background": "#050b1e", "sidebar": "#07152a", "accent": "#17d9e8",
    "button": "#12bde8", "tabs": "#10243d", "text": "#e8f4ff", "card": "#0b1b31"
}
# Bright accent palette used across the dashboard and navigation.
ACCENTS = {"Employees": "#4776e6", "Time & Attendance": "#16a085", "HR management": "#00a99a", "Leave management": "#14b8a6", "Contracts": "#f59e0b", "Employee documents": "#f97316", "Performance reviews": "#a855f7", "Payroll": "#f04f78", "User accounts": "#0ea5e9", "Audit trail": "#64748b", "Dashboard": "#8b5cf6"}

# Bundled English spelling dictionary (derived from a public frequency-based word list).
# Kept inside the application so spelling assistance works without an internet connection.
SPELLING_DATA_B64 = (
    'eNpcXdl2ozy3vO+3xEax+QKIXwI7ztMf1bAFOas7qtK0NaB58vBvGJ7tr+T133Br/4f7N9WjAtaR5sQ0BpvWR9AlrXtw+qgpjOpT'
    'PvYk1ea3ROUDNe9Sq4C6kl7TsE8Sd29/43SXDBHIHHMTFlhFpnWYwY77bpDTRhRfMiYHLJdOIADyE/ynMibKTntYfYb1Dvsn/TS1'
    'pG5QlKhpTFQV0vQYJsia5mmfUjVDiv9LjN1/R4H7efglSKmwmeFqTY/BUV1zWZguEUkRp9M8FKQyM/ymIrA8T/UZyEwgU9wy4kTR'
    'ZhPDPTWUgNxUvEw/QcNzcDovu1TbNfKi32MdDQ78oENZvlLEvgxjEj6Hhbjk1zqQVckUQWAlDYxxmcZHChxNFEzJAw3yw+WlHNtu'
    'YErqPdUayDyr/qRV3xOQUid2Yc+NtNS3KEub54PFU+Q0m+oi+mIcai43g7MWtFs53MaUhsY252fdh6mjPIDZXatYU2ZtbXTtXiZV'
    'jLqXgUVOxL5Bw2E5KiNz8FMAVMjAmJj29VwByPZOZEvfTR0FlaC4NeSnPnYF/EGmtyp9H+7TABhb3O9B4JXsQ6SLe2LJAFJkI3Mq'
    'bA46lT3iRajG42LVeHjfdoM+giiTR2ov28W9BNYAu6h1CgFVZZQsF8T+3toDRYgEFbjT+XRwoZQ+D9Mi8fOwuKadnE7ysuTR6Q8+'
    'XjT2c+rsaxvWKRySX8wXx/XUnZafkzlHmmaeOrmnTtHmdNrD6i1P112CC63CK6MhvkejKcxCBpkyLh/3ZzqKqGU27K1taPWZyE9X'
    'FtxYSD4iHq0Wlx6r0kqeHZeDgo7lmP0FTMcLryf3t+gaWbW69zGxEJDZZi5eRz2914vnmgx2lUpg2BudqKPueemEviAhtVxpkSqd'
    'Hotoa7RIWm8P8kxUSKf0SoFjEH/LzuVynlOQKUgmMlbPvI4lb3Nr0lHHn/tB42mkkiv9TCPU7zW/58SG/uTjVXN1JfGhc9wQDBwt'
    'kLFCyQUZ+7+jtaF7Jy5zp6Z2HQP839HqjJ2QXQzD61Q6jkEcC/Jqong2Vt0Xg+9qJsjoncJab/cQwnNhHpVpaT012/x7aR0x/YFQ'
    'VMlsqhAoy5eEuZQ3yMtHiTN3fjsiANeYKHWtM1dJVa9OYHFthIMHEg10RGmJwZJHV/e9qP0kyh2Vg1EHSGC02cd2rE3HHGDnenfP'
    'Clwpqzkbh6lAXaiwbjesUpMRqRqHbZfqWtVpFU+jkJk0QsOGp6kIoI075WK0/SSpo7+eCdJiCrGj0iyU90i9mIVRf9yt4+h17EPV'
    'MYaqYx+qjql1ExjuNUJ1pTKx6jaSWXNAliGQBsyD9L+DH9MEeTo+EzKaMBpZosX2TqqZUTFurYNiKlLNUFLGKR1Qt1yTkXEEQeEd'
    '/8PfoL57xNBY3v7LGuaQKJT/8oFKK7RdY4u9orQQa4DcNGL/jXXHoozAoS7BREYvGbVchsoS0IZ7raT/oQwgNApEuuKxxkXL/Llq'
    '6x89E921ufzVyW1RpTT7mM2B4Wjew6qHWuzNES5ORUkhORkj1sUdbKMe2TS2S5VTNVAmdrr3VP+o4o5opDAmMLF1cHlrup1DpjHj'
    'b+6tafD9Qif0Ul2HqLRKh4+UWbSz63GOepw9gB5z5F7u+ZKL9PKhTMnOk6wsyc4RdhdQ7Xbtxi5RZfiuGKC3Wq1GgHiaQFiZBuqn'
    'L/rIUwDzAcTNWh84NLZLhfELf+qjhGMQR+LlPotEMURBZu8RjF3GRcOwraUN3VoeMnyf7AVj6JJOVi704uBKTx4ySh34qcGSkZ0F'
    'WGu+0snGk0b6Tl3tWqdzUrZMtQ/9pJltHDAaS2A1MYY4jeLHV75zrEbCRlNk7KwGs08U99YaoBCkkm+wB2KO0/CROKpqE/1n2mnW'
    'EvaFUdhXarNXxPbrqycBNIxm6dHdEVJgNSFybYHgIkSO6JIwjmLdEt3Wnv5oFFaK7p9UqM6gkX3PwMnlsLF5GvYLdQCtEVNKprIY'
    'TjvyV7ryORxbVFkc5+lHJvMU6QGzpPlwvEiq2A+AMwpCCmKBjdFhmR5P+i157SjHYHDzeKLmElqTTD6lGU7axAzRn/MAr2xRoNYB'
    'o7SvYkgoFC2g+2BYAyEdPtmxQH3M+S02T19JbM1MZWNvLpYEg+c3g3hwdQAqer8HytODH/XBP7hobSqHZyAfwjgQdqm0gvIowzpO'
    'v6500GrsF2y8UHyt0NROmcHBEfXG0yOEpEcX0te4Ti4pMZ82faWg6BmDyannIu3bMOmsQg/Xn8e0OywQRWuKmhGsmlK0CIz4HR6s'
    'rY+MP3jOmjUD1VKA/TIEkNPIvVvjUMtA5SutIuoJWjKSVNVys4/YKJDIRvw5zKqoIKyme+spDg4JLhqOz7s+XbhW+h6Y0j4OrJ2i'
    'B368EatWXp/41yBhnN26WJQzDjonVqWJC41e7uR4s2U6+ewITgv+0j+vaEyqydMys2MQIrUTxusov2jbpnIvrBIYg8hhqwmYs02l'
    'TRdNuNrIJm9CMz1V5N/UKvx/KPrf7f9zKPlVQdpkqE2WXi3nv6fllgErla+WqG8uercMm4fbgMHyjLkVys48JCiLOtxGMlQ4HtCS'
    'QUWqgEwXSAVI+R4M8HEbqKwTKzwYArgljAAaFAJGNlDTKpw6svMUbR9tEOeA2qQGO61l9L8jlf8dcgiTe37mORDdjxmWKWfOdKAq'
    'CiP7RoLqLukT6/VzG8TcW9lArs9t3oFiPadtQxYpNU3FpwXqK7aP/aSrn9a6MCCzGrSkzia5TOnlYEBXG1Lsz7TKI2YT8xf+AzmW'
    'mx+tK4X2MUl8q4VtSk0PE/74iThgaCrDmpjipqq5ENNn1SLqrE6CIBeN2MFjlWrtN+WqTgo55JkxYyeudIA2bf6G/Gqy2iSjppnA'
    'Dh9sRlVs6kcqo9BQQTZCd705BU2GMZDfo7Gnl/7I02rTyeUcVELTo41+wyFHQyAlExUIdmlSZ+HvNZ3RkC9H7xdqD2jyaLUxRXJK'
    'MrdhlQiPu0QslkPnBvwyc96G/SkmY81NZrbgUCNEMbl8hxPHOr9pfozJMAptfRQbRGvbqbyV7s4tf6PVsT08KW7sxXEhVzpmtjat'
    'ecFquBBuFhQsWmdsnBBontGMz6zXS6uFXAYMBsMMfUbL2fKFnDFqamWrPef8JdUVMm9JhT9vOdiBIPOnTmwtWr5+WP82Vt2m3jBc'
    'baSlByI3uCqtg0CEPY6aK9cXZyxZsvGrKDE72mWo8MHvyREP1PiqQeWi3C/mzPuYY4NoxBpsPClzVvzquEtaPeA8+dXHizm5Pzi2'
    'm/eWtw8kf2/D9jZeZ3wpiE01mmNOR+dXylxIJUEL82aFbFZLa6K+CQ9pUXQWLTMsQ6W6c/16GTiMAKiANcYUCBHLxhD6cmseMfe8'
    'UAi6JZpMrStHASJjz9GYMsCkG8kSjTjUUUAh6smXW2GjtGChmHWITLP1Riu2asRaNqGnX1KrvoCVisY1jYxSk1HSG3FSzaqoQB69'
    'prgkDZ6FayfTr7+t9XS6Pz+oK8uEv8sObGg+oozapAHX0jzb4B4mIxVJog07AiyIQKUUrF0MgSkICyQpSseyHGvkf6t59LdOmZO/'
    'JacbW/uFlRUqw8uaLzdkOcpUuL2xxL7F0rctFu9aNCxSExuHJSOoDX/PqbWeT4psvBXlgbVv2Zjkrc001JM0Sj/5kMWxs56ZjMHs'
    '9oiRdKcIAGthXI8Fay0x7Js4xF3R0s4FwF//6FP6RW3Z4r0LIaPU/pogDAHWIS1T4J2IaXYnNZgtMdOu9tBn3Z3X9EczXnU7NDOV'
    'R4iY82NSEI3xI5F9iB9JazhVE8n4tEAt6fObAkcTpnUdtudnxuL5vWt+JKbcn+EdVDLFwp7hY3snKwqm44XXk08nd3AtwZh+O057'
    'npNwiYAbRRit9+Q8yaSaccohRldPuXnaxcTvLKRB66CYdQgNQ0AUonXMLxRKDQShevQH+jbQU8mCgyPKdXzLGiGn+5hRYk3gDic6'
    'WnCtJi2dDKdZPlkpT+R7N6BviP5KmkusDwpr6iBINmQmEtW3g2eBXBSpzN4Hh8sNstRlCKxB9m60q4w1vpdJhfsxDyq2j9lqEcgy'
    'tfpXZKGm0kS2KmsPxa4N74pQkebHa90HWvOG7NPWSQPTdVKuAapwT4FjJxQEqoCmWOxpLFe3w+ZyyeRNnC41+BCY/KkvFq7fTOi3'
    'Uvj9mV2yyRSOKKwRFvNXVVdLrw3WkbOVxrY8yyW1aKKIP1Ijvo0ykBVTDQSxTq0VVZqDjicPN4q0knlNQpvDsQM1GTtTG3jR1K7r'
    'zMKzBPkoEpjlfOzgUJK9ldaIvmDDWS4bCaezA0ZByPcJKvryNXuzkwQxyIvnKCvzpc1hFpXJrCFRGwkWlejaqitE4jxJ2L07qH8l'
    'pXwQRQYMAuF319pKOuly0osDtVuhqZ27MeVn2hOOjkisaRV/erR0clmUKcu05Lx0QrsnJ28Ny3CPHoiaqXamUBv9EbaBNTr31k9T'
    'ueVRGUlKaS3HitPVZqKbilfQ8eROlTX8EE0jWTym1zAavFbJ9oGxnx5pDZSNhsIsJjtERXcoTcQOXNHbdJwM7FMmCeN6AlF1GP3m'
    'FmJE5WXPPzYFW08m6xcWDsCw1adauCtl2NkW5lcgS1grWEwYBbRS0wY3K1P/09Ks2IN9iNk23uTg5/s44z9PzA1RlNlUfjhjWj+7'
    'dqjWz3ugq7e2RXNBi4QjbXcB91k3znM2nZDYfEZiG7D8AVX1KxitIrudvxv8paJFuY2+0QptU6LgNt+dP1s9qfxmnqMgrERMTqLj'
    'oZYZISbfYL8XNnbK5JLTMzo+DRWCTyd38G3MeD/pD/3VfU6B9NBSenczuG1YU3tyLnhyW7BdIlFMWnYN+yHLgs5WGM60+2DC9Dbq'
    'wfW2pWE2yHkaQmpiLwAsBrWhnYZteCzdY7FVTYF2UsPJrF7BLOIy9/M+TdM6n0cK2rKPgylqWo1WYaLmh2SfLG+PD7TNwzEGnkaK'
    '02yVUmJ5JZgNPbsRVR6CRWyD27WSOPvzKZ/nj8PNk/xHR2Emt6Au+J3Log0EWt0n5RlReyUPydR0785pDBWS4kCq1QtpHP3SBkT6'
    '9kVDI5MxmAMoWOZwRph/Ot/ThY4nv/rtAUrzspcnJ7jB0slrd09NuEejfaXjhdcrf04btXnAQNjEznO0OKIRzXw7Y5m30tNlPl41'
    'Tr10XYB0f0RE0WjDYOdzdlryK0S+uoCXJ23gPx4nnny8av46qxdNl/bTx5Db9lawsdluMnQGAQXHrjcu60NleEXxR4cMrK1Zp70I'
    'jFDkWr3j8p8OCP85BdY0hbP51vnhFA6NtJfeukGNkFvTUnB8vintc3yTYJhAWIV3Akpgg0oVUlvs28dML7AWk3KTOnGWLqwiZVD9'
    'ENfAPbhqhnXdHLkfbOyUGWqeJRzblncLb+O3FYupBRHWKk9BEWzKkNh1cF4IrSZFjd3avCFvF1rJR5zQrCf/mH1LJuPUoMg8yeEk'
    'SxYCYGtPuQsHvnOPO1g9qXa+Tp1lvDrKLfv2cs+YxBV1ZQU7okVjxRKncguX2MqoRTQhzSEvDVRggTFW4c5eSRLq5cCCbVUWz9KG'
    'piwi3GuDOgoqQcl8HP60Im5frjqGLr08QsUIsykci3kJthUFzKcK20Koq4DO1Rhi1JnvGLTaVLrPyfcLZR6FJtyzzyd74ctM+3NJ'
    'dvmbmWqg+vqC6vDdKHOsb85hI60sAzaiG0S6llaqsBVoQiNm2IINAuxOsVoR107o7CvN494JjZRA7dE1qGp7G9O5mLLwKy9c0yxa'
    'QyvLNu0GeqYC+3U4aLJmrBCXNnVpnRbqBWfxUJUDXIYpuvtQtFZPCG0VKlKth3qwnWpsZZyI3cDFovNqTfj+SJUHjVga1t1gcx+D'
    'IwuJqUrYxGZdaINkGI02toz80DBDjLIwoIYKh1WHoIQ2YL4QwwqlBufAAGyOIGf32RkShsppWSDLnFm37As31HI8BUaDr4PC2qRs'
    'frDYNDrpI4lVMUx0OvcKHnmfGHXdJ/g8cDm3aVhqmlRFD1hFNAU329OFjidXpoZGWTF9qZySOEdMVdVDN0vTxsjlwpZhvWiSNFW1'
    'REubBOWDZtBl18Z8gQb/7xzWEAaeGSFNYcZYu8doUHRDJZidlX5LpWkYXEU/Uu/TRJWdfr1jbStwNJGvtPFTxBRTqFSLMzewYlXb'
    'TJ6en7ejcCbZunepEPDkVK/i63Ett06qq0TOabVPVnmCpH7/4+b98PsRudOQ8r8Vs29InVNqXV7lX+u82STXjT0UQdqVqs4VgGhc'
    'WFuZ/WFURFgm6jaVK1NYWz/N2WkVD5fMe5hV3jsjsGYGCzt6qHFYo7Fa5ZfEQYdGQUonATyRKJTLpB0kk27EKmOqgEA/nbBMVl21'
    'ItirNzUaK7vBNuVi43glldWaasASAnVUqBFpf6FOo5YsyNirB1PEuJNPGPZOHJSbaJIIZFpazjr15PuVjid3xK2xwLobXLhET0Ml'
    'baohqXYxv8rb7FlLsPGkp7395D57OTkdHUsyjEYb2+OxbOHPVPYlYn3EBBrUJpZVtB5MZgeSimaaNUwEdjt6/Lr7vLAJ5ezn0WFz'
    '5z93IqCyDu3obe0hLhtiZyINwm+e4QP7EFTZ9zb+52y87rxkQNBAuu5vuTl0YKV+uO9LaNYtBvvA6gtoDcmOHRnkFOTsz8QPLKS1'
    'GZryxjV2AakEjSBMtOq/P7GYHxgGkkVCozf7zb01SgocdX0w0i1PJO1Lbq0MV7M6hTGWObnNQ6AJBqpQlcstg+5aSiPTKpvoh2R7'
    '0jMJsp/MVmhYcKN33zmBJdDN7skrCT8VmYMMagffhvD5ja9B0n1+y6nCGyZ9sD36ob13QmQ9FNHwGrjLS1q2PfA0sRRQumcXSVB9'
    'MN1PFs5SOERbRBKytONFYseqccG64SudDBUL3Ndldn3rnbvku8tG6/6lk3x1FntMc03oECfbP53QSHdG935lVMxx7pdHO+1+HMty'
    'XhKSRg6mG6tZsPGkpz3DONp/nYw77t8ztwrjQswRAR7j4LJJhgJ5jLqSSZRelwlM6BaDe6gKaJzYkAgn1m1xeG99deuvH2L7gMnF'
    'Ad0j1ZHwS3jSXAVLmMZgkPc4KO3ByymEwYgia5LMmCBKwlp+g8Ld0tZ4cnx5lBhWHhXnON3Gdw2zqA0JlFgQ51FQ5kvrRqDubBKI'
    'yr/Kk8f7Lykjx+1dtHPBLob8CmhMh8C1E1u1oTt2g9QYBVNYO/eJCZyqisXM96qbP13PBsi8m8YxEOvSycZOlUu7NqWPnfHKtyk/'
    'iiYPTXefB4Uck+EjpsLHORE++jT4wMEgnc5sdOnWZBqjQtcCmSW1dTXhWr1OI5xFyCM/xX4sqwFdBU6xHz84Ua/p0IvDO6j9MIs0'
    'COLl8d0rhncvHFnlBsWL6xZN5bTixb87FM44CSPxSAYElsog6zLYvmglm0RBYLtZVlVONbp9sfK+PH57xfDtheavnxB8cYMMqppP'
    'sGQTOdcZyFdmtDDHfOno3uuYa6BcgkDme0D9hgp7IO1BKgALT1BHwWroersuo9RkpN+SpGqEwJWkN4zoiFNNqPjw7yc/+purJm8W'
    'pve3pRLnbmJh8IzJ8jszhmgw2rf/Sfhrxq0MoDUn0G5C380jIj+cbjazT8Jfy+DPvKAH/M1UXk3BDPUXA7Tbv9vQ/t/uuXWsN7x6'
    'ceOzF1Ar1MmwtokOCC4fNPhQeeY8ksw0xQX8eSLB8aIbN8Oozi3oILRwvMUmo/x8U9Fy500dPeDBQ1SiWku5uc+/sceHyhwNwowM'
    'TbA2nBQJ6e+WhHoyzJRPTaJGoXIpopM52L0V1q7pa6EX/Sc0bbh4GxC9MVGBVNxjpooooBA01fH++pqZctxsYSL59xjo4/FIzMfH'
    'w3YM5oETtg3y69iBniU2BrdI+TRTobPWKHx9AXcqDAyVoqm/CONbyki1SK0ELefeBuc+ZM7DYyDMw+dbDFXYOAapJvY46JIqWJuv'
    'v0wSyR1b7A3pV1kzj+8JyZkTKheQfr+wTNfwmwo/4Kx4z3Q1D6OhCtGGk9TdzpIMVLiJcpptHu7y7pjPeZcLng0AoXbJRdlRB5qi'
    'KSdwa7kzumWvOUrw7wB3S6tdDRCHFafbGtwLDvEGQUVhwecWYmA3qCTW87MC7CvPE7+imdxaVUHHoakb7lQ05UFFolzGOBcTyDzm'
    'XqSqT+s3FXOH4mKyfvPRlSB3tSzWMGTW4nWV79W+/3fw46wOwOd+O2PB2Pi0ipEfYOOylrGK/DLakFJaNcsMvrEyGCfmvFlY8gOS'
    'MASy/WOWDzmT4BtjWO7NvJUoUhzRN9IlXxK6DSwLRb7SV2YpE7EZrtmYMoFcwG3Am11G2T88mQFNUpUwFQdnVotz5oct31TkV9+p'
    '+PsUZn9R41BwXP6GdfiJThmqMiUvaXe2sLpgW61Wk12oBrKoCvPOyQ2r0mqni5Lv9Bf2NsX7+mJ2Rek4yTumk8mNyjJRjp0G4K5o'
    'lYC3Yc5qAQo7HvljfNvEqZVf5ayKWdExcxGLboPVOS2TaGvZl0TBDu2zoxhVprsmKiPVWZlT9SF9zBVkDYtClfypho0o92Dhkple'
    'PZgEm6WyTDe0/SpVXqh+U+HHATiQxmjLslozWl2FU3EQ7MblMnqRor6VSFdcTv53Y1vaZsq6gAFKd/sdjYXK807KscD+tInuLIAp'
    'e7GEzpYUlzeg7seNBE0LUD2zchsvY0xXRpf4jEJ9u92bBmIfomK8z3bQehJe3bzwak0fZOz7nMKQe/AnlTGLM8bSQyDj8aOihHA/'
    'SuPHFYTIGJDB8e/AjwigdkzsBYk0wFdtn7cFlbB6AhUZgOt4NzcWDRhOYjFPwzeUhYqsF1svtKbvlbRQ4awBZJSajCrBSd8dx2KK'
    'QVoLBcrAKi7WBaERyhFUFF4gDWmGc+EAbGIEUei7pdtxVZoPKhxdAvOxkTyxJTfR5bFwO9oaLvyCcL4owkoQTFE6dsEP1BeTecdF'
    'BgBLa8LWNOCbijmPFYgotvcsT3lhaPfsjIerMY4bgs44GgUnozJ79AcceVG5YT6YiWOZRg4YG2MtEdKnFKxNAncVCBFa7RMjwz8W'
    'nEhEuivs9AXlO6VNxmCKBkOUIR2qIqQvjqsIdPGl0U/6SjLnIBLAMk4iebwRLXhyHNPoMctRq6nrSWgGLw8W0wc/3+PBggrg9wJZ'
    'ZP9QqQPKRgI0csEdNqlr168urQ+VzUc5OBQ3oecDnp5teEl4JcNorEJJBMEUR+Qgi1r5ZAOTWjsX4MQ/My0mBiw5jtW3ihbOOHM0'
    'nGa8oRdIqdpTAB6jyWcAJFzhtZsv1bn5i7mCLc81sIpgUoJbOl+GKmRqZ12mNilBwolizE+OsXXGQWvQJJWVFPf6WJIbuecqK9XB'
    'hg89IHDhsshvLDmBSa9I8pvzHptAUcsengarpsLXILDbN1QG6MxTgGqeWZY5aWnqUypjyo/lMrm6hhJlSTWxk8O6wXTfO2Ef1fhX'
    'rIqGhh8zqI2nuzKDlAOoTpl0a9SldV3YhE8lbI1auKZXniNV4nT5kHzscTX4D10DyMoev+H0qMoPMe7Mdp2pR1qWaH4saufW34wQ'
    '2tDPfT4oS2NJvxOLSnlQgbQyUfFHbQNTjkITh6RQnxNbDtz9BizHSAFrK3Y4Kwwq9aniVvg1CvbqiwgFvSe23OUzS4Vh1bOkjbh9'
    'JOorq9tw41p5xx2YFM2audRL8syYS6e69eFHcEvacAxHbV1tEopE0feuj113lk+AnEHovxujgMFlYpowXvomzq1lQcXYeZanYfZy'
    'FWimG+xuCRiCSDVjICD2UzhHadg6JTvP/nQsSm2oxQiohO0c3RA0ok3Ryu9vdRz7e/qB+csj++T1wyBVbFLD++baBKES+cHfE66Z'
    '07eow2oNRHyjoKwjP+whPplV9ve4qQH4Pb6f+Rbk1Umzw+1vKBytc7OgqcfMiV0baJebnkNpPG00mrYJz7I19u1vO90/d/oDygSy'
    '1GFPfDEMYBs4RJMx0bbVpaSFEhbUNuxBwW4jkqLHZIKyIZkgACs/AhSeiQ9TNHhPqEfTf7m1urhzfuOmMxcjJkZuxhEKotI204YL'
    'HwSmH0SWCnD22JqDewKKBIlMP1K1etgGGjuvai8XDvnwurKpYh+oDTmA8oRNaJvF5lHZk1u7q6tmsR7/V8N8iYX622XRLdbbpo1H'
    '7hpuVJg2nFikqknwpOOFxCWjPQZ7c0FzKlKmRKArFH8ghnJ4k7ZRbJI1YIY0dRw+nVSxbR74bXm4iG3FpKZoqvcDTbaQBn6Px+cm'
    '48xkw28sUGBdozCT63IwxHrgCjbLJgRxvjVJy9xV8bFMBrFzCXfiLUxCMagogfGDgmjKOelJytv0ygdWqIRaLxCHo1/N6NsHmLl6'
    'C5Ur6GIQPnMB92Bekh9spzu1MVeYQBZtXXTOEKGpy7Q/L/SvBcWoxs1cNJg1BgPQDttqN77SQ3UUaIITDHkAzsN84g6FeydGel2t'
    'ysv6LTXtgZTK6/PA7ak3bYPnizkFKKe0KMl9IAVbJec3SR0FRYZ286tJyJwGx43Tv1mXGIAWljCpVtamUJldxCpip5xbYMmDZ6Ya'
    'Y3I9EppjKOTM05OGxrWbdScaLs0qDVg50RsaOA80Sk3GLw6Lg4WpBDXCET+IA1HzMbNXhGoP3/YgN7VyumfCz+Uly7k/12cK91mD'
    '6znfqTypfktVuRIZO6vBJClr2wLIF3PEdNaTvDv734ErqqS0+qZmVSB5lJqMj27iXDdjgrBj8QyXfJlFzOceTo09tspTcGKRGsEi'
    '1ZFrE8wbdqobrVV2QNuCUhLD2ZVJu0sfiWydkx4dsLvyOxvAlSpcHjcMDZn9mIKhv5mxbtgUr0nMGED2vDsw4JoPNRk6lGNkgGR2'
    'ubpoYxudql1wJQLoonRQRLEAeSm7VJkpMGfz4XpxVDdDR7xjCMrSlYd/etKcajLSdVazl1nrs2s9kCU1R/XHU2JQsHhJwrX6zAUR'
    'jGnyDXtx+bZz/CSkpNEq3I3Y5hVIK7vJOsSYRaApbpkzY5+OlscZsXhwqTQ/xmHFNWyx/LpyjOkzN6LyI+/UHHee7c6NP3lL0ogU'
    'MLqO6zQzOEAlKukcCmYO/TPrJltMNg+Z7xMRmH+zM1U7RQ30SfM8vRjsjPEeekMM/5quDWu+OWE2n05Gb3lfM4KdMQGfZE2KwU1Q'
    'foPZX3pmNPQVOa/My42K8pOYOtM4FvxDoIgFjXMbcK6/AxHXBVNnHEtxZJu9/QNsg5bj2zSt35k0ydEz69kmcDabmS9rEGlKGXLM'
    'orB+KbOJNOBz2g3/y0J54TJmg0mZv2KZnwPFvPILUZ9ZMDERacqdi+ImlYzhZtVmIOpWQw5JG8qRBkNsmTKfq75F+8S9uqw0IPq3'
    'XJB4jOQyTpA8XQIyo5ilSMD+lErrfdH2ZjAZSkUCcCviDhy1MghSDBRXoqEhU/4W5ztz087SyFSUR8L1vVsOTyxwTWXJLPTNRJVW'
    'M7EOj+c/Hs9AOkZRVpnFzQnksLY5CAoNRFEobm2D0ZAp+82ToQp/W1OM3dtc7yiTICurD5v/rBY/VylJ6iiQmQKqXAvI9c3VodYW'
    'rCq7+8CCweznlXCBPO1PBaU1+uxV94YMet8VtnLC+aDpdwM1ZMecXqpsZjLMD2bnMStWvHmvH6Kg6gUV0Y9Isp1i1oi6WzDBntQU'
    '8UyWCf1qt7JVlpsCK64XR/vsyuYDC5yKEV2yqL04MOUnfI8ZEyZ/xzd2x6BWArLsPdGp4vamtVrRt1rRt9xSeYc7FNwfuvqhox8V'
    'jh9G/kdukIAPF1Jzm9FhIUhIb59Yoc0+9ZE/qrGY6zSJhTMdqKNAU0kwwZOrHCZTmGUih8xCWowjh1uNaCG84NnlD7E+h7fIXpK8'
    'PahYZT9V4mBE0fOExDBYpTKgb8aZZ9aBKrA4wvw0yLNXAkmcjNXrD4WTgOJ9dz6WGcbMH5NumFfhx/Dmly9Dxf0yYJVKeyblWLGU'
    'iuczR+bWK0kdBfNHWAzWVvp9OdyXfGYe+SmDSkrhCSPASk+/iXH7nWT5ix66aLeJwCzgaBbqLuNvqSOHcmAsWCBafA6miFhjF93M'
    'emzj6MdcBGk02abVTC4dNrcUSywwioSDkI11slovlPmVMIr00lOR56R0pkinTf05NRlq8JsElMLGXtPnktocX9oXS3dibSXQrSqi'
    'Dhk0FXa45nLTJRcCHfJdlwasAJPnxCB46K/Uzi2O04aiQ0g8xU71oW2iSKF+EEeo+QipfLqmTOOcDKOR9tgagMrUAJnaRpiR2jIo'
    'EyU8BoX/wEPvRYy1gyh3XDvxYgiBeSaigEkdJ/IarASp4VlxaESdfZniRcFOP53uJ5M3RmThcLvhotCXxUEvlLdGdshwfXQia34k'
    'jnd4h4Gq4lm/Z5tG3OpuWY1YTHVUWo/JWOxqnhquuBpH6gLA3qvBrs/0Iz1nBVDvqjZgM3tY0LQGpjGYQgYtxvDIqOCMxFMNa9Bq'
    'rvVvUBx1bKQNPdmeZK6UFc5doa4Cyl/CV286yfAkNQ8nSLt3monr9I3hEJlGOp3KIashgFpO0Qu7peLpMtBJxRAU6vxZReQHnx/j'
    'D7aBHo8In5YUvDtQDoHR6HBp9kAE05Oqgo+e3EOxopaxqfqQ7JmhOnbc2S8Hy+whjuPPgtFYhfLClcNyLHz2uxG9lwJC32vVNkfh'
    'dLdwzlo8Zy2es5aYs4Jo0bMxntMRMqXYN2fuHFzyJshC4e0ShSPqt/Jhw/ZRPfswOcjv1nW1mT3KLKEKGfZxy1RkmHEn9IYZ4wpJ'
    'nDqyaB5IzKExAk7/J8NorESp7ydPFGB8fYzjcxBw9Hl4CV4bvVBpCH+4rn3jekJThjkHUjReNxdyxiGEAWRxuns8GCc+vXU7JkxP'
    'j0nzU2EVUfAiMkIM5hsVjieP+aFjJI0kqaNAlpKAg45NYUkjMnnzN6KC8UtTBvqex0z3nFIRUL4Or/IfXuXXetgxv7kuLqQ1O7AD'
    'gyMeHwgGu2WjwtgtOi1wcNB0eKjEMbOBWgWlo4EHT/q1gppotlOxEBaj45z8dlpPrpn3kVXYDr58dTsKmztC10soWA3k2Qz8phnm'
    'Vq39wuCKoEP+nfPo5lEk88EmXJjE2F4IZcAtB+GUupGJYvTIn5WhPw6OAA+dJMaUgPbftJxjZ/Vgg4PfObnpR04ATlIcwzxw+1zA'
    '/fWjKKmrdi0b2alqaHsUxhHbrU31POrQ5PHoM8VDN7cb1kFqEsyCXaZqtRvZpdqvPk5hzDVKYdFGM4TWZzbILAnguCoT1II2mGWo'
    '3tOE7ymHhksawfmdGBM+PyQYhY4EiaQyipVUj0CByBlE7DoiI4RTlsRdFXynC5lwiHpoK4XwpdMN5h+zZWKd3XdOa4Ryxc8MsKC8'
    'PvOcTB2hXe3Nzkj/PNsMkYnVCOBAGB+Gr+Hh4XT8/lKh3F9tE7w5XH9zaPtu49U35Lw1hNSXf8cI5+0O8e2+7e0O5M2saGF+AOyk'
    'PwVd6YfHLT+4qqoW78Nnb+//2ijmPtzw14oPVV2BbPSGVSzgB2prm6i2xopY/+mdoqbiSwMSIdMBL/2TwWH7UHdJbWy3Ce5jNvJN'
    'Iff2mXkn946flYKLkbMmY5YRJY6SMCJa6X4sgDoUA6y+IKb1DIwzE4GW+j48odAQe4hQM9SKc2tGeP8v837+HfNPKCzWILBELnHP'
    'KZlwicFU0Zz15Gwj92FNzBwyWd7x5ogpTtRp+9g6RrOxNYjdMZWz3yXobOwUpaJzi+u/YieNgzywU3rXA/KAYhfpRhV7aEYZY92l'
    'Exp9QXnmg6FMbe4USNvpnglf+OGd4ULXK69dw3zitBQHZ6koXdzKKmK2dSpn9tAg8Uxl8I+YkjpLlYb5t0jyIrELB2YglrvM9L+w'
    'Tbvz/e6mth6J0cID60DclaXFsSjyOlsKopi8WMKwaMxWHTTLpLAKLJ74NTayyizkDAVvMg/ETLVIUyRANar17lDwEEknTJhp6VTp'
    'Eq9i8nJzxDb748JyELnEdT9gyGB8Ntm1+VCGfwhb8SIMYQq9v+/KuoJfVqoMhs+L3DH/mw0yvutVtgtXCV51X8lEH7XRYjgNhIV1'
    'ZB2n0YDxghm/s1k1nWU7J4N2PMVr4I6x+oXLglmzsgFiM+ALFndcixgFRcVy9TdYVyWpAWbhwU5LOWbbybdAgZkO5dE/XQK2MdxK'
    'p/vA2ow33dZAnxW961IG4IlHhxQf8clcWbi34kGZu8J6DdVA/NAUhW47H+jumo8os3HzFV+x7u5uV3TCKG1cnCfSCe+b2bnvnoFx'
    'b9RsDuwG2OzpdL/QGnwOMXMYuWhtHBwRswWfLec2q/5vWYVl4zVMYxhEOku/pts0NKmT+qSt8uKvifo00BRIg139EZHlddMeMMj0'
    'crUQVWHZeOHWGO6cwTytCDxKChyDhI3EIGKF/bk+QUF/SXyxGhNpccvPz1hcccqNP0Vionpd1LzFYSywNs+YL4w+7xN/4bAzd5bs'
    'iMuofViwabgL1X6AqLUqri5l3LjYRkoRDEpxSck1riS5iPSlL/yCD8kxB/KzleQPXuKASdA1zCVJvAY4QG2rgO1U39gluuMZMany'
    'Nt1uGgngmoy/j0t8cVkqjNZMb3PFZUQQ1ck21VCGrhrPtPnGYxLhe1Aimd1FaV9mPUkNloK4fcYroQyjBS8RJLTaqMh0S25IzGpQ'
    '1tLGdoMyZNPwrGyTVGXOpiQW7p6C6GMU9gVtxuNkkcilxkK6S3SPu0QiRuVMCWA0FCfNbILQuRS5pUs2nEUF1lF3MnHmau+kmgkd'
    'G7zWoBiL1U71C0DUKQo6GxBEVtnxyGr4yx4jAjMZSn0Xd0yF9b68FNeXxOtnHbh/C8UNRk3RXJAxtOqC7ztOIIppZXBtAggFe1FA'
    'pZO3ku6+i9QQS1B3HMecBRpA4ZUa9JJshDHFSCehN7mKGO2ztOxFq986JFNE5Odg4auHW3EQdyikMEMo+3CfP+wIzKood+vBvoZZ'
    'sUbXsdWPWH6EGViR01KexMpnUWh/f0plbuweFPtwKwmaIrF3VmuEZ6rVNZnJ0D/QY0o/Evo4mI4nH4UkcwnFvklhLphV0e4uWQLJ'
    '5GZof7qFFnFMyOl/0gh/96SGmb3rkwA0iTuQy5WkAyN/qCgeOKt3z0eRZlQdPNqIfuY2KC7kMOaAB0e08QvZndWgLNZm/NZHlQmL'
    'xVGjeY4oOKGH56nEaqJPfewx/iI7Q6YunWw0ZajdkV68FVPy997HvwYqiersyvcaZtUXkSpWPoGaIIsyf5lkVeQ2uV0NCgyMGAMo'
    '9+5vJfud8bQABiR85/iuV44JyqdgiG5S5fYDyPd0n2ap+CSJM7ukaV0aKUVdbNIRHyNsGeSMn+pCXQ42nrR2Kp/myNGTh6Pumilr'
    'rBOdtr+zw8dUoBjQopDQ56yQZ2mOcHbMfCywU1qzHKfZFkfrlNz+NdCXxynvYqjEXAy8UAjKDls4miidq+RTYOsc11XxV49JkIfd'
    'snHfSw0dOlC7xfMsv5Fb1tqbwt1L19rn9HU87Fsmh0o8GRK1+W2jxp4DW4QWFfoofGEb6Ns7pMV22tMyzcQlO1WiqXbKEntyFjnq'
    'SDS2Fc7dpAbZZaQ1kHTl1Ro6eHES3JCnyDkCb6U7cku/PWmEFVLMbunrHxrv5zByv6URjG+hjoQvqaHTORfSK0G0G7XRAy/3GeVR'
    '+lNX/+k9VKqs9noVlZcdk4HamTr+sh3wW6rkzN9y8s3QsRLySCcbT1o7dQyDK97zQm88v2acHWX9jgIIzr0AN6n4GU0xi2wkr50o'
    'dNJ6MlaTp9YHntzhFYzGGS+MiJaPiZ2WFBgGeGYGbExqVTuVA2VF5MP6OM2NjveKX5MxymYNm11qMpRAOdu7M8U105gJ3CRyi1xU'
    'ejeL2EIEn+EqJ/On75rxj65edWyn/mg1APpjdPXxm/5oLqLl6p6H2YTJLsq/4vwrzrYS2VY62n2bNd9UWP2gk5ji1Ca2KuRltg3a'
    '8GyjSd54zJhskeovQGKLgNEYeuXiEpFaetnGQ788v6qwNodVLKEnQyHF53B7/OwvB5hK1i6gfFJ9N3+wamfV/ipT00bBR+lEDpSo'
    'qjMTjTEOO/ayjDxoIivsUQNLfhEpYW+5mvNjELeQXYVvd1r2npb9TMu+d8JUHFwvw6ESfsLEYpy0CkPEmB2EmdpQU17u01KVuMQW'
    'NN3VPvFutU9IU9cd8f34zuyWjtK3VJ1lJZV9sn2RasPCuYqJ4kYa0Ut8TV1EgacydzuDHPAbpoTrcQ3R7LdhTebPOjTaIsqQZ7U6'
    'vtkURGGQVrG88xknckleJuUhsHyCycnpmgPTp1JZRHHgwKhUF59EA10/vFsMmr9T6oTCisIpB+5lgdX2Jblb8XQe1OoFlad330hi'
    '3eTpz65VS6FeWqBmPWxLUTG4DUbDNxVF++04f3hwsk15/vE30LD+0fCJB4/IvoelzR8GcUaJCHk6/oeDJ19SmfE8vUTQSKIxBfD1'
    'xVpPVNymx6S+eXpkOplvbqPNKIgJbGq8i2CNTXmuhExfRkQxIXXha5r5ZJxGgRUlaR7fJjKfpToQbI/gXJx4FzgbGBbbwklN4aQt'
    'AKJL5rSwEExuE6cFF92MstiG9ZdFRhmwDlJ5aROMQclQtQMHpajS/5rdKTnX1v0XsFHhm8J3Pq7RVPxIw+jSPpVNUfaaTyPlCMoV'
    'A4JzAsx2lIfJEUeTokjRzNeahGxWsAUzBllN8ldmtwKK5UWSykqX5S3j5wPENNoCsAJkjtSyBmiZHzKrWcpu07ATOBjZM+Mp89ZW'
    'I1551fScJAcyDmb1pPvFeI/4ZeZ+zsrunN2z5I2KshOo+G3OzMx63VSHpWY442cOAHiNb5f8wgx1KJXFstCmqM0CtGlCXjpnkBxk'
    'DOvJ1NtbE/71BcCUULNd5ZeH5jY1ePHUPtmJHggVHi0ystKYlQutJzft90rvz+N2k4pYHuyqDndVOpFkDANlIyY+z6NwknDouqmI'
    '6izYR00oznxUOVMG+ZxHc0DhH6zZQi3lmfkVPtquasgf+b5jVuPdA1NOqMRjLmNdCvYDklCyJm6ETnhgg6omOMGqKGDmkwP3CU+4'
    '4TlsUPldEwrLVLBax2/bKCJPGI3VuBNxkM3I1IrKjebcIns62XjS7vD0HVss5lwGA19aWegWyxfemrin0M3pxzSenL/qauj4jvuF'
    'n/KonSMoP+F91dSLTusPf7Td60tPxVJDP+1zsya3BoTDhzZUHtHQTcwSudWQecL7ZmugjilZcxK2sf4ZGO2ZTS9UDaiVMEvVBxSx'
    'xVmKqGHQr75ZJ/ox+b065ZQBb/BBwV3YhtMileN0E1vItTsfEJkXqJpnCuVuwSBrxm/jGmy8SQ2dhXH6OCNtuLWb3MTMg2w9seNF'
    'Xqqh5cnNRvBLYyM9bJa8bYrQFiGgLZ/ZDULlcf+7V5ewAXmexqDuExi+u9Uuq2+pFKc4aCg363cMgJtUm0Y8SOTAqh1Ue8NjYkaU'
    'x2Dzx/waU2rDv2NdK4/QNqbpwtynC/M5XeDjNIKLOK6+zl5tJfK9Fzy3q2cWxNQNkc6pk7BV+zAPbyo0Zbw+nBvO3AqDyhgBixH9'
    'Eogi2EiMksg/QsaQaO81nEuM3rsnux8SWOy0OKQSIRW9BNQDKV2UP1Hie0bE05HgxT2gWa9REe35a5dKZwtaM8z9RD8mdIJTmQLF'
    'z/dWGsOvl7C4pvL4GBZlG1gSc/FILIp8kKXBK/HuO1kxnETpfiWn6pUiWVwmg8qoTIqhfgb4zsdIqeqzN0JTTfiAP4SbVElwe9BQ'
    'aZqU2ilSO/XUdjUIi/+0OnkijC8oQ2YroAvl97hQDqIChpZ0ntwOTFH/OWqd84BDb4RE/JZKO+YBz/81GPvoa84+4jFrtDJzUKUf'
    'tyUwctnPBpIVgXXM9VyTQNHJWlbGHW3dCtCLY4bxXzxARrQXXIsE4OQyibS7ne92doxSk3F2tMB2MwMj/l6lwuy4UfFHwzt/TXWp'
    'wCwWF72hshU/1Gi33pITchCC/DrP9HT5GIweuLVGkIU310gU8oerP60RQx/TRkH8Yb27f0qPyPqQ9QMEIA8enBHG4RTpUEqDjSet'
    'nTLI4DmkYYzI9bPM36kk1HvqZDW373kKv9vexeClbcH8MVEhIS1GlA9eNqeqIDmvwg3ze45oRzxl80NFRjf8SeHQmYilOCYSh5oB'
    '78RRMgnMdRySgFje7xPVz4NbBRlTln98PgbKHQeR73o84e6b/sDSvwnrDVQW7EZ4772RPFDVaBXTbPyAMRQGP8pUnxMFMuMY3B1Y'
    'mMOAUahc5ZpbTj+cxwj9McgVs68vzIIJG+pYxpJ+g4daYSDHhfmxxocjw+4c2K8WPkUlXRSy0Dfkx/uZMOAzgRF/JATgQawYfDzX'
    'Z8LIKrfGU/kjAufMpUllzJtvvF9/z4zxpGMfGQP78SRjZwqq83pq9gtlYqXpLhwW3/MFQkVksFaia/x3Xdu/x7X9OyfDPK+Qce+z'
    'qV8sijisp81n7FHibrZztemeVbixNoiMnXVLxUYbfwSvF2bv/eU5Hk46qYz5sN7JbIg5gdCh+R2foI5e8gNwwV/pQpV2aHI5WXds'
    '8kiBYTCp1Zlnm+jLEccgYRNxcv7Png8Fk2Eew5CzDaGzIv/vmCSNF6qBC37RMgj9ZassskT50PYeSQoTNT5gv/0zcl8vz8qG9nnH'
    'bNIdFCVNt+dJJKVWh4BV8sXssJ3WYhs7isFSDi0Dk80uevmQSH7YI9LYiKThBxkEKkKNwBxBYgKc1cZgnILXHXaDqrRZNWUkQJQW'
    'MhaM5eZF+ayRTvZmGjJ6jbzoPCxS4GgSYumAtklnaEE+hFkgF7tU9IFLG4btgW6lgn+CKyAwhwRKUayiXunWew0CWbLULsqthQNJ'
    'YTqZenNryslqUMtceLEURDLdTomMnWk0bE0NFjLSGi7HnrlL6vFJZ2jcl4/ssG4PTYSw+9xdaD6dqn4v/kUYs1P2bk8l0lC0itMp'
    'z9pkXFE9QgBoRLnNyksvTKHrdhWnyPeLxnGk5hP04h6/Dc9j210bYUpT/mjqRWfuwPaeN9MeNj36jaWTufJYky6a7jGSl0cvPZh/'
    'zLJjTGbr1eAon9HNmg+SzZaw6tW2Cw+3HRMniOTvNo5RjekaO+tZn3slXY7V3/NQbW3oX+Pumv0PH6+aetFENljnoLruj9NXF3l6'
    'Oj10py5cxzo5T8hUlcF7dh9rZHcvhkdEaBvYIxKVo9ugLix2/kUmM3cIZIqT2MVQy1bUWWCvgvyFeKcveIRawlRR3IYSIZUe18Lf'
    'aDtpOOhFNrgtasfUWY+2asye/uoiOvvU47xr67tTiWKfCZgd4djAAF1rCBYdTx7hU5NVk3FWNtAtIulu1uXu0+l/n3pWgqutMlUU'
    'p/kMbnJq9GgTGKqKxr3m+4XOYT6tnTgV89C7qs07aWb7yWzYW3JTt1zWhSMnXs9aBosYpD2mR9T0kFNPGheEhRcjl/nNLwyIRn01'
    'HS+8nryHcamrXRPuuuczidOfJE5nv2GNvdr+E8G0Vs0SyOQqq8natKIgUky6x+q+mSwiCp7D6eFqxQd0gigE/eD9haaLpvbib62F'
    'W/cKO/78nWn6Nau1ky6zV0EekD+F156aks7KqW0PkW6fl25KOl54ufB68vC7O247f+vDFcC/OWUaVfFY7z0rD2fvsTuAY++eo5QU'
    'HvkU0kp+dqT4352CVnaTK0tWG1EmaV6BmagJNpEpI1MYpC5mGCelQLsbu7NpDwy76eXGl/wk3ZqRXnXMcE9XPl40PYR176MU6djh'
    'BNWiHLTbHtgdb1F9yDs5IuFlDYygva0mag9lD+yuQlaUn/U8/tc4dkWcMNHx5CFeGnumRsVhvavIEZ20eYg8mw9/ivmIb9FYyJyP'
    'Hh3R2vkrXWiIpcZN3cpx9+Avbm6LopAw75GYkpw8TpcAsdRgvl+oQzt6XlGa0jGmZQ3s2dE1NXRpDOakjpeOjZpw4XV4UP0g9Un/'
    'WvgUV+h73HilERjNJ34hqVuCqfAEt5ApjmwHl1c/rQ56nDiaRIwOjoiI3W6/WPp2lTRsaM1qUBG5+WjpAiQF2n72MYDOuUecOeha'
    'v7QEwXanadpcitcXg+/pyserpl40zqqvENMLhqnd6pScmFP6pYauYe0YjnrZ+dIvNYNNo0urWDLtOAaJCMRalJlmTqdGX/LrXKYC'
    'j7hNj+OSuMk55hEKydKFr32oQU2QLgqHRYQXidC4BYAm5Prcoagl1Xt8DNHx5CFu7r/t9kcnAfOk8kYS4sFtffQcA5XT7EjnM0Kg'
    '1X7AVURBbaYBgEg6afgv2bJBzshCZ9eg4fpQ0/N1RJkA8Wc66ukqxHjiIfNH7+IeyStNZPsfKml4Nz3c1ogVqdpQZGUs55+a8apz'
    'bLrWMk5tlT49Tp/g3aE14ayeJJ20N0XUaS7s7SounknYf61Wa0gWdLzwenJH+r8chfo/He8H6QMU89dw5emqufh46RAQtI7AUVR3'
    'v2OYwV/jMVaOmNZVK6ZERWTlyw1HNw2/ffU0aO1cn2qN4fmKK4ou1GsMRXDITCdnT04J/zvUeP3v8CITmUMFzeVk4YMzYhEa1fsU'
    '1cj0NPalnqtOZa/eLzb/zzT6aRw62Zwz4k6jNHbzvpine2+xGz8id6pvjpDtgeGu17wabVnFCdJIkvnFYr9QVzHrnIpUXsMZJ2q4'
    'oBCaiJU19dT53tqp7QK7l4i2LyVmvm5TOokRaWg+p2a/WPTodV3tWocwjb0okNuBFi5E7FAlAnia9PwT/5x8v9C5m/eQak91tLk1'
    'n01L8NMiXGenO7v9AykmfpXg5ONFEyFb18Pp5qt7XzGHXHa+E9Lo1mpslOVtwhu56aL5dIqP69JibXfm+GxTz/C9f0eyGvTQfX1q'
    'IldjLKszVGu68LzNp9aZjZ80ONO5T1vPD/LTYj/6h5Nmv/LaNc5a0fHCL056uqi5BHGOMy9a97AXk/mvgSUXLaGYRdjFCyemjnWb'
    'QfXYlXM4YE3EqMTgoFEPVsW61+Pq9bh6laaXWhm44jaNJRyzoRr3wPiM/dfKr5ruuovp0Thmh3gsKXAMUjoJN93bskStEA0/Z3tK'
    'rhTsWsxs+LAtmcq9aTTcuz/L3j8KWQnmGOzxnXY88RMRsCYCSVj0UjSDjxfNX2cR16bLZVhT71hsEq1raLvd3omXT6SJet01IW0d'
    'A1NnkSrXE2DqZDxZl3FGfu1fGHy5SLBh3QOHi1lIrWH0Y2ccXuxtJB/xn9aQSaYKJx4OsFEf2UNduD+66yPqIbkbePKelNCEnKO7'
    'cWSn9eiBHJFloHuXfEb6kuV9Z000QtA25srTW4Tb4G8D6uJYouzyrtbYaZxasc7iy9ArdfBTTC4XehqfLHKLXINB/Lbx1GMwTpc4'
    'jNM13HG6hmxdvWjd16FZ66LnPZt1y7p30kOql3Bqj68dWtZ0c1tuOl54PXkXRE3E15qLux7b6eKqj07BTzJ2ZgF5DpzDktTFQWuN'
    'nfYo5Tn8v1qLN8XHkC5d7T4nj5TGjGvvk6v9XFxq87lyaML3uh5I6jrm5Sup/30lt3yN9OGx+H6hSs3rNIycMlX8uyb2na4mn4ve'
    'drx2KOKMQYKHCKScC0pdEwGVOlwF1dTJ2FlEutSL9FNghLJ3L71RJe9+dofyI7DUz9Bz6zPEwLvxkPbpAj6yctV69Xr1OqvR61KH'
    'XtG1v/pHmCKoyVvkYjVYBKWLKiBzVItX/hi6Xju2YBLQuvjUyRgsYibaXboymCqL8bbwPWfuCmfFJX9Tobisl9z8wxF3vuZ7jx+K'
    'CEKjmYo8zepMMNplMYmBblbbnn3tL+dN7nmsm6Bu2Gzs1N63c1ZhzhRlPi5En4jURuIzs42sz+HB+fyGBWke9c+b9n823jYDyFDd'
    'go6Zx1FRIqKto04+3bTRxAVl+/hNl8wfJBDQDwgjRsKD7WzeW9OdDTz6oxNQha8yaoW4jDoiVtT94x2lOVA1knQ2YzwKD8DrAlFT'
    '30McA2PrWzSbwNHiXPR5ecCY7xvhVzAGwTwLi0EuQxIfgyFw3N6IpK6+cBhMjnlBC6gT7VnbAKUVO4fy5s/WgWa/E9bYOhh4IAmk'
    'W/jzFy+t6kfQic7IjY8mCedOajB+DDFLCi4nVpNB2iMWnkV3MdtVHZPPBf2nUMEVrb0QlfjS11tEFYFyrreIs1CT6uuCucaQm/Sh'
    'aeN1005A0PRH48h37X7R9fiELsKkXkFNowotiY0eg4LOt56r5hGpXCMlx7YHOmKNRcDH1n00qtCrPiruSNBGY4MGP4Jfgpfnyo6q'
    'Tg+vqfKGeBsWqCrAWx3+p/FgXZLOV9Qlfs+QfGvtE6+941gbz8YS6WWnMkidCSx4MdapinHlCEmDnrprkkSkAVxA0O6feuwMtvuu'
    'ik6UAW5Dz2RyvIfL1l7zUmveP62plenBU9SHzl0Tafp4SpXpQ2ew88Eq2tRVwPQdGuYcK5+TEepQIOmV1aAivAYqVDhrvwdqbs+N'
    'Xln3LbJLtYg2J3H/3LmdOZo4JXrfL7R7PMfYXccclK7lML/uEc+4iH2l6eqpH42zrkSOUtvGcp47Ue+fHrJu0wWY0JTubMvahzz8'
    'KgVJPUkEMHUS8cHvX+YjPM/dU+lO2TQSNTgQTZ1W7eIcmoY1eNsDYaPCoRNgNNLpprwrKp9EdZCNKgv0mJtQFoppcYpi+HYoK/g6'
    'Wz48bAOGvL3Po8GrEgJmo54HfrHNRLe1rbGkHmKIs7nPNTWma6DBaF3Z8QKc2KpFLqDukZPSredcr+RFO5EqZgN9FV7Xyf4hXhIm'
    '/BWLniLyWXhNk9MGgXVKxstna3Be/63oA9S9gtHV28l53zhyfN80THxH7r03HWZ/S1HbgCb1Bw3cTxxe/biz+eC3Eu8Fz0kX1hz+'
    'ZtAoZApMqticAu1m7o7oYpQDXKaCWg0stsH0laRLNv8A8PZ/g4kC+fMhwE1q6ChyZSjamQLmfeC9UnCMVQpvHEKlIcZkxRf9gI5z'
    'paUygA0PYdLenfdp8ajmbgitfLws5a37VfjtH6nJOtv/IlF4J5wqLf1LPXf9Ug9gkSqn+JDF74DhV3aSYTTaOESoASR52SkaYiCL'
    'sQl9eetWfIoLN+C7QSvGpJIy+rQaGVERSd9SZbRJdZwwGyBWla+Eh1zX2tkeLBJxPvRKfsgpnXlSbILOvVHMRXQvDuoXH1ECp8Gb'
    'CsNFNSjTjUr/shN/+sJIB0wRm9vCU3iFN+KhDoZVSBeL3jk1kRFPPfL31gVKl3+hHBtNm+Ru22lgN7yP3GCTimqOq/gKAgVSopX0'
    'yUMiEvY4Zha2+/3AYDXobzrZeNLT/hRgM75/Uvjrxnz0umQXX91lKrhVhDaQZN9JdAW1ZNyEb8N92upHwBpZqc0W4vlmwYSu+OkE'
    'vdPdhpXsWEuu0tWbaoh+HU9oG8vwz+GSKdR4Chas6BVPUE6GC39NlSVfY6sSgysSyzw2qezAQAz09qYySk2BRWgBbwX6tnWYrlJt'
    'unZjOYZ66JQ6UJMqMoTL40xQZyOrwJFmqUx6QybtUPEAsP7y50bGIGGi4MHoZ9nCTZTPI658trE7Z83lKIpd4fP45aiDYlV1vo4/'
    'kHP3D+Tc44dxQHapNt7lVnHl3cISVwrL0Yb/LFuf23BTxQSjiaR9XEOIvj4fmt9T03zicuRxG6isUmmK+tRUigEeNIVyP3QP1gRG'
    '4wN5TGAGkcECl2wPXq09JnQpCUSgRumYFy9dBBs7ZVKCZzreCppiIYTO1Olh6ZONJ62dWpq4pO36ViQpcAwCr8s/JVJrKY3qTZcD'
    'FyGIR+yI4IyC9xuPNbkxPfxEmxBlCNXm2PyWkQm8bLwYdGyTrhYc+El5mqvTYPXy5Y8j1n2Ogm/HmCvaijPe0JCnEtB/VsD8I3bU'
    'QEYN7zXjXhJFzfY7b37UvFGpdFq0bRnH886zeWJ0WXBtnlnIUfGhBU6PjWNozJHxUXSvUihX2uASnib0yYMgHuBiYOv1StDJTiut'
    'Xu7kg9Gbsu4lhy+bSYBmv61Ooh2MqglkeSHSGxk8olvypeAGWdedyD7CxcAFHLJwq91CMiByYdd2GhhTyF+AEXyEzFgpmkgd8a2J'
    'NGARe3GW8I7xz5tjkDe7jDea5ybv04aDaJoa6tWPDx8++ODKPKrFx9fYPzyN8Jn98opJNfON/c9yY3Py8ZmhT7/h/in4sh8+3fNB'
    'I/fRJQ/CIGRyP2zzfnHc8BdPSbcm6ntqHL+USDXXOb/a4HCQtv4b/41D+3/fP3oddRxgMra8H9twuUVWAItnagpudI/YreZvWI16'
    'srNBoVqhtm4XKn5QWhDatZoAZ0ibZ3Ef0CdLI5HlsRE9EzS27rn9YQ4kGI1VKMfLULE0S/INoGu5WanI32rnGxUmctErd41IaY3x'
    'yIgrXlx3H/VTE6N/YGLUqgJA8lb+PDeRPsc5zJEtK+UoSwHp+DHLjLMZ83d1lrcGLxktalLEpvYZA9eBrPWJI2Ylo/KZD9gSMG9r'
    '5LgRfifI0SgRP0BNRXRMeE2Gv0pNtUodEKOi8Ms3laSMLN8Mo3wz0uXbWVgc2aKXgk2wDjVi2DXqbfXRz6EDlzYjfpJlun8zA0GZ'
    'KjxBjtZ+1BRr9AxrHCCMxWzHLirSsksZ/+lnPXxupkFuynGjxXGT2aFfqAwC11pBws8LUVm3zAi/JhqyfrzwK8ANPlRGfof3bSiI'
    '8Ts++Zs65dLbxe1dmQPw99HvsDYyYlYGsR/91siIn2BqCp/MGvU2yjj8UtDv7xwoiSLI/OY2DbhpIKjAkcqsikq2JhFc3g+S7OxD'
    '0BdMwxcVfWYSBhhMjr/C8RPKTAXZSaDFbF8uB3xjGCrjw7gqRvRUkkHRLQpkf0q9KSYkVYwLN2J2Cosbi0DSXV2hjDEARyuVOCkN'
    'a01QQRDqjfcnSTxMH/H4MQVQoSPMWwUyo4pCke74G/g1AGw7yCoxfs4JnCuRQWStHwWZ+BX5gxDEj1RF5s7ikfTOt5HyEuMPwCiI'
    '7JUCxyClk2pmsYnjURCMSYi7YZZ+i4jFHQ5ThTKNAWOg/E1Ouw5ug1TL8SV2MUvxnuKYWEBdOLHy01S/NEVWejYFr12T+ZH1pJMx'
    'fKVw5bi4RhBHk271UsHQzXXnsu5g1U7t+HL7CrqiIigyBgu3Z9zzJerZI1JSdgggbeQH/EhKia9e+mf3Kg6ZrcIijDeVDC176DMV'
    'FcJRd+GCnEbwyesRglGo7XFTpsCsBmX86VyVNC1UZLIoA9ogCgq6GIIst2hhEpcXR/1cEYHNQdpYLPDUFG6aNwUt1Bd7+AYHm5Qv'
    'vFAroNSvFLkOVon33aAUfKWI9hc3xYCqtcRZLdwXDlIJhnU3S2Gk6CSN6MQi1LWmwFNUjQDlr/QAi5JOwhO7F87k+5aGiMPwyIlk'
    'D5TricecOSYJzWm+mwkldZqTIbTyOkdYazKMRtmv3X7aUyeOBKh7Cmqc8aY09lscZhY2nx8pU2jGtko1k3PecnACfeOhsTIc/jpl'
    'sIGbzy+m1tkD5dGi5uoadLzwenIJCA3jFRp+zsd87JG4RxnG4cIlswwuFw/V1Yfr6ONtF/5NpZNdDOEQN6Go0iISrkT/F1n4X882'
    'lJ9ZL7yCfKTS0RwZMqs/mXnxoZOxs25pkf0eBLh9cAXxsFFYPieo+IV0CzZl1lvjKFijALqmXnQvSbgP94/JnjqxxHvEQcMooVIi'
    'ZneNq4cklY9lCpc9JRNPOoCo1yS6qpHbg55RM4sEuX8lYag7DhY0VPs7u3j6oiDIIxlk7j4y7gw2pixwd42ItUlP5ps2oBguJ77L'
    'IUiB3YD1PV7hEJPXco+8XzQmA2SOPfQAhkmbMop80ous4OXERr4VeNaP8ZrtnWDyZsoAM99NDaIIKngcw4iHZbo2HOCMtLofa/Y/'
    'fLxq6kXj5IYuRIfu6pSjuiVffnijay2/7s+kNm85igre8mGm8U9N9qrGdOWosamYIKR14dQprbkvxV01dJqZJMBolPGh3WJSFUCR'
    'MZjSqL5mrYqXpn/obNg88Cwt92Zivpl0Bp/ILnbtzdfq8rlCdo9s19CzasVK2W5L8HyH+iBuWwsoaIupXuoPNZyUETsfbRA/2GiZ'
    '0VBd8BYdL4lyw3Tq7tzPie4nC3tHJakKbBPHBNvkBnSbogvyawQgOUrfpveMRMJZ/hjCxjmy5c130cDLSSILMr+ZLvgLq3DaA3UY'
    'vGs+QcPHFJE9R6C+/t99iVBiGTQb2EpyI2p2Glpc4/3bN83YP70u9xvDX63dW63dU63dTywZi6fAMUi4shhO+zbN6LZjEuxdxLGf'
    '0TncDzbCzHkPHrmjgBb9KIhJlLByk5dyo7s7W3qWuKKJTIlZSom5STnnJkqLTeNqFLmNFOBprDS10YvUWaAlO9GMoSa5OgoiLVe+'
    '0tdIju6YzLED1XwHNrpfbVRNDNqtU3egWJGGrXzgCeVOxs5qsPDoWcR55e3C66l5WRhjqZtvndkXf1uPGCDJqWiSLFKD1XDlmKRy'
    'CtrtSqHqHppJ2NiXRlMAx4jMgmKQVfXjuSKnR4qaytCXD6iZJaYEjEa7Du9uf6uaXV9Ha+Sbyp4xQap6nt7Ekdq0NkGUFzCLNWUJ'
    'bRpsdwWx2xiKmdnlOfbCDbFIxDbVjmOQahIhThaHlwqNdpx7I9xPC5IGcFBAUlH16v+OYXEjZO4o1WH6Ec6ajNQoJDzXR5P97FH5'
    'PPRoojoO9hHyCliw8FDyJ9A+SzTfpJJR+py384uFClubhKou7gMzH0CRIJK4613S/UIrOXPQGzci4WGa7WI1yIUmsnuM+vc+6t/7'
    'jHbX64Rjijs8Y1J14oDdhaFzSSmX4Yl06WSnE+asqOMZM1PXTl4BUlki7SJd2Hc81586oVF2RSRR97VrILrnn75CEZdjzOyuTJGt'
    'YmxkcaPjkHWeZHmozGptAwvw6TXQ6oUXViVXVOkyZ+Rb88+6SZRLshLMXkAdm84Zn66roSGZlOzXFOFPPfTeA7/OoRde3DZIO0vV'
    'sPql8vJS/X25+r5ce19ReV/6WeR0oXSn7ufFn78Aat7x4oteRXQPGAPZkoCFjcLKkYocici+whFUzviJX3rhUST8cU0VoBBah/Pb'
    '8I2/BJM3BLzBflSyAWqQwdTONl2bi07DLbH/JEH7M6l8NsjarWuUU6tpeKwcmJmMwRgt0xrMsh5K2ISHHSiDGj42CuRvizZCq0X1'
    'kCQezIEOx6+NFI+NnWloRS05vO058AchScvwWMQ+1cGR0lqDxmnwr0+A1TZZoKvC0PCKtNy2PGWRwvvtfHZzxKvfo3+IBzit3LrA'
    'b50Li5rwCfv1KXAMUk2UX/eoQJN29zvhMT3fHosIW8M47BiWoTziVje6jmmEFJw3HieEyhDTI//TvtuU+NESrTVUnjSAByjC6WjK'
    'F5feCLT96otwndbO95Mpl7tmT3914x+tEn/RMwus5wePHxgUU4gTz2N0NqWLsfz4+ZSgcswtPuEYxGEcNcLwqgL2/6bHwDvEYGyw'
    'Jz+yISIf8dqGGVqC6fGw3UNbOlhDkZNpl8o8Ik5rZ1VMC9pgNPCNDrKY55h/zIgwxjJY7j/3M07zsPmGPHgvYkGreDLYVbIxu+nW'
    '1+JBU+DOW+ig08O5S7Z3wsxUPdUTLECJPyz+cLYhhYvfL+oMAaOzRBttQl+mp7VlxBuhQZn5C8PnuVUAN9vwE0+V3je2ZjpeJbSx'
    'RELWiq06dunqzTFeZPu4Pqjape048CVo7Zo0UPuTE3MCFbD10Pwu+eeDJmwaYYjqvT3588TDhaaTq1a2GbNUvTbeKZu6xpOAX4uI'
    'oaVYDbJ3EiJB637lp2MyduL+IYCR3dtU1GD7uo0JOqgp7t2Y8dv0WzemrxDBD9Wv3Ijm0slpFO5ogka3MHiWe5hVTTFUNWqfb4Dq'
    'O5NotEGuKNZhfA0rL4VcNeo7/ujnzx8T2X99RfrroMVqE3eZXfPpmtNxj0xoateJzXN+ayW1adpHwPZvsL/mlkoeCaOmmubJYYl2'
    '99CcHqDrsTq1VyHBS36xATNPFzqe/BQtjfNBuxKNVPXvItWsRO6L2s8rvwMt9eZ1W7EwxI+dKjqm48nt5k6F5ySEqbNwgff1jLbE'
    'dUZ/1HhrD1S/CdrZeNLaabidNvuf3OaQTejTh/Wq/ZyadKHjyUMkf24oiB2QlgutnZtp0Fb9ExzBumUXricxQbPUSa7PZ8utO1wC'
    '8U72tHdPemn7pNV8uwjWK4UnDUHUREz6m0pXjQpGPBuTunZ3CT6farhq/jirweP9g1P7h48XjUsnb44ahwiQNEI4wrTfrLIHXfI5'
    '6dV46ZGntp685wVPOJK9/Jl56yUKp2++BJ1CRmy7mJ+miq5uHnTWxVFnea1lCicbX6sR38NlLxI6kB/mUxy2vegiKqH969F9Rddn'
    'R1KGR+1ooUeN4nvUXnz9bONJ6WLkAoGQ+1ud6ruNQ69dOkUgHINQSFof8d1Iw0PrGjBSuHI6+mrNFj8VX+OzGWl8b+os5gut+3NS'
    '4F0z/tF1f1cDxq3Nq1SQScbOnFjy7tAhPgrvu8nx4ZBJTqMaLPwcHDMQw1mMiDl6q/idYVw1GGPkhl9lTQ7mqffJO/uYKp9IogxS'
    '031xGhzs6iQytg0/YwTf+V+byLyrnvGbVpxs6cVRWvtddSYimOu8NFcnzoFp7YcnoNmxra0K0TXjH1296roQa08xJeYfF51KLja0'
    'B5Kzi/+mQtE6BSYcg4SNw2ujSUdSbOz06sCxCS4ZeXzY40cDAxJ91kUmiyfwuHoWpW0ZbPKxPvkH8DqPj4X39wMtj6wb2lO0u4tv'
    'uQZ1CvKtNWieu0DzCTztPxTJ26adSBCp0uDLqGQPnCrt+WJ9+IDm9/9Z/tryvRqkxzPvysVNv5NH1t9ep47r1dO5Xh20duqE4NF1'
    'gbO6P6leQ5c6sYMSRuVqVIN1ySXqF144cybrpwWCnEbx/fxzA2Yhatb33+YoAFscuRC1h2iKxcaTnvbdU+MeXWwefrTxhkrM5pHP'
    'FgOfrY92zm3Bk0s4fqeXGyfxDa4GKgyXsa633DRI2A57OSKTDlf0LWbBWMafz58k7AYfUa3SiEgEqf3iuU0NQ8TShXcniJGbSWrM'
    '+Mue7hROndJT8k2u8JiA0bL9mEBQRRnlqnVy9796rVm0iql2s/aGsp7NZD0byXpOEhs/BxDBx4ume4nlg6D2ve6B4W2NGUY8EAnq'
    't/KChihzOc/3qTvKXssQC+da/DUJh1Ee6sFjriQ9gnubOQpng/J9j0Gof1pVjGnhG2XG1JkD2bU3SRIZsk9R8cliICiN6aovQ9K9'
    'rednkEapI3c0QT1jZ5d/pNSpO//gEQXr6lUXsXc13XMM//0kGCmfHwhia1FHJt4h6PzisSek8Oy6aEQ89uVNXRf2vkkPrie0Tjqe'
    '/I+bHqgeyjKPmE9auMAuWN07CWGNRti4ZmXsRcG8hsbewEqwiEujdKdfQQFhg6dOI7qJ3keoLcIlrukuprX5F6ej/Owq0HqCytgN'
    'FEHPJV7uPPh21KU5sz581Yupvg2pF27EP2K7Ibzu/GXUC+ca6atPE18aT75igPTSQttLZ62Ja5AqtEdNs18e6gFZtF7d+iQR0clr'
    'rq8pUjT1BOWijMlF/eAP/ujo93dytfn9bb6XqRUNA74QSeI9FVAciBJiHLdOOurbpuL5VrDUx9sJvPLL+PEHBKHyyYVGqGNhzF5M'
    'a8gffw9Co0M9tAlXH4LrG1oHx+NIxVNJjfkYFRaCnKTAz9cX0s5fDYRL/mFdEqp2s/ErgGN+frdCi5RmOdRyef5+hjF6Lr51BZX1'
    'RIhPhEfqK4HqI5fjW57oDM/Jj/71OyDVJlpOSAYy3HMG2Z6YHGadE8Tvio38ATGqXC41odGkl1PMdpM9dTIGU8rOjou/F5aFfHWn'
    'MwvurlSk8gLHMGr1cyQwmC6vT5nzikjyC+MH6mSZ+OnWb4x18WA11SSV0lS+NfeCSudIUF6o0BUt8YJTpQ0d5YJb3EYaqH7gEvn8'
    'fSwLxqB4I4on3qAuyqmy4IRGy/dHvh2/z/8j61vXnGWZZv/fZ2kiMU5U8oImkzn6RW0a83zrmklXgexEQEBoTFft1mrcz6jgDNfB'
    'BBEV+mJvjsDIQGaRWZLnnnfG5Jsrv0pF29EeOstvlUAIvDf+dGlXVcIqK3+lzczMXU9335WCg/0rwmi0tfwcnAFusEvaFWc/gSrW'
    'IuEyfEoPDRnhyml2b5MfrYNo7NtwqIyIkuFM3DgIrUMHnxjfZpyv1exRfrFUvAfut8POeeTPOz5lcITSxHVgzmig0gB6Hkjus8mS'
    'h7ETpeS9SVMbWOvH8FN5o2/lqYismAQ2PB/G/2F2/kmMlJsk3P/d86cl+4FKQWUJY0s6NKeM1HdCCV9AXaYClAbk06SL/kRXcHQX'
    'fU0oG4AT5Yty3iRZMKyemOhQZjl+8OpKMUhWARsQE3X4ZPhTQKucUdnfSLUpTT517ek4qsNQX0ZIb2+KC7YUg6Ri0EX7BvJkc3Nd'
    'XBTFm7f3ph01GmHD3SiZjCymJkx/8qOm3hRKO+UEtLCaoACB+A0oar8224VCLgQGx9dMG9XQmQ7AbqSOSqVCU1eOWALjgtHRWUMF'
    '2To8wjkprZGZ7LCoz1xmFqrZhWqOQsWSX9zLBnZreuIDxBnbJdDWdgaNOA2eFH7AGDkBUD8hN0ExVKHAPmKPI1bu4AJffYUlmO8B'
    'rxoqPAoWYNfbUe8PRJZZ3qQekmgHtH1yG/horSDEuCzrqhUhYHhe2SWTLQwkXbFsufEIRRujFG0AePq1iMsGqdww2OPSkvEYPkPn'
    '+fNF4QVqIFhkjoli4ifNRnhxpVDpBJZAXXVJPFgQDz65JtlOmfgCnwjRKUWMHxVETVuUD29Gap3Go/0jf44Lfuy6HxfNDgjhmK8J'
    'wAFFL+Nxxe+e+I4myXi7saEXwg9qug4WB9C+JF7Y/+lcnRFZgoLAQPEmboJpBCJ3DijOGLk34uBzRt4dE5cTHWjIDs4QHihSh8o5'
    'gF6XxXfYEZGv+F0o4vCUURpNGuhclUZWGp8UcqFSxfPQxwNJ3tgtau4H2owYYB50s/mmtpl9D6u9aPgZ6r0VkCO3x8E8B2GKnokC'
    'IcW5dp2FJbvzh2aMjufx2bm5G0+k8jmgExMH6TRyR4PnGftDisUa5itl3Zjb0E7RxiJ8toWZxoJ4oDffBLQmABFva6RouVPw3PLR'
    'I8SYVKd+lpHqWUYv5W7AJlnITIab1jS0xL7jBddeszdJBAfs1i0MqgSiRHKEtpYzEVm1VLUXx8iS8GYL92Zb9WYVxwKz9wfBNPJJ'
    '+I0QDEe147MNOEBXiMfQCO/rs2Hlw0fzNDDXZ2qNC+2eG5ZmpX8Jy0UTeyqU7YaJLICNLUkSBjgpWFcKXChEZ/ou2u2t3dMJe9Ih'
    'WnIJxVCFcgi048Ycpz4EG2lRgkjcMz3vd8m0CRXQfv/fgQ7DSav4G4pjO7MlvFQ4rrqH6ltg8+kJ0DTIapeL3ZnEMyICdV91Zz8s'
    'CK3o9DNlhYSAdiZ4l5fd9uBH+72Y3Cb1foCbywU/5OOFcxLpch3b804XKDqmhKMD2ivaOKCxOLoiXeOAvM401v4yfmC4561FV3Xl'
    '/lk5k9vpaTuTtsIws9fUGoTUSsOCLl1CV1mrZkybQQ5s0JX2ps5ACUZzz4ziriy63ttTab28dH1QrMcdoSytqzvoBq/L/FQCSeA3'
    'bzxDOgjjDYqHZUN3enrCow3WLf8YOij9YiE4Csm1dbir/IJ9hDsjFnFscQfHAL2z6fqXYGxhjlw3SKiADwXvG+87KrA7FrzKWv8M'
    '9Q29NIiRktaJmyrTiAmhjpXEIc0bBTZv3P/xE7S/NwNkY4cqJnFEnbXiCbDesDPcVfBwB1zx8sH2azT/xrBQ0GYMTJVjdNXA7Om/'
    'dLvhC4dgFDJtXAVk0AXPb5u90smQuuBqQ27aUC1EZ6Ezu+XaSpJW1XqMOwPFVk92J8w/ItrBHHQ/mYKcJwLedQL6b/3+xEB5jlmh'
    'E66TTLEkMkg1443N67/UktTaYSxwTBM4C8GEpth2leKOd02aFn5Nbtg6o/sfyfsflqe2H6eGhCysYnDNjn6D9k5I0+e5S2LlTJB2'
    'uZWYe2vb8Z7g0JMyobia7L4SUIUs4yBPzmqStgxA6Zyx/u5f+hmu3qIWlE8iOG7TW4vTA7Uxv/61TkBaBqts7mwEhdJrQRgrUPcs'
    'ZHu3hAfFsFwGCPi9IM8gef2iVVEkCOlSqA0+LZwVwP0v+JpJiTKw8OMlAI0KV18nby5PsbU8xcbyINUMj33RQj0jSq3Z3i/aOdt0'
    'k3AXzTl566YFW7gs24atkx5CDk1Pp7E73z/PSD3tJs7OieyB8soJT6OSFDOfKQ5bbgSLyPdO2mtkPq3JJF++5ZcfVZIqOBHn4yue'
    'X+IhYJ3IWdoMKJVYZ9q65wMuUeuAgEFzJhv7sbkSrZH7AfkzwF8suelsPGntVAk6F91gJICF/nexV9oHMoaj0P4GSbvCIvd/iRr1'
    'IJFAvtuEftVSz3yTtfVf6KtV6iVfD8eZ7zMttsnpFKvB7OqZJP28zOjKB7qZ7Z3wATMxNb3v2KuoadC0HFedGqbN5clHy7JBbmlZ'
    'B3/mC1aDMS0rNh5hM3i4iawUY91Yod/qySg6HU/ucGTgo18vw/bQvXUq64LGUJhs8zAwyEao4fCLKzU29EC7SaFUzniK4b5bT21U'
    'IHjPKwQ+uzuZEpmgTilChBLS0on8LszAS1aHgSScQzedwKHn1uRsdrbMhquxKpzlYLw5bpALmozdopo43JJ90l3n/7nAVJRPNmyK'
    'sjEEkwpm1YHMHH3jErKMmfEdYf4xs43iavnFZ4zvMQ3mibu8g1Qzlo/ZC4DMVDYa9bUUSE/LTCNLKo54YppEqtkeKEftORcll9R2'
    'joVud8e+uxij07e2nPeDM0MI2amLPUlmuPSEcrYikjvqyhuNEhB53tpMtp4m6WRj0L90stNSiWucL0YTvQFWbOJhZzUYzwRuppl2'
    'MzPzOSsTsVCFLVMwBYFXLQbloPljSIFjkG6jsMBKJ2HltDbmTAwaDoiYWw9UBGD2qz5OPwIeDLoUcutFsaS25lV+pFWQZLMfP8jn'
    '/pG08aMsir7L2nsua++3rD7FppHt6iMr0bpvXDYiGI1VyBA2fJmn1GV3G0CUAxtP0mqA70CtuEKRoIAeQOwwdHrZ3ob6ZWACbbKr'
    'KsQbecHSZEwND5vD4DubySGNeMCVy5uHksieVrnL1cFydbQxLByQF0R3xlDy6Kt5xVqtk8m3j1Lo7Ns2PPqkAlKuAOtsPGncQSwM'
    'DupAStYu2k7pAmsLet4dXloX1D4/7W6eQxsoDf811W7s16oylz+paAySTjsFS+WFhVv3sWJlsIs0FN9I0LhuxELZIOHllc+rRznZ'
    'ef2IWGWQa13FkAMHsKMB2fysRk3SYCaLT2zMFNwB4BTLgKZhwydUau8NGtaFJYU4Bom7y8WlBl8P0aFbTq7CGgYWwNNQ/2Pavy46'
    '1reko3xHLO+ImQEc2iFCFjAK5YHNAuQuVKVPmEXY8GZjgxtMzSVMdtYI5qrJcOXGNx0B128puc244VW43fDap5FrI4zdwikHV+LO'
    'FdBffPw22Muk2jK5qkxnPQla//UV2gkjIfcStuk+s42bsB5CwOIsIiek9klezYjU02z0JTaXk/pPQpy3EFTx5eK0gkRi/T2R7GWS'
    'FJp1rZs5Ncdyk10jsrr7ed+10UBEl+aJz3qe/OmxcSwRNtAxiBz/4DUI6cb/R+9BYHfgVP/wlbYt3AJjHIPYTefdZRCFJp1T28kU'
    'gjlz1YYIkNNgBDute7/0ckgvh7OmqjbR2s9IcH8o8ABYbQdoLiu7DyYs7/yWnrb/HexLEGEdDXMZnrurFdfvCLqZ8YHoTn3yoYhT'
    'TN0aDRY/9Lq5naysXPUIQyUooIb0q4od76EaFZs6EgT0HToSxOq/vknh3KEQzKk6Dd21A7CioOTDUJNfbfFa6680nMJTVH2D1pN3'
    'N7ajzobOIqQ4WLYbInX3A3O66xetJ/9yoRbsNLgR2zkVSRiF2phm3Q+Akgy2LmkX2ZVt8+5cA4lkzbt6RyBOt8raziyK9liEDgvn'
    '2IUKj0eHnBcdDKgCSgoBfZdOwudmjRnfBof0R4iAD2WSVyCaRVQ8DEBH6jT5VgqP1jdyEkWVUeJ6N+NAYg5tgo2d2vEWA+wvbVlQ'
    'j6Vh/hbKIsyUntcsG01xCvlMXnPJUSA6Z8tGkxxrsGuCPHixbXup2XqRu1F7q/6+y/BUIv5aI2dojtEDzM871D6eHH2i53BwCkRY'
    'g7DrCs0DmOZ4zvhdFhbOJwplE9rRC1YpWy3Gm+I5u6cCUtaZF7UH/WBQ1Jpg5MXoGjeW8A1exIGL1U55UgAMVLOAQ2KiN/OcMa/1'
    'Efmwuoqx42Ia83M2nmwXr9fWdVxONuuWaNgZX+Vkn1Benqybhwz78OuQWNOEtOh9KFN2oYLj9Xby+m3QmPDL/G3c5tOjMqHRPVAO'
    'uZme3xOfGWUEEldKPrAwIz0PTnX9jzP3kCg+XMKPgkWCygvSLy22kD89v//FOctk6ATj0/POraGNtuJ20ZNqHD0WQDZcqXEB/CnJ'
    'gm9SxVRZwJ5Khvf4kc12pZTOOAHXrl/aEYQ7LQN+1oXb2dgpbzg4bqlohFa4TSOVyz9Ox3HnePLG8RS7xVNsFk/eAp7KDcc1tP5l'
    'tsRLgpPJ/BgjlTusI3deWTMWDxoRnz7canoZchRUguLMGveWGK4VxFvYryNUIlMtDY1GPUJq8mky6ySFznSN96DpkHKMnEvldork'
    'zRQptlKk2EgRpJq97AXmVslwyuoXVckun1ZUUf5NbIs524a1tUZNtlEzNiGQBIzGKmRCKgo49ywbqL3kpNWcyK9HBIXlA71T5Sl+'
    'DZ//uKuERdMEOVN5HCwgcy0d1FsdVY54dJoRbv73DxqtPpIKHQTPFQTpqOjyQeLtqs0dDKt2dcCdy/nvP5YLql1iRz0YYwxeT654'
    'bVA1+jbJJR5vlU4XrD/HjChBgVqpc6r6loQpHbY9relbVQvJ9pOMndVgDmG20i9SerDuvmBKIv6hsSlBMylEC2dvDxMrAJBBQmQP'
    'GGs+4+Kh8wlNImWRTHhQ+12jByBc3jmN2kAHfMrwgYP2psiTHZMj9Nnn8yZ+E1RaETyqF6I/mvvPkw30gQsH1AY3aP0MtLhHYUeB'
    'gDbRBFdwCFnCTAfKAPHOZvNod9KahNeA3/Vg/pqMwZiVL1aPF1c6NljC6XI62Kz4D3Ti+qlKTvkMveWdy5M+Mei3UchR8nKRRvAE'
    'XgpYhQnAl4mJW+du+nQur4UCx34BMXfMmMriI+LBVxxKnLyZInHPN6Xm58Fw3AIJFg2S7Pfw/fGHlBdUSFGGv3c4f3fnVrsTZOys'
    'mu2BTD7GKk1gA8E/6eRKOsU7+QzvFOd2J5zaLTkSbOmNWJ1xujsM9Z91cwngEZuv8I1NEyetNfhtxaZc4u37y0nNX09q/sak5m9s'
    'JhKjgnhS3AVQ07C/PASGpafT8eRM6C/OdaD8spCrJSJbdga2UvRvdSevNqTAMUgJEk4cItXeGHmpPs/U1X7w92lghNfBnzXF5EL0'
    'vO70XLEkREQ+GnRin2LMsyt13wMXnfjc6afTnewZ4NCekQ6ftdAZas3JHcvzTF8NSEFYP4PJwx31u5OxsxrMkd/RQUNu8/A/wWis'
    'QrvUFiGQPRTT2LDI4x4wBi524sacVIHGvVPzh1H+wPrFtT+h4PSub5/CMUhcCc9HpFeMr9sw1KCvdDKlFitufAuk4br0m2itFDQ5'
    'gB3XuReno0SER+lxHDWy56gBo9EO5B36UeUyXY+942gSjtxKBOOT67yehk5fEVSmU3wrOslHbDcotvgGI6bY1l78UnFBERk76xft'
    'ueySdrJ3awdZzhDZStzyEsPp37vGH8RK5Ghf6Csx2je1v6P6lu8zjngxyguYvZDKCyjjmHW2iBywW0joaQoOxxxC/2pq6lclyzN5'
    'RLUDc6RQb9lfpidDE9awrPgQ9pvLRaeXgjpfcS64cpNsJmMHtoGvPNm3J6Qgiuqp7j6QoRHDQqkm4y2Z8TKHM4TB34jD8On0dKH3'
    'Bbmzp/PwqYTFuIhMl0at5SJjQX/2ZXGdqmg+z3VywTUs+YVWAMrF0WiZL5hyJkXO4CsJVfl88WqDsabAsFARemKIpkcZdPzi9eQR'
    't9WSnnRY/mNw2mXsga3eyn2aHLRD2menUBXlOevF/OzV5TmXL5oMo9AhL5ydFOrSEjOTolWkv6Q7Py+o1cNmCm7fANXaHhPd3qJv'
    'Ko1wzCocTSLCbG95PksQDOFQdfLZNTR98fNCpCeXFDgGKZ2E+x517QHWM7h45mK0VBvw/GoDrNRdxOFlP5Wsh6TPrb/PqKn+6vrb'
    'FTOQ7vGVuBu6K5fV+DLb2KEi7Y0IjenL729oZA/W7RxW6GY/6fLlMW699P4DqZ5hfEpvTN0IoIL9H3TnsACa0Uedr1eM0EyYKhjd'
    'auxYIFD8vthVR/eoo6EBQKwKHf+eehO194ppxojB+WoTsUPFuWkAZBZRQAGySCw1+/1WhEzTNgQunTi6wiOaG6PaAaM9huKAk+oG'
    'T7UBMJSnYxUbO3Uo/sJC4kRHuQuNAo2VQVKJKNHT77oDTKuI53ZAM5RqDGXW/XSzTa/BKw67YQ9ehx4FDT2WMCmCtKZAR5HWFJf0'
    'rjTrlvt5XcNEc3n3VF0wJcE9P0z1Kx0Hzo5hYg8tkBNWEzsadYF+3Wc8lv5CO87BzOFBDJbRfNIFG0WBOKjZWEFGCOxOrZ0k0mXQ'
    '8/5gvaOBRgie8C5dPenz4HaKz4LNCH/pMQ/3f7d/N3YGm8RUoUApa1zL1RvhiaW3gSfQcVG3lnTfuK4Mcpe0nfS5NHbHo8Ky71a6'
    'AXLtY/K+6HhyJNWGL+eff148DqUp/0Jzyi0GmSKKc8+SxeBQ+N1F+BFCDfCNBfeGRcm7zl4Qtycqx70NSB4W9N90/yPTO9LJqESN'
    '4DiIrwFXc9+Ge0nbHafn3fCB8abPizd/XLzx0yIkWmEjLTaKXVI++NVQWH3hnnQECg0OkEWLyLE1GYGeoRTj0Ynsr60ryjCUhqJo'
    'imMptzn5srJjLoqgRPhFxg+/7N8G3esut/tdEhuugsj7fl/sXyxCe+PqMlwGwJWPd1koouSQ6TGD0j3W1RIYYWvHLlFeFuf0gs9j'
    'g1y1SgVgCDVJ3nMeT+ZLTOpiTRxkClOfbkUU/JooRsqDgWIJ4lA6kVeuS6wiMm9yy7a7Ed0Y0rl53cGNPeTRWIxVqIzdmAtNcgtU'
    'Y+lQydKXaiBNOr2qkU22mxK/bfS+6+uvGG3eM+8EcfITBREbCBuy/hdGzIKjHCkJe/xug8pxSdwod4N+1TaYwLMpvLryPgD67Ccu'
    'vGfln5ksldCy0rQ5DtRxfXi4aQvZzvJSOAMrZCEumma7DfBdWztkSMZFGFsVaNjUNonZ9zVe2rdBJ04b3XgG/wRXWGAO4O52iqmq'
    'jmtn2a1axWFSqpk9qu63xzO65NdIU1RzhLjzTvaBqaFi7FWESeL9KM49qdwo651dANdhUod7T6rwILLIq0FhzfgqauwWdEnhGHWX'
    'e9zl3u9td3u2s34cepdATTnlbd7cuB7L7it0Rz8HxIuN/MuaD4N9xBjZK7uWguypkxpMGfXSy4Gr5QQ9xOMM8ogwjx7o0UM9GMLb'
    'p9jeht9/t3YBH0JvWswHYN4L4cjah2/cbYk8N/E1WlTuXbhxoyKlfdCk5yfk+bXmis7PjTsQIfmqEUZ0GqTe0gW/MjOmSznQSbsx'
    'kBH7qR8ZDMu+A5ltQfcvWoMHQfaYjMFYgTrtLvn6xaEEd13H04XML6w2MG0dZrA9v4AfmOArKZcAqhaguAnGmkaqegDhe8ITrA0X'
    'ijDwKwMIJQVuTof2NEQV0f6SnvIlNl6afkjw9NH8aZvwzbMGQLyBCDUQpxU0mik2SQcIbaANtCn6hv3EEEwL60RilUgr6z0Blus0'
    'LA9kDGezkwkf07omSbqDphnBEmj7mYjawHmJm6YkCLarhPtR+Gg0M9GQ7XDKD7yDeSU/dkXNuMrwzJueHQcDzNAyHZXeQMw4vWFE'
    'VCUzGQ3UDAbjMwbfRfhMSuFjay8GySTLjyTWFd4w2cFMA9oz2J/cvhz9S99dwFgaWbLUJhN015gKZBZWl2FglApxhLEzQ6SHkijf'
    'rCFskpL3iIjA4sBvZNgAVbsXo4d+YrxXTZhKUVeAl4JAeXvTx5vNbfr7d2vdfh3vKiC2S/MFLQRkJcyLX4vBWXFpsAMbeXgIWJbk'
    '4h3bzGOgLdYhsFto+pGG6qunBVfLiKLHDqLYoN3s1poGZGCDA9JJvO6zBwTzOOI5zzg1E08B+/x0TyB8AurmQmp8RWpQt2rGRAIl'
    'rdkDIiDXZ3webLJlNHSeoHQJ0dI0ZlkJc7IZXhD3xM6Memezzo0nKmXUV3PTWWE3HFghLcj/Qi+y8A7NM6JwsQyqPSaywj5Q4wJy'
    'waxfQ5VG1gWNUJrc2KnlKb2Qf5AzhfxqXZSP7wU8sbYmCD3RncNjE2h9L0B+Xb1R70uTDGgVRabIVvkQ3W0S2d8l4XJjajRhcrN2'
    'MeMYpJrMdrt5WYU5YzHrTplMPnCewdw7IrPXwYNQMjrFpZKgx7QpVsyUCZHR/HgvuGRslhZPQRzD5HRge/D8JGUtj5M9bv0wDx+K'
    '3EBdt3kLlxu9VRZExMnchoYg5nJpL3h5UOTFJ9uCrfKTpJv2Nqs8NQnVgCBvjpVIoGehsXtma+L0s1iUNQqgevsNmDtFR4qAUErs'
    'knRROerRbfh2612qOMWwPNwsBfsI5UTJqA8kV5OSQFUZ4hikmtjHTkHLXQ0LMQXBFbhhIz5TA1kD3xD9qb/rHWI3vgioi+iG3sD8'
    'G63nL1398pslEF5/5eVXLdSvemo/GXvpb21EfPkArlc0pcswUbS+w9BJIuO8w2I1JiCcpgKpklSj2hjmIxbOCyzUoXFbWOEXDWMB'
    'snM4q81atg/ykJRraWgi0VVoc2n4pHjKkfQggdBNSZKjQHZ2gafPSa3RWIVxmZHzvvZLNlmYQztdasCx9BHHcg45SEtgv1i+LkYQ'
    'RSEe+tbe6KEWsxFlKjsEi8cMy/CmoO9fCHr/KIqPwk8DBdykq24roVcKSYcSiQLD6wb2if4MZDfSM0o4zcyyJtWtB6NvdDWQuMQk'
    '4gUFPX9W8UftfjFZQr6kILYJC0VKXYBA3jiAcf2ysAphMfOWZt8S0NnL875I5I6Njg/Lvi2+tE2dyHaXpIH5PxcrjFbdg1kxFeeO'
    'K+ISNXFRIcnqygBtzYRmJzRH6rKEKlOOysR2DzIZu3UlFMmwZdbkJ4VqQEPkKrvc+FqkUoVTpwxDYBVhY7RkzxM3dngvTlDHxWeL'
    'gSgLgYhdlWgQF6iootSVN4U5i4i3V4rYT2PPrFS8VTG0ewrIFLG4H9C9oXBNT1u5NuddHGyBmkRmHLz5gz3D5ZDbQlVyJlXkY3Bw'
    'vNHDd3nELeKDvW4BqxogVdWP/bTvVR0hKriWqNZ1yXjvZMwtZTd7GevFb1jC3MQMcVRJhEWdrg0SfrBPnIFpgFtqQMcIZpo+kDAi'
    'KIQ0c19oQ/hGW5wxWsvohGrfF0CJYD8U6xWu/KxCOiXhLpczkr88KOiC6+lJ5utykmp2YF0GKEoBQeG4JJhUMydDzzqz55T1cs+n'
    'xtsvXm1gmJsEg92oOgPIMLZR1TczKGyawVD5i+Ia7gz1TrUMcm8lh3ShYCw6+N3IwMkcfl4sr3gh5bxT8DMLifpijd3CyhPEjU2c'
    'vmnkrocjlabAaLYaZZeEyB4RWJKNTloHe7I7RcKBAFhRq9ZoK7jPTmDVXpY9/UhA0TMH8MF4FyuI4ipY29vgwg8UDZVworrFWAAy'
    'Gkb5AXMwF1ZB7jX0TkMCOzkgT18tAplmSb42RD7/YksivztBcL5WHRn2+jP7oYGyveRIh6msqUM1SDgAV4Skduktx+AxqdmpnEQH'
    'vFNbFxXAAnU6gghowlJNksIP46AaaJkoBOxIMzp8Ml1c0hQoCxUWd7SB2fe45SybJzsRWE5wbBGiqKwrehrAlAIjxTU51JqSHd+H'
    '0fU7DN2x3r9ZX3sIqgBm4WmP7yg09FRgw5OILPAFQQnak4PZVWmK5iuEaxSCt9THNXrjNzLhaXPInSnjmPrUJviL1ydLWSqeyQMG'
    'so/Qxt3ggi0WFW1Ke2AUt6mjo+OOySDhT7pFwbLkbtjl+EFBt+3FTivWgJWvDMC8Bdmd9FVLl8UWk92gNresvcUtPHkQmCRHQTE4'
    'gP5pF3wcXHP9vgPWhwjvY118g6qmK0dFQj3qUJIQNMIJ9QM3aJp+pMCwsLMKFXfUqXWjzhvKa47U7Pf3bFtnyX6qyf+PqV9UUnac'
    'BWKMsLT+GGyLYi+mjJGGgyCOTfKYd88ywrD5zsW6bdjZJ60PPuK33i7E1BmcQXMtZSKwG6CJxRwdmdxnGKm1GqDEs/RyH9XNTRMU'
    'fzpngvpi8mWGfHgIB+KA2/u4M9cbsA+RO01v7GJmzPS6Z3GUbVZ4Cqxo1suET+0oHZhNIHD7Xijo+83X7C9+jPe3OWz2sa7k1g+k'
    'IGOLYDJ2xoupDUUXEWQ7Xo9LMs77UDv9kKn/YsJPHeZy6DdmifFz4XgZUv7XC5QkkiXJUVCq0KCpw+L+JEId5tpJEgvwhXu/cOdK'
    'V9K54zWLGWT/kFRVAmNzYmIny0eoNgv3hU+6QrUvjf9BQh30DV9ruCTJzDlH+ufboVKyUW6OUbIKjsU5rPJasMdTaWIwHBW39/9D'
    'kr03EPhuQ+FFlyWwg43uEgU3Utx4LCgl36ckyQSfKBuqx2bCWwpaOxfT7STWZhwsOvALRLDyZSv3EZPClF1lNx5kJ7w5AdrIn5Lt'
    'PJOOvRtXHB30ubL7oQ3Kgjl1UoOpadMuZd2w9iubvfNpy+Ru0DcK/AuPf7SnErDO9k7kKPSBNcqqlvRc2jhrkwP1roEuRqli2pcf'
    'W4pfqvyqD9c6BR3IiLgeosT8PIa5H8JEN/KRRs1kBmMWN05lAWC+iCZLOS3u1NDwMQkLfV3rVNZ8KvPExrz4mVivQhCliFTPDlx3'
    'aKaoppkO+bg94Y0mOxnCyHhVfVXDocixyVd2qwTGEV4wBg/3nKYonqYoPLSkwUShCDJezIV6wQR6xRZWBRWwzBXC0lQ5GrfhKsa2'
    '3KSeTIUqDMkGOmDm5+qwalgyyVxxwW6/DqFo8MbLl2rNb1Zrfgu15kF0u3wwPLzgVo6JKT7ubdDHLIAaB0o9hmN2WTpmHflARqjX'
    'O3fPke/6Bh1s7FS+P+1aC3dvpQT75tBMMbrDuQhF4LdjmvVlz6SCIXyoE1kMHRGHmEIg1UuH/IsiIHnkK9HawoH26t6pituxdJ2E'
    'vd96LPzkCqXhjHe92OsqI9OqV9ABd15DGgR5HBRtXXBkWef2HW9jdjnQzfDC8y/OVHaT3Ca5diA4+aEGl4ODoOUFxzY5bqk6NKkm'
    '9jjJy4MOOd0MtebMQSCzkEub0HM51K0BcHlRI6xpQqa49cuhuuQG9crXFEg3+qgiZHqKD1Y3U4rwimQH5eAmZwCmVwjdTD/M5EKq'
    'gapQA6MjFi41ovJWrAS3sfYAjkUJh5m3wskoLZU6qj/LHTinkxMBhzNa30EOFpdqL9SCffPxr0CY9E382PvqyyO+jh+6vXfMw7/V'
    'Gr8zfuu/6d80tP8LC8gkxWcTFpO2ZzNhe+mGyyOPoJgGuG5N5DTM2MjaYKHcKFryCIWAuj7182Yn7ySYuI1gwopDCHaXRWALHwte'
    'O4Bf+FoSRRHQzYzFYEBMuAP3+kECFvoO74sW7JoVs32WS8YaZ8WJyUUStDjqejK5UfoXLPUgPA0OTKo8xOQhY9mdCC0yi18jrwEb'
    'ik2q/JOuZnnFZmUapFm4sQ/uD42FoQgVKZRJIuiVVxnLeiAjeJXvsYnqbQYjwxRhUqCGaUtBUM0mrkCE1G3gJFOG+AdnGalBDjwT'
    'xUgJ984G5kFRaSkXCtpcGXNReQLwRkSqmUIo3GU5DXz4XtPayMQcgO5jAJvkKRSsTdRmb++u+I0pBG4dBs5VaSChp6IF052x5BQ9'
    'guLCyZ9SD+AyYlFiolAoVZf4ZVF+7xD6ctJInpTXNfPg80aeFExtA1npNiozEoe8YCksNKSkWViYAzg73nCFsicmYE//1PhC6vGx'
    'zeozMSb73UxxmVVT4MEHyLp8MKel5Y+o8nCwPBx/iOSVKCrsX61b1QDWdPHHaP8U7B8HpEaG96dVpY0wLZctvS/N79hypr152mCc'
    'c7pTuqDgIIdanx1yxrhnSq7bQj6FpKn4Ka34wQLXoa4PlcSE1iND2GibhtjQD0MZDGFc4vjbbsRdmbPlDcPff939eWjfzV/+dMcy'
    'oOSJhds9BTnD+w6L7xvR41ckc9Gz6FE7cdg1yT0W6gB3SZSmhi/d8ku5256C7n3u4KDnmXK3/e4Ez3smKNqZb7iJyssAmYHvWL03'
    'UVXFJlyS0aQDP5CIrnZMpluRUioz9qpE626iAdak4dEkbU8NDgrmOXXMGOWGKc+3Gw6ZaSQ0PpyUdywDXZwFhhSdalFebS15kXcx'
    'OQTnZUyECqpxR3ebFI21EBZlwIl/QFaGNuCfUbKLBF/CWmYhYJwg1ehwQT9EzAIkXeWKnOlrixM4LzGVhZtpQF4DH2R5zcqnCtXX'
    '1ztOI5t4YKBnFk+DynY3qdxWdkqMsIB35ttuD/v+qTgrodE3zsNuAxMuNZnubPDvGMlQ0o4jmYkjVkq+SWfqaJzmy4UCdzVfEkSB'
    'SoIihsycL3wj8LMKS9GMTSNNJlq31qM9ifnGbyMTDsmadEYWAK4n/DQ108jEd7MXajUc6XLh1/OGfETzgksrW1A8OX3kEFx4HtnU'
    'xrzyAWVXE/d8PIAjBWoIIYxwWRYKj7hBuUUCBJ1h48LgFnrYKe6SsEG2onPGRoWT5hOHTZ4rnxYkrQm+v4VhnygRegPlYyMVp0uS'
    '7PguMy3cfdJgxewkdEpek2E0VqHD3WTNCSASA9f4BFNIvFKSJL0VB1Kn1qvXIsHYgUVkStgWLzjZjTJM8pqGTRaJgt1aIe+U2YCD'
    'q+BmZh5QeT1AAcw8hcuoKyu0yBuRkHl7DIRdknaZYh0M1Hc0URvkFqjQYs/BtEhnuVEX48v5xMUUTV5Q0xccew3prMvtBQ7AgABy'
    'ZjAgvMmMM1cmrG0YBEx1w5utlbbMB5uZx5ln1xNpuWMtaENsFlAicXIa5Sjg5TeFrN5K90HTsVIwOceeGHZDxnvsO9ZbT8vnipvt'
    'JJFlvvhBsGas3cCGtfojUP3DzUOjRt6BLdiW/5k7xiaf8zhhrQHEI/GAWlC4Q75mfMahfCAB+cJ+esvlhUYEMo6cVaXHVm2QS3n0'
    'R08wvm+EvLTMj0Sk9ZrDIS+yvcIChiZQfbMSqM5bnqFqaMJEKsQFp0lN1EcPuFEwLKxF4CWPofJy4DzSdg+Nr+kPkscd8ZNqE4ij'
    'nyIUdO7soMtcyh3nWJ0UbpkHeUSfLvM4XUDshgNfdEUNR9Z95pETsiIbbSp9Istbi6hXYmuWmR18l0KyOPqdmrkAGsi7QhHNVaOm'
    'jG53E+iNEOC8lVvWV3zaeRrsumIaEsgxC9Ows2uQd3LWzAa1pJlZzs4zJO4Qw7GMY8smKtTbpCwkDGgLcVDpZqAXkhxXlDFmKbjS'
    'BubwgjLXwxCue2C5hBXwrYeMDgIPK5yaM5wzCoFDroBMW0NcHa7X+yGSJNkumuBJ6uQCwJzQLS3cDmqbfJxEjsckSXueJGj0ZW7T'
    'DjJ2Jud0kq78dNfYjWKXlGOdZDnpeNQGmOWkKmJJ2tFmXYdi1E4+fErSEQNijGsbJbkNE8fn0TQOY5Co6DAlQ8dqcthBtAEnt4s5'
    'zvz4j2lxEgKjZZAaP0FWkibbTxHk5Mhn5SZm2vStjFJ5tUVebcqrTe8IkX4tPhV/8XCdgvDlFWzvvOoxPZNkNeAAOXaq/7mfrQvP'
    'RcmiCRW2eKBcYohc+FbnMSEfVyoY7j6qjYbFz4xvo+LC5Bveo/DuZ+H9+mRtk93ylSd05HtHfqsG07fnoPTwSpKLQcFxhpC4CYqg'
    'GtJmZ5U39Zpl9NbroE7ly1FJsMNXOPQu6uEUD60LT9cjfAi7JA9j7KyKMkXA6muL/ag5KtB2uBExbQ+lbFfBKDnLfYqeNahsHpKy'
    '48QbNbpRctNXZ3qKNpgqkk0bT0l1wwknUc7hm9puwXZJp8qPTIQB6sVQEt8nrUarQQLOygExut1eGqfi/FwI9XCL7sD5PjMX+Ljm'
    'UYPq1ojcKF/q8garorZhCuekzjaIClIbfCTBzH56wdivCbW/82pZ8Xpt5CEz856N3MyCpG0RRIfPXcVEWzwpWDelQHWKQ3unwsFB'
    'mSX2WcAocHDOaAILJA7jx5JZOLL60ECFlNlXLypw+cpEZSaUXdCio9iJdMe+ImE02trBOYGZttVSzz5XvWIavlycc30lvgkL1vmp'
    '3HI5hiAFWVRi86GGNR9PSTuISI8nryqJqsKRwDeFyo37swUrKSgVzHsJ601SsbzlZb8bYMTvYNeJMArl/WDLciQXRqzWpeS9H5o2'
    'Lv7WJGJ/qwrYsT7pkq3n4XeBjusYc7nJcBfYp94Pxx9WH7XCcAwSwxVzwwfep8fA10o62XhShhKGSqqro12NrtygbGRM6snwjVgG'
    'Bzb6Ir+BmiWyHbssWzU8EqeDAeoYBoNPPvBDOnOENit8NoIHl8410Jvu4JoBhHO7De15Hy1dMM2jqvnBQeGhQeHB3WybLSpBQUOf'
    'AyQvLZppaGTBylX5xIwBZNe8QNMHsKXBQFtm2swZjmNBJTjQ6de5xoSdwE6NXnjH8qSgAzy49YKFEQ3xCofcA1lcdML0hGOkpwPZ'
    'yxWPk1c7Nnzi0zFtaNTL/dDcPUA3XT6pNbdYFj5pVTiBIehTideITwczvu58jTZsYzN0p9sAcGv9UjjY71CW3JAJ5VKGSQvJp1hH'
    'PvVl5GKVyPNOpqNlwpuNKTXBT2821u+5YmD+znxv8+zf6a0a+Fk3ql5ogXw8UfPhRM3fvfm//7sP7f+CBwI4CK3lpBw64s19Ujsy'
    'oBMcpD2jO16JEO1OALiP+wA+IgxMik6cLiCHPkXM78pwWnMEDNqGLYCMSYBZAVjpOanVvp/8+s27o8+XYT99t1EfPvx88e8LERbG'
    'hli+TANPcT35rnBv81+TE74FAQ+EOS8UzIa5UPRD72HwBTbeIJLIwLm9sygH3PCS/kmJYJM3CnwoaThDB8Ad3xMhsmRW8FhgDnlc'
    'u35SGumBTncKBbvb04v3v+LHOc07VInsfPacAhTQzcKHwSkjAUMCUVjrisX5DZ8YzgPl8hkun93ls1WeksgcF74ZocODE1O4HuU+'
    'MLBtvMy6szamae1YGjuVpS2SRueg6DIDZ6zOD/K0O3KlQoZqxnHZSW2NZvVu/YRELsADa10/rKe6/ccgX3x8OqFbuETS0JckRniF'
    'OnvuHB9R4h0ZZPl0Wjpzgt5l3iMQOlPItJgU8eTrU2Ss5EMut0HyTpgvrNIbOwlGlcWg9CuRVwOMLWc3A6MFUcRgcjEzUCBT3whv'
    'DQ9COYN9TPfBxymKKIxy8cJ60FwMcnTJJRzlcHGUQLmRSJvLdhmdyviUS1YETFvpEz/gMyep736LA5nwEoWtaC1YEFntag7LyIOX'
    'QeiHlLWNJajgxEYCr5KvinZVCdYiaqDLj4hSsEqfg1k+Oq2n7bEG+0snG00VDB3H3WwpHsDWW62CuboGvEvV6PLMrLTaViUsxl1Y'
    'DZHv+rANkvkJmOxN+Eg6tnqXVID8ItCQoe7sejTy8nN9+ZEBU7dxaQF1mC92i0gQGmhFYiruiUFUJonz1/fQnXPvGnPE6G1Xya27'
    '6xTWp/Gtil5IE9z5LqRloqBV0lPdlej9TpH8/J3UXcWWqd19JzujOHgYMvCNZX73gYEdamMa0OnhduXYnA4SXtl2SVkzXa+BbcCL'
    'nHcO7Q6q9S8F9Mp4Ib6HeTbw4vtBwaDeD0WtM2Yb7vfcSk9jSO2HkX+0QAJErefH6fxsFHQNh396sH/qaIuoaP+x/3wfWJD/Eu79'
    'z41Hs8FHKQgcuUfCty5Z0hUUpwb8UA/C+IVyx64vSfalVXqSQP93eKmFtuhQ4uRjOXwP/Rpf0wltKmaWIRT/YgeL411k2u8G+npS'
    'yMPTDp90yFQUXihKUnGAxe5K3EjBnog7Ff1Q7gRLhd0qErS+kN0FLNUgi/MNuxa2yCXsWyDQEX06KPnf74oTWE2Yyt0BvJLkKNgM'
    'ivRlTy/fEvUCCpX6l1P3igfu0tkQ9q2Xzf5GumDW4459z/B/3dnkQoVvK8MJPWNKBDD+DK0KJaYnjQaFmUZnAcpYSnp+3DsoS0jc'
    'NNfLCNRaJO3ea8g1Hg0LhTzO3gQCBonqkBYmG6oxBEhh67W2/irvYJmnzMlBnpODPB3wmsRWqLsPCAZmyJUCbQ6BUWSMtho+KZjG'
    '5amQn2yLGuqml6fvT4TZLbqF/ZoUOAvkogQi0nVu7rAcALQ+eUjBPXEMdkfXWycggD8peMv8XZOkduo0ijXZ6PiR4WMP82XT49zK'
    'LJkwjAJDIp+Dnu6zvWcQKFzyIGEBAisXisQ60LoT0OcFdj3w/TQYXdKbmooivxqs+6ZKwqQ9r6bLhzDO3OsBqpeTibu3zTRvhkvi'
    'ZkUY8o1Q5XHP/UJrn/E0W9eOYxQsetgNttiY04VrXoSqiY3lHZ9CG2UQWbeUmT0AjdQS57IESVjxGMtT7nl3ZDVh6NFGalSrGWQM'
    'poJT+0ixU3iuLHhV7xIhrFvmuUAgUXyvpb015prGubP2vhkFv6g1gPfmqj36+XrlctpGHpgQvc8jfqz5mMaAYL3j5MVdcxetS15w'
    'EM6HrA0oP8/7F+VAbmagE8sOAG1Ow9uAwys2ci2OI/sQVCtMkmjJeAmZyIpvAyEs8D0GJR2fDSGwCP+uwQ3kyGEfmO5HRBf3/CQi'
    'PDTdHqLNK356UphGhYi+riZUBcmX9LaYtWAByK2iIOcbbsaghJUzmCwPyClJ0ipSvDGIXZHsjgJNEHrG8/PZBu8oQewez/iYpcqh'
    '4TBVxfDdNTt1oCg/M/NYHdLZvdG57n1N07eBGSOjmUYvwWrQaycRQvn2z69pYrDBjblLN+udRkAl5VwIljAsBKUO7zkuSbm3m2yO'
    'Mt7c3AwOqT0OYLg9AuIlUYnKGN3nC9/X+XJhYvi9fkz3/CGn3HJr1KBGAGJKGBFt4BzaSY1Agwnf++9sCPLtxoYs3x7tFqda+ObO'
    'zbJgidQCDmeTugRQLXDPrZFdMjpUYH/QAYA2NuuogHteLpnmhQbFqb1Qd6saMMqCMlGQcreOURa2d1Ysy3DBHmXRjZFgEcY91Avc'
    'rUHgTg0CTa4KIF8HHqDYKLJR1z44t+aeVzajHGNjfK2YGpkftvkQ1kG92kazdtffNQbPigOjcPY5g4VrGkTfeuzesteId7Y1pugd'
    'FBfcsuXK69k6Nl7TL+fZUNEzDxOGG2p+EjCxIEIMfTOnASCZQQ3XLP9iDGF6sOeat/CTl2M5SGSUospgHzEFyHU2QoXBkXcDh3Sc'
    'fo/wctjJ24FhRC2lJw1uFHCQHxSy5ku/AS88ZVfZMURLiEOo7rZ+alwlZPjPeLAiX3Zb2FPqDp4PvmuyZ4Uy1w3cpa0fOCZJuCnz'
    'H3OT2C12PqWgjI4VgyslCEXAQlnkcaOzMiu3SGwzCvhZV0wX+HB0mN09RJLkN0my65JZgYPamdT5mKqi4ZhsNgk6L1vEFxhh5bRg'
    'Q45Qc9WUUa4/OF8wIb6qOlGfPkbHdOlkZtEUR9AsulV9Gez0WgzlI1LlaFZYfcdIcLmCGeHsbP8UyM6OOXRqHMyT3bp+G2O2Sivs'
    'XT0Ifk+769PZXQX3KOgUuqQehd9mI6wmVcKOmtzamanW22DqBVidq1AdyOx5PJldG97zLQV72TI88kWPWf5KQNBoBN28vBOF7ef9'
    'T2l6LxQK4/12KWs5sa/4tav73urRcbkcF0Dzc7S+N3u3x6iZy4NrNe6Y2D5w+G8DTb8eE36w5l5BACNi5h4TJxyOKUMcaYOyn/uh'
    'Fad37EuDwMUVP5RAyCRAd3oOOz7wg8uECfLBW/HXQmER0vGFiQMoaetY5I2eUjkY1jxKOoaZim9ONnaq+zJnbnRebVAQqzyt9pCL'
    'pGyBSh5VMIlkJSV79TvoUQz2xuJ4YOCEeRxV8pjaASqy1kuTBZAaf8xrELQIYm+PW5vpLU8MYYpcB/sQmavbxIMWSAj0qgzaVFh4'
    '3rT8qv/oj7BGll5+jqVc7ZJfPu+836IHWVRYURHvhkps3TOWDk82CpkoTh2GCqf7wfJV9jDAd72w4yBUlKT0SEZXdwqGXp2p9aEb'
    'rw+6eJBXdOcItOSntTt3uTW5+waQCqphVe1BOj6DZpc+UKIwBuLCSFu0PZDothP3u3SV0rTbzcEvXcF0MV9xQL3Zs3XkjrC/84yZ'
    '9GWybxvGuPThenxyrEYlebY+5jx88WuEiz78Z5qT/ExUvHr/rPCXeWsZas0bshGExAe94aTXoDiGs8aVOCyKBnSC4kLvEMFQcXIK'
    '95TQyFMyxfJ22POOFIcHGfBgv0zfDj/gm45VbSzjcImxKPJ8bZX1E4xZ+cw8EPr6RfXCb8bY9kTuNcbgvM0aVCv37h9q4RiCwG7+'
    'N+NbC94880V1ar60hrv1QmaoWcKynfa7QPFiw4UCxXvGCI3eWk/+kmFxV/MCNbbt4QwmGX5aNNgoNnNv2Hxl7A0//xDFOODXRi6t'
    'eAwUiyR3jpAtH6GMlNL3cDI52b7WqYUxjUHDyU7Sx3TmtNRSJqioZ+pmfG4C1M92xQ6T9B+jnOySuKWRnhdG6R04IEWSBvhBpjQx'
    'YM8LCD+QzLd/87QNu2TCRBTZw+jHBPrpJJzNEBmvKSC0ZPNZTOhNr3zni2OMbbaL2IwEEO0S7QoIzhaZW+j4tVQvUNhlqP+ohTdH'
    'AVoS3ELFm2QljJDyxDBQtHjoNmYkkNvY5mpE5oDNPhN3XnRaFnB1f4+b0dt4kKSVJJyeEdReROlCj0Aom3jomAJp4vCJRicdTz5/'
    'UZSoL0P3fLrHpBZoDbcVA3qSPdLW9+6fvJ6cmd4NEcpevmJEfeejXT4DBDP2ww0TDTc9COJGm/ZywSWOQSkrQccXmSmqk9fT8Erm'
    'Hccg4YqJDgbLS7qiM23C2tboONLrBVuOBDQeBM33GbtFNVEMMesnhsHIvEI76byug7ZZkXInFfaWDNXjwi8DXadxtmMx26KfhILR'
    'KM63M/riVnUf0I3DBIIoXWRM1zpr8XBnNegeDjZOQZvRZXvRKY0gsZuyGxVXvkQ+SsU9cf8i/aLGgqCv4cvTKzKCjHYHH2mDuZ5k'
    'NOMIyFSu96/gjj2CI4PdEz+caCRgQE+rPwKbi8FXNO8mtionnlybAlyeDv+JSSmB/ZVdz8hMCbJhCa5Qau2hUH+yQ9DRbWD77Ich'
    'up9MIaWBvV6zSGVwRpLGZBiNtp6789E3mhbJxU61f55MfrbucsMZ2U57bGg9qRPHw/zEeNRtd2+TXd2SHorYcNJw4PwkYQvWOd9o'
    'NlWznny3QmCtdvWygQ4TdXF0ujtZe5R48KNczhu0Sd73uQ3iSI5cI8zGHRlZOJWdpoZB7GgZrhE4dB1EjaJBqV+8qB80xZMSO12n'
    '/pQXHafW2XjS83qE17sfq496DKJUL3N4t1++gVefxCgSQZHZm6UvYYdS6kQXSfW+W3kQo2BwGSc9LZ2cflKjuJKQNSsvFjG6WlE9'
    'XLQPYVJQNRlGo5zUCKHVvLOc0LTYx25QgSax3z1QrXrrzkadzbufW9ZZEYqVmtb64y9p2v7DfYPFueTTIIN1O6c4ToM86RmYT4MM'
    '/kpfVFkLQ5QtqEgVVocH4qhBu8N8UWVyBtPsODOGN0EcR34Wqh4hdyK4KtzkDPd1lmctxxaJW22s9pe/jA7lGCPLSfeTKQ3n9X75'
    '++rk2zwWlQ9gNXG2idk9eRTjXrj8+I8S5rPYHqoJ1AiN3tDWW6NtuPKA7//PjAyF4VC3bIsXFckrbF72NKb/HexlmsqL6SL7F0aG'
    'uPmTx5XZ76HWKrZ3S/BtjiifbDNs/dQjdRynSYE9GUGJbeUw1PVAl2+javgIUlw3ElwhHGPcPZnsJq75DaZ8NFeArcOMGOXzOjy/'
    '2NVdty/D+B9T/TaxtIXxQ1q28H/EYcXNgLehtpmdBrycvgxfl+ylpsBRxHkQx8WDtV4BH5OZYrtTKLLZxVls74Q5FFTeaJAnRT07'
    'ZumFElG8s5sLspcds5XbdPy7cI0YnW9z5FgrjC7D16X32E9ebUiBY5C44nAWnZYLhs1ZxjFINQnXR6TfB783lifqtADD6gGl11TZ'
    'gi9dgipE9zn64l/m3cbWZdPrX4b9rK9hDo/tnR8PJwyfL8NuvqQeNGgPGtqOt9qDayHNr+E0fd3jNlErm28AJvYtwKtVDn4bZhWO'
    'Zp5x/lcPsupk88+3KXzm5cudDg0nx0eD84pNvtYaxrlnQJj8rMK8/8dgn+WZe36bj1+GCMImPfJcCvuOwSIoqAp0+rRzLsjYWQ3m'
    'gE0VAhawdP/RCIEe8dTJe1NQ5hiib9fj0hNLqpQeyzOut4GmcuAokpGVUmcmEiGUXimPwnfmxl+6KHdE9CpqhqtCbiRqtSiLzIjt'
    'tiojY7JvHMKj2MnZY+uU9xaGHse6cZZKzOVPXLZdN70MR3FUm/SGgPIcd5WRbvh8GfZv7lTUlsmXnta6l+MatW5Mv5IO/leZ11pd'
    'yc0QxgH90GoDF0GICtWPNhk76xcj8OhDd3q6ePUA0FsE6yGd3nc3pEHl3fHcbqlEDtmwf3NlyjxJ7Zdo7elpvUg7JwvH2/Dloj86'
    'crvIBNcpkfDRq9c4t0eR0rehOwpDDZPrRbjFwvd4hs0Uh6fT1Fqbo1/SMdwnjQDizO0eSM/P1zwenbCtCxp3J9PybWA68xI5nRdn'
    'M4lc5j6p17geZ9ZLccyaZxGJp1mkkAILgy6nT3OGeCiy4yrPDcOvaTU3RnD9WRzLlALHIL4F0v1kjnKZIpRoV8ez6zRyxk55ZqqO'
    'TDf92YuMDhMGp7HP+InjerphBK+q0LkbkW4+DXpknS8Oog1K3TZArb9KNdZ/uuajfxsDkTB8RHve4/sqJZsDIq2xDbu/xWVazgtK'
    'wO8dS2Yist8cTXX6xeyC8/w0jDKdfeVmKGdv3med/x8DItJZyrTHIcW8HR9STCI3yoibcgEw28emLBdZ2d6Zp+DV+JZDnxFDW9V2'
    'AG+Aj4aF5darv1nt9OiUDxhMNkXSWWPmS3MunSjbb1J8TVIce3Uy4hBB0MWT052OX7ye3KntBl3ya+3rpSZa51WRn6b/e7UHIPuy'
    'RodfPGx9XWd6mVST1Q9cPJLYDaczrq2jYY9QuutZz2iJNwnZ10WFkt+EI3JfbDxp7dRPeDm7huR/gxheqHEwDlhZDXLaj0wIvnSq'
    'wtlPThBXGnRIgsgZMNNUBsl+U10dPfk6/GLDrvJHSiRcBMugroBGDF3Z9kmVMqmJDjJ2tobjMNRuKiclO8ocDyaGHCK4ipuB7jyl'
    'irrpmDt4KxvodfLmGzOGQj0mhN2DalM77Abeyqm1Arx1TnUHk+aLttizLrZj1Ihdxnxs2s5q1IMKWoMzlfehFz3uuRT4ikLv46qv'
    'URXXbgvnPVBzeyfvDhTe7CQBHTKpIj/UmHkljIlylpTRzqu+lpmEXbTnprT9Xx8xkdLOxX+O6XmxasLnITIGUzpFmU7RV/qi3T/b'
    'vB+1sT/Rxv70Nvant7E/Zxv700a3V5eln1AifVJZs8D/uHv9c7hd+jk8dPg5Sg+h9EmLn6MIMHOOAB74PfF9eHtgiIfAFqzI8kmX'
    '86ZHoG+dBITJ9dHzhisbdyAB6WJjFd+gZFlOoIBQdy2qe9m8HqwzBpGvbrrI9k6Y9kY9xN3yeinSe0xDjL22fIZvWjvn45EZC55c'
    'OrYP1ovNCDva3RxaD785/GFO097y+dGj8acPJmmcBy0zMc8D6f/foRagFTc+MOIYpASpJvPJ+BTNeP/gxt5vNn+lb07XWm0/t/42'
    'EwagfY0KxAFV6mQ0i2moxuMb2lZVfKvf8g1V+kgcGnr2ezI7p0fqOZth2m2d7M7dOaxJky3pi8tP2Q1KbPLEv5gSLcZgZjaRnO0Q'
    'ujqYKUyu+iJu7B6SYHmGiuFplCucyJ068x3O2xFtAqZPDEqjJldSp/vJnID65ZXJ68ORGsORc2QkRo95dYpxZgCWKmxtdKXH9Ixm'
    'hszBP3tDQ8pmqb1He6cJPAWOQapJBDJHw91ora4wumfNPupgK2MP22dcmfml23kNg4lvv78uql9WxIGLwpUH8Y1ITE6x/Jz4JMxT'
    'fzbiThC48mCfe9o86BRx6QzueGBSRO0lvKeTjSc9r/eYwSNmceeWTfKCjkwnDpHzHA6m9DFg56fHSC+476wcPatFHakM9Hpc3GQ5'
    'XCxl7bXv+B6AddP+H4PyhfrGhE54KB4j3Q1x6euKUvH8ipTNaTeVKA5ucvzCazj1hJUpUkWmINsLCGcquboc5ZzMOA3qUZ7mqIPd'
    'QqZ6fr1uIfIZ7ThrC7DFWHRPkz5RkOzpZGOnum1zpgVc7Uhj8bhwqpvqslk96eE42oAxBv1h2L/58ummnkB+kg8/22gY7HEbU1hF'
    'OrdRMeuzxR6LTci8bM38tP10zzVubPMM5B5p3Prdb70udB4xRP7v591su18Sux/zzsadS6z2TiLsrzGEDU5FuQ7l6UhxAGM62Rh0'
    'WVymdy1XONnp5tkfKPRaaoTR+RC5Xq55ydvc48P+kusZSnbLSX6UGp5QBp1dRX0IkfDYRxLivsvb4MdbbnpVmY0n3b5d1E57YPNq'
    'zL79n6/kLsO1O1ys/kEGf8gB9fG+YTj2CAknLxS74sqm6+fLUL4NrkBUb91zEsNG7Yqz0R+/Zdg76QUtDEsE3ery+Vyj4JWz1BU1'
    'hf1CcjhbjlKSa03zSdWpaAasMuZzt9cnF36R5XioXnlgOp8l9VkiIrDhvxeGr1IMcw+ipF7+wXueYx3B4adIvRK94Icp7rYcUbLB'
    'ImDwM7DjeSanRrNE1t3Up9ec0bD3h8dRRu1875VgH0rt/O2PgTvGB0sn9oeO4cnGk57XezpeXy1L4TfuS+khzul9MnuGmig5P1ON'
    'emVPoKelYpyxbpigwutloCZjZ0u/6uTNfUqk0XnsvkjHk3fn8/jtQc4zxdJfl8E/navk5/5KD8rEY6k18bd/3jB3rN3gEH/P7xyn'
    'gUFxyqbJK3STKr/Qxka6sOhVy7PAX/GhonOFr8PYgig9JT1nkRad8rjEV5nGoFEqSOmsBvN9FPSoFXn2jLvZeNLaafjK5zR7M0SP'
    'OqirUdHsC7GYRAAxNWRWTZ3V5wfB/Zj/y+DyHOq7l/MaGNNrGLuRzedr0Hfw1+CIW3WZx0C9dhs9/DBeg0+I61QOnFYRhtdv8oUN'
    'MYpUbelLR9eJONJe217n2/rVlzSAseEX0dBWXEzvulesTd1eMbR76X33ircdVdZMKgGdf18I/91Uv4xOQ+2prvHpLWi47i4jhbFg'
    'e3vN0/kR+oXFDn2EK5Myd+5fzEnttfbLvWV/zWer/prtzvfkhRWvuUfX6+Mrs9f54m5Q4HJcC1t6UJyvOdudTMH37jziz4ueEXAM'
    'EtmSF01ggTgNOAEt2py3pkze0vok0pzncaZAkSXIbpMRH5TymDWVnCcsNUVKMtZ75rcEsuOp3QStug3XY9jujZehnvmtB1L40wwV'
    'D0FqA9ORw+CC069mKFqCuEtyDoskkey8/KBSsbkgHYVnKgnQmJng/gofU4FiqLmU3j3olG7aeCG3cuDH/x9j/a85XL8iP/HlA4de'
    'xqVbzLvgPa7OSjDPXp7Gz2lYvrjcLFBWu5P2KRXw85PUl+ljUx6u9y+nNuoqZyvimg2+wkL2Rb/t+aBh6G0oDflrnui0WL4v2+0r'
    'X4cvlzQuX5cUmVsIkzEYC7CpEvL14U8GhRXTxGTKt5gbJ9tTJ2OwCHz/DtwV25z3AKOqUmN1wA9bUOpwQUWowzy0kgqNA9wUFuxK'
    'xpcrsQpRzFGm6VV1oOqQjYaJQhRJR72rKzQwAj5LfjXSUlozfmqjhKMJb6QWBY8Q6qFBYyOWo0AXdVs7fvcVL/lGsd4fdU5YRa76'
    'jtxoy2VuBeRgbteGTSDs00qBC/hcyyehfMbt7FTqMbebeCF8nsp2J3qHDxmaAJJK9AaTxrgr6cUPba/2+/338+9naP+XS3uTC1oS'
    'RRBnY+mvySu7Xj/YaQoxDm9i67QLKtGy5Z8RedBovkjOWyBdYm5YmBHOyJhvN6SHu3R/8NR+pDfzh/oQfzDr8DOs+A2tfRLCfk2W'
    'PDLoZ+DG2x9GvyUKRLEdeCf8DE9eaBInRv0MuPXi+1XqcYTkNZFQBxYJAPf9RlQw/LWsaY5w/pZke/pGtFOm8C5GslHgqvI63W4U'
    'XIp/MmbdlwEe7vnV6slPWhhkywVoiGoCGZ94FqUQA0QQuMpPjFL/GBM5LJ/3ghTjbGAGWB4UdFS4w5W4GabASiJJN3iB/CRqBvjB'
    'JuphYbJabfhR5+XHivd+3P8wMgYM2pvEUasAGMBoi88JP23A0n6tHlJij16QjxhcvvGW+8GI5if9scTME3Yp/7RxfPutzSkiTAKm'
    'ARq+f1AooUuFFtyF3qAFIm0pDTLOQQBWAt9ERrSdpriTDAdIZr5vFMj5BnygwJ1klkCuZK32BFbKXZKhUUnOD7o6P+zoQNJCXh7O'
    'P2lGIcD3spz7Kn+o+uQHik4gGIYmHX8wGrrz/jf6LiMNvMfaCgbgfgwAlg0cV5UMo1DhIOhd6g5/cEi75LAEouXtdP+iNbgJc5vI'
    'CMgUBSlcvZCC18zA3xDw8oH2BQFv9mOlHo2xIhK6mW1to020x3jgpo/2FkTz+nOMuNMmK+SUJEcBO4VkviqFnj9WYw7sTtSZ1udL'
    'JFYEpbV/0exske3OmMERFs55GdqNgsKt+j8/Bxujg5MJAL05fo6FLvmqASTJncC40GsFIHxqSPiB2gAI3h418QJ0Jyvvy4Ow82sr'
    'Gaaff1grD9WmY8MEGUCBbCgRxxM7O//hk+vIjiRYHecIshn6bgWa4If5o4U7+DD7L77OGquJhnDktzl6MN14Xoo68G2qYeRtV240'
    'NurW0SrNTsCia85jaO7+kXZugJxj0qXF+PjX3quP4bajfX4MPNfxgUPm93zlrtfHsLQ31F/OZG/ICwT6McBjgv9WbB5GqKU3gW8q'
    'VX4M2wZRB0TSOrLD406C/Z9BdGkf0osEnguCKguFegcPqGuFUI/gMbRu1IwIqkz4n8Far+jhozXJZshPHUpG8H8to1rr9EgDa+8D'
    'Z2BAIK2A9gyBiy4xH/GR+5+/eccH71CDAoQJDPXhARWFY4NWLisB4SGKbcTXtQfC5Jl0ZsmMfvFBkuolHqiVEDhdmw9IHKnKE5w+'
    'F6aGwXNZCaMrUj4eZCeVSudTnfODLz3gjvZRACNC/1yo26sRqrZ60OF9WFvHbMbzRfv7oJbnGYd3PKDQlv25x/0FlTa0xDIQPBUc'
    'DALRyt/Dp60/qA/xgTyax214Gp4pLJStOMXjY4BzFI0Zb/X2hqdexAf2dz/0/Y9QCPKMz5FN8tjHdg/0tkk9A6a1HliJ/ZAyuYeW'
    'JBNDnyj4kgw2znZrXV6mk8iH0C8Ue6IpYqTTacxrIK9O8jvRQL3LQJYPYBLqXM3HXKb7/AecF0lXDdCPCDK8UOlvq8oYRgLvOGEU'
    'pFIwedyQ9rASuseMHIBauC0QF1GV0HV/cCbegD7LgyeRPBakamnPrMnUOiCPpbXDqF1YhfZYPscV6qFbzO2mN3TAm5xwr+05V5tJ'
    'aNXelJQwSMstkenbUqJYJMOOThdatv5Ck62Z2qB4qEksDxDA1UwDm0KiQpgVW+tPQZAyVVlldvPXkCB2QGCseaeghcPOzJktHza+'
    'KRwKTiGZEtlGSZ8tr7ZWuVHkhLD9DH+tLrXGF6fabdCP/MhX6OsDHBfUjvzA5Vb2/9j0Qk3cfQB+LP9Q8lvZYdOX19Zt2uBjowYW'
    'jLQanyfJypMdHlC3sOl8usaxvz9tiOqJo4MatIYEJ8ElpqyoTYB+lKMyMXXReXaNZXiDSmE0SC078vHHZLyYhr9wiMO/IOs2INkg'
    'rU/6KOi8XKGXCRRq+oEtCdD1J0lDhSKCR4G7o/23ZgnBH3yvBA5BKslDVy6M/ij1IYke6ePYhxtOyQD51EyidB9/+K2sb0DrQHi8'
    '8GZ74Uysx/vQ+dqPz/NO1S/Lv2Vo/xf80iKJFoWkAmZex7RAg9YnoRw85doNH1H5zFh7ZLQblC4RdNM6W+xPVkcxOJgjwjl6QEcP'
    '6ZDNBztL7421Lg3ESKkP42bycY0DkxdU60XnZhA+hkq06wdNnLdriP4TcufKiRqhw9qplmXhttt/OAyVZ6Ai3dCSugyj8mmk+FBQ'
    '9x0Im9NluA0UHx6Bveh0i0rCJErRV8Njg8MZdjOCnhELmsk/4I7AH4kCvtcLBc56BD7oZb3oUrUxUfAxrFojRbIb2PMz9Q2v5x4c'
    'GZjG1fP2Yrw0M7WhUqSxJwWubddBunpFd2bXdpVZj5qrcwg7YQ5rLidhTNtIMRyEJJNOVlt8eATQ2e7Tm0igNDgIRlLBdbm1Rg+x'
    '1gYqaWKytLzivDoynvK6YCYEgpd5dic/2BZm2jZBrR/wgB6SIFWMT5S4fMy4nZuUVW5Did0cOLR1BjKs1rDRH74kB8JlG10zdmT8'
    'szWxVFXcaE2SI0H5VJisJpmEMvG+C1cYA/FKXXCEwuLMKbrDwppfXgN9f/SFmuz3H05Qar/rgKAqA2Qovjce6LP4qFUcvauK0pAL'
    'kKGCikKO/cw5fgDA6T5QMBN2FnPWnz1h6yWf1q7b2aNo7yraKnA7j3E3zjWYfTB2fNBcpFh9cY8dqdj5AHZ0TVY2Z3ukGZ8GeRu7'
    '49i5U72RFxvSg21PGwxvbFChvI+SNwlkshtRRCIMQBRjn4dMKgWN2IcihIY6g8K0xrrGChNQ2MwD6A+jRBaS10ChUF5pUxv20oN/'
    '6ZToRhjIq2iI09j7qCRv/HBQtRvQ902V7I15BAEDAPHDeC9fGHZWAtsYEvXWgpIFs4IQmM1qqBS/P0wiAFdR4H7VCvLHi772UaI4'
    'Cm6Ao1eXgQ3+HzRVHw+x9lptODOhPuigkWZqTWlLRRrwGymSYTPweKBFZx4s1k1rZCPvbuJCTbWQUrTV2I0Cp/4Yeb0NoZvE52gB'
    'LR8UbEEiozHl6SOpAbZjhE/ZPcOOQTwZTdkk5YK6Uol2yuYDQMc1SY4CXkKpSK7C3uYKpHtVF+Hd+QXOO3olyU1HV5AzjJfCuLR2'
    'DYlDKU4YTnJZGl4VwhIEnhA0Xrb3zDSOk2Ux0M2M0SJO624/hpquSnbik7ghzYh5wpSCtHFRclrXTGmTgi6g339pwkI3AY2TvOjs'
    'H+jx4vuzIe9pwpeU/T/8lTpHQ99p7Vz33rkueF1IpxEmlnLwIQSl88KbZ4pwhvwVqM+WIAuza66KiMi75FzTos+gDXKZ0NAmdN2X'
    'tOIkGbSZaeXsbkMmoUmsKiDBVdhtzFeGolYlba4efkk797aJBQIgfyTMUVE7nqBgV8iAuWp06du9wXZCG7YsSclQsZU7rlsUQTQZ'
    'P5KN79OENc88e2zRnH7DJ5PdRv4sQM+S60eI1p9BVz2C6oJRMV+o9g2KVTYDbwZEtwJmF09jISis6rB2iqKMhWFvNS+/0O6m/c7y'
    '2qBMSBOfuF4+SWfZABXdcdUXQDC8PBrk64flyKx2ej+dwqjBAgw4aMr2z9bVFH+E6xeLGk7Ho+T9vjQaJlmUope1P5HJokjSMFNo'
    'Kh1MwbB/kF56uC8JBfJm4n45J7pwhzbfEC2Y+VQms/RpzUUzmg2ojaZhixzqH+FdyF6hKX1comsgVk2QeSZjMKbJlMFfrKtqkYpJ'
    'odMExlCLtMGa6VrB7PaC2VqILbB2HINUE8VNzR8xLd+MrE9QR5m2G/NbvPWtZl54UCi0h4NALw8d05l66xZoTmWZntPF4dGaMaeD'
    'ogWJGf+T4totUagumDAfb6k+ecPYlflZ5GzHybWN3Oh4p2A8N2frjYFOHqSYnFboVelT/eIP9Ut8pl/iIz0JWzsTer/vkvJyZ9vQ'
    'z5kRK8ZqpzEb923grcFIPeGkjvy+xzU/FrB+jRZofqAUH2Kk5KyeCFW4k34Im504NA76mnzPjPdxh/K2F5jiaCNUSD2wZT4y5sw3'
    'VBGGh9EitRQKSieVmCnJE4Uo+o40o192aig8aRVXaLOzohEXh3XmjcdbA2r0FuqMEzDQpz09lU40lFDDsSAaRr4l9oiA5Z90v0Dq'
    'OlOgsZt65tx9aZDLyd36JjLlwXaAwzAO6rHNT8VNhIXMjw4jsyYU0iPsGE+mPtAFG4d0GR9yAXtW7VKQbfCuPFNuIQfanVeE+8ys'
    'gU9MUAmq0Q2yTmRefCDzMjNz/nekmxeqy6CaKhYOPoHy+D8OQhuwmQLAIX+ImkWqPinkgcgnwtqgYRr3Hhm6mbktUs0cxK6no/H/'
    'XK3TevGuJaCLiYhjO0cL6t+w6LVR4IfQuqR8MWKKWAegdSWpIkvgEjYlCFsNErUOHP01eQx85c1Y8KfGZj/bkl1OdQ8+WBaEDdpL'
    'YqR0XSZhpr3OWs13pG7qpQr+suMy27tfCi+s7s6LmBzSms9PnWiChnWd0o0WPrT+bLubFsLC7/2fZrPkT/PeSj+O04FIAgbHvX5N'
    '3iiQrAa+skJsFHSDHlzWsJkwCu26ddywpmHhiSo8Z3ZinuBsFVqrKOSLd/qYMaNBcaeZL3nI0BVqQ+pkDKZor6HFwfQjsgj3ZJCv'
    'Pfz0oN2McdyNWXfJUbD/i/0Iiyp1k8cTkNccQZC+UlBUMSxvmAnwMzJxHL5kfhsnFIEuKYrRI4vsz+ILlkUu+XZjJz7fdpUsEN7e'
    'bXepagxmhOGP7o04UJy/G1qBiSwkGdPTS2ZsiIMmTlzm2acmL1lzxdmdubxe2F3WM95G3j2ANZ9viry5GpA4bdw8CnDpYFib8kGt'
    'ddZed+At8UAa0NkOPflixvX13wYFPrUuM6fsacB2JUY98QHk24CCmx8UjDj7qeYHZwt4KsqCw+gXnUUPsIsnBb9GBqFbxsChac4q'
    'lbnqVrPHAiLV7jaHx+hUILO68DnvcQ0mzDxmNf35eTzufDYiuAxtfZpnF+Wj54MprtFlXIJUSU5SQBWnBnqcic6lcKJZKAsEBS+8'
    'K/Y7s6sZ76LaCrfAn4aZURWiLvEuePh2CoaAj5GCT/wY9cQPdqnygZcR5CBIAipeIvN8SsYpCobRyBw8orwc8ouwX8MHn1iWzMrJ'
    'drpJLIAB9vKpFpnHgFDKjlJBvvwuZLl8Mxi0rIQiaUvXm7cCeesW334hNMJAcOnDQvzR8p4gvkBXDflc/5JumNgc7C2iow0G8Yo4'
    'Lq2MFt7icSnaadzYZ8CKiOW4XilnyVESXRbOUuLDPmLS975KQqP3poOlXZ5hjyOcWeiOxPnR49ZeGMc0sXN2IAloO48Hx9A4kmQ5'
    'WnuBLhewEFIAs+lgv7NJ6upHyKy+UDWuiNBd5Lqa5dh4JqGRFozG06BElEAfzbr0aVEQDToOGSdePVCWjidjKQ6jhBfUEn2kwkoc'
    'Stk/ZKeWAydcQKPert4D1t5A8BYrew0A3QhOk8LCZma+5s8IqDsm1Qz4Gy+l4zfpAPHGoEKEz9eMz+5XqhtEFNdv19hADsD5SstL'
    'n+qBqFPN/jOMuY0gPtB1Js27y2d93iUx6ck1Hd3EXioNeK1fdX57t8hf9NuhOrXdxKMnPqcFn+ppCKentR43qGOIiYzguSeDvWkS'
    'HTuPVLCYfLZ2/58sAcd4Op/COHROxPKpgyavPhU163Nc5vVf+xvaP76crm141X7DgdnnRkYs3h/BPDmwnl8gQd+J2Hqridj1WMoQ'
    'lmgXzXjpQaHgsCpnENE1LCNuha7RBQvrGcEK1TZkOHmD35ykLb40RDDjMOkbDegqidhHnOO+4lvmxuhGn929YqQGMZeBuOLEU7S9'
    'MBRDBnB2peGCexhXJoMHwgC+fLGZbZh1PyMqVYODEUycie8EDiccgWiafHutM0NHU3vtCBApujaUwxK42H6Wt9lHE5yUwTIh0G83'
    'U/1ScNSgL774ivxv3XOq+F5OthuUEOp74ETOadg7z8GY4WAf5TiU6KEVFztGec9YoAiiuD7YmbEOeu44VHBD6piV0NNqqP90EBYl'
    'dkIy/s55YaEgXSmYnplB8FFIbZIY54dJGJ0i2OqzKOnUCJBYsLCh3YGAOFDQcLp3/5w/YjbNtFBJmtluNjwBh5429gfJ5c/XTvys'
    'aeCD+eGpfQ1zkRwEesI/fLYP1gQs79uEj0HIVhFfpyjSi1D++XvVOqgSPrBMbtW3GUEVEirzE9m7DBTXWTgqgfxUDZh5V8uA83hJ'
    'ih1Skx5IvcuC7i8FXddGqDCVTzQog2VgnBTIRRaSL6sD6Xz/osy85VS29W2g94kPYbmn9i48fkFnheXFuJ0ppHnaDNQ1F3Q/WXen'
    'B+I5GqWYd72k2bAJWxUIoggXVriF8+ANt2Mvc6Q+U4xSU9roc57uM/3Tz84MZV3CxrShmuw1vXBJ7dea2I9ZoVNN0oZFwPZ6Xel7'
    'XTNLw4olS8KdBAFt6BcJRuOqBwBaAtU0kurRk4adUaXt/3F1ZWvK8uryvO8SJSq/QFgJaNtXv1PDG/x2P22qMg9kHtm12WX1+jiU'
    'ZdZRtRNQe3aCf8i4QiXiRoElXLXrmo6X3CNRQEmpqzXdhXcTUKTR+yxzrWneFVPOcSzsBlG8Em4tansOuncSue1LVrtUTpM60uQK'
    'BunpYk6nPbM8y/6skGy6Rfyk4xevJ48Abf2+pibjHk1cE+ZPpDDQIGuKVTUc76wS0JgruzV/JSk4C1Njp2KR6M+ukrtuHFI08r+D'
    'Fs46fK23pOhVTXyBOeQ1Ar3j9fHEYoqzN0qHXVlgV7WwHvLwUH3x6fxQEIOP35Lyj6R+y74ljnu4FI6EIV0R9UWpjBCgK8IB7+L9'
    'twvWsxdsypb4YETLoMaRWDqpZrJYLthPA2S8y0UZtlwORrZ18yVKleMFom2zmS5X1iGMR0mts8UKsCRMITe8D4UVUSPSuLPGAjBx'
    'y10tgspoUV+ksAfjt9YXt0A8cUpIBsXGXaGiD4xKbpEBhYvxUz8RwLxZ1F6Vp4L2TC5C5anasjxD7marPFlbYcNPE/HyMJ/ybByV'
    'ZFGIsgKg7AjYdzO23EQq6GOXFtl76mTwN6CkioU5y9ugeuE+I4oOIrVqwphf9CFRqVt1o6BZV5prMJOwS7c5YbrgGUAm+K5yR5Rb'
    'uz4IptSGI9huMqmOKfunGLCRWoxrOqI08+J4oWh9VMTRwrqoWifQf5g+IZdLGzJT/TrfUOfDUH/cHcNFJMoyTBn1Frhnp8GTAv1W'
    'v6pynyORjlXVFlVCG0sctX3WkDHTi4ydWfOeAq1V87STScPmkpopvRuyDKz93XTV3RVg9SyjGKMPEtWXTr4JpRdnU8hvN+E+yVCe'
    '5CZk8G1nC72zrO8u67vLekNX6o1FN09UAWIOV3D3aJdFGMzdLwaRrdal9JHQf9Jo5JTIkqX6pl+yb4vmRaCPt+ONewZIdQpuuxiE'
    '/uCNvayEpTaHt0y/BDlCm0wYtYK7oxdfY3dy783fN9FJwQ1pQHdV3ExEC9Er/f1wP3t/pUnJ/nKwVGcfmJMk8u3jBXvT+KVhUdXa'
    'wR2OC3ehLX0X2jK8cYIAiCAjVr9u2ojp57zhFWyROM1K6kar4LAO/frlDN7CDvbnAjc+6qV8brPb4E+m0Jp7VXGfLFUm1N+hocPf'
    '8QZefpbrFZXLp5NKdjCy1+vskewVj1UoUa9X3GUrhud7kWrXEZejNd+ut1Yls7OGgb8c6fsCl2uUp6vuhlzat2gidmNBEEXNSqhA'
    'dt8aFGrOFKixUmDkvcPMiK19piovJ0eWlkzKlq9hTKJcVNPVyPuBY19gNM2T5l/P2Il2HIOo2yweFhxKqu+KzE49vJm1oMHWVQwn'
    'ZQgleZ5GOqsL2DPRyrONjzDtxiLBgIx0a1SK4SlnQxEqOJhHo5heMj51oO98TYDgW4I6R870vVVC1nNkuXRCvx0tnINcv5l9uLJV'
    'MLGFTOiB2sMbXUZgFlHYT89759z8lb6o/cMdTy3zOGKOB7/BeLCMCssnmL18pRFj7DR+YDM9KSgPpifdTk/npkRFBzDtznPs0yQo'
    'oTwkbghog7eBlWNiUYN4fWgapfN08o/oZKN84bSxC4/OglFA0Lgk1SDrHlAyXCzdq3coCOjYToExnR3wmeGdPwc7XSZDZ8+Twhyn'
    'ygUh5RIOKCpHAgMpUoPlepxclKZwcw4wT8VAvRxFD6yNGzvjl/SLkUFsY0omiPCyPdACM/FXHNIQjEJFXYTJhPt+ARK8jLXo9kCA'
    '1jA6k55dGXHdC04xNNN/IJO2o5utQaqJ+gaketEZvF4nozw+58V0w6WALVk8hATScgtRRYOoEPPiR4UvCsvaOo+4JVBX7IMi2ko1'
    'Xu83sjkR3zuJ3Wshn/6fXGksLqcmiXZ4UnUtMsve5HrbzKqHvyqYVCgyTImHqkFkWEUSpwcojoJiqEKBkgFnl1n4cI03xWQYhT4j'
    'RE4ok9wrkz3jPUREzrqTqA3ArShCGfhElw387a3JC25v42rhkireRtBMY6ojL7pov7TqheagcAwdjCYgeTkVS55KcFl8qPDWxztj'
    'CIantpGQNV/8ojb41vLpwjqn4p5wek3b6j4LpZA0qRJMilM6zAiIb8sceVYbtQ++f/KktfOps9zZIW1ZwHvDIlJtpdgnxSDDykkn'
    'vWqD9FPd7oSknty0p0Dreu/cRx506jQM+Aa/oLkzBfb6WKdnRhc/MfmUd7im/7n24MqHB7djgeTRkIwRZFNFpkn0GLa4rH6iXQJN'
    'rFd35Uq8kifC8oHudF7M9BJQp5wN46ZcXiuz6HCzoMrSwYLP/hh2s66BVkA64FzD0r4j+8Z4fBxdEuAxEi3FViUQrMRAvCA1QK75'
    'ep1Oelg51obEsVeDtGLD70nxeU4+zP/KkIAYZk3jOJCyH0So6VeMpXEaPUM1jfJUVcI06kxsI1XiwSP6jb3l4BvbSYm8nHWZUOe1'
    'sR77vLaLHZfUA2GQGiFooWfytbnnu8SdVVM2XdNjYlpi7I7tlB+fZe4SdCQabyNyuvHM85MqbeR9/TNZkfzsbEyzx98TIz5zfgrA'
    'qM6commgPg0bhmnmxkYglXjXBZAXSInwUcBOu+qnE7YK3AI9BC5DV7LukwINqLpsSCdmCkMxMOAzlwlVf0JcV3brdMId0JzdePkr'
    'JS4ZnVpZ81hgTDziMIVJ8fqPpMs6QUMEJgXuilt4sr6JrZMyxvc6JXJyl5fv4XgmeLhoeW5isVq0E1pEiQHT6JFM6oYQ+LlA/MHW'
    'kc0rz9Qv7GNrhWvi9C/vmpoDZaIIKN6ZmJ46j5t0cILXw2kzfeGVL8sQ2VEg+eskrC5VwI+zhiqjvmrPZZDJznlKhYxZCOM1v1Yi'
    'CXtYE6emIVpyNbI3MjFvtu4Ksy67IhMeLCFIwlK46h43EeVDsEhO3nRuhF2UozJcmU7EKnJolmxqkUA8i5ZaplIYRoBm30hpkLmm'
    'ifpejagPNFU8XLo6vatf/FRFgfVxz1uevHaJzTzUj+AtaukW5KXwVdx4hBvYF75jphJcRx5CIsGwVyGseg9NrvoeP7LWAJTRHClX'
    'b34a4qS0f9euT1DM+02ud2p/LqdxX8Kz4PzP0FG5pCob1r46FVS9rKluOmndWElbikQqhwJKj6vUqkLUwrHxE7feiw25VtPtDnHX'
    'stG94ZB8glotoGLfMznOhZP4fXFQ2mJweZ26cQ1STey9ykPduZDKdWbFY/fDyKRH3d13tiwsS5/qBw838bGTf2Q2+o9C/VLhGhkv'
    'tmCtu/PWmmXy1aRBYGOXRlHl1joXN109h50K0Hm7mLxdFtDy/jJRfhWIX2Vy1uCt0ODXihf28UKAyex5Hm7rXfIFvws1dKdXQ37H'
    'HGMQkj+ZmHxgbsF9FQtnsrRjdvFWWSPSkZ2xJswSaWj0dDhIJajhNrE1H7QJiswDKpA1fH2CrfALtb5ev8XoW1ItUxBwhVED5uj8'
    'GN5PA0yp0s7MXDn2upMxWXPrHrxwUwRYNuO1mQBlJq5DNoG3UQVZyZJ0kswnCt6vIyYl6WpBNOOoEJWlyXfQSXAhOb6uNok1ZAEm'
    'DIEaTZkHY6WVdbZGSHfg6qoVMqE6geYMlCjTJmhX7uRDUr0BNDhV2XUkUCM5ULhshyIjrGER3qVlzsEEHoGzYUJljnVySc5Y8muC'
    'nOFtD0CKSz52xgj3SjHgmc9mBanBNplqwwOsdqGn7+XsRtfjiiOz5JtujwvqFCBXGQleugaDletn1iWv3xKZaZ0WfRRSGkffHiKN'
    '14TzQwcDwCEiyZ46VpGSq0rs6t2H2JUw3I/AJLIyQff2eZkO+9j66HJr57A1ycIdJ+3pmlJwf8yWyeE2fsT5T0lKUmY5nA3XIzIY'
    '6r4mKCdy0JU5X8bFxSaoiQZRJ7+xql1ymV88F9FHbu1u3vDTKnFmtwtiEijuOv5BrIRV4khwWRSh/mWiDrfJya/CNcCs/FcSNwc3'
    'cpdNzjZltElNuBxyF32Y1h1hDiwqS2VRxVNc3RbPmOc2OLvKqUZoDzuuBQp57BwX/aBNwFh9oiVebAqcqiEFkb889v8WxdQlT6tR'
    'nA00T0d2JeHeE2+P1NudfLvSBberCgbb5ObfIGNnsqT8VPbv+rjsUQWXXXVwiWvkSBfboeE6oNvehp+Pa37j/iHwfAh48XVnVRQx'
    'VVLU1ueHm/WJ+6GBL8LMOFQuZxOMePI7iBygsFNgaoBqfomghVhRfSfSjwkVphtF5k0nQMwckoRFN0/79FJDSBLmX1ZhqHZlL9WD'
    'qAUZwkY4gM4sbDuVdjW2++7GdmcEDzZMh5uhQ0OlrAx8cGzToCbG8mAeO7yrz0Q1yhFb+cDk1Orm+mATfRTFsiH74SZMniNKA2dD'
    'mliT1rIb3bFl9mR0gjXPsXeZV4hBGQLF4eV69SVhpOiK6JWiIlIqviYaUijeNPvWJ3tbDS5+uJsyq+j9PXCW4GdpCQOD7b85fKCh'
    '5FlriEiZ4/os3jEoSvcOFPEmoJZpIIMUoaBpFEJIq1CWR9SUEC3FXVoLdt9DkJ3b3qqiA7r3N3bNG+EM5vvZqTjkrPrPeEVJ4uzL'
    'WSnxGhbfWIr2DpJNDoD0shxSVhqWhNM4yxlEoZ59hUpntVNnKl6xOQplZ1mUkMvyVYUcuJR28cb/Jfb5NzJyPQR3D0Nk5xkwca40'
    'mA6KfUnpVt+oe6zeTWhCo2iGD3YcjsJZHQJ9J+kqDCyYQgSmmJXRereSUsU+G0gwBXOU5SgGubgcMro9qI3LKPHuDD9A1bj4OCs9'
    'UpnwVxSZaqdzaMPTSmdwDkFAY4+Cc09BqISK9/CcL5AtpgkNcJMRgZVFsNBjw05WPibU4kTeUcnpgAv8Wd7NZIJTUjpUIbAJOsJv'
    'F8uVR1+s5PTDISs75uaqCSsqMVtptY6CvEcebISu2nr4uMdelWA0u8sV7qc7/PD0cvz98VsBmtWm8hlq7O/+XBOvx2xEq42fxNVJ'
    'wCrgotVHl3gSlyFQRx0WbEv4SJmHKxpUWysTznIuH95z3iA64GKMYqcI7Mfdcj22IkBsSDj1+EHt+8H6l08QhgS2mqePVv4a+80U'
    'GKhfBrX5tf60XuY64L4HiIgREDrDvf2mmQKk04tCktiCRtwhx8hyxW70lQ8kr7rPbOVaDkWM/teBh/XWAX5i+3ETebMqLvhccZVX'
    'Ex5cxmsEl6MJ4MQ206XWSccRoiAtPYJCt+CD+UBqk9FGK5x37NBsDS4lDG7R7LOIwuTHHoK90snsDNrzIFJqXRmB3VLL1FkYYkqA'
    'UOFTH4qa2XBS6GPJpYms6ho+dKSuMXyfmiHsQ/0MJHC4NfKYYVq5xYLiZNmUhB+DlG2YscLlHli7EJvEJr7gsUZy+DWMIMhwJ9+/'
    'eT0lrMFP2efkf0yrkCi9+isbcf5mjS8QyY8VHrlyFAXmKKef5H89wJLKn6OEw5gXWL0lytg14Apu7zJAudW8SKdDhW0dXhKnO7sw'
    'YvbwpTdo4MjrpYi/XnCDAn9Nrfna7KXBq1D1h1clQLh8CAgXQIqYOAEyhRJbiJW3RFXapOYuxd2Kl8JbjhvRhOzaumC1am4heDBt'
    'MPni9UsiPyWbvnRo+UmBgb0+eeVjEBp8SsR9yg0Lz9yaVJPJBNXZSm2YFRkN6JACFZSE3pegBp6E0UvqiYGsFKUPrduganXlYwMN'
    '4sslP5wWBF7f+S6j8VSR2/d4kjHofjKG4h6PMTaa9bh0Z+NJa6d2N8dT01/8NJQZ6NYhoUjbfOdmxRNOF+qKcJP/t6R2mTwS76pH'
    'Odm33ePb+BHmk/Wt92gNP+LfGgeFhTcnrbjgengIKefS3JoQelzNn/GcUaNYiz4JvNiwq1EgqZ7xIUOrhdelk8RKsFPlpa9L5Gcg'
    'c6mozzYCWKEq6U5BbwyuPJXQxJfafmwlxiXbDHcfQJ4UZmlh594CTPUMM84wBruKVd6UJWU8xbt8SB2dg1+yiffZZloLtixBPzVM'
    'hRI6ECZ7V2odDfNVsGEXqgLgwnZEGTt21ppCrFeddDy5vqskLOukVSRv3Bi4ptcwwl9+iRcTqom6pZe0Rd2l000XP+p7YHq9sb8f'
    'r7+Sw4837h6VMd4Y2QlceEuuj/a+YfTrL/KOz8HWNb39dd/hNiWtF/8R8XVcJ5WyJzFBt2H7ZtTfmbRvTtKs6RcO/zKnwcu/n7XF'
    'eGq9i9LSY7pwYIRJ0NbhOKCCaqIJCF+DQhERaaBaVWuhAMxJk1D7SQGNcQP1qkzgwYgQcHRNkRJWBtOdVvg0CNbwf7SQTxHnSElu'
    '2Iq/+kYknkFbfSsSkacpfBu24DEVu8Etouv0xBKZVnVxrzMyJCCtzyzGnICVeHQqZQpn2Z6D2PSlOnHzMaltYbkeXiNHTHzPoUFB'
    'zcSeEqYgIOzsNprsD1ElaiOIjFQR640ftgEd29STbIiPO+ng6cqVHEK+p7UT1ivT36PVwwrD3wMfvaVgq3dadDMqulh/aQQ+QMTq'
    'vkgyKYJqqDaI/JAvmUcPSeAMDumwyyWWOoGZET+2kg1YYrF8s3K9pYm5okpkxY+VE/QwhPjCZLvsHgzreChMyDn5fmCcsGZWEFl1'
    'A08Is2wFo0OtsjBizwwQMviMOgtrFVdfm7jihg5GZvEOWLE9dTIGU3SWeKyaFH0D8vXK51ev6eTMtk2SF69N0qkm5xore6d44sYn'
    'mtbMpFyxCZCfi/W6I7c+Dn209Z9nRpu87+YA51R2I/miPYkKTctgPJUZ0lZZ4gSRLbUWINl/vAp39/TFiuWClUmdnxBWClh6WXlh'
    'CVb42++WZ2ijSw4/ZgM2G3Q2mjI9iiICYHbCYjtF3g0qpuxAtnbCWg+ctz+oooWUrwGKpXDhnXwg5EsmlxgPTnUC2KnIcJcxUp5i'
    '64RnIPY/YuH4MsPp/bwrkBLm0n1w0dH7bQ1RgWRmoT1dlH7KR3tyRZ532Ui845SW1HERqr3IfIVFEH6JfkxHow3bBc2Pm0jr9jGE'
    'EQOTw925vOdW1zMxY4dlZ/KRBYYbdBq8Ww+qL1uvWQOU1gZC4MuHRgaFzAb9DiJNw6UXfgOF0vJcS+GZwXqx2OPkEz8rzzURWDxe'
    '2uDciGs/VPrJQIN8xmPF8wMQrpiCDkJzWWKrK3B+9wevHLTfwGXFRh6J0f1FyH6VGp7PFPKLgk0G1RqgNMvNE6tfKVoPNYa4nYbl'
    '0ARKaPKO79ejLKN1sVI7DfYJlPPLhQLtKGEO39G39ttSxCpROezAFlqOIIPhQ4MrvkvrnjJ4CNTKqyYaQgceYEGI4ijQtQGkNFhY'
    'khrI8+LR7bH/8NA1swDI0pmjj+a9CdzngL4xLuRIP/knD0/8KoUHVily+xwZC+eZe0TzsGvbIK8Z421iEJtwwV0R7fvkC84x4BOY'
    '7Z20qOMdMgqYS8OGSBqjOlaVAYgLEG7iYXIDdUEQg85YarssrGBQ11koYtwjBuw3UZ60K2PrIWkyjEabUAhFZhnFWpWxq6CVAdt1'
    'dUzQPX3R8Yt/GQkf9thXcUpesv4K1RdLDm5v+zVDbwvdqXwpreMCU1CtVzTHxjEIA0sWZlT5Bqd2anGR00FlLZrAoPvJTgMOfufV'
    'krCmsPAx7066mSBKj5q4pamRFkUmI+ah55PQOI7tXD/BbIxMgdrLwUwlIvdI7Yk4A81VNYEzmi/NEJEFrbI15KvRRho5NGkI5oXi'
    'fHlNCtJr8heP7/eKdL1e9WxzkFZ5nPTLAPwwrWC4WWQn2fACp9hBlZkhE45BqgljARa+gr1o/tg4T2u2d1LNdtswlaeW2MwkD0FK'
    'VzKxyx+HoFV5FLu02G7RDfQnrebdJBRwvoli68njiRs0Thlf+roPrYlqoMqn4Z2HPVgotSSjqwAh+nLA1rnGD8k9tioXfWzsbIJQ'
    '27jbZ4wyT1O1XvfKFYMg0KAbmGBpffqWYGh/W3OY05hgkMD594zDCI/hLtqa/onP9/g2AkHTuv1gq337DY8RoAQRVhGr8wuLlE7C'
    'CBMMrKbAEsRm9O2DIQE4a0bRTpdwRqssZAScmwFOChyHvcZqYsR21yDyg7Tr7vZiwqMjJkyu262mnfDgRXxgmwMEdey6okhru95q'
    'y3dcvpPvzdAd93TnsrUAtvbrMbWM8Wi/acYP8UNfNGN0g1cq2XAGaer/TZc3ei+tx5nbgLb9mrnnPDz4+dEszqOOJZIViggAKg92'
    'aQDXwgv283yHJVQxvKU068LRPC9H6xjnGfMMbUyVcZ9QExPuVcHQikL9yT4NFTvDsq9kMyIGsaUz425gCKzuFj9slZfWTWvCtLVu'
    'MvMTeOF5G/J6dUPeXBBedd8iRlK4UZLeYVwKActZmZr0clUdsHLbQAPc6Vg6oU4L4Yrzwz8YCu0Q9YhGY/ylwgMmKFRNOG7cbZn1'
    'Onn2o+R5/QwQ8HryT27m8FkltBEShAqRod7aP65iZAWEJecmsOHmW+Ttm4CtFJBOmy7bMlYShHnzi38gFh/Dm4TTgo2UQSIbjc2N'
    '/hYtPglqqa239Vtv6IMxeCnORJi+whlULybQfOAKepxn6vTaqc+P/COltlugTTvSjVSorYhgrxslyFqYLVFkSfZOpKQd0MEigUP2'
    'Ia/JMAoVbZA9BVE4+GB5oIzzCfNTU+kQlN+EEiWGblIQroHQQLCV7lrVAWJfdZDQo0f9Gxy6nwkprs3vnATATrV7MlSg7PUP5o8U'
    'n8gnWnK54IfiCJEO4fm7MbCS8KmBn0zlkZ0QQgo5TI2JtlnLeLNDji0OOXY4kHAjpNhHSOmk6706C0UuGJkG2eV6t1EofjCrl8nV'
    '0yw608cteZkNF2pC7sijiAQWqtonr5F0p4QxozR1MnZWgi2dnBaWavb37ezfv87+9a9EWepk7Cw8UdUBSuNKSg1rCHRTZKqdduYw'
    'TGoThdS886tOuo0mCAuL+dzpnk42nrR2qiCKM9NNd+URhohvZwGT4oAX4ilCsugBglxWXecfhIFafbM/NjXyEwIGZnswaGA5GTMs'
    'rbPzK7INOM8u7kqkfP5y6542k03Ciw7xGKAPmndaO2V8giP9aqXlmtjitFLPirXhTSfzgobprx3lktGfikG9QD5wRFt5UWDGHvJR'
    'EM6bfkT5LdWuNmmWeNE7WOTXB95M5CKP5F96d3REpi8J6xpIJnnKDoRQV9JZYit92wll2+Oj5ALPWlKVpBWfx+dLoWJTRDiNrUlf'
    'eq2rOqWTK16F92dl39rCR7ELkatCf2RshrFz+Z559pZcU/ykmNTXNkxvsyTwUYRMV/fnsXFXSmssd1wEmvF58boK7iDnNkgImMjM'
    'R/u/YC9D5i60lkPVRThaGI7m98Ea6VD9hf42RwOYGpk5fvQJEVw23H58HauTSnZMsw6CUFLq3gmVsEBFxFQ3kNt1SD6AUbm4EZxl'
    'Wa+WZIn2e2SXCYjyyZ1PTbxNu4EO3vjIXBC5Q2pHgttwfgPxIBJ6No2V/MakTDAae3AHZxAq2TW8FyaQT3zgi/gRpt0g6aQY6HEH'
    'k9AJJ9kwC2UGc7NGmf3YaJ89a3zLSmEgTW36WIVVjXAMwhpANIidLMwumEOFOCmXNPLi5VGNVsWo4q1AY+mkBhN5TkVhqVvGiSWy'
    'gmNaYDErS16SLi+SRM9BdH6awsMQje3adtvYK9JCHVrh/AlG028suHfSlLAPBUKCyEvLgB+Iru9eCO0riRYKWPQzSvXipZSTMyiQ'
    'Yf41SFfka89iHHSRYWmKDHsnGacXrlRYkgk+KgjfRyPLw95JNQvjHlmAttw7hnPgoTFOUhwP2cEFhItKX5Pd7Pgt5CwgJl9q4RoK'
    'ydoZCk6nChuvO7bhB+4IGjvtyswQIqWTU6mbO0z+yx87w0dERdYgW+AWFnG5KHFSlP0uhCjKlsmXWrf6CaaFYLBt+KiV5wsWuhK9'
    '8zBe/LkKWiyZxYURoXvMqZPRTBbYSAurSQod58TKzZxkD15+dFI7Jkn41kb5yeZ7JForpTJGrmNt4sV9ZEmiWJ6y7upe4oPISZ5O'
    'DLJ2VoOFxf1RHGayf5RtLb7KnnsguRAapAZbOzmNreHia0ry5/1I83IyGyUPsyGZlVU0BsWMF3dz5hd6N+/0oxTGnde48/7HoX+3'
    'mgFBfzMUfGvV76wKcKFNYzKLOqX18n6HmTebmrSOzC9c/eVzkwI9LZt/p9F9sl9Wuk3UPpP8+7nTDkBF2JSmWz/jj7cEZSy+NzFL'
    'glZ0+9mG9t9qr40nYDduPWvi4yNxRCdm13UyVPi6agbj/9Y3DJR3krSYk3wMCOam63E2XPoNAQ2SkW495f9TdrHfWiBNvT+1+UHj'
    'jQ8abwNscAUf4GfSQBna0Q+bmNF8oQYoxlGbwnBPl/wh4mAZ5ww3h+rOYNwzhXGoQmo98Brghppnw87ejTt7NwwwNy7abSpAAOzA'
    'M84fMi6VB7GaFOIM7xe3/i7Rbu4MJVEW97ClG6M2PKcMAfT5KPjOCMWsrz37S8/c60qksoRVwZvpx8zLaalhl2famJk2uB9BYSJT'
    'HhB9JVFrjoOxFSKQTMfJl6EYmK/mRR4vlGyc+jH5iNjHbXCs5617vWHzJgO4xQZM3hkDYVKcK11RCs7Ysb/pioeR5KGIiSQa6rx2'
    'CRj8a+M6xGu9otoDFuaSFYfiSaiaZokz/Vj9XODGm6yaSMqkXVmgeFMbgJlizRvjjRsK5BlVlQbx3VfFg+VZX3pj0DcFugG7Pbs5'
    'KrbGVFI3XStoInewsE3PzOpJOdneZJzuJyYDlLFsx0IAPWa7oj0HIGMyjEYrKw4g1SbybNQziOC3m9wddHS1M7mBPZMsI40K5jGh'
    'BhOf09yJjsOGTNbnT3WgwLraFGznhwH7S52Ehb8I/9fN05QmZbIy8JilyOFQbsnYCqdjveGlUyUZ5/KC1GAKBEtwE2eDwnFNzlRg'
    'tME2m7g4acSoObK4AGQIzxUosGNmBlN5KLapeQwR6TptJgrJulNyaB0Um6kPwcQyA4KJX9Id2Y25sajuL67/ynORafWvQdLHQFfn'
    'aYh4mSrvhkyGWM00OIjM0iWPbpIw1haE3NPffF+cNRdQzV1p7WpdOlGESamLu4IDlXT0sdknMGRVid5ATU+pTmua2VWHuL+06TXG'
    'zXf3Gp1euxZ7yHC0S8kQvJ4S5aLg47fk25SjHzIFs8nm1EkYj9xt2kNx8FIAclsKK+F2HdZO6snQL6Ikwnr6r3EYqL1xFt3XZL+i'
    'Y/XFpSHxKKdrcAGq9cFLnbeBjZyuKTNKQVImVtxZ1plNBAoUQ82rGwf7IMrQ+86PzfcEG63F3bZBZOig+EZPcMMIEEKSyMxcd90X'
    'TbZIJxcDcwyucHDs2HE2jkFkFwGA69gKtvnWYKJbCXqKV4aHwK5QSJj5AEka3HIpouyKTgqTRoTO069HUpUm4iy9P24Tl1xPKhuY'
    '7bPxfMeWxi+eu06c3OoSJl3ntUvkV5aCROy1Q/5PqnH2yXHzlhszmm299qIEKxO7tA1Z1IkKjFhEizJWIEFTcLnINg+gGp1MWQvU'
    'ZlaDviuYOmtg0183vlrNRN9QFcCuRsmn/UTWQJlW0d1ddHd+RHZiD2aCA49toeLHXOEt03G+UNVA3Y7D/Y6DhelQYTpUXg6XFy7L'
    'b8OLej683Mg0qxi92E6PJ6ui3PMstiIwb/zoxlvuvlcKl5LVoLwZqTeF/fDQ4lcZEhH7uIPpNuHju4ZjgG+E9Q/bLLQ+DdsIvf2u'
    'SaLcMPuIsd9vEmoqqUlnPjfMoEJA8DmJumElauNVxU3k7rIN8yEQZolSkXvklbW/sHyCQeuiQF3U/8LQBuKTAr28uqYwmWqnwaQU'
    'r0aQTgyPiBYoT9mn81l05TVvG28UhriyaJioZPhmYSNcw0K/zGP1jp2GTqmvhgl4zJyFb7xlQO/J3pL6RMk9opQ2ClLbrFYosBgl'
    'lYSk90mAYYayV+u/MKBQu9/JoKGOSpqbGx9khlkXRPHSpt0gqcM7U/XFFGgAPb43z5Tlj7GOw31m8qVRp/XKp/I2Pym0pRCn2UBD'
    'o62NOsEmhqEXVkyK0pFsTycbO7VtcYWvjUZY/HGdLMU9vJ7UBpj4i6+0tMrN1UFfdUUrmMXP/OJTKpDQGtWr/eTurHKyrmnySoH8'
    'QAqFZ+o7o9mWyDpF0/gfvJMbeaMSYDRCmScdBFT/38FKmoqtE893XDMl16RAiIyd1WBKyXJV4IjKdI1u+6QiGvzTOeMfVI49JA4G'
    'Jb57+cDW18XUEHie4xPiaY9qE4e7Kqb2gn7yrTMgjt3w+0qelg21gAImCekN20mNdvPmHaWmsnKbxv50uzb3K8OZjSc99cO93PNe'
    '52Fo+fk+KfDFu4Hu9KKPxnMMdvhYUiBNPfD6SsOJQksAbkYjPxciv6Sh2YpR8DvmntU1brJZogqeiJJDhbNM/QYDSNZkR/rJti6x'
    'Rh4NrDpEhvmL2nVJaueqkMGt1lq2sEca9uoeYYj1SvDtkYqNg37M5nTpRurDoJScqtq12EJPhkV8G99ZMUW64Ll1uw/qEOx57c6/'
    'hjOdno+DNxJnSPBykwqUmCKC95qG1TlsSd9k7KwGc97i1i4Xw9jmRbobqjEc8aYv0H4Pw4ZTH02dxDvsSBnaHs9GJqMMNLvPga1H'
    '0cRuI6y9e7S3s2o2z6wGITnkqpiSgHxPJ3VQW8X2G2jHGvvSdF7RV66t6Y70qTiLGOWs+kWnoHYguMLQv31lxV407gfWPdBu8MI5'
    'O02+f1G75hfUTRn36qC5Hxws9JQs9TxAf8o+nc+d7uFECle/ZrRD7gBjmiRcl7ubt8mTT2edBUlXte3GIirHoK9NMgY7dSMfmtbO'
    'Xylq09g5DYqt2lOvZzBjG+nXRnqXwB44SOTrQaEqyV4O1CvC9NIknfaSpyB25OVszt9OwZkjXrsheweLdhkjV3912FJfT1dEbpoy'
    'S+FQQ9yCRoLLHkiqASeq78FPqmMV4gxoq03SelOfZ2ex1mRDirkGE/koWr5o7Vwx6RMTKI5ql/cSWQTsY3Mc0hFUuenqbJFD9vPL'
    'MNkdDWsSLuR8dKKUoQ2VnFbVcA24M+lNN7+DTonzSVRXHMe1OsETamLKJDurIGSFwz0gTDGkNra6pYm989uBbN+cuY+tN92au/ZR'
    'HkNi3xWXbY9cZOoUDVXjfr026Jequu08fMhnDYKG4i+wdZUwYAbJHWmiVfXXlpZpktXy6a6Aqv0gpzvIdQ9e0r49YsD0SDxdOXTG'
    'mKDpbkLL9fPGiUBIVqxKbgz8KUOGP6UfSjARRcAAUYRLJ51W8pmTVI14GgIMe9eRzievp8Remw/zv7L5y4kpfVv7S98S5oKQ0s7i'
    'r6AW/frz1baD4X6NxxeV8r0NkJkyoEw0EeboNlC6tpKsxuuR0yUR1gnfgWuOj1zxzjHDCZoL7WU+igTMEj3L3ykTJyQMa0jqF/+I'
    'N+HCMGpunTAaYbw4h+6PSSngG/+DMEk/vgkqngAgcrbJuudcU8iaxoTdzxvnhHT3NgG1xaS5h8nLmr6QGzjLGMPUupUCTdlNfp3Q'
    'pHaC7dZfHCE+ZSr5UzxSuGFKdkoXvOGs++Qo8mGkTWffcbwEt1p2ggNlWiCaUpGNwkVioB0tfukEtMgIXaKA2maCsTsuGhI8eNer'
    'OFFTLEI3TpLQp7tnXhqhY6Q711txDTaE1ru8taoIx9y3SekoL+Z762YHspfQadcmUVywqInlLxmcuU9KJPSRowm0hS0xAkkpYgIQ'
    'ouxyyDgtHGESIEUEWf1OnDCbdLMbkbbX6xOnFYLQCk2nYZNLZtRR2NYnBXbGp3Xl1uogNLbKizBONXrGEOaVsyFCGcm6KmxTAz+h'
    'OpvYzk+aPmEFNv3vYE06aekD95fr02uMN3lUNxXmPjT6hBxQhUgRWOf887Q7PXYtxANvnIeevOukkaRQEZn7cCy5iRMFTcWh3zcK'
    'aJbvxQA1AcFePV5XgaD20B386N03ZKeCgTp0cH1j/7EJMvGH5Z0fXB/ehoywC7abpB/fK05QPgfDXcVBZrFKmGSUTs+8ulZAZWki'
    '90BEysx6pJqo4j5rF8HMTQAoFGKvdDJb2CXa6d1eMk3wusPGl9gojgJppN0g6VOizTztCm4hBoRdB9aZz0RGJMpRTIqEB7iA1TjZ'
    'jOuGTq1sP3b7ob7hHKvis+ZB8VSFDNaFaV9tPrqrZrLLswvEgx4ySHuSOBxCZiaQ2YmxK4l2zU2YSMlBwaV7Qt0HCSqFzIlZkNWg'
    'EPBaQaPNs0sI8jJIXWHs+XXG47AK1+GhLXa/QVB0P4r/x1H+3PTkF6li9vGctVjkr4/j8lmcIqifZsyE89p9iskooyJ0KXEKf+as'
    '9Ry9MBOGx7SeyraHlogwGu1CeBFP6pmfhObGezKMRirzSAbQVQMYFXa+BgR2lMEwC3E5BwmOIk7WzOcZH8oJv5NzAu+5EdBfV094'
    'pgnxZCWla6AFlPtCkkYypTuFStEmdu/zmfmIrUA6LyYmPyc3qm3eqQnkDkkQHH7b1HjNB/oqEGn4cLdkPiQo2Q4PKxqhFVTpnE5u'
    'AtvMGcf6KdJ7H98HkaZcWZLUNolW3GyFelr6E0p/HaNwkjocq3xdHb41wqep5tkf7fAVTNvMz4Ajck3cNWprBHekYwaUOc3Z+6Nb'
    'eLcWO8QJE1PZgDeG4G6XTF8cPlDCrNGs5Etu3d58HR64g7yCPimgniPwxo2TVnOh3zze8oh+ZR5xT8Ran190As98+ZOEmmmhADfo'
    'j9ZYs1ZYSZDxs3zxo/VbnkKkj0SkSfZWsxw7zLI6DZlXbwtko2rQTGKTYmGajTYZkGtzOr+4aadtgzlzESA/C58IFGGknlBW7s3s'
    'iXHnBm77YuR4l+WmzmVLj2sycAsJ2BQ6dGc6T4HwRvuHgTGZOTdAmD8mqgBB5d0UiWkWBj1g6LRbIkFEZtri60ObV3oBtIRwVhGm'
    'B3uVePdAjV+2N1kvtDa2Dy+kkpQ/92ExYY3RCOe+gThldLJMGleEgG+TIE+jovXZ+LXmD3ZEror0B5vlmU0WThMREP4F84PM8yjY'
    'TdCl/GR0BoFvfSxY5RdUGc9RxHMv1mS2M/L8NvMqLijbUKz2VmMx16uUc7ySseR0JWb5BCsZ8UVXM3tzT2aHE4dGICQDGhvetM+Z'
    'qcaYlogF+ryZfd68IQswXbgRefN1/MCPxJqkfqjjl705Tqi0EPVROkvn0Ni79S9t93PAuW9AZO+EX0XUxpRyrNt09hEo8Tbhxv4t'
    'O53Ro85OaexJR2XKLSi4/p4tFMhddtlRxU34/HhFs7RCu6A6oqj/1fCGMkam6JR+/7u5CONf9gXNPrpWJ5e+nNCOPpNqJpuS1REb'
    'r8lcdeO87N2hPlofmh/XwkhxpQj7Pi0bJJReqRMGs64fXoSw4fAcI1J9i0awrqYkFpXLpt0EcyGWHSbXNsEnuxLPYW5xRM+EKjsF'
    'NrtZK+UNrqpSNLOe1cXNuv24Mznor1T76ijWfGaHVMyKigfusnt2Us26DxundUzGzjTiycqbVXONwSKMhzvOpuGf2u7sTUs59iqx'
    'UsO1uwIeNgRjNgHIEHP/nhZOF5tQQwHS+cMUKpxADMbk5UsODdR24FTEQFxYyTA6Ox7XBNJBp+fOy6VbjccAHBrHEqtQ0Wv9tGdK'
    'W0UPCk8SqLESqWJyZpUGj8FtfLRg06MFDbRlkJsas6aHfNPo5lNpG2+o0tKSKPa482wE8D0ODwKj+o56+N3r4bd2XRFpIbHhess8'
    '1k7nTmYZKC7fZmuXER7DzvRsHaJWu7ZOF9pNZmzz+WRwULxrI3hmNRhDSlpTJ2EuJvGLRtKt6uA0hJBO2FbY4aMiQl90Rok9WR2C'
    'NXzF6LdosIvLgvMLKY0ZD/rJtzCBf6hoWFsVDb6KBl8EJmLxMKx4dIUsX7BByEBLJKWTamYLw6KETLhTWx3ikqx09ZW9pO5IdMoh'
    'UJfJUBpT4BgEBSdYNxXEgcBWhVyCSfPBdTyUnybpwZg2fdik+3XWb8n+Dx+/JOGNPhtx/phFrHg7j0mYbwMyBWscHL6RlzD/y6sk'
    'ut7IzkmqQIxYTVq6bLp67zF5R2do8m6yOzddeyqP05y+NKoap07HL15P7ihZ0q3znkenoiX7N1cyjXFZ5BcfvyX0SBd1NHIb5KA2'
    'egCLISIp+jFNa5gvS+SSW+LFQ2bhsLPvDUsCDbxXoySMRNRPN/8EYwCQlzQwL2miof/aR5anYuNJqT9Py+TH904ZHY18suhmTbDz'
    'LXjIJsV2mRzYxblucS3RCBqfhnntHwJ91zt36paUL2X4eyQO175lCvnXnU//yE7NSbHBVSKOP44AhI3gtUuyIoaN+YFjkDDlD3Du'
    '3W2cHe7IPOobuJhuhxRL9t3eX5wGtHGaaJfr5cP3NxUuXBZ6SScbT3rqh01eLOrYdYmMRc6qLnDAyIP1XDb4koQ9Z3CwafmyHZ6m'
    'KBtg3wbsQNy5ZknqZOysdNbthOuT8hhwDOJMXaeoU8XYCQlJNT3dkcmVLQxbVV/nsvk1R13fYuPVObrVXf4+u6NwLFFeK2dliGHt'
    'WM70J3+lzg9niXrgcplI+z0+jMYFwtSZHQatJjWMR4W998185HErBGXlfHOA8t89UMZ3l1HuVt7NbHgnHNTHTreq1vTFlSOhAgrm'
    'gL50gg9kjpjFgLexL7TVMyPFHbdBlXSv+JavaPleZ/wkyCW3+6rLcM+1vrGrMa4kFi8lllg01E6/4rwVmUW1htNj4o6LHCp0a6Ew'
    'SGRenJaoIcnmUBMmiS/mz1aBoq6RmkdIjXFbvuvRJiujcrNWuQhydHV8gCdJJwtF5dfG+JhRZ+HKpPN8oqmTrjSnk0nxbqVdohJJ'
    '81oljlCWmOAqmuDSsAkiR03Y0LZpu5tenRPIiepNIsWTWwVrVRyOYQebkvk17IYUaDsvHxARCyXlp+nVKzTS+o/G3ylrGfqeTjae'
    'lHb/ksRRIDVFN+N3GWK8Sc70IrGK/ckXadCd7Mqbt3MHDtGVpwz+5NYwK3OYWVFuXJP7mWR20LQbNKkdU2fdhofanXYT/Iz57OXh'
    'QsNJJueBBULEoQANR+dh6THvErmBlwl8RxCkEUGNxUjsyOjojdNd6dLIlCsrBPF/qBK8SYRqg4ljkNJJDRYk/DzYZyM6+Ka181c6'
    'qT88JDRwo8A1wIZO95sLq8h4MgX5dn6M2/kxTBXzLvmy4SDd+oe6nR+KVxay0DaqLIlrXgRfGZayru+gTTq7Sxbhmhw9XE17/XS6'
    'y6qG2CaqQsUdXLy5FiR8blSf73Y4cQ4PS8CcCKwfHafGqXtftfWm+DCqkPWtmMOsB1tJ/B3uvfE3PVW7nfMD3OOSty+u8IXsy/qL'
    '04wlP6aL0plEfpHaA3F5EFyTkKf8SyLf/9NAIvsGYjNt1jCX6//1kVHulxGbk+AyAGK+MSIz7ofntDvOcd50ReAXH78l9Uti/0KW'
    'v11woGddcVAw6X4PPM2GpIZMnmFbGZtns2qqDIlRpNrGoLXz/WT6Sh54EMcgNh/fm0+GFxnPEpUCS3bsQUonNViQcCdHxOKRTtBt'
    'N9ipLZzaur1tj9oadD8c981xiJFm7kPr3GtO1TGRcKtnvYKdivZqBe2uqKLKN14m1JmN5htDlLlXrWBKHw+73AeXYtHItZA5kKT2'
    'YFNUN173J6IZWlGpPdI1SJ3sRqOhtgcqI4HJgcdn5jRWl/yqQsAmFTcKfQK9U9WkIdFnPmUOpeQOSp9vBw8IZ6q6UtnzDzkmH3LM'
    'POQ+7ZC/5hzy12Q5JK45SdJJw+JmtXjKIXgkJbiyg+mpLMN7VJZ8Ixf4NV7M/4wXHRFuYP9iY6dhyVx2NldO2sytYJ8bu80dLvJg'
    'JdAtAqg/XvVslojeLrJMK4+Fd8GFmV5V1f2sjVpy3TO/1e4Q7r363M+g7meVaTrV/V9Z7VLFiCEqJ3M4uqSesk6jCdojAXZ1Ookm'
    '02idaQ20QvYtCuAROlz/9U1r52d8ao9vPeMbEcoSr06keLpJnO9igWJG2I4U106+WzxYDRY+lN58H6NEFS6lnqYAcDfYqCyAy7sC'
    'U5AqItCAjTgGcWX3msKVaeymHZDX1A1FSwGmMVZQt9uWhSHbj3iIhb3aawjxf4zbhZoDrZKv/buIOzXMnUL5mQLHILb/DG+ycsDb'
    'Oeo9S7T277QonCRy9hdjTrK/7FeyNnw5Jc/hCRUiLRzqrmL4PwSuncDXDy5aeax8e6PJ5Pff8Df+TYmLPuUvXT71L2nNufK2mqp7'
    'aWrrovGClJqQPyC2xOLtxVvN2OvRmuSJDz1slXdK8F0kceO5fbjLkCohaZHYscGBVd7RvDou+KndOTiJdlwmijONABBFEX2ok4dB'
    '+hGsK8pNHFQ1wUhXiI9oVk5WgzLZDl3cRKB5EOl4K5Mfet4OnEvi+p4Y51HxvDMEWsU9L3dipYgA3bHs8QJBe3o88GmPVrzxXQ6e'
    'bMLbH5ueeyZ8DJUoF+eZa3oH91Uc8+IFkGPeKKDPS6BuZY0oDAWOQsTkYIzHG5OOvK+ysQ9XbVVt9MBMMDc+ed8TH6zedGze7zsD'
    '1WiAYCH2kJE43iVqL1fvEDcZOws7/gArX1dsqG+6xiddfViPxEbjuZuTyoBK+iEdBGTDTBpE6G88x3NwN8SBo6lMDJGxs3Ky2mln'
    'CgDjw7c0ALTBtuIo0SlrLEkcBXTh67zWESdxQD4Guz7JMFcihaw5Ra1HK3PWUs9ROJ0EUOoV7ZIAKpJABdddpka4b5CYgrCAFlmx'
    'sYhyPTT/LraLWK4wNFSSNWLsdqc9kDqHJiwPTUgDPmjlmY8YAX98f/r48HpJt+GujSskKRAm4ei+YqiKe0FvgzscXcL8AYnTulV3'
    '8Ieh2nkzyOGN1QenZ/Vw9OaHo4nUfbdAvj1f+Vbb9/Zs0TsGNO8+UHhH+/g+W67PkHB/u7Ale9/p9Zl11uSTr63qZyYVTVLlzcIm'
    'tIju8cYjRJ82DEd8hDBU0m/z5H8//zva/zC2LlNzhGy6pi0o9jegsmuyx54e3DXxgAyTkQ1Qawpo4+thpX9kXbPFXuwTiEQjZW9a'
    'TJoLpSttrPtk2NVqW2I7eseNpFXHDQt24ZDg/nGjPAezp6DfvIrQpbJLTIYSaFd8QNB0/gTzxpJ/ZDWkQfZwdpLRytjhvtoGr+4y'
    'HIVSuqQrIK0SOcFOJigSGQjsc6CYDAhuQi0tkLxMRu256my1y0wD1FwU9T1FOFP1Jfl0iVyscczwi38Z4kA7JOswldMxqxMYbSQK'
    'Vg8oJrlPJud9LEmkGBlknEj6CB2hiXaTHtMGsyg3k74YL/+yhuwzLad5l0iHWmn9CAU43QKslDI6U2GunGiNX3raiz3edQHZ/1jf'
    'QXQQVLc08lJQXs5oU88N0y+v5Wnk74+9LjHqZRjNk3JLltN8ErcB+T5ItMRfNO+9dGaGMys0nFoBPCjCj/LT2oQyXC6TxN1QiS1L'
    'NGiJDDFB7ZoojBQXvkVZeFKkoCc0E1ir4dDNQDm9GfiOfcEtm0WXahZfmtkQp7oOhGSUlZFDB5GVPo7clm5s35BsT4FjEFtS1MRa'
    'inQm7as9uWqAYmpXeU8BSJbIadDOpHVI5aDsD+sZradehsTOvxF6t50C6gcgRATrnn5037VuuG6iJQr1HUqP9mO6c1hGQAJNMwUp'
    'zTI/6f5LkBkFHKTkYexEehJxk5SRCuxV4VJdCpf8Jo4lb9Re+Zps8XnuwoM8EOlITT/epkRgLDkLGPuThJLzM0wVjzAV3CdXeJlc'
    'a4N4/TXWUyc6pO8wa897Ixs0kd7LBdcikjjiInBkwS5NNIE3WF64C60h3jQU0JCEx4BzjT+4AhkbDB4SFfqVm+KI8qKRJQziaAJI'
    'xodYx6ygiVQxhFP2+I1XfVfe1CaoP35NpPjmaW7YgiAjT+pUFROiXKhyGvfcNHhNNL3pZD0YfNuYX5qINpNkFsrwJN+3jQKd3XYK'
    '6N0aq4mdFaMzNHN2sMj1xaJvBWaj8LAoGHCnqsQBrBjlrbq41fsxf5g164OCAlv1OeqD1X3ry/wUlXqV9P1Bgd7t/Ab72VGRhCH0'
    'I54kH4NCvAdkidfYZlW+gaHfY4mo9KqEJZpb6gSjUG6yknipsL9c3F8u8C/J0mxcJSrVebF7A7RAAkvvBCYQiilC8lmwcb3hOhxE'
    'GP2jq3/Mp3/Hkl0tBW1Gmn5zOw2Xmnndgvb1xba+4mvA+lY+kF2itfeuzFQywag1eDV7JRGEBkh1OjKyywGSikGaWOzXhDm/uqfO'
    'gf8d1SEg/VZWRdYkuB/FGGblCB1tg3ju6yrYNw+BtVjyQ+kidlaNAxENNBk7pmIfode6xVPgGMSm/8JNRW2Wwwt1Ja5r+u1ObRTk'
    'yqbU2ezCxnvXgqh5tETmqRn8fgxFzNaL66ZzS2ankYKl101pqApPdf/wpPFpqjuLonJO+w9ETndkvKaFz6iLlz3odA/L4SX3CwUZ'
    'g9m9Yznow5uXuQeRMVKbe2POr6SLKgz0t68DcZY4K8HFDhmZCRMeVW6YCw1wKaEhZ3+A0zwGyq8LO5RAeXk85eWhXk5CDmq13RUP'
    'kjOhr2xaCQw4iI3yFQfgultr250KfHTB22FjN2zf7hoPURuryCsFjkFKkDASthUyzVVqx6xSqF/4ZWo3N5Xrq3KDt0CI2B62wmiv'
    'rN0Wq6Ils2kI6thSohJ25QtawgjKFN1b8mSQTdcJaOIVpKevMg+6dvVm8oG7H+nmMwfIoWdkXTBa4KYMo8z0bRjgU5jH89/VpUWS'
    'LzaetHb6ZTGcC94N/X27+PfFxpOehsPFaTbY2KRshYNdrNDNrDvH3t9viSwsS1JNE3Ts/Iv11PiSnvbHb0sRQkpsZuNOPFDcFvjF'
    'xk6n0wtK7QpGnLUOEcSQ7iHNeFn3m4eTknVn9F7MSb98ozys9Ydlv2SnSUlVQnIZDamTYhLeFifAEaUdLDQPlxW+d0Ti0ptfPTyv'
    'MwovNaIkzPQl9UiYqjxZQsMlq0xwwekaX7ocbEmJ8gjMHoG6wSCnfRfVvbUfnK4Ddx+M7CPkQjxYliiDxyKgSzimK8cPv63YqROW'
    '9b9fkDVxuPsLssF3Mwf9KNZ6Dfb0KK4aP1dmO/BxHDhWasQNC4icGPUNx5GdsVYFp8XgUgoqO43YTlqiLg0qR7oEoWounh8WuwDK'
    'dDkY+y6xc10qJ12tjXlWfEc8qZU6Gc1Ca5fhw4VyzPak2JnYtdMotulS77gGjMYqtMFeBvqeLtBWDWBKJSgCQPuJmT7dIDwpSPms'
    'g9Q79mWpOAEQ3U8sw2ol6Iv/q8OgtQ6VTkbolMB5SEAHAwKVbcxq0JFZI6iVCzO4jw+cpwd8eAAjIjbpAKtPaslv7MwTRqNLT9Aw'
    'VdTDvEV7cvMUEg8mmLj2vvW6m+xLUwl4+6rCb1iMEqSQs1W8zQc18IwtncL1AIKoOHwUwqR0Us3sMS+WaFjY2/+ITmugXOhTCY0m'
    'fkGiNVN9fGlqhtGSSK7g8mq66+X1ziPIlrFuuR3s8QI60or6dDdeMkdMBivblEvC7ehdkNtxdkFuKjq3w5/i2G3NH+SuNLhHEtw1'
    'iZLu9PSu/vl9cAMBEvbK6E7MfVATcW+jS3Rf70lFCgsDrhyDjie3M5Yw3Hcl4n3CU+IkS4A1/DBkUPpqu9F03B1xrAozN4jI66n2'
    '9lQ8TJahdBahgYTxKGk34OhZZ3NoVuPu4ksuD0uK8hFtzj3ONgf9+9Kfu3I1UfL58GewrnlajUD3A9Dmyur3o9zPLupDu0BPaVm1'
    'ObLxNsBSfiOT+40iATCBk9pISGKyTEYagZfTgmcLpUVzNra24sd6zOxL0d/2S0aHwl05u3L3kK1ph1Bnp6Kt7D2riSqW/6lW+i/c'
    '+a/XSf/1KkmbJRvmiaEljkFCx7YyYwhQe2tmU2vYc0T+O15+Z6qkedhYloldoZrIvL/83K3sNrB3fYX5/N5meNfhWxJar9QJs9ns'
    'M0lgvxJPN3/t628YCF9l80NVXjFjHE1sTh8V4EoiqLxOL/eGyfZOpDvFLmVxlql5Chuc7JhxNwRAHk9sqRsoksAxiM15DDlPrjBE'
    'arBDbP3foZY7aNiy4qnAQDtRPXadOa2d/EQezstd9wg16X4yxVSCnFxUEwOUoZaok5feKi2unfFijrXK0+CEMv2YdlPhAI6iE8vE'
    '2T9Smm69NpkGqSLWiCDy4vVObBr0W7+axfRPa4FHQ+qkdFLN7MSkAVfDqXf2T4m0YvhuJsXdsCvvLb1nsqxKeSINcRQUoeuSLy0V'
    'uiVrUEN0Pu5cKZzLftfsaeL2YcEaZrmyB3KsHW34iLC84sPxaU2jtaxuK87Cy7GeI43voaUaQLyZDPNO5DUGhnFbiFgV/r2U8yP5'
    '19aKs+1d01ui3ExvudFPwHZue5bws3ibQZAxWBh9nQbfATLVWqF5ULD3nxKNvdNs3a3j0KtGjLHoupf091PcfnwdFcVxUI+R8hZj'
    'pPO57ZJQXfopPREZ4St1hGJIIe8GGJB+xPT7hGlwfiQ+SiTidnbTPNnG+jTezGhM874AGVPLuyWnuQizHqjDkTjV31B257A7z+Fq'
    'dPi3UFijYtoidbeekpvTEHu181Rkao/JH13SZxyDRPh1L5+IXfOVeWahmNYYFeHusHB6sspkRz4SbWllBcmtRAKZJpFRXakiYku8'
    '7oSHdJOBltCr8TvblFVH4Ptw7L/S+o/8lf6f9Es7fKhnksYBWdGO3WQ9zdXwOhovnixcx5OlLx72pu7tpP7bVrJWTUSsmWPtRFT9'
    '2c6ViJSFu7xlj8Qj7H6uqtPaabd0jra/Dk5Rkm/CV7jw6pZeMaLads2veYtmkGH9olr9CFntXMzL78HGTu3Z0dfeG7+vURaOu5sK'
    '70kUCXNzdSzEFNRzGx4kMQLYzsHY9jUY2w6HSkHSXhfjqSLHvCsFRGWQOAZxgeu8mwwSrkxVk9BiDogXuepVTTMxdSarOh9AciQD'
    'jSReAxeE5c20krKfXaOfXXs/u/Z+dj1H/lxxcfp33jW6qp1a+CaPWbi67j9f5Q5E2fosfv2g+knlSulNUedT/VcvJOmnn2LvR9fP'
    'k+timU1F1ehVJ9jjAHs6Wf3pR9m/T7KfB9n7OXaSI/SOFCgjHIkBehxiWCbCDFr7EK1OMlN3Q6T6VN019QMDImGpRg++RsrkWdlY'
    'RL7kOeb6gtroKwWOQULHPuQofmQMh2r4GjV87bV5dW1e+9xgjRMzpMUOgTgTkNPO5pwJPEcYliqr9VEmmV0wnbtpexcHXU56GpGH'
    'U+8YdH5qaGReNxXPyjvejOlkShDe62ZfszrIIDV10pXOC7H+Ufic0rnbcujpxT5EamNQHaVlHw6vB0bWiFQ5kyTSA1PnEd1ImJ55'
    'zsGf6Brq+UyjPZcUOJqE256r609sB/3Wr53tJ7PidN07CetT/5TiDkWZztpJEseFKgeXUQFOl8bkIC6jknPHbLOcv6rHYgNLsnKY'
    '65PuFUsBEQRe1S1g7brHZiowG1AakLATuve02J0SuxefWx/araHZ2Gl4N/f9ZzhpNhpSELtLJxKnkPfeo9x9iUPBST1lmnjtMph9'
    'BKcTbaAg0E48sCMFSqEkw2hcwukSJuy9qoo9qordFcTubYAkNlq0TSSONZl9aToexftAeHEeA1LUDSfaZu99k8r4ueCxF09FiIzB'
    'wkqWeD97fvvXAWTKVKdIdvhrH2U1dLltH4Vf77jwkx+rLOIIQgqEjRd+GmO8YowBIldeSQPP1zm75E1AxGK9k7EGeyVb0s6NhkdH'
    'aZRLzAN3Pn5JwnPL7C+ynUgYditK1pX2TiZHq8T2AKw7pkCHpIahmgLHIDZiF3sYI3xT8xW7UcHeBpmZ9FaLGF3RqvrLS+qvWET3'
    'qbIgMqpR/0uVzMtTSa/Y8+A+hU6FAVn9ALo8DPYmOKg2PIXMzffrq31+uX1+RftMUjrpZoLYq94pfqu2eEdt8e61xduLAu/CGZmf'
    '8hguY14+OP3Fl8OyJpkePMMqQF//kQ7ehtEZ+vmiGePxB5eqIF7wJiMYjgHTVTy3hdmMR0YH7MEn5xssl4zDB6WZShIp2R+Lgb6J'
    '4Ft0ilw0tf8LftyI1gDxJlQgBI0/OGOM12ggMFmE3DA0qZ88qY9M2In04vrQPjkcq2Oz6LcuhDSRKdBV/kYk6YTDYT+806ZoawBE'
    'tbiT5nh4MlIXlVKkxDWxyRiMH06Uk0KdMpD6rhP9vcH2bbY4CmADW4onbiWetGt40gXYhVd1F9/ULZQfZo53k7F7AdLtzV2PAWlI'
    'KRPi7v2kINJFboIIMwt+DBjd8r4x3myjbX3aoNvEN9cVW8PJ4K0qr9h2iddpIVBd1wDwGVrp74pEZog2/BIF1s+4SQdB2pgDts0J'
    'jLaN9cPEzT3YmiyxEijKZH1SoFv1GWo08ITDlZ7jgQe4tlPgaIEAPdYtEOnGyxU9iKpEso+QUoYFVTE3/gazVoAy3EsOYG0MonxI'
    'TqFWRUCDE+JN0CfUZm+IdMFEStzNkLGVOmv+Mg/qJWUM+zOLWEanImv3YPaewcyJNIhSdW80X/BjmQUUAyNNFvgh2k760S09ENEO'
    'EGogPmO+yAX02/l4C+/zkWgD1D8YKpZzeo6qKmuKEXBjK/rNqyS09VQwPRHZUDIEFfaZdhoZcOt4hpybuLP2cOd7/ntwV23GLZ4U'
    'q2AncDUjP5SoMIaizGvA8Xjyj99SJpSfeE+58GLtkrnjPOsJSaOVDay980Jdbg9tIAdWBn3d78j4nApqAn3KN2cR3D9RcL17ExYK'
    '3CCe8YAVrqVAdwORyBJkmd8IRY83T+O+Awr8uChpTbjo7B7o+hyW7Uaa58FoPYrykcFpQ5ANk2FfNIm/DIORpuEhArbLby1UZq9S'
    '5liijKMwBUddit4mIKyCMrIc7NwAQMBuj3zgx1qVjxdQVE1DVoSoBYGqUcEIdAp7XC752EWTlWTTA0zf3FN0Z27hBd8UabjaTK08'
    '0mCnGEnNaWXtL+B1ulT9/SnaEua9XzjCkd9YV8pvGFDPCS8qlAzFD2osiEnA6QoQDWnJZE7efvCmQ2Az0P5+ynHBjyX5UOk/XOYP'
    'l3UgCoHwQ8I8oH1JR0goQBsbW6kjAvURseBmsSbM4kp1E5mi92PsVzjGPLe8h2J5aIri8EPXBUe4UbaElYRe3tTIAhV4/lBhQtQ7'
    'd40ynGp28dxEOZBtD40UD48ODz0jCoRI5+U4i/qhmuhQBO2bj7EgD7ZuGG6sb6hk8szcEbNxR18eOpZF62LHghYZYsjoFi5hFlC6'
    '2Z0PlugwTDFluToQj1Ub3g56w+dxBNR35BinjQH0uZEjdiYfcYCERMa5X6pJWmXDbH4wR2hZwtWFj/rqWgSKqB+B648vSYg7EvoV'
    'CSQynSHuFGSiNdYHvWMleThPVZ3OANq3PS//JWkh0nACdcWB4yQ39gMbVZVpwhy0692WcjCr/bXAfYY/+EyAlNnxk/DTg4/l88x4'
    'wqX+tFqzDq2JrcMFzWj70qAXnGNpmIrEFlAizF9QyLWbuInF4o41hi8Kk1f80B/mgV9wThGY7HQU/Zi/H54u8tEiAMoIkLbwxQic'
    'D+gskyaJo4FFkVQaOHvzxcaT1k6R+uS8FzAYdwdQws8IJh/bIH1aeRgQslZAGoDDbXbRBcnyIqg7kYkGwLE2seucmdjgo5HutY/b'
    'RMdobI3OB9/qlijoFEVn6YsrPpZUUjp1Y1huSUoM0A0jjQa31kAD8fHvPsIlRn0myz1dWFjAZqnSEB4FwweaEISJTBHR/FWNw4Ag'
    'uRgkpchvipUsAdWg9IQCnJuZtNjZvl4HMnbpSBAOpinuVYRYJS78ZHjDhHtqTlqDT1cyZalZeXpuXWKDXI7bJRt9Yo9CfpDLx9mh'
    'mPkpZ6YJLsoAZAY848pjEimuNJ8lo78ta7VOBQg/zrzrUVcwmt0/T+kfu0QHLJaaSJNhFCrVZ9xkr1Q4I/FKEunDX8ukLHZIuSVR'
    'cG5b8iBxJdS0E18svXylT0CzW6XjiwGPn8rjNbZam34UsvXq4Ih0fR1vEGe24w0ejO9KM+NloD4z9epdwGBvDMGDyL2R1qhNO63/'
    'u9otUGo4m6+TU3WdeqquSBd+LrxBB3Ea7pkE4obfAy+iCuXQ9uDtZMpkevcECKe3opsWwGiG2a80NytrYJyuhViVW7FScB9M8P3L'
    'FfczCW1XzPmuXLPEZQisQfautCucqCImfqEy8gG1IOEYJTJ6VwEpmKmhCmsAvK1WdRSyhRg/OoeHCFmoGQnOF38z6kw0OLHi1swu'
    'kbMwYqyZ9qnGuc4uybxz90saEuUxsWoWes50uB9ZJaSxcfh0QvMf5OuDLUUTN0aG14cCYPZI5VkGFkI2TdjSU+Ty4frxiBpRBfIl'
    '1VfUli8+2sfS9bLB17Cu/O6vQfWeqx2W0hcD+8KmNxqRDXn5coX6mlih4q5kYX0wS76knNUuvrJD+lKK4UKpj+sd1Fzv8WCSv5V4'
    'bxl+L9wn3ggS4w32i3D98ov8qi77xQNClanpdP44aEhX1NbX4ULhwubKhHoXiphhpLEbtnt3QsdalhgkvnECHWyUKEmSuB6WFqNg'
    'kxgufSAum0T1aLC5AALecTJmuQVq0qqN1zR88/UfiYytdm+1dyg0ECf5y77WddjSndcVnJS2cT1TYAGRIIOFd0KTTHKlSF0+lhtF'
    'HGQBcquoolMwGQPc6HgJC8VBVGpxSbvh/rDyzvZHKBt7ZHVRGMeLgFMmSRKRs668FEYXX1CkfS/IV5zMo9PY6nEVMioP9Uwa4ko5'
    'pG6rww9+XZFKpgkJsCUZilEGltAvFwx8RGVmWpY0Xw7cbQ4ZqtLrY251M+r8P0rSh4A3h2hlwV3yDddmiu6vidOtFTeODR1rJ9iC'
    'C75KvGCEQoq+AIEv2AX9mDGNQPzCkCS+2kUSzoqIWn+1XqWcF52RFMbl+MzSb+SJ4x+NvgeJLU1WsdVY8PBKc+Fu6SmbBn0oIuxP'
    'XI0xVhEebw+KeiQY9VECvH25yQofDwPTxcX1OrfaCJAK92iZTdVM/qti0GkQopzDu1kyCuYg5oyvgHkhiO3DLMwJuWCZ7noyWivq'
    'LZDYTeZIVZxXvgcGCD25tFpz5SjFhGU0F5f/vFNgdsv7jaORRliP5J1v84HQ9V1md0xNVByuG3GPUGfV9N0V36FYJCo4vOwLuEu0'
    'qpM+H/LsTWGWKCNvlytMx9Qrbv74EDnaDzKSbRKTwYqy3ojsK9ZEm9g1HhQL0wwEQIYSeqGELrdJnkYHMuMCbCKtYSKtMvGWaP13'
    'aCti08URIhl/4nkNb3kSHCWdjHr5drhVwBTeLDwY2OMi8SLXcDMfYO2RPDb5eKirDNIdM2W+KfhMOEJ70vHk4VhITisgvjSwEU4c'
    'NZxV+g9dvULCpT8wHo4WUVSPRQl+sCE5imwUXfEI9qLCTmGnB5/9YWB+JrZP01xpymnA75LZ3Kfhyqn6RjBVXbEIXbUEXb0AXbn8'
    '3ESO2AiqSZ0TANKgKe4DNVIBu9K8EW386TvSROy+GFJNlxAAaETCg2UepxhGYV4NmuMQnU1kn3cHVGwQqNodUL01oHJfAESmVbr4'
    'WsOq0/HVp+NrnI6v/Vx6Z6xE9T7TKBL6WC8U6PWJ4MG6Ev3Lfum34mDt9SPcDbgF/IszycTDYAocg9Sw4IAXbeHtLNzAorbYHI7l'
    '7iwN0SHdRM622JsejExrsy9t2UT25VYrXErMdjjxRQHBaJTHvBaR6BDjzkLHVdcXtjaH2W7kiIUwf0zUWQflqlfli15Kn/H+xmVh'
    'jeiUGohjMPpG6sYw+7n/PSdwbp4VFqGTaTwmnQoHjQohjR+c5hieKEzQouWkFbXKc6oQYTIpaulJgY4nXpEHDD3KFgpyabHOEgUj'
    'LfPkCCeWNBY6u0NhVwFL7iimu2N+1xx35fEwNEk4BAYB4WadllSdJV4HAJAD05++GxEaMy4rqjxta6C1OEda+znczmpQJiW2lx90'
    '4UaBDarQUZunu6oZTOxwAISZ3cob7KpW56oX5mr0NxN2SXC8lrzMde5erUmV05LkGHEIsnZW8XWWiULrBV3pXdDaufNzk/DgxEw+'
    '4rBPEMdjmW4z7pkDm330TZJjtRMqRXzGK1B9suSnvUiOUfZwRgKE7RWPrAlY2ogT3SOFI6yJdKSk+hxJTap41oSOGA+V0MokN7Uf'
    'EUSO+rUYMdqTOqnviu1MLgVXpWCpzCeJLiBrP63T+dp1BLFBssaBABOrKD5+27Sz7sjkl0DAWzyMkh8K7E5BHWaTsTO6skflYWZ7'
    '5nY+pPOXzLbXNHcyp1NRjKHBcRRFjgdTTjJ2Nn86rcEU/X7EJSgbgKA0zO532qiOaSYM8XharHqQR/DUV+dWxxWCICyz/+O0IWFI'
    'Iko6bokvw8kU+JAofJL54viQ0l3a5Ku4gP8ShhsYIA6GlYhYFI5lCUyTgqdISG4UVDuVG83eE4f4JlZKL87VpKLqogGt3zlx1sbQ'
    'V4E03UqUKep8MuewwmlkAqUMtC1syjRFZ3cY5G26a4kP/Hg+WBmVSKri9RfcDCAFpczBir4cr6EcP9z6LodfESNmfW5+9/tt3gHP'
    '/e/XFOgcRm7NUHAu1nZ54q4qB+Y06ZzqjPmsHz77S3vRH/IxP04+86ErilSgsLNp1HyFT1wbpT0nw2h0cQsapkpgKBjl4GvgbNmH'
    'X/bFapIPm32z3XonVhN9bLAPkWtZwjlUlM+xh9EwGsMEQ+gLVUTCNYZhkv6kVuylxvSNnzrhHA81kXlFg6KESb30i1+iACu/rj1/'
    'VYP9HlEJ/R4O7d9PbZYfuI2TvUEy6IAQ8HEfPAlLqAR62RCjT0I1ygrF2y4RcXnwYsoGtMbx6APzpI/hSSFJXAXVwOvGyO3fM0uk'
    'gZlaaO0fXrERqsA9uBzzwBj0wVwJ8cbdxCdVRBcu4AcJtdnOLL3heeBeR1Y3j4EhdWYAORRAZooHx9MPDacB4dSWZmtL6ljhiWLc'
    '7dmooltksaQHZkiKOK0UWymbRKVY0U41s27ENjd/2LLJ97JFCpWtDZXyHuYsodZu1ZgzfMRE4YNz2Q9NZj94qyDAnnoaGw8BQJgl'
    'UgXTxw9O5WkBJPgnqGb4zGUEPqXhRhElkUCPE69iBLL6sqIHzg92px8s0E3cJLLzCII9eGSF4i6RNmb6xTyl85fEG9c2+nwliEwr'
    'kYg260RKs4O14sJO5vS0PqcJuLUIjp1of0nIyMrEIQzIjeEpMzaegSzWKMmI1Euefmp5kwtByKCoLR5sGx7cHiBQ8CeWzCZK+6Yp'
    'bRLnDFIbpTxiLiKljFhhGtaZki3XgxdJEvjBpjU0PS55cD64ifh1MpBRe6Pg6QYwXH7HdO68nhK7vqkhMJE+agIbVUkElkBrhH1J'
    '34XLp2TaoAr+0frGYyqcUm64S5wnVlxTkcH64MruY6K2cjC3Ygrs1Ut+64tqLyFR2twl2ICKicKiC9JBKc5YryRQylTnNDSKr0S7'
    'xenIB6ZPm4Bn1xmWoNJTjsqREpkpwfmThyZLH5wkfXCWBiIXwUCuOCt+l4k9rYGKD5hdLColwGo3mBEaOrth5sd7ipuEZhTygzkX'
    'ICdI0qlmH47IFGAMyLFLtNlIkEPOsgbLqsEazIaQy4ytvClI661QvCMM7x6Cd+CihHhLpEtsE3kDL2BjH/8hF3C710dYCe/RoKQC'
    'mz8mTixMfl4OFvzW+Xsa5NzkCQIyGuZaAcEuTmrgyoSFswbMPsWltuHToM8MFi6udjFSiuybhkGeJGkka77rwVnVh/bu0e/jLvFu'
    'bW0uB6P3h/bYCGmEDG56D52ILB0rBeU7fnd95cNN2NGbsCOaML/F0Aj23zwQJk2OPj5MnI+SutXWE/oPE3YcDz8cYLJDjeHOhDs+'
    'm8i6k1NHcc187bfMg6GXohvla1woD6IFIM5PNsG1HU+aUqTxEbMbrIRAMx1kB6yJ72F+mnyoMsvqmmgTbwQJ2cuduA3KNX5U7rgR'
    'GwLV7o9QqxT3n14ihQ65w3NvA3bOXeL0Ks+uzgakuUk1s8urriAVs56mrINJMRLDTIq2aNfD7cRgrryOmX3uLvnWYHUjmb3g2qow'
    'AhcIA1i7bQKpxqzC0URmeSuDgB60EsbB54R1Pz7ScFLafFJINPKk40+eV6gspGxalciz3GPTQZD9Rt7sIZLCyDJxfknInr0o7XPA'
    'OWkCiICroBQUyIoR1QLJ3s1rTAaqt5FEnXqkXc3pt2zyUhuHpkU3XgUZO6vBbI3HLzWd/iWhW3BHad/E0lF6V4+YGptxsUcj6PFA'
    'rAJqsl9PcMrSV15ITCgGaYUuEwzw0CUNknQXOJp0b0YNIMRsy5rxM3EY406wivtvdvn6pGAvmRtUhU2rMvnqTO79BxO/yHooqdYQ'
    'GRTszq7oN7mjE90apguLEpOvMElZblGzOSC6PU0nxWEKuYGfTh+Lpd3V5RQj8Tbkp6BvTBxNOM4PRqNthDm9uBm4TgjnrwbaQvQR'
    'G5Oo/PXLNMMssyaZNcf85Bz0MzmbPt33fmoGigVGnDOJorTGtUsCHBOhxpvxxlz+cxr4/kKQGmxD08BTHE2cmZm0+A6RzjXsyh47'
    'cnDx9NcESo1u6Ps83RF9Rkf0OZWFoxOTb8V0Un6EJ3ufEOUU+54NXtaV1GvPIMyuz4PBbuIVS75PhOkzq54Hwad/fjS7MGN/z8zN'
    'PDM38ULEJxOmMRh9FLVZlZGZO1pnnHFu4kJhkTW97FsxXkEKCKVl9d0GNgqb9JyhZ25VgyjlPUmkSweaqS8mI+K2/aKQJMbY+uT1'
    'lIQFVrOzxpgAySYFgxJVgNqv3QAdstnLNjOHnrP73XN0ukHYayBxkpHeReaudE5zQ2aQzVcyUJVtOYFSp64ujUIFP3NGd07Yfd6g'
    'VZUzp/tmTfDNWHmY2RuBiLwyT04EZZI5egMiJUgNPUZoWijQGVl2rTqzwptRSc0uBbNLgfBUqUE+IrbP2E/0bRd1TsncE9oAejod'
    'JvVLHgfgHY0yAfa4mwQiJeRbkigV26ZrTC2e0hEwlCA2dCi9gQhtfg1Pyl9pZXpg9DBr9DBr9DB7qNDQJvx90QlmthKh5tG+jvp3'
    '86E5eKFcwHN6EKktFZrQtrDZVxFX7jOmc5+LRoQLS/XivfmLb8qqC+fSIMInIr4uyUfIEIJs+Rek7BJROwjlooZ8xGoj9kJjP6Di'
    'vQxyUkWaWISygJcGKFLbLww0wqB6+LHE2GPRxMyCo2UU6VZMyoDIGCelF+1pX/gGNyD03LQvk3cgLGwPm/iQmLw75f+6urYtB1El'
    '+t5/aRI6cdqIAxjb/vrDvhTJnLWSqs1VQORaFMBm9N5UDJzYP3EjAOlNTN80UDGzUUzPzmNO+4SG5cqIFlzUyc3IZ2aFJFO8uam4'
    'AByuI6YewEWcmf7hlzlA8J1t1rNXOJUEAdMFpPgkGdLztbLSrDrBsU6STFl5OmDl+u2qhdvOWEtWtOCrW/A1WvCV49dOF1E5so9e'
    'Q7xoDemidQgXrVyrA6WH5FJauT4GSutZd2d2cOfQbnVLs2JGKhcubKwSBlstBbZyaWOV6glyW++0PkguvCxBiMO1VZ91Z9+Lc875'
    '/sr5/oop70rxIdALPhcDet0jqZzQ2sZp3EXubAHX8So6wovN/YdF807w/Oy1cZy2rWAbSCGRuzKZL/hTrMnnZGtmi5J9Fgic8aPf'
    'z1cKNWReriXGcZVReyNMhQNXQ0Zz9Q3XQrIZV76GgdY/JKmZMcgPqXcw2Y5nHcTJvBer5u+JBK5YzeyErt9uggiUSyB5Y5a+2QB1'
    'po+jA82p8kyykDCKWR9DdsvAaw0qFOklMxj/yVDmUfNPXtYZg0khjHqB8NlCWDRT216VmCmFHzuZdrIkq/nNmUIiPGJhwKSRraRL'
    'O5Wf9FzNONUgsguDspiW79T7FFQczueCe7D+Yahh0jOAcgnEXb7MkQKoJzeA79uQwujwt+FFMUvWBsCRsWSYsPxU8D3i2UeCpFhT'
    'OqisgYpsbcHlTW9J/SQZC+LJ82w4xgzSxwS0TDwv0DkX+DrnMmqGunFWxGcIxQDNDtxmfWPPdDymZpAUvV3W6XnZ/YUgGyuPanBu'
    'mDl1AtVN4h1mbQArn8zO2taTAUgZhSSDubTL9t7sJq5ECjC/mUW+UZAPLImx7oBjuqT3y9lN3nKRuG8uF1XBcskrS6NwsQlXSMA7'
    '86n5txaGM2/HBGMZgnEuFEg+eSYYnKb2ZW1g1cvC0dpK+I+ZxPJ2lkmzGAyv4MDId30AEIVkIe78KnEuOpSJVR+GHirFqg9Dk/uz'
    '57HoSn2unW4ktGA4Cupb41i1PK5eFU9QV6wsrzO9tofo9Nw4MwVOlJAkUiUkWgdI5QPWwCO4pmFEKSI6qIGAHl7xaOw0z7T6w8tG'
    'U4O1Ii7JBapv6OY4TEjXa2Ztx+tjb+bBKZev9d5O7BDnExs0G5uwTUcc4la4AMjmxr1i0G++lU3bxRsTuXGQwHM4nWjEAVl95tWg'
    'CuGdbz6AscUBjI2t9KZebdN+6ObOTVxJgGgV6JKC3wJUgwjzIwtWX3FaiDxFe39zfSP1bTDJE5cPNp/f2tAmQFktOrht7Jxu0+75'
    '5JbQcYOiAohXgeEus5zlqD5YHPpG3vD2xu0DjlBaPxFmujty+GRP/PIN3p7e7blMEc13uJ9O73XmfoeB44zawK20jRci3QLIS5so'
    'Lxfo9obDXctoxOyDAtlDKsFtQQGYjQKkLRIX6vQHfqWBHacg42AqEkaiZEpKuup0NqA88N44AT2GQpsbJySgusOrWn1vDZ29BIyH'
    'a5pbkqc1YmFzBNYeVL9TeU0RE7nShAsoWNuwCXztfZGhqt5juq8sAZxcJOPXAlbFNe7qPcAapdbhrxk9cUFgk1Ihc1qzLd2kiAjq'
    'Ukj5Mc8/NigTXBrbvDS24Z4ynKsmmUST2CLGPMzrTc9bb37eKqMNqx8bzYClojZcFaCErV7ChDZGxsysz9jpmgSamdJVuIBAvjsA'
    'EQcrYVgGliipsB8NjTBTatMHTp/Yntb0pBc+Xj6aRE0M9BAvZACwx9+0zLXFOheBvCxcOoXWZfbJBowGkJWaYDdi5Vh4IJuMJSag'
    'qOdx6tG4GokrXItwkdRlbKoZyprD583j5y0GzptGzmRqLvIP12w2TpJBZekz3kKyC+2GUHN5T2Y38yruh3SQN+zG2NtJVlkm5A6n'
    'Y0oGFDfoGBsPev/CetEDs4R56mvTia1Nb6pTd3WZg7g+mJrUYXC4tGmgtOUoH2iKKVgFJ4SiMB130hmI0HZdfRSCzEUCpCIp72Yt'
    'M1BzC5Wb6ZEzs6p9p426X8AcuQYNmxVwClRyO+sAD0GEOEVtfw5rhoMSYjHb8zJM8CRKw0wn++hMaiuE37bVXINuQPXkArdAI4Bq'
    'JjXYiMnPO7M8ArxR30jdsFe88duQ7kXwElwBdtaOPd7ETllWrLluJx913vvnCC8qhH/7b0f+eeM93opBFTpsxXlT50/WLN5Mj+h4'
    '6XwmR4Uhu5mj0hEoQBNtdtc3aWAfSnNHB2jSCgGBHTo6xZdwWobTwlhS+kvBbwb2MiuJs1M0a/zf04WWsGHXoBMuMYAz0FDQW6Wb'
    'V6yKhw8ar33IkQl+FAPXAJruwe6cj5qwoAJKJ4a+J9Er1aS/oR5yN+N6kLhiB/LzpSxcoL3t9I01KsGgvtZqda01dLRWqWgFK6JX'
    '3KQykJ3MoPamNo6C2+Q8/sjPj2NbcDy+0YPKClvGoPK9LKJOWJwBa1qa6uzggmzDbouzOaSzGg9Kg9ph4+ElgOHOSDg8abyyGuwm'
    'ylG6gYaVNigMNhSbtdgT9MZeZbqGj9pmpX+l3hsALitD/a7ys6rd6uCP9anPT5d8zVcOXD6M839MO+PfVF6b6xZfR1EWvIrb+IG1'
    'qYRBHp3iwoKWzkUC7Xq0OFvdeLkKmNzl1hxX1Jri/VEgJahIVplgeJKP16hhlMomk9dX+DxmVSf2EVRCRnrlne++NIns4ZJrKWQI'
    'ms8BDCXQA9kxGPuXQBJoC5N6R5mSfKFva+MriQyEklJDp6ojnXmuYTSQkos31pH7MAnuySyM9d+wKuZ2canskaVdR9OaPrdTiTmd'
    'YnRYjf0V6Dfn6YFYXL4YWkAvk5c6gy2iikrtJRhWAMQj5FP0wj2pQPLNfVDyEtwO8eLimCyA34ARXRWerWHSG+YuY0uK0B9++v7m'
    'fKxx27wltVNp0Z5pS0zh04l50k1ffNIppc4zN8D5wrtBVRA6mgqFXJoeuhnj6NWsCDZL1nd0G5uy3fCtO9QBeWBdnLFusTkxoKy3'
    'ZHYzt7XLRwWyaf0M49GMA+JKcTe00wEL93vI5ziGZNPbfnilIk9DdlxJahfE9aSoA0UxraoaZU1mimDV6ylrvNmCuRkYu7REhW+d'
    't0f2+fYmzc+ds0mAymkOJIGUSXCl/yBRw2w1vQJIKwXSQJXQWZ3pDOWTnbEXxa7JGpy572ixu1NM5bBiN3NbO967dNE0lfBsZzb0'
    'nUYs6p8o+MOWyGhYsk6+ZYXah4jQGytpzzH6JZ7N2Rg4AIaTfrBHlgAMvf6Ihm0T1UO39/O3EFYytP/t4+GFJMpBo0jwYYFFRXHG'
    'wyo9c6eLTP6900WgkNwPaZYLBh+yCS2EhA3Cg5upjtSWa/cETB1r7i8YL4SzrcbtBFA6LSdn6C0/NXqCRiGqc7cmpubWXIvQYHJS'
    'S0dVMU19D2dHTbOjxk12UAX2pnqT7aaoNo8D8rZpEJf9oYcscuMePS4WkHMxvYlJgjKQfCp1OhNFbrOiK/L/vC55l4enPT6HDwV4'
    'Ml/sRrj4rHLEHANU6d+1tw2gwti9pdQoX9wkSNygHhPH2ri3+kY1oJ5MeBJ45CHAtxSQiQ1DhJOpvnEZsBew2wdN+eLOhfeNC3Hf'
    'Armf+vGgJpelckkLt6sFkwOn5OJO/BoakYTLAMOqNqMlwo7PLgz6wqibAnSzY1QLqaXAScFJDDeNvhHb4oGdLprqgE5Eh3Z+bOgx'
    'ldzQcAbIhrpMOz+OgnkV6IXn7urboFhMHdZDjsJFXzI5aJG3ST1GC/UYAiVcRtin+h6rzOAlBQ8HtIP6pJL6nPkxgOqNoeOXIWKW'
    'yUG1sBVIZZa2xtH21Yb3UHyY5v8Y/uPR8XWTVzy86dV8XZZAJEbNYgkpPaPyRnXAgSLs4RAHszxHXZols6YbQ3xfSAlQw0pZ7SBq'
    'bYcaYFIdu9jaDOTDs5wOrPmjUZM62E+wErwamEfQn+jQStis93gO0XBUwE3UWdsc3TYstnjS+Eg0XCxc8yZTYbzC+RVxZ+Uz3zOF'
    'TDpSLrLra3bicySe27bNyqUFwuU5ic0LD813aIdoC/JoATp6cCN8wGqsrOcNp+keardsUGGr8S5qZcvO/rKzRj2wb6ho9vE+hRgD'
    'BV0GuA00HJ2f/RkfIpt+qW2lpz7C5Wk1aDNsZnDYpZEGnMdmDJiWnQcqmxLMPOBYg7je/X7z/Gy/zXZQM9N5NttlPkWVPMqZgCqQ'
    'lkc6o6enU2SdPy2U/AJtolWM3uWizbdmjbwA+qz2LQ0dfjTMwzrSsnH9mVFu882Mb5+Abx9Ig2sglc6W6ad4/tUB2VhdbvvZe1QN'
    'II/oJQ+VJnyezOapTJ5qNk9JrPWZgCaWO6U/QfEMyOjsl+nKKWQHiwb0+6U3c9dpTZMNW9VuFDA2xyf5h6ar2X6khBhoH8vHHwY9'
    '7ZYWXn4BOPsOkQ/MILgdTEz+duZ9v/wzSQdbR1SmIS5PcQVyQEX7T2jREGTs/+z3KQIRvm0dapkT9rYnXP1N49O5lVin+M1grgGa'
    'ffcOXOXwnHS0KFAV/MWmTKHn0I8AVO6KM66EDajkG6oQn3Mzq+YtwrYohed+9RtYccE8HwIxhnhzgeuHwY/dcGjfk/398tbg98bK'
    'tFRNvdHtDcvwsEWswyAnqkJoH1BZC4UARMo6D9hry7Ab2CWJ3wJUg9nFCvi2VHkA/Y0g9lZb8Hf8NUowFgID1YDa3X5jp1ymlt4G'
    'p5+XiX3C2weubzyeG5ePfRrk78Qag57eoAEhPlAutZE159zlGTdEdbiPirmXi5lC71QVsV94IYaeS6j08x4hc8UUNwl1KNHc/Xrl'
    'ooz4G8kToX3VwdNA3A4ckOm+Dv1RhkxKwLcXtJeBFB/2dgnsxG3AznuTHzxS1SHDPEB+SJT0H/vwHsvOyeQerQoPJu8SxSNjcgA0'
    'gGLrxYggN7JrTE3m+gRId4Jw1KOMqqH47GBS9S0QLvgyzjduH3CRfb568h6Yufj+7vOtaaA0QA0kMYqOJe/TG8giimjvGsOIy/me'
    '4tMR5GMC1oH5JgO6xGgE6Amn2lICeGRLw+Zufu+jELPGE8hG+w479w527XPvOsCzS4SPTEbQHygUeBG0xKWAfeGQfV/8/hesFEHI'
    'ajVbZIaWJYDtIapvXqAKKfEdSMkPEOshOWYJPOdFxuJ84v+0/jMh5saoBvxLb3QbUMkFVmg7sWqBaSMRI7lmpgj5hsAcwKqqicKH'
    'H74qss37/5S435+cTmBDcV8vnMuJVwJvLwrhwSsFDsnow8deIKHGQiKXCzOyfvvAAAdkPBfbCd/G6s2JnUeL9tXFtVJycV99EB/L'
    'TzuXWkCnCx6tTxBGDTwBL2Z2ufZqply+Da6o3QIfF5M7MN8ZTMuu6ik8onjsXJQCxELbOp5rEwtnGPUK2AeXAUa80iq1U+ylUGAY'
    'mEdHI1E2RKrWvdcA1QzMkEZPbcPW/mvSZ7vxNrn0RuHnvzqjaOXrtD8N/3Ha/8/0DvpKa3qj2xuGu96q0W3AUURjACkcBUbIOGK4'
    's/kuDyMHmq0LLJCDOMDIo2uQ5pfkLPbNydiwjqu4Ny/pAiWzp9+vod+ETRGMhhHf+8nLPEXoIY9GQwScnbZljtRJfz+AH3RGvNnp'
    'tvSpUXmjGvAjhO30InTleAA/INcUnka4OupEYHkpkbFYAjGMgGV0+9u2F787oTpgeN7Lu0T2uJJ2GNjPbFCUBQrJXg21uwE6sBis'
    'pOfE3hMI/lEYhUCDDJ0coxbRTij8KY4HQZuw9NOCMiHkcuPRhc61Gmew2I45KH57RbZP1XbyWwDG9cyeexo6+DopzavOPewF0pjy'
    'BmRfqDm25BZB524tBW6Bwr+g0lR8jC6QfAvbfwmFeYAKJPE/g/SGEcK4DgPRS6E7U5AOHKAjfqYC4Vmc98IJpOC3AOEl4pmpQn7n'
    'PQ67VHZrHEGVOy8KF+66XNmccY2bkg2rwHoLngYavqi8T0B1NKAC947DtkRvS74ibPQ+oEYfmBqtdstf7EMCY3/LYOxV01U8kfLW'
    'XKTepQRstw4w64LojA/WktCuK4XEq7iifE38dF7SoiDePbymExt2PHFw8lqdA0Ivh4VejhB6OSjSckyEEj0RfyP7M0R9O5jFw5qs'
    'xBXrEmcGD4wyDgpyHBbkOCS2cUwMu97kA6OFY6K38hSVZ290YJPwwWdidYSCKYfWrQ8vW2tqc1AS+YhTd4dEkg8qyT2sJfcINbmH'
    '9OQe7DpBVzHZcR3m4Fb1EWddD51pPbiSDaqOkKiYVztRd4FgRMUxPrh6jEMr4QclcQ+L3x4hfmtgD2Qb45PUxWE1eEcotjsohAvK'
    'pMw6NgTup+Go6zFroAnuUE+6SaZV/GZgD+sNVfBgT3uE3d2AOYuT3h0wMi6OH7FneMSeYQd/Ud2PrJH6QbHEwxtvR2y8HdxpA61m'
    'HJQd3FI7uFB5cJx5Xh9aaq3A2vQ/pVPkXBbNOwyq0U7AWUFnDNBnmQ76vGBXkAwDfwGO3gnpBVHq+AxYs6DyG6PcZSLYIEbQFFvg'
    '8ATzrJgI/9IHvH3gMvwo3ON0ereGTUVxWKzQ+3+z/nqYSl69ntdNeWNSV23enytPCPCozYlAzNqK3dFO11Oif4ICtUXEmRdSjBUO'
    'gianhvXWK1F/77Trc6zlDeQKyPX3k7pqTolpnNxOCF4NcvDnmRb53rH6e0oyhEyyPgO6iC0tcnofmbz7a19t6r8LBuAQ7QespIhF'
    'E1bSaf/9sgggWTPLmwHte0fVqQQDdAtZw71VojhvFwBTA0gKfllssPksMzgfqcMHKEISrLa4PMWmMKO0hKq4gku2tk0J1+W16ZsE'
    'ceEZd7jMCwmfIoFncAfj9VjN12M1Xo/VeD0W5QB1szsor1aUOCBoe4CRKELt8VMqEIQRLBpCC8iR9IdEg0DLDpIVM3lSvFBDQ7nC'
    'plPfZCf3eSlfmMzrg7z3TJ09UQj9832BJRJ461PwFW/jueGaYyx8w7Syh0tEs6oBt36bzwA1dFYg1C0qByaKCnP/lMyOOfYjhBfU'
    'lo2Aid7UoRJUMtPGbVpDJIc7Zs1byZATbLihCfSSWAzYdWi4IwkPo/49MfopDFwYk/XpQyKQlajUTLrTp6PGuiascblSpz8k8IAL'
    'CM0YZ2W2agsD/CAFlFDEXhrgMSA884LR/nFKCrTFeaMmPfVgOZvZOmelmMfp2qQC3V2LdlWiHcoHwfsYmn7h58XEUjmpGHwefNv4'
    'nH81FemAMf0y9b8zCR/4u00nX5RANZLjyW+kpzhN+PfOjhT+xasAfRvQ6knCUyANAxUQfuDivb1qHrmA64vkCAaUvV4HNYneyOw5'
    'BPuBuX7UEvb72FoEYvTAkEskGqebh4le9mdNyBOeAG1vnXKkC74jD9TgDmU4WIk0R27YDHSKOypoAR0pM85BoRfAut01P5/7GpNj'
    '2FCPjcH2eCP536gtEEjyZkBeRmis/lKY3jxoahwpgSLV0kPwBSFSLsl0wK+PTBc5fmAWA00Ymhu2N8II/ANXG1gST2osNd9VVlRj'
    'JSZjLn5EB1w6DBwomWMUMNDNMJMrJj2qRSEGtKODNBVIB7CHP90lAX71+1zHUUjhJsCCASthpufbl5fDtA7GM3mGp0AxCz9lCYdV'
    'lVmTz1g4E+ewQdCpumXR1UyWLB/MPjHq9ttbLSAMJMYbvDpnWN6Fy2CrnrGeVbHyCfyM10yF3RRJapwIkirl1AbdPCtsfqbP/TUq'
    'g2rStNwiGaom2EemSnwMcNDMqU4VrBuxvSjUxtySKlJ5krDYivTmB6iBWBVLXHM74NtdJWrM5A4cnnYBUl4CZn4T4MdSCnshJaGo'
    'BxQ4BXAC08ABcczS3Ikos9X1D6yEEsszCx9srhEo8949IXrnyyh+GaXN+lboB/L/eh/qg5L6IGxUcDwH4AQCKZy+Oghg5nVW2cpg'
    'a6ajqj5Wvs+GWbPYVXy3NYLwnVg7SQfYkJH73rIC/GKUBlrJSBsJL+ICUBX7lSwqgCgrUq8qD40uH2pSH1w9alDnDPIjiseDswcA'
    'YE4A1Ik8NEQhu2uBpUEhAMj1YaZIDhL5QALS9CBlpyVeBUoyVxcyIMp4GOiXQ+tHsrfhheExNgWlj7mI0vAkSaKyqdJSTGkxkGsy'
    '+86FZZUyxY8FcEcy0OjlhPlsXIsyLIkp00/TnALUFKANYDfGgguoeKXXB642OExH8ppEpV6c8GKH7xyO330KJjSv4vnb3OY6ibcs'
    'vm/hcswqAYoPmN9VAoJK5TObQe7R8JkiTc+8nbj7ABM30Zn5QUohoU3KRQ8jVZSANXCAYs6ymKkzhXxxhOoWArHc5/RNykHrY1Z1'
    'A2NFnZMqANSHkV44QHhQj1hnlB2iEFbjrpL0TbRHJI5fzLw6ZeuPo48vZtZ3Mq9K4OqcUsOhuNK7RsaV03ITVSgsWoAp0wXCPuDU'
    'IhiA76pD1TWCsKJv2vKIQXvwHlUw6qoEMO9NN99qB79kfbZKLlemDRo7WFYCFzZVNnxPrHgyMO2CzmVmFciM0nFoIC6uxiaggtsQ'
    'EcC4/B9+e5Q1L9YN8LZiaRQdKBZQifPspthFyQdceTGRDVW8mbHUBdJtwBGbMFMlUwQXV6RJw4oHj4aKXbOfXh9mEWV9hOcqKUFA'
    'tKtlZoOF4/J8HI4diClhVlreqJFYzOas3GSnKl9ELwpn/UhAz8tsnoNXewKca0C1WoC77PixFMrLk9/NHForfkLyoVmbQLipmpBD'
    '+BzwEA0fxyrGOLT7LWAPO78a3lM/LOB3v5Fw+PnwfXMd9Pa1sk2ExAgpPXOtmdz+NDgVvy6Qxx6GrKhj3Cr0EUxy+J8GBi5cXOi8'
    'YqM8AJ1AjoniDNSN0shYTw5WqMMFdTAKhD6fDHX2lt4MI8jHyYukWn+nM1b4GxU7w+eM22NIk9hihjeMV8vW2i3uLC1VcbqmScmz'
    '2E1c9jdGc0skCECpTjB90ZLPEqOxJ32Gb/rip4NNMpArrQttQDhDnO+yYSvi0wJtHBVo73MCzQcDmhU1kjsNP7jetGEVC6r1RWlB'
    'zHicnYV+Fs5S/ZHNmi/OumCrxRfXORaYO4c+2QZNECAKoZo4P/G/MPRTKsgEEA2GKRQzBGV6OWTp1EuJ83O+iXKSBSBvjjt/++ae'
    'wOtE+MOubOYZs2SAcLBcJSncASs372JqXD1tOmzTpBqYTM9ZeWdKcwfo/m1eq0LSRZnmbAb3G7R5w3/rw7Y1J0IX3SZCL01OLTPX'
    'TJQKqFgPN9ASwDQ/0wAsDNhXSGSJwYgkefA98zNgozNTR2ybm034Ivrr6Z8Or3ok9e21xN05X6YrVvnEecFhy9frYwb7d/fVNS3z'
    'Y0ZumJU+SlInnOEPdQ66IppZJWfJUmNEo2IIUhpOPA9dQV6S7sAKdBqhyAlaGiD8axIH2fUmyXWyYlbJRRlbVRrBYUZxPKc+lP8h'
    'YNmgiUTbT3c0lKA6ItXhNy4CLnR7kkpPFsBxCGxUC9yYLvQXlEWKCNgkdLonMxrx5kBl4IefVy0cUWkXNXeDsHDBIL1qpKUBYvKd'
    'FIlDdjB/wiEuneHqVHmCyslmjWPkqndYsM/bFXes/CD0ln4mMNaAjcncNCMAZwB2IjjTBYKnUgSz4aZeUWYRtd2TBsjuQq0VD2rx'
    '3RbLjRiprhQvWnCg1smEBY9c+uOyvBLRQ3E0JUJoJQJSH1ccY6Bdf/OVifDaE0BJwW8BwsWJYIb+HixFFhDFEcDkgStiXMq7ibOe'
    'QWcozvMQOaqd5bFz24PsZl7Fhy8PtAA3TrfUD+YdSglpXJi7vZAonoL9KfFGHqUnWYpVllzW/IT0UZV4DEVYg3m6TAzuuM+YVIYi'
    'yiBHZO7Qt4ZxSyeCtQ8Hf4QeXBcjQktpYG/sUwjYLvzqEroANRDq3q/pKgo3lJQWVPJJM29GaVtB7e9pxYCgNybUCZXekC7XJKpW'
    'x2s8uuwd7JGm4IuBl8Ewp8AjCzepCvejqgL9iDXREbPaKQC635LoTQyCb0LFzL6CsYyEUqAt5U2x35wY3206kJIdeDnfJsb73Se8'
    'KohvLldhZYZS5kL0fpfDvIgqwfOidLpZL9oB09KYDyOKJ3P5XsP36kzMSsfcRHMJzg9U0IDsH14ry3RhG61AD4aT9NxEw+RHPV1C'
    '4HaJNK96++u/uzJHwHGH8fJ2/689l54/DLe3Sb6qqGsBgd9LYPu48rsg4rmDNywDb++w32H9HYulH4Y6TMUpIo7c1m9Xqo7m+/72'
    'M/9+wvDC0Xyg6SMJOl37xuWN34/SRcjEd4vFfRjqh+FdFpT0Fhp8xPJRndc6f5TgHBVileL4gW4DjmQtH/lYpo9IpDhOcL+OdAjH'
    'O+VxFX/ONkVkz0ixj60MPB79zPXnNRnvww8UHsbThONp2zzeECUwP+BHLkJO820YT6Ro5ECfYSQr+cbpjf8T2oXzvn1rGLcIv98+'
    'It5v8Wb324jopfXpASN/lC2ZWSL8crf0N+ujl1BqHAwWIq385BvD7M9gTQ0UUWWd3Zmel9ssbnKSKdEAZYBq5PT65qNA5Y3C44dP'
    'Wzl/BAyKHGqLU22psJo0Yfm4iSrCDp6cihXda27u/qNjjlUMbgOVgWqg+Q31nCbqUC3cWzy4cVxkYDeNGALZ0oyxOl0XFRfrUPLc'
    'Rcs/OMHMUSGWbvkq0tOBnhEKIJ70lPQIgVP29JFDQXF+p2Ay6qguTjhjdEWmjwVI8bGFxZ7akiC2z5jtpamgt+mHTGuhBgy1zaOC'
    'py1DagCcCgCbi7wqRVQbOkB629lX8KYieHHf9ctbSEXbLJDt4VTUIKw8XFEHMV9kf4mhwHzZ1TIKVCP53X1nfODTKFzldE2bOO7z'
    '0zZ04dIIj1vfzBVYqyIllkUEHMCM/uQol+/p6nx+h40i+XYc30tY69XPd1+MHZAvWfrfwbOy54811icI+LKomqSzJwnbnFmraMUy'
    'fTiEfe1TvoVVd5bIUYlOBoPUTqD5SUWlYUS0fD6OrdPYDUNvpU9+9ye26MUVGxHrXEAlCQZFCMQoXi4ocKUpX/n2M2t2+oRs+TJU'
    'mcrHjYTrPCX3IRMqaeYtD+QUDSjQ4UHKB2eq7TCvAmT0RD1B4km2D8blKWDxHLDkRqImhlMecRVS3vXdk98C1AG4wkEc/jHdKbqF'
    'A1zp3vVVkcu+f1RYyqeWQNBX+vvSAfJOOWspmemFfK8YAu4cOO2s3zshI975TnYo+l4INsyUxPVEQoL16vZ0X3GrWOMNd6R0rqJN'
    'VB6rOlpyO3NvwEDrP2NF1wu6YEemVC8xGWbuoA5OsNgFYQA1IyonNDj1AvZHXVFPKs6IcRGNKJP32oLBe6UcTS9g3HjZ6mPqhQ3r'
    'btkz08t6v+CPl7+jNeqkcCPZoBqpxTJExIZaWw/DbozjFCchLTjX2S/EEdHuuHuozq68kZNH7ptOODafcOycvecOpalQL8aVKnFE'
    '0Cc6eNk7NlR37qfuCHTv/QOOUgFyTdB3F7Ydb1dn7eOovXgJzrcwYA1soEjYa3W6B6PrjvVTMi1IDIiXyQZ8Zze0c+Vo5yIRxYLE'
    'ZMf4Vy5qkikA75Zve7lgPRVMkhFE4rtuwAuIlJS0yvEb5IcEbUdnlBTcoVm74bwGunPKa+o8HFkhU3rKKsnHnbtr+7gAveE8RVOI'
    'wk9pp0a9zl54UL1y7gReMgX4dl4n2/CB75CUworY3vLylC3L1ZqACBCkYQl0bzu/TKYDY7Of6ZyM0Cgc0417YZTP79Q7N8d77Hvg'
    '+QfGUQf84zBwp8s3Pr8DW+xmz7zKSprYDcIKQbmhdah/PCB+1wmhTvx1sJLcGVyqUc1vBkoc58vHXGxfwro2UVm7CTm0DS9B8xaC'
    '5i0EzQXss4X43SGlwL3RwV/7eUeWdusO4AON/YF2E8UCMY3O1Nyc/CwggL1SelkQwnAnXv65iVTSQ91loDKgojJGzoy5DXJuD+75'
    'gFMmswMxdUni+IAg7mrZPkJbIT6MpE+0Oj3Cv6/9SxeT9rZh+kLXs995iAmMrTIvaNkffXYl2m1+IGC4/3BtwxySxkACCy5aIaV/'
    'gp7dALeBhiOyHTCvA74cCP6e/b9OJIm0iM5w5Dq+GIxNhy07kKqHAMiK4I7osDzWOz4OTzvHL7gSdP6fbZieOLiM0jXqL2HHnRxQ'
    'zt0nYH0ketG2NFEz6BUbDJdRhOGKI0tvQ2btkXecdF8/3HYoMrPTz5oP3s4m47/7pE2ZHXcY6ZBTh9SogFHxnMbTUTT/h8/A8t27'
    'S7uv0oEhhEZ6IIVZcbJkeK5HxIBTf9c5st1NUF0bZ70/bRSyOFe19klrWDaIlL8NEiok5HLiK/3HoPTsEE7gilQ3vLw+B5hWl9Sr'
    'fz4RKW/IMUfWLn0cabdL0jXQhAukTQD619MZFuTBdqfoAt1XEa5wdwdg9+v3oWmApr2QgI6/Y68RYVzFMT0APlnwsiWV49WSvAMx'
    'z/3b4DGygdgKv03085icfyJHYqhYlol3BRjZhyGjY/Y6nVbzQq4dFKJdxXHFJlGJagtZ3rwOoIf1Sr54OfQ/prerb3ORqaRHvH0a'
    '+5uJgsjI5/pG9mTs+NaQX30b1LDBOFaK/2MKzzJHrN+za+oVIg8QDhRe44Pr+N99fBHdVCVE+4Ej5vp/6YDSkxKRDBUh8QROYN7R'
    'hvH8MEbY18wrfYFLFFofZqRIB8bP4BgZmMtX8aZOh2qC1yuayle8iR21H+g2PUhlf7OsPT6HqxucW/qON9bh+IyJbfvkPVi9l5TU'
    'RYhZQJrsw6D0wLR7d4umGybARN+4QYjonoNHDPc8gt9HgHuZbrzh1absPBEfLJsbNaGmQJvBOWJ7DtfnyA/g8LBCn51ghQS6kBsm'
    'CohM6ycc5VOGvum3qQaGRkpCHrMZaH3DUt/4DUd0ceJGhlEk2ps1zD9Cr2nZI7lHPLnqXOEbsgZ2w1xGFtpnqfSGOatdwc0OoFSQ'
    'Iq06stAF1sLLHrYVX7AT3g0zti3C6b7PNfCTBzwJt3dgDOuNX1ElWT2iRjjvGTp3bm+k7Fh5IRE/z9ton29xsr3DnVGEHtWAWFQn'
    'ZlRKHDzioKeaSjTedGUrrid0SJslWpL0vEylTH4sDgjk8wM+1RelqCsd7PEKIN5esKkX3a0tGHr10iANUOAf/G2jtP27z698lbt2'
    'UQLIHaJtTuqLVTDpdlAA6tjr4Ddd/U7S7zZyZii/NkQx/G7RbnS4TH7nwLkEzDXQeC3fU9xvSVzMwqy1AkDcgznJuUqeCJDSkyq8'
    '7z5CKB94lOp30nXtQG5gv1OLMdM3rsB+GDZRZAgLele3YpxNiKUA4VKiCYCYb00sUPSi+6qmamBlKUx8xBiIfJc+zFO5fhep2t1x'
    '3ud7du/wvReB+zTrXUG+t6hnCCj7fDPHuSin7Y6tYZXkHWN3w31yP4PLwlweD+xeMAYiv15g2ZVhQ6QwVDZ+ChXZJMfcU8auArLG'
    'LT64t0FPmtfoQh+zxzuP7Lo4XzVsi7Zm5g6f+dtGHwzhMlAlcPM/82ZmfhfzkrXS02Efts96dofpPbadn9x+wvzxbUAFmXvdcDMD'
    'uEel4lEXN47z+s/uSFeperSBR5l08FBG1wDCMW74MCkzvB+nviMpPs5gU9m3DzeZHPA124XjghmiUc8AbYAqRPYvm8e5KgD9sCZH'
    'RKq8czxfYVX6L/Vj5MqI0DJcU4DZo10b4OGfnSkC6y/brwEmBv/hyagdotxIBqZRa3BEtEyHqjVGuPreO/KnvajSQvvGqjq7zP7M'
    'lvnbWeFlA2J84hKCgITOPi+O7ixPN7MUwLHE97tYPTaQW75lxx7Dvj4hRgFWFD3APJB8VDzmmaYxvOa9wfQDRUhaOu2G2ddYAq43'
    'FUEfZrcxsxkG+flVHFnDAczK19XVOTQXDcQgxv7u+4i5A51we5uEPcRYIX1MlC/L3GLdoJsw9NBHJGxrrBBrWjgwY4fa3k3lkr+t'
    '6ukN5WVzX5C36F5yufdC04htg5iL2DDrnWzTLIto+LYJGU5LGG6ePaAza4FqdBsb6payEpDpCYNLCxdGuQpueXOTY6RKv3EarOLC'
    '3Bt6KlqY1Aqwke+Tp+855mbdEF31to/+i7f6uJXsHzFVvTnAh/H8MKootNVsztBjPzmgPSa+gM40MvzY6f0wnMMQoa65DxXr8Efj'
    '34fRvVAv2f1qFEq4gd8oJBOAR7NNtUBi5b3wEMbhhXqWaZg3esiRrYoV1YBrfE24mKFCt2z+MKpw67U3sdoGgJazqZEldTweA0Cy'
    'W9emUxFaU2nWx/gsAeWzd66q7x29bIVpiEMAOnUUl44+uVp4esc9fIs+fCA/6RlrKLwD2c8c1/kS+2Zd4peBJlVxQ+m+xp2WA9lW'
    'w1heombg3EQd9T0lALHA9VaaTjyrFn0onoRhVHIrDgSgCqVhXceINNSjKE3/UdFBs7Rr+IFvLRJYm1OLpyPimAa/O/7+if/0ERdy'
    'xRNDYR1i8oQnmcLOi+hi41Nvs80uuJZJOIYMAcqORu0MIQcgRxlbjoDsjj831GjiLLXFClXzGGf00ns100SBnKmi5iFn6TUVh3ul'
    'qC2vpBI5Jr+0Q5/D0XsimdNyxcYnEeI+5viQjPgcY5cY1MyEH44BDn3J8prjUQS2KzzhpdCR78PV8xgj58P6+IG870DIRfd9PXGn'
    'Gx+89d+lsNEXTwPJ/RL3vnW4zxHqxlH85iWT7U4ByH3rHyVUXQHgtULXCU1ZJl2iLaB4dFJo336gcWjfqCVHDLYYgzD+MRghghNG'
    'YVR6R/rMaOtwQx7fLy6xe7TgKq3QHhaAVriBvbO99lqzQS8jqR9FNb6d6W4wAN4F0MEhDxSrFevuECfdyVE03grwihAlqEnZuxXM'
    'oDpLEwjX+Yv2pMEfZQq+GFAinGrcdqpgBsXxc/JmtshMj0xg4aOxvwjpZ9ZX6vjYCyQHcHXedYISmoHwuL1Pf+Bxh0Q38lOxR4er'
    'CfXtVM2SyFSyVWJC5kiFULiWL+3w79yTqA9a6PQwOdOqd6PPMj5KNnBauRuwCjMsOOJ6ndNff4G9HBoW8nSAvQIou51nUmSnffe/'
    'rhQyvwlo4N28xgD+l4LfAtiH2s5GkYy9qfZBgB5vmfttak44SQpUv+IyzqErnQA5BXcsqga9CfqZyPAWXti1fn29Opmuk1QQCJ3i'
    'zWyRGR8NOcqug2scjhdOwRkLjh6wxg8sj9zDBt+fnd2nS15vA1SiooTccW+s2CLO+tpRcRLvRWkkp8ueRJnizllZgEDnleS+5DJn'
    '29Ajol8SiTaggZoovC13JnZRNFJMaa7w800U7/ile5o7Q3vTW4qJYSFeI8Y4ciHdyeS9MtfLzu4igK1cessuF76IzhZlb9ntL73M'
    'MvgridLtxeEwFHX1/5W3hwPdkA2CVC59cAG/WqoA4B26L93JLZZuAaqB3vGqiv5SU9TZDwP+uzsogQITOhQvcOz8hO+NhbKpUAps'
    'yuzCgHzbNUATd5kYVcJrMs/X5IDXXAdQ2tjtk91dp13jOmtvJK+qKMVbEkC/oC6SMsqksIoU+dZ3hg7/K3r91wSXCtt69bsQYFsx'
    'DHwsU1whbhpcFoxiXno7D8EWYsnoGPKD6Wg2C5e52uEc3pm+mkmeubHoa1YuauUnAab3g0knWCNhHgEhmYJKhonKizL3nbEteqW7'
    'D+sNVA2pmUxQb9CQEUE7AV+0UBsAZZ8e1EZhjvjmhYQPRFnxors+g7oh4ALHJVMRywsSGM2smsMaJZawTw66kEJB2kvXKUMhb3E2'
    '1thyJ1SWe/PiGxeAm3K2pr/+ZU5vRMt7Ug3WdhiYTJCI6Sw/RVndDJjnNUNFNrhcGokCNS6yvdFtwFw+oMIVPRZDduVHSI6QGja/'
    'BQgX1l4iJ2Gn391haYfH4YtFn3Qjv5DwmWDMSwc4+QnAQDdczgOux5tAISlaexjuSXRlr5I0AnlRYpohNQE3qAKnWXjVo+eojmVJ'
    'd4ZddsUBwZyvl67xA+PbLJk1o2Tb8kpf8P06mVOwhCtuolT79qVlN0t5kxUxOamuFJ1nAMikionJaOmikiRIAy1Cv2QUqQigDIJU'
    'KOURR4uaqv3VUBJFyGKo8fIr9LV1xvxWineK8yDuK1FXmRhdGskkzDz2KSeEw4Tug8uH3kJt/pqrBcVfoZ3tJd1sL6qIeSWOaoLb'
    'AoPM+T8m+G+ZhCng+VIwPW1HIR3wBPAbWf+NjkKIZf7L8FRU9uqtJvpC9zkzZwuv+aIFNQH5u0RLQIQVCyDZQAr3xW+7E8iVvtQp'
    '9dm/ukZrujVfZFN718RzES+If1H8vKP8bIyHHw0ZB42C9NtzXOQlFzNm4epDlIE4SLbBTzdUAtRKzFdn5tp2SIhjT7CX8ownJCxe'
    'kkGZyYvn0188i9Mpv9OZ5T6ng4TpTDgGCKZyS4cuBgZC6G/8IeCOzohzq07RpoOquRRqAzAbd2b2rvNfAZiROwcPM94kyQ8OibFb'
    '7KHhl2/WWsYBUJ17/3jSx8/06m/iBwHReWj04zPv5mWAGsgADZb4/LYa4BSQWbH1ROwvQT1xduzK1cJUr9N8L9g/+6K8gtpBIiSc'
    'KkfldrMoSECVuDFrJrC62QFZZitt0p0V1/Hjcyc/OQt9zVk9jfgtQLjoYTlG+YHCWZUrS5RUoAVnEjKH253NqxkCbCyPPqvNqFJF'
    'NaOwZyCbwswqL7C+UR2QSK++oGYH57MLLhsWq+Iq/7JHesvuBAsoFP3wr9qBjfgp+EKAWUFnio7liTHjXGfvOBMyVZUKwayLT4yN'
    'nC+GAm+iUcJ11muoswufJ9yCOwhZr04/j4wZAXYmROlAoeXOVSBgbl0aLdrkRDYXVMO9hODpUn/AZ1eFVpLyiIMRDMq2BYC3TTjJ'
    'mGfOLynGA1ixOJoEmVQMrn/kCbllTX2xEF9U8EDuL/cPf85SlunW28UygG4ifvFb62nIV6qSRWlym/4V98AEoN0Nz8139HSgCMq5'
    'ZGZLnrljQAaXmRiFl/HcjIUfVoKMt4QSYP3Hm824SWy+GiA5yx3hltlpWHBrq0Be2fQYIb2aNGZPGjOTtWjKBM6m30BO2LvtfH8m'
    'syouZYCAuIWBIyLjQLg/eiBm1pi1KwyI40mfT2ZV23Tk8ofHF2tEHIiPgzKcv4dAq6yPWcOZDK+IDQ1MVoQc4OamJ7KdyX6CWrDc'
    'mPedikJfcSyeoE7fdFrSH9kOWkmeSSVy4M/noBvKp0r0VFueTwY80fzmk59f/rv12vZI7KfK1NGPeAa/wOdbD9KrB0DV2fnqGxHb'
    'VjI0GQL4CrDW5fkF51L7go+k01463fmc/tKTlaKj5ySGosbkj+Pb4+uY+g8ytJ3d8OcSqMTWZV5skUhoJxue9D0mLoaCyZb/RHIj'
    'LaI2IcTdTneHuM98vG5TBO/14JjCVQZcIVwFyKCp9IAO5QMHMA+dGT8sinpgxZU0TE30Ct1NRPKNQSOUA5HIqjHBs3Mzx6G6g4fD'
    'O33R208iEVxFw1TJSBXJcsugtFp+SOiXapUPq1M+qE4Z+vpJoKl2eqOVUKF6J6Kb2YnLcGxkvvkH0NHqKgAAxr/uzYzGDaq4O69+'
    'MorswcJd6E/lsbS/r4MPWm8ktLUgiMGw4YsKxU0DhSW5Qtm9fXn/4vDJYnC+drD++Quw6T7Y2B84q3tMeGLpo115LjcSRVBuJV+S'
    'wfal1XBKIoNAr9kHkgvpt73MfGyhlAHvQQBhAVCOhayIsXLpWDq4Aj4bqnRhgDWJMpgzXVYXSWF9KUziJi9FRUL+tpmVwOICIOCj'
    'CitgcWkXCuSb06PIdJBBMYY57fkgTtUOXkIKylhBYKzo9Q41EFyrIitHfvKxWooz13sIyNC04KNwXJWd1TGxxGpTOwHl1cfkL7JK'
    '3IlgUV2jLlEwPQhBcdSE9JbvAgysEyfkiqSDeNM+hELwnPThEa4CvOTgmFTbm6t1iyqMBfGcBaDy41uwiuEKjAC2okVlcTSmuPEr'
    'e4ncSItomPSkF3PwsgHR/OJPT78s8V9Y8v89OdC5YKusc9Y0puHkPlHn+i46xEnwg7u8By6VBkF8KZouAsaX3IollVNniwLpCzRI'
    'hAuJ3BfUebJZ4Yjwsi1y5m3JzrBTJsZY6LsoEJdXyRVrmeOxxanrvSD2NHWhCCj9VUVJFVHm13xlRl9JtJgxlMo4XfC/8JHS3Nc5'
    'D7kc6ZrmrYnztSRo+cENN0ArrjfTULAbD16Nx3Y2US8emGK7oZbrCElni5KEcSjODEIFHc98gfB14L5HULr9kOBsOfgiO7pvJMqK'
    'LkQ5kq4bPNJ95mrJkXSk+0gzMgktnaT007kCUVknWTML9+Z3N1M9pPhJjnTOT0UtgiDaaTYfFtVAT1torwJa1NZiodUXrpBVjFrj'
    '5hVzNizUJw79QMgHOieWF07kHz6Gf/D8PaJjtWIZWA8FL2w5oPMegfjcIghrrFEdym1vlvh5dXDZiwDOPpirxGtzu4IFKQgNsr7U'
    'tj04GhFaOImEwd8gondbRU1mkFBhgTSlUFu8ne8kfGiLG3KOPpdmhs6FhE88S1Z972UApcSg5ZuUNRZ6hUES634Ha27B5Vyz3fgp'
    'g1ayJsoU0iZpQNjBIhomhZZuCwJ6X0muiSweUZLodMkcfRCbX05xKuA9rHb3sNrdY6jXJXJ0znpq1JsG1Pu4B6ZvpPaGWxhIK5nT'
    'OYvQjuU2L3j9j/lJUkW5/nlQYcMhbQ1gjmEjubLjsLYS8VIFwh+NZRGVrxLJKH0Alu0EuQuiImov7mI7+FFvIVQNTnGxTVmu2/Dp'
    '2y0MFaiJKt+1OU2VivwEHIQeWxJdpkNgNWOzTBTe9fSWbB8jBmvPBedQv3Mo7ARnB9z5qnw06qwU8Gf/mP/+RBXV35+elvGfQPyi'
    'OZAF5W1PFE2hsU7hoG7jQS19nT1JInSlU82itu3+oCWpPxiKKg6JoYop+1KsfEi554FemIo7O2VLw064EzxwDhvWI3BmhNebg9aN'
    '2loOXXPeGYoIVO6YbHaGPnZGpGw6Zjem5CV4FVD0+oB7W36ZlIB09JFhj61PDI/5G1HBG9v/+b4oV/cnP0N+IDM9/jSvKh0zH7zc'
    'LpO4LxQgZMKXPmdkvAvfwawEsHJJ9K2zR1qe4D+y/WGWFjpBXhsrloQsenAlV91EZ45mkWQt5ZemZ/A6AJfCaVB8KpIQfPoUezI2'
    'EKOSZnnjuwCTC+kzqmiHmRmvMhHbBcGf2zdL/qnJFhq2mW2jzpCBPZI6kQ6VxpX2t29Oy7DieoGGeSJsO3+FkBZvB5uYgVU1Bmyb'
    '1hRWg8+OShbQKAOOBK6MT0lJ94hOSPGIusPyc+8KcA8jvTCN+kqkyPuQxu7Derp5uhxEj68qptWZjxE3Ef1BQfFGwLq3Nnz+qWR+'
    'WB8meN4SCZ6txndmJWZTyEWuY3b06PVnRlivj2knx+FApKXe0DJwBaGT6aqAVd9wTWyx5sr0VlX4mjSKYeOmHf1DMg5xHVvnGwmt'
    'mmovgnIqA3otuBpKx+aZMM9m4vg8VcqDsHVpj1tBc2zwYRd+gVejJJ/qEwjClwqZHLfWED/0jjvIBrMcoAAFXMfqhHBk7fBqydz8'
    'JTUfNglEO5Im23Yfaxho6a845jCQPOrLaRhxavQ9/+GvBuFP03kK7X8dPWxvtfPlMmEoK03cZMXMtsdJjohzwh/2WKc9Mmb5efkm'
    'ERR+6I5N3JDHQYbfUqZYTGd/UN3fASsF6IMFAsTKAMDnPS9fnjJn/tla51hAIWClCMRAYw2FSIP67DUUXiy3E9CWJauH59uFg8cO'
    'NAMC4IBLQG+rYwdJ8vvNkUwHmnh3AJWz4ArJxq3zPlVmnCih7KgWEkW0cPSddakg+Ukmy4rFaICIBqkvVzd/SkJRyspNx4KA9By+'
    'dVAKmRIibnzliq38XCZ6/FEMP4pUw6XOeUKPyAP4jhw1uF6jYBpQQcOtc62iANvTtkyOVn6pHDSArbz30vFyE7VwuPApbqMGDjg7'
    'dVjj4RFF8fRb5hvWSRRxupZT1EGUxeqhRi6RcnAFJCpvVAOGexOVSYXuCT6BEm7FvgOtw+TxtYSCD1xa+DKDB0r+HnlnkXRKA2uf'
    'ZIaPuPz2iA8Rc/kMwfuDWlE7pTIz85sBg0DnX4gcHyHMflDPX6fICig/OwNkpiQ5gcFj4lOSRn7kxdaKzuc8BWyl4opzX4cVsnXO'
    '5r7ELNBAhSUDwHxXjmaviAuEi2LUeK3Y4D5YQtVfQ7jaoBrYT22itCZu6cvaUcTkonBNKZ2b8+a2Xlw+RPkmy7pdO8300qlOAh++'
    'u4A8ijlrCKY7DDpjInSpxVF2hurOu4YlO+vhXvpTcMzr/omZXtw4hw9UvFscvek6oR/nOL34cOISHVCYfr9++3QaB1K/fuf+4x8E'
    'Oqh/51f/dy+oS+nrt5teM/4inXY3BGM4BWQYBoJ3+leACAEXhlEgh1IwhWNAhXRQhT2/zunai+WcHkd6dAbpPdIlAfRXfkLcAf76'
    '0CuZVXJslWEX/ktb8SfWpDvJdZkoyxZ46Wj/mzo9VpJ0I0NhgXefPeI04f8AKST9FYLJGxfkTkzpT4yHTq3qnF7LAe8ditjbAv3k'
    'ybWdTjcSBdrkh32rWDkJEszwiSQgGPoOrKb1993/++/X2adfjJfj1dOzpHG+4NSk6ES3f/JoVqf5MfXKcPYm+lT3fKJfOdGvnO5B'
    'Trbos62ph/rMO/6IFJTBwHt1JWC3NhCi2Gk25JUSBhhSnNQbQYp2KQBK2ZCNBQ2d7T8PbOaZr1Og/sqhuvTcS689e903eiKfvv6+'
    '/nB+phfm3/TTudn1QWXsMuDiSaGzt1gd9dYJbIfg5x8Em6de9f7iE/qbNmhM/Zvg6TWVPiqvPx2ez5n3g3/93cofLujpw7W/bsJi'
    'EwgGGuAYyJj3rP6lC3WP/yX+UaidYfz7hyWkPwjO/6GE/xLCPSiO/vdIdxDqlPvDzbZ6Gi/P+Jvvf31c8Nensj1KSMXcJvBrJ1v/'
    'dx/d7gn65DbtHxaU/rKuqPrb+w83lpJOYox8T9C91nkPeqCj+DvvLA+yPpz9H3YN7NE='
)



def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def display_date(value):
    """Display stored ISO dates as DD-MM-YYYY."""
    raw = str(value or "").strip()
    if not raw: return ""
    try: return datetime.strptime(raw[:10], "%Y-%m-%d").strftime("%d-%m-%Y")
    except ValueError: return raw

def stored_date(value):
    """Accept DD-MM-YYYY (or legacy ISO) and return ISO for database storage."""
    raw = str(value or "").strip()
    for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try: return datetime.strptime(raw, fmt).strftime("%Y-%m-%d")
        except ValueError: pass
    raise ValueError("Enter the date as DD-MM-YYYY, for example 25-12-2026.")


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)
    return salt.hex() + "$" + digest.hex()


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, digest_hex = stored.split("$", 1)
        calculated = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 310_000)
        return hmac.compare_digest(calculated.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


class Store:
    def __init__(self) -> None:
        DATA_HOME.mkdir(parents=True, exist_ok=True)
        PHOTO_DIR.mkdir(parents=True, exist_ok=True)
        DOC_DIR.mkdir(parents=True, exist_ok=True)
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        self.conn = connect_database(DB_PATH, DATA_HOME)
        self.conn.row_factory = sqlite3.Row
        self._audit_lock = threading.RLock()
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA busy_timeout = 5000")
        try:
            self.conn.execute("PRAGMA journal_mode = WAL")
        except Exception:
            pass
        self._schema()
        self.ensure_admin_role_column()

    def _schema(self) -> None:
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            role TEXT NOT NULL DEFAULT 'Administrator'
        );
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_no TEXT NOT NULL UNIQUE COLLATE NOCASE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            preferred_name TEXT DEFAULT '',
            id_number TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            email TEXT DEFAULT '',
            address TEXT DEFAULT '',
            job_title TEXT DEFAULT '',
            department TEXT DEFAULT '',
            employment_status TEXT NOT NULL DEFAULT 'Active',
            start_date TEXT DEFAULT '',
            emergency_name TEXT DEFAULT '',
            emergency_relationship TEXT DEFAULT '',
            emergency_phone TEXT DEFAULT '',
            allergies TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            photo_path TEXT DEFAULT '',
            whatsapp_number TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS vision_conversations (
            actor TEXT PRIMARY KEY COLLATE NOCASE,
            messages_json TEXT NOT NULL DEFAULT '[]',
            updated_at TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT DEFAULT '',
            details TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS hr_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            record_type TEXT NOT NULL,
            title TEXT NOT NULL,
            date_from TEXT DEFAULT '',
            date_to TEXT DEFAULT '',
            status TEXT DEFAULT '',
            details TEXT DEFAULT '',
            field_a TEXT DEFAULT '',
            field_b TEXT DEFAULT '',
            quantity TEXT DEFAULT '',
            condition_issued TEXT DEFAULT '',
            condition_returned TEXT DEFAULT '',
            file_path TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_employees_name ON employees(last_name, first_name);
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
        CREATE INDEX IF NOT EXISTS idx_hr_employee_type ON hr_records(employee_id, record_type);
        CREATE TABLE IF NOT EXISTS attendance_punches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            biometric_id TEXT NOT NULL,
            punch_datetime TEXT NOT NULL,
            punch_type TEXT DEFAULT '',
            source_file TEXT DEFAULT '',
            raw_data TEXT DEFAULT '',
            imported_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE SET NULL,
            UNIQUE(biometric_id, punch_datetime, source_file)
        );
        CREATE TABLE IF NOT EXISTS attendance_daily (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            work_date TEXT NOT NULL,
            first_in TEXT DEFAULT '',
            last_out TEXT DEFAULT '',
            total_hours REAL DEFAULT 0,
            late_minutes INTEGER DEFAULT 0,
            early_minutes INTEGER DEFAULT 0,
            overtime_minutes INTEGER DEFAULT 0,
            status TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            adjusted_by TEXT DEFAULT '',
            adjusted_at TEXT DEFAULT '',
            source TEXT NOT NULL DEFAULT 'Biometric',
            UNIQUE(employee_id, work_date),
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS attendance_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_attendance_punch_datetime ON attendance_punches(punch_datetime);
        CREATE INDEX IF NOT EXISTS idx_attendance_daily_date ON attendance_daily(work_date);
        CREATE TABLE IF NOT EXISTS attendance_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attendance_daily_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            work_date TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(attendance_daily_id) REFERENCES attendance_daily(id) ON DELETE CASCADE,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_attendance_attachment_daily ON attendance_attachments(attendance_daily_id);
        CREATE TABLE IF NOT EXISTS leave_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            leave_type TEXT NOT NULL,
            date_from TEXT NOT NULL,
            date_to TEXT NOT NULL,
            days REAL NOT NULL DEFAULT 0,
            reason TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Pending',
            decision_by TEXT DEFAULT '',
            decision_at TEXT DEFAULT '',
            attachment_path TEXT DEFAULT '',
            attachment_name TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS employee_contracts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            contract_type TEXT NOT NULL DEFAULT 'Employment contract',
            title TEXT NOT NULL,
            start_date TEXT DEFAULT '',
            end_date TEXT DEFAULT '',
            probation_end TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Active',
            notes TEXT DEFAULT '',
            file_path TEXT DEFAULT '',
            file_name TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_contract_employee_dates
            ON employee_contracts(employee_id, start_date, end_date);
        CREATE TABLE IF NOT EXISTS performance_reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL,
            review_date TEXT NOT NULL, review_period TEXT DEFAULT '', reviewer TEXT DEFAULT '',
            overall_rating TEXT DEFAULT '', kpi_score REAL DEFAULT NULL, strengths TEXT DEFAULT '', improvement_areas TEXT DEFAULT '',
            goals TEXT DEFAULT '', employee_comments TEXT DEFAULT '', follow_up_date TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Draft', file_path TEXT DEFAULT '', file_name TEXT DEFAULT '',
            created_by TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_performance_employee_date ON performance_reviews(employee_id, review_date);
        CREATE TABLE IF NOT EXISTS employee_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            document_type TEXT NOT NULL DEFAULT 'Other',
            title TEXT NOT NULL,
            document_number TEXT DEFAULT '',
            issue_date TEXT DEFAULT '',
            expiry_date TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Current',
            notes TEXT DEFAULT '',
            file_path TEXT DEFAULT '',
            file_name TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_employee_documents_expiry
            ON employee_documents(employee_id, expiry_date, status);
        CREATE TABLE IF NOT EXISTS leave_balances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            leave_type TEXT NOT NULL,
            opening_days REAL NOT NULL DEFAULT 0,
            accrued_days REAL NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL,
            UNIQUE(employee_id, leave_type),
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_leave_employee_dates ON leave_records(employee_id, date_from, date_to);
        CREATE TABLE IF NOT EXISTS payroll_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            pay_period TEXT NOT NULL,
            pay_date TEXT DEFAULT '',
            basic_salary REAL DEFAULT 0,
            weekday_hours REAL DEFAULT 0,
            saturday_hours REAL DEFAULT 0,
            sunday_hours REAL DEFAULT 0,
            public_holiday_hours REAL DEFAULT 0,
            overtime REAL DEFAULT 0,
            allowances REAL DEFAULT 0,
            bonus REAL DEFAULT 0,
            gross_pay REAL DEFAULT 0,
            paye REAL DEFAULT 0,
            uif REAL DEFAULT 0,
            other_deductions REAL DEFAULT 0,
            total_deductions REAL DEFAULT 0,
            net_pay REAL DEFAULT 0,
            status TEXT DEFAULT 'Draft',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS payroll_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payroll_id INTEGER NOT NULL,
            employee_id INTEGER NOT NULL,
            file_path TEXT NOT NULL,
            file_name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(payroll_id) REFERENCES payroll_records(id) ON DELETE CASCADE,
            FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_payroll_employee_period ON payroll_records(employee_id, pay_period);
        CREATE INDEX IF NOT EXISTS idx_payroll_attachment_record ON payroll_attachments(payroll_id);
        """)
        defaults = {"shift_start":"09:00", "shift_end":"19:15", "grace_minutes":"10", "lunch_minutes":"15",
                    "pay_shift_start":"09:00", "pay_shift_end":"19:15", "pay_paid_lunch_minutes":"45",
                    "pay_unpaid_lunch_minutes":"15", "pay_weekday_rate":"400.00", "pay_saturday_rate":"450.00",
                    "pay_sunday_rate":"800.00", "pay_public_holiday_rate":"800.00"}
        for key, value in defaults.items():
            self.conn.execute("INSERT OR IGNORE INTO attendance_settings(key,value) VALUES(?,?)", (key, value))
        # Migrate existing payroll databases without disturbing saved records.
        for column in ("weekday_hours", "saturday_hours", "sunday_hours", "public_holiday_hours"):
            try:
                self.conn.execute(f"ALTER TABLE payroll_records ADD COLUMN {column} REAL DEFAULT 0")
            except sqlite3.OperationalError:
                pass
        # Add numeric KPI score to existing performance reviews without changing historic records.
        try:
            self.conn.execute("ALTER TABLE performance_reviews ADD COLUMN kpi_score REAL DEFAULT NULL")
        except sqlite3.OperationalError:
            pass
        # Preserve whether a daily attendance record was entered manually or derived from biometrics.
        try:
            self.conn.execute("ALTER TABLE attendance_daily ADD COLUMN source TEXT NOT NULL DEFAULT 'Biometric'")
        except sqlite3.OperationalError:
            pass
        # Safe additive migrations for payslip delivery and employer contributions.
        for table, column, declaration in (("employees", "whatsapp_number", "TEXT DEFAULT ''"), ("payroll_records", "employer_uif", "REAL DEFAULT 0"), ("payroll_records", "payslip_number", "TEXT DEFAULT ''"), ("payroll_records", "whatsapp_status", "TEXT DEFAULT ''"), ("payroll_records", "whatsapp_message_id", "TEXT DEFAULT ''"), ("payroll_records", "whatsapp_recipient", "TEXT DEFAULT ''"), ("payroll_records", "whatsapp_submitted_at", "TEXT DEFAULT ''"), ("payroll_records", "whatsapp_status_at", "TEXT DEFAULT ''")):
            try:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {declaration}")
            except sqlite3.OperationalError:
                pass
        self.conn.commit()
        try:
            self.conn.execute("ALTER TABLE employees ADD COLUMN biometric_id TEXT DEFAULT ''")
            self.conn.commit()
        except sqlite3.OperationalError:
            pass
        # Tamper-evident audit ledger: additive migration, preserving all historical rows.
        for column, declaration in (("prev_hash", "TEXT NOT NULL DEFAULT ''"), ("entry_hash", "TEXT NOT NULL DEFAULT ''")):
            try:
                self.conn.execute(f"ALTER TABLE audit_log ADD COLUMN {column} {declaration}")
            except sqlite3.OperationalError:
                pass
        self.conn.commit()
        self._backfill_audit_chain()
        self.conn.executescript("""
        CREATE TRIGGER IF NOT EXISTS audit_log_no_update BEFORE UPDATE ON audit_log
        BEGIN SELECT RAISE(ABORT, 'Audit records are append-only'); END;
        CREATE TRIGGER IF NOT EXISTS audit_log_no_delete BEFORE DELETE ON audit_log
        BEGIN SELECT RAISE(ABORT, 'Audit records are append-only'); END;
        """)
        self.conn.commit()

    @staticmethod
    def _audit_digest(row_values: dict, previous_hash: str) -> str:
        payload = {
            "id": int(row_values["id"]), "actor": str(row_values["actor"] or ""),
            "action": str(row_values["action"] or ""), "entity_type": str(row_values["entity_type"] or ""),
            "entity_id": str(row_values["entity_id"] or ""), "details": str(row_values["details"] or ""),
            "created_at": str(row_values["created_at"] or ""), "prev_hash": previous_hash,
        }
        canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _backfill_audit_chain(self) -> None:
        """Chain legacy audit rows once, then only append hashes for new entries."""
        previous = "0" * 64
        rows = self.conn.execute("SELECT * FROM audit_log ORDER BY id").fetchall()
        for row in rows:
            item = dict(row)
            if item.get("entry_hash"):
                previous = item["entry_hash"]
                continue
            digest = self._audit_digest(item, previous)
            self.conn.execute("UPDATE audit_log SET prev_hash=?, entry_hash=? WHERE id=?", (previous, digest, item["id"]))
            previous = digest
        self.conn.commit()

    def verify_audit_chain(self) -> dict:
        previous = "0" * 64
        checked = 0
        rows = self.conn.execute("SELECT * FROM audit_log ORDER BY id").fetchall()
        for row in rows:
            item = dict(row)
            expected = self._audit_digest(item, previous)
            if item.get("prev_hash") != previous or not hmac.compare_digest(item.get("entry_hash", ""), expected):
                return {"valid": False, "checked": checked, "total": len(rows), "first_invalid_id": item["id"],
                        "message": "Audit chain verification failed. One or more records may have been changed or removed."}
            previous = item["entry_hash"]
            checked += 1
        return {"valid": True, "checked": checked, "total": len(rows), "last_hash": previous,
                "message": "Audit chain verified. No changes detected in the recorded chain."}

    def ensure_admin_role_column(self) -> None:
        columns = {row[1] for row in self.conn.execute("PRAGMA table_info(admins)")}
        if "role" not in columns:
            self.conn.execute("ALTER TABLE admins ADD COLUMN role TEXT NOT NULL DEFAULT 'Administrator'")
            self.conn.commit()

    def admin_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) FROM admins WHERE active=1").fetchone()[0])

    def create_admin(self, full_name: str, username: str, password: str, role: str = "Administrator") -> None:
        allowed_roles = {"Administrator", "Manager", "Staff", "Caregiver"}
        role = role if role in allowed_roles else "Administrator"
        self.conn.execute("INSERT INTO admins(full_name,username,password_hash,created_at,role) VALUES(?,?,?,?,?)",
                          (full_name.strip(), username.strip(), hash_password(password), now_text(), role))
        self.conn.commit()
        flush_all()          # a new sign-in credential must survive a power cut

    def authenticate(self, username: str, password: str):
        row = self.conn.execute("SELECT * FROM admins WHERE username=? COLLATE NOCASE AND active=1", (username.strip(),)).fetchone()
        if row and verify_password(password, row["password_hash"]):
            return row
        return None

    def list_admins(self):
        return self.conn.execute("SELECT id, full_name, username, active, created_at, role FROM admins ORDER BY full_name COLLATE NOCASE").fetchall()

    def reset_admin_password(self, admin_id: int, new_password: str) -> None:
        self.conn.execute("UPDATE admins SET password_hash=? WHERE id=?", (hash_password(new_password), admin_id))
        self.conn.commit()
        flush_all()          # write the new credential now, not a few seconds later

    def delete_admin(self, admin_id: int) -> None:
        """Remove an account completely. Audit history is untouched."""
        self.conn.execute("DELETE FROM admin_permission_overrides WHERE admin_id=?", (admin_id,))
        self.conn.execute("DELETE FROM admins WHERE id=?", (admin_id,))
        self.conn.commit()

    def set_admin_active(self, admin_id: int, active: bool) -> None:
        self.conn.execute("UPDATE admins SET active=? WHERE id=?", (1 if active else 0, admin_id))
        self.conn.commit()

    def log(self, actor: str, action: str, entity_type: str, entity_id: str = "", details: str = "") -> None:
        # Serialize append operations so concurrent API requests cannot fork the chain.
        with self._audit_lock:
            previous_row = self.conn.execute("SELECT entry_hash FROM audit_log ORDER BY id DESC LIMIT 1").fetchone()
            previous = previous_row["entry_hash"] if previous_row and previous_row["entry_hash"] else "0" * 64
            created = now_text()
            next_id = int(self.conn.execute("SELECT COALESCE(MAX(id),0)+1 FROM audit_log").fetchone()[0])
            item = {"id": next_id, "actor": actor, "action": action, "entity_type": entity_type,
                    "entity_id": str(entity_id), "details": details, "created_at": created}
            digest = self._audit_digest(item, previous)
            self.conn.execute(
                "INSERT INTO audit_log(id,actor,action,entity_type,entity_id,details,created_at,prev_hash,entry_hash) VALUES(?,?,?,?,?,?,?,?,?)",
                (next_id, actor, action, entity_type, str(entity_id), details, created, previous, digest)
            )
            self.conn.commit()

    def employees(self, search: str = ""):
        term = f"%{search.strip()}%"
        return self.conn.execute("""SELECT * FROM employees
            WHERE employee_no LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR job_title LIKE ?
            ORDER BY last_name, first_name""", (term, term, term, term)).fetchall()

    def employee(self, employee_id: int):
        return self.conn.execute("SELECT * FROM employees WHERE id=?", (employee_id,)).fetchone()

    def save_employee(self, data: dict, employee_id: int | None, actor: str) -> int:
        stamp = now_text()
        fields = ["employee_no", "first_name", "last_name", "preferred_name", "id_number", "phone", "email",
                  "address", "job_title", "department", "employment_status", "start_date", "emergency_name",
                  "emergency_relationship", "emergency_phone", "allergies", "notes", "photo_path", "biometric_id", "whatsapp_number"]
        values = [data.get(k, "").strip() for k in fields]
        if employee_id is None:
            cols = ",".join(fields + ["created_at", "updated_at"])
            marks = ",".join(["?"] * (len(fields) + 2))
            cur = self.conn.execute(f"INSERT INTO employees({cols}) VALUES({marks})", values + [stamp, stamp])
            new_id = int(cur.lastrowid)
            self.log(actor, "Created employee", "employee", new_id, f"Employee no. {data.get('employee_no','')}")
            self.conn.commit()
            return new_id
        sets = ",".join(f"{k}=?" for k in fields) + ",updated_at=?"
        self.conn.execute(f"UPDATE employees SET {sets} WHERE id=?", values + [stamp, employee_id])
        self.log(actor, "Updated employee", "employee", employee_id, f"Employee no. {data.get('employee_no','')}")
        self.conn.commit()
        return employee_id

    def hr_records(self, employee_id: int, record_type: str):
        return self.conn.execute("SELECT * FROM hr_records WHERE employee_id=? AND record_type=? ORDER BY id DESC", (employee_id, record_type)).fetchall()

    def save_hr_record(self, employee_id: int, record_type: str, data: dict, actor: str, record_id: int | None = None) -> int:
        stamp = now_text()
        fields = ["title", "date_from", "date_to", "status", "details", "field_a", "field_b", "quantity", "condition_issued", "condition_returned", "file_path"]
        values = [str(data.get(k, "")).strip() for k in fields]
        if record_id is not None:
            sets = ",".join(f"{field}=?" for field in fields) + ",updated_at=?"
            self.conn.execute(f"UPDATE hr_records SET {sets} WHERE id=? AND employee_id=? AND record_type=?",
                              values + [stamp, int(record_id), employee_id, record_type])
            self.log(actor, "Updated HR record", record_type, int(record_id), f"Employee ID {employee_id}: {data.get('title', '')}; status: {data.get('status', '')}")
            saved_id = int(record_id)
        else:
            cur = self.conn.execute(
                "INSERT INTO hr_records(employee_id,record_type," + ",".join(fields) + ",created_at,updated_at) VALUES(" + ",".join(["?"] * (len(fields)+4)) + ")",
                [employee_id, record_type] + values + [stamp, stamp]
            )
            saved_id = int(cur.lastrowid)
            self.log(actor, "Added HR record", record_type, saved_id, f"Employee ID {employee_id}: {data.get('title', '')}")
        self.conn.commit()
        return saved_id

    def attendance_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM attendance_settings WHERE key=?", (key,)).fetchone()
        return str(row[0]) if row else default

    def set_attendance_setting(self, key: str, value: str) -> None:
        self.conn.execute("INSERT INTO attendance_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        self.conn.commit()

    def save_attendance_punch(self, biometric_id: str, punch_dt: str, employee_id, punch_type: str, source_file: str, raw_data: str):
        existing = self.conn.execute("SELECT id FROM attendance_punches WHERE biometric_id=? AND punch_datetime=?", (biometric_id, punch_dt)).fetchone()
        if existing:
            return int(existing[0]), False
        try:
            cur = self.conn.execute("INSERT INTO attendance_punches(employee_id,biometric_id,punch_datetime,punch_type,source_file,raw_data,imported_at) VALUES(?,?,?,?,?,?,?)",
                                    (employee_id, biometric_id, punch_dt, punch_type, source_file, raw_data, now_text()))
            return int(cur.lastrowid), True
        except sqlite3.IntegrityError:
            return None, False

    def rebuild_attendance(self, actor: str, employee_ids=None):
        start = self.attendance_setting("shift_start", "08:00")
        end = self.attendance_setting("shift_end", "17:00")
        grace = int(self.attendance_setting("grace_minutes", "10") or 0)
        lunch = int(self.attendance_setting("lunch_minutes", "60") or 0)
        where = ""; params=[]
        if employee_ids:
            marks = ",".join("?" for _ in employee_ids)
            where = f" WHERE employee_id IN ({marks})"; params = list(employee_ids)
        dates = self.conn.execute("SELECT DISTINCT employee_id, substr(punch_datetime,1,10) AS work_date FROM attendance_punches" + where, params).fetchall()
        for item in dates:
            eid, work_date = item[0], item[1]
            if eid is None: continue
            punches = self.conn.execute("SELECT punch_datetime FROM attendance_punches WHERE employee_id=? AND substr(punch_datetime,1,10)=? ORDER BY punch_datetime", (eid, work_date)).fetchall()
            if not punches: continue
            first = str(punches[0][0]); last = str(punches[-1][0])
            try:
                fi = datetime.fromisoformat(first); lo = datetime.fromisoformat(last)
                total = max(0, (lo-fi).total_seconds()/3600 - (lunch/60 if len(punches) >= 2 and (lo-fi).total_seconds()/3600 > 6 else 0))
                shift_start = datetime.fromisoformat(f"{work_date} {start}:00")
                shift_end = datetime.fromisoformat(f"{work_date} {end}:00")
                late = max(0, int((fi - shift_start).total_seconds()/60) - grace)
                early = max(0, int((shift_end - lo).total_seconds()/60))
                overtime = max(0, int((lo - shift_end).total_seconds()/60))
                status = "Present" if len(punches) >= 2 else "Missing punch"
                if work_date == datetime.now().strftime("%Y-%m-%d") and fi.date() == datetime.now().date():
                    pass
            except ValueError:
                total=0; late=0; early=0; overtime=0; status="Review"
            self.conn.execute("""INSERT INTO attendance_daily(employee_id,work_date,first_in,last_out,total_hours,late_minutes,early_minutes,overtime_minutes,status,notes)
                VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(employee_id,work_date) DO UPDATE SET first_in=excluded.first_in,last_out=excluded.last_out,total_hours=excluded.total_hours,late_minutes=excluded.late_minutes,early_minutes=excluded.early_minutes,overtime_minutes=excluded.overtime_minutes,status=excluded.status,source='Biometric' WHERE attendance_daily.source!='Manual'""",
                (eid, work_date, first, last, round(total,2), late, early, overtime, status, ""))
        self.conn.commit()
        if actor: self.log(actor, "Rebuilt attendance", "attendance", "", "Daily attendance recalculated from biometric punches")

    def attendance_daily(self, start_date="", end_date="", employee_id=None):
        sql = """SELECT d.*, e.employee_no, e.first_name, e.last_name FROM attendance_daily d JOIN employees e ON e.id=d.employee_id WHERE 1=1"""
        params=[]
        if start_date: sql += " AND d.work_date>=?"; params.append(start_date)
        if end_date: sql += " AND d.work_date<=?"; params.append(end_date)
        if employee_id: sql += " AND d.employee_id=?"; params.append(employee_id)
        sql += " ORDER BY d.work_date DESC, e.last_name, e.first_name"
        return self.conn.execute(sql, params).fetchall()

    def attendance_punches(self, employee_id=None, start_date="", end_date=""):
        sql = "SELECT p.*, e.employee_no, e.first_name, e.last_name FROM attendance_punches p LEFT JOIN employees e ON e.id=p.employee_id WHERE 1=1"
        params=[]
        if employee_id: sql += " AND p.employee_id=?"; params.append(employee_id)
        if start_date: sql += " AND substr(p.punch_datetime,1,10)>=?"; params.append(start_date)
        if end_date: sql += " AND substr(p.punch_datetime,1,10)<=?"; params.append(end_date)
        sql += " ORDER BY p.punch_datetime DESC"
        return self.conn.execute(sql, params).fetchall()

    def counts(self) -> dict:
        total = self.conn.execute("SELECT COUNT(*) FROM employees").fetchone()[0]
        active = self.conn.execute("SELECT COUNT(*) FROM employees WHERE employment_status='Active'").fetchone()[0]
        admins = self.conn.execute("SELECT COUNT(*) FROM admins WHERE active=1").fetchone()[0]
        payroll = self.conn.execute("SELECT COUNT(*) FROM payroll_records").fetchone()[0]
        return {"total": total, "active": active, "admins": admins, "payroll": payroll}

    def recent_audit(self, limit: int = 12):
        return self.conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()

    def backup(self) -> Path:
        """Create an encrypted database-only backup."""
        flush_all()          # the backup must contain every committed change
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = BACKUP_DIR / f"your-userd_registration_{stamp}.db"
        temp_db = BACKUP_DIR / f".backup_work_{stamp}.db"
        try:
            with sqlite3.connect(temp_db) as dest:
                self.conn.backup(dest)
            write_encrypted(target, self.conn._key, temp_db.read_bytes())
        finally:
            temp_db.unlink(missing_ok=True)
        return target

    def backup_bundle(self) -> Path:
        """Create a portable backup containing the database and employee files."""
        flush_all()          # the bundle must contain every committed change
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = BACKUP_DIR / f"your-userd_registration_full_{stamp}.zip"
        temp_db = BACKUP_DIR / f".backup_work_{stamp}.db"
        encrypted_db = None
        try:
            with sqlite3.connect(temp_db) as dest:
                self.conn.backup(dest)
            encrypted_db = BACKUP_DIR / f".backup_work_{stamp}.enc"
            write_encrypted(encrypted_db, self.conn._key, temp_db.read_bytes())
            with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                manifest = {"format":"Beyond Registration backup","version":2,"database_protection":"aes-gcm","created_at":datetime.now().isoformat(timespec="seconds"),"files":{}}
                sources=[(encrypted_db,"database/your-userd_registration.db"), (DATA_HOME / KEY_FILE,"database/database.key")]
                for folder, arcname in ((PHOTO_DIR, "EmployeePhotos"), (DOC_DIR, "EmployeeDocuments")):
                    if folder.exists():
                        for item in folder.rglob("*"):
                            if item.is_file():
                                sources.append((item,(Path(arcname)/item.relative_to(folder)).as_posix()))
                if CUSTOM_DICT_PATH.exists():
                    sources.append((CUSTOM_DICT_PATH,"custom_dictionary.txt"))
                for source, archive_name in sources:
                    archive.write(source,archive_name)
                    digest=hashlib.sha256()
                    with source.open("rb") as handle:
                        for chunk in iter(lambda:handle.read(1024*1024),b""):
                            digest.update(chunk)
                    manifest["files"][archive_name]=digest.hexdigest()
                archive.writestr("backup_manifest.json",json.dumps(manifest,indent=2))
            return target
        except Exception:
            try: target.unlink(missing_ok=True)
            except OSError: pass
            raise
        finally:
            try: temp_db.unlink(missing_ok=True)
            except OSError: pass
            if encrypted_db is not None:
                try: encrypted_db.unlink(missing_ok=True)
                except OSError: pass

    def restore_bundle(self, bundle_path: str | Path) -> Path:
        """Validate a full backup, make a safety backup, then restore its data."""
        bundle_path = Path(bundle_path)
        staging = DATA_HOME / f"restore_staging_{secrets.token_hex(4)}"
        staging.mkdir(parents=True, exist_ok=False)
        staged_db = staging / "your-userd_registration.db"
        try:
            with zipfile.ZipFile(bundle_path, "r") as archive:
                names = archive.namelist()
                if "database/your-userd_registration.db" not in names:
                    raise ValueError("This ZIP does not contain a Beyond Registration database backup.")
                # Verify checksums for new-format snapshots; legacy ZIPs remain restorable.
                if "backup_manifest.json" in names:
                    try:
                        manifest=json.loads(archive.read("backup_manifest.json").decode("utf-8"))
                        expected=manifest.get("files",{})
                        for member,digest in expected.items():
                            if member not in names or hashlib.sha256(archive.read(member)).hexdigest()!=digest:
                                raise ValueError(f"Backup integrity check failed for {member}. No data was restored.")
                    except (json.JSONDecodeError,KeyError,TypeError) as exc:
                        raise ValueError("The backup integrity manifest is invalid. No data was restored.") from exc
                # Reject unsafe archive paths before extracting anything.
                for name in names:
                    member = Path(name)
                    if member.is_absolute() or ".." in member.parts:
                        raise ValueError("The selected backup contains an unsafe file path and was not restored.")
                for name in names:
                    if name == "database/your-userd_registration.db":
                        payload = archive.read(name)
                        if payload.startswith(MAGIC):
                            if "database/database.key" in names:
                                backup_key = key_from_vault_bytes(archive.read("database/database.key"), staging)
                            else:
                                backup_key = load_or_create_key(DATA_HOME)
                            payload = decrypt_payload(payload, backup_key)
                        staged_db.write_bytes(payload)
                    elif name == "database/database.key" or name == "backup_manifest.json":
                        continue
                    elif name == "custom_dictionary.txt":
                        archive.extract(name, staging)
                    elif name.startswith("EmployeePhotos/") or name.startswith("EmployeeDocuments/"):
                        archive.extract(name, staging)
            if not staged_db.exists():
                raise ValueError("The database file could not be read from this backup.")
            with sqlite3.connect(staged_db) as check:
                result = check.execute("PRAGMA integrity_check").fetchone()[0]
                has_employees = check.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='employees'").fetchone()
                if result != "ok" or not has_employees:
                    raise ValueError("The backup database failed validation. Your current data has not been changed.")
            safety_copy = self.backup_bundle()
            self.conn.execute("PRAGMA wal_checkpoint(FULL)")
            self.conn.close()
            try:
                for suffix in ("-wal", "-shm"):
                    try: Path(str(DB_PATH) + suffix).unlink(missing_ok=True)
                    except OSError: pass
                write_encrypted(DB_PATH, load_or_create_key(DATA_HOME), staged_db.read_bytes())
                self.conn = connect_database(DB_PATH, DATA_HOME)
                self.conn.row_factory = sqlite3.Row
                self.conn.execute("PRAGMA foreign_keys = ON")
                self.conn.execute("PRAGMA journal_mode = MEMORY")
                self._schema()
                for folder_name, target_folder in (("EmployeePhotos", PHOTO_DIR), ("EmployeeDocuments", DOC_DIR)):
                    source_folder = staging / folder_name
                    if source_folder.exists():
                        for item in source_folder.rglob("*"):
                            if item.is_file():
                                dest = target_folder / item.relative_to(source_folder)
                                dest.parent.mkdir(parents=True, exist_ok=True)
                                shutil.copy2(item, dest)
                dictionary = staging / "custom_dictionary.txt"
                if dictionary.exists():
                    shutil.copy2(dictionary, CUSTOM_DICT_PATH)
            except Exception:
                # Keep the app usable if the restore operation itself fails: reopen
                # the database, and if it cannot be opened, roll back to the safety copy.
                try:
                    self.conn.close()
                except Exception: pass
                try:
                    self.conn = connect_database(DB_PATH, DATA_HOME)
                    self.conn.row_factory = sqlite3.Row
                    self.conn.execute("PRAGMA foreign_keys = ON")
                    self.conn.execute("PRAGMA journal_mode = MEMORY")
                    self._schema()
                except Exception:
                    try:
                        self.restore_bundle(safety_copy)
                    except Exception:
                        pass
                raise
            return safety_copy
        finally:
            shutil.rmtree(staging, ignore_errors=True)


_SPELL_WORDS = None
_SPELL_LOCK = threading.Lock()
COMMON_SPELLING_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "can", "for", "from",
    "had", "has", "have", "he", "her", "his", "if", "in", "is", "it", "its", "not", "of",
    "on", "or", "our", "she", "that", "the", "their", "them", "there", "they", "this",
    "to", "was", "we", "were", "what", "when", "which", "who", "will", "with", "you",
    "your",
}


def load_spell_words():
    """Load the offline dictionary once and share it with every text field."""
    global _SPELL_WORDS
    with _SPELL_LOCK:
        if _SPELL_WORDS is None:
            try:
                raw = zlib.decompress(base64.b64decode(SPELLING_DATA_B64.encode("ascii"))).decode("utf-8")
                words = {line.strip().lower() for line in raw.splitlines() if line.strip()}
            except Exception:
                words = set()
            try:
                if CUSTOM_DICT_PATH.exists():
                    words.update(line.strip().lower() for line in CUSTOM_DICT_PATH.read_text(encoding="utf-8").splitlines() if line.strip())
            except OSError:
                pass
            words.update(COMMON_SPELLING_WORDS)
            _SPELL_WORDS = words
        return _SPELL_WORDS


def spelling_help(word, limit=5):
    """Return close dictionary words and one correction when the typo is obvious."""
    clean = re.sub(r"[^A-Za-z]", "", str(word or "")).lower()
    words = load_spell_words()
    if not clean or len(clean) <= 1 or clean in words:
        return {"word": clean, "correct": True, "suggestions": [], "correction": ""}
    candidates = [item for item in words if item[:1] == clean[:1] and abs(len(item) - len(clean)) <= 2]
    if not candidates:
        candidates = [item for item in words if abs(len(item) - len(clean)) <= 1]
    def similarity(typed, candidate):
        if len(typed) == len(candidate):
            for index in range(len(typed) - 1):
                if typed[:index] + typed[index + 1] + typed[index] + typed[index + 2:] == candidate:
                    return 0.92
        return difflib.SequenceMatcher(None, typed, candidate).ratio()

    ranked = []
    for item in candidates:
        ratio = similarity(clean, item)
        if ratio < 0.62:
            continue
        if len(item) < len(clean):
            ratio -= 0.12
        ranked.append((ratio, item))
    ranked.sort(key=lambda pair: (-pair[0], pair[1]))
    suggestions = [item for _ratio, item in ranked[:limit]]
    correction = ""
    if ranked:
        best_ratio, best_word = ranked[0]
        second_ratio = ranked[1][0] if len(ranked) > 1 else 0
        if best_ratio >= 0.72 and best_ratio - second_ratio >= 0.04 and len(best_word) >= len(clean) - 1:
            correction = best_word
    return {"word": clean, "correct": False, "suggestions": suggestions, "correction": correction}


def add_custom_spelling(word):
    clean = re.sub(r"[^A-Za-z'-]", "", str(word or "")).lower()
    if len(clean) < 2:
        raise ValueError("Enter a word to add to the dictionary.")
    words = load_spell_words()
    words.add(clean)
    try:
        CUSTOM_DICT_PATH.parent.mkdir(parents=True, exist_ok=True)
        existing = set()
        if CUSTOM_DICT_PATH.exists():
            existing = {line.strip().lower() for line in CUSTOM_DICT_PATH.read_text(encoding="utf-8").splitlines() if line.strip()}
        existing.add(clean)
        CUSTOM_DICT_PATH.write_text("\n".join(sorted(existing)) + "\n", encoding="utf-8")
    except OSError:
        pass
    return clean


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1180x760")
        self.minsize(980, 640)
        self.configure(bg=BG)
        self.store = Store()
        self.actor = ""
        # CORTEX runs entirely on this PC through local Ollama. There is no hosted
        # service, no API key and no subscription: an empty URL is the normal,
        # correct state until an owner explicitly points it at a local server.
        self.vision_server_url = os.environ.get("VISION_SERVER_URL", "").strip().rstrip("/")
        self.vision_access_token = ""
        self.vision_history = []
        self.vision_busy = False
        self.appearance_path = DATA_HOME / "appearance.json"
        self.appearance = dict(ORIGINAL_APPEARANCE)
        try:
            saved = json.loads(self.appearance_path.read_text(encoding="utf-8"))
            for key in self.appearance:
                value = saved.get(key)
                if isinstance(value, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", value):
                    self.appearance[key] = value
        except (OSError, ValueError, TypeError):
            pass
        # Version 3 adopts the new dark, luminous interface as the default visual system.
        self.appearance = dict(ORIGINAL_APPEARANCE)
        self._style()
        self._setup_editing_tools()
        self.protocol("WM_DELETE_WINDOW", self._close)
        if self.store.admin_count() == 0:
            self.show_first_run()
        else:
            self.show_login()

    def _style(self):
        """Apply the modern glass-inspired visual system consistently."""
        pal = self.appearance
        self.configure(bg=pal["background"])
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", font=("Segoe UI", 10))
        style.configure("TFrame", background=pal["background"])
        style.configure("Fun.TFrame", background=pal["background"])
        style.configure("Card.TFrame", background=pal["card"], relief="flat", borderwidth=0)
        style.configure("TLabel", background=pal["background"], foreground=pal["text"], font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 25, "bold"), foreground=pal["text"], background=pal["background"])
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#9bb6cc", background=pal["background"])
        style.configure("CardTitle.TLabel", font=("Segoe UI", 11, "bold"), foreground=pal["text"], background=pal["card"])
        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=(14, 10), background=pal["card"], foreground=pal["text"], borderwidth=0, focusthickness=0)
        style.map("TButton", background=[("active", "#173d59"), ("pressed", "#10243d")], foreground=[("disabled", "#60758b")])
        style.configure("Primary.TButton", background=pal["button"], foreground=WHITE, padding=(16, 11), font=("Segoe UI", 10, "bold"), borderwidth=0)
        style.map("Primary.TButton", background=[("active", pal["accent"]), ("pressed", pal["sidebar"])], foreground=[("active", WHITE)])
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=39, background=pal["card"], fieldbackground=pal["card"], foreground=pal["text"], borderwidth=0, relief="flat")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), padding=(11, 12), background=pal["tabs"], foreground=pal["text"], borderwidth=0)
        style.map("Treeview", background=[("selected", "#16445b")], foreground=[("selected", "#ffffff")])
        style.configure("TNotebook", background=pal["background"], borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(16, 11), background=pal["tabs"], foreground="#69718a", borderwidth=0)
        style.map("TNotebook.Tab", background=[("selected", pal["card"]), ("active", "#173d59")], foreground=[("selected", "#22d3ee")])
        style.configure("TEntry", padding=(10, 9), fieldbackground=pal["card"], borderwidth=1)
        style.configure("TCombobox", padding=(9, 8), fieldbackground=pal["card"], borderwidth=1)
        style.configure("TCheckbutton", background=pal["background"], foreground=pal["text"], font=("Segoe UI", 10))
        style.configure("TRadiobutton", background=pal["background"], foreground=pal["text"], font=("Segoe UI", 10))
        style.configure("Vertical.TScrollbar", background=pal["background"], troughcolor=pal["background"], borderwidth=0, arrowsize=12)

    def _set_appearance(self, palette, save=False, redraw=True):
        """Apply a validated palette; save preferences separately from business data."""
        updated = dict(ORIGINAL_APPEARANCE)
        updated.update({k: v for k, v in palette.items() if k in updated and isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v)})
        self.appearance = updated
        self._style()
        if save:
            try:
                DATA_HOME.mkdir(parents=True, exist_ok=True)
                self.appearance_path.write_text(json.dumps(updated, indent=2), encoding="utf-8")
            except OSError as exc:
                messagebox.showerror("Appearance not saved", f"The appearance was applied for this session, but could not be saved:\n{exc}")
        if redraw and getattr(self, "actor", ""):
            self.show_design_studio()

    def show_design_studio(self):
        self._shell("Design Studio")
        ttk.Label(self.content, text="Design Studio", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Change the programme's colours whenever you like. Your settings are stored on this computer and do not change employee, payroll or other business records.", style="Sub.TLabel", wraplength=850).pack(anchor="w", pady=(5, 18))

        presets = {
            "Modern glass (2026)": dict(ORIGINAL_APPEARANCE),
            "Original (classic)": {"background":"#f4f6f8", "sidebar":"#26384a", "accent":"#2563eb", "button":"#2563eb", "tabs":"#e5e7eb", "text":"#243041", "card":"#ffffff"},
            "Ocean blue": {"background":"#edf5fb", "sidebar":"#173b57", "accent":"#168aad", "button":"#1677b8", "tabs":"#d8eaf5", "text":"#203447", "card":"#ffffff"},
            "Forest green": {"background":"#f0f6f0", "sidebar":"#214b3a", "accent":"#2f855a", "button":"#2f855a", "tabs":"#dcebe0", "text":"#23382d", "card":"#ffffff"},
            "Warm sunset": {"background":"#fff7ed", "sidebar":"#713f12", "accent":"#ea580c", "button":"#c2410c", "tabs":"#ffedd5", "text":"#422006", "card":"#ffffff"},
            "Lavender": {"background":"#f7f4fc", "sidebar":"#493568", "accent":"#8b5cf6", "button":"#7c3aed", "tabs":"#ede4fa", "text":"#352747", "card":"#ffffff"},
            "Dark slate": {"background":"#e8edf2", "sidebar":"#18212b", "accent":"#3b82f6", "button":"#2563eb", "tabs":"#d5dde6", "text":"#1f2937", "card":"#ffffff"},
        }
        selected = tk.StringVar(value="Custom colours")
        current = dict(self.appearance)
        fields = [("background", "Main background"), ("sidebar", "Sidebar / header"), ("accent", "Accent colour"), ("button", "Main buttons"), ("tabs", "Tabs / table headings"), ("text", "Text"), ("card", "Cards / panels")]
        panel = ttk.Frame(self.content, style="Card.TFrame", padding=18)
        panel.pack(fill="x", pady=(0, 14))
        ttk.Label(panel, text="Choose a ready-made theme", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 8))
        choice = ttk.Combobox(panel, textvariable=selected, values=list(presets) + ["Custom colours"], state="readonly", width=28)
        choice.pack(anchor="w")
        colors = ttk.Frame(self.content, style="Card.TFrame", padding=18)
        colors.pack(fill="x")
        ttk.Label(colors, text="Fine-tune individual colours", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 10))
        swatches = {}
        def paint_swatch(key):
            swatches[key].configure(text=current[key], background=current[key], activebackground=current[key])
        def choose_color(key):
            picked = colorchooser.askcolor(color=current[key], parent=self, title=f"Choose {key} colour")[1]
            if picked:
                current[key] = picked
                selected.set("Custom colours")
                paint_swatch(key)
        for idx, (key, label) in enumerate(fields, start=1):
            r = (idx - 1) // 2 + 1
            c = ((idx - 1) % 2) * 2
            ttk.Label(colors, text=label).grid(row=r, column=c, sticky="w", padx=(0, 12), pady=7)
            swatches[key] = tk.Button(colors, text=current[key], command=lambda k=key: choose_color(k), width=12, relief="raised", bd=2, cursor="hand2")
            swatches[key].grid(row=r, column=c+1, sticky="w", padx=(0, 24), pady=7)
            paint_swatch(key)
        def preset_changed(_event=None):
            name = selected.get()
            if name in presets:
                current.clear(); current.update(presets[name])
                for key, _label in fields: paint_swatch(key)
        choice.bind("<<ComboboxSelected>>", preset_changed)
        actions = ttk.Frame(self.content)
        actions.pack(fill="x", pady=16)
        ttk.Button(actions, text="Preview", style="Primary.TButton", command=lambda: self._set_appearance(current, save=False, redraw=True)).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Apply and save", style="Primary.TButton", command=lambda: self._set_appearance(current, save=True, redraw=True)).pack(side="left", padx=8)
        def restore_original():
            current.clear(); current.update(ORIGINAL_APPEARANCE)
            selected.set("Original (classic)")
            for key, _label in fields: paint_swatch(key)
            self._set_appearance(ORIGINAL_APPEARANCE, save=True, redraw=True)
        ttk.Button(actions, text="Restore original appearance", command=restore_original).pack(side="left", padx=8)
        ttk.Label(self.content, text="Tip: Preview is temporary. Use Apply and save to keep your choices after closing the programme.", style="Sub.TLabel", wraplength=850).pack(anchor="w")

    def _setup_editing_tools(self):
        """Install application-wide editing and spelling assistance."""
        self._spell_words = load_spell_words()

        # Standard Windows-style right-click editing menus for Tk/ttk text controls.
        for widget_class in ("Entry", "TEntry", "TCombobox", "Text"):
            self.bind_class(widget_class, "<Button-3>", self._show_edit_menu, add="+")
        for widget_class in ("Entry", "TEntry", "TCombobox"):
            self.bind_class(widget_class, "<KeyRelease>", self._entry_spell_event, add="+")
        self.bind_class("Text", "<KeyRelease>", self._text_spell_event, add="+")
        self.bind_class("Text", "<ButtonRelease-1>", self._text_spell_event, add="+")

    def _is_password_widget(self, widget):
        try:
            return bool(widget.cget("show"))
        except (tk.TclError, TypeError):
            return False

    def _clipboard_text(self, widget):
        try:
            return self.clipboard_get()
        except tk.TclError:
            return ""

    def _replace_selection_with(self, widget, text):
        try:
            if isinstance(widget, tk.Text):
                try:
                    widget.delete("sel.first", "sel.last")
                except tk.TclError:
                    pass
                widget.insert("insert", text)
            else:
                try:
                    start = widget.index("sel.first")
                    end = widget.index("sel.last")
                    widget.delete(start, end)
                except tk.TclError:
                    pass
                widget.insert(widget.index("insert"), text)
        except tk.TclError:
            pass

    def _show_edit_menu(self, event):
        widget = event.widget
        if not isinstance(widget, (tk.Text, tk.Entry)) and widget.winfo_class() not in ("TEntry",):
            return "break"

        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Undo", command=lambda: self._edit_action(widget, "<<Undo>>"))
        menu.add_separator()
        menu.add_command(label="Cut", command=lambda: self._edit_action(widget, "<<Cut>>"))
        menu.add_command(label="Copy", command=lambda: self._edit_action(widget, "<<Copy>>"))
        menu.add_command(label="Paste", command=lambda: self._edit_action(widget, "<<Paste>>"))
        menu.add_command(label="Paste as plain text", command=lambda: self._replace_selection_with(widget, self._clipboard_text(widget)))
        menu.add_separator()
        menu.add_command(label="Select All", command=lambda: self._edit_select_all(widget))

        # Add spelling suggestions for the word under the mouse/cursor.
        word = self._word_at_event(widget, event)
        if word and not self._word_is_correct(word):
            suggestions = self._suggest_words(word, 5)
            if suggestions:
                menu.add_separator()
                menu.add_command(label=f"Spelling: {word}", state="disabled")
                for suggestion in suggestions:
                    menu.add_command(label=f"Replace with '{suggestion}'", command=lambda sug=suggestion: self._replace_word(widget, event, word, sug))
                menu.add_command(label="Add to dictionary", command=lambda w=word: self._add_to_dictionary(w))
            else:
                # Still offer the dictionary option when a word has no close match.
                menu.add_separator()
                menu.add_command(label=f"Spelling: {word}", state="disabled")
                menu.add_command(label="Add to dictionary", command=lambda w=word: self._add_to_dictionary(w))

        menu.tk_popup(event.x_root, event.y_root)
        menu.grab_release()
        return "break"

    def _add_to_dictionary(self, word):
        add_custom_spelling(word)

    def _edit_action(self, widget, sequence):
        try:
            widget.event_generate(sequence)
        except tk.TclError:
            pass

    def _edit_select_all(self, widget):
        try:
            if isinstance(widget, tk.Text):
                widget.tag_add("sel", "1.0", "end-1c")
                widget.mark_set("insert", "1.0")
            else:
                widget.select_range(0, "end")
                widget.icursor("end")
        except tk.TclError:
            pass

    def _word_at_event(self, widget, event):
        try:
            if isinstance(widget, tk.Text):
                index = widget.index(f"@{event.x},{event.y}")
                line = widget.get(f"{index} linestart", f"{index} lineend")
                col = int(widget.index(index).split(".")[1])
                matches = list(re.finditer(r"[A-Za-z][A-Za-z'-]*", line))
                for m in matches:
                    if m.start() <= col <= m.end():
                        return m.group(0)
            else:
                idx = int(widget.index(f"@{event.x}"))
                value = widget.get()
                for m in re.finditer(r"[A-Za-z][A-Za-z'-]*", value):
                    if m.start() <= idx <= m.end():
                        return m.group(0)
        except (tk.TclError, ValueError, IndexError):
            return ""
        return ""

    def _current_entry_word(self, widget):
        try:
            pos = int(widget.index("insert"))
            value = widget.get()
            for m in re.finditer(r"[A-Za-z][A-Za-z'-]*", value):
                if m.start() <= pos <= m.end():
                    return m.group(0)
        except (tk.TclError, ValueError):
            pass
        return ""

    def _word_is_correct(self, word):
        clean = re.sub(r"[^A-Za-z]", "", word).lower()
        if not clean or len(clean) <= 1 or clean.isdigit():
            return True
        return clean in self._spell_words

    def _suggest_words(self, word, limit=5):
        return spelling_help(word, limit).get("suggestions", [])

    def _replace_word(self, widget, event, old_word, new_word):
        try:
            if isinstance(widget, tk.Text):
                index = widget.index(f"@{event.x},{event.y}")
                line = widget.get(f"{index} linestart", f"{index} lineend")
                col = int(widget.index(index).split(".")[1])
                m = next((m for m in re.finditer(r"[A-Za-z][A-Za-z'-]*", line) if m.start() <= col <= m.end()), None)
                if m:
                    start = f"{index} linestart + {m.start()} chars"
                    end = f"{index} linestart + {m.end()} chars"
                    widget.delete(start, end)
                    widget.insert(start, new_word)
            else:
                value = widget.get()
                pos = int(widget.index("insert"))
                m = next((m for m in re.finditer(r"[A-Za-z][A-Za-z'-]*", value) if m.start() <= pos <= m.end()), None)
                if m:
                    widget.delete(m.start(), m.end())
                    widget.insert(m.start(), new_word)
        except (tk.TclError, ValueError):
            pass

    def _entry_spell_event(self, event):
        widget = event.widget
        if self._is_password_widget(widget):
            return
        word = self._current_entry_word(widget)
        misspelled = bool(word and not self._word_is_correct(word))
        try:
            widget.configure(foreground="#dc2626" if misspelled else TEXT)
        except tk.TclError:
            pass

    def _text_spell_event(self, event):
        widget = event.widget
        if not isinstance(widget, tk.Text):
            return
        if getattr(widget, "_spell_after_id", None):
            try:
                widget.after_cancel(widget._spell_after_id)
            except tk.TclError:
                pass
        widget._spell_after_id = widget.after(120, lambda w=widget: self._spellcheck_text(w))

    def _spellcheck_text(self, widget):
        if not widget.winfo_exists():
            return
        try:
            widget.tag_configure("misspelled", foreground="#dc2626", underline=True)
            widget.tag_remove("misspelled", "1.0", "end")
            content = widget.get("1.0", "end-1c")
            for match in re.finditer(r"[A-Za-z][A-Za-z'-]*", content):
                word = match.group(0)
                if not self._word_is_correct(word):
                    start = f"1.0 + {match.start()} chars"
                    end = f"1.0 + {match.end()} chars"
                    widget.tag_add("misspelled", start, end)
        except tk.TclError:
            pass

    def clear(self):
        for child in self.winfo_children():
            child.destroy()

    def show_first_run(self):
        self.clear()
        outer = ttk.Frame(self, padding=32)
        outer.place(relx=0.5, rely=0.5, anchor="center", width=640)
        ttk.Label(outer, text="Welcome to Beyond Registration", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="First-time setup · Create the two administrator accounts", style="Sub.TLabel").pack(anchor="w", pady=(6, 20))
        card = ttk.Frame(outer, style="Card.TFrame", padding=24)
        card.pack(fill="x")
        ttk.Label(card, text="Administrator 1", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 8))
        dean_name = self._field(card, "Full name", "Dean")
        dean_user = self._field(card, "Username", "dean")
        dean_pass = self._field(card, "Password (minimum 4 characters)", secret=True)
        ttk.Separator(card).pack(fill="x", pady=18)
        ttk.Label(card, text="Administrator 2", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 8))
        hei_name = self._field(card, "Full name", "Heidelise")
        hei_user = self._field(card, "Username", "heidelise")
        hei_pass = self._field(card, "Password (minimum 4 characters)", secret=True)
        ttk.Label(outer, text="Passwords are stored as salted hashes. Choose unique passwords and keep them private.", style="Sub.TLabel", wraplength=600).pack(anchor="w", pady=12)

        def create():
            fields = [dean_name.get().strip(), dean_user.get().strip(), dean_pass.get(), hei_name.get().strip(), hei_user.get().strip(), hei_pass.get()]
            if not all(fields):
                messagebox.showwarning("Missing information", "Complete all six fields before continuing.")
                return
            if len(dean_pass.get()) < 4 or len(hei_pass.get()) < 4:
                messagebox.showwarning("Password too short", "Both passwords must be at least 4 characters long.")
                return
            if dean_user.get().strip().casefold() == hei_user.get().strip().casefold():
                messagebox.showwarning("Usernames must differ", "Choose a different username for each administrator.")
                return
            try:
                self.store.create_admin(dean_name.get(), dean_user.get(), dean_pass.get())
                self.store.create_admin(hei_name.get(), hei_user.get(), hei_pass.get())
                self.store.log("System", "Initial setup completed", "system", "", "Two administrator accounts created")
            except sqlite3.IntegrityError:
                messagebox.showerror("Setup error", "A username already exists. Restart the application and choose unique usernames.")
                return
            messagebox.showinfo("Setup complete", "Administrator accounts created. Please sign in.")
            self.show_login()

        ttk.Button(outer, text="Create administrator accounts", style="Primary.TButton", command=create).pack(anchor="e")

    def _field(self, parent, label, default="", secret=False):
        wrap = ttk.Frame(parent, style="Card.TFrame")
        wrap.pack(fill="x", pady=5)
        ttk.Label(wrap, text=label, style="Sub.TLabel").pack(anchor="w")
        entry = ttk.Entry(wrap, show="•" if secret else "")
        entry.pack(fill="x", pady=(3, 0))
        if default:
            entry.insert(0, default)
        return entry

    def show_login(self):
        self.clear()
        outer = ttk.Frame(self, padding=34)
        outer.place(relx=0.5, rely=0.5, anchor="center", width=460)
        ttk.Label(outer, text="Beyond Registration", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="Full Business Profile Solution", style="Sub.TLabel").pack(anchor="w", pady=(4, 20))
        card = ttk.Frame(outer, style="Card.TFrame", padding=24)
        card.pack(fill="x")
        usernames = [row["username"] for row in self.store.list_admins() if row["active"]]
        ttk.Label(card, text="Username", style="Sub.TLabel").pack(anchor="w")
        username = ttk.Combobox(card, values=usernames, state="normal")
        username.pack(fill="x", pady=(3, 8))
        password = self._field(card, "Password", secret=True)
        show_password = tk.BooleanVar(value=False)
        def toggle_password():
            password.configure(show="" if show_password.get() else "•")
        ttk.Checkbutton(card, text="Show password", variable=show_password, command=toggle_password).pack(anchor="w", pady=(2, 4))
        password.bind("<Return>", lambda _e: login())

        def login():
            row = self.store.authenticate(username.get(), password.get())
            if not row:
                messagebox.showerror("Sign-in failed", "The username or password is incorrect.")
                password.delete(0, "end")
                return
            self.actor = row["full_name"]
            self.current_username = row["username"]
            self.store.log(self.actor, "Signed in", "session", row["id"])
            self.show_dashboard()

        ttk.Button(card, text="Sign in", style="Primary.TButton", command=login).pack(fill="x", pady=(18, 4))
        ttk.Label(outer, text=f"Version {APP_VERSION}  ·  Company reg. {COMPANY_REG}", style="Sub.TLabel").pack(anchor="w", pady=12)
        username.focus_set()

    def _vision_send_prompt(self, prompt, status_widget=None, reply_widget=None, send_button=None):
        """Send a message to Vision from any screen; responses return on the Tk UI thread."""
        prompt = (prompt or "").strip()
        if not prompt or self.vision_busy:
            return False
        self.vision_history.append({"role": "user", "content": prompt})
        self.vision_busy = True
        try:
            if status_widget is not None:
                status_widget.configure(text="Vision is thinking…")
            if send_button is not None:
                send_button.configure(state="disabled")
        except tk.TclError:
            pass

        business_context = self._vision_business_context()
        history_snapshot = list(self.vision_history[:-1])

        def completed(answer, error):
            self.vision_history.append({"role": "assistant", "content": answer})
            self.vision_busy = False
            try:
                if reply_widget is not None and reply_widget.winfo_exists():
                    reply_widget.configure(text=answer)
                if status_widget is not None and status_widget.winfo_exists():
                    status_widget.configure(text=(error + " · Check Vision settings" if error else "Vision is active · Ready for your next question"))
                if send_button is not None and send_button.winfo_exists():
                    send_button.configure(state="normal")
            except tk.TclError:
                pass

        threading.Thread(
            target=self._vision_request,
            args=(prompt, completed, business_context, history_snapshot),
            daemon=True
        ).start()
        return True

    def _build_vision_dock(self, parent):
        """Keep a single floating Vision launcher visible throughout the signed-in workspace."""
        launcher = tk.Frame(parent, bg=self.appearance["background"])
        launcher.place(relx=1.0, rely=1.0, anchor="se", x=-24, y=-20)
        button = tk.Button(
            launcher, text="✦  Ask Vision", command=self._open_vision_popup,
            relief="flat", bd=0, bg="#08bcd4", fg="#031321",
            activebackground="#38e6f2", activeforeground="#031321",
            font=("Segoe UI", 11, "bold"), padx=22, pady=13,
            cursor="hand2", highlightthickness=0
        )
        button.pack()
        self.vision_launcher = launcher

    def _open_vision_popup(self):
        """Open a focused floating assistant window with text and optional voice input."""
        existing = getattr(self, "vision_popup", None)
        if existing is not None:
            try:
                if existing.winfo_exists():
                    existing.deiconify()
                    existing.lift()
                    existing.focus_force()
                    return
            except tk.TclError:
                pass

        win = tk.Toplevel(self)
        self.vision_popup = win
        win.title("Vision · Beyond Registration")
        win.geometry("650x620")
        win.minsize(520, 460)
        win.configure(bg="#07152a")
        win.transient(self)
        win.attributes("-topmost", True)
        win.after(500, lambda: win.attributes("-topmost", False))

        header = tk.Frame(win, bg="#0b2038", padx=20, pady=15)
        header.pack(fill="x")
        tk.Label(header, text="✦  VISION", bg="#0b2038", fg="#21d9e8",
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(header, text="Your personal AI · Beyond Registration",
                 bg="#0b2038", fg="#b7d2e8", font=("Segoe UI", 9)).pack(anchor="w", pady=(3, 0))

        transcript_frame = tk.Frame(win, bg="#07152a", padx=16, pady=14)
        transcript_frame.pack(fill="both", expand=True)
        transcript = tk.Text(transcript_frame, wrap="word", bg="#0b1b31", fg="#e8f4ff",
                             insertbackground="#ffffff", relief="flat", bd=0,
                             padx=16, pady=14, font=("Segoe UI", 10), state="disabled")
        scroll = ttk.Scrollbar(transcript_frame, orient="vertical", command=transcript.yview)
        transcript.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        transcript.pack(side="left", fill="both", expand=True)
        transcript.tag_configure("vision", foreground="#27d8e7", font=("Segoe UI", 10, "bold"), spacing1=7)
        transcript.tag_configure("you", foreground="#9a9dff", font=("Segoe UI", 10, "bold"), spacing1=7)
        transcript.tag_configure("body", foreground="#e8f4ff", spacing3=10)

        def add_message(who, body):
            transcript.configure(state="normal")
            transcript.insert("end", who + "\n", "vision" if who == "VISION" else "you")
            transcript.insert("end", body.strip() + "\n\n", "body")
            transcript.configure(state="disabled")
            transcript.see("end")

        if not self.vision_history:
            add_message("VISION", f"Hello {self.actor}. I'm here. Ask me about Beyond Registration, your people, operations or business performance.")
        else:
            for item in self.vision_history:
                add_message("YOU" if item["role"] == "user" else "VISION", item["content"])

        status = tk.Label(win, text="Vision is ready · Approved business snapshot is shared with the hosted Vision service",
                          bg="#07152a", fg="#8faec8", anchor="w",
                          font=("Segoe UI", 9), padx=18)
        status.pack(fill="x")

        composer = tk.Frame(win, bg="#0b2038", padx=14, pady=14)
        composer.pack(fill="x")
        prompt_var = tk.StringVar()
        entry = tk.Entry(composer, textvariable=prompt_var, bg="#102943", fg="#f2f8ff",
                         insertbackground="#ffffff", relief="flat", bd=0,
                         font=("Segoe UI", 11))
        entry.pack(side="left", fill="x", expand=True, ipady=12, padx=(0, 8))
        entry.focus_set()
        send_button = tk.Button(composer, text="Send  ➤", relief="flat", bd=0,
                                 bg="#10c5dc", fg="#031321", activebackground="#5cebf4",
                                 font=("Segoe UI", 9, "bold"), padx=15, pady=10,
                                 cursor="hand2")
        mic_button = tk.Button(composer, text="🎙", relief="flat", bd=0,
                               bg="#173d59", fg="#e8f4ff", activebackground="#205675",
                               font=("Segoe UI", 13), padx=12, pady=7,
                               cursor="hand2")
        mic_button.pack(side="right", padx=(0, 7))
        send_button.pack(side="right")

        def send():
            prompt = prompt_var.get().strip()
            if not prompt or self.vision_busy:
                return
            prompt_var.set("")
            add_message("YOU", prompt)
            self.vision_history.append({"role": "user", "content": prompt})
            self.vision_busy = True
            status.configure(text="Vision is thinking…")
            send_button.configure(state="disabled")
            context = self._vision_business_context()
            history = list(self.vision_history[:-1])

            def completed(answer, error):
                if not win.winfo_exists():
                    self.vision_history.append({"role": "assistant", "content": answer})
                    self.vision_busy = False
                    return
                self.vision_history.append({"role": "assistant", "content": answer})
                add_message("VISION", answer)
                self.vision_busy = False
                send_button.configure(state="normal")
                status.configure(text=(error + " · Check Vision settings" if error else "Vision is ready · Ask another question"))
            threading.Thread(target=self._vision_request,
                             args=(prompt, completed, context, history), daemon=True).start()

        def voice_input():
            mic_button.configure(state="disabled", text="…")
            status.configure(text="Listening… speak now")
            def listen():
                try:
                    import speech_recognition as sr
                    recognizer = sr.Recognizer()
                    with sr.Microphone() as source:
                        recognizer.adjust_for_ambient_noise(source, duration=0.5)
                        audio = recognizer.listen(source, timeout=6, phrase_time_limit=25)
                    spoken = recognizer.recognize_google(audio)
                    def put_text():
                        if win.winfo_exists():
                            prompt_var.set(spoken)
                            entry.focus_set()
                            status.configure(text="Voice captured · Press Send to ask Vision")
                            mic_button.configure(state="normal", text="🎙")
                    self.after(0, put_text)
                except ImportError:
                    msg = "Voice input needs the optional SpeechRecognition and PyAudio packages. Text chat is ready."
                    self.after(0, lambda: (status.configure(text=msg), mic_button.configure(state="normal", text="🎙")))
                except Exception as exc:
                    msg = "Could not capture voice: " + str(exc)
                    self.after(0, lambda: (status.configure(text=msg[:150]), mic_button.configure(state="normal", text="🎙")))
            threading.Thread(target=listen, daemon=True).start()

        send_button.configure(command=send)
        mic_button.configure(command=voice_input)
        entry.bind("<Return>", lambda _event: send())
        tk.Label(win, text="Enter to send  ·  Microphone requires a working microphone and optional speech packages",
                 bg="#07152a", fg="#718da8", font=("Segoe UI", 8), padx=18, pady=8).pack(fill="x")

        def close_popup():
            self.vision_popup = None
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", close_popup)

    def _shell(self, active="Dashboard"):
        self.clear()
        pal = self.appearance
        header = tk.Frame(self, bg="#07152a", height=78)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="BR", bg="#08bcd4", fg=WHITE, font=("Segoe UI", 19, "bold"), padx=18, pady=7).pack(side="left", padx=(22, 13), pady=12)
        tk.Label(header, text="BEYOND REGISTRATION\nFull Business Profile Solution", bg="#07152a", fg=WHITE,
                 font=("Segoe UI", 11, "bold"), justify="left").pack(side="left", pady=12)
        tk.Label(header, text=f"{self.actor}   ·   Administrator", bg="#07152a", fg="#b7d2e8", font=("Segoe UI", 10), padx=24).pack(side="right")
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        nav_bg = "#171b31" if pal == ORIGINAL_APPEARANCE else pal["sidebar"]
        nav_hover = pal["accent"]
        nav_active = pal["accent"]
        nav = tk.Frame(body, bg=nav_bg, width=248)
        nav.pack(side="left", fill="y")
        nav.pack_propagate(False)

        # Scrollable navigation keeps every module reachable on smaller screens.
        nav_view = tk.Frame(nav, bg=nav_bg)
        nav_view.pack(side="top", fill="both", expand=True)
        nav_canvas = tk.Canvas(nav_view, bg=nav_bg, highlightthickness=0, bd=0)
        nav_scroll = ttk.Scrollbar(nav_view, orient="vertical", command=nav_canvas.yview)
        nav_canvas.configure(yscrollcommand=nav_scroll.set)
        nav_scroll.pack(side="right", fill="y")
        nav_canvas.pack(side="left", fill="both", expand=True)
        nav_inner = tk.Frame(nav_canvas, bg=nav_bg)
        nav_window = nav_canvas.create_window((0, 0), window=nav_inner, anchor="nw")
        def _nav_inner_configure(_event=None):
            nav_canvas.configure(scrollregion=nav_canvas.bbox("all"))
        def _nav_canvas_configure(event):
            nav_canvas.itemconfigure(nav_window, width=event.width)
        nav_inner.bind("<Configure>", _nav_inner_configure)
        nav_canvas.bind("<Configure>", _nav_canvas_configure)
        def _nav_mousewheel(event):
            if getattr(event, "delta", 0):
                nav_canvas.yview_scroll(int(-event.delta / 120), "units")
            elif getattr(event, "num", None) == 4:
                nav_canvas.yview_scroll(-1, "units")
            elif getattr(event, "num", None) == 5:
                nav_canvas.yview_scroll(1, "units")
            return "break"
        for widget in (nav_canvas, nav_inner):
            widget.bind("<MouseWheel>", _nav_mousewheel)
            widget.bind("<Button-4>", _nav_mousewheel)
            widget.bind("<Button-5>", _nav_mousewheel)

        tk.Label(nav_inner, text="YOUR WORKSPACE", bg=nav_bg, fg="#9fb5d2", font=("Segoe UI", 9, "bold"), padx=18, pady=18).pack(anchor="w")
        nav_items = [
            ("▦", "Dashboard", self.show_dashboard, "Overview"),
            ("✦", "Vision AI", self.show_vision, "Intelligence"),
            ("♙", "Employees", self.show_employees, "People"),
            ("◷", "Time & Attendance", self.show_attendance, "People"),
            ("▤", "HR management", self.show_hr_management, "People"),
            ("▧", "Leave management", self.show_leave_management, "People"),
            ("▣", "Contracts", self.show_contracts, "Records"),
            ("▧", "Employee documents", self.show_employee_documents, "Records"),
            ("★", "Performance reviews", self.show_performance_reviews, "Records"),
            ("▰", "Payroll", self.show_payroll, "Finance"),
            ("♙", "User accounts", self.show_user_accounts, "System"),
            ("◷", "Audit trail", self.show_audit, "System"),
            ("✎", "Design Studio", self.show_design_studio, "System"),
        ]
        last_group = None
        for glyph, title, command, group in nav_items:
            if group != last_group:
                tk.Label(nav_inner, text=group.upper(), bg=nav_bg, fg="#829bb9", font=("Segoe UI", 8, "bold"), padx=18, pady=12).pack(anchor="w")
                last_group = group
            is_active = title == active or (title == "HR management" and active == "HR management")
            row_bg = nav_active if is_active else nav_bg
            b = tk.Button(nav_inner, text=f"{glyph}   {title}", command=command, anchor="w", relief="flat", bd=0,
                          bg=row_bg, fg=WHITE if is_active else "#d5e1ef",
                          activebackground=nav_hover, activeforeground=WHITE,
                          font=("Segoe UI", 10, "bold" if is_active else "normal"), padx=17, pady=10, cursor="hand2", highlightthickness=0)
            b.pack(fill="x", padx=9, pady=2)

        # Keep backup and sign-out actions visible at the bottom.
        nav_footer = tk.Frame(nav, bg=nav_bg)
        nav_footer.pack(side="bottom", fill="x")
        tk.Frame(nav_footer, bg="#354b66", height=1).pack(fill="x", padx=16, pady=8)
        tk.Button(nav_footer, text="↻  Create full backup", command=self.create_backup, anchor="w", relief="flat", bd=0,
                  bg=nav_bg, fg="#d5e1ef", activebackground=nav_hover, activeforeground=WHITE, font=("Segoe UI", 9), padx=17, pady=7, cursor="hand2").pack(fill="x", padx=8)
        tk.Button(nav_footer, text="⤺  Restore backup", command=self.restore_backup, anchor="w", relief="flat", bd=0,
                  bg=nav_bg, fg="#d5e1ef", activebackground=nav_hover, activeforeground=WHITE, font=("Segoe UI", 9), padx=17, pady=7, cursor="hand2").pack(fill="x", padx=8)
        tk.Button(nav_footer, text="⇥  Sign out", command=self.sign_out, anchor="w", relief="flat", bd=0,
                  bg=nav_bg, fg="#d5e1ef", activebackground=nav_hover, activeforeground=WHITE, font=("Segoe UI", 10), padx=17, pady=9, cursor="hand2").pack(fill="x", padx=8, pady=8)
        # Right-hand workspace: page content above, persistent Vision composer below.
        workspace = ttk.Frame(body)
        workspace.pack(side="left", fill="both", expand=True)
        self.content = ttk.Frame(workspace, padding=30)
        self.content.pack(side="top", fill="both", expand=True)
        self._build_vision_dock(workspace)


    def _vision_business_context(self):
        """Return a privacy-conscious, read-only business snapshot for Vision."""
        c = self.store.counts()
        conn = self.store.conn
        def count(sql):
            try:
                return int(conn.execute(sql).fetchone()[0] or 0)
            except sqlite3.Error:
                return None
        def grouped(sql):
            try:
                return [dict(r) for r in conn.execute(sql).fetchall()]
            except sqlite3.Error:
                return []
        context = {
            "application": APP_NAME,
            "version": APP_VERSION,
            "signed_in_administrator": self.actor,
            "employee_counts": c,
            "attendance_records": count("SELECT COUNT(*) FROM attendance_daily"),
            "leave_records": count("SELECT COUNT(*) FROM leave_records"),
            "hr_records": count("SELECT COUNT(*) FROM hr_records"),
            "contracts": count("SELECT COUNT(*) FROM employee_contracts"),
            "performance_reviews": count("SELECT COUNT(*) FROM performance_reviews"),
            "payroll_records": count("SELECT COUNT(*) FROM payroll_records"),
            "employee_departments": grouped("SELECT COALESCE(NULLIF(department,''),'Unassigned') AS department, COUNT(*) AS employees FROM employees GROUP BY department ORDER BY employees DESC LIMIT 20"),
            "employment_statuses": grouped("SELECT employment_status AS status, COUNT(*) AS employees FROM employees GROUP BY employment_status ORDER BY employees DESC"),
            "recent_audit_activity": []
        }
        try:
            context["recent_audit_activity"] = [
                {"actor": r["actor"], "action": r["action"], "entity_type": r["entity_type"], "created_at": r["created_at"]}
                for r in self.store.recent_audit(8)
            ]
        except Exception:
            pass
        return context

    def _vision_offline_reply(self, prompt, context=None):
        """Useful local assistant behaviour when no AI service key is configured."""
        c = context or {}
        c.setdefault("employee_counts", {"total": 0, "active": 0, "admins": 0, "payroll": 0})
        c.setdefault("employee_departments", [])
        q = prompt.lower()
        if any(w in q for w in ("overview", "summary", "how is", "business status", "dashboard", "employees")):
            depts = c.get("employee_departments", [])
            dept_text = ", ".join(f"{x['department']}: {x['employees']}" for x in depts) or "No department data yet"
            return (f"Here is the current Beyond Registration snapshot, {self.actor}.\n\n"
                    f"• Employees: {c['employee_counts']['total']} total, {c['employee_counts']['active']} active\n"
                    f"• Administrator accounts: {c['employee_counts']['admins']} active\n"
                    f"• Attendance records: {c['attendance_records']}\n• Leave records: {c['leave_records']}\n"
                    f"• HR records: {c['hr_records']}\n• Contracts: {c['contracts']}\n"
                    f"• Performance reviews: {c['performance_reviews']}\n• Payroll records: {c['payroll_records']}\n\n"
                    f"Department distribution: {dept_text}.\n\n"
                    "I am currently in Local Assistant mode. Connect the hosted Vision service to enable full conversational reasoning and business analysis. Only the approved read-only business snapshot is shared when you ask a question.")
        if any(w in q for w in ("what can you do", "help", "capabilities", "commands")):
            return ("I am Vision, the business intelligence assistant for Beyond Registration. I can help interpret the business dashboard, explain modules, prepare management reports, identify questions worth investigating, and—when connected to an AI service—reason over the approved business snapshot.\n\n"
                    "I currently have read-only access to summary counts and non-sensitive audit activity. I do not edit employee records, approve leave, change payroll, or alter user access. Those actions remain in the existing application and require an administrator.")
        return (f"I can help with that, {self.actor}. I am currently running in Local Assistant mode, so advanced natural-language reasoning is not enabled yet.\n\n"
                "Your application database remains on this computer. When online Vision is connected, the approved read-only business snapshot is sent to your hosted Vision service for analysis. No AI API key is entered or stored in this desktop application.\n\n"
                "I can already provide a live business overview—try asking: ‘Give me a business overview.’")

    def _vision_request(self, prompt, callback, context=None, history=None):
        """Send the conversation to the hosted Vision service and report useful diagnostics."""
        base_url = (self.vision_server_url or os.environ.get("VISION_SERVER_URL", "")).strip().rstrip("/")
        if not base_url:
            self.after(0, lambda: callback(
                "Vision's online service has not been connected yet. Set VISION_SERVER_URL to the deployed Vision service address in the launch environment. No API key belongs in this desktop application.",
                "Vision service not configured"))
            return

        messages = []
        for item in (history if history is not None else self.vision_history)[-10:]:
            role = item.get("role")
            if role in ("user", "assistant"):
                messages.append({"role": role, "content": str(item.get("content", ""))[:12000]})
        latest = prompt
        if context:
            latest += "\n\n--- APPROVED BEYOND REGISTRATION BUSINESS SNAPSHOT (READ-ONLY) ---\n" + json.dumps(context, ensure_ascii=False, default=str)[:24000] + "\n--- END BUSINESS SNAPSHOT ---"
        messages.append({"role": "user", "content": latest[:30000]})
        payload = json.dumps({"prompt": latest[:30000], "messages": messages}, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        token = (self.vision_access_token or os.environ.get("VISION_ACCESS_TOKEN", "")).strip()
        if token:
            headers["Authorization"] = "Bearer " + token
        endpoint = base_url + "/api/chat"
        req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")

        def response_preview(value, limit=700):
            value = re.sub(r"\s+", " ", str(value or "")).strip()
            if len(value) > limit:
                value = value[:limit] + "…"
            return value

        def parse_json_response(raw_text, status, content_type):
            clean = (raw_text or "").lstrip("\ufeff").strip()
            if not clean:
                raise ValueError(
                    "Vision returned an empty response (HTTP %s, Content-Type: %s) from %s."
                    % (status, content_type or "not supplied", endpoint)
                )
            try:
                return json.loads(clean)
            except json.JSONDecodeError as parse_error:
                preview = response_preview(clean)
                raise ValueError(
                    "Vision returned a non-JSON response (HTTP %s, Content-Type: %s) from %s. "
                    "Response begins: %s | JSON parser: %s"
                    % (status, content_type or "not supplied", endpoint, preview or "<empty>", parse_error)
                )

        try:
            with urllib.request.urlopen(req, timeout=90) as response:
                status = getattr(response, "status", response.getcode())
                content_type = response.headers.get("Content-Type", "")
                raw_text = response.read().decode("utf-8", "replace")
            data = parse_json_response(raw_text, status, content_type)

            if isinstance(data, str):
                answer_value = data
            elif isinstance(data, dict):
                service_error = data.get("userExplanation") or data.get("error")
                answer_value = (data.get("reply") or data.get("response") or data.get("answer")
                                or data.get("message") or data.get("content") or data.get("text"))
                if not answer_value and service_error:
                    raise ValueError("Vision service returned HTTP %s: %s" % (status, response_preview(service_error, 1200)))
            else:
                raise ValueError(
                    "Vision returned JSON in an unexpected format (HTTP %s, type %s): %s"
                    % (status, type(data).__name__, response_preview(data))
                )

            if isinstance(answer_value, dict):
                answer_value = (answer_value.get("text") or answer_value.get("content")
                                or answer_value.get("message") or json.dumps(answer_value, ensure_ascii=False))
            answer = str(answer_value or "").strip()
            if not answer:
                raise ValueError(
                    "Vision returned valid JSON but no reply text. Response begins: %s"
                    % response_preview(raw_text)
                )
            self.after(0, lambda answer=answer: callback(answer, None))

        except urllib.error.HTTPError as exc:
            try:
                raw = exc.read().decode("utf-8", "replace")
                content_type = exc.headers.get("Content-Type", "") if exc.headers else ""
                body = raw.lstrip("\ufeff").strip()
                try:
                    detail_data = json.loads(body) if body else {}
                except json.JSONDecodeError:
                    detail_data = {}
                if isinstance(detail_data, dict):
                    detail = (detail_data.get("userExplanation") or detail_data.get("error")
                              or detail_data.get("message") or response_preview(body, 1200))
                else:
                    detail = response_preview(body, 1200)
                if not detail:
                    detail = "The server returned an empty error response."
                detail = "HTTP %s (%s): %s" % (exc.code, content_type or "unknown content type", detail)
            except Exception as read_error:
                detail = "HTTP %s; could not read error response: %s" % (exc.code, read_error)
            self.after(0, lambda detail=detail: callback("Vision's online service returned an error: " + str(detail), "Vision service error"))

        except ValueError as exc:
            detail = str(exc)
            self.after(0, lambda detail=detail: callback("Vision response problem: " + detail, "Vision response error"))
        except Exception as exc:
            detail = "%s: %s" % (type(exc).__name__, exc)
            self.after(0, lambda detail=detail: callback("Vision could not complete the request: " + detail, "Connection error"))
    def show_vision(self):
        self._shell("Vision AI")
        top = ttk.Frame(self.content)
        top.pack(fill="x")
        ttk.Label(top, text="Meet Vision", style="Title.TLabel").pack(anchor="w")
        ttk.Label(top, text="Your personal AI and business intelligence partner for Beyond Registration.", style="Sub.TLabel").pack(anchor="w", pady=(4, 14))
        hero = tk.Frame(self.content, bg="#07152a", padx=20, pady=16)
        hero.pack(fill="x", pady=(0, 14))
        tk.Label(hero, text="✦  VISION", bg="#07152a", fg="#8ee6d6", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        tk.Label(hero, text="Loyal  •  Intelligent  •  Proactive  •  Professional  •  Responsible", bg="#07152a", fg="#e8f4ff", font=("Segoe UI", 10)).pack(anchor="w", pady=(5, 0))
        settings = ttk.LabelFrame(self.content, text="Vision online connection", padding=12)
        settings.pack(fill="x", pady=(0, 12))
        service_state = ("Vision live service configured · " + self.vision_server_url) if self.vision_server_url else "Waiting for hosted Vision service address"
        ttk.Label(settings, text=service_state, style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(settings, text="Vision uses your original Gemini-powered server. Its AI credential stays on the server; this desktop app never asks you for an AI API key.", style="Sub.TLabel", wraplength=850).pack(anchor="w", pady=(5, 0))
        chat_card = ttk.Frame(self.content, style="Card.TFrame", padding=12)
        chat_card.pack(fill="both", expand=True)
        ttk.Label(chat_card, text="Talk to Vision", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 8))
        transcript = tk.Text(chat_card, wrap="word", height=15, bg="#fbfcff", fg=TEXT, relief="flat", padx=14, pady=12, font=("Segoe UI", 10), state="disabled")
        scroll = ttk.Scrollbar(chat_card, orient="vertical", command=transcript.yview)
        transcript.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        transcript.pack(fill="both", expand=True)
        transcript.tag_configure("vision", foreground="#5145cd", font=("Segoe UI", 10, "bold"))
        transcript.tag_configure("you", foreground="#138a79", font=("Segoe UI", 10, "bold"))
        transcript.tag_configure("body", foreground=TEXT, spacing3=8)
        def add_message(who, body):
            transcript.configure(state="normal")
            transcript.insert("end", who + "\n", "vision" if who == "VISION" else "you")
            transcript.insert("end", body.strip() + "\n\n", "body")
            transcript.configure(state="disabled")
            transcript.see("end")
        if not self.vision_history:
            add_message("VISION", f"Hello {self.actor}. I am Vision, your business intelligence partner. I am here to help you understand your business, spot opportunities, solve problems and make better decisions. What would you like to work on today?\n\nYou can start with ‘Give me a business overview’.")
        else:
            for item in self.vision_history:
                add_message("YOU" if item["role"] == "user" else "VISION", item["content"])
        composer = ttk.Frame(chat_card)
        composer.pack(fill="x", pady=(10, 0))
        prompt_var = tk.StringVar()
        prompt_entry = ttk.Entry(composer, textvariable=prompt_var)
        prompt_entry.pack(side="left", fill="x", expand=True, ipady=8, padx=(0, 8))
        status = ttk.Label(chat_card, text="Connected to your hosted Vision service · Read-only business snapshot · No records changed", style="Sub.TLabel")
        status.pack(anchor="w", pady=(8, 0))
        def send():
            prompt = prompt_var.get().strip()
            if not prompt or self.vision_busy: return
            prompt_var.set("")
            add_message("YOU", prompt)
            def completed(answer, error):
                self.vision_history.append({"role": "assistant", "content": answer})
                add_message("VISION", answer)
                self.vision_busy = False
                send_button.configure(state="normal")
                status.configure(text=(error + " · Check settings" if error else "Ready · Vision service · Read-only business context · Administrator remains in control"))
            self.vision_history.append({"role": "user", "content": prompt})
            self.vision_busy = True
            status.configure(text="Vision is thinking…")
            send_button.configure(state="disabled")
            business_context = self._vision_business_context()
            history_snapshot = list(self.vision_history[:-1])
            threading.Thread(target=self._vision_request, args=(prompt, completed, business_context, history_snapshot), daemon=True).start()
        send_button = ttk.Button(composer, text="Send to Vision  ➤", style="Primary.TButton", command=send)
        send_button.pack(side="right")
        prompt_entry.bind("<Return>", lambda _e: send())
        actions = ttk.Frame(self.content)
        actions.pack(fill="x", pady=(10, 0))
        ttk.Button(actions, text="Business overview", command=lambda: (prompt_var.set("Give me a business overview and highlight the main areas I should focus on."), send())).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="What can you do?", command=lambda: (prompt_var.set("What can you do to help me run Beyond Registration?"), send())).pack(side="left")
        ttk.Button(actions, text="Clear conversation", command=lambda: self._clear_vision_history()).pack(side="right")

    def _clear_vision_history(self):
        self.vision_history = []
        self.show_vision()

    def show_user_accounts(self):
        self._shell("User accounts")
        ttk.Label(self.content, text="Administrator user accounts", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Create accounts, reset passwords, deactivate or delete access. Existing passwords cannot be viewed because they are securely stored as hashes.", style="Sub.TLabel", wraplength=850).pack(anchor="w", pady=(5, 16))
        table_frame = ttk.Frame(self.content)
        table_frame.pack(fill="both", expand=True)
        cols = ("name", "username", "status", "created")
        tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=8)
        for col, title, width in [("name", "Full name", 220), ("username", "Username", 180), ("status", "Status", 100), ("created", "Created", 180)]:
            tree.heading(col, text=title); tree.column(col, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        def refresh(select_id=None):
            for item in tree.get_children(): tree.delete(item)
            for row in self.store.list_admins():
                tree.insert("", "end", iid=str(row["id"]), values=(row["full_name"], row["username"], "Active" if row["active"] else "Disabled", row["created_at"]))
            if select_id and tree.exists(str(select_id)): tree.selection_set(str(select_id))
        def selected_id():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Select account", "Please select a user account first."); return None
            return int(sel[0])
        actions=ttk.Frame(self.content); actions.pack(fill="x", pady=12)
        def create_account():
            win=tk.Toplevel(self); win.title("Create administrator account"); win.transient(self); win.grab_set(); win.geometry("420x390")
            box=ttk.Frame(win,padding=20); box.pack(fill="both",expand=True)
            name=self._field(box,"Full name"); user=self._field(box,"Username"); pw=self._field(box,"Password (minimum 4 characters)",secret=True); confirm=self._field(box,"Confirm password",secret=True)
            def save():
                if not name.get().strip() or not user.get().strip() or len(pw.get())<4:
                    messagebox.showwarning("Check details","Enter a name, username and password of at least 4 characters.",parent=win); return
                if pw.get()!=confirm.get():
                    messagebox.showwarning("Passwords differ","The passwords do not match.",parent=win); return
                try: self.store.create_admin(name.get(),user.get(),pw.get())
                except sqlite3.IntegrityError:
                    messagebox.showerror("Username exists","Choose a username that is not already in use.",parent=win); return
                self.store.log(self.actor,"Created administrator account","admin",user.get())
                win.destroy(); refresh(); messagebox.showinfo("Account created","The new administrator account has been created.")
            ttk.Button(box,text="Save account",style="Primary.TButton",command=save).pack(anchor="e",pady=12)
        def reset_password():
            aid=selected_id()
            if aid is None:return
            row=next((r for r in self.store.list_admins() if r["id"]==aid),None)
            if not row:return
            win=tk.Toplevel(self); win.title("Reset password"); win.transient(self); win.grab_set(); win.geometry("400x260")
            box=ttk.Frame(win,padding=20); box.pack(fill="both",expand=True)
            ttk.Label(box,text=f"Set a new password for {row['username']}").pack(anchor="w",pady=(0,10))
            pw=self._field(box,"New password (minimum 4 characters)",secret=True); confirm=self._field(box,"Confirm new password",secret=True)
            def save():
                if len(pw.get())<4 or pw.get()!=confirm.get():
                    messagebox.showwarning("Check password","Use at least 4 characters and ensure both entries match.",parent=win); return
                self.store.reset_admin_password(aid,pw.get()); self.store.log(self.actor,"Reset administrator password","admin",row["username"]); win.destroy(); messagebox.showinfo("Password reset","The password has been changed.")
            ttk.Button(box,text="Reset password",style="Primary.TButton",command=save).pack(anchor="e",pady=10)
        def toggle_access():
            aid=selected_id()
            if aid is None:return
            row=next((r for r in self.store.list_admins() if r["id"]==aid),None)
            if not row:return
            if row["username"].casefold()==getattr(self,"current_username","").casefold():
                messagebox.showwarning("Cannot disable current account","You cannot disable the account you are currently using."); return
            if row["active"] and self.store.admin_count()<=1:
                messagebox.showwarning("Last administrator","At least one active administrator must remain."); return
            active=not bool(row["active"])
            if not messagebox.askyesno("Confirm access change",f"{'Enable' if active else 'Disable'} access for {row['username']}?"):return
            self.store.set_admin_active(aid,active); self.store.log(self.actor,"Changed administrator access","admin",row["username"],"Active" if active else "Disabled"); refresh(aid)
        def delete_account():
            aid=selected_id()
            if aid is None:return
            row=next((r for r in self.store.list_admins() if r["id"]==aid),None)
            if not row:return
            if row["username"].casefold()==getattr(self,"current_username","").casefold():
                messagebox.showwarning("Cannot delete current account","You cannot delete the account you are signed in with."); return
            if str(row["role"] or "Administrator")=="Administrator" and self.store.admin_count()<=1:
                messagebox.showwarning("Last administrator","Create another administrator before deleting this one."); return
            if not messagebox.askyesno("Delete account",
                f"Delete the account {row['full_name']} ({row['username']})?\n\n"
                "The account is removed and can no longer sign in. The audit trail keeps every "
                "action it ever took. This cannot be undone."): return
            self.store.delete_admin(aid)
            self.store.log(self.actor,"Deleted user account","admin",row["username"],row["full_name"])
            refresh()
        ttk.Button(actions,text="＋ Create user",style="Primary.TButton",command=create_account).pack(side="left",padx=(0,8))
        ttk.Button(actions,text="Reset selected password",command=reset_password).pack(side="left",padx=4)
        ttk.Button(actions,text="Enable / disable selected",command=toggle_access).pack(side="left",padx=4)
        ttk.Button(actions,text="Delete selected",command=delete_account).pack(side="left",padx=4)
        refresh()

    def show_dashboard(self):
        self._shell("Dashboard")
        ttk.Label(self.content, text="Business Command Centre", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Your business command centre for employee records, HR, attendance, leave, contracts, documents, performance reviews and payroll.", style="Sub.TLabel").pack(anchor="w", pady=(5, 22))
        counts = self.store.counts()
        cards = ttk.Frame(self.content)
        cards.pack(fill="x")
        for title, value, subtitle, accent, glyph in [
            ("Employees", counts["total"], "Employee profiles recorded", "#3478f6", "♙"),
            ("Active employees", counts["active"], "Currently marked active", "#13a879", "✓"),
            ("Administrators", counts["admins"], "Authorised administrator accounts", "#8b5cf6", "⚙"),
        ]:
            card = ttk.Frame(cards, style="Card.TFrame", padding=0)
            card.pack(side="left", fill="both", expand=True, padx=(0, 12))
            tk.Frame(card, bg=accent, height=7).pack(fill="x")
            inner = ttk.Frame(card, style="Card.TFrame", padding=16)
            inner.pack(fill="both", expand=True)
            top_line = ttk.Frame(inner, style="Card.TFrame")
            top_line.pack(fill="x")
            ttk.Label(top_line, text=title, style="Sub.TLabel").pack(side="left", anchor="w")
            tk.Label(top_line, text=glyph, bg=accent, fg=WHITE, font=("Segoe UI", 17, "bold"), padx=10, pady=4, relief="raised", bd=2).pack(side="right")
            ttk.Label(inner, text=str(value), font=("Segoe UI", 27, "bold"), foreground=accent, background=WHITE).pack(anchor="w", pady=(5, 2))
            ttk.Label(inner, text=subtitle, style="Sub.TLabel", wraplength=200).pack(anchor="w")
        lower = ttk.Frame(self.content)
        lower.pack(fill="both", expand=True, pady=(22, 0))
        quick = ttk.Frame(lower, style="Card.TFrame", padding=20)
        quick.pack(side="left", fill="both", expand=True, padx=(0, 12))
        ttk.Label(quick, text="Quick actions", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 12))
        ttk.Button(quick, text="＋  Add employee", style="Primary.TButton", command=lambda: self.employee_form(None)).pack(anchor="w", pady=4)
        ttk.Button(quick, text="View employee directory", command=self.show_employees).pack(anchor="w", pady=4)
        ttk.Button(quick, text="Open Payroll", command=self.show_payroll).pack(anchor="w", pady=4)
        ttk.Button(quick, text="Create a database backup", command=self.create_backup).pack(anchor="w", pady=4)
        note = ttk.Frame(lower, style="Card.TFrame", padding=20)
        note.pack(side="left", fill="both", expand=True)
        ttk.Label(note, text="Planned modules", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 12))
        for item in ["Employee history and documents", "Attendance and leave", "Payroll and PDF payslips", "Training, warnings and company stock", "Internal messaging tools"]:
            ttk.Label(note, text="•  " + item, background=WHITE).pack(anchor="w", pady=5)
        ttk.Label(self.content, text=f"Local data folder: {DATA_HOME}", style="Sub.TLabel").pack(anchor="w", pady=(18, 0))

    def show_employees(self):
        self._shell("Employees")
        top = ttk.Frame(self.content)
        top.pack(fill="x")
        ttk.Label(top, text="Employee directory", style="Title.TLabel").pack(side="left")
        ttk.Button(top, text="＋ Add employee", style="Primary.TButton", command=lambda: self.employee_form(None)).pack(side="right")
        ttk.Label(self.content, text="Search by employee number, name or job title. Select a row and open the profile.", style="Sub.TLabel").pack(anchor="w", pady=(5, 14))
        bar = ttk.Frame(self.content)
        bar.pack(fill="x", pady=(0, 12))
        search = ttk.Entry(bar)
        search.pack(side="left", fill="x", expand=True)
        tree_frame = ttk.Frame(self.content, style="Card.TFrame", padding=8)
        tree_frame.pack(fill="both", expand=True)
        cols = ("employee_no", "name", "job_title", "department", "status", "phone")
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="browse")
        headings = [("employee_no", "Employee no.", 120), ("name", "Employee name", 220), ("job_title", "Job title", 180), ("department", "Department", 150), ("status", "Status", 100), ("phone", "Telephone", 140)]
        for col, title, width in headings:
            tree.heading(col, text=title)
            tree.column(col, width=width, anchor="w")
        scroll = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        def refresh(*_):
            for node in tree.get_children(): tree.delete(node)
            for row in self.store.employees(search.get()):
                tree.insert("", "end", iid=str(row["id"]), values=(row["employee_no"], f'{row["first_name"]} {row["last_name"]}', row["job_title"], row["department"], row["employment_status"], row["phone"]))
        ttk.Button(bar, text="Search", command=refresh).pack(side="left", padx=(8, 0))
        ttk.Button(bar, text="Clear", command=lambda: (search.delete(0, "end"), refresh())).pack(side="left", padx=(6, 0))
        tree.bind("<Double-1>", lambda _e: self.open_selected_employee(tree))
        actions = ttk.Frame(self.content)
        actions.pack(fill="x", pady=(12, 0))
        ttk.Button(actions, text="Open profile", style="Primary.TButton", command=lambda: self.open_selected_employee(tree)).pack(side="left")
        ttk.Button(actions, text="Edit selected", command=lambda: self.edit_selected_employee(tree)).pack(side="left", padx=8)
        refresh()

    def open_selected_employee(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select an employee", "Select an employee first.")
            return
        self.employee_form(int(selected[0]), readonly=True)

    def edit_selected_employee(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select an employee", "Select an employee first.")
            return
        self.employee_form(int(selected[0]))

    def employee_form(self, employee_id: int | None, readonly: bool = False):
        existing = self.store.employee(employee_id) if employee_id else None
        if employee_id is not None and existing is None:
            messagebox.showerror("Employee not found", "This employee record could not be loaded from the database. Refresh the employee list and try again.", parent=self)
            return
        win = tk.Toplevel(self)
        win.title(("Employee profile" if readonly else "Edit employee" if existing else "Add employee") + " · Beyond Registration")
        win.geometry("900x720")
        win.minsize(780, 600)
        win.transient(self)
        win.grab_set()
        win.configure(bg=BG)
        head = ttk.Frame(win, padding=(22, 18))
        head.pack(fill="x")
        name_text = f'{existing["first_name"]} {existing["last_name"]}' if existing else "New employee profile"
        ttk.Label(head, text=name_text, style="Title.TLabel").pack(anchor="w")
        ttk.Label(head, text="Personal details and emergency contact · Additional employee modules will follow", style="Sub.TLabel").pack(anchor="w", pady=(4, 0))
        outer = ttk.Frame(win, padding=(22, 0, 22, 18))
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
        scroll = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        inner_window = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        # Keep the form as wide as the available canvas instead of using a fixed width.
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(inner_window, width=max(1, event.width)))

        values = {k: (existing[k] if existing and existing[k] is not None else "") for k in [
            "employee_no", "first_name", "last_name", "preferred_name", "id_number", "phone", "email", "address",
            "job_title", "department", "employment_status", "start_date", "emergency_name", "emergency_relationship",
            "emergency_phone", "allergies", "notes", "photo_path", "biometric_id"]}
        if values.get("start_date"):
            values["start_date"] = display_date(values["start_date"])
        vars = {}
        photo_label = ttk.Label(inner, text="No photo selected", style="Sub.TLabel")
        ttk.Label(inner, text="Employee details", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=4, sticky="w", pady=(12, 8))

        # Each field gets its own label row followed by its input row. The old layout
        # placed the next label in the same grid row as the previous input.
        specs = [
            ("employee_no", "Employee number", 1, 0), ("first_name", "First name *", 1, 2),
            ("last_name", "Last name *", 3, 0), ("preferred_name", "Preferred name", 3, 2),
            ("id_number", "ID / passport number", 5, 0), ("phone", "Telephone", 5, 2),
            ("email", "Email", 7, 0), ("job_title", "Job title", 7, 2),
            ("department", "Department", 9, 0), ("start_date", "Start date (DD-MM-YYYY)", 9, 2),
            ("biometric_id", "KM30 biometric / User ID", 11, 2),
        ]
        for key, label, row, col in specs:
            ttk.Label(inner, text=label, style="Sub.TLabel").grid(
                row=row, column=col, sticky="w", padx=(0, 12), pady=(8, 2))
            if readonly:
                # Display saved values as labels in view mode. This avoids blank-looking
                # readonly ttk.Entry controls on some Windows themes and makes every
                # stored field visibly readable.
                shown = values[key] if str(values[key]).strip() else "—"
                ttk.Label(inner, text=str(shown), background=WHITE, foreground=TEXT,
                          wraplength=340, anchor="w").grid(
                    row=row + 1, column=col, sticky="ew", padx=(0, 18), pady=(0, 5))
            else:
                var = tk.StringVar(value=values[key])
                vars[key] = var
                entry = ttk.Entry(inner, textvariable=var, width=38)
                entry.grid(row=row + 1, column=col, sticky="ew", padx=(0, 18), pady=(0, 5))

        ttk.Label(inner, text="Employment status", style="Sub.TLabel").grid(row=13, column=0, sticky="w", pady=(8, 2))
        vars["employment_status"] = tk.StringVar(value=values["employment_status"] or "Active")
        status = ttk.Combobox(inner, textvariable=vars["employment_status"], values=["Active", "On leave", "Suspended", "Terminated", "Resigned"], state="readonly" if not readonly else "disabled")
        status.grid(row=14, column=0, sticky="ew", padx=(0, 18), pady=(0, 5))

        ttk.Label(inner, text="Residential address", style="Sub.TLabel").grid(row=15, column=0, sticky="w", pady=(10, 2))
        if readonly:
            ttk.Label(inner, text=str(values["address"] or "—"), background=WHITE,
                      foreground=TEXT, wraplength=760, anchor="w").grid(
                row=16, column=0, columnspan=4, sticky="ew", pady=(0, 8))
        else:
            vars["address"] = tk.StringVar(value=values["address"])
            address = ttk.Entry(inner, textvariable=vars["address"])
            address.grid(row=16, column=0, columnspan=4, sticky="ew", pady=(0, 8))

        ttk.Separator(inner).grid(row=17, column=0, columnspan=4, sticky="ew", pady=14)
        ttk.Label(inner, text="Emergency contact", style="CardTitle.TLabel").grid(row=18, column=0, columnspan=4, sticky="w", pady=(0, 6))
        for key, label, row, col in [
            ("emergency_name", "Contact name", 19, 0),
            ("emergency_relationship", "Relationship", 19, 2),
            ("emergency_phone", "Contact telephone", 21, 0),
        ]:
            ttk.Label(inner, text=label, style="Sub.TLabel").grid(
                row=row, column=col, sticky="w", padx=(0, 12), pady=(6, 2))
            vars[key] = tk.StringVar(value=values[key])
            entry = ttk.Entry(inner, textvariable=vars[key])
            entry.grid(row=row + 1, column=col, sticky="ew", padx=(0, 18), pady=(0, 5))
            if readonly:
                entry.configure(state="readonly")

        ttk.Label(inner, text="Allergies / important health notes (restrict access in shared use)", style="Sub.TLabel").grid(row=23, column=0, columnspan=4, sticky="w", pady=(12, 2))
        allergy = tk.Text(inner, height=3, wrap="word", font=("Segoe UI", 10), relief="solid", bd=1)
        allergy.grid(row=24, column=0, columnspan=4, sticky="ew", pady=(0, 8))
        allergy.insert("1.0", values["allergies"])
        if readonly:
            allergy.configure(state="disabled")

        ttk.Label(inner, text="General notes", style="Sub.TLabel").grid(row=26, column=0, columnspan=4, sticky="w", pady=(8, 2))
        notes = tk.Text(inner, height=3, wrap="word", font=("Segoe UI", 10), relief="solid", bd=1)
        notes.grid(row=27, column=0, columnspan=4, sticky="ew", pady=(0, 8))
        notes.insert("1.0", values["notes"])
        if readonly:
            notes.configure(state="disabled")

        ttk.Label(inner, text="Employee photograph", style="CardTitle.TLabel").grid(row=30, column=0, columnspan=4, sticky="w", pady=(14, 6))
        photo_var = tk.StringVar(value=values["photo_path"])
        photo_preview = ttk.Label(inner, text="No photograph", anchor="center", relief="solid")
        photo_preview.grid(row=31, column=0, rowspan=3, sticky="nw", padx=(0, 14), pady=(0, 8), ipadx=5, ipady=5)
        photo_label.grid(row=31, column=1, columnspan=2, sticky="w")
        photo_label.configure(text=Path(values["photo_path"]).name if values["photo_path"] else "No photo selected")
        # Keep a reference to the Tk image so it is not garbage-collected.
        photo_preview.image = None

        def load_photo_preview(path):
            photo_preview.configure(image="", text="No photograph")
            photo_preview.image = None
            if not path:
                return
            image_path = Path(path)
            if not image_path.exists():
                photo_preview.configure(text="Photo file\nnot found")
                return
            try:
                if Image is not None and ImageTk is not None:
                    img = Image.open(image_path)
                    img.thumbnail((150, 150))
                    tk_img = ImageTk.PhotoImage(img)
                else:
                    # Tkinter supports PNG/GIF natively; Pillow enables JPEG/BMP previews.
                    tk_img = tk.PhotoImage(file=str(image_path))
                    factor = max(1, (tk_img.width() + 149) // 150, (tk_img.height() + 149) // 150)
                    if factor > 1:
                        tk_img = tk_img.subsample(factor, factor)
                photo_preview.configure(image=tk_img, text="")
                photo_preview.image = tk_img
            except Exception:
                photo_preview.configure(text="Preview unavailable\nInstall Pillow to view JPG/BMP", image="")

        load_photo_preview(values["photo_path"])

        def choose_photo():
            path = filedialog.askopenfilename(parent=win, title="Choose employee photograph", filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp"), ("All files", "*.*")])
            if path:
                photo_var.set(path)
                photo_label.configure(text=Path(path).name)
                load_photo_preview(path)

        if not readonly:
            ttk.Button(inner, text="Choose photograph…", command=choose_photo).grid(row=31, column=3, sticky="ne")
        else:
            ttk.Label(inner, text="CV, contracts, training, leave, payroll and disciplinary records will be added in later stages.", style="Sub.TLabel", wraplength=780).grid(row=34, column=0, columnspan=4, sticky="w", pady=14)

        for col in (0, 2):
            inner.columnconfigure(col, weight=1, uniform="employee_fields")
        inner.columnconfigure(1, weight=0)
        inner.columnconfigure(3, weight=0)


        footer = ttk.Frame(win, padding=18)
        footer.pack(fill="x")
        ttk.Button(footer, text="Close", command=win.destroy).pack(side="right")
        if not readonly:
            def save():
                data = {k: v.get().strip() for k, v in vars.items()}
                if data.get("start_date"): data["start_date"] = stored_date(data["start_date"])
                data["allergies"] = allergy.get("1.0", "end-1c").strip()
                data["notes"] = notes.get("1.0", "end-1c").strip()
                if not data["employee_no"] or not data["first_name"] or not data["last_name"]:
                    messagebox.showwarning("Required fields", "Employee number, first name and last name are required.", parent=win); return
                photo = photo_var.get().strip()
                if photo:
                    src = Path(photo)
                    if src.exists():
                        ext = src.suffix.lower() if src.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".bmp"} else ".img"
                        dest = PHOTO_DIR / f"employee_{employee_id or 'new'}_{secrets.token_hex(4)}{ext}"
                        try:
                            shutil.copy2(src, dest)
                            data["photo_path"] = str(dest)
                        except OSError as exc:
                            messagebox.showerror("Photo error", f"Could not copy the photograph:\n{exc}", parent=win); return
                try:
                    self.store.save_employee(data, employee_id, self.actor)
                except sqlite3.IntegrityError:
                    messagebox.showerror("Duplicate employee number", "That employee number is already in use.", parent=win); return
                except sqlite3.Error as exc:
                    messagebox.showerror("Database error", f"The employee record could not be saved:\n{exc}", parent=win); return
                messagebox.showinfo("Saved", "Employee profile saved.", parent=win)
                win.destroy()
                self.show_employees()
            ttk.Button(footer, text="Save employee", style="Primary.TButton", command=save).pack(side="right", padx=(0, 8))

    def show_hr_management(self):
        self._shell("HR management")
        ttk.Label(self.content, text="HR Management", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Keep documents, training, disciplinary records, requests and company property organised by employee.", style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=(5, 14))
        employees = self.store.conn.execute("SELECT id, employee_no, first_name, last_name FROM employees ORDER BY last_name, first_name").fetchall()
        if not employees:
            ttk.Label(self.content, text="Add an employee first, then return here to create HR records.").pack(anchor="w", pady=12)
            ttk.Button(self.content, text="Open employee directory", command=self.show_employees).pack(anchor="w")
            return
        employee_map = {f'{r["employee_no"]} — {r["first_name"]} {r["last_name"]}': int(r["id"]) for r in employees}
        selected_employee = tk.StringVar(value=next(iter(employee_map)))
        selector = ttk.Frame(self.content, style="Card.TFrame", padding=12)
        selector.pack(fill="x", pady=(0, 12))
        ttk.Label(selector, text="Employee", style="CardTitle.TLabel").pack(side="left", padx=(0, 12))
        employee_combo = ttk.Combobox(selector, textvariable=selected_employee, values=list(employee_map), state="readonly", width=48)
        employee_combo.pack(side="left", fill="x", expand=True)
        notebook = ttk.Notebook(self.content)
        notebook.pack(fill="both", expand=True)

        configs = {
            "Documents": {"type": "Document", "title": "Document name / type", "date_from": "Date added (DD-MM-YYYY)", "date_to": "Expiry date (DD-MM-YYYY, if applicable)", "status": "Status", "details": "Notes", "field_a": "Document category", "field_b": "", "file": True, "statuses": ["Current", "Expired", "Pending", "Under review", "Approved", "Declined", "Archived"]},
            "Training": {"type": "Training", "title": "Programme / course", "date_from": "Start date (DD-MM-YYYY)", "date_to": "End date (DD-MM-YYYY)", "status": "Outcome / status", "details": "Notes / skills gained", "field_a": "Provider", "field_b": "Qualification / certificate", "file": True, "statuses": ["Pending", "Under review", "Approved", "Declined", "Planned", "In progress", "Completed", "Not completed"]},
            "Disciplinary": {"type": "Disciplinary", "title": "Record type (e.g. verbal / written / final warning)", "date_from": "Incident / warning date (DD-MM-YYYY)", "date_to": "Follow-up date (DD-MM-YYYY)", "status": "Status", "details": "Incident description, action taken and employee response", "field_a": "Nature of incident", "field_b": "Follow-up owner", "file": True, "statuses": ["Open", "Under review", "Resolved", "Closed"]},
            "Special requests": {"type": "Special request", "title": "Request type (e.g. special leave / advance / hours change)", "date_from": "Request date (DD-MM-YYYY)", "date_to": "Date(s) requested, if applicable", "status": "Decision / status", "details": "Request details, decision and comments", "field_a": "Requested outcome", "field_b": "Reviewed by", "file": True, "statuses": ["Pending", "Under review", "Approved", "Declined", "More information needed", "Completed"]},
            "Company property": {"type": "Company property", "title": "Item / property description", "date_from": "Issue date (DD-MM-YYYY)", "date_to": "Return date (DD-MM-YYYY, if returned)", "status": "Item status", "details": "Additional notes / serial number", "field_a": "Acknowledgement / employee sign-off", "field_b": "", "file": False, "statuses": ["Issued", "Returned", "Lost", "Damaged"]},
        }
        tree_by_type = {}
        def edit_selected(cfg, tab_name, tree):
            if tree is None or not tree.selection():
                messagebox.showinfo("Select a record", "Select a record in this tab, then click Edit selected.", parent=self)
                return
            record_id = int(tree.selection()[0])
            row = self.store.conn.execute("SELECT * FROM hr_records WHERE id=?", (record_id,)).fetchone()
            if not row:
                messagebox.showerror("Record not found", "This HR record could not be found.", parent=self)
                return
            label = selected_employee.get()
            if int(row["employee_id"]) != employee_map.get(label):
                messagebox.showwarning("Employee changed", "Please select the employee who owns this record.", parent=self)
                return
            self.hr_record_form(cfg, tab_name, employee_map, label, refresh_all, record=row)
        for tab_name, cfg in configs.items():
            tab = ttk.Frame(notebook, padding=12)
            notebook.add(tab, text=tab_name)
            top = ttk.Frame(tab)
            top.pack(fill="x", pady=(0, 10))
            ttk.Label(top, text=f"{tab_name} records", style="CardTitle.TLabel").pack(side="left")
            ttk.Button(top, text="Edit selected", command=lambda c=cfg, t=tab_name, tr=None: edit_selected(c, t, tree_by_type.get(c["type"])) ).pack(side="right", padx=(8, 0))
            ttk.Button(top, text="＋ Add record", style="Primary.TButton", command=lambda c=cfg, t=tab_name: self.hr_record_form(c, t, employee_map, selected_employee.get(), refresh_all)).pack(side="right")
            tree_frame = ttk.Frame(tab, style="Card.TFrame", padding=6)
            tree_frame.pack(fill="both", expand=True)
            cols = ("title", "date_from", "date_to", "status", "file")
            tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="browse")
            for col, heading, width in [("title", "Description", 300), ("date_from", "Date", 130), ("date_to", "End / expiry / follow-up", 160), ("status", "Status", 150), ("file", "Attachment", 180)]:
                tree.heading(col, text=heading)
                tree.column(col, width=width, anchor="w")
            yscroll = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=yscroll.set)
            tree.pack(side="left", fill="both", expand=True)
            yscroll.pack(side="right", fill="y")
            tree.bind("<Double-1>", lambda _e, tr=tree, typ=cfg["type"]: self.open_hr_record_viewer(tr, typ))
            ttk.Label(tab, text="Tip: double-click a record to open its attachment, if one is saved.", style="Sub.TLabel").pack(anchor="w", pady=(7, 0))
            tree_by_type[cfg["type"]] = tree

        def refresh_all():
            employee_id = employee_map.get(selected_employee.get())
            if not employee_id:
                return
            for cfg in configs.values():
                tree = tree_by_type[cfg["type"]]
                for node in tree.get_children():
                    tree.delete(node)
                for row in self.store.hr_records(employee_id, cfg["type"]):
                    attachment = Path(row["file_path"]).name if row["file_path"] else "—"
                    tree.insert("", "end", iid=str(row["id"]), values=(row["title"], display_date(row["date_from"]), display_date(row["date_to"]), row["status"], attachment))
        # The callbacks are evaluated after this function has been defined.
        employee_combo.bind("<<ComboboxSelected>>", lambda _e: refresh_all())
        refresh_all()

    def hr_record_form(self, cfg, tab_name, employee_map, employee_label, refresh_callback, record=None):
        employee_id = employee_map.get(employee_label)
        if not employee_id:
            messagebox.showwarning("Select employee", "Please select an employee first.", parent=self)
            return
        win = tk.Toplevel(self)
        mode = "Edit" if record is not None else "Add"
        win.title(f"{mode} {tab_name} record · Beyond Registration")
        win.geometry("650x760")
        win.minsize(560, 600)
        win.transient(self)
        win.grab_set()
        win.configure(bg=BG)
        ttk.Label(win, text=f"{mode} {tab_name} record", style="Title.TLabel").pack(anchor="w", padx=22, pady=(18, 4))
        ttk.Label(win, text=f"Employee: {employee_label}", style="Sub.TLabel", wraplength=600).pack(anchor="w", padx=22, pady=(0, 12))
        outer = ttk.Frame(win, padding=(22, 0, 22, 12))
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
        scroll = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(canvas_window, width=e.width))
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        entries = {}
        row_num = 0
        def add_entry(key, label, default=""):
            nonlocal row_num
            if record is not None and key in record.keys():
                default = str(record[key] or "")
            ttk.Label(inner, text=label, style="Sub.TLabel").grid(row=row_num, column=0, sticky="w", pady=(8, 2))
            var = tk.StringVar(value=default)
            ent = ttk.Entry(inner, textvariable=var)
            ent.grid(row=row_num+1, column=0, sticky="ew", pady=(0, 4))
            entries[key] = var
            row_num += 2
        add_entry("title", cfg["title"])
        add_entry("date_from", cfg["date_from"])
        add_entry("date_to", cfg["date_to"])
        ttk.Label(inner, text=cfg["status"], style="Sub.TLabel").grid(row=row_num, column=0, sticky="w", pady=(8, 2))
        current_status = str(record["status"] or "") if record is not None else cfg["statuses"][0]
        status_values = list(cfg["statuses"])
        if current_status and current_status not in status_values:
            status_values.append(current_status)
        status_var = tk.StringVar(value=current_status)
        status_combo = ttk.Combobox(inner, textvariable=status_var, values=status_values, state="readonly")
        status_combo.grid(row=row_num+1, column=0, sticky="ew", pady=(0, 4))
        entries["status"] = status_var
        row_num += 2
        for key in ("field_a", "field_b"):
            label = cfg.get(key, "")
            if label:
                add_entry(key, label)
        if cfg["type"] == "Company property":
            add_entry("quantity", "Quantity")
            add_entry("condition_issued", "Condition when issued")
            add_entry("condition_returned", "Condition when returned")
        ttk.Label(inner, text=cfg["details"], style="Sub.TLabel", wraplength=560).grid(row=row_num, column=0, sticky="w", pady=(8, 2))
        details = tk.Text(inner, height=5, wrap="word", font=("Segoe UI", 10), relief="solid", bd=1)
        details.grid(row=row_num+1, column=0, sticky="ew", pady=(0, 8))
        if record is not None:
            details.insert("1.0", str(record["details"] or ""))
        row_num += 2
        file_var = tk.StringVar(value=str(record["file_path"] or "") if record is not None else "")
        if cfg.get("file"):
            ttk.Label(inner, text="Supporting attachment (optional)", style="Sub.TLabel").grid(row=row_num, column=0, sticky="w", pady=(8, 2))
            file_row = ttk.Frame(inner)
            file_row.grid(row=row_num+1, column=0, sticky="ew", pady=(0, 8))
            ttk.Label(file_row, textvariable=file_var, style="Sub.TLabel").pack(side="left", fill="x", expand=True)
            def choose_file():
                path = filedialog.askopenfilename(parent=win, title="Choose supporting document", filetypes=[("Documents and images", "*.pdf *.doc *.docx *.jpg *.jpeg *.png *.txt"), ("All files", "*.*")])
                if path:
                    file_var.set(path)
            ttk.Button(file_row, text="Choose file…", command=choose_file).pack(side="right")
            row_num += 2
        inner.columnconfigure(0, weight=1)
        footer = ttk.Frame(win, padding=16)
        footer.pack(fill="x")
        ttk.Button(footer, text="Cancel", command=win.destroy).pack(side="right")
        def save_record():
            data = {k: v.get().strip() for k, v in entries.items()}
            data["details"] = details.get("1.0", "end-1c").strip()
            if not data.get("title"):
                messagebox.showwarning("Required field", "Please complete the description/title.", parent=win)
                return
            chosen = file_var.get().strip()
            if chosen and (record is None or chosen != str(record["file_path"] or "")):
                src = Path(chosen)
                if src.exists():
                    try:
                        suffix = src.suffix.lower() or ".dat"
                        dest = DOC_DIR / f"hr_{cfg['type'].lower().replace(' ', '_')}_{employee_id}_{secrets.token_hex(5)}{suffix}"
                        shutil.copy2(src, dest)
                        data["file_path"] = str(dest)
                    except OSError as exc:
                        messagebox.showerror("Attachment error", f"Could not copy the attachment:\n{exc}", parent=win)
                        return
            try:
                self.store.save_hr_record(employee_id, cfg["type"], data, self.actor, int(record["id"]) if record is not None else None)
            except sqlite3.Error as exc:
                messagebox.showerror("Save error", f"The HR record could not be saved:\n{exc}", parent=win)
                return
            messagebox.showinfo("Saved", f"{tab_name} record {'updated' if record is not None else 'saved'} successfully.", parent=win)
            win.destroy()
            refresh_callback()
        ttk.Button(footer, text="Save changes" if record is not None else "Save record", style="Primary.TButton", command=save_record).pack(side="right", padx=(0, 8))

    def open_hr_record_viewer(self, tree, record_type):
        selected = tree.selection()
        if not selected:
            return
        row = self.store.conn.execute("SELECT * FROM hr_records WHERE id=?", (int(selected[0]),)).fetchone()
        if not row:
            messagebox.showerror("Record not found", "This HR record could not be found.", parent=self)
            return
        employee = self.store.employee(int(row["employee_id"]))
        employee_name = f'{employee["employee_no"]} — {employee["first_name"]} {employee["last_name"]}' if employee else "Unknown employee"
        win = tk.Toplevel(self)
        win.title(f"{record_type} record · Beyond Registration")
        win.geometry("700x680")
        win.minsize(560, 480)
        win.transient(self)
        win.grab_set()
        outer = ttk.Frame(win, padding=22)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text=f"{record_type} record", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text=employee_name, style="Sub.TLabel").pack(anchor="w", pady=(3, 14))
        body = ttk.Frame(outer)
        body.pack(fill="both", expand=True)
        canvas = tk.Canvas(body, highlightthickness=0, bg=BG)
        scroll = ttk.Scrollbar(body, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        window_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window_id, width=e.width))
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        fields = [("Description", "title"), ("Start / record date", "date_from"), ("End / expiry / follow-up", "date_to"),
                  ("Status", "status"), ("Field A / category / provider", "field_a"), ("Field B / qualification / reviewer", "field_b"),
                  ("Quantity", "quantity"), ("Condition when issued", "condition_issued"), ("Condition when returned", "condition_returned")]
        r = 0
        for label, key in fields:
            value = str(row[key] or "").strip()
            if not value:
                continue
            ttk.Label(inner, text=label, style="CardTitle.TLabel").grid(row=r, column=0, sticky="w", pady=(8, 1))
            ttk.Label(inner, text=value, wraplength=600, justify="left").grid(row=r+1, column=0, sticky="w")
            r += 2
        ttk.Label(inner, text="Details / notes", style="CardTitle.TLabel").grid(row=r, column=0, sticky="w", pady=(10, 2))
        detail = tk.Text(inner, height=6, wrap="word", font=("Segoe UI", 10), relief="solid", bd=1)
        detail.grid(row=r+1, column=0, sticky="ew")
        detail.insert("1.0", row["details"] or "")
        detail.configure(state="disabled")
        inner.columnconfigure(0, weight=1)
        attachment = str(row["file_path"] or "")
        footer = ttk.Frame(win, padding=16)
        footer.pack(fill="x")
        if attachment:
            ttk.Label(footer, text=f"Attachment: {Path(attachment).name}", style="Sub.TLabel").pack(side="left", fill="x", expand=True)
            ttk.Button(footer, text="Open attachment", command=lambda: self._open_saved_attachment(attachment, win)).pack(side="left", padx=8)
        else:
            ttk.Label(footer, text="No attachment saved", style="Sub.TLabel").pack(side="left", fill="x", expand=True)
        ttk.Button(footer, text="Close", command=win.destroy).pack(side="right")

    def _open_saved_attachment(self, filename, parent=None):
        path = Path(filename)
        if not path.exists():
            messagebox.showerror("File not found", "The saved attachment could not be found on this computer.", parent=parent or self)
            return
        try:
            if os.name == "nt":
                os.startfile(str(path))
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Could not open attachment", str(exc), parent=parent or self)

    def open_hr_attachment(self, tree):
        selected = tree.selection()
        if not selected:
            return
        row = self.store.conn.execute("SELECT file_path FROM hr_records WHERE id=?", (int(selected[0]),)).fetchone()
        if not row or not row["file_path"]:
            messagebox.showinfo("No attachment", "This record does not have an attachment.", parent=self)
            return
        path = Path(row["file_path"])
        if not path.exists():
            messagebox.showerror("File not found", "The saved attachment could not be found on this computer.", parent=self)
            return
        try:
            if os.name == "nt":
                os.startfile(str(path))
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Could not open attachment", str(exc), parent=self)

    def _read_km30_xlsx(self, path):
        """Read ordinary .xlsx files without requiring Excel or an external Python package."""
        ns = {"a":"http://schemas.openxmlformats.org/spreadsheetml/2006/main", "r":"http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
        with zipfile.ZipFile(path, "r") as z:
            shared=[]
            if "xl/sharedStrings.xml" in z.namelist():
                root=ET.fromstring(z.read("xl/sharedStrings.xml"))
                for si in root.findall("a:si", ns):
                    shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["a"])))
            wb=ET.fromstring(z.read("xl/workbook.xml"))
            rels=ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            relmap={r.attrib["Id"]:r.attrib["Target"] for r in rels}
            sheet=wb.find("a:sheets/a:sheet", ns)
            rid=sheet.attrib.get("{%s}id" % ns["r"])
            target=relmap[rid]
            if not target.startswith("xl/"): target="xl/"+target
            root=ET.fromstring(z.read(target))
            rows=[]
            for row in root.findall(".//a:sheetData/a:row", ns):
                vals=[]
                for c in row.findall("a:c", ns):
                    ref=c.attrib.get("r","")
                    m=re.match(r"([A-Z]+)", ref)
                    col=0
                    if m:
                        for ch in m.group(1): col=col*26+(ord(ch)-64)
                        col-=1
                    while len(vals)<=col: vals.append("")
                    v=c.find("a:v", ns); val="" if v is None else (v.text or "")
                    if c.attrib.get("t")=="s" and val.isdigit() and int(val)<len(shared): val=shared[int(val)]
                    elif c.attrib.get("t")=="inlineStr": val="".join(t.text or "" for t in c.iter("{%s}t" % ns["a"]))
                    vals[col]=val
                rows.append(vals)
            return rows

    def _parse_km30_datetime(self, value):
        if value is None: return None
        text=str(value).strip()
        if not text: return None
        # Excel serial date/time
        try:
            num=float(text)
            if num>20000:
                return datetime(1899,12,30)+timedelta(days=num)
        except ValueError: pass
        candidates=["%Y-%m-%d %H:%M:%S","%Y/%m/%d %H:%M:%S","%d/%m/%Y %H:%M:%S","%d-%m-%Y %H:%M:%S","%Y-%m-%d %H:%M","%d/%m/%Y %H:%M","%d-%m-%Y %H:%M","%Y/%m/%d %H:%M","%Y-%m-%d","%d/%m/%Y","%d-%m-%Y"]
        for fmt in candidates:
            try: return datetime.strptime(text,fmt)
            except ValueError: pass
        return None

    def _km30_find_columns(self, headers):
        norm=[re.sub(r"[^a-z0-9]","",str(h).lower()) for h in headers]
        def find(words):
            for i,h in enumerate(norm):
                if any(w in h for w in words): return i
            return None
        return find(["userid","useridno","usernumber","employeeid","empno","employee_no","id"]), find(["datetime","timestamp","checktime","attendancetime","punchdatetime"]), find(["date","workdate"]), find(["time","checkin","checkout","punchtime"]), find(["type","status","inout","punchtype"]), find(["name","employeename"])

    def show_attendance(self):
        self._shell("Time & Attendance")
        ttk.Label(self.content, text="Time & Attendance", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Record and manage attendance manually. Enter payable hours after deducting the unpaid break; attach signed timesheets or supporting documents where needed. Biometric integration is deferred.", style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=(5,14))
        bar=ttk.Frame(self.content); bar.pack(fill="x", pady=(0,10))
        ttk.Button(bar,text="＋ Add manual hours",style="Primary.TButton",command=self.add_manual_attendance).pack(side="left")
        ttk.Button(bar,text="Attach file",command=lambda: self.attach_attendance_file(tree)).pack(side="left",padx=8)
        ttk.Button(bar,text="Open attachment",command=lambda: self.open_attendance_attachment(tree)).pack(side="left")
        ttk.Button(bar,text="Attendance settings",command=self.attendance_settings).pack(side="left",padx=8)
        ttk.Button(bar,text="Refresh",command=self.show_attendance).pack(side="left")
        frame=ttk.Frame(self.content,style="Card.TFrame",padding=8); frame.pack(fill="both",expand=True)
        cols=("date","employee","in","out","hours","late","early","ot","status","attachment")
        tree=ttk.Treeview(frame,columns=cols,show="headings",selectmode="browse")
        for c,h,w in [("date","Date",95),("employee","Employee",220),("in","Clock In",150),("out","Clock Out",150),("hours","Hours",70),("late","Late",65),("early","Early",65),("ot","Overtime",75),("status","Status",130),("attachment","Attachment",190)]: tree.heading(c,text=h); tree.column(c,width=w,anchor="w")
        y=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=y.set); tree.pack(side="left",fill="both",expand=True); y.pack(side="right",fill="y")
        rows=self.store.attendance_daily()
        for r in rows:
            name=f'{r["first_name"]} {r["last_name"]}'
            att=self.store.conn.execute("SELECT file_name FROM attendance_attachments WHERE attendance_daily_id=? ORDER BY id DESC LIMIT 1",(int(r["id"]),)).fetchone()
            attachment=att["file_name"] if att else "—"
            tree.insert("","end",iid=str(r["id"]),values=(display_date(r["work_date"]),name,r["first_in"],r["last_out"],f'{r["total_hours"]:.2f}',f'{r["late_minutes"]} min',f'{r["early_minutes"]} min',f'{r["overtime_minutes"]} min',r["status"],attachment))
        tree.bind("<Double-1>",lambda _e:self.open_attendance_attachment(tree))
        ttk.Label(self.content,text="Select an attendance day and use Attach file for supporting documents such as signed timesheets, correction forms or medical notes.",style="Sub.TLabel",wraplength=900).pack(anchor="w",pady=(8,0))

    def add_manual_attendance(self):
        """Record payable hours when the biometric clock is unavailable or being serviced."""
        employees = self.store.employees("")
        if not employees:
            messagebox.showinfo("No employees", "Add an employee before entering attendance hours manually.", parent=self)
            return
        win = tk.Toplevel(self)
        win.title("Add manual attendance hours · Beyond Registration")
        win.geometry("600x520")
        win.minsize(540, 480)
        win.transient(self)
        win.grab_set()
        win.configure(bg=BG)
        frm = ttk.Frame(win, padding=22)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="Add manual attendance hours", style="Title.TLabel").grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(frm, text="Use this when the biometric device fails, is serviced, or an employee's punches cannot be retrieved.", style="Sub.TLabel", wraplength=520).grid(row=1, column=0, columnspan=2, sticky="w", pady=(5, 14))
        employee_map = {f'{r["employee_no"]} — {r["first_name"]} {r["last_name"]}': int(r["id"]) for r in employees}
        employee_var = tk.StringVar(value=next(iter(employee_map)))
        date_var = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        hours_var = tk.StringVar(value="10.00")
        in_var = tk.StringVar()
        out_var = tk.StringVar()
        reason_var = tk.StringVar(value="Biometric device unavailable / service")
        ttk.Label(frm, text="Employee", style="Sub.TLabel").grid(row=2, column=0, sticky="w")
        ttk.Combobox(frm, textvariable=employee_var, values=list(employee_map), state="readonly").grid(row=3, column=0, columnspan=2, sticky="ew", pady=(2, 9))
        ttk.Label(frm, text="Work date (DD-MM-YYYY)", style="Sub.TLabel").grid(row=4, column=0, sticky="w")
        ttk.Label(frm, text="Payable hours", style="Sub.TLabel").grid(row=4, column=1, sticky="w")
        ttk.Entry(frm, textvariable=date_var).grid(row=5, column=0, sticky="ew", padx=(0, 8), pady=(2, 9))
        ttk.Entry(frm, textvariable=hours_var).grid(row=5, column=1, sticky="ew", pady=(2, 9))
        ttk.Label(frm, text="Clock-in time (optional, HH:MM)", style="Sub.TLabel").grid(row=6, column=0, sticky="w")
        ttk.Label(frm, text="Clock-out time (optional, HH:MM)", style="Sub.TLabel").grid(row=6, column=1, sticky="w")
        ttk.Entry(frm, textvariable=in_var).grid(row=7, column=0, sticky="ew", padx=(0, 8), pady=(2, 9))
        ttk.Entry(frm, textvariable=out_var).grid(row=7, column=1, sticky="ew", pady=(2, 9))
        ttk.Label(frm, text="Reason / authorisation (required)", style="Sub.TLabel").grid(row=8, column=0, columnspan=2, sticky="w")
        ttk.Entry(frm, textvariable=reason_var).grid(row=9, column=0, columnspan=2, sticky="ew", pady=(2, 9))
        ttk.Label(frm, text="Enter payable hours after any unpaid break. Manual entries are marked and audit-logged.", style="Sub.TLabel", wraplength=520).grid(row=10, column=0, columnspan=2, sticky="w", pady=(0, 12))
        frm.columnconfigure(0, weight=1); frm.columnconfigure(1, weight=1)

        def save_manual():
            employee_id = employee_map.get(employee_var.get())
            if not employee_id:
                messagebox.showerror("Select employee", "Select an employee.", parent=win); return
            try:
                work_date = stored_date(date_var.get().strip())
                parsed_date = datetime.strptime(work_date, "%Y-%m-%d")
                hours = float(hours_var.get().strip().replace(",", "."))
                if not 0 <= hours <= 24:
                    raise ValueError("Payable hours must be between 0 and 24.")
            except Exception as exc:
                messagebox.showerror("Check date or hours", f"Enter a valid date and payable hours.\n\n{exc}", parent=win); return
            reason = reason_var.get().strip()
            if not reason:
                messagebox.showerror("Reason required", "Enter the reason for the manual entry or its authorisation.", parent=win); return
            first = in_var.get().strip(); last = out_var.get().strip()
            for label, value in (("Clock-in", first), ("Clock-out", last)):
                if value:
                    try: datetime.strptime(value, "%H:%M")
                    except ValueError:
                        messagebox.showerror("Invalid time", f"{label} must use HH:MM format, for example 09:00.", parent=win); return
            existing = self.store.conn.execute("SELECT id,source,status FROM attendance_daily WHERE employee_id=? AND work_date=?", (employee_id, work_date)).fetchone()
            if existing and not messagebox.askyesno("Replace attendance record?", "An attendance record already exists for this employee and date. Replace its daily summary with this manual entry?", icon="warning", parent=win):
                return
            now = now_text()
            first_dt = f"{work_date} {first}:00" if first else ""
            last_dt = f"{work_date} {last}:00" if last else ""
            try:
                self.store.conn.execute("""INSERT INTO attendance_daily(employee_id,work_date,first_in,last_out,total_hours,late_minutes,early_minutes,overtime_minutes,status,notes,adjusted_by,adjusted_at,source)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?, 'Manual')
                    ON CONFLICT(employee_id,work_date) DO UPDATE SET first_in=excluded.first_in,last_out=excluded.last_out,total_hours=excluded.total_hours,late_minutes=0,early_minutes=0,overtime_minutes=0,status='Manual hours',notes=excluded.notes,adjusted_by=excluded.adjusted_by,adjusted_at=excluded.adjusted_at,source='Manual'""",
                    (employee_id, work_date, first_dt, last_dt, round(hours, 2), 0, 0, 0, "Manual hours", reason, self.actor, now))
                self.store.conn.commit()
                row = self.store.conn.execute("SELECT id FROM attendance_daily WHERE employee_id=? AND work_date=?", (employee_id, work_date)).fetchone()
                self.store.log(self.actor, "Added manual attendance hours", "attendance", row["id"], f"Date {work_date}; payable hours {hours:.2f}; reason: {reason}")
                messagebox.showinfo("Manual hours saved", "Manual attendance hours were saved and recorded in the audit trail.", parent=win)
                win.destroy()
                self.show_attendance()
            except Exception as exc:
                self.store.conn.rollback()
                messagebox.showerror("Could not save manual hours", str(exc), parent=win)

        buttons = ttk.Frame(frm); buttons.grid(row=11, column=0, columnspan=2, sticky="e", pady=(6, 0))
        ttk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Save manual hours", style="Primary.TButton", command=save_manual).pack(side="right")

    def attach_attendance_file(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select attendance", "Select an attendance day first.", parent=self)
            return
        attendance_id = int(selected[0])
        row = self.store.conn.execute("SELECT employee_id, work_date FROM attendance_daily WHERE id=?", (attendance_id,)).fetchone()
        if not row:
            messagebox.showerror("Attendance record not found", "The selected attendance record could not be found.", parent=self)
            return
        path = filedialog.askopenfilename(parent=self, title="Choose attendance supporting document", filetypes=[("Documents and images", "*.pdf *.doc *.docx *.xls *.xlsx *.csv *.jpg *.jpeg *.png *.txt"), ("All files", "*.*")])
        if not path:
            return
        src = Path(path)
        if not src.exists():
            messagebox.showerror("Attachment error", "The selected file could not be found.", parent=self)
            return
        try:
            suffix = src.suffix.lower() or ".dat"
            dest = DOC_DIR / f"attendance_{row['employee_id']}_{row['work_date']}_{secrets.token_hex(5)}{suffix}"
            shutil.copy2(src, dest)
            stamp = now_text()
            self.store.conn.execute("INSERT INTO attendance_attachments(attendance_daily_id,employee_id,work_date,file_path,file_name,created_at) VALUES(?,?,?,?,?,?)", (attendance_id, int(row["employee_id"]), row["work_date"], str(dest), src.name, stamp))
            self.store.log(self.actor, "Added attendance attachment", "attendance", attendance_id, f"{row['work_date']}: {src.name}")
            self.store.conn.commit()
            messagebox.showinfo("Attachment saved", f"The attendance attachment was saved successfully:\n\n{src.name}", parent=self)
            self.show_attendance()
        except OSError as exc:
            messagebox.showerror("Attachment error", f"Could not save the attachment:\n{exc}", parent=self)

    def open_attendance_attachment(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select attendance", "Select an attendance day first.", parent=self)
            return
        attendance_id = int(selected[0])
        row = self.store.conn.execute("SELECT file_path, file_name FROM attendance_attachments WHERE attendance_daily_id=? ORDER BY id DESC LIMIT 1", (attendance_id,)).fetchone()
        if not row:
            messagebox.showinfo("No attachment", "This attendance record does not have an attachment.", parent=self)
            return
        path = Path(row["file_path"])
        if not path.exists():
            messagebox.showerror("File not found", "The saved attendance attachment could not be found on this computer.", parent=self)
            return
        try:
            if os.name == "nt":
                os.startfile(str(path))
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Could not open attachment", str(exc), parent=self)

    def import_km30_excel(self):
        path=filedialog.askopenfilename(parent=self,title="Select KM30 Excel attendance report",filetypes=[("Excel workbook","*.xlsx"),("CSV file","*.csv"),("All files","*.*")])
        if not path: return
        try:
            if path.lower().endswith(".xlsx"):
                rows=self._read_km30_xlsx(path)
            else:
                import csv
                with open(path,"r",encoding="utf-8-sig",newline="") as f: rows=list(csv.reader(f))
            if not rows or len(rows)<2: raise ValueError("The selected file does not contain an attendance table.")
            # Find the first useful header row.
            header_index=0
            for i,row in enumerate(rows[:15]):
                joined=" ".join(str(x).lower() for x in row)
                if any(k in joined for k in ("user","employee","date","time","punch","attendance")):
                    header_index=i; break
            headers=rows[header_index]; data_rows=rows[header_index+1:]
            id_col,dt_col,date_col,time_col,type_col,name_col=self._km30_find_columns(headers)
            if id_col is None or (dt_col is None and (date_col is None or time_col is None)):
                raise ValueError("I could not identify the KM30 User ID and date/time columns in this Excel file.")
            employee_rows=self.store.employees()
            by_bio={str(r["biometric_id"]).strip().casefold():r for r in employee_rows if r["biometric_id"]}
            by_no={str(r["employee_no"]).strip().casefold():r for r in employee_rows}
            imported=duplicates=unmatched=invalid=0
            source=Path(path).name
            for row in data_rows:
                if not row or id_col>=len(row): continue
                bid=str(row[id_col]).strip()
                if not bid or bid.lower() in {"userid","employeeid","id"}: continue
                if dt_col is not None and dt_col<len(row): dt=self._parse_km30_datetime(row[dt_col])
                else:
                    d=str(row[date_col]).strip() if date_col is not None and date_col<len(row) else ""
                    t=str(row[time_col]).strip() if time_col is not None and time_col<len(row) else ""
                    dt=self._parse_km30_datetime(f"{d} {t}".strip())
                if not dt: invalid+=1; continue
                emp=by_bio.get(bid.casefold()) or by_no.get(bid.casefold())
                eid=emp["id"] if emp else None
                ptype=str(row[type_col]).strip() if type_col is not None and type_col<len(row) else ""
                raw=" | ".join(str(x) for x in row)
                _,ok=self.store.save_attendance_punch(bid,dt.strftime("%Y-%m-%d %H:%M:%S"),eid,ptype,source,raw)
                if ok: imported+=1
                else: duplicates+=1
                if emp is None: unmatched+=1
            self.store.conn.commit(); self.store.rebuild_attendance(self.actor)
            msg=f"KM30 import complete.\n\nImported: {imported}\nDuplicates skipped: {duplicates}\nUnmatched biometric IDs: {unmatched}\nInvalid date/time rows: {invalid}"
            if unmatched: msg += "\n\nTip: enter the KM30 User ID in the employee profile so future imports match automatically."
            messagebox.showinfo("KM30 import",msg,parent=self)
            self.show_attendance()
        except Exception as exc:
            messagebox.showerror("KM30 import error",f"The Excel file could not be imported:\n\n{exc}",parent=self)

    def attendance_settings(self):
        win=tk.Toplevel(self); win.title("Time & Attendance settings · Beyond Registration"); win.geometry("460x390"); win.transient(self); win.grab_set(); win.configure(bg=BG)
        ttk.Label(win,text="Time & Attendance settings",style="Title.TLabel").pack(anchor="w",padx=22,pady=(20,4))
        ttk.Label(win,text="These settings are used when daily attendance is calculated from KM30 punches.",style="Sub.TLabel",wraplength=410).pack(anchor="w",padx=22,pady=(0,16))
        frm=ttk.Frame(win,padding=22); frm.pack(fill="both",expand=True)
        fields=[("shift_start","Normal shift starts (HH:MM)"),("shift_end","Normal shift ends (HH:MM)"),("grace_minutes","Late grace period (minutes)"),("lunch_minutes","Standard lunch deduction (minutes)")]
        vars={}
        for i,(key,label) in enumerate(fields):
            ttk.Label(frm,text=label,style="Sub.TLabel").grid(row=i*2,column=0,sticky="w",pady=(6,2)); v=tk.StringVar(value=self.store.attendance_setting(key)); vars[key]=v; ttk.Entry(frm,textvariable=v).grid(row=i*2+1,column=0,sticky="ew",pady=(0,6))
        frm.columnconfigure(0,weight=1)
        def save():
            try:
                datetime.strptime(vars["shift_start"].get().strip(),"%H:%M"); datetime.strptime(vars["shift_end"].get().strip(),"%H:%M")
                for key in ("grace_minutes","lunch_minutes"): int(vars[key].get())
            except ValueError: messagebox.showerror("Invalid setting","Use HH:MM for shift times and whole numbers for minutes.",parent=win); return
            for k,v in vars.items(): self.store.set_attendance_setting(k,v.get().strip())
            self.store.rebuild_attendance(self.actor); win.destroy(); self.show_attendance()
        foot=ttk.Frame(win,padding=16); foot.pack(fill="x"); ttk.Button(foot,text="Cancel",command=win.destroy).pack(side="right"); ttk.Button(foot,text="Save settings",style="Primary.TButton",command=save).pack(side="right",padx=(0,8))

    def payroll_records(self, employee_id=None, pay_period=""):
        sql = """SELECT p.*, e.employee_no, e.first_name, e.last_name
                 FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE 1=1"""
        params=[]
        if employee_id:
            sql += " AND p.employee_id=?"; params.append(employee_id)
        if pay_period:
            sql += " AND p.pay_period=?"; params.append(pay_period)
        sql += " ORDER BY p.pay_period DESC, e.last_name, e.first_name, p.id DESC"
        return self.store.conn.execute(sql, params).fetchall()

    def save_payroll_record(self, data, actor):
        stamp=now_text()
        fields=["employee_id","pay_period","pay_date","basic_salary","weekday_hours","saturday_hours","sunday_hours","public_holiday_hours","overtime","allowances","bonus","gross_pay","paye","uif","other_deductions","total_deductions","net_pay","status","notes"]
        values=[data[k] for k in fields]
        cur=self.store.conn.execute("INSERT INTO payroll_records("+",".join(fields)+",created_at,updated_at) VALUES("+",".join(["?"]*(len(fields)+2))+")", values+[stamp,stamp])
        rid=int(cur.lastrowid)
        self.store.log(actor,"Added payroll record","payroll",rid,f"Employee ID {data['employee_id']}; period {data['pay_period']}")
        self.store.conn.commit()
        return rid

    def show_leave_management(self):
        self._shell("Leave management")
        ttk.Label(self.content, text="Leave Management", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Record applications, review supporting documents, approve or decline leave, and maintain configurable leave balances. Only approved leave is deducted from balances.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(5, 14))
        bar=ttk.Frame(self.content); bar.pack(fill="x", pady=(0,10))
        ttk.Button(bar,text="＋ New leave application",style="Primary.TButton",command=self.leave_form).pack(side="left")
        ttk.Button(bar,text="Set leave balance",command=self.leave_balance_form).pack(side="left",padx=8)
        ttk.Button(bar,text="Annual leave calculator",command=self.annual_leave_calculator).pack(side="left",padx=8)
        ttk.Button(bar,text="Approve selected",command=lambda:self.decide_leave(tree,"Approved")).pack(side="left",padx=8)
        ttk.Button(bar,text="Decline selected",command=lambda:self.decide_leave(tree,"Declined")).pack(side="left")
        ttk.Button(bar,text="View request / report",command=lambda:self.open_leave_report(tree)).pack(side="left",padx=8)
        ttk.Button(bar,text="Open attachment",command=lambda:self.open_leave_attachment(tree)).pack(side="left",padx=8)
        ttk.Button(bar,text="Refresh",command=self.show_leave_management).pack(side="left")
        frame=ttk.Frame(self.content,style="Card.TFrame",padding=6); frame.pack(fill="both",expand=True)
        cols=("employee","type","from","to","days","status","balance","attachment")
        tree=ttk.Treeview(frame,columns=cols,show="headings",selectmode="browse")
        for c,h,w in [("employee","Employee",190),("type","Leave type",150),("from","From",100),("to","To",100),("days","Days",65),("status","Status",100),("balance","Remaining balance",130),("attachment","Attachment",170)]:
            tree.heading(c,text=h); tree.column(c,width=w,anchor="w")
        y=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=y.set); tree.pack(side="left",fill="both",expand=True); y.pack(side="right",fill="y")
        rows=self.store.conn.execute("SELECT l.*, e.employee_no, e.first_name, e.last_name FROM leave_records l JOIN employees e ON e.id=l.employee_id ORDER BY l.id DESC").fetchall()
        for r in rows:
            balance=self.leave_remaining(int(r["employee_id"]),r["leave_type"])
            tree.insert("","end",iid=str(r["id"]),values=(f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}',r["leave_type"],display_date(r["date_from"]),display_date(r["date_to"]),f'{r["days"]:g}',r["status"],f'{balance:g}',r["attachment_name"] or "—"))
        tree.bind("<Double-1>",lambda _e:self.open_leave_report(tree))
        ttk.Label(self.content,text="Select a request and click View request / report, or double-click a row to view the full application. Dates must use DD-MM-YYYY (day-month-year).",style="Sub.TLabel",wraplength=950).pack(anchor="w",pady=(8,0))

    def open_leave_report(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select leave", "Select a leave application to view.", parent=self)
            return
        row = self.store.conn.execute("""SELECT l.*, e.employee_no, e.first_name, e.last_name, e.department, e.job_title
            FROM leave_records l JOIN employees e ON e.id=l.employee_id WHERE l.id=?""", (int(selected[0]),)).fetchone()
        if not row:
            messagebox.showerror("Leave application", "The selected application could not be found.", parent=self)
            return
        win = tk.Toplevel(self)
        win.title(f"Leave application report — {row['employee_no']}")
        win.geometry("720x700")
        win.transient(self)
        body = ttk.Frame(win, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Leave Application Report", style="Title.TLabel").pack(anchor="w", pady=(0, 12))
        fields = [
            ("Employee", f"{row['employee_no']} — {row['first_name']} {row['last_name']}"),
            ("Job title / department", f"{row['job_title'] or '—'} / {row['department'] or '—'}"),
            ("Leave type", row['leave_type']),
            ("Start date", row['date_from']),
            ("End date", row['date_to']),
            ("Working days requested", f"{row['days']:g}"),
            ("Status", row['status']),
            ("Submitted by", row['created_by'] or '—'),
            ("Submitted at", row['created_at'] or '—'),
            ("Decision by", row['decision_by'] or '—'),
            ("Decision date", row['decision_at'] or '—'),
            ("Supporting document", row['attachment_name'] or 'No attachment'),
        ]
        for label, value in fields:
            line = ttk.Frame(body)
            line.pack(fill="x", pady=2)
            ttk.Label(line, text=label + ":", width=23, style="Sub.TLabel").pack(side="left", anchor="nw")
            ttk.Label(line, text=value, wraplength=480).pack(side="left", anchor="nw", fill="x", expand=True)
        ttk.Label(body, text="Reason", style="CardTitle.TLabel").pack(anchor="w", pady=(12, 3))
        reason = tk.Text(body, height=5, wrap="word")
        reason.pack(fill="x")
        reason.insert("1.0", row['reason'] or "")
        reason.configure(state="disabled")
        ttk.Label(body, text="Additional notes", style="CardTitle.TLabel").pack(anchor="w", pady=(10, 3))
        notes = tk.Text(body, height=3, wrap="word")
        notes.pack(fill="x")
        notes.insert("1.0", row['notes'] or "")
        notes.configure(state="disabled")
        actions = ttk.Frame(body)
        actions.pack(fill="x", pady=(12, 0))
        if row['attachment_path']:
            def open_attachment():
                p = Path(row['attachment_path'])
                if not p.exists():
                    messagebox.showerror("Attachment missing", str(p), parent=win)
                    return
                try:
                    if os.name == "nt": os.startfile(str(p))
                    elif sys.platform == "darwin":
                        import subprocess; subprocess.Popen(["open", str(p)])
                    else:
                        import subprocess; subprocess.Popen(["xdg-open", str(p)])
                except Exception as exc:
                    messagebox.showerror("Open attachment", str(exc), parent=win)
            ttk.Button(actions, text="Open supporting document", command=open_attachment).pack(side="left")
        ttk.Button(actions, text="Close", command=win.destroy).pack(side="right")

    def leave_remaining(self, employee_id, leave_type):
        bal=self.store.conn.execute("SELECT opening_days, accrued_days FROM leave_balances WHERE employee_id=? AND leave_type=?",(employee_id,leave_type)).fetchone()
        if not bal: return 0.0
        used=self.store.conn.execute("SELECT COALESCE(SUM(days),0) FROM leave_records WHERE employee_id=? AND leave_type=? AND status='Approved'",(employee_id,leave_type)).fetchone()[0]
        return float(bal[0] or 0)+float(bal[1] or 0)-float(used or 0)

    def annual_leave_calculator(self):
        """Estimate annual leave accrual using recorded attendance days, at 1 day per 17 days."""
        win=tk.Toplevel(self); win.title("Annual leave calculator"); win.geometry("590x390"); win.transient(self); win.grab_set()
        body=ttk.Frame(win,padding=20); body.pack(fill="both",expand=True)
        employees=self.store.employees("")
        emap={f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}':int(r["id"]) for r in employees}
        ttk.Label(body,text="Annual Leave Calculator",style="Title.TLabel").grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,10))
        ttk.Label(body,text="Employee").grid(row=1,column=0,sticky="w",pady=5)
        emp=ttk.Combobox(body,values=list(emap),state="readonly",width=38); emp.grid(row=1,column=1,sticky="ew",pady=5)
        ttk.Label(body,text="From date (DD-MM-YYYY)").grid(row=2,column=0,sticky="w",pady=5)
        start=ttk.Entry(body); start.insert(0,"01-01-2026"); start.grid(row=2,column=1,sticky="ew",pady=5)
        ttk.Label(body,text="To date (DD-MM-YYYY)").grid(row=3,column=0,sticky="w",pady=5)
        end=ttk.Entry(body); end.insert(0,datetime.now().strftime("%d-%m-%Y")); end.grid(row=3,column=1,sticky="ew",pady=5)
        result=ttk.Label(body,text="Choose an employee and calculate.",wraplength=490)
        result.grid(row=5,column=0,columnspan=2,sticky="w",pady=(14,8))
        def calculate():
            try:
                if emp.get() not in emap: raise ValueError("Choose an employee.")
                d1=datetime.strptime(start.get().strip(),"%d-%m-%Y").date()
                d2=datetime.strptime(end.get().strip(),"%d-%m-%Y").date()
                if d2<d1: raise ValueError("The end date must be on or after the start date.")
                employee_id=emap[emp.get()]
                iso1=d1.isoformat(); iso2=d2.isoformat()
                days=int(self.store.conn.execute("SELECT COUNT(*) FROM attendance_daily WHERE employee_id=? AND work_date BETWEEN ? AND ? AND COALESCE(total_hours,0)>0",(employee_id,iso1,iso2)).fetchone()[0])
                accrued=days/17.0
                used=float(self.store.conn.execute("SELECT COALESCE(SUM(days),0) FROM leave_records WHERE employee_id=? AND leave_type='Annual' AND status='Approved' AND date_from<=? AND date_to>=?",(employee_id,iso2,iso1)).fetchone()[0] or 0)
                result.configure(text=f"Recorded days worked: {days}\nAnnual leave accrued at 1 day per 17 days: {accrued:.2f} days\nApproved annual leave overlapping this period: {used:.2f} days\nEstimated accrual less leave taken: {max(0,accrued-used):.2f} days\n\nThis is an estimate from attendance records with recorded hours. Check paid days/entitlements and the employee's leave-cycle opening balance before relying on it.")
            except ValueError as exc: messagebox.showerror("Annual leave calculator",str(exc),parent=win)
            except sqlite3.Error as exc: messagebox.showerror("Annual leave calculator",str(exc),parent=win)
        ttk.Button(body,text="Calculate",style="Primary.TButton",command=calculate).grid(row=4,column=1,sticky="e",pady=8)
        ttk.Button(body,text="Close",command=win.destroy).grid(row=6,column=1,sticky="e",pady=(8,0))
        body.columnconfigure(1,weight=1)

    def leave_balance_form(self):
        win=tk.Toplevel(self); win.title("Set leave balance"); win.geometry("480x330"); win.transient(self); win.grab_set()
        body=ttk.Frame(win,padding=20); body.pack(fill="both",expand=True)
        employees=self.store.employees(""); emap={f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}':int(r["id"]) for r in employees}
        ttk.Label(body,text="Employee").grid(row=0,column=0,sticky="w",pady=5); emp=ttk.Combobox(body,values=list(emap),state="readonly",width=34); emp.grid(row=0,column=1,sticky="ew",pady=5)
        ttk.Label(body,text="Leave type").grid(row=1,column=0,sticky="w",pady=5); typ=ttk.Combobox(body,values=["Annual","Sick","Family responsibility","Unpaid","Maternity","Parental","Study","Other"],width=32); typ.set("Annual"); typ.grid(row=1,column=1,sticky="ew",pady=5)
        ttk.Label(body,text="Opening balance (days)").grid(row=2,column=0,sticky="w",pady=5); opening=ttk.Entry(body); opening.insert(0,"0"); opening.grid(row=2,column=1,sticky="ew",pady=5)
        ttk.Label(body,text="Accrued/adjusted days").grid(row=3,column=0,sticky="w",pady=5); accrued=ttk.Entry(body); accrued.insert(0,"0"); accrued.grid(row=3,column=1,sticky="ew",pady=5)
        def save():
            try:
                if emp.get() not in emap or not typ.get().strip(): raise ValueError("Choose an employee and enter a leave type.")
                op=float(opening.get()); ac=float(accrued.get())
                self.store.conn.execute("INSERT INTO leave_balances(employee_id,leave_type,opening_days,accrued_days,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(employee_id,leave_type) DO UPDATE SET opening_days=excluded.opening_days, accrued_days=excluded.accrued_days, updated_at=excluded.updated_at",(emap[emp.get()],typ.get().strip(),op,ac,now_text()))
                self.store.log(self.actor,"Updated leave balance","leave_balance",emap[emp.get()],f'{typ.get()}: opening={op}, accrued={ac}'); self.store.conn.commit(); win.destroy(); self.show_leave_management()
            except (ValueError,sqlite3.Error) as e: messagebox.showerror("Leave balance",str(e),parent=win)
        ttk.Button(body,text="Save balance",style="Primary.TButton",command=save).grid(row=4,column=1,sticky="e",pady=16)

    def leave_form(self):
        win=tk.Toplevel(self); win.title("New leave application"); win.geometry("620x650"); win.transient(self); win.grab_set()
        body=ttk.Frame(win,padding=20); body.pack(fill="both",expand=True)
        employees=self.store.employees(""); emap={f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}':int(r["id"]) for r in employees}
        def field(label,row,widget="entry",values=None):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky="w",pady=6)
            w=ttk.Combobox(body,values=values,state="readonly" if label=="Employee" else "normal",width=38) if widget=="combo" else ttk.Entry(body,width=41)
            w.grid(row=row,column=1,sticky="ew",pady=6); return w
        emp=field("Employee",0,"combo",list(emap)); typ=field("Leave type",1,"combo",["Annual","Sick","Family responsibility","Unpaid","Maternity","Parental","Study","Other"]); typ.set("Annual")
        start=field("Start date (DD-MM-YYYY)",2); end=field("End date (DD-MM-YYYY)",3); days=field("Working days requested",4); days.insert(0,"1")
        ttk.Label(body,text="Reason").grid(row=5,column=0,sticky="nw",pady=6); reason=tk.Text(body,height=4,width=40,wrap="word"); reason.grid(row=5,column=1,sticky="ew",pady=6)
        attachment={"path":"","name":""}; ttk.Label(body,text="Supporting document").grid(row=6,column=0,sticky="w",pady=6); attach_label=ttk.Label(body,text="No attachment"); attach_label.grid(row=6,column=1,sticky="w")
        def attach():
            p=filedialog.askopenfilename(parent=win,title="Choose supporting document",filetypes=[("Documents and images","*.pdf *.doc *.docx *.jpg *.jpeg *.png *.txt"),("All files","*.*")])
            if p: attachment["path"]=p; attachment["name"]=Path(p).name; attach_label.configure(text=attachment["name"])
        ttk.Button(body,text="Attach file…",command=attach).grid(row=7,column=1,sticky="w",pady=5)
        ttk.Label(body,text="Notes (optional)").grid(row=8,column=0,sticky="nw",pady=6); notes=tk.Text(body,height=3,width=40,wrap="word"); notes.grid(row=8,column=1,sticky="ew",pady=6)
        def save():
            try:
                if emp.get() not in emap: raise ValueError("Select an employee.")
                start_iso=stored_date(start.get()); end_iso=stored_date(end.get()); d1=datetime.strptime(start_iso,"%Y-%m-%d"); d2=datetime.strptime(end_iso,"%Y-%m-%d")
                if d2<d1: raise ValueError("End date cannot be before start date.")
                n=float(days.get());
                if n<=0: raise ValueError("Working days must be greater than zero.")
                file_path=""
                if attachment["path"]:
                    src=Path(attachment["path"]); destdir=DOC_DIR/"LeaveAttachments"; destdir.mkdir(parents=True,exist_ok=True); dest=destdir/f'{datetime.now().strftime("%Y%m%d%H%M%S%f")}_{src.name}'; shutil.copy2(src,dest); file_path=str(dest)
                stamp=now_text(); cur=self.store.conn.execute("INSERT INTO leave_records(employee_id,leave_type,date_from,date_to,days,reason,status,attachment_path,attachment_name,notes,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(emap[emp.get()],typ.get().strip(),start_iso,end_iso,n,reason.get("1.0","end").strip(),"Pending",file_path,attachment["name"],notes.get("1.0","end").strip(),self.actor,stamp,stamp))
                self.store.log(self.actor,"Created leave application","leave",cur.lastrowid,f'{emp.get()}: {typ.get()} {start.get()} to {end.get()} ({n} days)'); self.store.conn.commit(); win.destroy(); self.show_leave_management()
            except (ValueError,sqlite3.Error,OSError) as e: messagebox.showerror("Leave application",str(e),parent=win)
        ttk.Button(body,text="Save application",style="Primary.TButton",command=save).grid(row=9,column=1,sticky="e",pady=14)

    def decide_leave(self, tree, decision):
        selected=tree.selection()
        if not selected: messagebox.showinfo("Select leave", "Select a leave application first.",parent=self); return
        row=self.store.conn.execute("SELECT status FROM leave_records WHERE id=?",(int(selected[0]),)).fetchone()
        if not row: return
        if row["status"]!="Pending": messagebox.showinfo("Leave decision",f'This application is already {row["status"]}.',parent=self); return
        if not messagebox.askyesno("Confirm decision",f"{decision} this leave application?",parent=self): return
        self.store.conn.execute("UPDATE leave_records SET status=?,decision_by=?,decision_at=?,updated_at=? WHERE id=?",(decision,self.actor,now_text(),now_text(),int(selected[0])))
        self.store.log(self.actor,f'{decision} leave application',"leave",selected[0]); self.store.conn.commit(); self.show_leave_management()

    def open_leave_attachment(self, tree):
        selected=tree.selection()
        if not selected: messagebox.showinfo("Select leave", "Select a leave application first.",parent=self); return
        row=self.store.conn.execute("SELECT attachment_path,attachment_name FROM leave_records WHERE id=?",(int(selected[0]),)).fetchone()
        if not row or not row["attachment_path"]: messagebox.showinfo("No attachment", "This leave application has no supporting document attached.",parent=self); return
        p=Path(row["attachment_path"])
        if not p.exists(): messagebox.showerror("Attachment missing",str(p),parent=self); return
        try:
            if os.name=="nt": os.startfile(str(p))
            elif sys.platform=="darwin": import subprocess; subprocess.Popen(["open",str(p)])
            else: import subprocess; subprocess.Popen(["xdg-open",str(p)])
        except Exception as e: messagebox.showerror("Open attachment",str(e),parent=self)

    def show_contracts(self):
        self._shell("Contracts")
        ttk.Label(self.content, text="Employee Contract Management", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Store contracts, amendments and renewals against each employee. Previous contracts remain in the history. Dates use DD-MM-YYYY.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(5, 14))
        bar = ttk.Frame(self.content); bar.pack(fill="x", pady=(0, 10))
        ttk.Button(bar, text="＋ Add contract", style="Primary.TButton", command=self.contract_form).pack(side="left")
        ttk.Button(bar, text="View contract", command=lambda: self.open_contract_report(tree)).pack(side="left", padx=8)
        ttk.Button(bar, text="Open document", command=lambda: self.open_contract_attachment(tree)).pack(side="left")
        ttk.Button(bar, text="Refresh", command=self.show_contracts).pack(side="left", padx=8)
        frame = ttk.Frame(self.content, style="Card.TFrame", padding=6); frame.pack(fill="both", expand=True)
        cols = ("employee", "type", "title", "start", "end", "probation", "status", "document")
        tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")
        for c, h, w in [
            ("employee", "Employee", 190), ("type", "Contract type", 150),
            ("title", "Title / description", 200), ("start", "Start date", 100),
            ("end", "End date", 100), ("probation", "Probation end", 105),
            ("status", "Status", 90), ("document", "Document", 180)
        ]:
            tree.heading(c, text=h); tree.column(c, width=w, anchor="w")
        y = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=y.set)
        tree.pack(side="left", fill="both", expand=True); y.pack(side="right", fill="y")
        rows = self.store.conn.execute("""SELECT c.*, e.employee_no, e.first_name, e.last_name
            FROM employee_contracts c JOIN employees e ON e.id=c.employee_id
            ORDER BY c.id DESC""").fetchall()
        today = datetime.now().date()
        for r in rows:
            status = r["status"]
            if r["end_date"] and status == "Active":
                try:
                    if datetime.strptime(r["end_date"], "%Y-%m-%d").date() < today:
                        status = "Expired"
                except ValueError:
                    pass
            tree.insert("", "end", iid=str(r["id"]), values=(
                f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}',
                r["contract_type"], r["title"], display_date(r["start_date"]),
                display_date(r["end_date"]), display_date(r["probation_end"]),
                status, r["file_name"] or "—"))
        tree.bind("<Double-1>", lambda _e: self.open_contract_report(tree))
        ttk.Label(self.content, text="Double-click a contract to view its details. Use Open document to open the attached contract file.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(8, 0))

    def contract_form(self):
        win = tk.Toplevel(self); win.title("Add employee contract"); win.geometry("700x690")
        win.transient(self); win.grab_set()
        body = ttk.Frame(win, padding=20); body.pack(fill="both", expand=True)
        employees = self.store.employees("")
        emap = {f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}': int(r["id"]) for r in employees}
        def add_field(label, row, values=None):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", pady=6)
            if values is not None:
                w = ttk.Combobox(body, values=values, state="readonly", width=42)
            else:
                w = ttk.Entry(body, width=45)
            w.grid(row=row, column=1, sticky="ew", pady=6)
            return w
        emp = add_field("Employee", 0, list(emap))
        typ = add_field("Contract type", 1, ["Employment contract", "Fixed-term contract", "Permanent contract", "Amendment", "Renewal", "Probation agreement", "Other"])
        typ.set("Employment contract")
        title = add_field("Title / description", 2); title.insert(0, "Employment contract")
        start = add_field("Start date (DD-MM-YYYY)", 3)
        end = add_field("End date (DD-MM-YYYY, if applicable)", 4)
        probation = add_field("Probation end date (DD-MM-YYYY, if applicable)", 5)
        status = add_field("Status", 6, ["Active", "Pending signature", "Superseded", "Terminated", "Expired"])
        status.set("Active")
        ttk.Label(body, text="Notes / amendments").grid(row=7, column=0, sticky="nw", pady=6)
        notes = tk.Text(body, height=4, width=42, wrap="word"); notes.grid(row=7, column=1, sticky="ew", pady=6)
        attachment = {"path": "", "name": ""}
        ttk.Label(body, text="Contract document").grid(row=8, column=0, sticky="w", pady=6)
        attach_label = ttk.Label(body, text="No document attached", wraplength=360)
        attach_label.grid(row=8, column=1, sticky="w", pady=6)
        def choose_file():
            p = filedialog.askopenfilename(parent=win, title="Choose contract document",
                filetypes=[("Documents", "*.pdf *.doc *.docx *.odt *.rtf"), ("All files", "*.*")])
            if p:
                attachment["path"] = p
                attachment["name"] = Path(p).name
                attach_label.configure(text=attachment["name"])
        ttk.Button(body, text="Attach contract…", command=choose_file).grid(row=9, column=1, sticky="w", pady=5)
        def save():
            try:
                if emp.get() not in emap:
                    raise ValueError("Select an employee.")
                if not title.get().strip():
                    raise ValueError("Enter a title or description.")
                def parse_optional_date(value, label):
                    value = value.strip()
                    if not value:
                        return ""
                    return stored_date(value)
                start_iso = parse_optional_date(start.get(), "Start date")
                end_iso = parse_optional_date(end.get(), "End date")
                probation_iso = parse_optional_date(probation.get(), "Probation end date")
                if start_iso and end_iso and end_iso < start_iso:
                    raise ValueError("End date cannot be before start date.")
                if attachment["path"]:
                    source_file = Path(attachment["path"])
                    folder = DOC_DIR / "Contracts"; folder.mkdir(parents=True, exist_ok=True)
                    target = folder / f'{datetime.now().strftime("%Y%m%d%H%M%S%f")}_{source_file.name}'
                    shutil.copy2(source_file, target)
                    file_path = str(target)
                else:
                    file_path = ""
                stamp = now_text()
                cur = self.store.conn.execute("""INSERT INTO employee_contracts
                    (employee_id,contract_type,title,start_date,end_date,probation_end,status,notes,
                     file_path,file_name,created_by,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (emap[emp.get()], typ.get().strip(), title.get().strip(), start_iso, end_iso,
                     probation_iso, status.get(), notes.get("1.0", "end").strip(), file_path,
                     attachment["name"], self.actor, stamp, stamp))
                self.store.log(self.actor, "Added employee contract", "contract", cur.lastrowid,
                    f'{emp.get()}: {title.get().strip()}')
                self.store.conn.commit()
                win.destroy(); self.show_contracts()
            except (ValueError, sqlite3.Error, OSError) as exc:
                messagebox.showerror("Save contract", str(exc), parent=win)
        buttons = ttk.Frame(body); buttons.grid(row=10, column=1, sticky="e", pady=16)
        ttk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Save contract", style="Primary.TButton", command=save).pack(side="right")

    def open_contract_report(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select contract", "Select a contract first.", parent=self); return
        row = self.store.conn.execute("""SELECT c.*, e.employee_no, e.first_name, e.last_name,
            e.job_title, e.department FROM employee_contracts c
            JOIN employees e ON e.id=c.employee_id WHERE c.id=?""", (int(selected[0]),)).fetchone()
        if not row:
            messagebox.showerror("Contract", "The selected contract could not be found.", parent=self); return
        win = tk.Toplevel(self); win.title(f'Contract report — {row["employee_no"]}'); win.geometry("700x620")
        body = ttk.Frame(win, padding=20); body.pack(fill="both", expand=True)
        ttk.Label(body, text="Employee Contract Report", style="Title.TLabel").pack(anchor="w", pady=(0, 12))
        details = [
            ("Employee", f'{row["employee_no"]} — {row["first_name"]} {row["last_name"]}'),
            ("Job title / department", f'{row["job_title"] or "—"} / {row["department"] or "—"}'),
            ("Contract type", row["contract_type"]), ("Title / description", row["title"]),
            ("Start date", display_date(row["start_date"]) or "—"),
            ("End date", display_date(row["end_date"]) or "Not specified"),
            ("Probation end date", display_date(row["probation_end"]) or "Not specified"),
            ("Status", row["status"]), ("Document", row["file_name"] or "No document attached"),
            ("Created by", row["created_by"] or "—"), ("Created at", row["created_at"] or "—"),
        ]
        for label, value in details:
            line = ttk.Frame(body); line.pack(fill="x", pady=3)
            ttk.Label(line, text=label, width=23, style="Sub.TLabel").pack(side="left", anchor="nw")
            ttk.Label(line, text=value, wraplength=440).pack(side="left", fill="x", expand=True, anchor="w")
        ttk.Label(body, text="Notes / amendments", style="Sub.TLabel").pack(anchor="w", pady=(12, 3))
        note_box = tk.Text(body, height=5, wrap="word"); note_box.pack(fill="both", expand=True)
        note_box.insert("1.0", row["notes"] or ""); note_box.configure(state="disabled")
        actions = ttk.Frame(body); actions.pack(fill="x", pady=(12, 0))
        if row["file_path"] and Path(row["file_path"]).exists():
            ttk.Button(actions, text="Open contract document",
                command=lambda p=row["file_path"]: self._open_document_path(p)).pack(side="left")
        ttk.Button(actions, text="Close", command=win.destroy).pack(side="right")

    def open_contract_attachment(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select contract", "Select a contract first.", parent=self); return
        row = self.store.conn.execute("SELECT file_path FROM employee_contracts WHERE id=?", (int(selected[0]),)).fetchone()
        if not row or not row["file_path"]:
            messagebox.showinfo("No document", "This contract has no document attached.", parent=self); return
        self._open_document_path(row["file_path"])

    def _open_document_path(self, path):
        p = Path(path)
        if not p.exists():
            messagebox.showerror("Document missing", f"The document could not be found:\n{p}", parent=self); return
        try:
            if os.name == "nt":
                os.startfile(str(p))
            elif sys.platform == "darwin":
                import subprocess; subprocess.Popen(["open", str(p)])
            else:
                import subprocess; subprocess.Popen(["xdg-open", str(p)])
        except Exception as exc:
            messagebox.showerror("Open document", str(exc), parent=self)

    def show_employee_documents(self):
        self._shell("Employee documents")
        ttk.Label(self.content, text="Employee Document Register", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Keep employee IDs, permits, licences, certificates and other important documents in one register. Expiry status is calculated from the expiry date; dates use DD-MM-YYYY.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(5, 14))
        bar=ttk.Frame(self.content); bar.pack(fill="x",pady=(0,10))
        ttk.Button(bar,text="＋ Add document",style="Primary.TButton",command=self.employee_document_form).pack(side="left")
        ttk.Button(bar,text="View document record",command=lambda:self.open_employee_document(tree)).pack(side="left",padx=8)
        ttk.Button(bar,text="Open attachment",command=lambda:self.open_employee_document_attachment(tree)).pack(side="left")
        ttk.Button(bar,text="Refresh",command=self.show_employee_documents).pack(side="left",padx=8)
        frame=ttk.Frame(self.content,style="Card.TFrame",padding=6); frame.pack(fill="both",expand=True)
        cols=("employee","type","title","number","expiry","status","attachment")
        tree=ttk.Treeview(frame,columns=cols,show="headings",selectmode="browse")
        for c,h,w in [("employee","Employee",205),("type","Document type",145),("title","Document title",180),("number","Document number",130),("expiry","Expiry date",105),("status","Status",110),("attachment","Attachment",160)]:
            tree.heading(c,text=h); tree.column(c,width=w,anchor="w")
        y=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=y.set)
        tree.pack(side="left",fill="both",expand=True); y.pack(side="right",fill="y")
        rows=self.store.conn.execute("""SELECT d.*,e.employee_no,e.first_name,e.last_name FROM employee_documents d JOIN employees e ON e.id=d.employee_id ORDER BY CASE WHEN d.expiry_date='' THEN 1 ELSE 0 END,d.expiry_date,d.id DESC""").fetchall()
        today=datetime.now().date()
        for r in rows:
            status=r["status"] or "Current"
            if r["expiry_date"]:
                try:
                    expiry=datetime.strptime(r["expiry_date"],"%Y-%m-%d").date()
                    if expiry < today and status not in ("Archived","Not applicable"):
                        status="Expired"
                    elif expiry <= today+timedelta(days=60) and status not in ("Archived","Not applicable"):
                        status="Expires within 60 days"
                except (ValueError,TypeError):
                    pass
            tree.insert("","end",iid=str(r["id"]),values=(f'{r["employee_no"]} — {r["first_name"]} {r["last_name"]}',r["document_type"],r["title"],r["document_number"] or "—",display_date(r["expiry_date"]) or "No expiry",status,r["file_name"] or "—"))
        tree.bind("<Double-1>",lambda _e:self.open_employee_document(tree))
        ttk.Label(self.content,text="Expired and soon-to-expire documents are highlighted in the Status column. Double-click a row to view its full record.",style="Sub.TLabel",wraplength=950).pack(anchor="w",pady=(8,0))

    def employee_document_form(self):
        win=tk.Toplevel(self); win.title("Add employee document"); win.geometry("680x660"); win.transient(self); win.grab_set()
        body=ttk.Frame(win,padding=20); body.pack(fill="both",expand=True)
        employees=self.store.employees(""); emap={f'{r["employee_no"]} — {r["first_name"]} {r["last_name"]}':int(r["id"]) for r in employees}
        def field(label,row,values=None):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky="w",pady=5)
            w=ttk.Combobox(body,values=values,state="readonly",width=38) if values is not None else ttk.Entry(body,width=41)
            w.grid(row=row,column=1,sticky="ew",pady=5); return w
        emp=field("Employee",0,list(emap))
        dtype=field("Document type",1,["Identity document","Passport","Work permit","Driver's licence","Professional licence","Qualification / certificate","First aid certificate","Medical certificate","Proof of address","Tax document","Other"]); dtype.set("Identity document")
        title=field("Document title",2)
        number=field("Document number (optional)",3)
        issue=field("Issue date (DD-MM-YYYY, optional)",4)
        expiry=field("Expiry date (DD-MM-YYYY, optional)",5)
        status=field("Record status",6,["Current","Pending renewal","Archived","Not applicable"]); status.set("Current")
        ttk.Label(body,text="Notes").grid(row=7,column=0,sticky="nw",pady=5)
        notes=tk.Text(body,height=4,width=42,wrap="word"); notes.grid(row=7,column=1,sticky="ew",pady=5)
        attachment={"path":"","name":""}; attach_label=ttk.Label(body,text="No document attached",wraplength=340); attach_label.grid(row=8,column=1,sticky="w",pady=4)
        def choose_file():
            chosen=filedialog.askopenfilename(parent=win,title="Attach employee document",filetypes=[("Documents","*.pdf *.doc *.docx *.odt *.rtf *.jpg *.jpeg *.png"),("All files","*.*")])
            if chosen: attachment["path"]=chosen; attachment["name"]=Path(chosen).name; attach_label.configure(text=attachment["name"])
        ttk.Button(body,text="Attach document…",command=choose_file).grid(row=9,column=1,sticky="w",pady=4); body.columnconfigure(1,weight=1)
        def save():
            try:
                if emp.get() not in emap: raise ValueError("Select an employee.")
                if not title.get().strip(): raise ValueError("Enter a document title.")
                issue_iso=stored_date(issue.get().strip()) if issue.get().strip() else ""
                expiry_iso=stored_date(expiry.get().strip()) if expiry.get().strip() else ""
                if issue_iso and expiry_iso and expiry_iso < issue_iso: raise ValueError("Expiry date cannot be before issue date.")
                file_path=""
                if attachment["path"]:
                    src=Path(attachment["path"]); folder=DOC_DIR/"EmployeeDocuments"; folder.mkdir(parents=True,exist_ok=True)
                    dest=folder/f'{datetime.now().strftime("%Y%m%d%H%M%S%f")}_{src.name}'; shutil.copy2(src,dest); file_path=str(dest)
                stamp=now_text()
                cur=self.store.conn.execute("""INSERT INTO employee_documents(employee_id,document_type,title,document_number,issue_date,expiry_date,status,notes,file_path,file_name,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (emap[emp.get()],dtype.get(),title.get().strip(),number.get().strip(),issue_iso,expiry_iso,status.get(),notes.get("1.0","end").strip(),file_path,attachment["name"],self.actor,stamp,stamp))
                self.store.log(self.actor,"Created employee document record","employee_document",cur.lastrowid,f'{emp.get()}: {title.get().strip()}')
                self.store.conn.commit(); win.destroy(); self.show_employee_documents()
            except (ValueError,sqlite3.Error,OSError) as exc: messagebox.showerror("Save employee document",str(exc),parent=win)
        buttons=ttk.Frame(body); buttons.grid(row=10,column=1,sticky="e",pady=12)
        ttk.Button(buttons,text="Cancel",command=win.destroy).pack(side="right",padx=(8,0)); ttk.Button(buttons,text="Save document",style="Primary.TButton",command=save).pack(side="right")

    def open_employee_document(self,tree):
        selected=tree.selection()
        if not selected: messagebox.showinfo("Select document","Select an employee document first.",parent=self); return
        row=self.store.conn.execute("""SELECT d.*,e.employee_no,e.first_name,e.last_name,e.job_title,e.department FROM employee_documents d JOIN employees e ON e.id=d.employee_id WHERE d.id=?""",(int(selected[0]),)).fetchone()
        if not row: messagebox.showerror("Document record","The selected document record could not be found.",parent=self); return
        status=row["status"] or "Current"
        if row["expiry_date"]:
            try:
                expiry=datetime.strptime(row["expiry_date"],"%Y-%m-%d").date()
                if expiry < datetime.now().date() and status not in ("Archived","Not applicable"): status="Expired"
                elif expiry <= datetime.now().date()+timedelta(days=60) and status not in ("Archived","Not applicable"): status="Expires within 60 days"
            except (ValueError,TypeError): pass
        win=tk.Toplevel(self); win.title("Employee document record"); win.geometry("700x610")
        body=ttk.Frame(win,padding=20); body.pack(fill="both",expand=True)
        ttk.Label(body,text="Employee Document Record",style="Title.TLabel").pack(anchor="w",pady=(0,10))
        details=[("Employee",f'{row["employee_no"]} — {row["first_name"]} {row["last_name"]}'),("Job / department",f'{row["job_title"] or "—"} / {row["department"] or "—"}'),("Document type",row["document_type"]), ("Title",row["title"]),("Document number",row["document_number"] or "—"),("Issue date",display_date(row["issue_date"]) or "—"),("Expiry date",display_date(row["expiry_date"]) or "No expiry"),("Status",status),("Attachment",row["file_name"] or "No attachment"),("Created by",row["created_by"] or "—"),("Created at",row["created_at"] or "—")]
        for label,value in details:
            line=ttk.Frame(body); line.pack(fill="x",pady=2); ttk.Label(line,text=label,width=20,style="Sub.TLabel").pack(side="left",anchor="nw"); ttk.Label(line,text=value,wraplength=460).pack(side="left",fill="x",expand=True,anchor="w")
        ttk.Label(body,text="Notes",style="Sub.TLabel").pack(anchor="w",pady=(10,2)); note=tk.Text(body,height=4,wrap="word"); note.pack(fill="both",expand=True); note.insert("1.0",row["notes"] or ""); note.configure(state="disabled")
        actions=ttk.Frame(body); actions.pack(fill="x",pady=(10,0))
        if row["file_path"] and Path(row["file_path"]).exists(): ttk.Button(actions,text="Open attached document",command=lambda p=row["file_path"]:self._open_document_path(p)).pack(side="left")
        ttk.Button(actions,text="Close",command=win.destroy).pack(side="right")

    def open_employee_document_attachment(self,tree):
        selected=tree.selection()
        if not selected: messagebox.showinfo("Select document","Select an employee document first.",parent=self); return
        row=self.store.conn.execute("SELECT file_path FROM employee_documents WHERE id=?",(int(selected[0]),)).fetchone()
        if not row or not row["file_path"]: messagebox.showinfo("No attachment","This document record has no attachment.",parent=self); return
        self._open_document_path(row["file_path"])

    def show_performance_reviews(self):
        self._shell("Performance reviews")
        ttk.Label(self.content, text="Employee Performance Reviews", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="Record appraisal discussions, strengths, development areas and agreed goals. Reviews are retained in the employee's history. Dates use DD-MM-YYYY.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(5, 14))
        bar=ttk.Frame(self.content); bar.pack(fill="x",pady=(0,10))
        ttk.Button(bar,text="＋ New review",style="Primary.TButton",command=self.performance_review_form).pack(side="left")
        ttk.Button(bar,text="View review",command=lambda:self.open_performance_review(tree)).pack(side="left",padx=8)
        ttk.Button(bar,text="Open attachment",command=lambda:self.open_performance_attachment(tree)).pack(side="left")
        ttk.Button(bar,text="Refresh",command=self.show_performance_reviews).pack(side="left",padx=8)
        frame=ttk.Frame(self.content,style="Card.TFrame",padding=6); frame.pack(fill="both",expand=True)
        cols=("employee","date","period","reviewer","rating","kpi","status","followup")
        tree=ttk.Treeview(frame,columns=cols,show="headings",selectmode="browse")
        for c,h,w in [("employee","Employee",210),("date","Review date",100),("period","Review period",150),("reviewer","Reviewer",150),("rating","Overall rating",130),("kpi","KPI / 100",85),("status","Status",100),("followup","Follow-up date",110)]:
            tree.heading(c,text=h); tree.column(c,width=w,anchor="w")
        y=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=y.set)
        tree.pack(side="left",fill="both",expand=True); y.pack(side="right",fill="y")
        rows=self.store.conn.execute("""SELECT r.*,e.employee_no,e.first_name,e.last_name FROM performance_reviews r JOIN employees e ON e.id=r.employee_id ORDER BY r.review_date DESC,r.id DESC""").fetchall()
        for r in rows:
            tree.insert("","end",iid=str(r["id"]),values=(f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}',display_date(r["review_date"]),r["review_period"] or "—",r["reviewer"] or "—",r["overall_rating"] or "—",(f'{r["kpi_score"]:.0f}' if r["kpi_score"] is not None else "—"),r["status"],display_date(r["follow_up_date"]) or "—"))
        tree.bind("<Double-1>",lambda _e:self.open_performance_review(tree))
        ttk.Label(self.content,text="Double-click a review to view the full appraisal record.",style="Sub.TLabel").pack(anchor="w",pady=(8,0))

    def performance_review_form(self):
        win=tk.Toplevel(self); win.title("New performance review"); win.geometry("800x790"); win.transient(self); win.grab_set()
        body=ttk.Frame(win,padding=18); body.pack(fill="both",expand=True)
        employees=self.store.employees(""); emap={f'{r["employee_no"]} - {r["first_name"]} {r["last_name"]}':int(r["id"]) for r in employees}
        def field(label,row,values=None):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky="w",pady=5)
            w=ttk.Combobox(body,values=values,state="readonly",width=42) if values is not None else ttk.Entry(body,width=45)
            w.grid(row=row,column=1,sticky="ew",pady=5); return w
        emp=field("Employee",0,list(emap))
        review_date=field("Review date (DD-MM-YYYY)",1); review_date.insert(0,datetime.now().strftime("%d-%m-%Y"))
        period=field("Review period",2); reviewer=field("Reviewer / manager",3); reviewer.insert(0,self.actor)
        rating=field("Overall rating",4,["Outstanding","Exceeds expectations","Meets expectations","Needs improvement","Unsatisfactory","Not rated"]); rating.set("Meets expectations")
        ttk.Label(body,text="KPI score (0–100, optional)").grid(row=5,column=0,sticky="w",pady=5)
        score=ttk.Spinbox(body,from_=0,to=100,increment=1,width=12); score.set(85); score.grid(row=5,column=1,sticky="w",pady=5)
        status=field("Status",6,["Draft","Completed","Follow-up required"]); status.set("Draft")
        follow=field("Follow-up date (DD-MM-YYYY, optional)",7)
        def text_field(label,row,height=3):
            ttk.Label(body,text=label).grid(row=row,column=0,sticky="nw",pady=5)
            w=tk.Text(body,height=height,width=48,wrap="word"); w.grid(row=row,column=1,sticky="ew",pady=5); return w
        strengths=text_field("Strengths / achievements",8); improvements=text_field("Development / improvement areas",9)
        goals=text_field("Agreed goals and actions",10); comments=text_field("Employee comments",11,2)
        attachment={"path":"","name":""}; attach_label=ttk.Label(body,text="No document attached",wraplength=360); attach_label.grid(row=12,column=1,sticky="w",pady=4)
        def choose_file():
            chosen=filedialog.askopenfilename(parent=win,title="Attach appraisal document",filetypes=[("Documents","*.pdf *.doc *.docx *.odt *.rtf"),("All files","*.*")])
            if chosen: attachment["path"]=chosen; attachment["name"]=Path(chosen).name; attach_label.configure(text=attachment["name"])
        ttk.Button(body,text="Attach document…",command=choose_file).grid(row=13,column=1,sticky="w",pady=4); body.columnconfigure(1,weight=1)
        def save():
            try:
                if emp.get() not in emap: raise ValueError("Select an employee.")
                review_iso=stored_date(review_date.get().strip()); follow_iso=stored_date(follow.get().strip()) if follow.get().strip() else ""
                score_value=score.get().strip()
                kpi_score=float(score_value) if score_value else None
                if kpi_score is not None and not 0 <= kpi_score <= 100: raise ValueError("KPI score must be between 0 and 100.")
                file_path=""
                if attachment["path"]:
                    src=Path(attachment["path"]); folder=DOC_DIR/"PerformanceReviews"; folder.mkdir(parents=True,exist_ok=True)
                    dest=folder/f'{datetime.now().strftime("%Y%m%d%H%M%S%f")}_{src.name}'; shutil.copy2(src,dest); file_path=str(dest)
                stamp=now_text()
                cur=self.store.conn.execute("""INSERT INTO performance_reviews(employee_id,review_date,review_period,reviewer,overall_rating,kpi_score,strengths,improvement_areas,goals,employee_comments,follow_up_date,status,file_path,file_name,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (emap[emp.get()],review_iso,period.get().strip(),reviewer.get().strip(),rating.get(),kpi_score,strengths.get("1.0","end").strip(),improvements.get("1.0","end").strip(),goals.get("1.0","end").strip(),comments.get("1.0","end").strip(),follow_iso,status.get(),file_path,attachment["name"],self.actor,stamp,stamp))
                self.store.log(self.actor,"Created performance review","performance_review",cur.lastrowid,f'{emp.get()}: {display_date(review_iso)}')
                self.store.conn.commit(); win.destroy(); self.show_performance_reviews()
            except (ValueError,sqlite3.Error,OSError) as exc: messagebox.showerror("Save performance review",str(exc),parent=win)
        buttons=ttk.Frame(body); buttons.grid(row=14,column=1,sticky="e",pady=12)
        ttk.Button(buttons,text="Cancel",command=win.destroy).pack(side="right",padx=(8,0)); ttk.Button(buttons,text="Save review",style="Primary.TButton",command=save).pack(side="right")

    def open_performance_review(self,tree):
        selected=tree.selection()
        if not selected: messagebox.showinfo("Select review","Select a performance review first.",parent=self); return
        row=self.store.conn.execute("""SELECT r.*,e.employee_no,e.first_name,e.last_name,e.job_title,e.department FROM performance_reviews r JOIN employees e ON e.id=r.employee_id WHERE r.id=?""",(int(selected[0]),)).fetchone()
        if not row: messagebox.showerror("Review","The selected review could not be found.",parent=self); return
        win=tk.Toplevel(self); win.title(f'Performance review — {row["employee_no"]}'); win.geometry("760x760")
        body=ttk.Frame(win,padding=20); body.pack(fill="both",expand=True); ttk.Label(body,text="Employee Performance Review",style="Title.TLabel").pack(anchor="w",pady=(0,10))
        details=[("Employee",f'{row["employee_no"]} — {row["first_name"]} {row["last_name"]}'),("Job / department",f'{row["job_title"] or "—"} / {row["department"] or "—"}'),("Review date",display_date(row["review_date"])),("Review period",row["review_period"] or "—"),("Reviewer",row["reviewer"] or "—"),("Overall rating",row["overall_rating"] or "—"),("KPI score",f'{row["kpi_score"]}/100' if row["kpi_score"] is not None else "Not scored"),("Status",row["status"]),("Follow-up date",display_date(row["follow_up_date"]) or "—"),("Attachment",row["file_name"] or "No document attached")]
        for label,value in details:
            line=ttk.Frame(body); line.pack(fill="x",pady=2); ttk.Label(line,text=label,width=20,style="Sub.TLabel").pack(side="left",anchor="nw"); ttk.Label(line,text=value,wraplength=500).pack(side="left",fill="x",expand=True,anchor="w")
        for label,key in [("Strengths / achievements","strengths"),("Development / improvement areas","improvement_areas"),("Agreed goals and actions","goals"),("Employee comments","employee_comments")]:
            ttk.Label(body,text=label,style="Sub.TLabel").pack(anchor="w",pady=(10,2)); box=tk.Text(body,height=3,wrap="word"); box.pack(fill="x"); box.insert("1.0",row[key] or ""); box.configure(state="disabled")
        if row["file_path"]: ttk.Button(body,text="Open attached document",command=lambda:self._open_document_path(row["file_path"])).pack(anchor="w",pady=10)
        ttk.Button(body,text="Close",command=win.destroy).pack(anchor="e",pady=8)

    def open_performance_attachment(self,tree):
        selected=tree.selection()
        if not selected: messagebox.showinfo("Select review","Select a performance review first.",parent=self); return
        row=self.store.conn.execute("SELECT file_path FROM performance_reviews WHERE id=?",(int(selected[0]),)).fetchone()
        if not row or not row["file_path"]: messagebox.showinfo("No attachment","This review has no document attached.",parent=self); return
        self._open_document_path(row["file_path"])

    def show_payroll(self):
        self._shell("Payroll")
        ttk.Label(self.content,text="Payroll",style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content,text="Hourly payroll: enter hours for weekdays, Saturdays, Sundays and public holidays. Employee UIF is automatically calculated at 1% of gross pay. Daily rates and shift/lunch times are editable under Pay rates & shift settings.",style="Sub.TLabel",wraplength=920).pack(anchor="w",pady=(5,14))
        bar=ttk.Frame(self.content); bar.pack(fill="x",pady=(0,10))
        ttk.Button(bar,text="＋ New payroll record",style="Primary.TButton",command=self.payroll_record_form).pack(side="left")
        ttk.Button(bar,text="Refresh",command=self.show_payroll).pack(side="left",padx=8)
        ttk.Button(bar,text="Pay rates & shift settings",command=self.payroll_settings).pack(side="left",padx=8)
        ttk.Button(bar,text="View / Print payslip",command=lambda:self.create_payslip(tree, "view")).pack(side="left",padx=8)
        ttk.Button(bar,text="Email payslip",command=lambda:self.create_payslip(tree, "email")).pack(side="left",padx=8)
        frame=ttk.Frame(self.content,style="Card.TFrame",padding=6); frame.pack(fill="both",expand=True)
        cols=("employee","period","pay_date","gross","deductions","net","status","attachment")
        tree=ttk.Treeview(frame,columns=cols,show="headings",selectmode="browse")
        heads=[("employee","Employee",210),("period","Pay period",110),("pay_date","Pay date",105),("gross","Gross",110),("deductions","Deductions",110),("net","Net pay",110),("status","Status",100),("attachment","Attachment",180)]
        for c,h,w in heads:
            tree.heading(c,text=h); tree.column(c,width=w,anchor="w")
        y=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=y.set)
        tree.pack(side="left",fill="both",expand=True); y.pack(side="right",fill="y")
        for row in self.payroll_records():
            a=self.store.conn.execute("SELECT file_name FROM payroll_attachments WHERE payroll_id=? ORDER BY id DESC LIMIT 1",(row["id"],)).fetchone()
            attachment=a["file_name"] if a else "—"
            tree.insert("","end",iid=str(row["id"]),values=(f'{row["employee_no"]} — {row["first_name"]} {row["last_name"]}',row["pay_period"],row["pay_date"],f'R{row["gross_pay"]:,.2f}',f'R{row["total_deductions"]:,.2f}',f'R{row["net_pay"]:,.2f}',row["status"],attachment))
        tree.bind("<Double-1>",lambda _e:self.open_payroll_record(tree))
        ttk.Label(self.content,text="Double-click a payroll record to view the complete calculation, attach a supporting document or open the saved attachment.",style="Sub.TLabel").pack(anchor="w",pady=(7,0))

    def create_payslip(self, tree, action="view"):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Select payroll", "Select a payroll record first, then choose a payslip action.", parent=self)
            return
        rid = int(selected[0])
        row = self.store.conn.execute("""SELECT p.*,e.employee_no,e.first_name,e.last_name,e.email,e.phone,e.job_title,e.department
            FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE p.id=?""", (rid,)).fetchone()
        if not row:
            messagebox.showerror("Payslip unavailable", "The selected payroll record could not be found.", parent=self)
            return
        safe_emp = re.sub(r"[^A-Za-z0-9_-]+", "_", str(row["employee_no"] or "employee"))
        safe_period = re.sub(r"[^A-Za-z0-9_-]+", "_", str(row["pay_period"] or "period"))
        out_dir = DOC_DIR / "Payslips"
        out_dir.mkdir(parents=True, exist_ok=True)
        pdf_out = out_dir / f"Payslip_{safe_emp}_{safe_period}.pdf"
        html_out = out_dir / f"Payslip_{safe_emp}_{safe_period}.html"
        money = lambda key: f"R{float(row[key] or 0):,.2f}"
        details = [
            ("Employee number", row["employee_no"]), ("Employee name", f'{row["first_name"]} {row["last_name"]}'),
            ("Job title", row["job_title"] or "—"), ("Department", row["department"] or "—"),
            ("Pay period", row["pay_period"]), ("Pay date", display_date(row["pay_date"])),
            ("Weekday hours", f'{float(row["weekday_hours"] or 0):.2f}'),
            ("Saturday hours", f'{float(row["saturday_hours"] or 0):.2f}'),
            ("Sunday hours", f'{float(row["sunday_hours"] or 0):.2f}'),
            ("Public holiday hours", f'{float(row["public_holiday_hours"] or 0):.2f}'),
            ("Hourly earnings", money("basic_salary")), ("Overtime", money("overtime")),
            ("Allowances", money("allowances")), ("Bonus", money("bonus")),
            ("Gross pay", money("gross_pay")), ("UIF employee contribution (1%)", money("uif")),
            (f"Other deductions — reason: {row['notes'].strip()}" if float(row["other_deductions"] or 0) > 0 and row["notes"] and row["notes"].strip() else ("Other deductions — reason not provided; update payroll notes" if float(row["other_deductions"] or 0) > 0 else "Other deductions"), money("other_deductions")), ("Total deductions", money("total_deductions")),
            ("Net pay", money("net_pay")),
        ]
        # Annual leave information: recorded attendance days / 17, plus configured opening balance, less approved annual leave.
        worked_days = int(self.store.conn.execute("SELECT COUNT(*) FROM attendance_daily WHERE employee_id=? AND COALESCE(total_hours,0)>0", (int(row["employee_id"]),)).fetchone()[0])
        annual_balance_row = self.store.conn.execute("SELECT opening_days FROM leave_balances WHERE employee_id=? AND leave_type='Annual'", (int(row["employee_id"]),)).fetchone()
        annual_opening = float(annual_balance_row["opening_days"] or 0) if annual_balance_row else 0.0
        annual_used = float(self.store.conn.execute("SELECT COALESCE(SUM(days),0) FROM leave_records WHERE employee_id=? AND leave_type='Annual' AND status='Approved'", (int(row["employee_id"]),)).fetchone()[0] or 0)
        annual_accrued = worked_days / 17.0
        annual_available = max(0.0, annual_opening + annual_accrued - annual_used)
        details.append(("Annual leave accrued (1 day per 17 recorded days)", f"{annual_accrued:.2f} days"))
        details.append(("Estimated annual leave balance", f"{annual_available:.2f} days"))
        details.append(("Status", row["status"]))
        # Formal, print-ready payslip layout.
        employee_details = details[:6]
        hours_details = details[6:10]
        earnings_details = details[10:15]
        deduction_details = details[15:18]
        net_details = details[18:19]
        leave_details = details[19:21]
        def html_table(items):
            return "".join(f"<tr><th>{html.escape(str(k))}</th><td>{html.escape(str(v if v not in (None, '') else '—'))}</td></tr>" for k,v in items)
        doc = f"""<!doctype html><html><head><meta charset='utf-8'><title>Employee Payslip</title>
        <style>
        *{{box-sizing:border-box}}body{{font:12px Arial,sans-serif;color:#243247;max-width:1100px;margin:20px auto;padding:18px;background:#fff}}
        .header{{background:#17365d;color:white;padding:24px 28px;border-radius:8px 8px 0 0;display:flex;justify-content:space-between;align-items:center}}
        h1{{margin:0;font-size:25px;letter-spacing:.3px}}.subtitle{{margin-top:6px;color:#dce8f6;font-size:13px}}.badge{{border:1px solid #8ca9c8;padding:9px 12px;border-radius:5px;font-weight:bold;letter-spacing:1px}}
        .reg{{background:#edf3f9;padding:10px 16px;color:#52647a;font-size:11px}}
        h2{{font-size:14px;text-transform:uppercase;letter-spacing:.8px;color:#17365d;border-bottom:2px solid #dce5ef;padding-bottom:7px;margin:22px 0 8px}}
        table{{width:100%;border-collapse:collapse}}th,td{{padding:9px 11px;text-align:left;border-bottom:1px solid #e1e7ee}}th{{width:42%;font-weight:normal;color:#536477;background:#f5f7fa}}td{{font-weight:600}}
        .net{{margin-top:20px;background:#e8f5ee;border:1px solid #b8ddc7;padding:18px 20px;display:flex;justify-content:space-between;align-items:center;color:#145c38;border-radius:5px}}
        .net strong{{font-size:24px}}.foot{{margin-top:25px;border-top:1px solid #dce3eb;padding-top:12px;color:#718096;font-size:10px;line-height:1.5}}
        @page{{size:A4 landscape;margin:8mm}}@media print{{body{{margin:0;padding:0;max-width:none;font-size:10px}}.header{{border-radius:0;padding:12px 16px}}h2{{margin:10px 0 4px}}th,td{{padding:5px 7px}}.net{{margin-top:10px;padding:10px 14px}}}}
        </style></head><body>
        <div class='header'><div><h1>Beyond Registration</h1><div class='subtitle'>Employee remuneration statement</div></div><div class='badge'>PAYSLIP</div></div>
        <div class='reg'>Company registration number: {html.escape(COMPANY_REG)}</div>
        <h2>Employee and pay details</h2><table>{html_table(employee_details)}</table>
        <h2>Hours worked</h2><table>{html_table(hours_details)}</table>
        <h2>Earnings</h2><table>{html_table(earnings_details)}</table>
        <h2>Deductions</h2><table>{html_table(deduction_details)}</table>
        <h2>Annual leave</h2><table>{html_table(leave_details)}</table>
        <div class='net'><span>NET PAY</span><strong>{html.escape(money('net_pay'))}</strong></div>
        <div class='foot'>Payment status: {html.escape(str(row['status'] or '—'))}<br>CONFIDENTIAL — This document contains private employee and payroll information. Keep it secure and share only with the employee or an authorised recipient.</div>
        </body></html>"""
        try:
            html_out.write_text(doc, encoding="utf-8")
            # Generate a real PDF automatically, so the user does not need to print/save it first.
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import mm
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            styles = getSampleStyleSheet()
            navy = colors.HexColor("#17365D")
            pale = colors.HexColor("#EDF3F9")
            styles.add(ParagraphStyle(name="SlipBrand", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=21, leading=25, textColor=colors.white, alignment=0, spaceAfter=2))
            styles.add(ParagraphStyle(name="SlipSubtitle", parent=styles["Normal"], fontSize=9, textColor=colors.HexColor("#DCE8F6")))
            styles.add(ParagraphStyle(name="SlipSection", parent=styles["Heading3"], fontSize=10, leading=13, textColor=navy, spaceBefore=9, spaceAfter=5, uppercase=True))
            styles.add(ParagraphStyle(name="SlipLabel", parent=styles["BodyText"], fontSize=8.5, textColor=colors.HexColor("#536477")))
            styles.add(ParagraphStyle(name="SlipValue", parent=styles["BodyText"], fontSize=8.5, textColor=colors.HexColor("#243247")))
            story = []
            brand = Table([[Paragraph("BEYOND REGISTRATION", styles["SlipBrand"]), Paragraph("EMPLOYEE PAYSLIP", styles["SlipSubtitle"])]], colWidths=[175*mm, 82*mm])
            brand.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),navy),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),10),("RIGHTPADDING",(0,0),(-1,-1),10),("TOPPADDING",(0,0),(-1,-1),12),("BOTTOMPADDING",(0,0),(-1,-1),12)]))
            story += [brand, Paragraph(f"Company registration number: {html.escape(COMPANY_REG)}", styles["SlipLabel"]), Spacer(1, 4*mm)]
            def section(title, items):
                if not items: return
                story.append(Paragraph(title, styles["SlipSection"]))
                data = [[Paragraph(f"<b>{html.escape(str(k))}</b>", styles["SlipLabel"]), Paragraph(html.escape(str(v if v not in (None, '') else '—')), styles["SlipValue"])] for k,v in items]
                t = Table(data, colWidths=[75*mm, 105*mm], hAlign="LEFT")
                t.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),pale),("GRID",(0,0),(-1,-1),0.35,colors.HexColor("#D7DCE2")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),7),("RIGHTPADDING",(0,0),(-1,-1),7),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
                story.append(t)
            section("Employee and pay details", employee_details)
            section("Hours worked", hours_details)
            section("Earnings", earnings_details)
            section("Deductions", deduction_details)
            section("Annual leave", leave_details)
            netbox = Table([[Paragraph("NET PAY", styles["SlipSection"]), Paragraph(f"<b>{html.escape(money('net_pay'))}</b>", ParagraphStyle("NetAmount", parent=styles["BodyText"], fontSize=17, textColor=colors.HexColor("#145C38"), alignment=2))]], colWidths=[90*mm,90*mm])
            netbox.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#E8F5EE")),("BOX",(0,0),(-1,-1),0.8,colors.HexColor("#B8DDC7")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),10),("RIGHTPADDING",(0,0),(-1,-1),10),("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8)]))
            story += [Spacer(1, 6*mm), netbox, Spacer(1, 5*mm), Paragraph(f"Payment status: {html.escape(str(row['status'] or '—'))}", styles["SlipLabel"]), Spacer(1, 3*mm), Paragraph("CONFIDENTIAL — This document contains private employee and payroll information. Keep it secure and share only with the employee or an authorised recipient.", styles["SlipLabel"])]
            SimpleDocTemplate(str(pdf_out), pagesize=landscape(A4), rightMargin=12*mm, leftMargin=12*mm, topMargin=8*mm, bottomMargin=8*mm, title="Employee Payslip").build(story)
        except ImportError:
            messagebox.showerror("PDF component missing", "The PDF generator (ReportLab) is not installed. Install it with: python -m pip install reportlab, then try again.", parent=self)
            webbrowser.open(html_out.resolve().as_uri())
            return
        except Exception as exc:
            messagebox.showerror("Payslip error", f"Could not create the payslip PDF:\n{exc}", parent=self)
            return
        self.store.log(self.actor, "Generated payslip PDF", "payroll", rid, str(pdf_out))
        self.store.conn.commit()
        if action == "view":
            try:
                os.startfile(str(pdf_out))
            except Exception:
                webbrowser.open(pdf_out.resolve().as_uri())
            messagebox.showinfo("Payslip ready", f"The PDF was created automatically:\n{pdf_out}", parent=self)
        elif action == "email":
            email_addr = str(row["email"] or "").strip()
            if not email_addr:
                messagebox.showwarning("Employee email missing", "This employee has no email address saved. Edit the employee profile first.", parent=self)
                try: os.startfile(str(pdf_out.parent))
                except Exception: pass
                return
            subject = f"Payslip {row['pay_period']} - {row['employee_no']}"
            body = f"Dear {row['first_name']},\n\nPlease find your payslip for {row['pay_period']} attached.\n\nRegards,\nBeyond Registration"
            mailto = "mailto:" + urllib.parse.quote(email_addr, safe="@") + "?subject=" + urllib.parse.quote(subject) + "&body=" + urllib.parse.quote(body)
            webbrowser.open(mailto)
            try: os.startfile(str(pdf_out.parent))
            except Exception: pass
            messagebox.showinfo("Email draft opened", "The payslip PDF has been created automatically. Your email draft is open; attach the PDF from the Payslips folder before sending.", parent=self)
    def payroll_settings(self):
        win=tk.Toplevel(self); win.title("Pay rates and shift settings · Beyond Registration"); win.geometry("650x720"); win.transient(self); win.grab_set(); win.configure(bg=BG)
        ttk.Label(win,text="Pay rates and shift settings",style="Title.TLabel").pack(anchor="w",padx=22,pady=(20,4))
        ttk.Label(win,text="All values below are editable. Hourly rates are calculated from the daily rate divided by paid shift hours.",style="Sub.TLabel",wraplength=510).pack(anchor="w",padx=22,pady=(0,12))
        frm=ttk.Frame(win,padding=22); frm.pack(fill="both",expand=True)
        fields=[("pay_shift_start","Shift starts (HH:MM)"),("pay_shift_end","Shift ends (HH:MM)"),("pay_paid_lunch_minutes","Paid lunch (minutes)"),("pay_unpaid_lunch_minutes","Unpaid lunch (minutes)"),("pay_weekday_rate","Monday–Friday daily rate (R)"),("pay_saturday_rate","Saturday daily rate (R)"),("pay_sunday_rate","Sunday daily rate (R)"),("pay_public_holiday_rate","Public holiday daily rate (R)"),("pay_public_holiday_dates","Public holiday dates (DD-MM-YYYY, comma-separated)")]
        vals={}
        for i,(key,label) in enumerate(fields):
            ttk.Label(frm,text=label,style="Sub.TLabel").grid(row=i,column=0,sticky="w",pady=5)
            v=tk.StringVar(value=self.store.attendance_setting(key)); vals[key]=v
            ttk.Entry(frm,textvariable=v,width=20).grid(row=i,column=1,sticky="ew",padx=(12,0),pady=5)
        frm.columnconfigure(1,weight=1)
        preview=ttk.Label(frm,text="",style="CardTitle.TLabel"); preview.grid(row=len(fields),column=0,columnspan=2,sticky="w",pady=(14,4))
        def update_preview(*_):
            try:
                a=datetime.strptime(vals["pay_shift_start"].get().strip(),"%H:%M"); b=datetime.strptime(vals["pay_shift_end"].get().strip(),"%H:%M")
                duration=(b-a).total_seconds()/3600
                paid=duration-int(vals["pay_unpaid_lunch_minutes"].get())/60
                if duration<=0 or paid<=0: raise ValueError
                rates=[float(vals[k].get())/paid for k in ("pay_weekday_rate","pay_saturday_rate","pay_sunday_rate","pay_public_holiday_rate")]
                preview.configure(text=f"Paid hours/shift: {paid:g}   |   Hourly rates: R{rates[0]:.2f} / R{rates[1]:.2f} / R{rates[2]:.2f} / R{rates[3]:.2f}")
            except Exception: preview.configure(text="Check shift times, lunch minutes and daily rates.")
        for v in vals.values(): v.trace_add("write",update_preview)
        update_preview()
        def save():
            try:
                a=datetime.strptime(vals["pay_shift_start"].get().strip(),"%H:%M"); b=datetime.strptime(vals["pay_shift_end"].get().strip(),"%H:%M")
                duration=(b-a).total_seconds()/60
                paid_lunch=int(vals["pay_paid_lunch_minutes"].get()); unpaid=int(vals["pay_unpaid_lunch_minutes"].get())
                if duration<=0 or paid_lunch<0 or unpaid<0 or unpaid>=duration: raise ValueError("Lunch minutes must be non-negative and shorter than the shift.")
                for k in ("pay_weekday_rate","pay_saturday_rate","pay_sunday_rate","pay_public_holiday_rate"):
                    if float(vals[k].get().replace(",",""))<0: raise ValueError("Daily rates cannot be negative.")
            except ValueError as exc:
                messagebox.showerror("Invalid pay settings",str(exc) or "Use HH:MM for times and valid numeric amounts.",parent=win); return
            for k,v in vals.items(): self.store.set_attendance_setting(k,v.get().strip())
            self.store.log(self.actor,"Updated pay rates and shift settings","payroll_settings","","Rates, shift times and lunch settings updated")
            win.destroy(); self.show_payroll()
        foot=ttk.Frame(win,padding=16); foot.pack(fill="x"); ttk.Button(foot,text="Cancel",command=win.destroy).pack(side="right"); ttk.Button(foot,text="Save settings",style="Primary.TButton",command=save).pack(side="right",padx=(0,8))

    def payroll_record_form(self, payroll_id=None):
        employees=self.store.conn.execute("SELECT id,employee_no,first_name,last_name FROM employees ORDER BY last_name,first_name").fetchall()
        if not employees:
            messagebox.showinfo("No employees","Add an employee before creating payroll.",parent=self); return
        win=tk.Toplevel(self); win.title("Hourly payroll record · Beyond Registration"); win.geometry("760x790"); win.transient(self); win.grab_set(); win.configure(bg=BG)
        ttk.Label(win,text="New hourly payroll record",style="Title.TLabel").pack(anchor="w",padx=22,pady=(18,4))
        ttk.Label(win,text="Enter hours worked in each day category. Pay is calculated using the editable daily rates and paid shift hours in Pay rates & shift settings.",style="Sub.TLabel",wraplength=700).pack(anchor="w",padx=22,pady=(0,10))
        # Keep the action buttons fixed at the bottom while allowing the full
        # payroll form to scroll on smaller screens.
        body=ttk.Frame(win); body.pack(fill="both",expand=True)
        canvas=tk.Canvas(body,highlightthickness=0,bg=BG)
        scrollbar=ttk.Scrollbar(body,orient="vertical",command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right",fill="y")
        canvas.pack(side="left",fill="both",expand=True)
        frm=ttk.Frame(canvas,padding=20)
        form_window=canvas.create_window((0,0),window=frm,anchor="nw")
        def _payroll_form_resize(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
        def _payroll_canvas_resize(event):
            canvas.itemconfigure(form_window,width=event.width)
            _payroll_form_resize()
        frm.bind("<Configure>",_payroll_form_resize)
        canvas.bind("<Configure>",_payroll_canvas_resize)
        def _payroll_mousewheel(event):
            if getattr(event,"delta",0):
                canvas.yview_scroll(int(-event.delta/120),"units")
            elif getattr(event,"num",None)==4:
                canvas.yview_scroll(-1,"units")
            elif getattr(event,"num",None)==5:
                canvas.yview_scroll(1,"units")
        canvas.bind_all("<MouseWheel>",_payroll_mousewheel)
        canvas.bind_all("<Button-4>",_payroll_mousewheel)
        canvas.bind_all("<Button-5>",_payroll_mousewheel)
        employee_map={f'{r["employee_no"]} — {r["first_name"]} {r["last_name"]}':int(r["id"]) for r in employees}
        ev=tk.StringVar(value=next(iter(employee_map))); period=tk.StringVar(value=datetime.now().strftime("%Y-%m")); paydate=tk.StringVar(value=datetime.now().strftime("%d-%m-%Y")); status=tk.StringVar(value="Draft"); notes=tk.StringVar()
        ttk.Label(frm,text="Employee",style="Sub.TLabel").grid(row=0,column=0,sticky="w"); ttk.Combobox(frm,textvariable=ev,values=list(employee_map),state="readonly",width=48).grid(row=1,column=0,columnspan=2,sticky="ew",pady=(2,8))
        ttk.Label(frm,text="Pay period (YYYY-MM)",style="Sub.TLabel").grid(row=2,column=0,sticky="w"); ttk.Label(frm,text="Pay date (DD-MM-YYYY)",style="Sub.TLabel").grid(row=2,column=1,sticky="w")
        ttk.Entry(frm,textvariable=period).grid(row=3,column=0,sticky="ew",padx=(0,8),pady=(2,8)); ttk.Entry(frm,textvariable=paydate).grid(row=3,column=1,sticky="ew",pady=(2,8))
        try:
            start=datetime.strptime(self.store.attendance_setting("pay_shift_start","09:00"),"%H:%M"); end=datetime.strptime(self.store.attendance_setting("pay_shift_end","19:15"),"%H:%M")
            paid_hours=(end-start).total_seconds()/3600-int(self.store.attendance_setting("pay_unpaid_lunch_minutes","15"))/60
            if paid_hours<=0: paid_hours=10
        except Exception: paid_hours=10
        categories=[("weekday_hours","Monday–Friday hours","pay_weekday_rate"),("saturday_hours","Saturday hours","pay_saturday_rate"),("sunday_hours","Sunday hours","pay_sunday_rate"),("public_holiday_hours","Public holiday hours","pay_public_holiday_rate")]
        hour_vars={}; rate_info=[]
        def calculate_from_attendance():
            try:
                datetime.strptime(period.get().strip(), "%Y-%m")
            except ValueError:
                messagebox.showerror("Invalid pay period", "Enter the month as YYYY-MM first.", parent=win); return
            employee_id=employee_map.get(ev.get())
            if not employee_id:
                messagebox.showerror("Select employee", "Select an employee first.", parent=win); return
            month=period.get().strip(); start_date=month+"-01"
            next_month=(datetime.strptime(month+"-01", "%Y-%m-%d").replace(day=28)+timedelta(days=4)).replace(day=1)
            end_date=(next_month-timedelta(days=1)).strftime("%Y-%m-%d")
            rows=self.store.conn.execute("SELECT work_date,first_in,last_out,total_hours,status,source FROM attendance_daily WHERE employee_id=? AND work_date BETWEEN ? AND ? ORDER BY work_date",(employee_id,start_date,end_date)).fetchall()
            if not rows:
                messagebox.showinfo("No attendance", "No daily attendance records were found for this employee and month. Import the KM30 file and calculate/rebuild attendance first.", parent=win); return
            try: unpaid=max(0,int(self.store.attendance_setting("pay_unpaid_lunch_minutes","15") or 0))
            except ValueError: unpaid=15
            holidays=set()
            for x in self.store.attendance_setting("pay_public_holiday_dates","").split(","):
                if x.strip():
                    try: holidays.add(stored_date(x.strip()))
                    except ValueError: holidays.add(x.strip())
            totals={key:0.0 for key,_,_ in categories}; counted=0; skipped=[]
            for day in rows:
                try:
                    if str(day["source"] or "Biometric") == "Manual" or str(day["status"]) == "Manual hours":
                        # Manual entries already contain payable hours after unpaid breaks.
                        hours = max(0.0, float(day["total_hours"] or 0))
                    else:
                        if not day["first_in"] or not day["last_out"] or "Missing punch" in str(day["status"]):
                            skipped.append(day["work_date"]); continue
                        first=datetime.fromisoformat(str(day["first_in"])); last=datetime.fromisoformat(str(day["last_out"]))
                        hours=max(0,(last-first).total_seconds()/3600)
                        if hours>6: hours=max(0,hours-unpaid/60)
                    dt=datetime.strptime(day["work_date"],"%Y-%m-%d"); weekday=dt.weekday()
                except (ValueError,TypeError):
                    skipped.append(day["work_date"]); continue
                if day["work_date"] in holidays: key="public_holiday_hours"
                elif weekday==6: key="sunday_hours"
                elif weekday==5: key="saturday_hours"
                else: key="weekday_hours"
                totals[key]+=hours; counted+=1
            for key in totals: hour_vars[key].set(f"{totals[key]:.2f}")
            update_calc()
            self.store.log(self.actor,"Calculated payroll hours from attendance","payroll",employee_id,f"Period {month}; days used {counted}; skipped {len(skipped)}")
            msg=f"Attendance hours loaded for {month}.\nDays included: {counted}. Manual-hour entries are included using the payable hours you entered."
            if skipped: msg += "\nDays skipped for missing/invalid punches: " + ", ".join(skipped)
            msg += "\nPlease review the totals before saving payroll."
            messagebox.showinfo("Attendance calculated",msg,parent=win)
        ttk.Label(frm,text=f"Paid shift hours used for daily-rate conversion: {paid_hours:g} (paid lunch included; unpaid lunch excluded)",style="Sub.TLabel",wraplength=690).grid(row=4,column=0,columnspan=2,sticky="w",pady=(2,4))
        ttk.Button(frm,text="Calculate hours from attendance for selected employee/month",command=calculate_from_attendance).grid(row=5,column=0,columnspan=2,sticky="w",pady=(0,8))
        for i,(key,label,ratekey) in enumerate(categories):
            r=6+i*2; daily=float(self.store.attendance_setting(ratekey,"0").replace(",","")); hourly=daily/paid_hours
            ttk.Label(frm,text=f"{label}  ·  R{hourly:.2f}/hour (R{daily:.2f}/day)",style="Sub.TLabel").grid(row=r,column=0,sticky="w",pady=(4,1))
            v=tk.StringVar(value="0"); hour_vars[key]=v; ttk.Entry(frm,textvariable=v).grid(row=r+1,column=0,sticky="ew",padx=(0,8),pady=(0,4))
        extra_vars={}
        for i,(key,label) in enumerate([("overtime","Additional overtime pay (R)"),("allowances","Allowances (R)"),("bonus","Bonus (R)"),("other_deductions","Other deductions (R)")]):
            r=6+i*2; col=1
            ttk.Label(frm,text=label,style="Sub.TLabel").grid(row=r,column=col,sticky="w",pady=(4,1)); v=tk.StringVar(value="0.00"); extra_vars[key]=v; ttk.Entry(frm,textvariable=v).grid(row=r+1,column=col,sticky="ew",pady=(0,4))
        uif_display=tk.StringVar(value="R0.00 (1% of gross pay)")
        ttk.Label(frm,text="UIF employee contribution (1% of gross)",style="Sub.TLabel").grid(row=14,column=1,sticky="w",pady=(4,1))
        ttk.Label(frm,textvariable=uif_display,style="Sub.TLabel").grid(row=15,column=1,sticky="w",pady=(0,4))
        base=18
        ttk.Label(frm,text="Status",style="Sub.TLabel").grid(row=base,column=0,sticky="w",pady=(8,2)); ttk.Combobox(frm,textvariable=status,values=["Draft","Approved","Paid","Cancelled"],state="readonly",width=18).grid(row=base+1,column=0,sticky="w")
        ttk.Label(frm,text="Notes",style="Sub.TLabel").grid(row=base,column=1,sticky="w",pady=(8,2)); ttk.Entry(frm,textvariable=notes).grid(row=base+1,column=1,sticky="ew")
        frm.columnconfigure(0,weight=1); frm.columnconfigure(1,weight=1)
        calc=ttk.Label(frm,text="Gross: R0.00    Deductions: R0.00    Net: R0.00",style="CardTitle.TLabel"); calc.grid(row=19,column=0,columnspan=2,sticky="w",pady=(12,6))
        def nums():
            hours={k:float(v.get().replace(",","")) if v.get().strip() else 0.0 for k,v in hour_vars.items()}
            extras={k:float(v.get().replace(",","")) if v.get().strip() else 0.0 for k,v in extra_vars.items()}
            rates={key:float(self.store.attendance_setting(ratekey,"0").replace(",",""))/paid_hours for key,_,ratekey in categories}
            earned=sum(hours[key]*rates[key] for key,_,_ in categories)
            gross=earned+extras["overtime"]+extras["allowances"]+extras["bonus"]
            uif=round(max(0.0,gross)*0.01, 2)
            extras["uif"]=uif
            ded=uif+extras["other_deductions"]
            return hours,extras,earned,gross,ded,gross-ded
        def update_calc(*_):
            try:
                _,extras,earned,g,d,n=nums(); uif_display.set(f"R{extras['uif']:,.2f} (1% of gross pay)"); calc.configure(text=f"Hourly earnings: R{earned:,.2f}    Gross: R{g:,.2f}    Deductions: R{d:,.2f}    Net: R{n:,.2f}")
            except ValueError: calc.configure(text="Enter valid numeric hours and amounts.")
        for v in list(hour_vars.values())+list(extra_vars.values()): v.trace_add("write",update_calc)
        update_calc()
        def save():
            try:
                datetime.strptime(period.get().strip(),"%Y-%m"); paydate_iso=stored_date(paydate.get())
                hours,extras,earned,g,d,n=nums()
                if any(x<0 for x in list(hours.values())+list(extras.values())): raise ValueError("Hours and amounts cannot be negative.")
            except ValueError as exc: messagebox.showerror("Invalid payroll","Check dates, hours and numeric amounts.\n\n"+str(exc),parent=win); return
            data={"employee_id":employee_map[ev.get()],"pay_period":period.get().strip(),"pay_date":paydate_iso,**hours,"basic_salary":earned,"overtime":extras["overtime"],"allowances":extras["allowances"],"bonus":extras["bonus"],"gross_pay":g,"paye":0.0,"uif":extras["uif"],"other_deductions":extras["other_deductions"],"total_deductions":d,"net_pay":n,"status":status.get(),"notes":notes.get().strip()}
            try: self.save_payroll_record(data,self.actor); win.destroy(); self.show_payroll()
            except sqlite3.Error as exc: messagebox.showerror("Payroll save error",str(exc),parent=win)
        def close_payroll_form():
            try:
                canvas.unbind_all("<MouseWheel>")
                canvas.unbind_all("<Button-4>")
                canvas.unbind_all("<Button-5>")
            except Exception:
                pass
            win.destroy()
        win.protocol("WM_DELETE_WINDOW",close_payroll_form)
        foot=ttk.Frame(win,padding=14); foot.pack(fill="x"); ttk.Button(foot,text="Cancel",command=close_payroll_form).pack(side="right"); ttk.Button(foot,text="Save payroll record",style="Primary.TButton",command=save).pack(side="right",padx=(0,8))

    def open_payroll_record(self, tree):
        selected=tree.selection()
        if not selected: return
        rid=int(selected[0]); row=self.store.conn.execute("SELECT p.*,e.employee_no,e.first_name,e.last_name FROM payroll_records p JOIN employees e ON e.id=p.employee_id WHERE p.id=?",(rid,)).fetchone()
        if not row: return
        win=tk.Toplevel(self); win.title("Payroll record · Beyond Registration"); win.geometry("620x650"); win.transient(self); win.grab_set(); win.configure(bg=BG)
        ttk.Label(win,text="Payroll record",style="Title.TLabel").pack(anchor="w",padx=22,pady=(20,4))
        ttk.Label(win,text=f'{row["employee_no"]} — {row["first_name"]} {row["last_name"]}',style="Sub.TLabel").pack(anchor="w",padx=22)
        box=ttk.Frame(win,style="Card.TFrame",padding=18); box.pack(fill="both",expand=True,padx=22,pady=16)
        lines=[("Pay period",row["pay_period"]),("Pay date",row["pay_date"]),("Monday–Friday hours",f'{row["weekday_hours"]:g}'),("Saturday hours",f'{row["saturday_hours"]:g}'),("Sunday hours",f'{row["sunday_hours"]:g}'),("Public holiday hours",f'{row["public_holiday_hours"]:g}'),("Hourly earnings",f'R{row["basic_salary"]:,.2f}'),("Overtime",f'R{row["overtime"]:,.2f}'),("Allowances",f'R{row["allowances"]:,.2f}'),("Bonus",f'R{row["bonus"]:,.2f}'),("Gross pay",f'R{row["gross_pay"]:,.2f}'),("UIF employee contribution (1%)",f'R{row["uif"]:,.2f}'),("Other deductions",f'R{row["other_deductions"]:,.2f}'),("Total deductions",f'R{row["total_deductions"]:,.2f}'),("Net pay",f'R{row["net_pay"]:,.2f}'),("Status",row["status"]),("Notes",row["notes"] or "—")]
        for i,(a,b) in enumerate(lines): ttk.Label(box,text=a,style="Sub.TLabel").grid(row=i,column=0,sticky="nw",pady=4,padx=(0,25)); ttk.Label(box,text=str(b),background=WHITE,foreground=TEXT,wraplength=380).grid(row=i,column=1,sticky="nw",pady=4)
        att=self.store.conn.execute("SELECT file_path,file_name FROM payroll_attachments WHERE payroll_id=? ORDER BY id DESC LIMIT 1",(rid,)).fetchone()
        ttk.Label(box,text="Attachment",style="Sub.TLabel").grid(row=len(lines),column=0,sticky="nw",pady=(12,4)); ttk.Label(box,text=att["file_name"] if att else "No attachment",background=WHITE,foreground=TEXT,wraplength=380).grid(row=len(lines),column=1,sticky="nw",pady=(12,4))
        def attach():
            path=filedialog.askopenfilename(parent=win,title="Attach payroll document",filetypes=[("Documents and files","*.pdf *.doc *.docx *.xls *.xlsx *.csv *.jpg *.jpeg *.png *.txt"),("All files","*.*")])
            if not path:return
            src=Path(path)
            try:
                dest=DOC_DIR/f"payroll_{row['employee_id']}_{row['pay_period']}_{secrets.token_hex(5)}{src.suffix.lower() or '.dat'}"; shutil.copy2(src,dest)
                self.store.conn.execute("INSERT INTO payroll_attachments(payroll_id,employee_id,file_path,file_name,created_at) VALUES(?,?,?,?,?)",(rid,int(row["employee_id"]),str(dest),src.name,now_text()))
                self.store.log(self.actor,"Added payroll attachment","payroll",rid,src.name); self.store.conn.commit(); win.destroy(); self.show_payroll()
            except OSError as exc: messagebox.showerror("Attachment error",str(exc),parent=win)
        def open_att():
            a=self.store.conn.execute("SELECT file_path FROM payroll_attachments WHERE payroll_id=? ORDER BY id DESC LIMIT 1",(rid,)).fetchone()
            if not a: messagebox.showinfo("No attachment","This payroll record does not have an attachment.",parent=win); return
            path=Path(a["file_path"])
            if not path.exists(): messagebox.showerror("File not found","The saved payroll attachment could not be found on this computer.",parent=win); return
            try:
                if os.name=="nt": os.startfile(str(path))
                else: subprocess.Popen(["xdg-open",str(path)])
            except Exception as exc: messagebox.showerror("Could not open attachment",str(exc),parent=win)
        foot=ttk.Frame(win,padding=16); foot.pack(fill="x"); ttk.Button(foot,text="Close",command=win.destroy).pack(side="right"); ttk.Button(foot,text="Open attachment",command=open_att).pack(side="right",padx=8); ttk.Button(foot,text="Attach file",style="Primary.TButton",command=attach).pack(side="right")

    def show_audit(self):
        self._shell("Audit trail")
        ttk.Label(self.content, text="Audit trail", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text="A record of sign-ins and employee profile changes in this foundation build.", style="Sub.TLabel").pack(anchor="w", pady=(5, 14))
        frame = ttk.Frame(self.content, style="Card.TFrame", padding=8); frame.pack(fill="both", expand=True)
        cols = ("date", "actor", "action", "type", "id", "details")
        tree = ttk.Treeview(frame, columns=cols, show="headings")
        for col, title, width in [("date", "Date / time", 155), ("actor", "User", 130), ("action", "Action", 180), ("type", "Record type", 100), ("id", "Record ID", 75), ("details", "Details", 300)]:
            tree.heading(col, text=title); tree.column(col, width=width, anchor="w")
        for row in self.store.recent_audit(250):
            tree.insert("", "end", values=(row["created_at"], row["actor"], row["action"], row["entity_type"], row["entity_id"], row["details"]))
        tree.pack(fill="both", expand=True)

    def create_backup(self):
        try:
            target = self.store.backup_bundle()
            self.store.log(self.actor or "System", "Created full backup", "backup", "", target.name)
            messagebox.showinfo("Full backup created", f"Full backup created successfully:\n\n{target}\n\nIt contains the database and employee photo/document folders. Copy it to a separate drive for protection against computer failure.")
        except (OSError, sqlite3.Error, zipfile.BadZipFile) as exc:
            messagebox.showerror("Backup failed", f"Could not create a full backup:\n{exc}")

    def restore_backup(self):
        source = filedialog.askopenfilename(parent=self, title="Select a Beyond Registration full backup", initialdir=str(BACKUP_DIR), filetypes=[("Full backup ZIP", "*.zip")])
        if not source:
            return
        confirmed = messagebox.askyesno("Confirm restore", "Restoring will replace the current database with the selected backup. A safety backup of the current data will be created first. Continue?", icon="warning", parent=self)
        if not confirmed:
            return
        try:
            safety_copy = self.store.restore_bundle(source)
            self.store.log(self.actor or "System", "Restored full backup", "backup", "", f"Restored {Path(source).name}; safety copy {safety_copy.name}")
            messagebox.showinfo("Restore completed", f"Backup restored. A safety copy of the data that was present before restoration was saved here:\n\n{safety_copy}\n\nThe application will refresh its dashboard.", parent=self)
            self.show_dashboard()
        except (OSError, sqlite3.Error, zipfile.BadZipFile, ValueError, KeyError) as exc:
            messagebox.showerror("Restore failed", f"The backup could not be restored:\n{exc}\n\nYour existing data should remain unchanged if validation failed before restoration.", parent=self)

    def sign_out(self):
        if self.actor:
            self.store.log(self.actor, "Signed out", "session")
        self.actor = ""
        self.show_login()

    def _close(self):
        try:
            self.store.conn.close()          # flushes pending writes and drops the writer lock
        except Exception:
            pass
        try:
            shutdown_persistence()
        except Exception:
            pass
        self.destroy()


def main():
    try:
        app = App()
        app.mainloop()
    except Exception as exc:
        try:
            messagebox.showerror("Application error", f"The application could not start:\n{exc}")
        except Exception:
            print(f"Application error: {exc}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
