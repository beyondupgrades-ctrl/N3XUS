"""Zero-config LAN discovery for the N3XUS phone app - standard library only.

The phone broadcasts the probe b"N3XUS?v1" to UDP 64282 on the office Wi-Fi.
This responder answers the sender directly with a small JSON document listing
the https:// addresses the API listens on, so the app finds the laptop in
well under a second - even after the router hands it a new IP, and without
the 48-thread /24 sweep. No mDNS library (python-zeroconf is LGPL), no
service, no account: one UDP socket.

Answers only private (RFC 1918 / link-local / loopback) senders and reveals
nothing a device on the same LAN could not learn by scanning.
"""
from __future__ import annotations

import ipaddress
import json
import socket
import threading
import time

DISCOVERY_PORT = 64282
PROBE = b"N3XUS?v1"
REFRESH_SECONDS = 60.0
_started = False


def _is_private(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return addr.is_private or addr.is_loopback or addr.is_link_local
    except ValueError:
        return False


def _host_of(url: str) -> str:
    """YOUR_SERVER_IP from https://YOUR_SERVER_IP:64281/mobile/ - "" when it is a name."""
    try:
        from urllib.parse import urlsplit
        return urlsplit(str(url)).hostname or ""
    except Exception:
        return ""


def _same_subnet(peer: str, host: str) -> bool:
    """True when both addresses are plain IPv4 on one /24."""
    try:
        a = ipaddress.ip_address(peer)
        b = ipaddress.ip_address(host)
        if a.version != 4 or b.version != 4:
            return False
        return str(a).rsplit(".", 1)[0] == str(b).rsplit(".", 1)[0]
    except ValueError:
        return False


def start(urls_fn, name: str = "n3xus", port: int = DISCOVERY_PORT, bind: str = "0.0.0.0"):
    """Start the responder thread once. Returns the thread, or None if the port is busy."""
    global _started
    if _started:
        return None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind((bind, port))
    except OSError as exc:
        print(f"[discovery] UDP {port} unavailable: {exc}", flush=True)
        return None
    _started = True
    cache = {"at": 0.0, "urls": []}

    def urls() -> list[str]:
        # lan_addresses() may shell out to PowerShell, so it is cached.
        if time.monotonic() - cache["at"] > REFRESH_SECONDS or not cache["urls"]:
            try:
                cache["urls"] = [u for u in (urls_fn() or []) if str(u).startswith("https://")][:8]
            except Exception:
                cache["urls"] = []
            cache["at"] = time.monotonic()
        return list(cache["urls"])

    def ordered_for(peer: str) -> list[str]:
        """The peer's own subnet first.

        A laptop is usually on more than one network at once - Wi-Fi, a
        Hyper-V or WSL adapter, a USB tether. All of them were advertised in
        the same order for every phone, so a phone on the Wi-Fi could be told
        to try 172.x (a virtual switch it can never reach) first and spend its
        whole timeout there. The address on the phone's own subnet is the only
        one that can work, so it goes first; the rest stay as fallbacks.
        """
        found = urls()
        same = [u for u in found if _same_subnet(peer, _host_of(u))]
        rest = [u for u in found if u not in same]
        return same + rest

    def run():
        while True:
            try:
                data, addr = sock.recvfrom(64)
            except OSError:
                time.sleep(0.5)
                continue
            if data.strip() != PROBE or not _is_private(addr[0]):
                continue
            try:
                body = json.dumps({"nexus": True, "v": 1, "name": name,
                                   "urls": ordered_for(addr[0])}).encode("utf-8")
                sock.sendto(body, addr)
            except OSError:
                pass

    thread = threading.Thread(target=run, name="n3xus-discovery", daemon=True)
    thread.start()
    print(f"[discovery] answering N3XUS phones on UDP {port}", flush=True)
    return thread
