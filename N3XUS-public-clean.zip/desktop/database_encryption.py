"""Encrypt the Beyond Registration SQLite database while the app is closed.

The open database is held in memory. A commit marks the database dirty and a
background writer re-encrypts the AES-GCM file a few seconds later, or at once
when a caller asks for it (auth changes, clean shutdown, backups). The 256-bit
key is stored only inside the existing Windows DPAPI vault, and is unwrapped
once per process. A different Windows user cannot unwrap that vault. This
module never prints the key.

Two safety rails sit around the file:

* a per-process key cache, so a commit does not re-open the DPAPI vault;
* a single-writer lock file next to the database, so a second script or a
  second server cannot silently overwrite the file a live server is writing.
"""
from __future__ import annotations

import atexit
import base64
import os
import secrets
import sqlite3
import threading
import time
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from communications import SecretVault

MAGIC = b"BRDB1\n"
KEY_FILE = "database.key"
PROTECTION = "AES-GCM at rest; key sealed with Windows DPAPI"
_SQLITE_HEADER = b"SQLite format 3\x00"

# How long a committed change may stay only in RAM before it is written to the
# encrypted file. A clean shutdown, a backup or an auth change flushes at once.
FLUSH_INTERVAL_SECONDS = float(os.environ.get("BR_DB_FLUSH_SECONDS", "3") or 3)

# The single-writer lock file. A live server refreshes its mtime every few
# seconds; a lock whose owner is gone, or whose mtime stopped moving, is stale.
LOCK_FILE = "your-userd_registration.lock"
_LOCK_HEARTBEAT_SECONDS = 5.0
_LOCK_STALE_SECONDS = 30.0


class DatabaseUnlockError(ValueError):
    """The database file cannot be opened with the available key."""


class DatabaseBusyError(RuntimeError):
    """Another live process already owns this database."""


# ---------------------------------------------------------------------------
# Per-process DPAPI key cache
# ---------------------------------------------------------------------------
_KEY_CACHE: dict[str, bytes] = {}
_KEY_CACHE_LOCK = threading.Lock()


def cached_key(directory: Path) -> bytes | None:
    """The key already unwrapped for this folder in this process, if any."""
    with _KEY_CACHE_LOCK:
        return _KEY_CACHE.get(_cache_name(directory))


def _cache_name(directory: Path) -> str:
    try:
        return str(Path(directory).resolve()).lower()
    except OSError:
        return str(directory).lower()


def forget_cached_key(directory: Path | None = None) -> None:
    """Drop the cached key (after a restore, or a key install)."""
    with _KEY_CACHE_LOCK:
        if directory is None:
            _KEY_CACHE.clear()
        else:
            _KEY_CACHE.pop(_cache_name(directory), None)


def _read_key_from_vault(directory: Path) -> bytes:
    vault = SecretVault(directory / KEY_FILE)
    current = vault.get("database_key")
    if isinstance(current, str) and current:
        try:
            key = base64.b64decode(current, validate=True)
        except (ValueError, TypeError) as exc:
            raise DatabaseUnlockError("The sealed database key is unreadable.") from exc
        if len(key) != 32:
            raise DatabaseUnlockError("The sealed database key is unreadable.")
        return key
    key = secrets.token_bytes(32)
    vault.set("database_key", base64.b64encode(key).decode("ascii"))
    return key


def load_or_create_key(directory: Path) -> bytes:
    """Return the database key, creating a DPAPI-sealed key on first use.

    The DPAPI vault is opened once per process per folder: unwrapping it costs
    a Windows API round trip, and the key never changes while the app runs.
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    name = _cache_name(directory)
    with _KEY_CACHE_LOCK:
        cached = _KEY_CACHE.get(name)
        if cached is not None:
            return cached
        key = _read_key_from_vault(directory)
        _KEY_CACHE[name] = key
        return key


def key_from_vault_bytes(vault_bytes: bytes, directory: Path) -> bytes:
    """Unwrap a previously exported DPAPI vault without replacing the live key."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    temporary = directory / f".database-key-{secrets.token_hex(4)}"
    temporary.write_bytes(vault_bytes)
    try:
        return load_or_create_key_from_existing(temporary)
    finally:
        temporary.unlink(missing_ok=True)


def load_or_create_key_from_existing(path: Path) -> bytes:
    vault = SecretVault(path)
    current = vault.get("database_key")
    if not isinstance(current, str) or not current:
        raise DatabaseUnlockError("The backup does not contain a sealed database key.")
    try:
        key = base64.b64decode(current, validate=True)
    except (ValueError, TypeError) as exc:
        raise DatabaseUnlockError("The sealed database key is unreadable.") from exc
    if len(key) != 32:
        raise DatabaseUnlockError("The sealed database key is unreadable.")
    return key


def write_encrypted(path: Path, key: bytes, plaintext: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    nonce = secrets.token_bytes(12)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, MAGIC)
    payload = MAGIC + nonce + ciphertext
    temporary = path.with_name(f"{path.name}.{secrets.token_hex(4)}.tmp")
    temporary.write_bytes(payload)
    os.replace(temporary, path)


def decrypt_payload(payload: bytes, key: bytes) -> bytes:
    if not payload.startswith(MAGIC) or len(payload) < len(MAGIC) + 12 + 16:
        raise DatabaseUnlockError("The database file is not an encrypted Beyond Registration database.")
    nonce = payload[len(MAGIC):len(MAGIC) + 12]
    ciphertext = payload[len(MAGIC) + 12:]
    try:
        return AESGCM(key).decrypt(nonce, ciphertext, MAGIC)
    except Exception as exc:
        raise DatabaseUnlockError("The database could not be unlocked with this Windows profile.") from exc


def _sqlite_snapshot(path: Path) -> bytes:
    connection = sqlite3.connect(str(path))
    try:
        connection.execute("PRAGMA wal_checkpoint(FULL)")
        return connection.serialize()
    finally:
        connection.close()


def _rollback_journal_image(payload: bytes) -> bytes:
    """Turn a checkpointed WAL image into a rollback-journal image.

    SQLite records WAL mode in header bytes 18 and 19. Deserializing that
    image into memory makes later statements try to open a WAL file and fail
    with "unable to open database file".
    """
    if len(payload) < 100 or not payload.startswith(_SQLITE_HEADER):
        raise DatabaseUnlockError("The database file is not a Beyond Registration database.")
    if payload[18] != 2 and payload[19] != 2:
        return payload
    patched = bytearray(payload)
    patched[18] = 1
    patched[19] = 1
    return bytes(patched)


def _remove_sidecars(path: Path) -> None:
    for suffix in ("-wal", "-shm"):
        sidecar = Path(str(path) + suffix)
        sidecar.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Single-writer lock file
# ---------------------------------------------------------------------------
_LOCK_FILES: dict[str, "WriterLock"] = {}
_LOCK_FILES_LOCK = threading.Lock()


def _pid_alive(pid: int) -> bool:
    """True when the process is still running (or when we cannot tell).

    On Windows `os.kill(pid, 0)` is NOT a liveness check: Python's os.kill
    opens the process with PROCESS_ALL_ACCESS, and a process this app cannot
    open that way (a hidden, elevated or console-detached server - the normal
    NEXUS launcher case) raises PermissionError even though it is running. A
    live server whose lock looked dead could then be taken over, so liveness is
    asked of the OS directly instead.
    """
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        return _windows_pid_alive(pid)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True          # exists, owned by another user
    except (AttributeError, ValueError, OSError):
        return True          # cannot tell: never steal a lock blindly
    return True


def _windows_pid_alive(pid: int) -> bool:
    """Ask Windows whether the PID is alive (no handle rights required)."""
    import ctypes
    from ctypes import wintypes
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    except (AttributeError, OSError):
        return True
    query_limited = 0x1000            # PROCESS_QUERY_LIMITED_INFORMATION
    still_active = 259                # STILL_ACTIVE
    error_access_denied = 5
    open_process = kernel32.OpenProcess
    open_process.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    open_process.restype = wintypes.HANDLE
    get_exit_code = kernel32.GetExitCodeProcess
    get_exit_code.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    get_exit_code.restype = wintypes.BOOL
    close_handle = kernel32.CloseHandle
    close_handle.argtypes = [wintypes.HANDLE]
    close_handle.restype = wintypes.BOOL
    handle = open_process(query_limited, False, pid)
    if not handle:
        error = ctypes.get_last_error()
        # 5 = the process exists but we may not open it: it is alive.
        # 87 = invalid parameter: no such process.
        return error == error_access_denied
    try:
        code = wintypes.DWORD()
        if not get_exit_code(handle, ctypes.byref(code)):
            return True
        return code.value == still_active
    finally:
        close_handle(handle)


class WriterLock:
    """One live writer per database file, enforced with a PID lock file.

    A second process that opens the same database while a live server holds it
    gets DatabaseBusyError instead of a second in-memory copy whose commits
    would overwrite the first one's. A lock left behind by a crash is taken
    over: its PID is gone, or its heartbeat stopped.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.token = secrets.token_hex(8)
        self.pid = os.getpid()
        self.released = False
        self._last_beat = 0.0

    # -- helpers ---------------------------------------------------------
    def _body(self) -> str:
        return (f"pid={self.pid}\ntoken={self.token}\n"
                f"started={time.strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"heartbeat={time.time():.3f}\n")

    def _read(self) -> dict[str, str]:
        try:
            text = self.path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return {}
        data: dict[str, str] = {}
        for line in text.splitlines():
            if "=" in line:
                name, value = line.split("=", 1)
                data[name.strip()] = value.strip()
        return data

    def _write(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f"{self.path.name}.{self.token}.tmp")
        temporary.write_text(self._body(), encoding="utf-8")
        os.replace(temporary, self.path)
        self._last_beat = time.monotonic()

    def _age(self) -> float:
        try:
            return max(0.0, time.time() - self.path.stat().st_mtime)
        except OSError:
            return 0.0

    def _stale(self, holder: dict[str, str]) -> bool:
        """A lock is stale only when its owner is gone or its heartbeat stopped."""
        if holder.get("pid") is None:
            return False                 # unreadable body: assume a live owner
        holder_pid = int(holder.get("pid", "0") or 0)
        if not _pid_alive(holder_pid):
            return True
        # The owner is alive, so a quiet file only means an idle database. The
        # age of the file is deliberately not a staleness signal: an idle server
        # must never lose its lock to a second process.
        return False

    # -- lifecycle -------------------------------------------------------
    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for _attempt in range(3):
            try:
                handle = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                holder = self._read()
                if not self._stale(holder):
                    holder_pid = int(holder.get("pid", "0") or 0)
                    raise DatabaseBusyError(
                        "Another Beyond Registration process (PID %d) is already using this database. "
                        "Close it before starting a second copy." % holder_pid)
                # Left behind by a crash: take it over. Only our own token is
                # written, so a race between two recovering processes ends with
                # one of them failing the O_EXCL open on the next attempt.
                try:
                    self.path.unlink()
                except FileNotFoundError:
                    pass
                continue
            else:
                try:
                    os.write(handle, self._body().encode("utf-8"))
                finally:
                    os.close(handle)
                self._last_beat = time.monotonic()
                with _LOCK_FILES_LOCK:
                    _LOCK_FILES[str(self.path)] = self
                return
        raise DatabaseBusyError(
            "Another Beyond Registration process is already using this database. "
            "Close it before starting a second copy.")

    def heartbeat(self) -> None:
        """Refresh the lock while we hold it, so it never looks abandoned."""
        if self.released:
            return
        now = time.monotonic()
        if now - self._last_beat < _LOCK_HEARTBEAT_SECONDS:
            return
        holder = self._read()
        if holder.get("token") != self.token:
            return          # somebody else took over after a stale sweep
        try:
            self._write()
        except OSError:
            pass

    def owns_file(self) -> bool:
        """True when the lock file on disk is still ours."""
        return self._read().get("token") == self.token

    def retake(self) -> None:
        """Claim the lock file again if it is not ours any more.

        A file deleted underneath us (a cleaner, an antivirus, a crashed
        process's cleanup) would otherwise let a second process in while this
        one is still writing, and this connection's own release would then
        delete that second process's lock.
        """
        if self.released or self.owns_file():
            return
        self._write()

    def release(self) -> None:
        if self.released:
            return
        self.released = True
        with _LOCK_FILES_LOCK:
            _LOCK_FILES.pop(str(self.path), None)
        holder = self._read()
        if holder.get("token") == self.token:
            try:
                self.path.unlink()
            except OSError:
                pass


@atexit.register
def _release_all_writer_locks() -> None:
    with _LOCK_FILES_LOCK:
        held = list(_LOCK_FILES.values())
    for lock in held:
        try:
            lock.release()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Debounced persistence
# ---------------------------------------------------------------------------
_FLUSHERS: "list[PersistingConnection]" = []
_FLUSHERS_LOCK = threading.Lock()
_FLUSH_THREAD: threading.Thread | None = None
_FLUSH_WAKE = threading.Event()


def _register_flusher(connection: "PersistingConnection") -> None:
    global _FLUSH_THREAD
    with _FLUSHERS_LOCK:
        _FLUSHERS.append(connection)
        if _FLUSH_THREAD is None or not _FLUSH_THREAD.is_alive():
            _FLUSH_THREAD = threading.Thread(target=_flush_loop, name="br-db-flusher", daemon=True)
            _FLUSH_THREAD.start()


def _unregister_flusher(connection: "PersistingConnection") -> None:
    with _FLUSHERS_LOCK:
        try:
            _FLUSHERS.remove(connection)
        except ValueError:
            pass


def _flush_loop() -> None:
    while True:
        try:
            _FLUSH_WAKE.wait(max(0.2, FLUSH_INTERVAL_SECONDS))
            _FLUSH_WAKE.clear()
        except Exception:
            time.sleep(max(0.2, FLUSH_INTERVAL_SECONDS))
        with _FLUSHERS_LOCK:
            pending = list(_FLUSHERS)
        for connection in pending:
            try:
                connection.flush()
            except Exception as exc:      # never let one bad write kill the writer
                print(f"[BR db] deferred write failed: {type(exc).__name__}: {exc}", flush=True)


def flush_all() -> None:
    """Write every dirty database to disk now (shutdown, backup, health)."""
    with _FLUSHERS_LOCK:
        pending = list(_FLUSHERS)
    for connection in pending:
        connection.flush()


def shutdown_persistence() -> None:
    """Flush everything, stop the writer and drop the writer lock."""
    try:
        flush_all()
    finally:
        with _LOCK_FILES_LOCK:
            held = list(_LOCK_FILES.values())
        for lock in held:
            try:
                lock.release()
            except Exception:
                pass


@atexit.register
def _flush_at_exit() -> None:
    try:
        flush_all()
    except Exception:
        pass


class PersistingConnection(sqlite3.Connection):
    """In-memory database that writes its encrypted file on a short delay.

    commit() only marks the connection dirty: re-encrypting the whole file on
    every commit made each small write pay for the entire database. A
    background writer flushes every FLUSH_INTERVAL_SECONDS, and flush() is
    called directly for auth changes, backups and a clean shutdown.

    Reads inside the same process always see committed data, because the
    database lives in RAM; only the file on disk lags by a few seconds.
    """

    def commit(self) -> None:
        super().commit()
        self._mark_dirty()

    def close(self) -> None:
        try:
            self.flush(force=True)
        finally:
            _unregister_flusher(self)
            try:
                lock = getattr(self, "_writer_lock", None)
                if lock is not None:
                    # The lock file is released by the last connection in this
                    # process that holds it, not by the first one to close.
                    lock.connections = max(0, getattr(lock, "connections", 1) - 1)
                    if lock.connections == 0:
                        lock.release()
            finally:
                super().close()

    # -- persistence -----------------------------------------------------
    def _mark_dirty(self) -> None:
        if not getattr(self, "_persist_enabled", False):
            return
        self._dirty = True
        self._last_change = time.monotonic()
        lock = getattr(self, "_writer_lock", None)
        if lock is not None:
            lock.heartbeat()

    def flush(self, force: bool = False) -> bool:
        """Write the encrypted file if there are changes. Returns True if it wrote."""
        if not getattr(self, "_persist_enabled", False):
            return False
        if not getattr(self, "_dirty", False):
            return False
        with self._persist_lock:
            if not self._dirty:
                return False
            if not force and self.in_transaction:
                return False          # a commit is mid-flight; try again next tick
            lock = getattr(self, "_writer_lock", None)
            if lock is not None:
                lock.retake()     # never write without owning the single-writer lock
            try:
                payload = self.serialize()
                write_encrypted(self._db_path, self._key, payload)
            except sqlite3.Error:
                return False
            # Only a write that reached the disk clears the flag: a failed
            # write stays pending and is retried on the next tick.
            self._dirty = False
            self._last_flush = time.monotonic()
            lock = getattr(self, "_writer_lock", None)
            if lock is not None:
                lock.heartbeat()
            return True

    def pending_write(self) -> bool:
        return bool(getattr(self, "_dirty", False))

    # Backwards-compatible name used by older call sites: write now, whatever
    # the dirty flag says (a new or migrated database has never been written).
    def _persist_database(self) -> None:
        self._dirty = True
        self.flush(force=True)


def connect_database(db_path: Path, key_directory: Path | None = None,
                     exclusive: bool = True) -> PersistingConnection:
    """Open the database in memory, migrating a plaintext file in place.

    exclusive=True (the default) takes the single-writer lock: a second live
    process is refused instead of being allowed to overwrite this one.
    Read-only helpers that must open a live database pass exclusive=False.
    """
    db_path = Path(db_path)
    key_directory = Path(key_directory or db_path.parent)
    writer_lock: WriterLock | None = None
    if exclusive:
        with _LOCK_FILES_LOCK:
            existing = _LOCK_FILES.get(str(Path(writer_lock_path(db_path))))
        if existing is not None and not existing.released:
            # This process already writes this file: share its lock, but make
            # sure the lock file is really ours before a second connection
            # works on it (it may have been deleted or stolen underneath).
            if not existing.owns_file():
                raise DatabaseBusyError(
                    "Another Beyond Registration process has taken over this database's lock "
                    "file. Close this process and start it again.")
            existing.connections = getattr(existing, "connections", 1) + 1
            writer_lock = existing
        else:
            writer_lock = WriterLock(writer_lock_path(db_path))
            writer_lock.acquire()
            # Another connection in this same process (a second Store, a helper)
            # shares the writer lock instead of refusing: the file on disk is
            # only ever written by this process, and close() releases the lock
            # once, when the last connection holding it closes.
            writer_lock.connections = 1
    try:
        key = load_or_create_key(key_directory)
        connection = sqlite3.connect(":memory:", factory=PersistingConnection, check_same_thread=False)
        try:
            connection.execute("PRAGMA busy_timeout = 5000")
        except Exception:
            pass
        connection._db_path = db_path
        connection._key = key
        connection._persist_enabled = False
        connection._persist_lock = threading.RLock()
        connection._dirty = False
        connection._last_change = 0.0
        connection._last_flush = 0.0
        connection._writer_lock = writer_lock
        connection.database_protection = PROTECTION
        if db_path.exists() and db_path.stat().st_size > 0:
            payload = db_path.read_bytes()
            if payload.startswith(_SQLITE_HEADER):
                plaintext = _rollback_journal_image(_sqlite_snapshot(db_path))
                connection.deserialize(plaintext)
                connection._persist_enabled = True
                connection._persist_database()
                if not db_path.read_bytes().startswith(MAGIC):
                    connection.close()
                    raise DatabaseUnlockError("The existing database could not be encrypted.")
                _remove_sidecars(db_path)
            elif payload.startswith(MAGIC):
                connection.deserialize(_rollback_journal_image(decrypt_payload(payload, key)))
                connection._persist_enabled = True
            else:
                connection.close()
                raise DatabaseUnlockError("The database file is not a Beyond Registration database.")
        else:
            connection._persist_enabled = True
            connection.flush(force=True)
        if connection._persist_enabled:
            _register_flusher(connection)
        return connection
    except BaseException:
        if writer_lock is not None:
            writer_lock.release()
        raise


def writer_lock_path(db_path: Path) -> Path:
    """The single-writer lock file that sits beside the database."""
    return Path(db_path).parent / LOCK_FILE


def encrypted_snapshot(plaintext_sqlite: bytes, key: bytes) -> bytes:
    nonce = secrets.token_bytes(12)
    return MAGIC + nonce + AESGCM(key).encrypt(nonce, plaintext_sqlite, MAGIC)


# ---------------------------------------------------------------------------
# Portable recovery key (passphrase-wrapped copy of the DPAPI-sealed key)
# ---------------------------------------------------------------------------
RECOVERY_MAGIC = b"BRRK1\n"
_SCRYPT_N, _SCRYPT_R, _SCRYPT_P = 2 ** 15, 8, 1


def _recovery_kek(passphrase: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    return Scrypt(salt=salt, length=32, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P).derive(passphrase.encode("utf-8"))


def export_recovery_key(key: bytes, passphrase: str) -> bytes:
    """Wrap the 32-byte database key with a passphrase (scrypt + AES-GCM).

    DPAPI ties the live key to one Windows user on one PC. If the laptop is
    lost, stolen, re-imaged or the profile is rebuilt, every backup of the
    encrypted database becomes unreadable. This blob is the copy of the key
    that does not depend on Windows. It is safe to keep inside the backed-up
    Data folder because it is useless without the passphrase - which must be
    kept OFF the laptop (printed, in the office safe).
    """
    if not isinstance(key, (bytes, bytearray)) or len(key) != 32:
        raise ValueError("A 32-byte database key is required.")
    if not isinstance(passphrase, str) or len(passphrase) < 12:
        raise ValueError("Use a recovery passphrase of at least 12 characters.")
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(12)
    sealed = AESGCM(_recovery_kek(passphrase, salt)).encrypt(nonce, bytes(key), RECOVERY_MAGIC)
    return RECOVERY_MAGIC + salt + nonce + sealed


def import_recovery_key(blob: bytes, passphrase: str) -> bytes:
    """Return the database key from export_recovery_key() output."""
    head = len(RECOVERY_MAGIC)
    if not isinstance(blob, (bytes, bytearray)) or not bytes(blob).startswith(RECOVERY_MAGIC) \
            or len(blob) < head + 16 + 12 + 32 + 16:
        raise DatabaseUnlockError("This is not a Beyond Registration recovery key file.")
    salt, nonce, sealed = blob[head:head + 16], blob[head + 16:head + 28], blob[head + 28:]
    try:
        key = AESGCM(_recovery_kek(passphrase or "", bytes(salt))).decrypt(bytes(nonce), bytes(sealed), RECOVERY_MAGIC)
    except Exception as exc:
        raise DatabaseUnlockError("Wrong recovery passphrase, or the recovery file is damaged.") from exc
    if len(key) != 32:
        raise DatabaseUnlockError("The recovery file does not hold a valid database key.")
    return key


def key_check_value(key: bytes) -> str:
    """Short, non-secret fingerprint so a person can confirm two keys match."""
    import hashlib
    return hashlib.sha256(b"BR-KCV" + bytes(key)).hexdigest()[:12].upper()


def install_recovered_key(key: bytes, directory: Path) -> None:
    """Seal a recovered key into THIS PC's DPAPI vault (restore on a new laptop).

    Refuses to overwrite an existing key: replacing a live key would lock the
    current database for good.
    """
    vault = SecretVault(Path(directory) / KEY_FILE)
    if vault.get("database_key"):
        raise DatabaseUnlockError("This PC already has a database key. Move the Data folder aside before restoring.")
    vault.set("database_key", base64.b64encode(bytes(key)).decode("ascii"))
    forget_cached_key(Path(directory))
