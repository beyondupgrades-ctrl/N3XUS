"""Generate a WireGuard-compatible key pair locally (100% in-house).

Run this ON THE DEVICE. It prints the private key and the public key. Send ONLY
the public key to CN3CT. Never paste the private key into a web form or message.

Usage:
    python scripts/cn3ct-keygen.py
    python scripts/cn3ct-keygen.py --public-only
    python scripts/cn3ct-keygen.py --out C:/Users/you/gateway.key
"""
from __future__ import annotations

import argparse
import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey


def _clamp(raw: bytes) -> bytes:
    key = bytearray(raw)
    key[0] &= 248
    key[31] &= 127
    key[31] |= 64
    return bytes(key)


def generate() -> tuple[str, str]:
    private_bytes = _clamp(os.urandom(32))
    private_key = X25519PrivateKey.from_private_bytes(private_bytes)
    public_bytes = private_key.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    encode = lambda value: base64.b64encode(value).decode("ascii")
    return encode(private_bytes), encode(public_bytes)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a WireGuard key pair locally.")
    parser.add_argument("--public-only", action="store_true",
                        help="Print only the public key (safe to paste into CN3CT).")
    parser.add_argument("--out", metavar="PATH",
                        help="Write the private key to this new file instead of printing it.")
    args = parser.parse_args()
    private_key, public_key = generate()
    if args.out:
        destination = Path(args.out)
        if destination.exists():
            parser.error(f"{destination} already exists; refusing to overwrite a key file.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        handle = os.open(str(destination), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(handle, "w", encoding="ascii", newline="\n") as stream:
            stream.write(private_key + "\n")
        try:
            os.chmod(destination, 0o600)
        except OSError:
            pass
        print("PublicKey  =", public_key)
        print("PrivateKey written to:", destination)
        print("Keep that file on this device only. Send PublicKey to CN3CT.")
        return 0
    if args.public_only:
        print(public_key)
        return 0
    print("CN3CT / WireGuard key pair")
    print("PrivateKey =", private_key)
    print("PublicKey  =", public_key)
    print()
    print("Keep PrivateKey on this device only. Send PublicKey to CN3CT.")
    print("Anyone with the private key can join the network as this device.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
