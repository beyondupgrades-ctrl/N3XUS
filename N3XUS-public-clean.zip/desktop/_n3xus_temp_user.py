"""Create ONE temporary test account in the live N3XUS database.

Read-only with respect to code and processes: this talks to the same encrypted
database the running server uses, through the app's own helpers, so the row is
written the way the app writes rows. No server restart is needed.

Usage:
    python _n3xus_temp_user.py add      # create test1
    python _n3xus_temp_user.py delete   # remove it again
    python _n3xus_temp_user.py show     # confirm what is there
"""
import sys, os, datetime

sys.path.insert(0, os.getcwd())

import importlib.util

spec = importlib.util.spec_from_file_location("legacy", "Beyond_Registration.py")
legacy = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(legacy)
except SystemExit:
    pass

TEMP_NO = "TEMP-TEST1"
TEMP_PW = "Test1234!"
FIRST, LAST = "Test", "Tester"

action = (sys.argv[1] if len(sys.argv) > 1 else "add").lower()

# exclusive=False: the live server owns the writer lock; this helper must not
# take it away from a running server.
conn = legacy.connect_database(legacy.DB_PATH, legacy.DATA_HOME, exclusive=False)
conn.row_factory = legacy.sqlite3.Row
stamp = datetime.datetime.now().isoformat(timespec="seconds")

try:
    if action == "add":
        row = conn.execute("SELECT id FROM employees WHERE employee_no=? COLLATE NOCASE", (TEMP_NO,)).fetchone()
        if row:
            eid = int(row["id"])
            print("employee already present, id", eid)
        else:
            cur = conn.execute(
                "INSERT INTO employees(employee_no,first_name,last_name,preferred_name,job_title,department,"
                "employment_status,start_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (TEMP_NO, FIRST, LAST, FIRST, "Temporary Tester", "QA", "Active", stamp[:10], stamp, stamp))
            eid = int(cur.lastrowid)
            print("employee created, id", eid)
        pw_hash = legacy.hash_password(TEMP_PW)
        exists = conn.execute("SELECT employee_id FROM mobile_accounts WHERE employee_id=?", (eid,)).fetchone()
        if exists:
            conn.execute("UPDATE mobile_accounts SET password_hash=?,active=1,updated_at=? WHERE employee_id=?",
                         (pw_hash, stamp, eid))
        else:
            conn.execute("INSERT INTO mobile_accounts(employee_id,password_hash,active,created_at,updated_at)"
                         " VALUES(?,?,1,?,?)", (eid, pw_hash, stamp, stamp))
        conn.commit()
        check = conn.execute("SELECT e.employee_no,e.first_name,e.last_name,e.employment_status,"
                             "a.password_hash,a.active FROM employees e JOIN mobile_accounts a ON a.employee_id=e.id"
                             " WHERE e.employee_no=? COLLATE NOCASE", (TEMP_NO,)).fetchone()
        ok = legacy.verify_password(TEMP_PW, check["password_hash"])
        print("ACCOUNT", check["employee_no"], "|", check["first_name"], check["last_name"],
              "| status", check["employment_status"], "| mobile active", check["active"],
              "| password verifies:", ok)
    elif action == "delete":
        row = conn.execute("SELECT id FROM employees WHERE employee_no=? COLLATE NOCASE", (TEMP_NO,)).fetchone()
        if not row:
            print("no temp account present")
        else:
            eid = int(row["id"])
            conn.execute("DELETE FROM mobile_accounts WHERE employee_id=?", (eid,))
            conn.execute("DELETE FROM employees WHERE id=?", (eid,))
            conn.commit()
            left = conn.execute("SELECT COUNT(*) FROM employees WHERE employee_no=? COLLATE NOCASE", (TEMP_NO,)).fetchone()[0]
            print("deleted employee id", eid, "| rows left:", left)
    else:
        rows = conn.execute("SELECT e.id,e.employee_no,e.first_name,e.last_name,a.active FROM employees e"
                            " LEFT JOIN mobile_accounts a ON a.employee_id=e.id"
                            " WHERE e.employee_no=? COLLATE NOCASE", (TEMP_NO,)).fetchall()
        print([dict(r) for r in rows] or "no temp account present")
finally:
    conn.close()
