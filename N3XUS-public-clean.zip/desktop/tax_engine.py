"""South African payroll tax calculations (100% free, in-house, no external API).

PAYE (progressive brackets LESS the age rebates), UIF (1% up to the monthly
ceiling), SDL (1%), VAT (15%). Amounts are rounded half-up to the cent with
Decimal, never with float round() (which rounds 2.675 down to 2.67).

Tables: SARS 2027 tax year, 1 March 2026 - 28 February 2027.
Update every March from the SARS "Rates of tax for individuals" page and
re-run desktop/tests. This is a calculator, not tax advice: have the
accountant confirm the first payroll run after every update.
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

TAX_YEAR = "2027 (1 March 2026 - 28 February 2027)"

# (upper limit of the band, marginal rate, tax on all income up to the previous limit)
PAYE_BRACKETS = [
    (245100, 0.18, 0),
    (383100, 0.26, 44118),
    (530200, 0.31, 79998),
    (695800, 0.36, 125599),
    (887000, 0.39, 185215),
    (1878600, 0.41, 259783),
    (float("inf"), 0.45, 666339),
]
PRIMARY_REBATE = 17820      # everyone
SECONDARY_REBATE = 9765     # age 65 and older (in addition)
TERTIARY_REBATE = 3249      # age 75 and older (in addition)

VAT_RATE = 0.15
UIF_RATE = 0.01
UIF_CAP = 17712.0           # monthly remuneration ceiling (max R177.12 each side)
SDL_RATE = 0.01


def money(value) -> float:
    """Round half-up to the cent."""
    return float(Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def rebate_for(age=None) -> float:
    total = PRIMARY_REBATE
    if age is not None and age >= 65:
        total += SECONDARY_REBATE
    if age is not None and age >= 75:
        total += TERTIARY_REBATE
    return float(total)


def paye_annual(gross_annual, age=None):
    """Annual tax after rebates; never negative."""
    taxable = max(0.0, float(gross_annual or 0))
    previous_limit = 0
    tax = 0.0
    for limit, rate, base in PAYE_BRACKETS:
        if taxable <= limit:
            tax = base + (taxable - previous_limit) * rate
            break
        previous_limit = limit
    return money(max(0.0, tax - rebate_for(age)))


def paye_monthly(gross_monthly, age=None):
    """Regular monthly PAYE by annualising (x12). Bonuses need the annual-equivalent method."""
    return money(paye_annual(float(gross_monthly or 0) * 12, age) / 12)


def uif_employee(gross_monthly):
    return money(min(max(0.0, float(gross_monthly or 0)), UIF_CAP) * UIF_RATE)


def uif_employer(gross_monthly):
    return money(min(max(0.0, float(gross_monthly or 0)), UIF_CAP) * UIF_RATE)


def sdl(gross_monthly):
    """1% of remuneration. Employers with annual payroll under R500 000 are exempt."""
    return money(max(0.0, float(gross_monthly or 0)) * SDL_RATE)


def vat_exclusive(amount_incl):
    return money(float(amount_incl or 0) / (1 + VAT_RATE))


def vat_inclusive(amount_excl):
    return money(float(amount_excl or 0) * (1 + VAT_RATE))


def vat_amount(amount_excl):
    return money(float(amount_excl or 0) * VAT_RATE)


def payroll_summary(gross_monthly, age=None):
    gross = float(gross_monthly or 0)
    uif = uif_employee(gross)
    paye = paye_monthly(gross, age)
    sdl_v = sdl(gross)
    return {
        "tax_year": TAX_YEAR,
        "gross": money(gross),
        "paye": paye,
        "uif_employee": uif,
        "uif_employer": uif_employer(gross),
        "sdl": sdl_v,
        "net": money(gross - paye - uif),
        "total_employer_cost": money(gross + uif_employer(gross) + sdl_v),
    }
