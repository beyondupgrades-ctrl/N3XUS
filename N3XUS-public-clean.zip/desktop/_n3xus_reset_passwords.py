"""Reset every N3XUS password to the one given on the command line.

Kept as a file so it can be re-run after a restart in one step. Writes ONLY
admins.password_hash and mobile_accounts.password_hash (+ updated_at), using
the app's own hash_password() so both /api/login and /api/mobile/login accept it.
"""
import sqlite3, sys, os, importlib.util, datetime
from pathlib import Path
sys.path.insert(0, os.getcwd())

PW = sys.argv[1] if len(sys.argv) > 1 else "0000"

spec = importlib.util.spec_from_file_location("legacy", "Beyond_Registration.py")
m = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(m)
except SystemExit:
    pass

conn = m.connect_database(m.DB_PATH, m.DATA_HOME)
conn.row_factory = sqlite3.Row
admins = [r["id"] for r in conn.execute("SELECT id FROM admins")]
mobile = [r["employee_id"] for r in conn.execute("SELECT employee_id FROM mobile_accounts")]
stamp = datetime.datetime.now().isoformat(timespec="seconds")
for i in admins:
    conn.execute("UPDATE admins SET password_hash=? WHERE id=?", (m.hash_password(PW), i))
for e in mobile:
    conn.execute("UPDATE mobile_accounts SET password_hash=?, updated_at=? WHERE employee_id=?",
                 (m.hash_password(PW), stamp, e))
conn.commit()

ok_a = sum(1 for i in admins if m.verify_password(PW, conn.execute("SELECT password_hash FROM admins WHERE id=?", (i,)).fetchone()[0]))
ok_m = sum(1 for e in mobile if m.verify_password(PW, conn.execute("SELECT password_hash FROM mobile_accounts WHERE employee_id=?", (e,)).fetchone()[0]))
print("admins reset:", len(admins), "verify:", ok_a)
print("mobile reset:", len(mobile), "verify:", ok_m)
print("db:", m.DB_PATH, os.path.getsize(m.DB_PATH))
conn.close()
