"""VOIC3 Section 14 — interactive workflow cards + immutable compliance export.

Additive only:

* ``hub_messages.metadata_json`` (nullable TEXT) carries the card payload for
  ``leave_card`` / ``safety_checklist`` / ``sos_pin``. Every card still writes a
  human-readable ``body`` (the standard ``text``/``content`` fallback), so an
  older Windows or Mobile build renders a normal message and never blanks out.
* ``workflow_audit_logs`` is an append-only table with a SHA-256 chain
  (``prev_hash`` → ``entry_hash``), so the compliance export can prove the
  records were not edited after the fact.

Nothing here is required by any existing route: a client that never sends a
card, a metadata blob or a geolocation simply keeps working.
"""
from __future__ import annotations

import hashlib
import json
import time

CARD_TYPES = ("leave_card", "safety_checklist", "sos_pin")

SCHEMA = """
CREATE TABLE IF NOT EXISTS workflow_audit_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  ref_type TEXT DEFAULT '',
  ref_id TEXT DEFAULT '',
  actor TEXT DEFAULT '',
  action TEXT NOT NULL,
  details TEXT DEFAULT '',
  latitude REAL,
  longitude REAL,
  prev_hash TEXT DEFAULT '',
  entry_hash TEXT DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_workflow_audit_kind ON workflow_audit_logs(kind, created_at);
CREATE INDEX IF NOT EXISTS idx_workflow_audit_ref ON workflow_audit_logs(ref_type, ref_id);
"""


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_schema(conn):
    """Create the audit table and add the nullable metadata column. Idempotent."""
    conn.executescript(SCHEMA)
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(hub_messages)").fetchall()}
        if "metadata_json" not in cols:
            conn.execute("ALTER TABLE hub_messages ADD COLUMN metadata_json TEXT")
    except Exception:
        pass
    conn.commit()
    return True


# ---------------------------------------------------------------------------
# Audit chain
# ---------------------------------------------------------------------------
def _digest(item, previous):
    material = json.dumps({
        "id": item.get("id"), "kind": item.get("kind"), "ref_type": item.get("ref_type"),
        "ref_id": item.get("ref_id"), "actor": item.get("actor"), "action": item.get("action"),
        "details": item.get("details"), "latitude": item.get("latitude"),
        "longitude": item.get("longitude"), "created_at": item.get("created_at"),
        "prev": previous,
    }, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def log(conn, kind, action, ref_type="", ref_id="", actor="", details="", latitude=None, longitude=None):
    """Append one immutable audit entry and return its id."""
    ensure_schema(conn)
    row = conn.execute("SELECT entry_hash FROM workflow_audit_logs ORDER BY id DESC LIMIT 1").fetchone()
    previous = (row["entry_hash"] if row and row["entry_hash"] else "0" * 64)
    next_id = int(conn.execute("SELECT COALESCE(MAX(id),0)+1 FROM workflow_audit_logs").fetchone()[0])
    item = {
        "id": next_id, "kind": str(kind)[:40], "ref_type": str(ref_type or "")[:40],
        "ref_id": str(ref_id or "")[:80], "actor": str(actor or "")[:120],
        "action": str(action or "")[:80], "details": str(details or "")[:2000],
        "latitude": latitude, "longitude": longitude, "created_at": _now(),
    }
    digest = _digest(item, previous)
    conn.execute(
        "INSERT INTO workflow_audit_logs(id,kind,ref_type,ref_id,actor,action,details,"
        "latitude,longitude,prev_hash,entry_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (item["id"], item["kind"], item["ref_type"], item["ref_id"], item["actor"], item["action"],
         item["details"], latitude, longitude, previous, digest, item["created_at"]),
    )
    conn.commit()
    return next_id


def verify_chain(conn):
    """Re-walk the chain; returns ``{valid, checked, first_bad}``."""
    ensure_schema(conn)
    rows = conn.execute("SELECT * FROM workflow_audit_logs ORDER BY id").fetchall()
    previous = "0" * 64
    checked = 0
    for row in rows:
        item = dict(row)
        if (item.get("prev_hash") or "") != previous:
            return {"valid": False, "checked": checked, "first_bad": int(item["id"])}
        if _digest(item, previous) != (item.get("entry_hash") or ""):
            return {"valid": False, "checked": checked, "first_bad": int(item["id"])}
        previous = item["entry_hash"]
        checked += 1
    return {"valid": True, "checked": checked, "first_bad": 0}


# ---------------------------------------------------------------------------
# Card payloads (stored in hub_messages.metadata_json)
# ---------------------------------------------------------------------------
def card_fallback_text(kind, payload):
    """The readable `text`/`content` string every card also carries.

    Older clients show this exactly as a normal message, which is why it must
    never be empty and must read sensibly on its own.
    """
    payload = payload or {}
    if kind == "leave_card":
        who = payload.get("employee_name") or "An employee"
        return ("Leave request · %s · %s to %s · %.1f day(s) · status: %s" % (
            who, payload.get("date_from") or "?", payload.get("date_to") or "?",
            float(payload.get("days") or 0), payload.get("status") or "Pending"))
    if kind == "safety_checklist":
        items = payload.get("items") or []
        done = sum(1 for i in items if i.get("checked"))
        return ("Shift handover safety checklist · %d of %d items signed off · %s" % (
            done, len(items), payload.get("shift") or "current shift"))
    if kind == "sos_pin":
        where = payload.get("place") or ""
        coords = ""
        if payload.get("latitude") is not None and payload.get("longitude") is not None:
            coords = " · %.5f, %.5f" % (float(payload["latitude"]), float(payload["longitude"]))
        return ("EMERGENCY SOS from %s%s%s · tap the card in VOIC3 for the live pin" % (
            payload.get("employee_name") or "an employee", (" at " + where) if where else "", coords))
    return "VOIC3 card"


def encode_metadata(payload):
    try:
        return json.dumps(payload or {}, separators=(",", ":"), default=str)
    except Exception:
        return "{}"


def decode_metadata(raw):
    try:
        parsed = json.loads(raw) if raw else {}
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Compliance export
# ---------------------------------------------------------------------------
EXPORT_COLUMNS = ("id", "kind", "ref_type", "ref_id", "actor", "action", "details",
                  "latitude", "longitude", "created_at", "entry_hash")


def _csv_cell(value):
    text = "" if value is None else str(value)
    if any(ch in text for ch in (",", '"', "\n", "\r")):
        return '"' + text.replace('"', '""') + '"'
    return text


def export_rows(conn, kind=None, since=None):
    ensure_schema(conn)
    sql = "SELECT * FROM workflow_audit_logs"
    clauses = []
    args = []
    if kind:
        clauses.append("kind=?")
        args.append(str(kind))
    if since:
        clauses.append("created_at>=?")
        args.append(str(since))
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY id"
    rows = [dict(r) for r in conn.execute(sql, tuple(args)).fetchall()]
    return rows


def to_csv(rows):
    lines = [",".join(EXPORT_COLUMNS)]
    for row in rows:
        lines.append(",".join(_csv_cell(row.get(col)) for col in EXPORT_COLUMNS))
    return "\n".join(lines) + "\n"


def _html_escape(value):
    return (str("" if value is None else value).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def to_html(rows, chain=None, title="N3XUS compliance export"):
    """Print-ready HTML (A4, no external assets) for the browser's Save as PDF."""
    chain = chain or {"valid": True, "checked": len(rows), "first_bad": 0}
    groups = {}
    for row in rows:
        groups.setdefault(row.get("kind") or "other", []).append(row)
    body = []
    for kind in sorted(groups):
        body.append('<h2>%s <span class="count">%d record(s)</span></h2>' % (
            _html_escape(kind.replace("_", " ").title()), len(groups[kind])))
        body.append('<table><thead><tr><th>#</th><th>When</th><th>Actor</th><th>Action</th>'
                    '<th>Reference</th><th>Details</th><th>Location</th><th>Hash</th></tr></thead><tbody>')
        for row in groups[kind]:
            loc = ""
            if row.get("latitude") is not None and row.get("longitude") is not None:
                loc = "%.5f, %.5f" % (float(row["latitude"]), float(row["longitude"]))
            body.append(
                "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
                "<td class=\"hash\">%s</td></tr>" % (
                    _html_escape(row.get("id")), _html_escape(row.get("created_at")),
                    _html_escape(row.get("actor")), _html_escape(row.get("action")),
                    _html_escape("%s %s" % (row.get("ref_type") or "", row.get("ref_id") or "")),
                    _html_escape(row.get("details")), _html_escape(loc),
                    _html_escape((row.get("entry_hash") or "")[:16])))
        body.append("</tbody></table>")
    verdict = "Chain intact · %d entries verified" % chain.get("checked", 0) if chain.get("valid") else \
        "CHAIN BROKEN at entry %s — investigate before relying on this export" % chain.get("first_bad")
    return """<!doctype html><html lang="en"><head><meta charset="utf-8">
<title>%s</title>
<style>
@page { size: A4 landscape; margin: 12mm; }
body { font: 12px/1.45 "Segoe UI", Arial, sans-serif; color: #0f172a; margin: 0; }
h1 { font-size: 20px; margin: 0 0 2px; }
.sub { color: #475569; font-size: 11px; margin: 0 0 14px; }
h2 { font-size: 14px; margin: 18px 0 6px; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
.count { font-weight: 400; color: #64748b; font-size: 11px; }
table { width: 100%%; border-collapse: collapse; font-size: 10.5px; }
th { text-align: left; background: #f1f5f9; border: 1px solid #cbd5e1; padding: 5px 6px; }
td { border: 1px solid #e2e8f0; padding: 5px 6px; vertical-align: top; }
td.hash { font-family: "IBM Plex Mono", Consolas, monospace; font-size: 9px; color: #334155; }
.verdict { margin: 10px 0 0; padding: 8px 10px; border-radius: 6px; font-weight: 700; }
.verdict.ok { background: #ecfdf5; color: #065f46; border: 1px solid #6ee7b7; }
.verdict.bad { background: #fef2f2; color: #991b1b; border: 1px solid #fca5a5; }
footer { margin-top: 16px; font-size: 10px; color: #64748b; }
</style></head><body>
<h1>%s</h1>
<p class="sub">Beyond Registration (Pty) Ltd · REG. NO. 2026721121 · generated %s · append-only audit trail</p>
<p class="verdict %s">%s</p>
%s
<footer>Immutable records: SOS incidents, safety sign-offs, leave approvals and meeting attendance.
Each row's SHA-256 hash chains to the previous row, so any edit breaks verification.</footer>
</body></html>""" % (
        _html_escape(title), _html_escape(title), _html_escape(_now()),
        "ok" if chain.get("valid") else "bad", _html_escape(verdict), "\n".join(body))
