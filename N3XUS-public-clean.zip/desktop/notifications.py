"""In-house notification center (100% free, no push service)."""
from __future__ import annotations
from datetime import date

SCHEMA = """
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT NOT NULL, title TEXT NOT NULL,
  body TEXT DEFAULT '', level TEXT DEFAULT 'info', read_at TEXT DEFAULT '',
  created_at TEXT NOT NULL);
"""


def ensure_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def push(conn, recipient, title, body="", level="info"):
    cur = conn.execute("INSERT INTO notifications(recipient,title,body,level,created_at) VALUES(?,?,?,?,?)",
                       (recipient, title, body, level, date.today().isoformat()))
    conn.commit()
    return cur.lastrowid


def list_for(conn, recipient, unread_only=False):
    sql = "SELECT * FROM notifications WHERE recipient=?"
    args = [recipient]
    if unread_only:
        sql += " AND read_at=''"
    sql += " ORDER BY id DESC LIMIT 100"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def mark_read(conn, nid):
    conn.execute("UPDATE notifications SET read_at=? WHERE id=?", (date.today().isoformat(), nid))
    conn.commit()


def unread_count(conn, recipient):
    r = conn.execute("SELECT COUNT(*) c FROM notifications WHERE recipient=? AND read_at=''", (recipient,)).fetchone()
    return int(r["c"]) if r else 0