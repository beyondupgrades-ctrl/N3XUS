@echo off
setlocal
rem ============================================================
rem  NEXUS LAUNCHER - Beyond Registration (Pty) Ltd
rem  Starts the local server (once) and opens the workspace.
rem ============================================================
cd /d "%~dp0desktop"

rem --- configuration ---
rem Bind to loopback by default. Set BR_SERVER_HOST=0.0.0.0 and BR_ALLOW_LAN=yes
rem explicitly only for a trusted LAN/Tailscale test.
set "BR_SERVER_HOST=127.0.0.1"
set "BR_ALLOW_LAN="
set "BR_SERVER_PORT=64281"
rem Satellite SOS shared secret must be set explicitly; never ship a known default.
if not defined BR_SATELLITE_KEY (
    echo BR_SATELLITE_KEY is not set. Satellite SOS ingress is disabled until you set it.
    set "BR_SATELLITE_KEY="
)

rem --- already running? ---
powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort 64281 -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>nul
if %errorlevel%==0 (
    start "" "https://127.0.0.1:64281/"
    exit /b 0
)

rem --- start server hidden, then open UI ---
start "NEXUS Server" /min cmd /c "set BR_SERVER_HOST=%BR_SERVER_HOST%&& set BR_ALLOW_LAN=%BR_ALLOW_LAN%&& set BR_SERVER_PORT=%BR_SERVER_PORT%&& set BR_SATELLITE_KEY=%BR_SATELLITE_KEY%&& python web_backend.py"

rem wait for the port (max ~20s)
set /a tries=0
:waitloop
powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort 64281 -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>nul
if %errorlevel%==0 goto openui
set /a tries+=1
if %tries% GEQ 20 goto fail
ping -n 2 127.0.0.1 >nul
goto waitloop

:openui
rem A native window when it is available, the default browser otherwise.
rem desktop_app.py never starts a second server - it only opens one on 64281.
if exist "%~dp0desktop\desktop_app.py" (
    start "N3XUS" /min cmd /c "cd /d "%~dp0desktop" && python desktop_app.py"
    exit /b 0
)
start "" "https://127.0.0.1:64281/"
exit /b 0

:fail
echo Could not start the NEXUS server on port 64281.
echo Check that Python is installed and try running desktop\web_backend.py manually.
pause
exit /b 1
