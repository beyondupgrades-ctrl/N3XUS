# Camera and Residence Centres

## Appearance and NEXUS AI

**Appearance & Interface** switches between the standard ERP dashboard and the NEXUS presentation. The choice is stored per user in that browser's local storage; it does not change or copy business records. Both views use the same authenticated session, API, database, permissions, payroll, reports and Android-facing API.

NEXUS uses the existing Vision chat endpoint for open-ended ERP answers. Without an existing Vision service connection, the NEXUS dashboard, module shortcuts and presentation still work, but open-ended answers are unavailable. No additional key, service or subscription is introduced.

Spoken replies use a locally installed English Windows voice. The interface prefers a locally installed female-sounding English voice when available and lets the user choose another installed voice. Accent and naturalness depend on the voices installed in Windows; the app cannot promise a particular neutral international accent. NEXUS mouth movement is a speaking animation, not phoneme-level lip synchronization. Voice input is optional and uses browser speech recognition, whose provider may process audio outside the app.

## Live View Centre

The camera relay runs on this Windows PC. It does not use a cloud account, subscription, or external API key. Live-view and relay listeners bind to `127.0.0.1`; camera streams are pulled over the home LAN.

1. Open **Live View Centre** and choose the folder for recordings. The folder is created if needed.
2. Leave retention at **3 days**, or select another value from 1 to 30 days. MediaMTX removes old recording segments automatically.
3. Use Tenda's model/firmware-specific RTSP instructions to enable a local stream and obtain its RTSP address. Enter the complete RTSP URL in the password-style field. The URL, including any camera login, is encrypted with Windows DPAPI and is never displayed after saving.
4. Add each camera stream separately. A dual-channel CH9 can have one entry per lens; give the entries distinct names. The app no longer imposes a fixed feed-count cap; practical capacity depends on PC decode capacity, network throughput, relay load and recording-disk capacity.
5. Use H.264 and a lower-bitrate/substream for a multi-camera grid when available. Browser codec support varies, and high-bitrate main streams can overload Wi-Fi or disk. Start with one verified feed and increase gradually while checking CPU, network and free disk space.

Recordings are saved as fragmented MP4 segments, typically one-hour segments. At 4 Mbps, 15 feeds can use about 1.94 TB over 3 days; dual-channel feeds or lower/higher bitrates change that estimate. Check free space on the selected drive before enabling many streams.

The folder must remain available while the application is running. Keep it outside temporary folders and avoid using the same directory for unrelated files. The app only previews/deletes supported video files within the selected recording tree. Preview a month or a time range before confirming permanent deletion. Time matching uses the clip-start timestamp in the filename when available, otherwise the file timestamp.

The relay's RTSP and WebRTC ports are bound to loopback only. Do not change them to listen on all network interfaces or expose them through router port forwarding. Live playback requires a working RTSP URL and local camera credentials where the camera requires them; these are device credentials, not API keys.

## Residence Control Centre

The identified bulb is the **BNETA IoT Smart WiFi LED Bulb Plus B22P**, SKU `IO-WIFI60-B22P`. BNETA's product page lists 9 W, 806 lm, RGB and 2700-6500 K white, dimming, 2.4 GHz Wi-Fi, timers/schedules, and BNETA/io.e app support. Alexa and Google Home are described as working through the Smart Life service. The published specifications do not list Matter or a local LAN protocol, so this build displays the bulb but does not issue cloud commands or claim direct local control.

Source: [BNETA B22P product specification](https://www.bneta.co.za/product/smartbulb_b22/).

Other Smart Life devices still need their exact make/model checked. Smart Life branding alone does not prove Matter or local protocol support. Matter pairing is local and needs the device setup code entered on the PC; never share that code in chat. Non-Matter devices need a documented local protocol or a local hub. Cloud-only control is intentionally not used.

## Included relay

MediaMTX is distributed under the MIT License. Its license is in `desktop/tools/MEDIAMTX-LICENSE.txt`. The official Windows amd64 release archive was checksum-verified before packaging.