BEYOND REGISTRATION — ESS MOBILE PREVIEW 5.1.0

Start with MOBILE_SETUP_5.1.0.md.

This release adds an installable mobile web app and employee-scoped API to the existing Windows application. It is a preview/PWA, not a signed Android APK. Native Android biometrics and push notifications are follow-on work.

Important: Windows stays the source of truth. The mobile API is loopback-only by default. LAN access requires TLS certificate/key configuration and explicit opt-in. Configure a certificate trusted by Windows and the phone; restrict the listener with Windows Firewall. The existing Android device has not been acceptance-tested.

Run tests from the desktop folder:
  python -m unittest -v tests.test_backend_smoke tests.test_your-userd_extensions tests.test_mobile_api
