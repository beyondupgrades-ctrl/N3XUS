BEYOND REGISTRATION — MODERN DESKTOP EDITION 5.0.21
==================================================

THIS IS A GENUINE INTERFACE REPLACEMENT
---------------------------------------
The previous Tkinter screens have been replaced by a modern HTML/CSS application
running in a native desktop window (pywebview + Microsoft Edge WebView2 on Windows).
The new design uses a midnight/navy visual system inspired by your supplied SharePoint
reference: layered translucent panels, subtle glass effects, luminous cyan/blue/violet
accents, rounded surfaces, contemporary typography, modern icons, responsive layouts,
charts, modal forms and smooth micro-interactions.

WHAT IS REDESIGNED
------------------
- Modern sign-in and first-run administrator setup.
- Glass dashboard with workforce metrics, attendance chart, department distribution,
  recent activity and workspace shortcuts.
- Employee directory and redesigned employee profile/editor.
- HR management records.
- Attendance, manual hours, KM30 XLSX/CSV imports, shift settings and rebuild.
- Leave applications, approvals/declines and leave balances.
- Contracts, employee documents and performance reviews.
- Payroll entry, live pay calculation preview, rates and shift configuration.
- Vision AI connection and chat workspace.
- Reports, audit trail, administrator access, settings, backup and restore.

EXISTING BUSINESS DATA IS RETAINED
----------------------------------
The new interface imports and calls the original Python Store/business layer. It uses
the same Beyond Registration data directory and existing SQLite database path:
Windows: %LOCALAPPDATA%\Beyond Registration\Data\your-userd_registration.db
Employee photos, employee documents and full backups remain in that same data folder.
The distribution does NOT contain or overwrite your live employee/payroll database.
The Store schema setup is idempotent and retains existing records. Do not delete the
Beyond Registration Data folder when replacing the application files.

INSTALL / RUN ON WINDOWS
-----------------------
1. Make a full backup of your current data before first launch (recommended).
2. Extract this ZIP to a normal folder, for example:
   C:\BeyondRegistration\Modern
3. Install Python 3.10 or newer if it is not already installed. During installation,
   enable "Add Python to PATH". Python's standard installation should include Tkinter,
   which is imported by the retained legacy business module.
4. Double-click Run_Beyond_Registration.bat.
   The launcher checks ReportLab PDF support every time. If ReportLab is missing, it
   attempts to install it using the same Python interpreter that starts the application.
   An internet connection is required for this first-time repair. pywebview is optional;
   if it is unavailable, the app can use its supported browser fallback.
5. On first use, create an administrator account with a password of at least 10 chars.
   If your existing database already has administrators, sign in using your existing
   Beyond Registration username and password. Your employee data is not re-created.

WINDOWS WEB RUNTIME
-------------------
The native application window uses pywebview and Microsoft Edge WebView2. Windows 10/11
usually has the WebView2 runtime installed. If the native window component is unavailable,
the launcher falls back to your default browser and keeps the local application server
running in the console window. Do not close that console while using the browser fallback.


LOGIN ACCOUNT PICKER (5.0.4)
---------------------------
- Existing active administrator accounts are loaded from your current SQLite database.
- Select your account by display name (for example, Dean Brown), then enter only your
  password. The selected value submits the matching existing username securely to the
  local sign-in endpoint.
- Disabled accounts are not shown. Password hashes and account IDs are never exposed
  by the login-options endpoint. If the account list cannot be loaded, manual username
  entry remains available as a fallback.
- First-run administrator setup remains unchanged. No existing passwords are changed.

VISION AI CONNECTION
--------------------
Vision is accessed from the Vision AI workspace. Open Settings and enter the PUBLISHED
HTTPS Cloud Run API URL. Do not use an AI Studio preview URL (for example an ais-dev URL),
which may return a browser cookie-check HTML page rather than API JSON. The service must
provide POST /api/chat and return JSON. GEMINI_API_KEY belongs only on the Vision server
(e.g. in Google Secret Manager), never in this Windows desktop package.
This package deliberately clears the old AI Studio preview URL rather than silently using
an endpoint already known to return HTML. Vision network access is not assumed to work
until you configure and test a published API endpoint.

VISION CHAT COMPOSER (5.0.1)

MODAL / FORM INTERACTION FIXES (5.0.2)
-------------------------------------
- Fixed modal event propagation so clicks inside dialogs reach their own controls.
- Submit buttons are now native submit buttons correctly associated with each modal form.
- Cancel, the × close control, and clicking the backdrop close the dialog.
- The Escape key remains an optional keyboard shortcut, not the only way to close.
- Read-only employee profile dialogs display a Close action rather than a Save action.
- Dialogs focus their first usable field when opened.

----------------------------
- Send is now a clearly labelled, clickable button with a paper-plane icon.
- Press Enter to send; use Shift+Enter to add a new line.
- Use Attach files to stage up to 4 supported files per message (8 MB total): PDF,
  TXT, MD, CSV, JSON, PNG, JPG/JPEG and WEBP. Remove staged files before sending if needed.
- Text files are sent as extracted text; PDFs and supported images are sent as file data
  to the configured Vision API. Office documents are not accepted by this composer.
- Attachments are sent only when you send the Vision message; they are not silently
  included in other business requests.

SECURITY / PRIVACY
------------------
- The local bridge binds only to 127.0.0.1 on a randomly selected port.
- The browser interface uses a local session cookie after sign-in.
- The business database and employee files remain on this computer.
- Vision prompts and files you explicitly attach in the Vision composer are sent to the
  configured external service when you press Send. Business records and payroll data are
  not silently attached.
- Use Windows account security and keep full backups protected because they contain
  confidential employee and payroll information.

VALIDATION & LIMITATIONS
------------------------
The package is validated for Python syntax, JavaScript syntax, backend API smoke tests,
ZIP integrity and preservation of the existing Store/database code. It has not been run
on your specific Windows PC, and your local database, WebView2 runtime, installed fonts,
Vision deployment and network permissions cannot be verified here.
This is the new interface foundation and includes the core day-to-day workflows above.
Some legacy attachment, payslip delivery and bespoke import edge cases may need follow-up
parity work after you test against your live business database. Keep the prior application
folder and backup until you have verified your workflows in this edition.

VERSION 5.0.8 UPDATE
- WhatsApp Web now opens in a dedicated native pywebview window within the Beyond Registration desktop application, rather than launching the default browser.

VERSION 5.0.5 UPDATE
- Vision can request approved in-app navigation using structured THOR_ACTION tokens. The local UI validates destinations and resolves staff profiles against the signed-in employee directory; it does not permit data mutations.
- Text inputs and chat areas retain native right-click context menus and text selection for Copy, Paste, Cut and Select All in supported WebView/browser hosts.
- Communications now presents a central two-channel hub: WhatsApp and Email. Gmail only/ are provider options within Email.
- WhatsApp Cloud API credentials and email OAuth connections still need to be configured by the administrator. This build does not claim provider accounts are connected until the status endpoint confirms them.
- Existing local SQLite data location is unchanged. Back up your database before upgrading/testing.


COMMUNICATIONS CENTRE (5.0.7)
----------------------------
- WhatsApp Web opens in a separate native desktop window managed by Beyond Registration; it does not launch your default browser. On your phone, choose WhatsApp >
  Linked devices > Link a device and scan the QR code shown in that window. This
  does not require a Meta API token. The WhatsApp page is hosted by WhatsApp and is not embedded into the HR Communications Centre panel. It is a linked-device/manual messaging
  experience; it is not an automation API and does not enable automatic HR alerts.
- The optional WhatsApp Cloud API form remains available under Advanced for
  official automated business messaging when Meta credentials are configured.
- Email connects through Google OAuth (Gmail) only. Configure the Google OAuth
  Desktop Client ID in Settings > Communications integrations, then use Connect
  Gmail in the Email channel. The app requests Gmail mail permissions;
  provider/admin consent may be required. No email password is stored by the app.
- Email sending and inbox access require successful provider authorization.


VERSION 5.0.9 PAYROLL UPDATE
- Payroll table now has an Edit / status action on every entry.
- Existing payroll records can be reopened, edited and saved.
- Status can be changed between Draft, Approved and Paid.
- Saving recalculates gross pay, UIF, deductions and net pay using the existing payroll rate settings.
- Existing SQLite database and payroll calculations are retained.

Before testing, create a full backup from Settings > Business data & backups.


VERSION 5.0.10 UPDATE — RECORD ACCESS & EDITING
------------------------------------------------
- Employee profiles can be opened and edited from the employee directory.
- HR records, contracts, employee documents and performance reviews now have View and Edit actions on each saved row.
- Leave applications can be viewed and edited after creation, including their status. Pending requests retain Approve and Decline actions.
- Payroll entries retain the View / Edit workflow and status changes.
- Attendance rows now have a View details action so the stored punch summary, hours, source and adjustment metadata can be inspected. Biometric-imported attendance is not directly editable here; correct source punches and rebuild attendance instead.
- Saved employee attachments can be opened from the relevant record detail view when the file still exists in the employee document folder. Replacing an attachment is supported in record editing.
- Read-only operational areas such as audit history and dashboard reports remain read-only by design. User access remains managed through dedicated administrator actions.

This update adds record-level viewing/editing for the main HR data-entry modules. It does not make every derived/system record editable: imported biometric punches, audit events, calculated dashboard metrics and generated reports are intentionally protected. Back up your live database before testing.


VERSION 5.0.11 — ADMIN CONTROLS FOUNDATION
------------------------------------------
- Adds an always-visible Logout button to the main application top bar.
- Logging out clears the authenticated server session and client-side employee,
  record and Vision conversation state, then returns to sign-in without stopping
  the application server. Another authorised user can sign in without restarting.
- Adds administrator-confirmed deletion for HR, contract, document, performance
  review, leave, payroll and manual attendance records.
- Deletion is allow-listed and audited. Only Draft/Drafted payroll records can be
  deleted. Approved leave and imported attendance are protected from deletion.
- Employee master records are not hard-deleted by this update because doing so
  could break linked payroll, attendance, leave and compliance history.

IMPORTANT SCOPE NOTE
--------------------
This is an administrative-controls foundation update, not completion of the full
Beyond Registration roadmap. The monthly payslip PDF workflow, approved-payslip
WhatsApp attachment delivery, removal of the old email/communications screens,
Vision service verification, anomaly engine, contract OCR/expiry alerts, ESS
portal, forecasting, audit exporter, Tier 13–16 intelligence modules, encryption
key architecture and regulatory sandbox remain to be implemented and tested.
WhatsApp automated sending requires a supported provider integration and valid
configuration; this package does not claim that the free WhatsApp Business app
supports unattended background sending.

TESTING
-------
The source package is checked for Python syntax, JavaScript syntax and ZIP
integrity. This is not a Windows UI acceptance test. Back up the existing
Beyond Registration data folder before installing and test on a copy first.


VERSION 5.0.12 - PAYROLL & WHATSAPP PAYSLIP FOUNDATION
- Adds a dedicated employee WhatsApp number field with a safe additive SQLite migration.
- Adds Drafted / Approved / Sent / Paid payroll workflow values (legacy Draft records remain readable).
- Adds employer UIF as a separate employer-paid amount on generated payslips.
- Generates a professional PDF payslip from a saved payroll record.
- Approved payslips can be uploaded and sent as PDF document attachments through the official WhatsApp Business Platform API.
- Removes the Gmail/email user-facing communications workflows.
- The free WhatsApp Business mobile app alone does not provide unattended Cloud API sending; official Meta API credentials are required.

LIMITATIONS / NEXT IMPLEMENTATION PHASE
- South African statutory UIF ceiling and other employer-specific statutory settings require confirmation against current official regulations and must be configured/verified before production payroll. Existing calculation rates are retained; this release does not claim a complete statutory payroll engine.
- Delivery status is currently recorded as Meta API accepted (Sent); Delivered/Read webhook tracking is not yet implemented.
- Payslip PDF currently contains core payroll and employer UIF summary; company registration/contact details, leave/YTD summaries, payment details, logo, corrections/version history and full payroll audit package remain outstanding.
- This is a staged release, not completion of the full BR roadmap.


VERSION 5.0.13 - COMPLIANCE ALERTS & PAYROLL RECONCILIATION
- Adds a Compliance & Alerts workspace with 90-day contract and employee-document expiry monitoring.
- Adds deterministic payroll checks for duplicate employee/period records, payroll entries for inactive employees, and active employees with payroll but no current active contract record.
- Alerts are advisory and do not automatically withhold wages or change payroll.
- This does not yet perform OCR/AI contract extraction, signature validation, or a complete legal compliance check.


VERSION 5.0.14 — RECONCILIATION DETAIL & VERIFIED BACKUPS
---------------------------------------------------------
- Payroll reconciliation findings now have a View details action. The detail window
  shows the employee, underlying payroll records, contract records, attendance, leave
  and related audit history where available.
- Ctrl+K / Cmd+K opens the compliance review for a pre-execution check. Findings are
  advisory and never automatically stop or withhold legally owed wages.
- Full local backups now include a SHA-256 integrity manifest. Restore validates each
  listed file before changing the live database. Older backups without a manifest remain
  supported. A safety backup is still created before restore.
- The backup utility does not automatically purge old snapshots or business records.
  Temporary working files created during a backup are removed after the archive is made.
- Gmail/email connector code has been removed; payslip delivery remains WhatsApp-only.

IMPORTANT SCOPE & TESTING NOTES
------------------------------
This is a focused maintenance release, not a claim that every item in the wider
Beyond Registration roadmap is complete. Offline Ollama/WebLLM switching, ESS/mobile
portal, automated contract/NDA templates, statutory rule monitoring, predictive
forecasting, regulatory audit export and end-to-end Vision action execution still need
separate implementation and environment-specific verification. WhatsApp document
delivery requires the customer's own official Meta WhatsApp Business Platform setup.
The package has passed source syntax and archive-integrity checks; it has not been
Windows UI-tested against your live database in this environment. Back up your data
before installing any new build.


VERSION 5.0.15 UPDATE — CLIPBOARD & RIGHT-CLICK EDITING
-------------------------------------------------------
- Added an application-owned right-click menu for editable text fields in the desktop
  WebView: Cut, Copy, Paste and Select all.
- Added Ctrl+X, Ctrl+C, Ctrl+V and Ctrl+A handling for editable text controls, including
  login fields, employee forms, payroll/attendance forms and the Vision chat composer.
- Added a native desktop clipboard bridge. On Windows it reads/writes Unicode text using
  the Windows clipboard API; the browser fallback uses the browser clipboard facilities.
- Read-only and disabled fields do not allow Cut or Paste. Copy and Select all remain
  available where applicable.
- This release preserves the existing business database location and does not include
  or overwrite the live employee/payroll database. Back up your data before replacing
  application files, as with every update.

DEVELOPMENT ROADMAP — ADDITIONAL REQUIREMENTS
---------------------------------------------
The following items remain planned requirements and are not represented as completed
features by this clipboard maintenance release:
- 30/60/90-day payroll and cash-flow forecasting.
- Attendance trend and anomaly detection.
- Automated onboarding and contract-compliance tasks.
- Secure outbound webhooks and API integrations.
- OCR for receipts, invoices and tax documents.
- Digital signatures with tamper-evident verification.
- Role-based dashboards and granular permissions.
- Offline-first synchronization.
- Cryptographically verifiable audit exports.


VERSION 5.0.16 UPDATE — PAYSLIP PDF RUNTIME REPAIR
-------------------------------------------------
- Fixed the launcher dependency check: previously it checked only pywebview, so a PC
  with pywebview installed but ReportLab missing skipped the requirements installer.
- Added ensure_runtime_dependencies.py to verify ReportLab using the exact Python
  interpreter used by the launcher.
- If ReportLab is missing, the launcher installs it and verifies the import before
  opening the application. pywebview remains optional because browser fallback exists.
- If repair fails, the app is not started with incomplete PDF support; a clear error
  is shown instead.
- Existing business data and database paths are unchanged.

AUTONOMY STATUS / IMPORTANT LIMITS
----------------------------------
This release improves startup self-repair but is not a fully autonomous or fully
self-contained installer. Python and Windows WebView2 remain prerequisites. First-time
package repair requires internet access. Gmail, WhatsApp Cloud API and Vision require
external provider accounts, credentials/authorization and network access. Biometric
clock integration depends on the supported KM30 export format and device workflow.
The new forecasting, OCR, e-signature, webhook/API, offline sync and cryptographic audit
export roadmap items are not represented as completed in this release.


VERSION 5.0.17 UPDATE — PAYSLIP REVIEW & WHATSAPP STATUS CLARITY
------------------------------------------------------------------
- Payroll now has a Review PDF action that opens an in-app PDF preview. The preview
  provides Open separately, Print, Download PDF and Close preview controls. Closing
  the preview does not alter or delete the payroll record.
- PDF responses display inline for preview and use an explicit download query for
  the Download action.
- Added persistent WhatsApp submission fields to existing payroll databases using
  safe additive SQLite migrations; existing employee and payroll records are retained.
- After a successful Meta API response, the payroll record shows the exact state
  “Accepted by WhatsApp — awaiting delivery report”, the recipient, submission time
  and WhatsApp message ID. The payroll workflow is no longer falsely changed to Sent
  merely because the API accepted the request.
- Payroll and WhatsApp delivery screens display the WhatsApp status separately from
  the payroll approval/payment status.
- IMPORTANT: This release records Meta API acceptance, not handset delivery or read
  confirmation. Actual Sent / Delivered / Read / Failed updates require a publicly
  reachable HTTPS Meta webhook, configured and subscribed in the user's Meta app.
  This desktop-only release does not yet include a public webhook host or automatic
  delivery-receipt callback processing, so the status will remain awaiting delivery
  report until that integration is implemented and connected.
- Validation performed: Python source compilation, JavaScript syntax check, PDF
  response code inspection, and ZIP integrity check. A live Windows WebView preview,
  live Meta send, and actual employee-device delivery were not testable here.

INSTALLATION / DATA SAFETY
--------------------------
Install the application files without deleting or replacing the existing Beyond
Registration Data folder. Make a fresh backup before updating. The update includes
only additive database columns for WhatsApp submission tracking.


VERSION 5.0.18 UPDATE — OTHER DEDUCTION REASONS ON PAYSLIPS
- The payroll Notes field is now printed directly beneath the “Other authorised deductions” line whenever an Other deduction amount is entered.
- If an Other deduction amount is present but payroll Notes are blank, the payslip explicitly says the reason was not provided and should be updated.
- Applied to both the modern desktop PDF generation service and the legacy payslip PDF/HTML generation path.
- No database schema change; existing payroll records and notes are preserved.


VERSION 5.0.21 — PAYSLIP & VERSION CONSISTENCY REPAIR
----------------------------------------------------
- Corrected the modern API bootstrap version and visible login version to 5.0.21.
- Payslip PDF from the modern backend now uses A4 landscape, matching the requested
  formal payslip layout.
- Added cumulative approved/paid/sent gross earnings, employee UIF, employer UIF,
  deductions and net pay to date, bounded to the active contract start date when an
  active contract is on file. If no active contract start date exists, the payslip
  labels the totals as cumulative recorded payroll instead of implying a contract date.
- The “Other authorised deductions” explanation remains printed from payroll Notes.
- Isolated API smoke checks cover first-run setup, employee create/read, payroll
  calculation and creation, PDF generation, compliance retrieval, backup creation,
  and unauthenticated API rejection.
- Python compilation, JavaScript syntax, one-page landscape PDF generation and the
  isolated API smoke test passed in the build environment. This is not a Windows UI
  acceptance test and does not verify live Gmail, WhatsApp, KM30 or Vision connections.


MASTER CHECKLIST
----------------
See ROADMAP_STATUS.md for the current implementation, partial implementation,
missing modules and the external items needed for final Windows acceptance.
The roadmap file intentionally distinguishes source presence from tested functionality.

DEVELOPER SMOKE TEST
--------------------
The optional regression test is in desktop/tests. Install desktop/tests/requirements-test.txt
and run `python -m unittest -v test_backend_smoke.py` from that folder. It uses a
disposable test data directory and does not access the live Beyond Registration database.


VERSION 5.0.21 — WHATSAPP CLICK-TO-CHAT + VISION COPY
- Added a WhatsApp link action beside the existing official WhatsApp API send option on approved payslips.
- The link action validates the employee's saved international WhatsApp number, starts a payslip PDF download, and opens a pre-filled wa.me message. The PDF must be attached manually in WhatsApp before sending.
- Added a Copy response control to every Vision AI answer, using the Windows desktop clipboard bridge when running in the installed app and browser clipboard fallback where available.


VERSION 5.0.22 OWNER-TEST UPDATE
--------------------------------
- This package is based on the supplied 5.0.21 source and adds a hash-linked, append-only audit log, integrity verification, an Audit trail screen verification control and an audit JSON export endpoint.
- The build passed isolated backend integration testing, Python compilation and JavaScript syntax validation.
- This is a development/owner-test build, not the final 116-requirement production release.
- Extract to a separate folder, back up your data, and test on a copy of the database. Do not overwrite your existing installation or use this as your only live payroll system.
- Read RELEASE_NOTES_5.0.22_OWNER_TEST.md and QA_REPORT_5.0.22_OWNER_TEST.md before testing.


VERSION 5.0.23 OWNER TEST PACKAGE — 134 REQUIREMENTS
---------------------------------------------------
This package adds the owner's 134-requirement master development plan and a 134-row
traceability tracker. See:
- MASTER_DEVELOPMENT_PLAN_134_REQUIREMENTS.pdf
- REQUIREMENTS_TRACEABILITY_134.csv
- OWNER_TEST_SCOPE_5.0.23.md
- RELEASE_NOTES_5.0.23_OWNER_TEST.md

IMPORTANT: 5.0.23 is a scope and owner-test handover update. The 5.0.22 application
source is carried forward unchanged. This package does NOT claim all 134 requirements
are implemented, and it does not contain the Android Staff Connect APK. Back up your
Beyond Registration Data folder and test against a copy.


5.0.24 OWNER-TEST EXTENSIONS
----------------------------
This ZIP adds ten optional Python service modules under desktop\\your-userd_extensions.
They are importable building blocks, not yet connected to the existing UI or live
business workflows. Read OWNER_TEST_SCOPE_5.0.24.md,
RELEASE_NOTES_5.0.24_OWNER_TEST.md and desktop\\your-userd_extensions\\README.md
before testing. Extension tests can be run from the desktop folder with:
    python -m unittest -v tests.test_your-userd_extensions
The generic ACB export is not bank-certified. WhatsApp needs real Meta credentials.
Encrypted backups require safe Fernet key custody. Test with copied data only.
